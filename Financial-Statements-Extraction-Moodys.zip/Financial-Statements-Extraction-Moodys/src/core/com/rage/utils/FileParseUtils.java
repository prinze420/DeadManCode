package com.rage.utils;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FileParseUtils 
{
	public static List<List<String>> parseFile(String fileName, String delimiter, int size)
	{
		List<List<String>> ret = new ArrayList<List<String>>() ;
		
		BufferedReader br = null ;
		
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;
			
			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;
				
				String[] split = line.split(delimiter) ;
				if ( split.length != size )
					continue ;
				
				List<String> tokens = new ArrayList<String>(Arrays.asList(split)) ;
				ret.add(tokens) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing Buffered-Reader: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		
		return ret ;
	}
}
