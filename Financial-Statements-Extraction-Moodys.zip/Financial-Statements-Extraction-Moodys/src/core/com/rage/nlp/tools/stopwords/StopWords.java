package com.rage.nlp.tools.stopwords;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;

import com.rage.utils.Configuration;

public class StopWords 
{
	private static String PROPERTY_STOP_WORDS_FILE = "stop.words.file" ;
	private static HashSet<String> stopwords ;
	
	public static HashSet<String> getStopWords()
	{
		if ( stopwords == null )
		{
			//String fileName = Configuration.getProperty(PROPERTY_STOP_WORDS_FILE) ;
			stopwords = loadStopWordsFromFile("./resource/stop-words/stop-words.txt") ;
		}
		
		return stopwords ;
	}

	private static HashSet<String> loadStopWordsFromFile(String fileName) 
	{
		HashSet<String> stopwords = new HashSet<String>() ;
		
		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(fileName)))) ;
			String line = "" ;
			
			while ( (line = br.readLine()) != null )
			{
				line = line.trim() ;
				if ( line.equals("") )
					continue ;
				
				line = line.toLowerCase() ;
				stopwords.add(line) ;
			}
			
			br.close() ;
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN LOADING STOP WORDS FROM FILE : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		
		return stopwords ;
	}
	
	public static boolean isStopWord(String token)
	{
		if ( getStopWords().contains(token) )
			return true ;
		
		return false ;
	}
}
