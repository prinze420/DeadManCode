package com.rage.table.data;

public class Cell {


	String str;
	int row;
	int cols;
	float yCoordinate;
	int TotalCols;
	

	public int getTotalCols() {
		return TotalCols;
	}
	public void setTotalCols(int totalCols) {
		TotalCols = totalCols;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + cols;
		result = prime * result + row;
		result = prime * result + ((str == null) ? 0 : str.hashCode());
		result = prime * result + Float.floatToIntBits(yCoordinate);
		return result;
	}
	@Override
	public String toString() {
		return "Cell [str=" + str + ", row=" + row + ", cols=" + cols + ", yCoordinate=" + yCoordinate + ", hashCode()="
				+ hashCode() + ", getStr()=" + getStr() + ", getyCoordinate()=" + getyCoordinate() + ", getRow()="
				+ getRow() + ", getCols()=" + getCols() + ", getClass()=" + getClass() + ", toString()="
				+ super.toString() + "]";
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Cell other = (Cell) obj;
		if (cols != other.cols)
			return false;
		if (row != other.row)
			return false;
		if (str == null) {
			if (other.str != null)
				return false;
		} else if (!str.equals(other.str))
			return false;
		if (Float.floatToIntBits(yCoordinate) != Float.floatToIntBits(other.yCoordinate))
			return false;
		return true;
	}
	public String getStr() {
		return str;
	}
	public float getyCoordinate() {
		return yCoordinate;
	}
	public void setyCoordinate(float yCoordinate) {
		this.yCoordinate = yCoordinate;
	}
	public void setStr(String str) {
		this.str = str;
	}
	public int getRow() {
		return row;
	}
	public void setRow(int row) {
		this.row = row;
	}
	public int getCols() {
		return cols;
	}
	public void setCols(int cols) {
		this.cols = cols;
	}
	

}
