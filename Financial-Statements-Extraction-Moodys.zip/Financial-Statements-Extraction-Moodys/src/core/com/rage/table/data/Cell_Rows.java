package com.rage.table.data;


public class Cell_Rows {

	 int Row_No;
	 int Y1;
	 int Y2;
	// public Cell_Rows( int row, int Y1, int Y2) {
//		setRow_No(row);
//		setY1(Y1);
//		setY2(Y2);
	//}
	 @Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + Row_No;
			result = prime * result + Y1;
			result = prime * result + Y2;
			return result;
		}
		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Cell_Rows other = (Cell_Rows) obj;
			if (Row_No != other.Row_No)
				return false;
			if (Y1 != other.Y1)
				return false;
			if (Y2 != other.Y2)
				return false;
			return true;
		}
		@Override
		public String toString() {
			return "Cell [Row_No=" + Row_No + ", Y1=" + Y1 + ", Y2=" + Y2 + "]";
		}
	 
	 
	 public int getRow_No() {
		return Row_No;
	}
	public void setRow_No(int row_No) {
		Row_No = row_No;
	}
	public int getY1() {
		return Y1;
	}
	public void setY1(int y1) {
		Y1 = y1;
	}
	public int getY2() {
		return Y2;
	}
	public void setY2(int y2) {
		Y2 = y2;
	}
	//public int compare(Object o1,Object o2) {
//		int ret = -1;
//		Cell_Rows r1 = (Cell_Rows)o1;
//		Cell_Rows r2 = (Cell_Rows)o2;
////		if(r1.getY1()> r2.getY1())
////		{
////		maxX2.add(o2);
//		 return Integer.valueOf(r1.getY1()).compareTo(r2.getY1());
	//	
////		}
////		else if (r1.getY1()<r2.getY1())
////		{
//////			maxX2.add(o1);
////			return -1;
////		}
////		else {
//////			maxX2.add(o2);
//////			maxX2.add(o1);
////			return 0;
////		}
////		return ret;
	//}

	 
	 

}
