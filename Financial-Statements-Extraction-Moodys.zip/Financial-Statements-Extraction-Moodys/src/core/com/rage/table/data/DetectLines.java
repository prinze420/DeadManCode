package com.rage.table.data;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFImageWriter;

import com.rage.extraction.pdf.utils.Pair;

/*import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;*/

public class DetectLines {


	static int threshold=140;
	static BufferedImage img, oimg;
	static int VerticalGap = 60;
	static List<Line> HLine= null;
	static float Hratio=0;
	static float Wratio =0;
	
	public static List<Line> detectLines(BufferedImage img,boolean horizontal){
		List<Line> lines = new ArrayList<Line>();
		
		Raster raster = img.getData();
		
		//**********Decide how to parse the pixel matrix based on whether to extract horizontal/vertical line
		int outer = horizontal ? img.getHeight() : img.getWidth();
		int inner = horizontal ? img.getWidth() : img.getHeight();
		int minLineLength = (int)(horizontal ? img.getWidth()*(0.03) : img.getHeight()*(0.02));
		System.out.println("Min line lenght - "+minLineLength);
		//***************************************
		
		//************Detect lines
		for(int i=0;i<outer;i++){
			
			Line line = null;
			for(int j=0;j<inner;j++){
				
				
				int x = horizontal ? j : i;
				int y = horizontal ? i : j;
				Pixel pix = new Pixel(raster.getPixel(x, y, new int[4]),x,y);
				
				if(pix.isWhite()){//Ignore white pixels and treat them as breaking points between lines
					
					if(line!=null){
						int start = horizontal ? line.getX1() : line.getY1();
						int end = horizontal ? line.getX2() : line.getY2();
						
						if((end-start)>=minLineLength){//The line is actually created in the else part below
							
							//##########Find the max color for line
							HashMap<Pixel, Integer> pxCounts = new HashMap<Pixel,Integer>();
							for(int a=line.getX1();a<=line.getX2();a++){
								for(int b=line.getY1();b<=line.getY2();b++){
									Pixel p = new Pixel(raster.getPixel(a, b, new int[4]),a,b);
									if(pxCounts.containsKey(p)){
										pxCounts.put(p, pxCounts.get(p)+1);
									}else{
										pxCounts.put(p, 1);
									}
								}
							}
							
							Pixel max = null;
							int count = 0;
							for(Pixel key : pxCounts.keySet()){
								if(max==null){
									max = key;
									count = pxCounts.get(max);
									continue;
								}
								
								if(pxCounts.get(key) > count){
									max = key;
									count = pxCounts.get(max);
								}
							}
							
							line.setColor(max);
							//#####################################
							lines.add(line);
						}
					}
					
					line = null;
					continue;
					
				}else{//For any non-white pixel append it to the line, thereby extending its length
					if(line==null){
						line = new Line(pix.getX(),pix.getY(),0,0,true,pix);
						continue;
					}
					line.setX2(pix.getX());
					line.setY2(pix.getY());
				}
				if(horizontal== true && line.getX2()-line.getX1()> minLineLength && x==img.getWidth()-1)
				{
					lines.add(line);
				}
				
			}
			
		}
		if(lines.size()>0)
			return lines;
		//************************************
		
		//**************Draw vertical lines based on hierarchyNode's Table-Columns
//		if(!horizontal && tableNode!=null && tableNode.getParagraph()!=null && tableNode.getParagraph().isTable()){}
		//**********************************************************
		
		//**************Detect fat rows due to color fills and deduce to two line; top/bottom
		List<Line> existingLines = new ArrayList<Line>(lines);
		lines = new ArrayList<Line>();//New set of lines to be populated after pruning of color fills to just two lines
		
		//There are cases where two lines occur one after the other with significant white space in between.
		//So we need to keep track of only those lines that are sandwiched in a fat line and not the ones outside the vicinity.
		List<Line> excludedLines = new ArrayList<Line>();
		
		for(int i=0;i<existingLines.size();i++){
			Line focus = existingLines.get(i);
			
			if(excludedLines.contains(focus))
				continue;
			
			int j=0;
			for(j=i+1;j<existingLines.size();j++){
				Line nextLine = existingLines.get(j);
				
				int checkStart = horizontal ? focus.getX1() : focus.getY1();
				int checkEnd = horizontal ? nextLine.getX1() : nextLine.getY1();
				if(checkStart!=checkEnd)
					continue;
				
				int start = horizontal ? focus.getY1() : focus.getX1();
				int end = horizontal ? nextLine.getY1() : nextLine.getX1();
				
				if((end-start)<=1 && nextLine.getColor().equals(focus.getColor())){//Same line or next
					focus = nextLine;
					excludedLines.add(focus);
				}else{
					break;
				}
			}
			
			if(j-i > (int)(img.getHeight()*0.025)){
				//Now that we have first and the last of a set of consecutive lines, add those to the lines list
				lines.add(existingLines.get(i));
				lines.add(focus);
			}else
				lines.add(existingLines.get(i));
		}
		excludedLines.clear();
		//*****************************
		
		//*******************Detect Fat lines and deduce to one
		existingLines = new ArrayList<Line>(lines);
		lines = new ArrayList<Line>();//New set of lines to be populated after pruning of fat lines to one
		
		//There are cases where two lines occur one after the other with significant white space in between.
		//So we need to keep track of only those lines that are sandwiched in a fat line and not the ones outside the vicinity.
		excludedLines = new ArrayList<Line>();
		
		for(int i=0;i<existingLines.size();i++){
			Line focus = existingLines.get(i);
			
			int j=0;
			for(j=i+1;j<existingLines.size();j++){
				int checkStart = horizontal ? focus.getX1() : focus.getY1();
				int checkEnd = horizontal ? existingLines.get(j).getX1() : existingLines.get(j).getY1();
				
				if(checkStart!=checkEnd)
					continue;
				
				int start = horizontal ? focus.getY1() : focus.getX1();
				int end = horizontal ? existingLines.get(j).getY1() : existingLines.get(j).getX1();
				
				if((end-start)<=1){//Same line or next
					focus = existingLines.get(j);
					excludedLines.add(focus);
				}else{
					break;
				}
			}
			
			if(j-i >= 2){
				//Now that we have first and the last of a set of consecutive lines, choose the first and ignore the rest
				lines.add(existingLines.get(i));
			}else
				lines.add(existingLines.get(i));
		}
		excludedLines.clear();
		//***********************************
		
		return lines;
	}
	
	
/*	public static List<Rectangle>  CellsLabeling(List<Line> HLine, List<Line> verticalLines , int index) {
		int prevX1=0, prevY1=0,i=0, HprevX1=0;

		List<Rectangle> RowId = new ArrayList<Rectangle>();
		
		for(Line hline:HLine )
		{
			if(index-1 == hline.getindex())
			{ prevY1 = hline.getY1();
			HprevX1 = hline.getX1();
			
			}
			else if(index == hline.getindex())
			{
				
				for(Line vline: verticalLines)
				{
					Rectangle R = new Rectangle();
//				if(vline.getX1()==verticalLines.get(verticalLines.size()-1).getX1() && vline.getY1()==verticalLines.get(verticalLines.size()-1).getY1())
//				{
//					System.out.println("hold last line");
//				}
 					if(prevX1==0)
					{prevX1 = vline.getX1();}
 					
 					if(Math.abs(img.getWidth()-vline.getX1())<15 &&  (hline.getY1()> vline.getY1()|| Math.abs(vline.getY1()- hline.getY1())<20)&& vline.getY1()-prevY1 < 20 &&( hline.getY1()< vline.getY2()
							|| Math.abs(vline.getY2()- hline.getY1())<30)
 							&& hline.getX1()( prevX1<vline.getX1() || Math.abs(hline.getX1()-vline.getX1())<10)
 							&& vline.getX1()<hline.getX2()&& vline.getX2()-prevX1 > 20) //verticalLines.get(verticalLines.size()-1).getX1())<15)
// 							&& Math.abs(HprevX1-hline.getX1())<20) 
 						{
						int x1= (int) (prevX1/Wratio); int x2 =(int) (vline.getX1()/Wratio); int y1 = (int) (prevY1/Hratio); int y2 = (int) (hline.getY1()/Hratio);
						prevX1 = vline.getX1();
						R.setBounds(x1, y1, x2-x1, y2-y1);
						RowId.add(R);
						i=0;
						break;
 						}

//					else 
						if( prevX1!=0 && ( hline.getY1()> vline.getY1()|| Math.abs(vline.getY1()- hline.getY1())<20)&& vline.getY1()-prevY1 < 20 &&( hline.getY1()< vline.getY2()
							|| Math.abs(vline.getY2()- hline.getY1())<30)
						&& hline.getX1()( prevX1<vline.getX1() || Math.abs(hline.getX1()-vline.getX1())<10)
						&& vline.getX1()<hline.getX2()&& vline.getX2()-prevX1 > 20)//&& vline.getX1()-prevX2 > 50)				 
					{
						i++;
						if( i>=2 )//&& (k>150 || k1>150 ) || (l>150 || l1>150 ))
						{
							int count1 =0;
							int count2=0;
							for(int ab=vline.getX1()-5; ab> vline.getX1()-11;ab--)
							{
								for(int a = prevY1; a<hline.getY1(); a++ )
								{
									int b = gray(ab, a);
									if (b>threshold){ count1++;}
								}
							}
							
							for(int ab=vline.getX1()+5; ab< vline.getX1()+11;ab++)
							{
								for(int a = prevY1; a<hline.getY1(); a++ )
								{
									int b = gray(ab, a);
									if (b>threshold){ count2++;}
								}
							}
							if(count2>240|| count1 >240)
							{
								int x1= (int) (prevX1/Wratio); int x2 =(int) (vline.getX1()/Wratio); int y1 = (int) (prevY1/Hratio); int y2 = (int) (hline.getY1()/Hratio);
								prevX1 = vline.getX1();
								R.setBounds(x1, y1, x2-x1, y2-y1);
								RowId.add(R);
								i=0;
							}
						}
						
					}
					
				}
				prevY1 = hline.getY1();
				break;
				
			}
			
			else continue;
		}
		return RowId;
	}*/

	public static List<Rectangle>  CellsLabeling(List<Line> HLine, List<Line> verticalLines , int index) {
		int prevX1=0, prevY1=0,i=0, HprevX1=0;
		Boolean LineFound = false;

		List<Rectangle> RowId = new ArrayList<Rectangle>();
		
		for(Line hline:HLine )
		{
			if(index-1 == hline.getindex())
			{
				prevY1 = hline.getY1();
				HprevX1 = hline.getX1();
				LineFound= true;
			
			}
			else if(index == hline.getindex() && HprevX1==hline.getX1() || Math.abs(HprevX1-hline.getX1())<20)
			{
				
				for(Line vline: verticalLines)
				{
					Rectangle R = new Rectangle();
//				if(vline.getX1()==verticalLines.get(verticalLines.size()-1).getX1() && vline.getY1()==verticalLines.get(verticalLines.size()-1).getY1())
//				{
//					System.out.println("hold last line");
//				}
 					if(prevX1==0)
					{prevX1 = vline.getX1();}
 					
 					if(Math.abs(img.getWidth()-vline.getX1())<15 &&  (hline.getY1()> vline.getY1()|| Math.abs(vline.getY1()- hline.getY1())<20)&& vline.getY1()-prevY1 < 20 &&( hline.getY1()< vline.getY2()
							|| Math.abs(vline.getY2()- hline.getY1())<30)
 							&& /*hline.getX1()*/( prevX1<vline.getX1() || Math.abs(hline.getX1()-vline.getX1())<10)
 							&& vline.getX1()<hline.getX2()&& vline.getX2()-prevX1 > 20) //verticalLines.get(verticalLines.size()-1).getX1())<15)
// 							&& Math.abs(HprevX1-hline.getX1())<20) 
 						{
						int x1= (int) (prevX1/Wratio); int x2 =(int) (vline.getX1()/Wratio); int y1 = (int) (prevY1/Hratio); int y2 = (int) (hline.getY1()/Hratio);
						prevX1 = vline.getX1();
						R.setBounds(x1, y1, x2-x1, y2-y1);
						RowId.add(R);
						i=0;
						break;
 						}

//					else 
						if( prevX1!=0 && ( hline.getY1()> vline.getY1()|| Math.abs(vline.getY1()- hline.getY1())<20)&& vline.getY1()-prevY1 < 20 &&( hline.getY1()< vline.getY2()
							|| Math.abs(vline.getY2()- hline.getY1())<30)
						&& /*hline.getX1()*/( prevX1<vline.getX1() || Math.abs(hline.getX1()-vline.getX1())<10)
						&& vline.getX1()<hline.getX2()&& vline.getX2()-prevX1 > 20)//&& vline.getX1()-prevX2 > 50)				 
					{
						i++;
						if( i>=2 )//&& (k>150 || k1>150 ) || (l>150 || l1>150 ))
						{
							int count1 =0;
							int count2=0;
							for(int ab=vline.getX1()-5; ab> vline.getX1()-11;ab--)
							{
								for(int a = prevY1; a<hline.getY1(); a++ )
								{
									int b = gray(ab, a);
									if (b>threshold){ count1++;}
								}
							}
							
							for(int ab=vline.getX1()+5; ab< vline.getX1()+11;ab++)
							{
								for(int a = prevY1; a<hline.getY1(); a++ )
								{
									int b = gray(ab, a);
									if (b>threshold){ count2++;}
								}
							}
							if(count2>240|| count1 >240)
							{
								int x1= (int) (prevX1/Wratio); int x2 =(int) (vline.getX1()/Wratio); int y1 = (int) (prevY1/Hratio); int y2 = (int) (hline.getY1()/Hratio);
								prevX1 = vline.getX1();
								R.setBounds(x1, y1, x2-x1, y2-y1);
								RowId.add(R);
								i=0;
							}
						}
						
					}
					
				}
				prevY1 = hline.getY1();
				break;
				
			}
			
			else{
				if(LineFound == true)
				{
					index =index+1;
				continue;
				}
			}
		}
		return RowId;
	}	
	
	public static List<Line> combineHLines(List<Line> horizontalLines){
		List<Line> HLine = horizontalLines;
		List<Line> AllHLines = horizontalLines;
		
		int i=0, a=0, prevY1= 0,prevX1=0, prevX2=0,index=0;
		Iterator<Line> It = horizontalLines.iterator();	
		while (It.hasNext()) {
			Line H = It.next();
			if(prevY1 == 0)
			{
				 prevY1 = H.getY1();
			}
			else if( (H.getY1() - prevY1)< 30){
				i++;
//				prevY1 = H.getY1();
			}
			else{ 
			//Here we got sublist of lines which have lines with nearest Y1 values
			final List<Line> HSub = HLine.subList(a, i);		
			a=i+1;
			// sorting list according to X1
			final List<Line> nwLine = new ArrayList<Line>();
			
			Collections.sort(HSub,  new Comparator<Line>() {
				@Override
				public int compare(Line o1,Line o2) {
					
					if(o1.getX1()<o2.getX1()){
						nwLine.add(o2);
						return -1;
					}else if(o1.getX1()>o2.getX1()){
						return 1;
					}
					else{
						nwLine.add(o1);
						
						return 0;
					}
				}
			});
			
			
				Line minX1 = nwLine.get(0);
				prevX1 = minX1.getX1();
				
				final List<Line> maxX2 = new ArrayList<Line>();
				Collections.sort(nwLine,  new Comparator<Line>() {
					public int compare(Line o1,Line o2) {
						if(o1.getX2()> o2.getX2())
						{
						maxX2.add(o2);
						return  1; //Integer.valueOf(o1.getX2()).compareTo(o2.getX2());
						
						}
						else if (o1.getX2()<o2.getX2())
						{
							maxX2.add(o1);
							return -1;
						}
						else {
							maxX2.add(o2);
							return 0;
						}
						
					}
				});
				
				 Line tempx2 = maxX2.get(maxX2.size()-1);
				prevX2 = tempx2.getX2();
				
				tempx2.setX1(prevX1);tempx2.setX2(prevX2);tempx2.setY1(prevY1);tempx2.setY2(prevY1);
				AllHLines.set(index, tempx2);
				index++;
				prevY1 = H.getY1();
				
			}
		}
		
		return AllHLines;	
	}
	
	public static List<Line> HLineStructure(List<Line> horizontal_lines) {
		List<Line> HLine = new ArrayList<Line>();
		int i=0,NewX2 = 0,index=0,
				prevY1= 0,prevX1=0;// prevX2=0,prevY2=0;
		List<Integer> Map = new ArrayList<Integer>(); 
		List<Integer> Tempx1 = new ArrayList<Integer>();
		for(Line H: horizontal_lines )
		{
			Tempx1.add(H.getX1());
		}
		Collections.sort(Tempx1);
		
		for (int a=0; a<Tempx1.size()-1; a++)
		{
			if(a==0)prevX1= Tempx1.get(a);
			else if(prevX1== Tempx1.get(a))
			{
				index++;
			}
			if(prevX1!=Tempx1.get(a)) {
				prevX1= Tempx1.get(a);
				if(index>20){
					index=a-1;
					break;
				}
				else index=0;
			}
		}
		
		for(Line H: horizontal_lines )
		{
			if(prevY1!=0 )
			{
				if( H.getX1()< Tempx1.get(index)+100 )
				{
					if( H.getY1()-prevY1 >25 && H.getY1()-prevY1 <100)
					{
					Map.add( H.getY1()-prevY1);
					i++;
					}
					prevY1= H.getY1();
				}
			}
			else 
			{
			prevY1= H.getY1();}
		}
		
		Collections.sort(Map);
		index=0;
		for (int a=0; a<Map.size()-1; a++)
		{
			if(a==0)prevX1= Map.get(a);
			else if(prevX1== Map.get(a))
			{
				index++;
			}
			if(prevX1!=Map.get(a)) {
				prevX1= Map.get(a);
				if(index>5){
					index=a-1;
					break;
				}
				else index=0;
			}
		}
		
		int a=0;
		prevY1=0;
		int YGap = 0;
		i=0;
		if(Map.size()!=0)
		{
		VerticalGap = Map.get(index)-10;//Map.size()-1)-10;
		YGap = VerticalGap;
		}
		else
		{
			YGap = VerticalGap;
		}
		for(Line H: horizontal_lines )
		{	
			a++;
			if(prevY1 == 0)
			{
				prevX1 = H.getX1();
				prevY1 = H.getY1();
			}
			else if( prevY1!=0 && Math.abs(H.getY1() - prevY1)< YGap ){// && H.getX1()< 1500){// && prevX2<= H.getX2() ) {
//				NewY2 = H.getY1();
				if(H.getX1()<prevX1){
					prevX1=H.getX1();
					prevY1 = H.getY1();
					}
				if(NewX2<H.getX2())
				{
					NewX2 = H.getX2();
				}
				if(a==horizontal_lines.size()) // for last line
				{
					H.setX1(prevX1); H.setX2(NewX2);H.setY1(prevY1);H.setY2(prevY1); H.setindex(i);
//					HLine.set(i, H);
					HLine.add(i, H);
				}
				
			}
			 else {
				 
				 if(  (H.getY1()-prevY1) > 50)//added NewX2 comparison to avoid continuous lines
					 
				 {
//					 if(NewX2-prevX1>1500)
//					 {
						int x1=H.getX1(); int y1=H.getY1(); 
						H.setX1(prevX1); H.setX2(NewX2);H.setY1(prevY1);H.setY2(prevY1); H.setindex(i);
//						HLine.set(i, H);
						HLine.add(i, H);
						i++;
				        prevY1 = y1 ;
				        prevX1 = x1; NewX2 = 0;
//					 }
					 
//					 else {
//						 int x1=H.getX1(); int y1=H.getY1(); //int y2=H.getY2();
//							prevY1 = y1 ; //prevY2 = y2 ; 
//							prevX1 = x1; NewX2 =0;// H.getX2();
//					 }
				 }
			}
		}
//		HLine.subList(i+1, HLine.size()).clear();

		return HLine;
	}
	
	public static List<Line> VLineStructure(List<Line> VLine) {
		int i=0,NewX2 = 0,NewY2=0, prevY1= 0,prevX1=0, prevX2=0,prevY2=0;
		for(Line line : VLine){
			if(prevX1==0){
				prevX1=line.getX1(); prevX2= line.getX2(); prevY1= line.getY1(); NewY2=line.getY2();
			}
			
			else if (Math.abs(line.getX1()-prevX1) <30) 
			{
				if(line.getY1()<prevY1 ){ prevY1=line.getY1();}
				
				if(NewY2!=0 && NewY2<line.getY1()) {
				line.setX1(prevX1); line.setX2(prevX2); line.setY1(prevY1); line.setY2(NewY2);
//				g.drawLine(line.getX1(), line.getY1(), line.getX1(), line.getY2());
				VLine.set(i,line );
				i++;
				NewX2 = 1;
				prevY1= line.getY1();
				NewY2 = line.getY2();
				prevY2 = NewY2;
				}
				else if( NewY2<line.getY2()){
					NewY2 = line.getY2();
					}
			}
			else{

				if(line.getX1()-prevX1>50 ){
				if(NewX2!=0)
				{
					if(NewY2!=prevY2)
					{
						//have to write some logic for broken lines
					}
				}
				int x1=line.getX1(); int y1= line.getY1(); int x2=line.getX2(); NewY2 = line.getY2();
				line.setX1(prevX1); line.setX2(prevX2); line.setY1(prevY1); line.setY2(NewY2);
				VLine.set(i,line );
				i++;
				prevX1=x1; prevY1= y1; prevX2=x2; NewY2 = 0;
				}
			}
		}
		VLine.subList(i, VLine.size()).clear();
		System.out.println("\n**************\n");
		return VLine;
	}
	
	
public static void Virtual_Line(List<Line> horizontalLines , List<Line> verticalLines ) {
		
		final List<Integer> set1 = new ArrayList<Integer>();
		for(Line l: horizontalLines)
		{
			 set1.add(l.getX1());
		}
		Collections.sort(set1);
		
		
		int count =0;
		int colCount = 0;
		int a=0;

		List<Cell_Rows> virtual = new ArrayList<Cell_Rows>();
		List<Integer> X = new ArrayList<Integer>();
		for(Line l: horizontalLines)
		{
			if(l.getX1()- set1.get(0)>30 && l.getY1()>30)
			{
				count =0;
				colCount = 0;
				
				for(int i=l.getX1()-5;i<l.getX1()+10;i++)
				{
					for (int j=l.getY1()+15; j<l.getY1()+25 ; j++)
					{
						if(j!= img.getHeight()-5)
						{
							int k = gray(i, j);
							if (k> threshold)
							{
								colCount++;
							}	
						}
						else break;
					}
				}
				if(colCount>120)
				{
					for(int i=l.getX1()-1;i>l.getX1()-12;i--)
					{
						for (int j=l.getY1()+5; j>l.getY1()-15; j--)
						{
							int k = gray(i, j);
							if (k> threshold)
							{
								count++;
							}
						}
					}
					if(count>180)
					{
						Cell_Rows r = new Cell_Rows();
						r.setRow_No(a);
						r.setY1(l.getX1());
						r.setY2(l.getY2());
						virtual.add(r);
						X.add(l.getX1());
						a++;
					}
				}
			}
			else continue;
		}


	Collections.sort(virtual,	new Comparator<Object>() {
		public int compare(Object o1,Object o2) {
//			int ret = -1;
			Cell_Rows r1 = (Cell_Rows)o1;
			Cell_Rows r2 = (Cell_Rows)o2;
			 return Integer.valueOf(r1.getY1()).compareTo(r2.getY1());
	       }
		});
	
	List<Cell_Rows> temp1 = new ArrayList<Cell_Rows>();
	List<Cell_Rows> temp2 = new ArrayList<Cell_Rows>();
	int x=0;
	int temp =0;
	for(int i=0; i<virtual.size()-1;i++)
		{ 
	//		Cell_Rows r =new Cell_Rows();
			if(virtual.get(i+1).getY1()-virtual.get(i).getY1()<10)
			{
				temp++;
				if(x==0)
				{
				temp1.add(virtual.get(i));
				}
				else if (x==1){
					temp2.add(virtual.get(i));
				}
			}
			else if(temp>90)
			{
				if(x==0)
				{x=1;}
				else {
					x=2;
					break;
				}
				temp=0;
			}
			else{
				if(x==0)
				{
					temp1.clear();
					temp=0;
				}
				else if(x==1)
				{
					temp2.clear();
					temp=0;
				}
				
			}
		}
	
	if(!temp1.isEmpty() && !temp2.isEmpty())
	{
		Collections.sort(temp1,	new Comparator<Object>() {
			public int compare(Object o1,Object o2) {
				Cell_Rows r1 = (Cell_Rows)o1;
				Cell_Rows r2 = (Cell_Rows)o2;
				 return Integer.valueOf(r1.getY2()).compareTo(r2.getY2());
		       }
			});
		
		Collections.sort(temp2,	new Comparator<Object>() {
			public int compare(Object o1,Object o2) {
				Cell_Rows r1 = (Cell_Rows)o1;
				Cell_Rows r2 = (Cell_Rows)o2;
				 return Integer.valueOf(r1.getY2()).compareTo(r2.getY2());
		       }
			});
		
		 int vx= temp1.get(0).getY1(); int vy1a=temp1.get(0).getY2(); int vy2a = temp1.get(temp1.size()-1).getY2();
		 int vx1= temp2.get(0).getY1(); int vy1b=temp2.get(0).getY2(); int vy2b = temp2.get(temp2.size()-1).getY2();
		 Line l = 	new Line(vx, vy1a-65, vx, vy2a+80, false, null);
		 verticalLines.add(l);
		 verticalLines.add(l);verticalLines.add(l); verticalLines.add(l); verticalLines.add(l);
		 Line l1 = 	new Line(vx1, vy1b-65, vx1, vy2b+80, false, null);
		 verticalLines.add(l1);verticalLines.add(l1);verticalLines.add(l1); verticalLines.add(l); verticalLines.add(l);
	
	}
	}
	
	public static Map<Integer, List<Rectangle>> Cells_Extraction(int pg, String pdf)
			throws IOException
	{
		File pdf1 = new File(pdf);
		FileInputStream ip = new FileInputStream(pdf);
		PDDocument pd = PDDocument.load(ip);
		
		
		PDPage pdpage = (PDPage) pd.getDocumentCatalog().getAllPages().get(pg-1);
		
		img = pdpage.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
//		ImageIO.write(img,"png",new File(Dir+File.separator+fname+pg+".png"));
		img = Thresholding(img);
		
		//oimg = pdpage.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
		
/*		String fpath = pdf1.getParent();
		String fname = pdf1.getName();
		fname = fname.substring(0, fname.lastIndexOf("."));
		File Dir = new File(fpath+"/output-"+fname);	
		if(!Dir.exists())
		{
			Dir.mkdirs();
		}*/

		//System.load("D:\\Deepak\\Workspace\\Financial-Statements-Extraction-Oracle-Sql\\OpenCV\\opencv\\build\\java\\x64\\opencv_java300.dll");
//			String image  = fname;
			List<Rectangle> RowId = null;
			
			//createPDFpageImage(pd,fname,pg);
			//LineExtractor.graphics_removal(fname, pg, Dir);
			//File lines = new File(Dir+File.separator+fname+"_lines"+pg+".png");
			//img= ImageIO.read(lines);
			//oimg = ImageIO.read(new File("./"+fname+pg+".png"));
			 Hratio = img.getHeight()/(pdpage.getMediaBox().getHeight());
			 Wratio = img.getWidth()/(pdpage.getMediaBox().getWidth()); 
			//Graphics2D g = oimg.createGraphics();
			//g.drawImage(oimg, 0, 0, null);

			List<Line> horizontalLines = detectLines(img, true);
			List<Line> verticalLines = detectLines(img, false);
			Virtual_Line(horizontalLines, verticalLines);
			
			Collections.sort(verticalLines,	new Comparator<Object>() {
				public int compare(Object o1,Object o2) {

					Line r1 = (Line)o1;
					Line r2 = (Line)o2;
					 return Integer.valueOf(r1.getX1()).compareTo(r2.getX1());
			       }
				});
			
			HLine = HLineStructure(horizontalLines);

			//g.setColor(Color.RED);
			//g.setFont(new Font("TimesRoman", Font.BOLD, 28));
			
			List<Cell> RowCol = new ArrayList<Cell>();
			int r =0;
			
			Map<Integer, List<Rectangle>> rowRectangleMap =  new LinkedHashMap<Integer, List<Rectangle>>();
			
			for(int i=1; i<= HLine.size();i++)
			{
				RowId = CellsLabeling(HLine, verticalLines, i);
				
				
				if(!RowId.isEmpty()){
					rowRectangleMap.put(r, RowId);
					r++;}
				/*for(int a=0; a< RowId.size();a++)
				{
					Rectangle big = RowId.get(a);
					g.drawRect((int)big.getX(),(int) big.getY(),(int) big.getWidth(),(int) big.getHeight());
					g.drawChars((r-1+","+a).toCharArray(), 0, (r-1+","+a).length(), (int)big.getX()+20, (int)big.getY()+20);		
				}*/
			}
			//System.out.println(RowCol);
			
			
			
			/*g.dispose();
			ImageIO.write(oimg, "PNG", new File(Dir+File.separator+fname+pg+".png"));
			File OriginalImg = new File(fname+pg+".png");
			OriginalImg.delete();
			lines.delete();*/
			
			return rowRectangleMap;
	}
	
	public static BufferedImage Thresholding(BufferedImage img) {
		int newPixel = 0;
		BufferedImage binarize = new BufferedImage(img.getWidth(), img.getHeight(),BufferedImage.TYPE_INT_BGR);
		for(int i=0; i<img.getWidth(); i++)
		{
			for(int j=0; j<img.getHeight(); j++)
			{
				int alpha = new Color(img.getRGB(i, j)).getRed();
				//int gray = gray(i, j);
				if(alpha< threshold)
				{
					newPixel =0;
				}
				else{
					newPixel =255;
				}
				int rgb=new Color(newPixel, newPixel, newPixel).getRGB();
//				newPixel = colorToRGB(alpha, newPixel, newPixel, newPixel);
				binarize.setRGB(i, j, rgb);
			}
		}
		
		return binarize;
	}
	
	
	public static void main(String[] args) throws Exception{
		
	
	try{
		System.out.println("Start");
//		String filingID =args[0];
//		String standalone = args[1];
//		String pdf =args[2];

		String pdf = "D:/InputFiles/Financials/Chinese/" + "_Sample_Financials_MME_GoerTek_2015FY[2016-09-26-060607922]_27968 .PDF" ;
		int page=64;
		
		Map<Integer, List<Rectangle>>CellsData = Cells_Extraction(page+1, pdf);
		
		Map<Integer, Pair<Float, Float>>  pageDistanceMap = new LinkedHashMap<Integer, Pair<Float,Float>>();
		
		for(Integer index : CellsData.keySet())
		{
			List<Rectangle> table = CellsData.get(index); 
			
			for(int i=0;i<table.size();i++)
			{
				Rectangle rect = table.get(i);
				float y1 = (float)rect.getY();
				
				float y2 = (float) (y1+ rect.getHeight());
				
				Pair<Float, Float>  distanceRange = new Pair<Float, Float>(y1,y2);
				
				pageDistanceMap.put(index, distanceRange);
				
				break;
				
			}
			System.out.println("Test");
		}
		
		System.out.println("Test");
		
	}catch (Exception e) {
			// TODO: handle exception
		
		e.printStackTrace();
	}
		
}
	
	


public static int gray (int xImg, int yImg)
{
	Color c = new Color(img.getRGB(xImg,yImg));
	int red = (int) (c.getRed() * 0.299);
	int green = (int) (c.getGreen() * 0.587);
	int blue = (int) (c.getBlue() * 0.114);

	int k = truncate( red + green + blue);
	return k ;
}

public static int truncate(int a) {
    if      (a <   0) return 0;
    else if (a > 255) return 255;
    else              return a;
}


public static void createPDFpageImage(PDDocument pdf , String image,int pg) throws IOException
{
	// extracting images from pdf with PDXObject 
	PDFImageWriter pi = new PDFImageWriter();
	pi.writeImage(pdf,"png","",pg, pg, image, BufferedImage.TYPE_3BYTE_BGR, 500);
//			pdf.getDocumentCatalog().getAllPages().size(), image, BufferedImage.TYPE_3BYTE_BGR, 500);
}




}
