package com.rage.table.data;



public class Pixel {

	int r,g,b,a;
	int x,y;
	private static final int minWhite = 230;
	private static final int minBlack =100;
	
	public Pixel(int[] pixel,int x,int y){
		this.r = pixel[0];
		this.g = pixel[1];
		this.b = pixel[2];
		this.a = pixel[3];
		this.x = x;
		this.y = y;
	}
	
	public boolean isWhite(){
		return r>=minWhite && g>=minWhite && b>=minWhite;
	}
	
	public boolean isBlack(){
		return r<minBlack && g<minBlack && b<minBlack;
	}
	
	public String toString(){
		return "("+x+","+y+") ("+r+","+g+","+b+","+a+")";
	}
	
	//The equals implementation uses a near match based on color only
	public boolean equals(Object o){
		if(o instanceof Pixel){
			
			Pixel p = (Pixel)o;
			
			if(a == p.getA() && nearlyEqual(b, p.getB()) && 
					nearlyEqual(g, p.getG()) && nearlyEqual(r, p.getR())){
				
				return true;
			}
		}
		return false;
	}
	
	private boolean nearlyEqual(int a,int b){
		return Math.abs(a-b) <= 20;
	}
	
	public int hashCode(){
		return r;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}

	public int getA() {
		return a;
	}

	public void setA(int a) {
		this.a = a;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

}
