package com.rage.table.data;

import java.awt.image.BufferedImage;
import java.awt.image.Raster;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

import javax.imageio.ImageIO;

public class PixelPrinter {


	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		BufferedWriter writer = new BufferedWriter(new FileWriter("pixels.csv"));
		BufferedImage img = ImageIO.read(new File("output.jpg"));
		
		Raster raster = img.getData();
		for(int i=0;i<263;i++){
			for(int j=0;j<818;j++){
				writer.write(pixel(raster,j,i)+",");
			}
			writer.write("\n");
		}
		
		writer.flush();
		writer.close();
	}

	private static String pixel(Raster raster,int i,int j){
		int[] pixel = raster.getPixel(i, j, new int[4]);
		String pix = "";
		for(int p:pixel){
			pix+=p+" ";
		}
		return pix.trim().equals("255 255 255 0")?"-1":pix.trim();
	}

}
