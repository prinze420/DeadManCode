package com.rage.document.pdf.utils;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;

import com.gyan.siapp.tools.sentdetect.SentenceBoundaryDetector;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.ontology.TimePeriodOntology;

public class StringUtility 
{

	public static boolean tokenizeRandomContains(String stringToCheck, String inStringCheck) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		
		List<String> keywordTokens=tokenize(stringToCheck.toLowerCase(),true);
		List<String> tokens=tokenize(inStringCheck.toLowerCase(),true);
		
		keywordTokens=removeLineItemStopWords(keywordTokens);
		tokens=removeLineItemStopWords(tokens);
		
		if(keywordTokens.size()==1 && keywordTokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(tokens.size()>1)
				return false;
		}
		if(tokens.size()==1 && tokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(keywordTokens.size()>1)
				return false;
		}
		
		int matches=0;
		
		for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				break;

			if ( index == 0 )
				matches++;
		}

		if ( matches>=keywordTokens.size() )
			return true ;

		return false;
	}
	
	public static boolean tokenizeRandomContainsBothWay(String inString, String toCheckString) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		
		List<String> keywordTokens=tokenize(inString.toLowerCase(),true);
		List<String> tokens=tokenize(toCheckString.toLowerCase(),true);
		
		keywordTokens=removeLineItemStopWords(keywordTokens);
		tokens=removeLineItemStopWords(tokens);
		
		if(keywordTokens.size()<1 || tokens.size()<1)
			return false;
		
		if(keywordTokens.size()==1 && keywordTokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(tokens.size()>1)
				return false;
		}
		if(tokens.size()==1 && tokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(keywordTokens.size()>1)
				return false;
		}
		
		int matches=0;
		for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				break ;
			
			matches++;
			
			if ( index == 0 )
				foundStart = true ;
		}
		
		if ( matches>=keywordTokens.size() )
			return true ;
		
		matches=0;
		
		for ( int i=0 ; i<tokens.size() ; i++ )
		{
			String keywordToken = tokens.get(i) ;

			int index = keywordTokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				break;

			matches++;
			
			if ( index == 0 )
				foundStart = true ;
		}
		if ( matches>=tokens.size() )
			return true ;

		return false;
	}
	
	public static boolean sentenceTokenizeRandomContains(String stringToCheck, String inStringCheck) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		
		List<String> keywordTokens=tokenize(stringToCheck.toLowerCase(),true);
		
		
		Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(inStringCheck);
		
		keywordTokens=removeLineItemStopWords(keywordTokens);
		
		for(String sentence:sentences)
		{
			int matches=0;
			List<String> tokens=tokenize(sentence.toLowerCase(),true);
			tokens=removeLineItemStopWords(tokens);
			if(keywordTokens.size()==1 && keywordTokens.get(0).trim().equalsIgnoreCase("other"))
			{
				if(tokens.size()>1)
					return false;
			}
			if(tokens.size()==1 && tokens.get(0).trim().equalsIgnoreCase("other"))
			{
				if(keywordTokens.size()>1)
					return false;
			}
			
			for ( int i=0 ; i<keywordTokens.size() ; i++ )
			{
				String keywordToken = keywordTokens.get(i) ;
	
				int index = tokens.indexOf(keywordToken.toLowerCase()) ;
	
				if ( index == -1 )
					break;
	
				if ( index == 0 )
					matches++;
			}
			if ( matches>=keywordTokens.size() )
				return true ;
		}

		return false;
	}
	
	public static boolean sentenceTokenizeRandomContains1(String stringToCheck, String inStringCheck) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		
		List<String> keywordTokens=tokenize(stringToCheck.toLowerCase(),true);
		
		
		Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(inStringCheck);
		
		keywordTokens=removeLineItemStopWords(keywordTokens);
		
		for(String sentence:sentences)
		{
			int matches=0;
			List<String> tokens=tokenize(sentence.toLowerCase(),true);
			tokens=removeLineItemStopWords(tokens);
			if(keywordTokens.size()==1 && keywordTokens.get(0).trim().equalsIgnoreCase("other"))
			{
				if(tokens.size()>1)
					return false;
			}
			if(tokens.size()==1 && tokens.get(0).trim().equalsIgnoreCase("other"))
			{
				if(keywordTokens.size()>1)
					return false;
			}
			
			for ( int i=0 ; i<keywordTokens.size() ; i++ )
			{
				String keywordToken = keywordTokens.get(i) ;
	
				int index = tokens.indexOf(keywordToken.toLowerCase()) ;
	
				if ( index == -1 )
					break;
	
				//if ( index == 0 )
					matches++;
			}
			if ( matches>=keywordTokens.size() )
				return true ;
		}

		return false;
	}
	
	private static List<String> removeLineItemStopWords(List<String> keywordTokens) 
	{
		List<String> ret= new ArrayList<String>();
		LinkedHashSet<String> lineItemKeyWords=TimePeriodOntology.getlineItemStopWords();
		for(String token:keywordTokens)
		{
			if(!lineItemKeyWords.contains(token.trim().toLowerCase()))
			{
				ret.add(token);
			}
		}
		// net income should return net income and not income
		if(ret.size()==1 && keywordTokens.size()==2)
			return ret;
		
		return ret;
	}

	public static List<String> tokenize(String line, boolean convertToLowercase) 
	{
		List<String> ret = new ArrayList<String>() ;

		StringTokenizer st = new StringTokenizer(line, " ~`!@#$%^&*()_+�-={}[]|\\:;\"'<>?,./012345678") ;
		
		while ( st.hasMoreTokens() )
		{
			String token = st.nextToken() ;
			if(token.contains(" "))
			{
				String [] tokens = token.split("\\s");
				for(String tokenChanged:tokens)
				{
					if ( convertToLowercase )
					 ret.add(tokenChanged) ;
				}
				
			}
			else
			{
			if ( convertToLowercase )
				token = token.toLowerCase() ;
			ret.add(token) ;

			}
		}

		return ret ;
	}
	
	public static boolean isPartialMatch(String inString, String toCheckString) 
	{
		List<String> keywordTokens=tokenize(toCheckString.toLowerCase(),true);
		List<String> tokens=tokenize(inString.toLowerCase(),true);
		
		keywordTokens=removeLineItemStopWords(keywordTokens);
		tokens=removeLineItemStopWords(tokens);
		
		if(keywordTokens.size()==1 && keywordTokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(tokens.size()>1)
				return false;
		}
		if(tokens.size()==1 && tokens.get(0).trim().equalsIgnoreCase("other"))
		{
			if(keywordTokens.size()>1)
				return false;
		}
		
		int matches=0;
		
		for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index != -1 )
				matches++;
				
		}

		if ( ((float)matches/(float)keywordTokens.size())>=(0.3f) )
			return true ;

		return false;
	}
	
	public static boolean doesKeywordMatchTokenSerialExcel(String toSearch,String inString) 
	{
		toSearch=toSearch.replaceAll("\\-", " ").replaceAll("\\s+", " ");
		toSearch=toSearch.replaceAll("\\�", " ").replaceAll("\\s+", " ");
		inString=inString.replaceAll("\\-", " ").replaceAll("\\s+", " ");
		inString=inString.replaceAll("\\�", " ").replaceAll("\\s+", " ");
		List<String> keywordTokens=tokenize(toSearch.toLowerCase(),true);
		List<String> tokens=tokenize(inString.toLowerCase(),true);
		
		// Serialwise token Check
		int j=0;
		for(int i=0;i<tokens.size();i++)
		{
			String a=tokens.get(i).replaceAll(",", "").replaceAll("�", "").trim().replaceAll("�", "").trim();
			String b=keywordTokens.get(j).replaceAll(",", "").replaceAll("�", "").replaceAll("�", "").trim().trim();
			
			if(a.trim().equalsIgnoreCase(b.trim().toLowerCase()))
			{
				j++;
			}
			else
			{
				j=0;
			}
			if(j==keywordTokens.size())
			{
				return true;
			}
		}

		return false;
	}
	
	public static boolean doesKeywordMatchTokenSerial(String toSearch,String inString) 
	{
		toSearch=toSearch.replaceAll("\\-", " ").replaceAll("\\s+", " ");
		toSearch=toSearch.replaceAll("\\�", " ").replaceAll("\\s+", " ");
		inString=inString.replaceAll("\\-", " ").replaceAll("\\s+", " ");
		inString=inString.replaceAll("\\�", " ").replaceAll("\\s+", " ");
		List<String> keywordTokens=tokenize(toSearch.toLowerCase(),true);
		List<String> tokens=tokenize(inString.toLowerCase(),true);
		removeLineItemStopWords(tokens);
		removeLineItemStopWords(keywordTokens);
		
		// Serialwise token Check
		int j=0;
		for(int i=0;i<tokens.size();i++)
		{
			String a=tokens.get(i).replaceAll(",", "").replaceAll("�", "").trim().replaceAll("�", "").trim();
			String b=keywordTokens.get(j).replaceAll(",", "").replaceAll("�", "").replaceAll("�", "").trim().trim();
			
			if(a.trim().equalsIgnoreCase(b.trim().toLowerCase()))
			{
				j++;
			}
			else
			{
				j=0;
			}
			if(j==keywordTokens.size())
			{
				return true;
			}
		}

		return false;
	}
	
	
	public static String cleanString(String input)
	{
		if(input==null || input.trim().equals(""))
			return input;
		
		input=input.replaceAll(",", " ").replaceAll("\\.", " ").replaceAll(":", " ").replaceAll("\\-", " ").replaceAll("\\s+", " ").trim();
		input=input.replaceAll("'", "");
		input=input.replaceAll("\\�", " ").replaceAll("\\s+", " ");
		return input;
	}
	
	public static boolean isStringNumber(String input)
	{
		try
		{
			Long.parseLong(input);
			return true;
		}
		catch(Exception e)
		{
			
		}
		return false;
		
	}
	public static void main(String[] args) {
		System.out.println(cleanString("asjh-12768"));
	}
}
