package com.rage.document.pdf.utils;

import java.io.BufferedWriter;

public class CustomFileWriter 
{

	public static void writeStringToFileWithNewLine(String writeStr,BufferedWriter writer)
	{
		if(writer==null)
			return;
		try
		{
			writer.newLine();
			writer.write(writeStr);
			writer.flush();
		}
		catch(Exception e)
		{
			
		}
	}
	
	public static void writeStringToFileWithSameLine(String writeStr,BufferedWriter writer)
	{
		if(writer==null)
			return;
		try
		{
			writer.write(writeStr);
			writer.flush();
		}
		catch(Exception e)
		{
			
		}
	}
	
}
