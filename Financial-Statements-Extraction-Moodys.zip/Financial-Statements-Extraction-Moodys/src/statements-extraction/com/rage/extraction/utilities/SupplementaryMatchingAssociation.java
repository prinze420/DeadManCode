package com.rage.extraction.utilities;

import java.sql.Connection;
import java.util.List;
import com.rage.extraction.statements.constant.DBConnection;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.db.MapCols;
import com.rage.extraction.statements.db.ParserOutput;

public class SupplementaryMatchingAssociation 
{

	static Connection con=null;
	
	public static void main(String[] args) 
	{
		System.out.println("Start RUNNING");
		try
		{
			Integer filingID=Integer.parseInt(args[0]);
			String section=args[1];
			Integer tableID=Integer.parseInt(args[2]);
			String label=args[3];
			System.out.println("FilingID=="+filingID);
			System.out.println("section=="+section);
			System.out.println("tableID=="+tableID);
			System.out.println("label=="+label);
			
			con = DBConnection.openConnection("LIVESPREAD");
			
			if(con==null)
			{
				System.out.println("Connection null");
				System.exit(0);
			}
			
			DataWriterSql db = new DataWriterSql();
			
			System.out.println("Getting section PO List");
			List<ParserOutput> secPoList= db.getSectionPOList(filingID,section,con);
			System.out.println("Getting Table ID PO List");
			List<ParserOutput> tablePOList= db.getPOListTableIDWise(filingID,section,tableID,con);
			
			if(secPoList==null || secPoList.size()<1 || tablePOList==null || tablePOList.size()<1)
				return;
			
			SupplementaryMatchingAssociation supplMat= new SupplementaryMatchingAssociation();
			System.out.println("Getting matching Row");
			ParserOutput matchingRow=supplMat.getMatchingRowForSection(secPoList,label);
			
			
			if(matchingRow!=null)
			{
				System.out.println("ROW MATCHED");
				int secMaxCols=getMaxColsFromPoList(secPoList);
				int tableMaxCols=getMaxColsFromPoList(tablePOList);
				System.out.println("section Col count="+secMaxCols);
				System.out.println("table Col count="+tableMaxCols);
				if(secMaxCols>0 && tableMaxCols>0 && secMaxCols==tableMaxCols)
				{
					System.out.println("GOT SAME COLUMN COUNT=="+label+"==Section=="+section);
					// update po index order and ref_PoID
					System.out.println("Getting Maximum index Val");
					int maxIndexOrder=db.getMaxIndexOrderForLineItemBreakUp(filingID,section,matchingRow.getPoID(),con);
					if(maxIndexOrder==-1)
						maxIndexOrder=matchingRow.getIndexOrder();
					maxIndexOrder=maxIndexOrder+1;
					for(ParserOutput tPo:tablePOList)
					{
						tPo.setIndexOrder(maxIndexOrder++);
					}
					System.out.println("Updating references");
					db.updateReferencesForBreakUps(tablePOList,filingID,section,matchingRow.getPoID(),con,true);
				}
				else
				{
					// update only ref_PoID
					System.out.println("DIFFERENT COLUMN COUNT=="+label+"==Section=="+section);
					System.out.println("Updating references");
					db.updateReferencesForBreakUps(tablePOList,filingID,section,matchingRow.getPoID(),con,false);
				}
			}
			else
			{
				System.out.println("NO ROW MATCH FOR THIS LABEL=="+label+"==Section=="+section);
			}
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		finally
		{
			try
			{
				System.out.println("Close Connection");
				if(!con.isClosed())
					con.close();
			}
			catch(Exception e){}
		}
		System.out.println("DONE RUNNING");
	}

	private static int getMaxColsFromPoList(List<ParserOutput> secPoList) 
	{
		int ret=-1;
		if(secPoList==null || secPoList.size()<1)
			return ret;
		
		for(ParserOutput po:secPoList)
		{
			for(int i=0;i<11;i++)
			{
				String label=MapCols.getPOAsRepValOnIndex(po, i);
				if(label!=null && !label.trim().equals("") && ret<(i+1))
				{
					ret=(i+1);
				}
			}
		}
		
		return ret; 
	}

	private ParserOutput getMatchingRowForSection(List<ParserOutput> secPoList, String label) 
	{
		if(secPoList==null || secPoList.size()<1 || label==null || label.trim().equals(""))
			return null;
		
		for(ParserOutput po:secPoList)
		{
			String poLabel=po.getAsRepLabel();
			if(poLabel!=null && !poLabel.trim().equals(""))
			{
				if(poLabel.trim().equalsIgnoreCase(label.trim()))
					return po; 
			}
		}
		
		for(ParserOutput po:secPoList)
		{
			String poLabel=po.getAsRepLabel();
			if(poLabel!=null && !poLabel.trim().equals(""))
			{
				if(poLabel.trim().toLowerCase().startsWith(label.trim().toLowerCase()))
					return po; 
			}
		}
		
		return null;
	}
	
}
