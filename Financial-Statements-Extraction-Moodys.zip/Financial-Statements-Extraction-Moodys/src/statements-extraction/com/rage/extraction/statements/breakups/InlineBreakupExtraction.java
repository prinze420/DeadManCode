package com.rage.extraction.statements.breakups;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.SectionSpreader;


public class InlineBreakupExtraction {
	//private static String amount = "[\\d{1,3}]+,[\\d{1,3}]+[.]?"; //"[[\\d]{1,3}[,.]{1}]+"; //"(\\p{Sc}|\\s)(?=)[[\\d]{1,3}[,.]]+";
	private static String amount = "(\\-*\\(*(\\d{1,3}(\\,|\\s|\\.))*\\d{1,3}((\\,|\\.)\\d{1,4})*\\)*\\-*)";
	private static TreeSet<String> CURRENCY_KEYWORDS = new TreeSet<String>(Arrays.asList(new String[] {
			"USD", "$"
	})) ;

	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(InlineBreakupExtraction.class);

	public InlineBreakupExtraction() {
		if (logger!=null)
			logger.debug("In-line breakup item extraction ...");
	}

	private static boolean hasInlineBreakups(ParserOutput po) {

		if(po.getLine()==null)
			return false;
		String text = po.getLine().toString().replace("[", "").replace("]", "");
		//List<String> columns = null;
		text = po.getAsRepLabel().trim();

		//	columns = new ArrayList<String>(Arrays.asList(text.trim().split("     "))) ;

		if (text.trim().isEmpty()) {

			if (logger!=null)
				logger.debug("Empty item ...");
			return false;
		}

		boolean valid = false;
		for (String itemLabel : InlineBreakupMeta.getInlineBreakups()) {
			if(itemLabel.trim().equals(""))
				continue;
			if (!valid && text.trim().toLowerCase().indexOf(itemLabel.trim().toLowerCase())!=-1)
				valid = true;
		}
		if (!valid)
			return false;

		List<String> amounts = findPosition(text, amount);
		if (amounts!=null && amounts.size()>0) {
			if (logger!=null)
				logger.debug("Valid in-line breakup item to extract ...");
			
			return true;
		}

		if (logger!=null)
			logger.debug("Invalid in-line breakup item to extract ...");

		return false;
	}

	private static List<String> computeGross(List<String> amounts, List<String> netAmounts) {
		List<String> grossAmount = new ArrayList<String>();
		if (amounts!=null && netAmounts!=null && amounts.size()==netAmounts.size()) {
			for (int i=0; i<netAmounts.size(); i++) {
				if (!netAmounts.get(i).trim().equals("")) {

					try {
						Long grossAmt = Long.parseLong(netAmounts.get(i).replaceAll("[^0-9.]", "")) + Long.parseLong(amounts.get(i).replaceAll("[^0-9.]", ""));
						grossAmount.add(String.valueOf(grossAmt));
					} catch (NumberFormatException e) {

						Double grossAmt = Double.parseDouble(netAmounts.get(i).replaceAll("[^0-9.]", "")) + Double.parseDouble(amounts.get(i).replaceAll("[^0-9.]", ""));
						grossAmount.add(String.valueOf(grossAmt));
					}

				}
			}
		}
		return grossAmount;
	}

	public static String ignoreBrucketData(String strLine) {
		strLine = strLine.replaceAll("\\([^()]*\\)", "");
		strLine = strLine.replaceAll("\\([^(]*?\\)", "");
		return strLine;
	}
	public static List<ParserOutput> extract(ParserOutput po) {

		if (logger!=null)
			logger.debug("Extracting in-line breakup item  ...");
		if(po.getLine()==null)
			return new ArrayList<ParserOutput>();

		String text = po.getAsRepLabel().trim();
		List<String> columns = null;
		List<ParserOutput> newParserOutput = new ArrayList<ParserOutput>();

		if (!hasInlineBreakups(po)) {
			if (logger!=null)
				logger.debug("Invalid in-line breakups item "+po.toString());

			return newParserOutput; 
		}
		if (logger!=null)
			logger.debug("Valid in-line breakups item to extract "+po.toString());

		/*	if (contentCategory.getColumn()!=null && contentCategory.getColumn().size()==1)
			columns = new ArrayList<String>(Arrays.asList(contentCategory.getText().trim().split("     "))) ;
		else if (contentCategory.getColumn()!=null && contentCategory.getColumn().size()>1)
			columns = contentCategory.getColumn();*/
		//text = columns.get(0).trim();

		List<String> grossAmounts = new ArrayList<String>();
		List<String> amounts = findPosition(text, amount);


		//	columns = new ArrayList<String>(Arrays.asList(po.getAsRepLabel().trim().split("     "))) ;
		// net values
		List<String> netAmounts = getColumns(po);

		if (netAmounts.size()>amounts.size() && amounts.size()>0) {
			String str = amounts.get(0);
			for (int i=amounts.size(); i<netAmounts.size(); i++)
			{
				if (str.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(str))
					str = "-"+str.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim();
				else
					if(SectionSpreader.isNumber(str) && !str.replaceAll("[,¥$]", "").trim().startsWith("("))
						str = str.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim();
				amounts.add(str.trim());
			}
		}

		int start=-1;
		if (amounts!=null && amounts.size()>0) {
			start = Integer.parseInt(amounts.get(0).split(":")[0].trim());

			String grossLabel = "";
			String netLabel = ""; 
			int index = text.toLowerCase().lastIndexOf("net", start);
			if (index==-1)
				index = text.toLowerCase().lastIndexOf("including ", start);
			if (index==-1)
				index = text.toLowerCase().lastIndexOf("less ", start);
			if (index==-1)
				index = text.toLowerCase().lastIndexOf("includes ", start);
			

			if (index!=-1) {
				index = text.toLowerCase().lastIndexOf(",", index);
				//issue fix
				if(index==-1)
				{
					index = text.toLowerCase().indexOf("-", index);
					if(index==-1)
					{
						index = text.toLowerCase().indexOf("-", index);
					}
					if(index==-1)
					{
						index = text.toLowerCase().indexOf("—", index);
					}
					if(index==-1)
					{
						index = text.toLowerCase().indexOf("(", index);
					}
				}
				if(index==-1)
				{
					index = text.toLowerCase().lastIndexOf("net", start);
					if (index==-1)
						index = text.toLowerCase().lastIndexOf("including ", start);
					if (index==-1)
						index = text.toLowerCase().lastIndexOf("less ", start);	
				}
								
				//issue fix

				/*if(index!=-1)
				{*/
					String baseLabel = text.substring(0, index)/*.replaceAll("^[A-Za-z]", "")*/.trim();

					grossLabel = baseLabel + ", Gross";
					netLabel = baseLabel + ", Net";
				/*}*/
			} else {
				if (logger!=null)
					logger.debug("Unable to find base item "+po.toString());

				return newParserOutput;
			}

			String subLabel = new StopWords().remove(text.substring(index, start)).trim();
			if (subLabel.toLowerCase().trim().startsWith("including") || subLabel.toLowerCase().trim().startsWith("net")) {
				int firstWS = subLabel.trim().indexOf(" ");
				if (firstWS!=-1)
					subLabel = subLabel.substring(firstWS).trim();
			}
			subLabel = "Less: " + subLabel.trim();

			// add/deduct values 
			List<String> values = new ArrayList<String>();
			String labelValues = "";
			for (String pos : amounts) {
				String[] token = pos.split(":");
				labelValues  = labelValues + "     " + (token.length==3?token[2]:"");
				String value = (token.length==3?token[2]:"0").trim();
				if (value.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(value))
					value = "-"+value.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim();
				else
					if(SectionSpreader.isNumber(value) && !value.replaceAll("[,¥$]", "").trim().startsWith("("))
						value = value.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim();
				values.add(value);
			}

			grossAmounts = computeGross(values, netAmounts);
			for (int i = 0; i < grossAmounts.size(); i++) {
				grossLabel = grossLabel + "     " + grossAmounts.get(i);
				subLabel = subLabel + "     " + values.get(i);
				netLabel = netLabel + "     " + netAmounts.get(i);
			}
			// gross
			ParserOutput grossCC = copyContentCategory(po);
			//	grossCC.setAsRepLabel(grossLabel.trim());
			//	grossCC.setLine(grossLabel.trim());

			columns = new ArrayList<String>(Arrays.asList(grossLabel.trim().split("     ")));
			grossCC.setAsRepLabel(columns.get(0).trim());
			grossCC.setLine(columns.get(0).trim());
			setpoObject(grossCC,columns);

			if (logger!=null)
				logger.debug("GROSS : "+grossCC.toString());

			// add/deduct Label
			ParserOutput addDeductCC = copyContentCategory(po);


			columns = new ArrayList<String>(Arrays.asList(subLabel.trim().split("     ")));

			addDeductCC.setAsRepLabel(columns.get(0).trim());
			addDeductCC.setLine(columns.get(0).trim());
			setpoObject(addDeductCC,columns);
			if (logger!=null)
				logger.debug("ADD/DEDUCT : "+addDeductCC.toString());

			// net
			ParserOutput netCC = copyContentCategory(po);

			columns = new ArrayList<String>(Arrays.asList(netLabel.trim().split("     ")));
			netCC.setAsRepLabel(columns.get(0).trim());
			netCC.setLine(columns.get(0).trim());
			setpoObject(netCC,columns);


			//netCC.setColumn(new ArrayList<String>(Arrays.asList(netLabel.trim().split("     "))));
			if (logger!=null)
				logger.debug("NET : "+netCC.toString());

			// In-line breakup list
			newParserOutput.add(grossCC);
			newParserOutput.add(addDeductCC);
			newParserOutput.add(netCC);

		}
		return newParserOutput;
	}


	private static List<String> getColumns(ParserOutput po) {
		List<String> cols = new ArrayList<String>();
		switch(po.getMaxCol())
		{
		case 1:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			break;
		}
		case 2:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			break;
		}
		case 3:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			break;
		}
		case 4:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			break;
		}
		case 5:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			break;
		}
		case 6:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			if(po.getValue6()!=null)
				cols.add(po.getValue6());
			break;
		}	
		case 7:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			if(po.getValue6()!=null)
				cols.add(po.getValue6());
			if(po.getValue7()!=null)
				cols.add(po.getValue7());
			break;
		}	
		case 8:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			if(po.getValue6()!=null)
				cols.add(po.getValue6());
			if(po.getValue7()!=null)
				cols.add(po.getValue7());
			if(po.getValue8()!=null)
				cols.add(po.getValue8());
			break;
		}	
		case 9:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			if(po.getValue6()!=null)
				cols.add(po.getValue6());
			if(po.getValue7()!=null)
				cols.add(po.getValue7());
			if(po.getValue8()!=null)
				cols.add(po.getValue8());
			if(po.getValue9()!=null)
				cols.add(po.getValue9());
			break;
		}	
		case 10:{
			if(po.getValue1()!=null)
				cols.add(po.getValue1());
			if(po.getValue2()!=null)
				cols.add(po.getValue2());
			if(po.getValue3()!=null)
				cols.add(po.getValue3());
			if(po.getValue4()!=null)
				cols.add(po.getValue4());
			if(po.getValue5()!=null)
				cols.add(po.getValue5());
			if(po.getValue6()!=null)
				cols.add(po.getValue6());
			if(po.getValue7()!=null)
				cols.add(po.getValue7());
			if(po.getValue8()!=null)
				cols.add(po.getValue8());
			if(po.getValue9()!=null)
				cols.add(po.getValue9());
			if(po.getValue10()!=null)
				cols.add(po.getValue10());
			break;
		}	
		}

		return cols;
	}

	private static void setpoObject(ParserOutput po,  List<String> vals) {
		for(int i=1;i<vals.size();i++)
		{
			String val = vals.get(i);
			switch(i)
			{
			case 1:	{
				po.setAsRepVal1(val);
				po.setValue1(val);
				break;
			}
			case 2:	{
				po.setAsRepVal2(val);
				po.setValue2(val);
				break;
			}
			case 3:	{
				po.setAsRepVal3(val);
				po.setValue3(val);
				break;
			}
			case 4:	{
				po.setAsRepVal4(val);
				po.setValue4(val);
				break;
			}
			case 5:	{
				po.setAsRepVal5(val);
				po.setValue5(val);
				break;
			}
			case 6:	{
				po.setAsRepVal6(val);
				po.setValue6(val);
				break;
			}
			case 7:	{
				po.setAsRepVal7(val);
				po.setValue7(val);
				break;
			}
			case 8:	{
				po.setAsRepVal8(val);
				po.setValue8(val);
				break;
			}
			case 9:	{
				po.setAsRepVal9(val);
				po.setValue9(val);
				break;
			}
			case 10:	{
				po.setAsRepVal10(val);
				po.setValue10(val);
				break;
			}
			case 11:	{
				po.setAsRepVal11(val);
				po.setValue11(val);
				break;
			}
			case 12:	{
				po.setAsRepVal12(val);
				po.setValue12(val);
				break;
			}
			case 13:	{
				po.setAsRepVal13(val);
				po.setValue13(val);
				break;
			}
			case 14:	{
				po.setAsRepVal14(val);
				po.setValue14(val);
				break;
			}
			case 15:	{
				po.setAsRepVal15(val);
				po.setValue15(val);
				break;
			}
			case 16:	{
				po.setAsRepVal16(val);
				po.setValue16(val);
				break;
			}
			case 17:	{
				po.setAsRepVal17(val);
				po.setValue17(val);
				break;
			}
			case 18:	{
				po.setAsRepVal18(val);
				po.setValue18(val);
				break;
			}
			case 19:	{
				po.setAsRepVal19(val);
				po.setValue19(val);
				break;
			}
			case 20:	{
				po.setAsRepVal20(val);
				po.setValue20(val);
				break;
			}

			}

		}
	}

	private static ParserOutput copyContentCategory(ParserOutput po) {
		ParserOutput newPo = new ParserOutput(po.getType(), po.getAsRepLabel(), po.getLineNo(), po.getPageNo());
		newPo.setAsRepLabel(po.getAsRepLabel());
		newPo.setAsRepVal1(po.getAsRepVal1());
		newPo.setValue1(po.getValue1());
		newPo.setAsRepVal2(po.getAsRepVal2());
		newPo.setValue2(po.getValue2());
		newPo.setAsRepVal3(po.getAsRepVal3());
		newPo.setValue3(po.getValue3());
		newPo.setAsRepVal4(po.getAsRepVal4());
		newPo.setValue4(po.getValue4());
		newPo.setAsRepVal5(po.getAsRepVal5());
		newPo.setValue5(po.getValue5());
		newPo.setAsRepVal6(po.getAsRepVal6());
		newPo.setValue6(po.getValue6());
		newPo.setAsRepVal7(po.getAsRepVal7());
		newPo.setValue7(po.getValue7());
		newPo.setAsRepVal8(po.getAsRepVal8());
		newPo.setValue8(po.getValue8());
		newPo.setAsRepVal9(po.getAsRepVal9());
		newPo.setValue9(po.getValue9());
		newPo.setAsRepVal10(po.getAsRepVal10());
		newPo.setValue10(po.getValue10());
		newPo.setSection(po.getSection());
		newPo.setPageNo(po.getPageNo());
		if(po.getPdfLine()!=null)
		newPo.setyCoords(po.getPdfLine().getY1());
		return newPo;
	}

	private static List<String> findPosition(String text, String regex) {
		List<String> positions = new ArrayList<String>();
		Pattern pattern = Pattern.compile(regex);

		text = containsKeyword(text);
		text = containsYear(text);
		Matcher matcher = pattern.matcher(text);

		while (matcher.find()) {
			String itemString = matcher.start()+":"+matcher.end()+":"+matcher.group();
			if(matcher.start()!=-1)
			{
				String sub = text.substring(0,matcher.start());
				if(sub.trim().toLowerCase().endsWith("note"))
				{
					continue;
				}
			}
			positions.add(itemString);
		}
		return positions;
	}

	private static String containsYear(String text) {
		List<String> keywords = Arrays.asList(text.split("\\s"));
		for(String keyword : keywords)
		{
			if(keyword.replaceAll("[0-9]", "").length()==0 && keyword.length()==4)
			{
				text = text.replace(keyword, "");
			}
		}
		return text;
	}

	private static String containsKeyword(String text) {
		for(String keyword : CURRENCY_KEYWORDS)
		{
			if(text.contains(keyword))
			{
				text = text.replace(keyword, "");
			}
		}
		return text;
	}

	public static void main(String[] args) {
		String text = "Accounts receivable, including amounts due from Affiliates (net of allocance for doubtful accounts of  1,198,807 and  185,597 at December 31, 2013 and 2012, respectively)        14,428,949      16,593,934";
		//text = "Freight revenue, including fuel surcharge revenue of $4,171,496 and $3,963,130 in 2013 and 2012        14,428,949      16,593,934";
		//text = "Accounts receivable, net of allowances of $403,296        14,428,949";
		//text = "Accounts receivable, net of allowance for doubtful accounts of $204 and $200 in 2013 and 2012, respectively        14,428,949      16,593,934";
		text = "Accounts receivable, net of allowance for doubtful accounts of $11,231 for both 2013 and 2012     5,541,086     5,111,602";
		text = "Accounts receivable, net of allowances for doubtful accounts and discounts of  107,704        2,476,669";
		text=" INTEREST EXPENSE Net of interest income of $23,000 in 2015 and $25,000 in 2014";
		text="Fixed Assets - Net of Accumulated Depreciation of $164,307 (Note 3 and Note 4)";
		ParserOutput po = new ParserOutput("", text, 1, 1);
		po.setLine(text);
		po.setAsRepLabel(text);
		FinancialStatementExtractor.setLanguage("English");
		List<ParserOutput> list = InlineBreakupExtraction.extract(po);
		System.out.println(list);
		//		System.out.println(text);
		//		String regex = "[[\\d]{1,3},]+";
		//		regex = "[\\d{1,3}]+,[\\d{1,3}]+[.]?";
		//		Pattern pattern = Pattern.compile(regex);
		//		Matcher matcher = pattern.matcher(text);
		//		while (matcher.find()) { 
		//			System.out.println(matcher.group());
		//		}

	}
}
