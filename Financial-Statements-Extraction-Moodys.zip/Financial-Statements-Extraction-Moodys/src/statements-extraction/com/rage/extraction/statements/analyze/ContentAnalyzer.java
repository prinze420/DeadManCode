package com.rage.extraction.statements.analyze;

import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.index.Indexer;



interface ContentAnalyzer {
	public Map<Integer, List<ParserOutput>> getDocument();
	public Map<SectionBoundary, List<ParserOutput>> getClusterContent();
	public void categorize(TreeMap<Integer, PageParse> pageParsesMap) throws Exception;
	public Map<String, List<ParserOutput>> getCategorizedData();
	public Map<SectionBoundary, List<ParserOutput>> getClusterGroups();
	public Map<String, List<ParserOutput>> getTableData();
	public boolean isTable(PDFLine text);
	public Indexer getIndexer();
}
