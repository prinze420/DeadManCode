package com.rage.extraction.statements.uitls;

import java.io.UnsupportedEncodingException;
import java.text.Normalizer;
import java.text.Normalizer.Form;


public class AccentsRemover {
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AccentsRemover.class);


	public static String removeAccents(String text)
	{
		if (logger!=null)
			logger.debug("Accents character removing ...");
		
		return text == null ? null : Normalizer.normalize(text, Form.NFD).replaceAll("\\p{InCombiningDiacriticalMarks}+", "");
	}

	public static String decompose(String text) {
		if (logger!=null)
			logger.debug("decomposing text ...");

		try {
			byte[] bytes = text.getBytes("US-ASCII");
			return new String(bytes, "ISO-8859-15");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		return text;
	}
	
	/*private static int[] ascii_to_utf8(int c)
	{
		int[] out;
		if(c < 128)
		{
			out = new int[1];
			out[0] = c;
		}
		else
		{
			out = new int[2];
			out[0] = (c >> 6) | 0xC0;
			out[1] = (c & 0x3F) | 0x80;
		}

		return out;
	}
*/
	public String convertAscii2UTF(String text) {
		return "";
	}
	
	public static void main(String[] args) {
		String text="-";
		//System.out.println(decompose("4050 � Interest Income-Banco Popular          505.10").replaceAll("\\?", " "));
		//System.out.println(decompose("BALANCE SHEET").replaceAll("\\?", " "));
		System.out.println(AccentsRemover.removeAccents(text));
	
		//System.out.println((int)'�');
	}
}
