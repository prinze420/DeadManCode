package com.rage.extraction.statements.classifier;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Pattern;

import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.train.MetaTree;
import com.rage.extraction.statements.train.Node;
import com.rage.extraction.statements.train.SectionMeta;
import com.rage.extraction.statements.train.SortedOutcomes;
import com.rage.extraction.statements.train.Tree;


public class LabelMapper {
	private Tree labelTree;
	private SectionMeta sectionMeta;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(LabelMapper.class);

	public LabelMapper(String fileName, String industry,String language) throws Exception {
		Constants.loadResourceProperty();
		labelTree=new MetaTree();
		labelTree.read(fileName, industry,language);
		sectionMeta=SectionMeta.getInstance();
	}
	public LabelMapper() {
	}


	public LabelMapper(Tree tree) throws Exception {
		Constants.loadResourceProperty();
		this.labelTree=tree;
	}

	public Tree getMapTree()
	{
		return labelTree;
	}

	public void setMapTree(Tree labelTree) {
		this.labelTree = labelTree;
	}

	private boolean isSubheader(ParserOutput po)
	{
		if( po.getLine()==null)
			return false;
		String text = po.getLine().toString().replace("[", "").replace("]", "");

		if (text!=null && text.trim().endsWith(":"))
			return true;
		int count=0;
		if(po.getValue1()!=null)
		{
			count++;
		}
		if(po.getValue2()!=null)
		{
			count++;
		}

		if(po.getValue3()!=null)
		{
			count++;
		}
		if(po.getValue4()!=null)
		{
			count++;
		}
		if (count==0 && po.getAsRepLabel()!=null && po.getAsRepLabel().replaceAll("[^a-z]", "").length()==0)
			return true;
		return false;
	}

	private void LabelSubsection(List<ParserOutput> poList)
	{
		ParserOutput prev=null;
		for (ParserOutput po:poList)
		{
			po.setSubSection("");
			if (po.getMaxCol()==0 || ( po.getType()!=null && po.getType().equals("ATTR")) || ( po.getType()!=null && po.getType().equals("HEADER")))
			{
				prev=null;
				continue;
			}
			if (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().length()>0 && Pattern.matches("[a-z]", String.valueOf(po.getAsRepLabel().charAt(0))) && prev!=null && po.getLine().length()==po.getLine().replaceAll("[0-9]", "").length())
			{
				String temp=prev.getAsRepLabel()+" "+po.getAsRepLabel();
				po.setAsRepLabel(temp);
				prev.setAsRepLabel("");
				prev.setSubSection("");
			}

			if (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().length()>0 && po.getAsRepLabel().trim().endsWith("at") && prev!=null &&  po.getLine().length()==po.getLine().replaceAll("[0-9]", "").length())
			{
				String temp=prev.getAsRepLabel()+" "+po.getAsRepLabel();
				po.setAsRepLabel(temp);
				prev.setAsRepLabel("");
				prev.setSubSection("");
			}
			if (po.getMaxCol()>0 
					&&( po.getType()!=null && po.getType().equals("HEADER")))
			{
				po.setSubSection("HEADER");
				continue;
			}
			else
				if (po.getMaxCol()>0 
						&&( po.getType()!=null && po.getType().equals("ATTR")))
				{
					po.setSubSection("ATTR");
					continue;
				} else if (isSubheader(po))
				{
					po.setType("SUB-HEADER");
					continue;
				}
			prev=po;
		}
	}

	// correct broken labels
	private List<ParserOutput> factorizeContentCategories(List<ParserOutput> list)
	{
		List<ParserOutput> newList=new ArrayList<ParserOutput>();
		ParserOutput prev=null;
		for(ParserOutput po:list)
		{
			if (po.getMaxCol()==0)
				continue;
			if (prev==null)
			{
				prev=po;
				newList.add(prev);
				continue;
			}
			if ((po.getType()!=null && po.getType().equals("ATTR"))) {
				continue;
			}
			String text = null;
			if( po.getLine()!=null)
				text = po.getLine().toString().replace("[", "").replace("]", "");
			
		//	if(text!=null && text.length()==text.replaceAll("[0-9]", "").length())

			if (text!=null && text.length()==text.replaceAll("[0-9]", "").length() && (prev!=null &&  prev.getAsRepLabel()!=null && prev.getMaxCol()>0 && !prev.getAsRepLabel().startsWith("STATEMENT") && (prev.getAsRepLabel().toLowerCase().endsWith(" and") || prev.getAsRepLabel().toLowerCase().endsWith(" at")) 
					|| ( prev!=null && prev.getAsRepLabel()!=null && prev.getMaxCol()>0 && !prev.getAsRepLabel().startsWith("STATEMENT") && prev.getAsRepLabel().toLowerCase().endsWith(";"))
					|| (prev!=null &&  prev.getAsRepLabel()!=null && prev.getMaxCol()>0 && !prev.getAsRepLabel().startsWith("STATEMENT") && text!=null && text.trim().length()>0 && Pattern.matches("[a-z]", String.valueOf(po.getLine().toString().trim().charAt(0))))))
			{
				merge(po, prev);
				if (po.getMaxCol()>0)
					newList.add(po);
				continue;
			}
			prev=po;
			if (prev.getMaxCol()>0)
				newList.add(prev);
		}
		return newList;
	}

	private void merge(ParserOutput source, ParserOutput target)
	{
		if (source==null || target==null) 
			return;
		String label=target.getAsRepLabel()+" "+source.getAsRepLabel();
		target.setAsRepLabel("");
		source.setAsRepLabel(label);
	}


	private String cleanLabel(ParserOutput po)
	{
		logger.debug("AsRep ::" + po.getAsRepLabel());
		String label=po.getAsRepLabel();
		if(label==null)
			return "";
		if(TimePeriodOntology.getNotesList()!=null)
		{
			for(String keyword:TimePeriodOntology.getNotesList())
			{
				label=label.toLowerCase().replaceAll("\\("+keyword.trim().toLowerCase()+"(.*?)"+"\\)", "");
				label=label.toLowerCase().replaceAll("\\["+keyword.trim().toLowerCase()+"(.*?)"+"\\]", "").trim();
				logger.debug("After TimePriodOnto AsRep ::" + label);
			}
		//label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
		//label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
	//	label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();
		}
		/*label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
		label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
		label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();*/
		label=label.replaceAll("[^a-z A-Z\\-]", "");
		label=label.replaceAll("\\s\\s+", " ");
		logger.debug("Retained Only Alphabets AsRep ::" + label);
		return label;
	}

	private List<List<ParserOutput>> split(List<ParserOutput> poList) {
		List<List<ParserOutput>> statements=new ArrayList<List<ParserOutput>>();
		List<ParserOutput> list=null;
		if(poList!=null)
		{
			if(!DataWriterSql.isSplitTable(poList))
				Collections.sort(poList);
			for (ParserOutput po:poList) {
				if (po.getMaxCol()>0  &&  po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equals("STATEMENT YEAR")){//&& cc.getColumn().get(0).equals("FISCAL YEAR END")) {
					list=new ArrayList<ParserOutput>();
					statements.add(list);
				}
				if (list!=null && po!=null)
					list.add(po);
			}
		}
		return statements;
	}

	private ArrayList<ParserOutput> combine(List<List<ParserOutput>> statements) {
		ArrayList<ParserOutput> list=new ArrayList<ParserOutput>();
		for (List<ParserOutput> poList:statements) {
			list.addAll(poList);
		}
		return list;
	}

	public ArrayList<ParserOutput> map(List<ParserOutput> conCategoryList) throws Exception
	{
		SortedOutcomes outcomes=new SortedOutcomes(labelTree);
		List<List<ParserOutput>> statements=split(conCategoryList);
		for (List<ParserOutput> poList:statements) {
			/*if(!FinancialStatementExtractor.getLanguage().contains("ITR") )
				poList=factorizeContentCategories(poList);*/
			LabelSubsection(poList);
			ParserOutput prevHead=null;
			ParserOutput prev=null;
			String prevSec="";
			boolean prevTotal=false;
			//int headerDistance=-1;
			for (ParserOutput po:poList)
			{
				/*if(po.getBreakups().equalsIgnoreCase("Y"))
					continue;*/
				logger.debug("PO ==>" + po.getAsRepLabel() + "[Section :" + po.getSection() + "]" + "[Type :" + po.getType() + "]");
				if (po.getLine()!=null && po.getLine().toString().replace("[", "").replace("]", "").endsWith(":") /*|| cc.getType().equals("SUB-HEADER")
						||*/ || po.getMaxCol()==1)
				{
					po.setType("SUB-HEADER");
					prevHead=po;					//headerDistance=0;
					String label=cleanLabel(po).toLowerCase();
					outcomes.search(label);
					List<Node> res=outcomes.resolveConflicts(prevSec);
					if (res!=null && res.size()==1)
					{
						Node node=res.get(0);
						po.setSubSection(labelTree.getSubSection(node));
						prevSec=po.getSubSection();
						logger.debug("[" + labelTree.getSubSection(node) + "]" + po.getAsRepLabel() + " ** PrevSubSection :" + prevSec);
					}
					continue;
				}
				if ((po.getType()!=null && po.getType().equals("ATTR"))|| (po.getMaxCol()==1 && !FinancialStatementExtractor.getLanguage().contains("ITR"))|| po.getType()==null ) {
					po.setSubSection("ATTR");
					continue;
				}
				if(po.getType().equalsIgnoreCase("HEADER"))
				{
					po.setSubSection("HEADER");
					continue;
				}
				String text = null;
				if(FinancialStatementExtractor.getLanguage().contains("ITR"))
				{
					if( (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equals("TOTAL SUB-SECTION"))
							|| (po.getAsRepLabel()!=null && po.getAsRepLabel().toLowerCase().trim().endsWith("total"))
							|| (po.getAsRepLabel()!=null && po.getAsRepLabel().toLowerCase().trim().endsWith("totals")))	
					{
						po.setSubtotal("Y");
					}
				}
				else
				{
					text = po.getLine().trim().toString().replace("[", "").replace("]", "");
					logger.debug("** PO Line :" + text);
					if ((text !=null && text.toLowerCase().trim().startsWith("total") )
							|| (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equals("TOTAL SUB-SECTION"))
							|| (po.getAsRepLabel()!=null && po.getAsRepLabel().toLowerCase().trim().endsWith("total"))
							|| (po.getAsRepLabel()!=null && po.getAsRepLabel().toLowerCase().trim().endsWith("totals")))
						po.setSubtotal("Y");
				}
				//headerDistance++;
				String label=cleanLabel(po).toLowerCase();
				outcomes.search(label);
				List<Node> res=outcomes.resolveConflicts(prevSec);
				if (res==null)
				{
					// label with other info
					label=po.getAsRepLabel();
					label=cleanLabel(po).toLowerCase();
					String[] labels=label.split("[^a-z A-Z0-9]");
					if (labels.length>0 && !labels[0].equals(""))
						label=labels[0].trim();
					outcomes.search(label);
					res=outcomes.resolveConflicts(prevSec);
				}
				if (res==null && label.length()>0 && po.getLine().length()==po.getLine().replaceAll("[0-9]", "").length())
				{
					// broken labels
					if (label==null || label.trim().length()==0)
						continue;
					String firstCh=String.valueOf(label.trim().charAt(0));
					if ((prev!=null && prev.getAsRepLabel()!=null) && ( prev.getAsRepLabel().trim().endsWith(";") 
							|| prev.getAsRepLabel().trim().toLowerCase().endsWith(",")
							|| prev.getAsRepLabel().trim().toLowerCase().endsWith(" and")
							|| prev.getAsRepLabel().trim().toLowerCase().endsWith(" of")
							|| prev.getAsRepLabel().trim().toLowerCase().endsWith(" to")
							||(po.getAsRepLabel()!=null && po.getAsRepLabel().trim().toLowerCase().startsWith("of "))) 
							&& Pattern.matches("[a-z]", firstCh) || ( prev!=null && prev.getAsRepLabel()!=null && prev.getAsRepLabel().trim().toLowerCase().startsWith(" at")))
					{
						if (prevHead!=null && po.getAsRepLabel()!=null && po.getAsRepLabel().trim().toLowerCase().startsWith("of "))
						{
							label=prevHead.getAsRepLabel()+" "+po.getAsRepLabel();
							po.setAsRepLabel(label);
							prevHead.setAsRepLabel("");
						}
						else
						{
							label=prev.getAsRepLabel()+" "+po.getAsRepLabel();
							po.setAsRepLabel(label);			
							prev.setAsRepLabel("");
						}
						//headerDistance=0;
						outcomes.search(label);
						res=outcomes.resolveConflicts(prevSec);
					}
					if (Pattern.matches("[a-z]", firstCh) && prev!=null)
					{
						label=prev.getAsRepLabel()+" "+label;
						outcomes.search(label);
						res=outcomes.resolveConflicts(prevSec);
					}
				} 
				if (res!=null)
				{
					if (res.size()==1 && labelTree.getSubSection(res.get(0))!=null && res.get(0).getParent()!=null && po.getMapNode()==null)
					{
						Node node=res.get(0);
						if (!po.getType().equals("SUB-HEADER") && node.level()>1)
						{
							po.setMapNode(node.getParent());
							po.setLabelMap(node.getParent().text());
							po.setSubSection(labelTree.getSubSection(node));
							po.setMultiMapNode(res);
							logger.debug("[" + labelTree.getSubSection(node) + "]" + po.getAsRepLabel() + " ** Non SubHeader");
						} else {
							po.setSubSection(labelTree.getSubSection(node));
							logger.debug("[" + labelTree.getSubSection(node) + "]" + po.getAsRepLabel() + " ** SubHeader");
						}
					} else if (prevSec.equals("") && res.size()>0)
					{
						Node node=res.get(0);
						po.setMapNode(node);
						po.setSubSection(labelTree.getSubSection(node));
						res.clear();
						res.add(node);
						po.setMultiMapNode(res);
						logger.debug("[" + labelTree.getSubSection(node) + "]" + po.getAsRepLabel() + " ** PrevSubSection -- Empty");
					} else {
						po.setMultiMapNode(res);
					}
				}
				prevTotal=po.getSubtotal().equals("Y")?true:false;
				if (!prevTotal)
				{
					prevSec=!po.getSubSection().equals("")?po.getSubSection():prevSec;
				} else if (prevTotal && po.getSubSection().equals(""))
					po.setSubSection(prevSec);
				else if (prevTotal && !po.getSubSection().equals(""))
					prevSec=po.getSubSection();
				if (prev!=null && prev.getSubSection().equals("") && prevTotal)
					prev.setSubSection(po.getSubSection());
				prev=po;
			}
			reOrder(poList);
		}
		return combine(statements);
	}



	private void markProximitySubsection(ParserOutput contCat, Vector<ParserOutput> vector)
	{
		if (vector==null)
			vector=new Vector<ParserOutput>();
		for(ParserOutput cc:vector)
		{
			if (contCat.getSubSection()==null || contCat.getSubSection().equals(""))
				return;
			cc.setSubSection(contCat.getSubSection());
			if (cc.getSubtotal().equals("Y"))
				break;
		}
		List<ParserOutput> newList=new ArrayList<ParserOutput>();
		for(ParserOutput cc:vector)
		{
			if (cc.getSubSection().length()>0)
				continue;
			newList.add(cc);
		}
		vector.clear();
		vector.addAll(newList);

	}

	private void markProximitySubsection(List<ParserOutput> poList) throws Exception
	{
		Vector<ParserOutput> vector=new Vector<ParserOutput>();
		ParserOutput refer=null;
		for (ParserOutput po:poList)
		{
			if ((po.getType()!=null && po.getType().equals("ATTR")) || (po.getType()!=null && po.getType().equalsIgnoreCase("HEADER"))) 
				continue;

			if (po.getAsRepLabel()!=null &&( po.getAsRepLabel().trim().toLowerCase().startsWith("total")
					|| po.getAsRepLabel().trim().toLowerCase().endsWith("total")))
				po.setSubtotal("Y");
			if (po.getSubSection().equals("") && po.getSubtotal().equals("Y") && refer!=null)
				po.setSubSection(refer.getSubSection());
			if (refer!=null && !po.getSubSection().equals(refer.getSubSection()))
			{
				if (poList.get(poList.size()-1).equals(po) && po.getSubSection().equals(""))
					vector.add(po);
				else if (refer!=null)
					checkMultiMap(refer, po);
				markProximitySubsection(refer,vector);
				refer=null;
			}
			else if (refer==null && !po.getSubSection().equals(""))
				refer=po;
			if (po.getSubSection().equals(""))
				vector.add(po);
		}
		if (vector.size()>0 && refer!=null)
			markProximitySubsection(refer,vector);
	}

	private void checkMultiMap(ParserOutput refer, ParserOutput cc) throws Exception
	{
		if (refer==null || cc.getMultiMapNode()==null)
			return;
		String section=refer.getSubSection();
		if (sectionMeta==null)
			sectionMeta=SectionMeta.getInstance();
		String nextSection=sectionMeta.getNextSubSection(section);
		List<Node> newList=new ArrayList<Node>();
		for (Node node:cc.getMultiMapNode())
		{
			if (labelTree.getSubSection(node).equals(section) || labelTree.getSubSection(node).equals(nextSection))
				newList.add(node);
		}
		if (newList.size()>0)
			cc.getMultiMapNode().retainAll(newList);
		if (cc.getMultiMapNode().size()==1)
		{
			cc.setSubSection(labelTree.getSubSection(cc.getMultiMapNode().get(0)));
			cc.setMapNode(cc.getMultiMapNode().get(0));
			cc.setLabelMap(cc.getMultiMapNode().get(0).getParent().text());
			refer=cc;
		}
	}



	private List<ParserOutput> reOrder(List<ParserOutput> catList) throws Exception
	{
		markProximitySubsection(catList);
		List<ParserOutput> finalList=new ArrayList<ParserOutput>();
		Set<String> subSec=new HashSet<String>();
		for (ParserOutput po:catList)
		{
			if (subSec.contains(po.getSubSection()))
				continue;
			if (po.getSubSection().equals("SUB-HEADER") || po.getSubSection().equals(""))
			{
				finalList.add(po);
				continue;
			}
			if (!subSec.contains(po.getSubSection()))
			{
				finalList.addAll(getObjOfType(po.getSubSection(), catList));
				subSec.add(po.getSubSection());
			}
		}
		catList=finalList;
		String section="";
		for (ParserOutput cc:finalList)
		{
			if (cc.getType()!=null && cc.getType().equals("ATTR"))
				continue;
			if (!cc.getSubSection().equals("") && section.equals(""))
				section=cc.getSubSection();
			if (cc.getMapNode()!=null && cc.getMultiMapNode()==null)
				continue;
			if (cc.getMultiMapNode()!=null && cc.getMultiMapNode().size()>0)
			{
				for (Node node:cc.getMultiMapNode())
				{
					if (labelTree.getSubSection(node).equals(section) && node.level()>1)
					{
						cc.setMapNode(node);
						cc.setLabelMap(node.getParent().text());
					}
				}
			}
			if (!section.equals(cc.getSubSection()))
				section=cc.getSubSection();
		}
		return finalList;
	}

	private List<ParserOutput> getObjOfType(String type, List<ParserOutput> catList)
	{
		List<ParserOutput> finalList=new ArrayList<ParserOutput>();
		for (ParserOutput cc:catList)
		{
			if (cc.getSubSection().equals(type))
				finalList.add(cc);
		}
		return finalList;
	}

	public ArrayList<ParserOutput> restructureContentCategories(List<ParserOutput> list)
	{
		if (logger!=null)
			logger.debug("Restructuring multi-line contents...");

		List<ParserOutput> newList=new ArrayList<ParserOutput>();
		ParserOutput prev=null;
		for(ParserOutput cc:list)
		{
			if (cc.getMaxCol()==0)
				continue;

			if (cc.getAsRepLabel()!=null && cc.getAsRepLabel().trim().startsWith("STATEMENT")) {
				newList.add(cc);
				continue;
			}

			if (prev==null)
			{
				prev=cc;
				newList.add(prev);
				continue;
			}
			if ((prev.getMaxCol()>0 && prev.getAsRepLabel()!=null && cc.getAsRepLabel()!=null && cc.getAsRepLabel().length()==cc.getAsRepLabel().replaceAll("[0-9]", "").length() &&  !prev.getAsRepLabel().startsWith("STATEMENT") && isWrappedText(prev.getAsRepLabel())/*prev.getColumn().get(0).toLowerCase().endsWith(" and")*/  ) 
					|| (prev.getMaxCol()>0 &&  prev.getAsRepLabel()!=null && prev.getAsRepLabel().toLowerCase().endsWith(";"))
					|| (cc.getLine()!=null && cc.getLine().replace("[", "").replace("]", "").trim().length()>0 && Pattern.matches("[a-z]", String.valueOf(cc.getLine().replace("[", "").replace("]", "").trim().charAt(0)))))
			{
				merge(cc, prev);
				continue;
			}
			prev=cc;
			newList.add(prev);
		}
		return (ArrayList<ParserOutput>) newList;
	}

	private boolean isWrappedText(String asRepLabel) {
		// TODO Auto-generated method stub
		return false;
	}

}
