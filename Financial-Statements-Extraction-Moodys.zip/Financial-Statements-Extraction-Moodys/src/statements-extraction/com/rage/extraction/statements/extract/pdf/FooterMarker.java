package com.rage.extraction.statements.extract.pdf;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.detectors.text.DataType;
import com.rage.extraction.statements.detectors.text.DataTypeFinder;

public class FooterMarker {

	TreeMap<Integer, PageParse>	reportPages;
	
	
	public FooterMarker(TreeMap<Integer, PageParse> pageParsesMap) {

		this.reportPages=pageParsesMap;
		
	}

	public FooterMarker() {
		// TODO Auto-generated constructor stub
	}

	public static void main ( String[] args )
	{
		FinancialStatementExtractor.setLanguage("English");
		
		List<String> patterns  = readPatternList();
		
		for(String eachPatten:patterns)
		{
			boolean ist=isPatternMatches("56,7899", eachPatten);
			if(ist)
				System.out.println(eachPatten);
		}
		
	}

	public void run ( )
	{
		System.out.println("Removing Footer Lines...");
		
		try
		{
			List<String> patterns  = readPatternList();
			List<Float> yAxis = new ArrayList<Float>();
			String matchedPattern = getPatternforFooterRows(reportPages,yAxis,patterns);
			
			if(matchedPattern==null)
			return;
			
			Pair<Float, Float> pair = new Pair<Float, Float>(0f, 0f);
			if(matchedPattern!=null)
			{
				pair = computeConstantYaxis(yAxis);
			}
			
			Map<Integer,PDFLine> pageFooterLineMap = getPageWiseFooterRows(reportPages,pair,matchedPattern,patterns);
			
			markFooterRows(pageFooterLineMap,reportPages);
			
			System.out.println("Footer rows##");
			
			for( int index = 0; index < reportPages.size(); index++ )
			{
				List<PDFBlock> pdfBlocks  = reportPages.get(index).getPageBlocks();
				
				for(int j = 0;j<pdfBlocks.size();j++)
				{
					List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
					
					for(int l=pdfLines.size()-1;l>=0;l--)
					{
						if(pdfLines.get(l).isLineFooter())
							System.out.println("Line::"+pdfLines.get(l).getPageNo()+"=="+pdfLines.get(l));
					}
				}
			}
			System.out.println("Done");
		}
		catch (Exception e)
		{
			System.out.println("Exception occured while marking Footer rows...");
			e.printStackTrace();
		}
	}
	
	private void markFooterRows ( Map<Integer, PDFLine> pageFooterLineMap, TreeMap<Integer, PageParse> reportPages2 )
	{
		for( int index = 0; index < reportPages.size(); index++ )
		{
			if(!pageFooterLineMap.containsKey(index))
				continue;
			
			PDFLine footerLine = pageFooterLineMap.get(index);
			
			List<PDFBlock> pdfBlocks  = reportPages.get(index).getPageBlocks();
			
			for(int j=pdfBlocks.size()-1;j>0;j--)
			{
				List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
				
				boolean matched = false;
				for(int l=pdfLines.size()-1;l>=0;l--)
				{
					PDFLine line  = pdfLines.get(l);
					
					if(line.equals(footerLine))
					{
						line.setLineFooter(true);
						matched = true;
						break;
					}
				}
				
				if(matched)
					break;
			}
			
			List<PDFLine> pdfLines = reportPages.get(index).getPageLines();
			
			for(int l=pdfLines.size()-1;l>=0;l--)
			{
				PDFLine line  = pdfLines.get(l);
				
				if(line.equals(footerLine))
				{
					if(line.equals(footerLine))
					{
						line.setLineFooter(true);
						break;
					}
				}
			}
		}
	}

	private Map<Integer, PDFLine> getPageWiseFooterRows ( TreeMap<Integer, PageParse> reportPages2, Pair<Float, Float> pair,
			String matchedPattern, List<String> patterns )
	{
		Map<Integer,PDFLine> pageFooterLineMap =  new LinkedHashMap<Integer,PDFLine>(); 
		
		for( int index = 0; index < reportPages.size(); index++ )
		{
			List<PDFLine> pdfLines  = reportPages.get(index).getPageLines();
		
			int maxLinesToCheck = 3;
			int lineCounter = 0;
			boolean footerFound = false;
			for(int l=pdfLines.size()-1;l>0;l--)
			{
				if(lineCounter==maxLinesToCheck)
					break;
				
				PDFLine line  = pdfLines.get(l);
				
				boolean matched = false;
				for(PDFChunk eachChunk : line.getChunks())
				{
					
					matched  = isPatternMatches(eachChunk,matchedPattern);
					if(matchedPattern.equals("([0-9]{1,3})") && matched)
					{
						// check if there are other numbers with comma, then false. this num can be note number
						if(ifLineContainsNumberChunks(line))
							matched=false;
					}
					if(matched)
					{
						if(eachChunk.getY1()>=pair.getA() && eachChunk.getY1()<=pair.getB())
						{
							footerFound = true;
						}
					}
				}
				
				
				if(footerFound)
				{
					pageFooterLineMap.put(index, line);
					footerFound=false;
					//break;
				}
				else
				{
					boolean isFooter=checkNearPagesForFooterPattern(line,reportPages,index,patterns);
					if(isFooter)
					{
						//footerFound=true;
						pageFooterLineMap.put(index, line);
						//break;
					}
				}
				
				lineCounter++;
			}
		}	
		
		return pageFooterLineMap;
	}

	private boolean checkNearPagesForFooterPattern(PDFLine line, TreeMap<Integer, PageParse> reportPages2, int index, List<String> patterns) 
	{
		if(reportPages2!=null)
		{
			boolean isMatch=false;
			String thisPattern=null;
			for(String pattern:patterns)
			{
				for(PDFChunk chunk:line.getChunks())
				{
					isMatch=isPatternMatches(chunk, pattern);
					if(pattern.equals("([0-9]{1,3})") && isMatch)
					{
						// check if there are other numbers with comma, then false. this num can be note number
						if(ifLineContainsNumberChunks(line))
							isMatch=false;
					}
					if(isMatch)
					{
						thisPattern=pattern;
						break;
					}
				}
				if(isMatch)
					break;
			}
			
			if(!isMatch)
				return false;
			
			System.out.println(thisPattern+"=Pattern Match For Line::pg="+line.getPageNo()+" "+line.getLine());
			
			int totalMatch=0;
			int pageLimit=10;
			for(int i=index-1;i>=0;i--)
			{
				List<PDFLine> pdfLines=reportPages2.get(i)!=null?reportPages2.get(i).getPageLines():null;
				if(pdfLines==null || pdfLines.size()<1)
					continue;
				if(pageLimit==0)
					break;
				pageLimit--;
				int lineCounter=0;
				int maxLinesToCheck=3;
				for(int l=pdfLines.size()-1;l>0;l--)
				{
					if(lineCounter==maxLinesToCheck)
						break;
					lineCounter++;
					PDFLine thisLine  = pdfLines.get(l);
					boolean matched = false;
					for(PDFChunk eachChunk : thisLine.getChunks())
					{
						matched  = isPatternMatches(eachChunk,thisPattern);
						
						if(matched)
						{
							totalMatch++;
						}
					}
				}
			}
			
			if(totalMatch>=5)
				return true;
			
			pageLimit=10;
			for(int i=index+1;i<reportPages2.size();i++)
			{
				List<PDFLine> pdfLines=reportPages2.get(i)!=null?reportPages2.get(i).getPageLines():null;
				if(pdfLines==null || pdfLines.size()<1)
					continue;
				if(pageLimit==0)
					break;
				pageLimit--;
				int lineCounter=0;
				int maxLinesToCheck=3;
				for(int l=pdfLines.size()-1;l>0;l--)
				{
					if(lineCounter==maxLinesToCheck)
						break;
					lineCounter++;
					PDFLine thisLine  = pdfLines.get(l);
					boolean matched = false;
					for(PDFChunk eachChunk : thisLine.getChunks())
					{
						matched  = isPatternMatches(eachChunk,thisPattern);
							
						if(matched)
						{
							totalMatch++;
						}
					}
				}
			}
			if(totalMatch>=5)
				return true;
		}
		return false;
	}

	private boolean ifLineContainsNumberChunks(PDFLine line) 
	{
		if(line==null || line.getChunks()==null || line.getChunks().size()<1)
			return false;
		
		for(PDFChunk chunk:line.getChunks())
		{
			DataType dataType=DataTypeFinder.findDataType(chunk.getChunk().trim());
			if(dataType!=null && dataType.equals(DataType.NUMERIC_VALUE) && (chunk.getChunk().contains(",") 
					 || (line.getLine().toLowerCase().contains("total") ||  line.getLine().toLowerCase().contains("net"))))
			{
				return true;
			}
		}
		
		return false;
	}

	public Pair<Float, Float> computeConstantYaxis ( List<Float> distances )
	{
		List<List<Float>> gapGroups = new ArrayList<List<Float>>() ;
		for ( int i=0 ; i<distances.size() ; i++ )
		{
			float thisGap = distances.get(i) ;

			boolean foundGroup = false ;
			for ( int j=0 ; j<gapGroups.size() ; j++ )
			{
				List<Float> thisGroup = gapGroups.get(j) ;
				Pair<Float, Float> pair = findMinMaxGaps(thisGroup) ;
				float minGroupGap = pair.getA().floatValue() - 1.0f ;
				float maxGroupGap = pair.getB().floatValue() + 1.0f ;

				if ( thisGap >= minGroupGap && thisGap <= maxGroupGap )
				{
					thisGroup.add(thisGap) ;
					foundGroup = true ;
					break ;
				}
			}

			if ( !foundGroup )
			{
				List<Float> newGroup = new ArrayList<Float>() ;
				newGroup.add(thisGap) ;
				gapGroups.add(newGroup) ;
			}
		}
		
		List<Float> biggestGroup = new ArrayList<Float>();
		
		for(List<Float> group : gapGroups)
		{
			if(group.size()>biggestGroup.size())
			{
				biggestGroup=group;
			}
		}
		
		Pair<Float, Float> minMax = findMinMaxGaps(biggestGroup);
		
		float padding = 1.0f ;
		Pair<Float, Float> pair = new Pair<Float, Float>(minMax.getA().floatValue()-padding, minMax.getB().floatValue()+padding) ;

		return pair ;
	}
	
	private Pair<Float, Float> findMinMaxGaps(List<Float> group) 
	{
		float min = Float.MAX_VALUE ;
		float max = Float.MIN_VALUE ;

		for ( int i=0 ; i<group.size() ; i++ )
		{
			float gap = group.get(i) ;

			if ( min > gap )
				min = gap ;

			if ( max < gap )
				max = gap ;
		}

		Pair<Float, Float> pair = new Pair<Float, Float>(min, max) ;
		return pair ;
	}

	private String getPatternforFooterRows ( TreeMap<Integer, PageParse> reportPages, List<Float> yAxis2,List<String> patterns  )
	{
		

		for(String eachpat : patterns)
		{
			List<Float> yAxis = new ArrayList<Float>();
			int patMatchedCount = 0;
			int maxPagesToCheck = 15;
			int pageCounter = 0;
			int leaveIndexPages=10;
			
			for( int index = 0; index < reportPages.size(); index++ )
			{
				if(reportPages.size()>40 && index < leaveIndexPages)
				{
					continue;
				}
				
				if(pageCounter == maxPagesToCheck)
				{
					break;
				}
				
				List<PDFLine> pdfLines  = reportPages.get(index).getPageLines();
			
				int maxLinesToCheck = 3;
				int lineCounter = 0;
				for(int l=pdfLines.size()-1;l>0;l--)
				{
					if(lineCounter==maxLinesToCheck)
						break;
					
					PDFLine line  = pdfLines.get(l);
					
					boolean matched = false;
					for(PDFChunk eachChunk : line.getChunks())
					{
						matched  = isPatternMatches(eachChunk,eachpat);
						
						if(matched)
						{
							System.out.println("Chunked matched::"+eachChunk.getChunk());
						
							System.out.println("x1="+eachChunk.getX1()+"\t"+"x2="+eachChunk.getX2()+"\t"+"y1="+eachChunk.getY1()+"\t"+"y2="+eachChunk.getY2()+"\t");
							
							yAxis.add(eachChunk.getY1());
							
							patMatchedCount++;
							break;
						}
					}
					
					if(matched)
					{
						break;
					}
					lineCounter++;
				}
				pageCounter++;
			}	
			
			if(patMatchedCount >= reportPages.size()-1 || patMatchedCount>9)
			{
				yAxis2.addAll(yAxis);
				return eachpat;
			}
		}
		return null;
	}

	public static boolean isPatternMatches ( PDFChunk eachChunk, String eachpat )
	{
		try
		{
			Pattern p = Pattern.compile(eachpat);
			
			Matcher m = p.matcher(eachChunk.getChunk().trim());
			
			if(m.matches())
			{
				return true;
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	public static boolean isPatternMatches ( String eachChunk, String eachpat )
	{
		try
		{
			Pattern p = Pattern.compile(eachpat);
			
			Matcher m = p.matcher(eachChunk.trim());
			
			if(m.matches())
			{
				return true;
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	
	private static List<String> readPatternList ( )
	{
		String file = "";
		if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
		{
			file = "resource/section-identification/FooterPageNoPatterns.txt";
		}
		else
		{
			file = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+ "/FooterPageNoPatterns.txt";
		}
		
		List<String> patterns =  new ArrayList<String>();
		
		BufferedReader br = null;
		String line = "";
		try
		{
			br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8")); 
			
			while((line=br.readLine())!=null)
			{
				patterns.add(line);
			}
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
				
		return patterns;
		
	}

	public TreeMap<Integer, PageParse> getReportPages ( )
	{
		return reportPages;
	}

	public void setReportPages ( TreeMap<Integer, PageParse> reportPages )
	{
		this.reportPages = reportPages;
	}

	public TreeMap<Integer, PageParse> removeFooterRowsFromPageParse ( TreeMap<Integer, PageParse> pageParsesMap )
	{
		try
		{
			for( int index = 0; index < pageParsesMap.size(); index++ )
			{
				///remove footer blocks
				List<PDFBlock> newBlocks = new ArrayList<PDFBlock>();
				List<PDFBlock> pdfBlocks  = pageParsesMap.get(index).getPageBlocks();
				
				for(int j=0;j<pdfBlocks.size();j++)
				{
					List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
					
					for(int l=0;l<pdfLines.size();l++)
					{
						PDFLine line  = pdfLines.get(l);
						
						if(line.isLineFooter())
						{
							pdfLines.remove(l);
							break;
						}
					}
					
					if(!pdfLines.isEmpty() && pdfLines.size()>0)
					{
						PDFBlock block =  new PDFBlock(pdfLines.get(0).getPageNo(), pdfLines);
						newBlocks.add(block);
					}
				}
				pageParsesMap.get(index).setPageBlocks(newBlocks);
				
				///remove footer Lines
				List<PDFLine> pdfLines = pageParsesMap.get(index).getPageLines();
				
				for(int l=0;l<pdfLines.size();l++)
				{
					PDFLine line  = pdfLines.get(l);
					
					if(line.isLineFooter())
					{
						pdfLines.remove(l);
						break;
					}
				}
			}
		}
		catch (Exception e)
		{
			System.out.println("Exception occured while removing Footer rows...");
			e.printStackTrace();
			
			return pageParsesMap;
		}
		
		return pageParsesMap;
	}

}
