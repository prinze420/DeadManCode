package com.rage.extraction.statements.breakups;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.ParserConfigurationException;

import org.xml.sax.SAXException;

import com.dp.hierarchy.HierarchyNode;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.associations.AssociationCreator;
import com.rage.extraction.pdf.associations.InnerSplit;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.analyze.ContentCategorizer;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.MapCols;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.SectionSpreader;
import com.rage.extraction.statements.fs.merge.RecursiveMergeStatement;
import com.rage.extraction.statements.index.MemIndexer.Type;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.similarity.JaccordSimilarity;


public class BreakupExtraction {
	private Map<String, ArrayList<ParserOutput>> sectionMap; 
	//private ParserOutput po;
	private ContentCategorizer contentCategorizer;
	private List<String> sectionBounds;
	private static int constantMultiplier = 1000000;

	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(BreakupExtraction.class);

	public BreakupExtraction(Map<String, ArrayList<ParserOutput>> sectionMap, ContentCategorizer contentCategorizer) {
		if (logger!=null)
			logger.debug("Breakup items extraction ...");
		this.contentCategorizer = contentCategorizer;
		this.sectionMap = sectionMap;
		findSectionBounds();

	}

	private void findSectionBounds() {
		if (sectionMap!=null) {

			if (logger!=null)
				logger.debug("Finding section bounds ...");

			for (String section : sectionMap.keySet()) {

				if (!sectionMap.get(section).isEmpty()) {
					RecursiveMergeStatement stmtMerger = new RecursiveMergeStatement(sectionMap.get(section));
					ArrayList<Integer> stmtIndex=stmtMerger.getStatementStartIndex(sectionMap.get(section));
					List<ArrayList<ParserOutput>> statements =  null;
					if (stmtIndex.size()>1)
					{
						statements = stmtMerger.breakStatements(stmtIndex);
					}
					else
					{
						statements = new ArrayList<ArrayList<ParserOutput>>();
						statements.add(sectionMap.get(section));
					}

					for (List<ParserOutput> statement : statements) {
						int startPage=-1, startLine=-1, endPage=-1, endLine=-1;

						if (statement.size()>0) {

							for (ParserOutput po : statement) {
								if (po.getType()!=null && (po.getType().equals("ATTR") || po.getType().equals("HEADER")))
									continue;
								startPage = po.getPageNo();
								startLine = po.getLineNo();
								break;
							}
						}

						if (statement.size()>1 && statement.get(statement.size()-1).getType()!=null && !statement.get(statement.size()-1).getType().equals("ATTR") && !statement.get(statement.size()-1).getType().equals("HEADER")) {
							endPage = statement.get(statement.size()-1).getPageNo();
							endLine = statement.get(statement.size()-1).getLineNo();
						}

						if (startPage!=-1 && startLine!=-1 && endPage!=-1 && endLine!=-1) {
							String startBound = "";
							startBound = String.valueOf(((startPage+1) * constantMultiplier)+startLine);


							String endBound = String.valueOf(((endPage+1) * constantMultiplier)+endLine);

							if (sectionBounds==null)
								sectionBounds = new ArrayList<String>();
							if (!sectionBounds.contains(section+"|"+startBound+"|"+endBound+"|"+startPage+"|"+startLine+"|"+endPage+"|"+endLine))
								sectionBounds.add(section+"|"+startBound+"|"+endBound+"|"+startPage+"|"+startLine+"|"+endPage+"|"+endLine);
						}
					}
				}
			}
		}
	}

	private boolean isOutOfBounds(int pageNo, int lineNo) {

		if (logger!=null)
			logger.debug("Finding breakup item out of section bounds or not ...");

		if(sectionBounds==null)
			return false;

		for (String bound : sectionBounds) {
			String tokens[] = bound.split("\\|");
			int startPage = Integer.parseInt(tokens[3]);
			int endPage = Integer.parseInt(tokens[5]);
			int startLine = Integer.parseInt(tokens[4]);
			int endLine = Integer.parseInt(tokens[6]);

			int currCC = ((pageNo+1)*constantMultiplier)+lineNo;
			if (currCC >= Integer.parseInt(tokens[1]) && currCC <= Integer.parseInt(tokens[2])) {
				logger.debug("PageNo :"+pageNo+" LineNo :"+lineNo+" part-of section "+tokens[0]+"...");
				return false;
			}
		}
		return true;
	}

	private String getAsRepLabel(ParserOutput po) {
		if (po.getMaxCol()>0) {

			if (logger!=null)
				logger.debug("As rep Label :"+po.getAsRepLabel());

			String[] tokens = po.getAsRepLabel().trim().split("    ");
			if (tokens!=null && tokens.length>0)
				return tokens[0];
			else 
				return "";
		}

		if (logger!=null)
			logger.debug("As rep Label : EMPTY");
		return "";
	}

	private static List<String> getAsRepValue(ParserOutput po) {
		List<String> values = new ArrayList<String>();
		Pattern pattern = Pattern.compile("[[[0-9]{1,3}[,]]+[0-9]{1,3}]{3,}"); //^?[0-9]{1,3}[,]+[0-9]{1,3}(\\s+|\n|$)
		//Pattern pattern = Pattern.compile("^[(]?[[0-9][[、]]]+[)]?\\s | ^[(]?[[0-9][.]]+[)]?\\s|^[(]?[[0-9]\\s*[.]?]+[)]|^[\\d+-]+");

		String line  = po.getLine().replace(po.getAsRepLabel(), "");
		if(SectionSpreader.languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()))
		{
			String s ="";
			while(line.contains(","))
			{
				s = line.substring(0,line.indexOf(","));
				s = s.replaceAll("\\.",",");
				String s1 = line.substring(line.indexOf(",")+1); 
				line = s+"."+s1;
			}

			if(line.contains("."))
			{
				line = line.replaceAll("\\.",",");
			}
		}
		Matcher matcher = pattern.matcher(line.replace("[","").replace("]","").trim());

		while(matcher.find()) {
			values.add(matcher.group());

			if (logger!=null)
				logger.debug("As rep Value :"+matcher.group());
		}
		return values;	
	}

	public static void refineBreakupItems(TreeMap<String, ArrayList<ParserOutput>> mergedMap) {
		for (String section : mergedMap.keySet()) {

			if (logger!=null)
				logger.debug("Refining breakup items of section "+section+" ...");

			for (ParserOutput cc : mergedMap.get(section)) {

				if (cc.getBreakupItems()!=null && !cc.getBreakupItems().isEmpty()) {
					List<ParserOutput> breakups = new ArrayList<ParserOutput>();

					for (ParserOutput ccBreakup : cc.getBreakupItems()) {

						/*if (ccBreakup==null || ccBreakup.getLine() == null || (ccBreakup.getLine()!=null && ccBreakup.getLine().trim().replace("[", "").replace("]", "").isEmpty()))
							continue;*/
						if (ccBreakup!=null && ccBreakup.getMaxCol()>0 
								&&  ccBreakup.getAsRepLabel()!=null && 
								ccBreakup.getAsRepLabel().startsWith("TOTAL SUB-SECTION") 
								&& getAsRepValue(ccBreakup).isEmpty())
							continue;

						ccBreakup.setSubSection(cc.getSubSection());
						breakups.add(ccBreakup);
					}
					cc.setBreakupItems(breakups);
				}
			}
		}
	}

	private ParserOutput getContentCategory(int pageNo, int lineNo) {
		if (contentCategorizer != null && contentCategorizer.getDocument().get(pageNo)!=null) {
			List<ParserOutput> documentPage = contentCategorizer.getDocument().get(pageNo);

			for (ParserOutput po : documentPage) {

				if (po.getLineNo() == lineNo) {

					if (logger!=null)
						if (logger!=null)
							logger.debug("Content Category on page "+pageNo+" line no."+lineNo+" is "+po.toString());

					return po;
				}
			}
		}
		if (logger!=null)
			logger.debug("Content Category on page "+pageNo+" line no."+lineNo+" not found.");
		return null;
	}

	private List<String> evaluateBreakupStartLocation(List<String> searchResults, ParserOutput po, int threshold, int evaluateLines) {
		if (logger!=null)
			logger.debug("Evaluating breakup start locations  ...");

		List<String> evaluatedList = new ArrayList<String>();
		Map<ParserOutput, List<List<ParserOutput>>> breakupMap = new HashMap<ParserOutput, List<List<ParserOutput>>>();
		breakupMap.put(po, new ArrayList<List<ParserOutput>>());

		for (String location : searchResults) {
			String[] tokens = location.split("\\|");

			if ((po.getPageNo() > Integer.parseInt(tokens[0]) ||(FinancialStatementExtractor.getEndPg()!=-1 && (Integer.parseInt(tokens[0]) < FinancialStatementExtractor.getEndPg())))/* && ((po.getAsRepVal1()!=null || (po.getAsRepVal1()!=null) && !po.getAsRepVal1().equals("")) || (po.getAsRepVal2()!=null &&!po.getAsRepVal2().equals("")))*/)
				continue;

			/*if (isOutOfBounds(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]))) {*/

			ParserOutput cc = getContentCategory(((Integer.parseInt(tokens[0]))), Integer.parseInt(tokens[1]));

			if(isChunkNumber(cc.getPdfLine()))
			{
				if (logger!=null)
					logger.debug("The start of breakup is not valid...");
				continue;
			}

			if (!cc.equals(po) && (((cleanLabel(cc.getLine().replace("[", "").replace("[", "").toLowerCase()).indexOf(cleanLabel(po))!=-1)||(cleanLabel(po).toLowerCase().indexOf(cleanLabel(cc.getLine().replace("[", "").replace("[", "").toLowerCase()))!=-1)))) {
				int count = 0;
				List<ParserOutput> page = contentCategorizer.getDocument().get(cc.getPageNo());

				for (int lineNo = cc.getLineNo(); lineNo < cc.getLineNo() + evaluateLines; lineNo ++) {

					if (page.size() > lineNo) {
						ParserOutput ccNext = page.get(lineNo);

						if (ccNext!=null && ccNext.getType().equals("TABLE"))
							count++;

						if (count >= threshold) {
							evaluatedList.add(location);
							if (logger!=null)
								logger.debug("Breakup of item \""+po.getAsRepLabel()+"\" start location is valid ...");
							break;
						}
					}
				}
			}
			/*}*/
		}
		return evaluatedList;
	}

	private List<String> evaluateBreakupEndLocation(List<String> searchResults, ParserOutput po) {
		if (logger!=null)
			logger.debug("Evaluating breakup end locations  ...");

		List<String> evaluatedList = new ArrayList<String>();

		for (String location : searchResults) {
			String[] tokens = location.split("\\|");

			/*if (po.getPageNo() == Integer.parseInt(tokens[0]))
				continue;*/

			if ((po.getPageNo() == Integer.parseInt(tokens[0]) ||(FinancialStatementExtractor.getEndPg()!=-1 && Integer.parseInt(tokens[0]) < FinancialStatementExtractor.getEndPg())))/* && ((po.getAsRepVal1()!=null || (po.getAsRepVal1()!=null) && !po.getAsRepVal1().equals("")) || (po.getAsRepVal2()!=null &&!po.getAsRepVal2().equals("")))*/
				continue;


			//	if (isOutOfBounds(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]))) {

			ParserOutput cc = getContentCategory(Integer.parseInt(tokens[0]), Integer.parseInt(tokens[1]));

			if (!cc.equals(po)) {
				evaluatedList.add(location);
				if (logger!=null)
					logger.debug("Breakup of item \""+po.getAsRepLabel()+"\" end location is valid ...");
			}
			//}
		}
		return evaluatedList;
	}

	private Set<ParserOutput> removeOverlappedBreakupItems(List<ParserOutput> contentCategories, String section) {

		Set<String> sections = new TreeSet<String>();
		for (ParserOutput contentCategory : contentCategories) {
			if (contentCategory.getSection()!=null)
				sections.add(contentCategory.getSection());
		}
		if (logger!=null && sections.size()>0)
			logger.debug("Removing overlapped breakup items ...");

		for (String keySection : sections) {
			for (ParserOutput contentCategory :sectionMap.get(keySection)) {
				List<ParserOutput> overlapCC = new ArrayList<ParserOutput>();
				if (contentCategory.getBreakupItems()!=null) {
					for (ParserOutput cc : contentCategory.getBreakupItems()) {
						if (contentCategories.contains(cc)) {
							int index = contentCategories.indexOf(cc);
							ParserOutput breakupItem = contentCategories.get(index);
							breakupItem.setSection(section);
							overlapCC.add(breakupItem);
						}
					}
				}
				if (overlapCC.size()>0) {
					contentCategory.getBreakupItems().removeAll(overlapCC);
					if (logger!=null)
						logger.debug("Overlapping information removed ...");
				}
			}
		}
		return new TreeSet<ParserOutput>(contentCategories);
	}

	private List<ParserOutput> getBreakupTable(List<String> startLocation, List<String> endLocation, String section) {
		if (logger!=null)
			logger.debug("Extracting breakup table ...");
		Map<Integer,List<Integer>> mp = new LinkedHashMap<Integer,List<Integer>>();
		Set<ParserOutput> table = new TreeSet<ParserOutput>();
		List<ParserOutput> overlap = new ArrayList<ParserOutput>();
		for (String start : startLocation) {
			String[] startPosition = start.split("\\|");
			for (String end : endLocation) {
				String[] endPosition = end.split("\\|");
				int startPgNo = Integer.parseInt(startPosition[0]);
				int endPgNo = Integer.parseInt(endPosition[0]);
				int startLineNo = Integer.parseInt(startPosition[1]);
				int endLineNo = Integer.parseInt(endPosition[1]);
				if(startPgNo==endPgNo && startLineNo<endLineNo)
				{
					if(!mp.containsKey(startPgNo))
					{
						List<Integer> lst = new LinkedList<Integer>();
						lst.add(startLineNo);
						mp.put(startPgNo, lst);
					}
					else
					{
						List<Integer> lst = mp.get(startPgNo);
						lst.add(startLineNo);

					}

				}
			}
		}

		for (String start : startLocation) {
			String[] startPosition = start.split("\\|");
			for (String end : endLocation) {
				String[] endPosition = end.split("\\|");
				int startLineNo = Integer.parseInt(startPosition[1]);
				int endLineNo = Integer.parseInt(endPosition[1]);
				int startPgNo = Integer.parseInt(startPosition[0]);
				int endPgNo = Integer.parseInt(endPosition[0]);
				if(startPgNo==endPgNo )
				{
					try {
						List<Integer> list = mp.get(startPgNo);
						if(list.size()>1)
							Collections.sort(list);
						if(!list.get(0).equals(startLineNo))
						{
							continue;
						}
					} catch (Exception e) {
						// TODO Auto-generated catch block
						//e.printStackTrace();
					}
				}
				if (startPosition[0].equals(endPosition[0]) && startLineNo < endLineNo) {
					List<ParserOutput> pageContent = contentCategorizer.getDocument().get(Integer.parseInt(startPosition[0]));
					int ct=0;
					for (ParserOutput cc : pageContent) {

						if (cc.getLineNo( )>= startLineNo && cc.getLineNo() <= endLineNo) 
						{
							/*if (cc.getSection()!=null && !cc.getSection().isEmpty() && !cc.getSection().equals(section)) {
								overlap.add(cc);
								if (logger!=null)
									logger.debug("Information overlap found ["+section+" : "+cc.getSection()+"]    "+cc.toString());
								continue;
							}*/

							//to check correct table
							ct = ct+1;


							if(ct==1 && ((cc.getPdfLine()!=null && cc.getLine()!=null && !cc.getLine().trim().equalsIgnoreCase("") && (/*(cc.getLine().replaceAll("[0-9]","").length()<cc.getLine().length()) ||*/ isChunkNumber(cc.getPdfLine())) )
									|| (cc.getLine()!=null && (cc.getLine().toLowerCase().contains("total")  || cc.getLine().toLowerCase().contains("net"))))
									&& ( cc.getIsHeading()==null ||(cc.getIsHeading()!=null && !cc.getIsHeading().equalsIgnoreCase("Y"))))
							{
								if (logger!=null)
									logger.debug("The start of breakup is not valid...");
								break;
							}
							else
							{
								if(ct==1)
									continue;
							}


							//to check correct table

							cc.setSection(section);
							if (cc.getType().equals("TABLE"))
								table.add(cc);

							if (logger!=null)
								logger.debug(cc.toString());
						} else if (cc.getLineNo() > endLineNo)
							break;
					}
				}
			}
		}
		List<ParserOutput> finalBreakupItems = new ArrayList<ParserOutput>(table);
		if (overlap.size()>0) {
			for (ParserOutput contentCategory : new ArrayList<ParserOutput>(removeOverlappedBreakupItems(overlap, section))) {
				if (contentCategory.getSection().equals(section))
					finalBreakupItems.add(contentCategory);
			}
		}
		Collections.sort(finalBreakupItems);
		return finalBreakupItems;
	}

	private boolean isChunkNumber(PDFLine pdfLine) {
		List<PDFChunk> PDFChunk = pdfLine.getChunks();
		for(PDFChunk chunk:PDFChunk)
		{

			if(chunk!=null && !chunk.getChunk().trim().equals(""))
			{
				String chunkString = chunk.getChunk().trim();
				if(SectionSpreader.isNumber(chunkString))
				{

					if((!chunk.getChunk().contains(",") && !chunk.getChunk().contains(".")) && chunk.getChunk().trim().length()==4)
					{
						return false;
					}
					return true;
				}
			}
		}

		return false;
	}

	private boolean evaluate(ParserOutput po, String breakupLabel) {
		if (logger!=null)
			logger.debug("Evaluating breakup item "+po.toString()+"...");
		String text = "";
		if(po.getLine()!=null)
		{
			text = po.getLine().replace("[", "").replace("]", "");
		}

		if (!text.trim().isEmpty()) {
			if (text.replaceAll("[^a-z A-Z\\-]", "").trim().equalsIgnoreCase(breakupLabel.trim()))
				return false;

			boolean key=false, value=false;
			String[] tokens = text.split("    ");
			Pattern amount = Pattern.compile("[[\\d+]{1,3}[,.]{1}]+");
			//	Pattern year = Pattern.compile("[\\d+]{4}");
			Matcher matcher = null;
			//int labelStartsAt = -1;
			for (String token : tokens) {

				/*if (!key)
					labelStartsAt++;*/

				if (token.trim().isEmpty())
					continue;

				//	matcher = year.matcher(token.trim());
				//	if (matcher.find())
				//		return false;

				matcher = amount.matcher(token.trim());
				if (matcher.find()) {
					if (!matcher.group().trim().equals(",") && !matcher.group().trim().equals("."))
						value = true;
				}

				if (token.replaceAll("[^a-zA-Z]", "").length()>0 && !(token.trim().length()==1) && !token.trim().startsWith("NOTE ") &&  !(token.trim().length()==1) && !token.trim().contains(" follows "))
					key=true;

				if (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equals("TOTAL SUB-SECTION"))
					key=true;

				if (key && (value || !value))
					return true;
			}
		}
		return false;
	}

	private List<ParserOutput> cleanBreakups(List<ParserOutput> breakupList, String breakupLabel) {
		if (logger!=null)
			logger.debug("Cleaning breakup item ...");


		List<ParserOutput> list = new ArrayList<ParserOutput>();

		for (ParserOutput cc : breakupList) {

			if (cc.getType().equals("SEPARATOR"))
				continue;

			if (evaluate(cc, breakupLabel)) {
				list.add(cc);
			}
		}
		return list;
	}

	private List<String> findStartLocation(ParserOutput contentCategory, List<String> endPosition) {

		if (logger!=null)
			logger.debug("Locating start position of breakup ...");

		List<String> evaluatedList = new ArrayList<String>();
		String label = getAsRepLabel(contentCategory);

		for (String location : endPosition) {
			String[] tokens = location.split("\\|");

			int pageNo = Integer.parseInt(tokens[0]);
			int endLineNo = Integer.parseInt(tokens[1]);

			for (int lineNo = endLineNo; lineNo >= 0; lineNo--) {

				ParserOutput cc = getContentCategory(pageNo, lineNo);

				if (cc.getType().equals("SEPARATOR"))
					continue;

				String ccLabel = getAsRepLabel(cc);


				if (!ccLabel.trim().isEmpty()) {
					float match = new JaccordSimilarity().jaccardSimilarity(label.trim(), ccLabel.trim());
					if (logger!=null)
						logger.debug(label.trim()+" == "+ccLabel.trim()+" match :"+match);

					if (match > 0.9 && isOutOfBounds(pageNo, lineNo))
						evaluatedList.add(""+String.valueOf(pageNo)+"|"+String.valueOf(lineNo));
				}
			}
		}

		return evaluatedList;
	}

	public void findBreakups(String ISBreakups, String BSBreakups, ParserOutput remainingNodesAssociation) {
		try {
			if (logger!=null)
				logger.debug("Finding breakups ...");

			contentCategorizer.getIndexer().openSearcher(contentCategorizer.getIndexer().getMemory());
			//Set<String> breakupsKeywords = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/breakupLabels.txt");
			ParserOutput thisYearRow=null;
			for (String section : sectionMap.keySet()) {

				if ((section.equalsIgnoreCase("IS") && ISBreakups.equalsIgnoreCase("Yes")) 
						|| (section.equalsIgnoreCase("BS") && BSBreakups.equalsIgnoreCase("Yes"))) 
				{
					for (ParserOutput po : sectionMap.get(section)) {

						if(po.getAsRepLabel().equalsIgnoreCase("STATEMENT YEAR"))
							thisYearRow=po;

						if (po.getMaxCol()>0 && po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT") && ((po.getIsHeading()!=null && !po.getIsHeading().equalsIgnoreCase("Y")|| (po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("N")) || po.getIsHeading()==null))) {

							if((po.getAsRepLabel()!=null && !po.getAsRepLabel().equalsIgnoreCase("")) && (po.getAsRepVal1()==null || (po.getAsRepVal1()!=null && po.getAsRepVal1().equals("")) ) && (po.getAsRepVal2()==null || (po.getAsRepVal2()!=null && po.getAsRepVal2().equals(""))) 
									&& (po.getAsRepVal3()==null || (po.getAsRepVal3()!=null && po.getAsRepVal3().equals(""))) && (po.getAsRepVal4()==null || (po.getAsRepVal4()!=null && po.getAsRepVal4().equals("")))
									&& (po.getAsRepVal5()==null || (po.getAsRepVal5()!=null && po.getAsRepVal5().equals(""))) &&  (po.getAsRepVal6()==null || (po.getAsRepVal6()!=null && po.getAsRepVal6().equals("")))
									&&  (po.getAsRepVal7()==null || (po.getAsRepVal7()!=null && po.getAsRepVal7().equals(""))) && (po.getAsRepVal8()==null || (po.getAsRepVal8()!=null && po.getAsRepVal8().equals("")))
									&& (po.getAsRepVal9()==null || (po.getAsRepVal9()!=null && po.getAsRepVal9().equals(""))) && (po.getAsRepVal10()==null || (po.getAsRepVal10()!=null && po.getAsRepVal10().equals("")))
									&& (po.getAsRepVal11()==null || (po.getAsRepVal11()!=null && po.getAsRepVal11().equals("")) ) && (po.getAsRepVal12()==null || (po.getAsRepVal12()!=null && po.getAsRepVal12().equals(""))) 
									&& (po.getAsRepVal13()==null || (po.getAsRepVal13()!=null && po.getAsRepVal13().equals(""))) && (po.getAsRepVal14()==null || (po.getAsRepVal14()!=null && po.getAsRepVal14().equals(""))
									&& (po.getAsRepVal15()==null || (po.getAsRepVal15()!=null && po.getAsRepVal15().equals(""))) &&  (po.getAsRepVal16()==null || (po.getAsRepVal16()!=null && po.getAsRepVal16().equals("")))
									&&  (po.getAsRepVal17()==null || (po.getAsRepVal17()!=null && po.getAsRepVal17().equals(""))) && (po.getAsRepVal18()==null || (po.getAsRepVal18()!=null && po.getAsRepVal18().equals("")))
									&& (po.getAsRepVal19()==null || (po.getAsRepVal19()!=null && po.getAsRepVal19().equals(""))) && (po.getAsRepVal20()==null || (po.getAsRepVal20()!=null && po.getAsRepVal20().equals("")))
											))

							{
								continue;
							}
							/*if(!breakupsKeywords.contains(po.getAsRepLabel().trim().toLowerCase()))
							{
								continue;
							}*/
							removesupllData(po);
							List<String> start = breakupValidStart(po);
							if (start!=null && start.size()>0) {

								List<String> end = breakupValidEnd(po);
								logger.debug(po.toString()+"\n"+start+" \n "+end);

								if ((start==null || start.isEmpty()) && end!=null && !end.isEmpty())
									start = findStartLocation(po, end);

								if (start!=null && end!=null && !start.equals(end)) {

									if (logger!=null)
										logger.debug("Breakup for item \""+po.getAsRepLabel().trim().trim()+"\" found.");

									List<ParserOutput> table = getBreakupTable(start, end, section);
									/*	int ct=0;

									for(ParserOutput pol:table)
									{

										ct = ct+1;


										if(ct==1 && ((pol.getLine()!=null && (pol.getLine().replaceAll("[0-9]","").length()<pol.getLine().length()))
												|| (pol.getLine()!=null && (pol.getLine().toLowerCase().contains("total")  || pol.getLine().toLowerCase().contains("net"))))
												&& ( pol.getIsHeading()==null ||(pol.getIsHeading()!=null && !pol.getIsHeading().equalsIgnoreCase("Y"))))
										{
											break;
										}

									}
									if(ct==1)
										continue;*/
									if (table!=null && !table.isEmpty() /*&& table.size()<20*/) {

										boolean partOfSection = isPartOfSection(table,sectionMap);
										if(!partOfSection)
										{

											List<ParserOutput> breakupList = cleanBreakups(table, cleanLabel(po));
											breakupList = segmentColumns(breakupList, section,po.getTableID());

											removeExistingBreakups(breakupList,remainingNodesAssociation,po);
											removeRemainingAssociation(remainingNodesAssociation,breakupList);
											removeExistingMatchedBreakups(breakupList,po);
											//removeExistingSUPPLBreakups(breakupList,po);

											List<ParserOutput> mergedBreakUp = mergingAttributes(po,thisYearRow,breakupList,"Implicit","Table",true);


											if(mergedBreakUp!=null && mergedBreakUp.size()>0)
											{
												for(ParserOutput po1:mergedBreakUp)
												{
													po1.setBreakups("Y");
												}

												po.getBreakupItems().addAll(mergedBreakUp);
												po.getMatchingBreakUpItem().add(mergedBreakUp);
											}




											/*}*/
											////////////////

											if (logger!=null)
												logger.debug("Breakup for item \""+po.getAsRepLabel().trim()+"\" extracted.");
										}
										else
											if (logger!=null)
												logger.debug("Breakup for item \""+po.getAsRepLabel().trim()+"\" not found.");
									}
								}
							} else {

								if (logger!=null)
									logger.debug("Breakup for item \""+po.getAsRepLabel().trim()+"\" not found.");
							}
						}
					}
				}
			}
			contentCategorizer.getIndexer().closeSearcher();

		} catch (Exception e) {
			logger.error(e);
			e.printStackTrace();
		}
	}



	private static Boolean removesupllData(List<ParserOutput> breakupList,ParserOutput po) {
		//Removing suppl from section suppl

		for(ParserOutput poBreakupCurrent:breakupList)
		{
			if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
			{
				List<List<ParserOutput>> suppList = po.getSupplementaryBreakUpItem();
				for(List<ParserOutput> sList :suppList)
				{
					Boolean found = false;
					for(ParserOutput suupBrakup:sList)
					{
						if(suupBrakup.getPdfLine()!=null && poBreakupCurrent.getPdfLine()!=null && suupBrakup.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && suupBrakup.getPageNo()==poBreakupCurrent.getPageNo()  && suupBrakup.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
						{
							System.out.println("Removed the Item from section suppl"+sList.toString());
							found = true;
							break;
						}
					}
					if(found)
					{
						suppList.remove(sList);
						return	true;					
					}
				}
			}
		}

		return false;
	}

	private static Boolean removesupllData(ParserOutput po) {
		//Removing suppl from section suppl

		if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
		{
			List<List<ParserOutput>> suppList = po.getSupplementaryBreakUpItem();
			for(List<ParserOutput> sList :suppList)
			{
				Boolean found = false;
				for(ParserOutput suupBrakup:sList)
				{
					if(suupBrakup!=null && FinancialStatementExtractor.getEndPg()>0 && suupBrakup.getPageNo()>FinancialStatementExtractor.getEndPg()	)
					{
						System.out.println("Removed the Item from section suppl"+sList.toString());
						found = true;
						break;
					}
				}
				if(found)
				{
					suppList.remove(sList);
				}
			}
		}


		return false;
	}

	private Boolean removeRemainingAssociation(
			ParserOutput remainingNodesAssociation,
			List<ParserOutput> breakupList) {
		//Removing suppl from remaining associtions
		for(ParserOutput poBreakupCurrent:breakupList)
		{
			if(remainingNodesAssociation!=null && remainingNodesAssociation.getSupplementaryBreakUpItem()!=null && remainingNodesAssociation.getSupplementaryBreakUpItem().size()>0)
			{
				List<List<ParserOutput>> suppList = remainingNodesAssociation.getSupplementaryBreakUpItem();
				for(List<ParserOutput> sList :suppList)
				{
					Boolean found = false;
					for(ParserOutput suupBrakup:sList)
					{
						if(suupBrakup.getPdfLine()!=null && poBreakupCurrent.getPdfLine()!=null && suupBrakup.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && suupBrakup.getPageNo()==poBreakupCurrent.getPageNo()  && suupBrakup.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
						{
							System.out.println("Removed the Item from remainingNodesAssociation"+sList.toString());
							found = true;
							break;
						}

					}

					if(found)
					{
						suppList.remove(sList);
						return	true;					
					}

				}
			}

		}

		return false;
	}


	private Boolean removeExistingMatchedBreakups(
			List<ParserOutput> breakupList,
			ParserOutput remainingNodesAssociation) {
		//Removing suppl from remaining associtions
		for(ParserOutput poBreakupCurrent:breakupList)
		{
			if(remainingNodesAssociation!=null && remainingNodesAssociation.getMatchingBreakUpItem()!=null && remainingNodesAssociation.getMatchingBreakUpItem().size()>0)
			{
				List<List<ParserOutput>> suppList = remainingNodesAssociation.getMatchingBreakUpItem();
				for(List<ParserOutput> sList:suppList)
				{

					Boolean found = false;
					for(ParserOutput suupBrakup:sList)
					{
						if(suupBrakup.getPdfLine()!=null && poBreakupCurrent.getPdfLine()!=null && suupBrakup.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && suupBrakup.getPageNo()==poBreakupCurrent.getPageNo()  && suupBrakup.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
						{
							System.out.println("Removed the Item from remainingNodesAssociation"+suppList.toString());
							found = true;
							break;
						}

					}

					if(found)
					{
						suppList.remove(sList);
						return	true;					
					}
				}

			}


		}

		return false;
	}

	private Boolean removeExistingSUPPLBreakups(List<ParserOutput> breakupList, ParserOutput remainingNodesAssociation) {

		//Removing suppl from remaining associtions
		for(ParserOutput poBreakupCurrent:breakupList)
		{
			if(remainingNodesAssociation!=null && remainingNodesAssociation.getSupplementaryBreakUpItem()!=null && remainingNodesAssociation.getSupplementaryBreakUpItem().size()>0)
			{
				List<List<ParserOutput>> suppList = remainingNodesAssociation.getSupplementaryBreakUpItem();
				for(List<ParserOutput> sList:suppList)
				{

					Boolean found = false;
					for(ParserOutput suupBrakup:sList)
					{
						//if(poBreakupCurrent.getLine()!=null && suupBrakup.getLine()!=null && poBreakupCurrent.getPageNo()==suupBrakup.getPageNo()  && poBreakupCurrent.getLine().equals(suupBrakup.getLine()))
						if(suupBrakup.getPdfLine()!=null && poBreakupCurrent.getPdfLine()!=null && suupBrakup.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && suupBrakup.getPageNo()==poBreakupCurrent.getPageNo()  && suupBrakup.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
						{
							System.out.println("Removed the Item from remainingNodesAssociation"+suppList.toString());
							found = true;
							break;
						}

					}

					if(found)
					{
						suppList.remove(sList);
						return	true;					
					}
				}

			}


		}

		return false;

	}

	private void removeExistingBreakups(List<ParserOutput> breakupList, ParserOutput remainingNodesAssociation, ParserOutput po2) {
		for(String section:sectionMap.keySet())		
		{
			ArrayList<ParserOutput> poList = sectionMap.get(section);
			for(ParserOutput po :poList)
			{
				for(ParserOutput poBreakupExisting:po.getBreakupItems())
				{
					for(int i=0;i<breakupList.size();i++)
					{
						ParserOutput poBreakupCurrent = breakupList.get(i);

						if(poBreakupExisting.getPdfLine()!= null && poBreakupCurrent.getPdfLine()!=null &&  poBreakupExisting.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && poBreakupExisting.getPageNo()==poBreakupCurrent.getPageNo()  && poBreakupExisting.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
						{
							System.out.println("Removed the Existing breakups "+poBreakupExisting.getLine());

							breakupList.remove(i);
							break;
						}

					}
				}


			}
		}

		//Removing suppl from section suppl
		for(String section:sectionMap.keySet())		
		{
			ArrayList<ParserOutput> poList = sectionMap.get(section);
			for(ParserOutput po :poList)
			{

				if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
				{
					List<List<ParserOutput>> suppList = po.getSupplementaryBreakUpItem();
					for(List<ParserOutput> sList :suppList)
					{
						for(ParserOutput suupBrakup:sList)
						{
							for(ParserOutput poBreakupCurrent:breakupList)
							{
								if(suupBrakup.getPdfLine()!=null && poBreakupCurrent.getPdfLine()!=null && suupBrakup.getPdfLine().getLine()!=null && poBreakupCurrent.getPdfLine().getLine()!=null && suupBrakup.getPageNo()==poBreakupCurrent.getPageNo()  && suupBrakup.getPdfLine().getLine().equals(poBreakupCurrent.getPdfLine().getLine()))
								{
									System.out.println("Removed the Existing suppl breakups "+suupBrakup.getLine());
									breakupList.remove(poBreakupCurrent);
									break;
								}

							}

						}
					}

				}
			}
		}
	}

	public static List<ParserOutput> mergingAttributes(ParserOutput mainPO, ParserOutput yearRow,
			List<ParserOutput> breakupList, String mainBreakUpType,String breakUpType,boolean supplinfo) 
			{
		ParserOutput thisYearRow=null;
		ParserOutput thisAttributeRow=null;
		ParserOutput thisMonthRow=null;
		Map<Integer, Integer> thisAttrMap=null;
		ArrayList<ParserOutput> ret= new ArrayList<ParserOutput>();

		if(breakupList==null || breakupList.size()<1)
		{
			return null;
		}
		// Creating matching attribute map


		for(ParserOutput row:breakupList)
		{
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
			{
				thisYearRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
			{
				thisAttributeRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
			{
				thisMonthRow=row;
				continue;
			}
			if(breakUpType!=null && breakUpType.equalsIgnoreCase("TextBreakUp"))
			{
				thisYearRow=breakupList.get(0);
			}
			if(/*thisAttributeRow!=null && */thisYearRow!=null /*&& thisMonthRow!=null*/)
			{
				thisAttrMap=InnerSplit.getAttrYearMatchingValueMap(thisYearRow,yearRow,mainPO);
				break;
			}
		}

		boolean isSupplementary=false;
		if(thisAttrMap==null || thisAttrMap.size()<1)
			isSupplementary=true;

		for(Integer col:thisAttrMap.keySet())
		{
			if(thisAttrMap.get(col)==null)
			{
				isSupplementary=true;
				if (logger!=null)
				{
					logger.debug("Attributes not null");
					logger.debug("isSupplementary is true");
				}
			}
			else
			{
				if (logger!=null)
				{
					logger.debug("The start of breakup is not valid...");
					logger.debug("isSupplementary is true");
				}
			}
		}

		int maxCol = mainPO.getMaxCol();
		int thisBreakUpMaxCol=0;

		for(ParserOutput row:breakupList)
		{
			if(row.getMaxCol()>thisBreakUpMaxCol)
				thisBreakUpMaxCol=row.getMaxCol();
		}

		// Assigning the values to be merged from the matching map
		boolean isFirstFound = false;
		for(ParserOutput row:breakupList)
		{
			row.setBreakUpMainType(mainBreakUpType);
			row.setBreakUpType(breakUpType);
			/*if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
				continue ;
			else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
				continue;
			else*/
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT YEAR") )
			{
				continue;
			}
			else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
				continue;
			else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
				continue;
			/*else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
				continue;
			else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
				continue;*/

			/*String lineItemSectionStr=row.getAsRepLabel();
			if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			{
				if(!isFirstFound)
					continue;
			}
			isFirstFound=true;*/
			if(!isSupplementary)
			{
				Map<Integer,String> colValueMap=InnerSplit.getColumnValueMap(row,"val");
				Map<Integer,String> colAsRepValueMap=InnerSplit.getColumnValueMap(row,"as_rep");
				if(thisAttrMap!=null && thisAttrMap.size()>0)
				{
					InnerSplit.clearAllColumnValueMap(row);
					MapCols.setPOValueOnIndex(row, 0, colValueMap.get(0));
					for(Integer fromColNo:thisAttrMap.keySet())
					{
						Integer toColNo=thisAttrMap.get(fromColNo);
						String val=colValueMap.get(fromColNo);
						String asRepVal=colAsRepValueMap.get(fromColNo);
						MapCols.setPOValueOnIndex(row, toColNo, val);
						MapCols.setPOAsRepValueOnIndex(row, toColNo, asRepVal);
					}
				}
			}
			ret.add(row);
		}
		if(isSupplementary && thisBreakUpMaxCol>0 && supplinfo)
		{
			if(maxCol==thisBreakUpMaxCol)
			{
				if (logger!=null)
				{
					logger.debug("No of columns matching");
					logger.debug("isSupplementary is false now");
				}
				isSupplementary=false;
			}
			else
			{
				if (logger!=null)
				{
					logger.debug("No of columns not matching");
					logger.debug("isSupplementary is true now");
				}
			}
		}
		removesupllData(breakupList,mainPO);

		if(isSupplementary && ret!=null && ret.size()>0)
		{
			//Add to all_suppl
			mainPO.getSupplementaryBreakUpItem().add(ret);

			//check values of all columns to values in the suppl (ie total match) and map accordingly
			List<ParserOutput> poMatches = null;
			if(breakUpType.equalsIgnoreCase("Table"))
			{
				System.out.println("====Values Check starts for "+mainPO.getAsRepLabel());
				Map<Integer, Integer> columnsMatchMap = InnerSplit.getTotalColumnMatchMap(mainPO,ret);
				if(columnsMatchMap!=null)
				{
					poMatches =  InnerSplit.mapColumnsMatches(ret, mainBreakUpType, breakUpType, columnsMatchMap,
							isSupplementary,false,null);
				}
				System.out.println("====Values Check ends for "+mainPO.getAsRepLabel());

			}
			if(poMatches!=null && poMatches.size()>0 )
				return poMatches;
			else
				return null;

			/*
			mainPO.getSupplementaryBreakUpItem().add(ret);
			return null;
			 */}

		return ret;
			}


	private List<ParserOutput> segmentColumns(List<ParserOutput> secContent, String section,Integer InstanceId)  throws  ParserConfigurationException, SAXException, IOException,Exception 
	{
		if (logger!=null)
			logger.debug("Segmenting section columns ...");
		List<PDFLine> lines = new ArrayList<PDFLine>();
		List<PDFBlock> blocks = new ArrayList<PDFBlock>();
		for(int i=0;i<secContent.size();i++)
		{
			lines.add(secContent.get(i).getPdfLine());
		}
		if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("Yes"))
		{
			InstanceId = 1;
		}
		Section temp= new Section(section.toUpperCase(),lines,null,0,blocks) ;
		//secContent = SectionSpreader.spreadBreakUpData(section, lines,secContent,InstanceId);
		secContent = SectionSpreader.spreadPageData(temp);
		return secContent;

	}
	private boolean isPartOfSection(List<ParserOutput> brkUpTable,
			Map<String, ArrayList<ParserOutput>> sectionMap) {
		int ct=0;
		ArrayList<ParserOutput> filterTable = new ArrayList<ParserOutput>();
		for(String section:sectionMap.keySet())
		{

			if(section.trim().equalsIgnoreCase("SUPPL") || section.trim().equalsIgnoreCase("znotes"))
				continue;
			ArrayList<ParserOutput> poList  = sectionMap.get(section);
			ct=0;
			for(ParserOutput po:poList)
			{
				if(po.getAsRepLabel()==null || (po.getAsRepLabel()!=null && po.getAsRepLabel().startsWith("STATEMENT")))
					continue;
				ct++;

				for(ParserOutput brkUppo:brkUpTable)
				{
					if(po.getLine()!=null && brkUppo.getLine()!=null && po.getPageNo()==brkUppo.getPageNo()  && po.getLine().replaceFirst("\\[", "").replaceFirst("\\]","").equals(brkUppo.getLine()))
					{
						return true;
					}
					if(po.getBreakupItems()!=null && po.getBreakupItems().size()>0)
					{
						for(ParserOutput brkUp:po.getBreakupItems())
						{
							if(po.getLine()!=null && brkUp.getLine()!=null && po.getPageNo()==brkUp.getPageNo()  && po.getLine().replaceFirst("\\[", "").replaceFirst("\\]","").equals(brkUp.getLine().replaceFirst("\\[", "").replaceFirst("\\]","")))
							{
								return true;
								//po.getBreakupItems().remove(brkUp);
							}


						}
					}
				}
			}
		}
		return false;
	}

	private String cleanLabel(ParserOutput po)
	{
		if (logger!=null)
			logger.debug("Cleaning label ..."+po.getAsRepLabel());

		String label=po.getAsRepLabel();
		if(TimePeriodOntology.getNotesList()!=null)
		{
			for(String keyword:TimePeriodOntology.getNotesList())
			{
				label=label.toLowerCase().replaceAll("\\("+keyword.trim().toLowerCase()+"(.*?)"+"\\)", "");
				label=label.toLowerCase().replaceAll("\\["+keyword.trim().toLowerCase()+"(.*?)"+"\\]", "").trim();
				label=label.toLowerCase().replaceAll(keyword.trim().toLowerCase(), "").trim();
			}
			//label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
			//label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
			//	label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();
		}
		label=label.replaceAll("[^a-z, A/\\-\\)\\(]", "");
		label=label.replaceAll("\\s\\s+", " ");
		//	CleanEnumeratedText cet = new CleanEnumeratedText();
		//	label = cet.replaceEnums(label);
		//	label = SectionBoundaryDetector.ignoreBrucketData(label);

		if (label.toLowerCase().indexOf("net")!=-1) {

			int index = label.toLowerCase().indexOf(", net");

			if (index!=-1)
				label = label.substring(0, index);
			else {

				index = label.toLowerCase().indexOf("net ");

				if(index==-1)
				{
					index = label.toLowerCase().indexOf("net");
				}

				if (index>0) {
					label = label.substring(0, index).replaceAll(",", "");
					index = label.lastIndexOf(",");

					if (index!=-1)
						label = label.substring(0, index);
					else
					{
						index = label.lastIndexOf("-");
						if(index!=-1)
							label = label.substring(0, index);

					}


				}
			}


			index = label.toLowerCase().indexOf("- net");

			if (index!=-1)
				label = label.substring(0, index);
			else {

				index = label.toLowerCase().indexOf("net ");
				if(index==-1)
				{
					index = label.toLowerCase().indexOf("net");
				}

				if (index>0) {
					label = label.substring(0, index).replaceAll("-", "");
					index = label.lastIndexOf("-");

					if(index!=-1)
						label = label.substring(0, index);
				}

			}
		}
		else
			if (label.toLowerCase().indexOf("less")!=-1) {

				int index = label.toLowerCase().indexOf(", less");

				if (index>0) {
					label = label.substring(0, index);
				}
				else {

					index = label.toLowerCase().indexOf("less ");
					if (index==-1)
					{
						index = label.toLowerCase().indexOf("less");
					}
					if (index>0) {
						label = label.substring(0, index).replaceAll(",", "");
						index = label.lastIndexOf(",");

						if (index!=-1)
							label = label.substring(0, index);
						else
							index = label.lastIndexOf("-");
						if(index!=-1)
							label = label.substring(0, index);
					}



					index = label.toLowerCase().indexOf("- less");

					if (index!=-1)
						label = label.substring(0, index);
					else {

						index = label.toLowerCase().indexOf("less ");
						if(index==-1)
						{
							index = label.toLowerCase().indexOf("less");
						}

						if (index>0) {
							label = label.substring(0, index).replaceAll("-", "");
							index = label.lastIndexOf("-");

							if(index!=-1)
								label = label.substring(0, index);
						}

					}
				}
			}
			else
			{
				if (label.toLowerCase().indexOf("(including")!=-1) {

					int index = label.toLowerCase().indexOf("(including");
					if (index!=-1) {
						label = label.substring(0, index);
					}


				}
			}

		if(label.trim().endsWith("-"))
		{
			label = label.trim().substring(0, label.trim().lastIndexOf("-")).trim();
		}
		if(label.trim().contains("-"))
		{
			label = label.trim().substring(0, label.trim().indexOf("-")).trim();
		}
		if (logger!=null)
			logger.debug("After cleaning label ..."+label);

		return label;



	}

	private String cleanLabel(String label)
	{



		if (logger!=null)
			logger.debug("Cleaning label ..."+label);

		if(TimePeriodOntology.getNotesList()!=null)
		{
			for(String keyword:TimePeriodOntology.getNotesList())
			{
				label=label.toLowerCase().replaceAll("\\("+keyword.trim().toLowerCase()+"(.*?)"+"\\)", "");
				label=label.toLowerCase().replaceAll("\\["+keyword.trim().toLowerCase()+"(.*?)"+"\\]", "").trim();
				label=label.toLowerCase().replaceAll(keyword.trim().toLowerCase(), "").trim();

			}
			//label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
			//label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
			//	label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();
		}
		label=label.replaceAll("[^a-z, A/\\-\\)\\(]", "");
		label=label.replaceAll("\\s\\s+", " ");
		/*CleanEnumeratedText cet = new CleanEnumeratedText();
		label = cet.replaceEnums(label);*/
		label=label.replaceAll("\\s\\s+", " ");
		if (label.toLowerCase().indexOf("net")!=-1) {

			int index = label.toLowerCase().indexOf(", net");

			if (index!=-1)
				label = label.substring(0, index);
			else {

				index = label.toLowerCase().indexOf("net ");

				if(index==-1)
				{
					index = label.toLowerCase().indexOf("net");
				}

				if (index>0) {
					label = label.substring(0, index).replaceAll(",", "");
					index = label.lastIndexOf(",");

					if (index!=-1)
						label = label.substring(0, index);
					else
					{
						index = label.lastIndexOf("-");
						if(index!=-1)
							label = label.substring(0, index);

					}


				}
			}


			index = label.toLowerCase().indexOf("- net");

			if (index!=-1)
				label = label.substring(0, index);
			else {

				index = label.toLowerCase().indexOf("net ");
				if(index==-1)
				{
					index = label.toLowerCase().indexOf("net");
				}

				if (index>0) {
					label = label.substring(0, index).replaceAll("-", "");
					index = label.lastIndexOf("-");

					if(index!=-1)
						label = label.substring(0, index);
				}

			}
		}
		else
			if (label.toLowerCase().indexOf("less")!=-1) {

				int index = label.toLowerCase().indexOf(", less");

				if (index>0) {
					label = label.substring(0, index);
				}
				else {

					index = label.toLowerCase().indexOf("less ");
					if (index==-1)
					{
						index = label.toLowerCase().indexOf("less");
					}
					if (index>0) {
						label = label.substring(0, index).replaceAll(",", "");
						index = label.lastIndexOf(",");

						if (index!=-1)
							label = label.substring(0, index);
						else
							index = label.lastIndexOf("-");
						if(index!=-1)
							label = label.substring(0, index);
					}



					index = label.toLowerCase().indexOf("- less");

					if (index!=-1)
						label = label.substring(0, index);
					else {

						index = label.toLowerCase().indexOf("less ");
						if(index==-1)
						{
							index = label.toLowerCase().indexOf("less");
						}

						if (index>0) {
							label = label.substring(0, index).replaceAll("-", "");
							index = label.lastIndexOf("-");

							if(index!=-1)
								label = label.substring(0, index);
						}

					}
				}
			}
			else
			{
				if (label.toLowerCase().indexOf("(including")!=-1) {

					int index = label.toLowerCase().indexOf("(including");
					if (index!=-1) {
						label = label.substring(0, index);
					}


				}
			}

		if(label.trim().endsWith("-"))
		{
			label = label.trim().substring(0, label.trim().lastIndexOf("-")).trim();
		}
		if (logger!=null)
			logger.debug("After cleaning label ..."+label);

		return label;

	}

	// labels appears around tabular information at the start
	private List<String> breakupValidStart(ParserOutput po) {
		if (logger!=null)
			logger.debug("Valid breakup item start location ...");

		List<String> breakupStart = null;
		try {
			if((po.getAsRepLabel().toLowerCase().contains("total")  || po.getAsRepLabel().toLowerCase().contains("net")) && (po.getIsHeading()!=null && !po.getIsHeading().equalsIgnoreCase("Y")))
				return breakupStart;
			if (po!=null && po.getMaxCol()>0 && po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT "))  {

				if (logger!=null)
					logger.debug("\nSearching ... "+po.getAsRepLabel().trim()+"\t"+po.toString());
				String cleanLabel = cleanLabel(po).trim();
				if (!(cleanLabel.isEmpty())){
					breakupStart = contentCategorizer.getIndexer().search("\""+cleanLabel,"englishContent", Type.ID);

					//breakupStart = contentCategorizer.getIndexer().search("\""+cleanLabel+"\"", "englishContent", Type.ID);

					if (logger!=null)
						logger.debug("Total Start found "+breakupStart.size()+ " valid entries :");

					breakupStart=evaluateBreakupStartLocation(breakupStart, po, 2, 12);

					if (logger!=null)
						logger.debug(breakupStart.size()+" ..."+breakupStart+"\n");
				}
			}
		} catch (Exception e) {
			logger.error(e);
			System.out.println(" Error -----------"+ e.getMessage());
			//	System.out.println(" Label -----------"+ po.getAsRepLabel());

		}
		return breakupStart;
	}

	// label appears with TOTAL prefix at the end of tabular information or values without label which matches in the statement reported
	private List<String> breakupValidEnd(ParserOutput po) {
		if (logger!=null)
			logger.debug("Valid breakup item end location ...");

		List<String> breakupEnd = null;
		try {
			if (po.getMaxCol()>0 &&  po.getAsRepLabel()!=null && !po.getAsRepLabel().trim().startsWith("STATEMENT ")) {
				List<String> value = getAsRepValue(po);


				if (value!=null && value.size() > 0) {

					if (logger!=null)
						logger.debug("\nSearching ... "+value.get(0)+"\t"+po.toString());
					//breakupEnd = contentCategorizer.getIndexer().search("\""+value.get(0).trim()+"\"", "englishContent", Type.ID);
					for(int i=0;i<value.size();i++)
					{
						String valueString = value.get(i);
						if(valueString!=null && !valueString.equalsIgnoreCase(""))
						{
							breakupEnd = contentCategorizer.getIndexer().search("\""+valueString.trim().replaceAll("[-$)(]", "")+"\"", "englishContent", Type.ID);
							if(breakupEnd!=null && breakupEnd.size()>0)
							{
								breakupEnd=evaluateBreakupEndLocation(breakupEnd, po);
								break;
							}
						}

					}
					/*breakupEnd = contentCategorizer.getIndexer().search("\""+value.get(0).trim().replaceAll("[-($)]", "")+"\"", "englishContent", Type.ID);
					breakupEnd=evaluateBreakupEndLocation(breakupEnd, po);*/

					if (logger!=null)
						logger.debug(breakupEnd.size()+" ..."+breakupEnd+"\n");
				}
			}
		} catch (Exception e) {
			logger.error(e);
		}
		return breakupEnd;
	}

	public Map<String, ArrayList<ParserOutput>> getSectionMap() {
		return sectionMap;
	}


	public List<String> getSectionBounds() {
		return sectionBounds;
	}



}
