package com.rage.extraction.statements.train.commands;

import com.rage.extraction.statements.mapping.IndustryMapReader;
import com.rage.extraction.statements.mapping.MapReader;


public class Train {

	
	public static void main(String[] args) throws Exception {
		long startTime=System.currentTimeMillis();
		String industry=null, documentName=null,language = null;
		long endTime;
		// Industry type
		if (args.length>0)
			industry = args[0];
		// document name
		if (args.length>1)
			documentName = args[1];
		
		if (args.length>2)
			language = args[2];
		
		if(language.trim().equalsIgnoreCase("English"))
		{
			language="";
		}
		if (args.length<3)
		{
			System.err.println("Usage: com.rage.extraction.statements.mapping.IndustryMapReader <Industry Type> <Document Name>");
			System.exit(1);
		}
		System.out.println(industry+" "+documentName);
		MapReader st=new IndustryMapReader(industry, language);
		// train
		st.train(documentName);

		endTime = System.currentTimeMillis();
		System.out.println("\nTotal time taken: "+((endTime-startTime)/1000.)+" seconds.");

	}
}
