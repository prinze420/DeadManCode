package com.rage.extraction.statements.constant;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.security.AbstractSecureKey;
import com.rage.extraction.statements.security.SecureKeyFactory;




public final class DBConnection {
	private static String _JDBC_DRIVER;
	private static String _DATABASE_SOURCE_URL;
	private static String _DATABASE_USER;
	private static String _DATABASE_PASSWORD;
	private static DBConnection instance;
	private ArrayList<String> propertyName = new ArrayList<String>();
	private ArrayList<String> propertyValue = new ArrayList<String>();
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DBConnection.class);


	public ArrayList<String> getPropertyName() {
		return propertyName;
	}

	public void setPropertyName(ArrayList<String> propertyName) {
		this.propertyName = propertyName;
	}

	public ArrayList<String> getPropertyValue() {
		return propertyValue;
	}

	public void setPropertyValue(ArrayList<String> propertyValue) {
		this.propertyValue = propertyValue;
	}

	public DBConnection() {
		Constants.loadResourceProperty();
	}

	public static DBConnection getInstance() {
		synchronized (DBConnection.class) {
			if (instance == null) {
				instance = new DBConnection();
				return instance;
			} else
				return instance;
		}
	}
	
	public static Connection openConnection(String schema) {
		Constants.loadResourceProperty();
		if (Constants.getProperty("jdbc.driver")!=null)
			_JDBC_DRIVER=Constants.getProperty("jdbc.driver");
		if (Constants.getProperty("database.source_url")!=null)
			_DATABASE_SOURCE_URL=Constants.getProperty("database.source_url");
		if(!schema.trim().equalsIgnoreCase("RAGE"))
		{
			if (Constants.getProperty("staging.user")!=null)
				_DATABASE_USER=Constants.getProperty("staging.user");
			if (Constants.getProperty("staging.pwd")!=null)
				_DATABASE_PASSWORD=Constants.getProperty("staging.pwd");

			if (_DATABASE_SOURCE_URL.equals(""))
				System.out.println("Source URL missing");
			if (_DATABASE_USER.equals(""))
				System.out.println("Staging User ID missing");
			if (_DATABASE_USER.equals(""))
				System.out.println("Staging password missing");

		}
		else
		{
			if(!_JDBC_DRIVER.toLowerCase().contains("oracle"))
			{
				if (Constants.getProperty("database.source_url")!=null)
					_DATABASE_SOURCE_URL=Constants.getProperty("rage.database.source_url");
			}
			if (Constants.getProperty("rage.user")!=null)
				_DATABASE_USER=Constants.getProperty("rage.user");
			if (Constants.getProperty("rage.pwd")!=null)
				_DATABASE_PASSWORD=Constants.getProperty("rage.pwd");
			if (_DATABASE_SOURCE_URL.equals(""))
				System.out.println("Source URL missing");
			if (_DATABASE_USER.equals(""))
				System.out.println("Rage User ID missing");
			if (_DATABASE_USER.equals(""))
				System.out.println("Rage password missing");
		}
		
		Connection connection=null;
		
		if(_DATABASE_USER.startsWith("ENC(") && _DATABASE_PASSWORD.startsWith("ENC("))
		{
			_DATABASE_USER = _DATABASE_USER.substring(_DATABASE_USER.indexOf("ENC(")+4,_DATABASE_USER.indexOf(")"));
			_DATABASE_PASSWORD = _DATABASE_PASSWORD.substring(_DATABASE_PASSWORD.indexOf("ENC(")+4,_DATABASE_PASSWORD.indexOf(")"));

			AbstractSecureKey AESsek = SecureKeyFactory.getInstance(SecureKeyFactory.getDatabaseConnectionSecureKey());
			if (_DATABASE_USER!=null)
				_DATABASE_USER=AESsek.decryptString(_DATABASE_USER);
			if (_DATABASE_PASSWORD!=null)
				_DATABASE_PASSWORD=AESsek.decryptString(_DATABASE_PASSWORD);
		}
		
		System.out.println("\n\n") ;
		System.out.println("DB Details ... ") ;
		System.out.println(_JDBC_DRIVER) ;
		System.out.println(_DATABASE_SOURCE_URL) ;
		System.out.println(_DATABASE_USER) ;
		System.out.println(_DATABASE_PASSWORD) ;
		System.out.println("\n\n") ;
		
		try 
		{
			Class.forName(_JDBC_DRIVER);
			connection = DriverManager.getConnection(_DATABASE_SOURCE_URL, _DATABASE_USER, _DATABASE_PASSWORD);
		} 
		catch (Exception e)
		{
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
			System.out.println("ERRORRRRRRR : " + e.getMessage());

		} finally{}
		return connection;
	} 

	

	public static String get_JDBC_DRIVER() {
		return _JDBC_DRIVER;
	}

	public static void set_JDBC_DRIVER(String _JDBC_DRIVER) {
		DBConnection._JDBC_DRIVER = _JDBC_DRIVER;
	}

	private static BufferedReader readBufferedFile(String fileName)
			throws FileNotFoundException, IOException {
		return new BufferedReader(new FileReader(
				new File(fileName).getCanonicalFile()));
	}

	@SuppressWarnings("static-access")
	public int loadRunConfig(String fileName) {
		int dT;
		try {
			// Open the properties file
			BufferedReader r = readBufferedFile(fileName);
			StreamTokenizer at = new StreamTokenizer(r);

			int i = 0;
			boolean notDone = true;

			while (notDone) {
				i = i + 1;
				for (int j = 0; j < 2; j++) {
					dT = at.nextToken();

					if (dT == at.TT_EOF) {
						notDone = false;
						break;
					}

					switch (j) {
					case 0: {
						if (dT == at.TT_NUMBER) {
							System.out.println((("Formatting error in row no: "
									+ i + " " + at.nval + " j:" + j)));

							System.exit(1);
						} else {
							propertyName.add(at.sval);
							break;
						}
					}

					case 1: {
						if (dT == at.TT_NUMBER) {
							System.out.println((("Formatting error in row no: "
									+ i + " " + at.nval + " j:" + j)));

							System.exit(1);
						} else {
							propertyValue.add(at.sval);
							break;
						}
					}
					}
				}
			}
		} catch (FileNotFoundException e) {
		
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("Error reading PrivateProperty file" + e));
			}
			System.out.println(e.getMessage());
		
			System.out.println((("Error reading PrivateProperty  file" + e)));

			System.exit(1);
		} catch (IOException e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("Error reading PrivateProperty file" + e));
			}
			System.out.println(e.getMessage());
			System.out.println((("Error reading PrivateProperty file" + e)));
			System.exit(1);
		}
		return 0;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	/**
	 * Get extractor run properties item by name
	 * 
	 * @param propName
	 * @return
	 */
	public String getProperty(String propName) {
		if (propertyName.size() > 0) {
			int index = propertyName.indexOf(propName);
			if (index != -1)
				return propertyValue.get(index);
		}
		return "";
	}

	

}
