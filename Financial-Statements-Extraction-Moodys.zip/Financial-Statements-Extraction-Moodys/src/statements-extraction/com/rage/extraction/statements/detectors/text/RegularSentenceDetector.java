package com.rage.extraction.statements.detectors.text;

import java.util.List;
import java.util.TreeSet;

import com.rage.extraction.statements.ontology.RegularSentenceOntology;
import com.rage.extraction.statements.uitls.Utilities;

public class RegularSentenceDetector 
{
	private static Boolean DEBUG = Boolean.FALSE ;

	
	public static boolean isMultiTokensPresent(String line,int restLines,int totalLines)
	{
		
		Boolean foundAll  = false;
		for ( List<String> keywords : RegularSentenceOntology.getMultipleTokenKeywords() )
		{
			foundAll  = true;
			for ( String keyword : keywords )
			{
				String modifiedKeyword = " " + keyword.trim() + " " ;
				if ( !line.toLowerCase().contains(modifiedKeyword.toLowerCase().trim()) )
				{
					foundAll = false;
					break;
				}

			}
			if(foundAll)
			{
				if ( DEBUG )
					System.out.println("Found multiple-token Regular-Sentence Keywords: " + keywords.toString()) ; 
				if(((totalLines-restLines)*1.0/totalLines*1.0)>0.65)
					return true ;
			}
		}
		return false ;
	}
	public static boolean isRegularSentence(String neighbourhood,int restLines,int totalLines)
	{
		List<String> tokens = Utilities.tokenize(neighbourhood, true) ;

		TreeSet<String> singleTokenKeywordsSet = new TreeSet<String>(RegularSentenceOntology.getSingleTokenKeywords()) ;
		singleTokenKeywordsSet.retainAll(tokens) ;

		if ( singleTokenKeywordsSet.size() != 0 )
		{
			if ( DEBUG )
				System.out.println("Found single-token Regular-Sentence Keywords: " + singleTokenKeywordsSet) ;

			return true ;
		}

	/*	String modifiedNeighbourhood = "" ;
		for ( int i=0 ; i<tokens.size() ; i++ )
			modifiedNeighbourhood = modifiedNeighbourhood.trim() + " " + tokens.get(i).trim() ;
		modifiedNeighbourhood = " " + modifiedNeighbourhood.trim() + " " ;
		Boolean foundAll  = false;
		for ( List<String> keywords : RegularSentenceOntology.getMultipleTokenKeywords() )
		{
			foundAll  = true;
			for ( String keyword : keywords )
			{
				String modifiedKeyword = " " + keyword.trim() + " " ;
				if ( !modifiedNeighbourhood.contains(modifiedKeyword) )
				{
					foundAll = false;
					break;
				}

			}
			if(foundAll)
			{
				if ( DEBUG )
					System.out.println("Found multiple-token Regular-Sentence Keywords: " + keywords.toString()) ; 
				if(((totalLines-restLines)*1.0/totalLines*1.0)>0.75)
					return true ;
			}
		}*/

		return false ;
	}
}
