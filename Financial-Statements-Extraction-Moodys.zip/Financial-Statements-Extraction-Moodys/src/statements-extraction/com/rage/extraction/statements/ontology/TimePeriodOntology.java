package com.rage.extraction.statements.ontology;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.pdf.utils.AccentsRemover;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;

public class TimePeriodOntology 
{
	private static List<List<String>> keywords ;
	private static LinkedHashSet<String> regexes;
	private static LinkedHashSet<String> notesList;
	private static LinkedHashSet<String> companySuffixList;
	private static HashMap<String, LinkedHashSet<String>> languageSpecificMap;
	private static LinkedHashSet<String> stmtForList;
	private static  LinkedHashSet<String> balanceList;
	private static  LinkedHashSet<String> lineItemStopWords;

	public static org.apache.log4j.Logger getLogger() {
		return logger;
	}



	public static LinkedHashSet<String> getCompanySuffixList() {
		return companySuffixList;
	}



	public static void setCompanySuffixList(LinkedHashSet<String> companySuffixList) {
		TimePeriodOntology.companySuffixList = companySuffixList;
	}



	public static LinkedHashSet<String> getStmtForList() {
		return stmtForList;
	}



	public static void setStmtForList(LinkedHashSet<String> stmtForList) {
		TimePeriodOntology.stmtForList = stmtForList;
	}



	public static void setKeywords(List<List<String>> keywords) {
		TimePeriodOntology.keywords = keywords;
	}

	public static void setRegexes(LinkedHashSet<String> regexes) {
		TimePeriodOntology.regexes = regexes;
	}

	public static void setNotesList(LinkedHashSet<String> notesList) {
		TimePeriodOntology.notesList = notesList;
	}

	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TimePeriodOntology.class);

	public static List<List<String>> getKeywords()
	{
		if ( keywords == null )
		{
			String fileName ="";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/time-period-keywords.txt" ;
			else
				fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/time-period-keywords.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			keywords = loadSuffixesFromFile(fileName) ;
		}

		return keywords ;
	}
	
	public static LinkedHashSet<String> getBalanceList()
	{
		if ( balanceList == null )
		{
			String fileName ="";
		/*	if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/notesList.txt" ;
			else*/
				fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/balanceList.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			balanceList = loadSuffixes(fileName) ;
		}

		return balanceList ;
	}

	public static List<List<String>> loadSuffixesFromFile(String fileName) 
	{
		//TreeSet<String> ret = new TreeSet<String>() ;

		List<List<String>> ret = new ArrayList<List<String>>() ;

		BufferedReader br = null ;

		try
		{
			//br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));

			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				line = AccentsRemover.removeAccents(line).trim();

				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;
				line = line.trim().toLowerCase() ;

				if(line.contains(";"))
				{
					List<String> tokens= Arrays.asList(line.split(";"));
					ret.add(tokens);
				}
				else
				{
					List<String> tokens =new ArrayList<String>();
					tokens.add(line);
					ret.add(tokens) ;
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}

	public static Map<String, List<String>> loadImplicitMetdata(String fileName,String userGroup) 
	{
		Map<String,List<String>> ret = new HashMap<String,List<String>>(); ;
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName)));
			String line = "" ;
			while ( (line = br.readLine()) != null )
			{
				line = AccentsRemover.removeAccents(line).trim();
				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;
				line = line.trim().toLowerCase() ;
				String[] split=line.split("\t");
				if(split.length>2 && split[0].trim().equalsIgnoreCase(userGroup.trim()))
				{
					if(ret.get(split[1].trim().toLowerCase())!=null)
					{
						ret.get(split[1].trim().toLowerCase()).add(split[2].trim());
					}
					else
					{
						List<String> temp= new ArrayList<String>();
						temp.add(split[2].trim());
						ret.put(split[1].trim().toLowerCase(), temp);
					}
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}
	
	public static LinkedHashSet<String> loadSuffixes(String fileName) 
	{
		LinkedHashSet<String> ret = new LinkedHashSet<String>() ;


		BufferedReader br = null ;

		try
		{
			//br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));

			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				line = AccentsRemover.removeAccents(line).trim();

				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;
				line = line.trim().toLowerCase() ;
				ret.add(line) ;

			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}



	public static void loadRules(String fileName) 
	{
		BufferedReader br = null ;

		try
		{
			//br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));

			String line = "", section="";

			LinkedHashSet<String> synonymList = null;
			while ( (line = br.readLine()) != null )
			{
				line = AccentsRemover.removeAccents(line).trim();

				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;

				if (line.trim().startsWith("[") && line.trim().endsWith("]"))
				{
					if (languageSpecificMap==null)
						languageSpecificMap=new HashMap<String,LinkedHashSet<String>>();
					synonymList = new LinkedHashSet<String>();
					if (!languageSpecificMap.containsKey(line.trim()))
					{
						languageSpecificMap.put(line.trim(), synonymList);
						section=line.trim();
					}
					continue;
				}
				line = line.trim().toLowerCase() ;
				synonymList.add(line);
				//ret.add(line) ;

			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

	}


	public static HashMap<String, LinkedHashSet<String>> getLanguageSpecificMap() {
		return languageSpecificMap;
	}

	public static void setLanguageSpecificMap(
			HashMap<String, LinkedHashSet<String>> languageSpecificMap) {
		TimePeriodOntology.languageSpecificMap = languageSpecificMap;
	}

	public static LinkedHashSet<String> getRegexes ( )
	{
		if ( regexes == null )
		{
			String fileName ="";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/time-period-Ragexes.txt" ;
			else
				fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/time-period-Ragexes.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			regexes = loadSuffixes(fileName) ;
		}

		return regexes ;
	}

	public static LinkedHashSet<String> getCompanySuffixes()
	{
		String fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/company-suffixes.txt";
		if ( companySuffixList == null )
		{
			companySuffixList = loadSuffixes(fileName) ;
		}

		return companySuffixList ;
	}

	public static LinkedHashSet<String> getNotesList()
	{
		if ( notesList == null )
		{
			String fileName ="";
			/*	if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/notesList.txt" ;
			else*/
			fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/notesList.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			notesList = loadSuffixes(fileName) ;
		}

		return notesList ;
	}

	public static LinkedHashSet<String> getlineItemStopWords()
	{
		if ( lineItemStopWords == null )
		{
			String fileName ="";
			/*	if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/notesList.txt" ;
			else*/
			fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/lineItemStopWords.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			lineItemStopWords = loadSuffixes(fileName) ;
		}

		return lineItemStopWords ;
	}


}
