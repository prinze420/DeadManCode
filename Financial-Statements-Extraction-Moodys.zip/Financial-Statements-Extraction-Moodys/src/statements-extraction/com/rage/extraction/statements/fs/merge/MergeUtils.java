package com.rage.extraction.statements.fs.merge;

import java.util.ArrayList;
import java.util.List;

import com.rage.extraction.statements.db.ParserOutput;


class MergeUtils {


	int getMaxColumn(List<ParserOutput> output)
	{
		int count=0;
		for (ParserOutput po:output)
		{
			if (po.getValue1()!=null && !po.getValue1().equals(""))
				count=setCount(count,1);
			if (po.getValue2()!=null && !po.getValue2().equals(""))
				count=setCount(count,2);
			if (po.getValue3()!=null && !po.getValue3().equals(""))
				count=setCount(count,3);
			if (po.getValue4()!=null && !po.getValue4().equals(""))
				count=setCount(count,4);
			if (po.getValue5()!=null && !po.getValue5().equals(""))
				count=setCount(count,5);
			if (po.getValue6()!=null && !po.getValue6().equals(""))
				count=setCount(count,6);
			if (po.getValue7()!=null && !po.getValue7().equals(""))
				count=setCount(count,7);
			if (po.getValue8()!=null && !po.getValue8().equals(""))
				count=setCount(count,8);
			if (po.getValue9()!=null && !po.getValue9().equals(""))
				count=setCount(count,9);
			if (po.getValue10()!=null && !po.getValue10().equals(""))
				count=setCount(count,10);
			if (po.getValue11()!=null && !po.getValue11().equals(""))
				count=setCount(count,11);
			if (po.getValue12()!=null && !po.getValue12().equals(""))
				count=setCount(count,12);
			if (po.getValue13()!=null && !po.getValue13().equals(""))
				count=setCount(count,13);
			if (po.getValue14()!=null && !po.getValue14().equals(""))
				count=setCount(count,14);
			if (po.getValue15()!=null && !po.getValue15().equals(""))
				count=setCount(count,15);
			if (po.getValue16()!=null && !po.getValue16().equals(""))
				count=setCount(count,16);
			if (po.getValue17()!=null && !po.getValue17().equals(""))
				count=setCount(count,17);
			if (po.getValue18()!=null && !po.getValue18().equals(""))
				count=setCount(count,18);
			if (po.getValue19()!=null && !po.getValue19().equals(""))
				count=setCount(count,19);
			if (po.getValue20()!=null && !po.getValue20().equals(""))
				count=setCount(count,20);
			if (po.getValue21()!=null && !po.getValue21().equals(""))
				count=setCount(count,21);
			if (po.getValue22()!=null && !po.getValue22().equals(""))
				count=setCount(count,22);
			if (po.getValue23()!=null && !po.getValue23().equals(""))
				count=setCount(count,23);
			if (po.getValue24()!=null && !po.getValue24().equals(""))
				count=setCount(count,24);
			if (po.getValue25()!=null && !po.getValue25().equals(""))
				count=setCount(count,25);
			if (po.getValue26()!=null && !po.getValue26().equals(""))
				count=setCount(count,26);
			if (po.getValue27()!=null && !po.getValue27().equals(""))
				count=setCount(count,27);
			if (po.getValue28()!=null && !po.getValue28().equals(""))
				count=setCount(count,28);
			if (po.getValue29()!=null && !po.getValue29().equals(""))
				count=setCount(count,29);
			if (po.getValue30()!=null && !po.getValue30().equals(""))
				count=setCount(count,30);
		}
		return count;
	}


	public ArrayList<Integer> getStatementStartIndex(List<ParserOutput> output)
	{
		ArrayList<Integer> pos=new ArrayList<Integer>();
		int count=0;
		for (ParserOutput po:output)
		{
			if (po.getAsRepLabel()==null)
			{
				count++;
				continue;
			}
			if (po.getAsRepLabel().equals("STATEMENT YEAR"))
				pos.add(count);
			count++;
		}
		return pos;
	}

	public String getSectionName(List<ParserOutput> output)
	{
		if (output.size()>0)
			return output.get(0).getSection();
		return "";
	}

	public int setCount(int count, int setCount)
	{
		if (count<setCount)
			return setCount;
		return count;
	}
/*
	public List<BrokerMasterRules> getSectionMergeRules(String section, List<BrokerMasterRules> metaRules)
	{
		List<BrokerMasterRules> rules=new ArrayList<BrokerMasterRules>();
		for (int i=0; i<metaRules.size(); i++)
		{
			BrokerMasterRules bmr =  metaRules.get(i);
			if (bmr.IndustryType.equals("MS") && bmr.tagType.equals(section))
				rules.add(bmr);
		}
		return rules;
	}*/

	/*public List<BrokerMasterRules> getSubSectionMergeRules(String subSection, List<BrokerMasterRules> metaRules)
	{
		List<BrokerMasterRules> rules=new ArrayList<BrokerMasterRules>();
		for (int i=0; i<metaRules.size(); i++)
		{
			BrokerMasterRules bmr =  metaRules.get(i);
			if (bmr.IndustryType.equals("MS") && bmr.ruleText.equals(subSection))
				rules.add(bmr);
		}
		return rules;
	}
*/
	/*public List<String> getSubSectionList(List<BrokerMasterRules> metaRules)
	{
		List<String> subSection=new ArrayList<String>();
		for (int i=0; i<metaRules.size(); i++)
		{
			BrokerMasterRules bmr =  metaRules.get(i);
			if (!subSection.contains(bmr.ruleText))
				subSection.add(bmr.ruleText);
		}
		return subSection;
	}*/
}
