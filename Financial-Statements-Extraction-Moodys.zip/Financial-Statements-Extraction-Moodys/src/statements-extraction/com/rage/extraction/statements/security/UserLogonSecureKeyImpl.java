package com.rage.extraction.statements.security;



import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.Arrays;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.lang3.StringEscapeUtils;

/**
 * This class is actual implementation class for SHA-256 encryption algorithm.
 * @author Saurabh.Jain
 */
final class UserLogonSecureKeyImpl extends AbstractSecureKey {

    /**
     * This is CIPHER algorithm for SHA-256 encryption.
     */
    private static final String CIPHER_ALGORITHM = "DESede/CBC/PKCS5Padding";
    /**
     * The algorithm name for SHA-256.
     */
    private static final String ALGORITHM_TYPE_SHA_256 = "SHA-256";
    /**
     * This is the message digest password for SHA-256 digest.
     */
    private static final String DIGEST_PASSWORD = "CPRAGEPUNE2010";
    /**
     * This is the key algorithm name for SHA-256 encryption.
     */
    private static final String SECRET_KEY_ALGORITHM = "DESede";

    /**
     * Default constructor.
     */
    public UserLogonSecureKeyImpl() {
    }

    //This method to create the cipher object for encrypt/decrypt funcionality.
    protected Cipher getCipherObject(int cipherInitMode) {
        try {
            //Create the digest for SHA-256
            MessageDigest messageDigest = MessageDigest.getInstance(ALGORITHM_TYPE_SHA_256);
            //Add password into digest.
            byte[] digestOfPassword = messageDigest.digest(DIGEST_PASSWORD.getBytes(ENCODING_TYPE));
            byte[] keyBytes = Arrays.copyOf(digestOfPassword, 24);
            for (int j = 0, k = 16; j < 8;) {
                keyBytes[k++] = keyBytes[j++];
            }
            SecretKey secretKey = new SecretKeySpec(keyBytes, SECRET_KEY_ALGORITHM);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(new byte[8]);
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM, new com.sun.crypto.provider.SunJCE());
            cipher.init(cipherInitMode, secretKey, ivParameterSpec);
            return cipher;
        } catch (java.security.InvalidAlgorithmParameterException e) {
            logger.error(StringEscapeUtils.escapeJava("Invalid Algorithm"), e);
        } catch (javax.crypto.NoSuchPaddingException e) {
            logger.error(StringEscapeUtils.escapeJava("No Such Padding"), e);
        } catch (java.security.NoSuchAlgorithmException e) {
            logger.error(StringEscapeUtils.escapeJava("No Such Algorithm"), e);
        } catch (java.security.InvalidKeyException e) {
            logger.error(StringEscapeUtils.escapeJava("Invalid Key"), e);
        } catch (UnsupportedEncodingException e) {
            logger.error(StringEscapeUtils.escapeJava("Invalid Key"), e);
        }
        return null;
    }

	
}
