package com.rage.extraction.statements.uitls;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;


import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PDFPageParser;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.security.SafeFile;


public class PDFDocumentLoader 
{
	@SuppressWarnings("unchecked")
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(PDFDocumentLoader.class);
	private static Float fullerLineLength;
	public static TreeMap<Integer, PageParse> loadDocument(String fileName, boolean all, List<Integer> pageNos)
	{
		PDDocument document = null ;

		try
		{
			new SafeFile(fileName);
			document = PDDocument.load(new File(fileName)) ;
		}
		catch (Exception e)
		{
			System.err.println("Error in loading PDF Document: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		if ( document == null )
			return null ;

		List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;

		TreeMap<Integer, PageParse> pageParsesMap = new TreeMap<Integer, PageParse>() ;
		Float maxlineLength = 0.0f ;

		System.out.println("\tTotal Pages: " + pages.size()) ;
	 logger.info("\tTotal Pages: " + pages.size()) ;

		for ( int i=0 ; i<pages.size() ; i++ )
		{
			PDPage page = pages.get(i) ;

			if ( !all && !pageNos.contains(i) )
				continue ;
			PDFPageParser parser = new PDFPageParser(i, page) ;
			parser.run() ;
			PageParse parse = parser.getParse() ;
			logger.info("\t\tDone page no. " + i) ;
			System.out.println(("\t\tDone page no. " + i)) ;

			//
			List<PDFLine> pageLines = parser.getParse().getPageLines() ;
			//System.out.println("\n\n\nPrinting Lines .... \n") ;
			for ( int i1=0 ; i1<pageLines.size() ; i1++ )
			{
				PDFLine line = pageLines.get(i1) ;
				if(maxlineLength<(line.getX2()-line.getX1()))
				{
					maxlineLength = line.getX2()-line.getX1();
				}
				
				System.out.println("\tLine " + i1 + " : " + line.getLine() + " : " + line.getHeight()) ;
			/*	System.out.println("\tLine Length "	+(line.getX2()-line.getX1()));
				//System.out.println("===================================");
		*/	}

			//List<PDFBlock> blocks = parse.getPageBlocks() ;

			//System.out.println("\n\n\nPrinting Blocks .... \n") ;
			/*for ( int i2=0 ; i2<blocks.size() ; i2++ )
			{
				System.out.println("\n\n\n") ;
				PDFBlock block = blocks.get(i2) ;
				System.out.println(block.getBlockString()) ;

				List<PDFLine> lines = block.getLines() ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					List<PDFChunk> chunks = line.getChunks() ;

					for ( int k=0 ; k<chunks.size() ; k++ )
					{
						PDFChunk chunk = chunks.get(k) ;
						System.out.print("'" + chunk.getChunk()+"' [" + chunk.getX1() + ", " + chunk.getX2() + "]") ;
					}

					System.out.println() ;
				}
			}*/

			//

			//parse.setPage(null) ;
			pageParsesMap.put(i, parse) ;
		}
	//	System.out.println("\tMax Line Length "	+maxlineLength);

		fullerLineLength = maxlineLength;
		logger.info("\tDone ...") ;

		try
		{
			document.close() ;
		}
		catch (Exception e)
		{
			System.err.println("Error in closing document: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return pageParsesMap ;
	}
	
	public static TreeMap<Integer, PageParse> createPageParsePageWise(Map<Integer,List<PDFCharacter>> pageCharacterMap,boolean isSpaceCheck)
	{
		TreeMap<Integer,PageParse> pageNoPageParseMap= new TreeMap<Integer,PageParse>();
		Float maxlineLength = 0.0f ;
		int pgNoSeq=0;
		for(Integer pgNo:pageCharacterMap.keySet())
		{
			List<PDFCharacter> charList=pageCharacterMap.get(pgNo);
			Map<Integer,List<PDFCharacter>> colCharMap=getColumnWiseCharacterList(charList);
			List<PDFLine> lines = new ArrayList<PDFLine>();
			List<PDFBlock> blocks = new ArrayList<PDFBlock>();
			/*if(colCharMap.size()<2)
			{
				
			}*/
			for(Integer colNo:colCharMap.keySet())
			{
				List<PDFCharacter> charLst=colCharMap.get(colNo);
				PDFPageParser parser = new PDFPageParser(pgNo) ;
				parser.run(charLst,isSpaceCheck) ;
				List<PDFLine> pageLines = parser.getParse().getPageLines();
				//lines.addAll(pageLines);
				for(PDFLine line:pageLines)
				{
					//System.out.println("Line:"+line.getLine());
					if(maxlineLength<(line.getX2()-line.getX1()))
					{
						maxlineLength = line.getX2()-line.getX1();
					}
				}
				
				List<PDFBlock> pageBlocks =	parser.getParse().getPageBlocks();
				//blocks.addAll(pageBlocks);
				pageNoPageParseMap.put(pgNoSeq, parser.getParse());
				pgNoSeq++;
			}
			/*PageParse pp= new PageParse(pgNo,null);
			pp.setPageBlocks(blocks);
			pp.setPageLines(lines);
			pageNoPageParseMap.put(pgNo, pp);*/
		}
		if(fullerLineLength==null || fullerLineLength<maxlineLength)
		{
			fullerLineLength = maxlineLength;
		}
		return pageNoPageParseMap;
	}
	
	public static TreeMap<Integer, PageParse> createPageParsePageWisePageNos(Map<Integer,List<PDFCharacter>> pageCharacterMap,boolean isSpaceCheck)
	{
		TreeMap<Integer,PageParse> pageNoPageParseMap= new TreeMap<Integer,PageParse>();
		Float maxlineLength = 0.0f ;
		
		for(Integer pgNo:pageCharacterMap.keySet())
		{
			List<PDFCharacter> charList=pageCharacterMap.get(pgNo);
			Map<Integer,List<PDFCharacter>> colCharMap=getColumnWiseCharacterList(charList);
			
			PageParse thisPageParse=null;
			for(Integer colNo:colCharMap.keySet())
			{
				List<PDFCharacter> charLst=colCharMap.get(colNo);
				PDFPageParser parser = new PDFPageParser(pgNo) ;
				parser.run(charLst,isSpaceCheck) ;
				List<PDFLine> pageLines = parser.getParse().getPageLines();
				//lines.addAll(pageLines);
				for(PDFLine line:pageLines)
				{
					//System.out.println("Line:"+line.getLine());
					if(maxlineLength<(line.getX2()-line.getX1()))
					{
						maxlineLength = line.getX2()-line.getX1();
					}
				}
				if(thisPageParse==null)
				{
					thisPageParse=parser.getParse();
				}
				else
				{
					if(parser.getParse().getPageBlocks()!=null)
					{
						if(thisPageParse.getPageBlocks()!=null)
						{
							thisPageParse.getPageBlocks().addAll(parser.getParse().getPageBlocks());
						}
						else
						{
							thisPageParse.setPageBlocks(parser.getParse().getPageBlocks());
						}
					}
					
					if(parser.getParse().getPageLines()!=null)
					{
						if(thisPageParse.getPageLines()!=null)
						{
							thisPageParse.getPageLines().addAll(parser.getParse().getPageLines());
						}
						else
						{
							thisPageParse.setPageLines(parser.getParse().getPageLines());
						}
					}
				}
			}
			if(thisPageParse!=null)
				pageNoPageParseMap.put(pgNo, thisPageParse);
		}
		if(fullerLineLength==null || fullerLineLength<maxlineLength)
		{
			fullerLineLength = maxlineLength;
		}
		return pageNoPageParseMap;
	}
	
	
	public static TreeMap<Integer, PageParse> loadDocument(Map<Integer,List<PDFCharacter>> pageCharacterMap,boolean isSpaceCheck)
	{
		TreeMap<Integer,PageParse> pageNoPageParseMap= new TreeMap<Integer,PageParse>();
		Float maxlineLength = 0.0f ;
		int pgNoSeq=0;
		for(Integer pgNo:pageCharacterMap.keySet())
		{
			List<PDFCharacter> charList=pageCharacterMap.get(pgNo);
			Map<Integer,List<PDFCharacter>> colCharMap=getColumnWiseCharacterList(charList);
			List<PDFLine> lines = new ArrayList<PDFLine>();
			List<PDFBlock> blocks = new ArrayList<PDFBlock>();
			for(Integer colNo:colCharMap.keySet())
			{
				List<PDFCharacter> charLst=colCharMap.get(colNo);
				PDFPageParser parser = new PDFPageParser(pgNo) ;
				parser.run(charLst,isSpaceCheck) ;
				List<PDFLine> pageLines = parser.getParse().getPageLines();
				lines.addAll(pageLines);
				for(PDFLine line:pageLines)
				{
					if(maxlineLength<(line.getX2()-line.getX1()))
					{
						maxlineLength = line.getX2()-line.getX1();
					}
				}
				
				List<PDFBlock> pageBlocks =	parser.getParse().getPageBlocks();
				blocks.addAll(pageBlocks);
				pageNoPageParseMap.put(pgNoSeq, parser.getParse());
				pgNoSeq++;
			}
			/*PageParse pp= new PageParse(pgNo,null);
			pp.setPageBlocks(blocks);
			pp.setPageLines(lines);
			pageNoPageParseMap.put(pgNo, pp);*/
		}
		fullerLineLength = maxlineLength;
		return pageNoPageParseMap;
	}
	
	private static Map<Integer, List<PDFCharacter>> getColumnWiseCharacterList ( List<PDFCharacter> charList )
	{
		Map<Integer, List<PDFCharacter>> ret= new TreeMap<Integer, List<PDFCharacter>>();
		for(PDFCharacter character:charList)
		{
			int colIndex = character.getMultiColumnIndex();
			
			if(ret.containsKey(colIndex))
			{
				ret.get(colIndex).add(character);
			}else
			{
				List<PDFCharacter> chList = new ArrayList<PDFCharacter>();
				chList.add(character);
				ret.put(colIndex, chList);
			}
		}
		
		return ret;
	}
	
	public static TreeMap<Integer, PageParse> loadDocument(String fileName, boolean all, List<Integer> pageNos,boolean isSpaceCheck)
	{
		PDDocument document = null ;

		try
		{
			new SafeFile(fileName);
			document = PDDocument.load(new File(fileName)) ;
			/*if (document.isEncrypted())
			{
				try {
					document.decrypt("");
					document.setAllSecurityToBeRemoved(true);
		        }
		        catch (Exception e) {
		            throw new Exception("The document is encrypted, and we can't decrypt it.", e);
		        }
			}*/
				
		}
		catch (Exception e)
		{
			System.err.println("Error in loading PDF Document: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		if ( document == null )
			return null ;

		List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;

		TreeMap<Integer, PageParse> pageParsesMap = new TreeMap<Integer, PageParse>() ;
		Float maxlineLength = 0.0f ;

		System.out.println("\tTotal Pages: " + pages.size()) ;
	 logger.info("\tTotal Pages: " + pages.size()) ;

		for ( int i=0 ; i<pages.size() ; i++ )
		{
			
			PDPage page = pages.get(i) ;

			if ( !all && !pageNos.contains(i) )
				continue ;
			/*if(i<35 || i>81 )
				continue;*/
			/*if(i<64 || i>64 )
				continue;*/
			/*if(i<38 || i>154 )
				continue;*/
			/*if(i<211 || i>211 )
				continue;*/
			PDFPageParser parser = new PDFPageParser(i, page) ;
			parser.run() ;
			PageParse parse = parser.getParse() ;
			logger.info("\t\tDone page no. " + i) ;
			System.out.println(("\t\tDone page no. " + i)) ;

			//
			List<PDFLine> pageLines = parser.getParse().getPageLines() ;
			//System.out.println("\n\n\nPrinting Lines .... \n") ;
			for ( int i1=0 ; i1<pageLines.size() ; i1++ )
			{
				PDFLine line = pageLines.get(i1) ;
				if(maxlineLength<(line.getX2()-line.getX1()))
				{
					maxlineLength = line.getX2()-line.getX1();
				}
				
				System.out.println("\tLine " + i1 + " : " + line.getLine() + " : " + line.getHeight()) ;
			/*	System.out.println("\tLine Length "	+(line.getX2()-line.getX1()));
				//System.out.println("===================================");
		*/	}

			//List<PDFBlock> blocks = parse.getPageBlocks() ;

			//System.out.println("\n\n\nPrinting Blocks .... \n") ;
			/*for ( int i2=0 ; i2<blocks.size() ; i2++ )
			{
				System.out.println("\n\n\n") ;
				PDFBlock block = blocks.get(i2) ;
				System.out.println(block.getBlockString()) ;

				List<PDFLine> lines = block.getLines() ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					List<PDFChunk> chunks = line.getChunks() ;

					for ( int k=0 ; k<chunks.size() ; k++ )
					{
						PDFChunk chunk = chunks.get(k) ;
						System.out.print("'" + chunk.getChunk()+"' [" + chunk.getX1() + ", " + chunk.getX2() + "]") ;
					}

					System.out.println() ;
				}
			}*/

			//

			//parse.setPage(null) ;
			pageParsesMap.put(i, parse) ;
		}
	//	System.out.println("\tMax Line Length "	+maxlineLength);

		fullerLineLength = maxlineLength;
		logger.info("\tDone ...") ;

		try
		{
			document.close() ;
		}
		catch (Exception e)
		{
			System.err.println("Error in closing document: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return pageParsesMap ;
	}
	
	public static Float getFullerLineLength() {
		return fullerLineLength;
	}
	public static void setFullerLineLength(Float fullerLineLength) {
		PDFDocumentLoader.fullerLineLength = fullerLineLength;
	}
	
	
}
