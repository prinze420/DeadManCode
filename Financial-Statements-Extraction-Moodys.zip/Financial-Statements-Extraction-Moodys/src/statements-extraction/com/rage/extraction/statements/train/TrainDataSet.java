package com.rage.extraction.statements.train;

import java.io.File;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;


/**
 * @author kiran.umadi
 *
 */
public class TrainDataSet implements Serializable
{
	private static final long serialVersionUID = -8619876697927703168L;
	private Date lastUpdated;
	private String industry;
	private String language;
	private Map<String, Node> trainMap;
	private List<String> fileList;

	TrainDataSet(String industry,String language) throws Exception {
		Constants.loadResourceProperty();
		this.industry=industry;
		this.language=language;
		lastUpdated=new Date();
		fileList=new ArrayList<String>();
		trainMap=new HashMap<String, Node>();
	}

	public Date getLastUpdated() {
		return lastUpdated;
	}
	public void setLastUpdated() {
		this.lastUpdated = new Date();
	}
	public Map<String, Node> getTrainDataSet() {
		return trainMap;
	}
	public List<String> getFileList() {
		return fileList;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getTrainDataSetFileName() throws Exception
	{
		String train=Constants.getProperty("train.path");
		if (!new File(Constants.getProperty("train.path")).exists())
			new File(Constants.getProperty("train.path")).mkdir();
		String sep=System.getProperty("file.separator");
		if (train.endsWith(sep))
		{
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase("Spanish ITR"))
			{
				train+=language+sep+this.industry+"-"+Constants.getProperty("train.dataset");
			}
			else
			{	
				train+=this.industry+"-"+Constants.getProperty("train.dataset");
			}
		}
		else
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase("Spanish ITR"))
			{
				train=train+sep+language.trim()+sep+this.industry+"-"+Constants.getProperty("train.dataset");	
			}
			else
			{	
				train=train+sep+this.industry+"-"+Constants.getProperty("train.dataset");
			}
			
		return train;
	}

}
