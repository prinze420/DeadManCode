package com.rage.extraction.statements.spreading.write;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.security.SafeFile;
import com.rage.extraction.statements.uitls.CleanEnumeratedText;


public class ExcelDataWriter 
{
	private static Boolean DEBUG = Boolean.FALSE ;

	private String outputFileName ;
	private String fileName ;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ExcelDataWriter.class);

	public ExcelDataWriter(String outputFileName, String fileName) {
		this.outputFileName = outputFileName;
		this.fileName= fileName;
	}

	public void run(TreeMap<String, ArrayList<ParserOutput>> mergedMap, int startPg,int endPg)
	{
		if ( DEBUG )
			System.out.println("\n\n\nExcel Writer Debug ...\n\n") ;
		try
		{
			try {
				new SafeFile(outputFileName);
				//PathTravesal  pt = new  PathTravesal();
				//pt.failIfDirectoryTraversal(outputFileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}


			try {
				new SafeFile(fileName);
				//	PathTravesal  pt = new  PathTravesal();
				//	pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}

			if ( !new File(getOutputFileName()).exists() )
			{
				FileOutputStream fileOut = new FileOutputStream(getOutputFileName()) ;
				Workbook wb = new XSSFWorkbook() ;
				wb.write(fileOut) ;
				fileOut.close() ;
			}

			InputStream inp = new FileInputStream(getOutputFileName()) ;
			 org.apache.poi.ss.usermodel.Workbook wb = WorkbookFactory.create(inp);

			//Workbook wb = new XSSFWorkbook(inp) ;

			String sheetName = computeSheetName(getFileName()) ;
			Sheet sheet;
			sheet = wb.createSheet(sheetName);
			int rowNo = 0 ;
			TreeMap<String, List<List<ParserOutput>>> supplementaryMap= new TreeMap<String, List<List<ParserOutput>>>(); 
			for(String section:mergedMap.keySet())
			{			
				System.out.println("Writing for sec=="+section);
				section = section.toUpperCase();

				if(section.equalsIgnoreCase("SD") )
					continue;
				ArrayList<ParserOutput> poObjects = mergedMap.get(section);

				if(poObjects!=null && poObjects.size()>0  )
				{

					for(int k= 0 ;k<poObjects.size();k++)
					{
						ParserOutput po = poObjects.get(k);
						rowNo = writeToExcel(po,rowNo,sheet);
						boolean isLineItemAddedInSuppList=false;
						if(po.getBreakupItems()!=null && po.getBreakupItems().size()>0)
						{
							/*for(ParserOutput brkup :po.getBreakupItems())
							{
							
								if(brkup!=null)
								{
									brkup.setBreakups("Y");
									rowNo = writeToExcel(brkup,rowNo,sheet);
								}

							}*/
						}
						if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
						{
							for(List<ParserOutput> brkups :po.getSupplementaryBreakUpItem())
							{
								if(brkups!=null)
								{
									if(supplementaryMap.containsKey(section))
									{
										if(!isLineItemAddedInSuppList)
										{
											List<ParserOutput> lineItemRef= new ArrayList<ParserOutput>();
											po.setBreakups("N");
											lineItemRef.add(po);
											supplementaryMap.get(section).add(lineItemRef);
										}
										for(ParserOutput brek:brkups)
										{
											brek.setSection(section);
											brek.setBreakups("Y");;
										}
										supplementaryMap.get(section).add(brkups);
									}
									else
									{
										List<List<ParserOutput>> temp= new ArrayList<List<ParserOutput>>();
										List<ParserOutput> lineItemRef= new ArrayList<ParserOutput>();
										lineItemRef.add(po);
										temp.add(lineItemRef);
										for(ParserOutput brek:brkups)
										{
											brek.setSection(section);
											brek.setBreakups("Y");;
										}
										temp.add(brkups);
										isLineItemAddedInSuppList=true;
										supplementaryMap.put(section, temp);
									}
								}
							}
						}
						
						if(po.getMatchingBreakUpItem()!=null && po.getMatchingBreakUpItem().size()>0)
						{
							for(List<ParserOutput> brkups :po.getMatchingBreakUpItem())
							{
								if(brkups!=null)
								{
									for(ParserOutput brkup :brkups)
									{
										if(brkup!=null)
										{
											rowNo = writeToExcel(brkup,rowNo,sheet);
										}	
									}
								}
							}
						}
						
					}
				}
			}

			rowNo=rowNo+2;
			
			
			for(String section:supplementaryMap.keySet())
			{			
				section = section.toUpperCase();

				if(section.equalsIgnoreCase("SD"))
					continue;
				
				List<List<ParserOutput>> breakUps = supplementaryMap.get(section);
				
				if(breakUps!=null && breakUps.size()>0  )
				{
					for(List<ParserOutput> poObjects:breakUps)
					{
						if(poObjects!=null && poObjects.size()>0  )
						{
							for(int k= 0 ;k<poObjects.size();k++)
							{
								ParserOutput po = poObjects.get(k);
								po.setSection((po.getSection().toUpperCase()+"_Suppl"));
								rowNo = writeToExcel(po,rowNo,sheet);
							}
						}
					}
					
				}
			}
			
			rowNo = writeToExcel(startPg,endPg,rowNo,sheet);


			FileOutputStream fileOut = new FileOutputStream(getOutputFileName()) ;
			wb.write(fileOut) ;
			fileOut.flush() ;
			fileOut.close() ;
		}
		catch (Exception e)
		{
			System.err.println("Error in writing to Excel File ... " + getOutputFileName() + ", " + getFileName() + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		if ( DEBUG )
			System.out.println("\n\n\n\n") ;
	}

	/*private Boolean isSplitTable(ArrayList<ParserOutput> poObjects) {
		for(int k= 0 ;k<poObjects.size();k++)
		{
			ParserOutput po = poObjects.get(k);
			if(po.getIsSplit()!=null && po.getIsSplit())
				return true;
		}
		return false;
	}*/

	private int writeToExcel(int startPg,int endPg, int rowNo, Sheet sheet) {
		rowNo = rowNo+1;
		org.apache.poi.ss.usermodel.Row tableRow = sheet.createRow((short) rowNo) ;
		tableRow.createCell(0).setCellValue("fNotes") ;
		tableRow.createCell(1).setCellValue("") ;	
		tableRow.createCell(1).setCellValue("") ;		
		tableRow.createCell(2).setCellValue("") ;		
		tableRow.createCell(3).setCellValue("") ;		
		tableRow.createCell(4).setCellValue(startPg);
		tableRow.createCell(5).setCellValue(endPg);
		return rowNo;
	}

	public int writeToExcel(ParserOutput po,
			int rowNo,Sheet sheet) {
		if((po.getAsRepLabel()==null || (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equalsIgnoreCase("") ))
				&& (po.getValue1()==null || (po.getValue1()!=null && po.getValue1().trim().equalsIgnoreCase("")))
				&& ( po.getValue2()==null || ( po.getValue2()!=null && po.getValue2().trim().equalsIgnoreCase("")))
				&& ( po.getValue3()==null || ( po.getValue3()!=null && po.getValue3().trim().equalsIgnoreCase("")))
				&& ( po.getValue4()==null || ( po.getValue4()!=null && po.getValue4().trim().equalsIgnoreCase("")))
				&& ( po.getValue5()==null || ( po.getValue5()!=null && po.getValue5().trim().equalsIgnoreCase("")))
				&& ( po.getValue6()==null || ( po.getValue6()!=null && po.getValue6().trim().equalsIgnoreCase("")))
				&& ( po.getValue7()==null || ( po.getValue7()!=null && po.getValue7().trim().equalsIgnoreCase("")))
				&& ( po.getValue8()==null || ( po.getValue8()!=null && po.getValue8().trim().equalsIgnoreCase("")))
				&& ( po.getValue9()==null || ( po.getValue9()!=null && po.getValue9().trim().equalsIgnoreCase("")))
				&& ( po.getValue10()==null || ( po.getValue10()!=null && po.getValue10().trim().equalsIgnoreCase("")))
				&& (po.getValue11()==null || (po.getValue11()!=null && po.getValue11().trim().equalsIgnoreCase("")))
				&& ( po.getValue12()==null || ( po.getValue12()!=null && po.getValue12().trim().equalsIgnoreCase("")))
				&& ( po.getValue13()==null || ( po.getValue13()!=null && po.getValue13().trim().equalsIgnoreCase("")))
				&& ( po.getValue14()==null || ( po.getValue14()!=null && po.getValue14().trim().equalsIgnoreCase("")))
				&& ( po.getValue15()==null || ( po.getValue15()!=null && po.getValue15().trim().equalsIgnoreCase("")))
				&& ( po.getValue16()==null || ( po.getValue16()!=null && po.getValue16().trim().equalsIgnoreCase("")))
				&& ( po.getValue17()==null || ( po.getValue17()!=null && po.getValue17().trim().equalsIgnoreCase("")))
				&& ( po.getValue18()==null || ( po.getValue18()!=null && po.getValue18().trim().equalsIgnoreCase("")))
				&& ( po.getValue19()==null || ( po.getValue19()!=null && po.getValue19().trim().equalsIgnoreCase("")))
				&& ( po.getValue20()==null || ( po.getValue20()!=null && po.getValue20().trim().equalsIgnoreCase(""))))
			return rowNo;
		CleanEnumeratedText cet = new CleanEnumeratedText();

		rowNo = rowNo+1;
		org.apache.poi.ss.usermodel.Row tableRow = sheet.createRow((short) rowNo) ;

		tableRow.createCell(0).setCellValue(po.getSection().toUpperCase()) ;
		if(po.getPrevHeader()!=null && po.getPrevHeader().equalsIgnoreCase("Y"))
		{
			tableRow.createCell(1).setCellValue("PREV-HEADER") ;
		}
		else
		{
			if(po.getAsRepLabel()!=null && po.getAsRepLabel().startsWith("STATEMENT") )
				tableRow.createCell(1).setCellValue("ATTR") ;
			else
			{
				if(po.getSubSection()!=null)
					tableRow.createCell(1).setCellValue(po.getSubSection().toUpperCase()) ;
			}
		}
		tableRow.createCell(2).setCellValue(po.getNotesColumn()) ;
		
		String mainBreakUpType=po.getBreakUpMainType()==null?"":po.getBreakUpMainType();
		String breakUpType=po.getBreakUpType()==null?"":po.getBreakUpType();
		tableRow.createCell(3).setCellValue(mainBreakUpType) ;
		tableRow.createCell(4).setCellValue(breakUpType) ;
		String keyWordMatched=po.getMatchingImplicitKeyWord()==null?"":po.getMatchingImplicitKeyWord();
		tableRow.createCell(5).setCellValue(keyWordMatched) ;
		int pageNo=-1;
		if(po.getRow()!=null && po.getRow().getLines()!=null && po.getRow().getLines().size()>0)
		{
			pageNo=(po.getRow().getLines().get(0).getPageNo()+1);
		}
		else	
			pageNo=po.getPageNoCoOrdinates()!=null?(po.getPageNoCoOrdinates().getStartPg()+1):-1;
		tableRow.createCell(6).setCellValue((""+pageNo)) ;
		tableRow.createCell(7).setCellValue(po.getBreakups()) ;
		if(po.getAsRepLabel()!=null)
		{
			String text = "";
			text = cet.replaceEnums(text);

			text = po.getAsRepLabel();//.trim();

			/*if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English") || FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
			{*/
			//	text = po.getAsRepLabel().replaceAll("[[^A-Za-z -&)(0-9-]]", "").trim();

			/*}*/
			/*else
				text = po.getAsRepLabel().trim();*/

			//	text = SectionBoundaryDetector.IgnoreEnumeration(text);

			tableRow.createCell(8).setCellValue(text) ;
		}

		if(po.getValue1()!=null)
			tableRow.createCell(9).setCellValue(po.getValue1()) ;
		if(po.getValue2()!=null)
			tableRow.createCell(10).setCellValue(po.getValue2()) ;
		if(po.getValue3()!=null)
			tableRow.createCell(11).setCellValue(po.getValue3()) ;
		if(po.getValue4()!=null)
			tableRow.createCell(12).setCellValue(po.getValue4()) ;
		if(po.getValue5()!=null)
			tableRow.createCell(13).setCellValue(po.getValue5()) ;
		if(po.getValue6()!=null)
			tableRow.createCell(14).setCellValue(po.getValue6()) ;
		if(po.getValue7()!=null)
			tableRow.createCell(15).setCellValue(po.getValue7()) ;
		if(po.getValue8()!=null)
			tableRow.createCell(16).setCellValue(po.getValue8()) ;
		if(po.getValue9()!=null)
			tableRow.createCell(17).setCellValue(po.getValue9()) ;
		if(po.getValue10()!=null)
			tableRow.createCell(18).setCellValue(po.getValue10()) ;
		if(po.getValue11()!=null)
			tableRow.createCell(19).setCellValue(po.getValue11()) ;
		if(po.getValue12()!=null)
			tableRow.createCell(20).setCellValue(po.getValue12()) ;
		if(po.getValue13()!=null)
			tableRow.createCell(21).setCellValue(po.getValue13()) ;
		if(po.getValue14()!=null)
			tableRow.createCell(22).setCellValue(po.getValue14()) ;
		if(po.getValue15()!=null)
			tableRow.createCell(23).setCellValue(po.getValue15()) ;
		if(po.getValue16()!=null)
			tableRow.createCell(24).setCellValue(po.getValue16()) ;
		if(po.getValue17()!=null)
			tableRow.createCell(25).setCellValue(po.getValue17()) ;
		if(po.getValue18()!=null)
			tableRow.createCell(26).setCellValue(po.getValue18()) ;
		if(po.getValue19()!=null)
			tableRow.createCell(27).setCellValue(po.getValue19()) ;
		if(po.getValue20()!=null)
			tableRow.createCell(28).setCellValue(po.getValue20()) ;

		if(po.getAllBreakups()!=null && po.getAllBreakups().size()>0)
		{
			rowNo=writeAllPOBreakUps(po,sheet,rowNo);
		}


		return rowNo;
	}

	private int writeAllPOBreakUps(ParserOutput po, Sheet sheet, int rowNo) 
	{
		if(po.getAllBreakups()==null || po.getAllBreakups().size()<1)
			return rowNo;
		for(POBreakUps breakUp:po.getAllBreakups())
		{
			rowNo = rowNo+1;
			org.apache.poi.ss.usermodel.Row tableRow = sheet.createRow((short) rowNo) ;

			tableRow.createCell(0).setCellValue(po.getSection().toUpperCase()) ;
			tableRow.createCell(1).setCellValue("Associations") ;
			tableRow.createCell(2).setCellValue(po.getNotesColumn()) ;
			tableRow.createCell(3).setCellValue("Association") ;
			if(breakUp.getAsRepLabel()!=null)
			{
				tableRow.createCell(4).setCellValue(breakUp.getAsRepLabel()) ;
			}
			tableRow.createCell(5).setCellValue((""+(breakUp.getStartPg()+1)));
			tableRow.createCell(6).setCellValue((""+(breakUp.getEndPg()+1)));
			tableRow.createCell(7).setCellValue((""+breakUp.getStartPgX1()));
			tableRow.createCell(8).setCellValue((""+breakUp.getStartPgY1()));
			tableRow.createCell(9).setCellValue((""+breakUp.getEndPgX2()));
			tableRow.createCell(10).setCellValue((""+breakUp.getEndPgY2()));
		}
		return rowNo;
	}

	private String computeSheetName(String fileName)
	{
		String text = new String(fileName) ;
		text = text.contains("/") ? text.substring(text.lastIndexOf("/")+1) : text ;
		text = text.contains(".") ? text.substring(0, text.lastIndexOf(".")) : text ;

		text = text.replaceAll("[^a-zA-Z0-9]", " ").replaceAll("\\s+", " ").trim().replaceAll("\\s", "_").trim() ;

		text = text.length() > 30 ? text.substring(0, 30) : text ;

		return text ;
	}

	public String getOutputFileName() {
		return outputFileName;
	}

	public void setOutputFileName(String outputFileName) {
		this.outputFileName = outputFileName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}



	public static void main(String[] args) 
	{
		//String fileName = "E:/Office/AmEx-MF-Risk/Big-Sample-Set/BankSamples/Capital One/6 june prominent tickets.pdf" ;
		//String outputFileName = "output/dummy.xlsx" ;
		//	ExcelDataWriter edw = new ExcelDataWriter(outputFileName, fileName, "1234 5678 9012", "1st July, 2014", "31st July, 2014", 
		//			new TreeMap<TableIdentificationRule, List<Pair<List<Row>,List<Column>>>>()) ;
		//edw.run() ;
	}



}
