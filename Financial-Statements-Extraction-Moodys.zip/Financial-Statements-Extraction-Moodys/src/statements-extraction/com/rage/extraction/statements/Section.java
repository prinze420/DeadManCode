package com.rage.extraction.statements;

import java.util.List;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.extract.pdf.Row;
import com.rage.extraction.statements.reprocess.ReprocessMetadata;
import com.rage.extraction.statements.uitls.Utilities;

public class Section {
	private String sectionName;
	private String subSection;
	private String scope;
	private String parseValue;
	private TreeMap<Integer, List<Row>> pageRowsMap;
	private SectionStartMatch keyword;
	private ReprocessMetadata reprocessMeta;
	private Integer instanceID;
	private String matchedChunk;
	private List<PDFBlock> blocks;
	private Boolean isSubsidiary;
	private Integer colNo;

	public Section(Section other) {
		setSectionName(other.getSectionName());
		setLines(other.getLines());
		setKeyword(other.getKeyword());
		setReprocessMeta(other.getReprocessMeta());
		setBlocks(other.getBlocks());
		setPageRowsMap(other.pageRowsMap);
	}

	public List<PDFBlock> getBlocks() {
		return blocks;
	}

	public void setBlocks(List<PDFBlock> blocks) {
		this.blocks = blocks;
	}

	public ReprocessMetadata getReprocessMeta() {
		return reprocessMeta;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

	public TreeMap<Integer, List<Row>> getPageRowsMap() {
		return pageRowsMap;
	}

	
	public Integer getColNo() {
		return colNo;
	}

	public void setColNo(Integer colNo) {
		this.colNo = colNo;
	}

	public Boolean getIsSubsidiary() {
		return isSubsidiary;
	}

	public void setIsSubsidiary(Boolean isSubsidiary) {
		this.isSubsidiary = isSubsidiary;
	}

	public void setPageRowsMap(TreeMap<Integer, List<Row>> pageRowsMap) {
		this.pageRowsMap = pageRowsMap;
	}

	public String getParseValue() {
		return parseValue;
	}

	public void setParseValue(String parseValue) {
		this.parseValue = parseValue;
	}

	private List<PDFLine> lines;

	public String getSubSection() {
		return subSection;
	}

	public void setSubSection(String subSection) {
		this.subSection = subSection;
	}

	public void setReprocessMeta(ReprocessMetadata reprocessMeta) {
		this.reprocessMeta = reprocessMeta;
	}

	public Section(String name, List<PDFLine> lines, SectionStartMatch keyword,
			Integer instanceID, List<PDFBlock> blocks) {
		setSectionName(name);
		setLines(lines);
		setKeyword(keyword);
		setInstanceID(instanceID);
		setBlocks(blocks);

		/*
		 * setMatchedChunk(matchedChunk);
		 */}

	@Override
	public String toString() {
		return getSectionName().toUpperCase() + "\t" + Utilities.findMinPageNo(this) + "\t"
				+ Utilities.findMaxPageNo(this) + "\t"
				+ getKeyword().getKeyword();
	}

	public String getSectionName() {
		return sectionName;
	}

	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public SectionStartMatch getKeyword() {
		return keyword;
	}

	public void setKeyword(SectionStartMatch keyword) {
		this.keyword = keyword;
	}

	public Integer getInstanceID() {
		return instanceID;
	}

	public void setInstanceID(Integer instanceID) {
		this.instanceID = instanceID;
	}

	public String getMatchedChunk() {
		return matchedChunk;
	}

	public void setMatchedChunk(String matchedChunk) {
		this.matchedChunk = matchedChunk;
	}

}
