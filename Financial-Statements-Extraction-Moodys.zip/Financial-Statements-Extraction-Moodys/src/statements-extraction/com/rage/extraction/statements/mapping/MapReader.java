package com.rage.extraction.statements.mapping;

import com.rage.extraction.statements.train.TrainDataSet;
import com.rage.extraction.statements.train.Tree;


/**
 * @author kiran.umadi
 *
 */
public interface MapReader {
	public void train(String fileName) throws Exception;
	public TrainDataSet getDataSet();
	public Tree getTree();
	public String getTrainID();
	public void export(String fileName) throws Exception;
}
