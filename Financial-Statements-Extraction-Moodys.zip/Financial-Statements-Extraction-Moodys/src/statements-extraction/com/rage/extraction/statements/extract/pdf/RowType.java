package com.rage.extraction.statements.extract.pdf;

public enum RowType 
{
	ROW_TOTAL_START,
	ROW_TOTAL_END,
	ROW_TRANSACTION,
	ROW_NON_TRANSACTION,
	ROW_HEADING
}
