package com.rage.extraction.statements;

import com.rage.extraction.statements.extract.pdf.RowSegmentationType;

public class SectionStartMatch 
{
	private String name ;
	private String keyword ;
	private String line ;
	private String neighbouringText ;
	private String matchedChunk;
	private RowSegmentationType rowSegmentationType;
	private Integer columnNo;

	
	public SectionStartMatch(String name, String keyword, String line, String neighbouringText, RowSegmentationType rowSegmentType,Integer columnNo)
	{
		if(columnNo==null)
		columnNo=0;
		setName(name) ;
		setKeyword(keyword) ;
		setLine(line) ;
		setNeighbouringText(neighbouringText) ;
		setRowSegmentationType(rowSegmentType);
		setColumnNo(columnNo);
		//setMatchedChunk(matchedChunk) ;
	}
	
	public RowSegmentationType getRowSegmentationType() {
		return rowSegmentationType;
	}

	public void setRowSegmentationType(RowSegmentationType rowSegmentationType) {
		this.rowSegmentationType = rowSegmentationType;
	}

	@Override
	public String toString() 
	{
		return "[Section: " + getName() + " ;;;;; Keyword: " + getKeyword() + " ;;;;; Line: " + getLine() + " ;;;;; Neighbourhood Text: " + getNeighbouringText() + "]";
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getNeighbouringText() {
		return neighbouringText;
	}

	public void setNeighbouringText(String neighbouringText) {
		this.neighbouringText = neighbouringText;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public String getMatchedChunk() {
		return matchedChunk;
	}

	public void setMatchedChunk(String matchedChunk) {
		this.matchedChunk = matchedChunk;
	}

	public Integer getColumnNo() {
		return columnNo;
	}

	public void setColumnNo(Integer columnNo) {
		this.columnNo = columnNo;
	}
}
