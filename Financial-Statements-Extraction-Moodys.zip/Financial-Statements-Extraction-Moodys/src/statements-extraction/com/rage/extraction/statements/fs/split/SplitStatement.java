package com.rage.extraction.statements.fs.split;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.constant.DBConnection;
import com.rage.extraction.statements.constant.ReadLogProperties;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.fs.merge.MergeStatement;

public class SplitStatement {

	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MergeStatement.class);

	public static void main(String[] args)
	{
		long startTime = System.currentTimeMillis();
		long endTime;

		String filingID = "";
		String debug = "";
		//String section = "";
		Integer columnNumber = 0;
		String coordReqd="No";
		String language="";
		if(args.length>0)
		{
			filingID = args[0];
		}
		if(args.length>1)
		{
			debug = args[1];
		}
		if(args.length>2)
		{
			coordReqd = args[2];
		}
		if(args.length>3)
		{
			language = args[3].equalsIgnoreCase("English") ? "" : args[3].trim();
		}

		List<String> sections = MergeStatement.getDistictSections(filingID);
		TreeMap<String, ArrayList<ParserOutput>> mergedMap = new TreeMap<String, ArrayList<ParserOutput>>();

		if(sections.size()>0)
		{
			if(debug.equalsIgnoreCase("On"))
			{
				loadLogfile(filingID);
			}	
			for(String section :sections)
			{
				ArrayList<ParserOutput> poList = MergeStatement.loadExtractedItems(filingID,section,"split",coordReqd);
				if(poList.size()==0)
					continue;
				columnNumber = DataWriterOracle.getColumnNumber(poList.get(0).getTableID(),filingID);
				if(columnNumber==-1)
					continue;
				splitSectionColumns(filingID, section, columnNumber,poList);
				mergedMap.put(section, poList);
			}

		}
		/*if(debug.equalsIgnoreCase("On"))
		{
			loadLogfile(filingID);
		}
		TreeMap<String, ArrayList<ParserOutput>> mergedMap = new TreeMap<String, ArrayList<ParserOutput>>();
		 */

		if(!DBConnection.get_JDBC_DRIVER().toLowerCase().contains("oracle"))
		{
			DataWriterSql dw = new DataWriterSql() ;
			dw.writeTable(Integer.parseInt(filingID), mergedMap,false, null,true,coordReqd,language);
		}
		else
		{
			DataWriterOracle dw = new DataWriterOracle() ;
			dw.writeTable(Integer.parseInt(filingID), mergedMap,false, null,true,coordReqd,language);
		}
		endTime = System.currentTimeMillis();
		System.out.println("Total time taken: "+((endTime-startTime)/1000.)+" seconds.");
		if(logger!=null)
			logger.info(StringEscapeUtils.escapeJava("Total time taken: "+((endTime-startTime)/1000.)+" seconds."));
		if(logger!=null)
			logger.info(StringEscapeUtils.escapeJava("Split Statement Completed."));
	}




	public static  void splitSectionColumns(String filingID, String section,
			Integer columnNumber, ArrayList<ParserOutput> poList) {
		//TreeMap<String, ArrayList<ParserOutput>> mergedMap = new TreeMap<String, ArrayList<ParserOutput>>();

		if(poList.size()==0)
			System.exit(1);

		List<ParserOutput> poNewList = new ArrayList<ParserOutput>();
		for(ParserOutput po :poList)
		{
			ParserOutput poNew = new ParserOutput();

			switch(columnNumber)
			{
			case 2:
			{
				if(po.getValue2()!=null)
				{
					if(po.getAsRepLabel()!=null && po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepLabel(po.getValue2());
					}
					po.setValue2(null);
					po.setAsRepVal2(null);
				}

				if(po.getAsRepVal3()!=null && po.getValue3()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal1(po.getAsRepVal3());
						poNew.setValue1(po.getValue3());

						if(po.getVal3Coords()!=null)
						{
							poNew.setVal1Coords(po.getVal3Coords());	
						}
					}

					po.setValue3(null);
					po.setAsRepVal3(null);
				}
				if(po.getAsRepVal4()!=null && po.getValue4()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal2(po.getAsRepVal4());
						poNew.setValue2(po.getValue4());
						if(po.getVal4Coords()!=null)
						{
							poNew.setVal2Coords(po.getVal4Coords());	
						}
					}
					po.setValue4(null);
					po.setAsRepVal4(null);
				}
				if(po.getAsRepVal5()!=null && po.getValue5()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal3(po.getAsRepVal5());
						poNew.setValue3(po.getValue5());
						if(po.getVal5Coords()!=null)
						{
							poNew.setVal3Coords(po.getVal5Coords());	
						}
					}
					po.setValue5(null);
					po.setAsRepVal5(null);
				}

				if(po.getAsRepVal6()!=null && po.getValue6()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal4(po.getAsRepVal7());
						poNew.setValue4(po.getValue7());
						if(po.getVal6Coords()!=null)
						{
							poNew.setVal4Coords(po.getVal6Coords());	
						}
					}
					po.setValue6(null);
					po.setAsRepVal6(null);
				}
				if(po.getAsRepVal7()!=null && po.getValue7()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal5(po.getAsRepVal7());
						poNew.setValue5(po.getValue7());
					}
					if(po.getVal7Coords()!=null)
					{
						poNew.setVal5Coords(po.getVal7Coords());	
					}
					po.setValue7(null);
					po.setAsRepVal7(null);
				}
				if(po.getAsRepVal8()!=null && po.getValue8()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal6(po.getAsRepVal8());
						poNew.setValue6(po.getValue8());
						if(po.getVal8Coords()!=null)
						{
							poNew.setVal6Coords(po.getVal8Coords());	
						}
					}
					po.setValue8(null);
					po.setAsRepVal8(null);
				}
				if(po.getAsRepVal9()!=null && po.getValue9()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal7(po.getAsRepVal9());
						poNew.setValue7(po.getValue9());
						if(po.getVal9Coords()!=null)
						{
							poNew.setVal7Coords(po.getVal9Coords());	
						}
					}
					po.setValue9(null);
					po.setAsRepVal9(null);
				}
				if(po.getAsRepVal10()!=null && po.getValue10()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal8(po.getAsRepVal10());
						poNew.setValue8(po.getValue10());
						if(po.getVal10Coords()!=null)
						{
							poNew.setVal8Coords(po.getVal10Coords());	
						}
					}
					po.setValue10(null);
					po.setAsRepVal10(null);
				}
				break;
			}
			case 3:
			{
				if(po.getValue3()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepLabel(po.getValue3());
					}
					po.setValue3(null);
					po.setAsRepVal3(null);

				}

				if(po.getAsRepVal4()!=null && po.getValue4()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal1(po.getAsRepVal4());
						poNew.setValue1(po.getValue4());
						if(po.getVal4Coords()!=null)
						{
							poNew.setVal1Coords(po.getVal4Coords());	
						}
					}
					po.setValue4(null);
					po.setAsRepVal4(null);

				}
				if(po.getAsRepVal5()!=null && po.getValue5()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal2(po.getAsRepVal5());
						poNew.setValue2(po.getValue5());
						if(po.getVal5Coords()!=null)
						{
							poNew.setVal2Coords(po.getVal5Coords());	
						}
					}
					po.setValue5(null);
					po.setAsRepVal5(null);
				}
				if(po.getAsRepVal6()!=null && po.getValue6()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal3(po.getAsRepVal6());
						poNew.setValue3(po.getValue6());
						if(po.getVal6Coords()!=null)
						{
							poNew.setVal3Coords(po.getVal6Coords());	
						}
					}
					po.setValue6(null);
					po.setAsRepVal6(null);
				}
				if(po.getAsRepVal7()!=null && po.getValue7()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal4(po.getAsRepVal7());
						poNew.setValue4(po.getValue7());
						if(po.getVal7Coords()!=null)
						{
							poNew.setVal4Coords(po.getVal7Coords());	
						}
					}
					po.setValue7(null);
					po.setAsRepVal7(null);
				}
				if(po.getAsRepVal8()!=null && po.getValue8()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal5(po.getAsRepVal8());
						poNew.setValue5(po.getValue8());
						if(po.getVal8Coords()!=null)
						{
							poNew.setVal5Coords(po.getVal8Coords());	
						}
					}
					po.setValue8(null);
					po.setAsRepVal8(null);
				}
				if(po.getAsRepVal9()!=null && po.getValue9()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal6(po.getAsRepVal9());
						poNew.setValue6(po.getValue9());
						if(po.getVal9Coords()!=null)
						{
							poNew.setVal6Coords(po.getVal9Coords());	
						}
					}
					po.setValue9(null);
					po.setAsRepVal9(null);
				}
				if(po.getAsRepVal10()!=null && po.getValue10()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal7(po.getAsRepVal10());
						poNew.setValue7(po.getValue10());
						if(po.getVal10Coords()!=null)
						{
							poNew.setVal7Coords(po.getVal10Coords());	
						}
					}
					po.setValue10(null);
					po.setAsRepVal10(null);
				}
				break;
			}
			case 4:
			{
				if(po.getValue4()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepLabel(po.getValue4());
					}
					po.setValue4(null);
					po.setAsRepVal4(null);
				}

				if(po.getAsRepVal5()!=null && po.getValue5()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal1(po.getAsRepVal5());
						poNew.setValue1(po.getValue5());
						if(po.getVal5Coords()!=null)
						{
							poNew.setVal1Coords(po.getVal5Coords());	
						}
					}
					po.setValue5(null);
					po.setAsRepVal5(null);
				}
				if(po.getAsRepVal6()!=null && po.getValue6()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal2(po.getAsRepVal6());
						poNew.setValue2(po.getValue6());
						if(po.getVal6Coords()!=null)
						{
							poNew.setVal2Coords(po.getVal6Coords());	
						}
					}
					po.setValue6(null);
					po.setAsRepVal6(null);
				}
				if(po.getAsRepVal7()!=null && po.getValue7()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal3(po.getAsRepVal7());
						poNew.setValue3(po.getValue7());
						if(po.getVal7Coords()!=null)
						{
							poNew.setVal3Coords(po.getVal7Coords());	
						}
					}
					po.setValue7(null);
					po.setAsRepVal7(null);
				}
				if(po.getAsRepVal8()!=null && po.getValue8()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal4(po.getAsRepVal8());
						poNew.setValue4(po.getValue8());
						if(po.getVal8Coords()!=null)
						{
							poNew.setVal4Coords(po.getVal8Coords());	
						}
					}
					po.setValue8(null);
					po.setAsRepVal8(null);
				}
				if(po.getAsRepVal9()!=null && po.getValue9()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal5(po.getAsRepVal9());
						poNew.setValue5(po.getValue9());
						if(po.getVal9Coords()!=null)
						{
							poNew.setVal5Coords(po.getVal9Coords());	
						}
					}
					po.setValue9(null);
					po.setAsRepVal9(null);
				}
				if(po.getAsRepVal10()!=null && po.getValue10()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal6(po.getAsRepVal10());
						poNew.setValue6(po.getValue10());
						if(po.getVal10Coords()!=null)
						{
							poNew.setVal6Coords(po.getVal10Coords());	
						}
					}
					po.setValue10(null);
					po.setAsRepVal10(null);
				}
				if(po.getAsRepVal11()!=null && po.getValue11()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal7(po.getAsRepVal11());
						poNew.setValue7(po.getValue11());
						if(po.getVal11Coords()!=null)
						{
							poNew.setVal7Coords(po.getVal11Coords());	
						}
					}
					po.setValue11(null);
					po.setAsRepVal11(null);
				}
				break;
			}
			case 5:
			{
				if(po.getValue5()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepLabel(po.getValue5());
					}
					po.setValue5(null);
					po.setAsRepVal5(null);
				}

				if(po.getAsRepVal6()!=null && po.getValue6()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal1(po.getAsRepVal6());
						poNew.setValue1(po.getValue6());
						if(po.getVal6Coords()!=null)
						{
							poNew.setVal1Coords(po.getVal6Coords());	
						}
					}
					po.setValue6(null);
					po.setAsRepVal6(null);
				}
				if(po.getAsRepVal7()!=null && po.getValue7()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal2(po.getAsRepVal7());
						poNew.setValue2(po.getValue7());
						if(po.getVal7Coords()!=null)
						{
							poNew.setVal2Coords(po.getVal7Coords());	
						}
					}
					po.setValue7(null);
					po.setAsRepVal7(null);
				}
				if(po.getAsRepVal8()!=null && po.getValue8()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal3(po.getAsRepVal8());
						poNew.setValue3(po.getValue8());
						if(po.getVal8Coords()!=null)
						{
							poNew.setVal3Coords(po.getVal8Coords());	
						}
					}
					po.setValue8(null);
					po.setAsRepVal8(null);
				}
				if(po.getAsRepVal9()!=null && po.getValue9()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal4(po.getAsRepVal9());
						poNew.setValue4(po.getValue9());
						if(po.getVal9Coords()!=null)
						{
							poNew.setVal4Coords(po.getVal9Coords());	
						}
					}
					po.setValue9(null);
					po.setAsRepVal9(null);
				}
				if(po.getAsRepVal10()!=null && po.getValue10()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal5(po.getAsRepVal10());
						poNew.setValue5(po.getValue10());
						if(po.getVal10Coords()!=null)
						{
							poNew.setVal5Coords(po.getVal10Coords());	
						}
					}
					po.setValue10(null);
					po.setAsRepVal10(null);
				}
				if(po.getAsRepVal11()!=null && po.getValue11()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal6(po.getAsRepVal11());
						poNew.setValue6(po.getValue11());
						if(po.getVal11Coords()!=null)
						{
							poNew.setVal6Coords(po.getVal11Coords());	
						}
					}
					po.setValue11(null);
					po.setAsRepVal11(null);
				}
				if(po.getAsRepVal12()!=null && po.getValue12()!=null)
				{
					if(po.getAsRepLabel()!=null && !po.getAsRepLabel().startsWith("STATEMENT"))
					{
						poNew.setAsRepVal7(po.getAsRepVal12());
						poNew.setValue7(po.getValue12());
						if(po.getVal12Coords()!=null)
						{
							poNew.setVal7Coords(po.getVal12Coords());	
						}
					}
					po.setValue12(null);
					po.setAsRepVal12(null);
				}
				break;
			}

			}
			po.setIsSplit(true);
			poNew.setIsSplit(po.getIsSplit());
			poNew.setPageNo(po.getPageNo());
			poNew.setyCoords(po.getyCoords());
			poNew.setSection(po.getSection());
			poNew.setSubSection(po.getSection());
			if(po!=null && po.getLineNo()!=null)
			poNew.setLineNo(po.getLineNo());
			if(po.getPdfLine()!=null)
				poNew.setPdfLine(po.getPdfLine());
			poNew.setType(po.getType());
			if(po.getLine()!=null)
				poNew.setLine(po.getLine());
			poNewList.add(poNew);
		}

		poList.addAll(poNewList);
	}




	private static void loadLogfile(String filingID)
	{
		ReadLogProperties rlp = new ReadLogProperties();
		try {
			rlp.ReadLogPropertiesFile(filingID,"resource/Statement-Merge-Log4j.Properties");
		} catch (Exception e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
	}
}
