package com.rage.extraction.statements.fs.merge;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.constant.DBConnection;
import com.rage.extraction.statements.constant.ReadLogProperties;
import com.rage.extraction.statements.db.CoordinateDetails;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.uitls.LongestCommonSubstring;

public class MergeStatement extends MergeUtils
{
	private List<ParserOutput> objList;
	private List<List<ParserOutput>> stmt;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MergeStatement.class);

	private static Connection con = DBConnection.openConnection("LIVESPREAD");
	public MergeStatement()
	{
		objList=new ArrayList<ParserOutput>();
		stmt=new ArrayList<List<ParserOutput>>();
	}

	public List<ParserOutput> merge(ArrayList<ParserOutput> poList)
	{
		List<Integer> stmtIndex=getStatementStartIndex(poList);
		if (stmtIndex.size()>1)
		{
			objList=poList;
			stmt=breakStatements(stmtIndex);
			objList=mergeMappedStmt();
			resetIndexOrder(objList);
		} else
			return poList;
		return objList;
	}

	public List<ParserOutput> resetIndexOrder(List<ParserOutput> objList)
	{
		int order=0;
		for (ParserOutput po:objList)
		{
			order+=10;
			po.setIndexOrder(order);
			po.setBreakups("N");
			po.setMark("N");
		}
		return objList;
	}

	public List<ParserOutput> mergeMappedStmt()
	{
		int maxColumn=-1, count=-1;
		List<ParserOutput> first=null;
		// Inner boundary
		for (List<ParserOutput> poStmt:stmt)
		{
			if (first!=null)
			{
				count++;
				maxColumn=getMaxColumn(first);
				int maxColumnNext=getMaxColumn(poStmt);
				for (ParserOutput po1:first)
				{
					for (ParserOutput po2:poStmt)
					{
						if (matchLabels(po1,po2,"Inner") || matchLabels(po1,po2,"Outer"))
						{
							mapValues(maxColumn+1, maxColumnNext, po1, po2);
							break;
						}
					}
				}
			}
			if (count==-1)
				first=poStmt;
		}
		// new items insertion
		count=-1;
		first=null;
		for (List<ParserOutput> poStmt:stmt)
		{
			if (first!=null)
			{
				count++;
				maxColumn=getMaxColumn(first);
				int maxColumnNext=getMaxColumn(poStmt);
				for (int i=0; i<first.size(); i++)
				{
					ParserOutput po1=first.get(i);
					for (ParserOutput po2:poStmt)
					{
						/*if (po2.getBreakups().equals("N"))
							insertParserOutputObject(first, po2);*/
						if (po2.getBreakups().equals("C"))
							if (matchLabels(po1,po2, "Outer"))
								mapValues(maxColumn+1, maxColumnNext, po1, po2);
					}
				}
			}
			if (count==-1)
				first=poStmt;
		}
		return first;
	}

	public String cleanLabel(String str)
	{

		if (str==null)
			return str;
		if (str.trim().equals(""))
			return str;
		List<String> items=new ArrayList<String>();
		items.add("by");
		items.add("and");
		items.add("of");
		items.add("in");
		items.add("on");
		items.add("from");
		items.add("for");
		items.add("provided");
		items.add("used");
		items.add("increase");
		items.add("decrease");
		items.add("&");
		str=str.replaceAll("[(/)]", " ");
		str=str.replaceAll("[^a-z A-Z]", "").toUpperCase();
		for (String item:items)
			str=str.replaceAll(" "+item.toUpperCase()+" ", " ");
		return str;
	}

	public boolean matchLabels(ParserOutput po1, ParserOutput po2, String boundaryType)
	{
		if (po1.getAsRepLabel()==null || po2.getAsRepLabel()==null)
			return false;
		if (po2.getMark().equals("Y"))
			return false;
		String str1=cleanLabel(po1.getAsRepLabel());
		String str2=cleanLabel(po2.getAsRepLabel());
		if (boundaryType.equals("Inner"))
		{
			if (po1.getSubSection()==null && po2.getSubSection()==null && po1.getSubtotal().equals(po2.getSubtotal()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
			} else if (po1.getSubSection().equals(po2.getSubSection()) && po1.getSubtotal().equals(po2.getSubtotal()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
				else
				{
					String[] strArr=str1.split("\\s");
					String[] strArr1=str2.split("\\s");
					int max=Math.max(strArr.length, strArr1.length);
					if ((wordMatch(str1, str2)/max)*100>90)
						return true;
					else
					{
						if (LCS(str1,str2)>=80)
							return true;
					}
				}
			}
		} else
		{
			if (po1.getSubSection()==null && po2.getSubSection()==null)
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
			} else if (po1.getSubSection().equals(po2.getSubSection()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
				else
				{
					String[] strArr=str1.split("\\s");
					String[] strArr1=str2.split("\\s");
					int max=Math.max(strArr.length, strArr1.length);
					if ((wordMatch(str1, str2)/max)*100>90)
						return true;
					else
					{
						if (LCS(str1,str2)>=80)
							return true;
					}
				}
			}
		}
		return false;
	}

	public double LCS(String str1, String str2)
	{
		LongestCommonSubstring matcher = new LongestCommonSubstring(str1.toUpperCase(), str2.toUpperCase());
		double sMatch = matcher.findMaxStringMatch();
		double s = sMatch/(str1.length()) * sMatch/(str2.length());
		return s*100;
	}

	public int wordMatch(String str1, String str2)
	{
		if (str1.equals("") || str1==null || str2.equals("") || str2==null)
			return -1;
		int matchCount=0, max=-1;
		String[] arrStr1=str1.trim().replaceAll("[^a-zA-Z 0-9]", "").split("\\s");
		String[] arrStr2=str2.trim().replaceAll("[^a-zA-Z 0-9]", "").split("\\s");

		max=Math.max(arrStr1.length, arrStr2.length);
		for(int i=0; i<max; i++)
		{
			if (i<arrStr1.length && i<arrStr2.length)
			{
				if (arrStr1[i].equalsIgnoreCase(arrStr2[i]))
					matchCount++;
			}
		}
		return matchCount;
	}

	public String getNextValue(int start,  ParserOutput po)
	{
		switch(start)
		{
		case 1:
			return po.getValue1();
		case 2:
			return po.getValue2();
		case 3:
			return po.getValue3();
		case 4:
			return po.getValue4();
		case 5:
			return po.getValue5();
		case 6:
			return po.getValue6();
		case 7:
			return po.getValue7();
		case 8:
			return po.getValue8();
		case 9:
			return po.getValue9();
		case 10:
			return po.getValue10();
		case 11:
			return po.getValue11();
		case 12:
			return po.getValue12();
		case 13:
			return po.getValue13();
		case 14:
			return po.getValue14();
		case 15:
			return po.getValue15();
		case 16:
			return po.getValue16();
		case 17:
			return po.getValue17();
		case 18:
			return po.getValue18();
		case 19:
			return po.getValue19();
		case 20:
			return po.getValue20();
		case 21:
			return po.getValue21();
		case 22:
			return po.getValue22();
		case 23:
			return po.getValue23();
		case 24:
			return po.getValue24();
		case 25:
			return po.getValue25();
		case 26:
			return po.getValue26();
		case 27:
			return po.getValue27();
		case 28:
			return po.getValue28();
		case 29:
			return po.getValue29();
		case 30:
			return po.getValue30();
		}
		return "";
	}

	public String getNextAsRepValue(int start,  ParserOutput po)
	{
		switch(start)
		{
		case 1:
			return po.getAsRepVal1();
		case 2:
			return po.getAsRepVal2();
		case 3:
			return po.getAsRepVal3();
		case 4:
			return po.getAsRepVal4();
		case 5:
			return po.getAsRepVal5();
		case 6:
			return po.getAsRepVal6();
		case 7:
			return po.getAsRepVal7();
		case 8:
			return po.getAsRepVal8();
		case 9:
			return po.getAsRepVal9();
		case 10:
			return po.getAsRepVal10();
		case 11:
			return po.getAsRepVal11();
		case 12:
			return po.getAsRepVal12();
		case 13:
			return po.getAsRepVal13();
		case 14:
			return po.getAsRepVal14();
		case 15:
			return po.getAsRepVal15();
		case 16:
			return po.getAsRepVal16();
		case 17:
			return po.getAsRepVal17();
		case 18:
			return po.getAsRepVal18();
		case 19:
			return po.getAsRepVal19();
		case 20:
			return po.getAsRepVal20();
		case 21:
			return po.getAsRepVal21();
		case 22:
			return po.getAsRepVal22();
		case 23:
			return po.getAsRepVal23();
		case 24:
			return po.getAsRepVal24();
		case 25:
			return po.getAsRepVal25();
		case 26:
			return po.getAsRepVal26();
		case 27:
			return po.getAsRepVal27();
		case 28:
			return po.getAsRepVal28();
		case 29:
			return po.getAsRepVal29();
		case 30:
			return po.getAsRepVal30();
		}
		return "";
	}

	public void mapValues(int startPoint, int maxColObj2, ParserOutput po1, ParserOutput po2)
	{
		if (po2.getMark().equals("Y"))
			return;
		int valPos=1;
		for (int i=startPoint; i<startPoint+maxColObj2; i++)
		{
			switch(i)
			{
			case 1:
				break;
			case 2:
			{
				po1.setAsRepVal2(getNextAsRepValue(valPos, po2));
				po1.setValue2(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 3:
			{
				po1.setAsRepVal3(getNextAsRepValue(valPos, po2));
				po1.setValue3(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 4:
			{
				po1.setAsRepVal4(getNextAsRepValue(valPos, po2));
				po1.setValue4(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 5:
			{
				po1.setAsRepVal5(getNextAsRepValue(valPos, po2));
				po1.setValue5(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 6:
			{
				po1.setAsRepVal6(getNextAsRepValue(valPos, po2));
				po1.setValue6(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 7:
			{
				po1.setAsRepVal7(getNextAsRepValue(valPos, po2));
				po1.setValue7(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 8:
			{
				po1.setAsRepVal8(getNextAsRepValue(valPos, po2));
				po1.setValue8(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 9:
			{
				po1.setAsRepVal9(getNextAsRepValue(valPos, po2));
				po1.setValue9(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 10:
			{
				po1.setAsRepVal10(getNextAsRepValue(valPos, po2));
				po1.setValue10(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 11:
			{
				po1.setAsRepVal11(getNextAsRepValue(valPos, po2));
				po1.setValue11(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 12:
			{
				po1.setAsRepVal12(getNextAsRepValue(valPos, po2));
				po1.setValue12(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 13:
			{
				po1.setAsRepVal13(getNextAsRepValue(valPos, po2));
				po1.setValue13(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 14:
			{
				po1.setAsRepVal14(getNextAsRepValue(valPos, po2));
				po1.setValue14(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 15:
			{
				po1.setAsRepVal15(getNextAsRepValue(valPos, po2));
				po1.setValue15(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 16:
			{
				po1.setAsRepVal16(getNextAsRepValue(valPos, po2));
				po1.setValue16(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 17:
			{
				po1.setAsRepVal17(getNextAsRepValue(valPos, po2));
				po1.setValue17(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 18:
			{
				po1.setAsRepVal18(getNextAsRepValue(valPos, po2));
				po1.setValue18(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 19:
			{
				po1.setAsRepVal19(getNextAsRepValue(valPos, po2));
				po1.setValue19(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 20:
			{
				po1.setAsRepVal20(getNextAsRepValue(valPos, po2));
				po1.setValue20(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 21:
			{
				po1.setAsRepVal21(getNextAsRepValue(valPos, po2));
				po1.setValue21(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 22:
			{
				po1.setAsRepVal22(getNextAsRepValue(valPos, po2));
				po1.setValue22(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 23:
			{
				po1.setAsRepVal23(getNextAsRepValue(valPos, po2));
				po1.setValue23(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 24:
			{
				po1.setAsRepVal24(getNextAsRepValue(valPos, po2));
				po1.setValue24(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 25:
			{
				po1.setAsRepVal25(getNextAsRepValue(valPos, po2));
				po1.setValue25(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 26:
			{
				po1.setAsRepVal26(getNextAsRepValue(valPos, po2));
				po1.setValue26(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 27:
			{
				po1.setAsRepVal27(getNextAsRepValue(valPos, po2));
				po1.setValue27(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 28:
			{
				po1.setAsRepVal28(getNextAsRepValue(valPos, po2));
				po1.setValue28(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 29:
			{
				po1.setAsRepVal29(getNextAsRepValue(valPos, po2));
				po1.setValue29(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 30:
			{
				po1.setAsRepVal30(getNextAsRepValue(valPos, po2));
				po1.setValue30(getNextValue(valPos, po2));
				po2.setBreakups("Y");
				po2.setMark("Y");
				valPos++;
				break;
			}

			}
		}
	}

	/*	public void mapSubSections(List<ParserOutput> poStmt)
	{
		if (poStmt.size()>0)
		{
			String section=getSectionName(poStmt);
			List<BrokerMasterRules> sectionRule=getSectionMergeRules(section, mergeRule);
			List<String> subSecList=getSubSectionList(sectionRule);
			for (String subSec:subSecList)
			{
				int start=-1, end=-1;
				start=markBoundary(subSec, sectionRule, poStmt, "Begin");
				if (start!=-1)
					end=markBoundary(subSec, sectionRule, poStmt, "End");
				if (start!=-1 && end!=-1)
					markBoundaryItems(start, end, poStmt, subSec);
			}
		}
	}
	 */
	public ParserOutput createItemLabel(ParserOutput po)
	{
		ParserOutput poNew=new ParserOutput();
		poNew.setStmt_id(po.getStmt_id());
		poNew.setID(po.getID());
		poNew.setAsRepLabel(po.getAsRepLabel());
		poNew.setIndexOrder(po.getIndexOrder());
		poNew.setSection(po.getSection());
		poNew.setSubSection(po.getSubSection());
		po.setBreakups("C");
		return poNew;
	}



	public void markInnerBoundaries(List<ParserOutput> poStmt)
	{
		int markBoundary=0;
		for (ParserOutput po:poStmt)
		{
			po.setSubtotal(String.valueOf(markBoundary));
			if (po.getAsRepLabel()==null)
				continue;
			if ((po.getAsRepLabel().toLowerCase().startsWith("total")
					|| po.getAsRepLabel().toLowerCase().startsWith("net ")
					|| po.getAsRepLabel().toLowerCase().startsWith("net cash from"))
					&& !po.getAsRepLabel().equalsIgnoreCase("net income"))
				markBoundary++;
		}
	}

	public int getInnerBoundaries(List<ParserOutput> poStmt, String subtotal, String boundaryOf)
	{
		int index=-1;
		for (ParserOutput po:poStmt)
		{
			index++;
			if (po.getAsRepLabel()==null)
				continue;
			if (po.getSubtotal()==null || po.getAsRepLabel().startsWith("STATEMENT"))
				continue;
			if (boundaryOf.equals("Start") && po.getSubtotal().equals(String.valueOf(subtotal)))
				return index;
			if (boundaryOf.equals("End") && po.getSubtotal().equals(String.valueOf(Integer.parseInt(subtotal)+1)))
				return index-1;
		}
		return -1;
	}

	public void markBoundaryItems(int start, int end, List<ParserOutput> poStmt, String subSection)
	{
		for (int i=start; i<=end; i++)
		{
			ParserOutput po=poStmt.get(i);
			if (po.getSubSection().equals("NA") || po.getSubSection()==null)
				po.setSubSection(subSection);
		}
	}

	public List<List<ParserOutput>> breakStatements(List<Integer> stmtIndex)
	{
		List<List<ParserOutput>> st=new ArrayList<List<ParserOutput>>();
		int start=-1, end=-1;
		for (Integer index:stmtIndex)
		{
			if (start!=-1 && end==-1)
				end=index.intValue();
			if (start==-1)
				start=index.intValue();
			if (start!=-1 && end!=-1 && end>start)
			{
				st.add(resetIndexOrder(getStatement(start, end-1)));
				start=index.intValue();
				end=-1;
			}
		}
		st.add(resetIndexOrder(getStatement(start, objList.size()-1)));
		return st;
	}


	public synchronized static ArrayList<ParserOutput> loadExtractedItems(final String filingId, String section,String splitMerge,String coOrdRequired) 
	{
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		PreparedStatement pStmt = null;
		ParserOutput po = null;
		Connection con = null;
		con = DBConnection.openConnection("LIVESPREAD");
		ArrayList<CoordinateDetails> coordDetails = null;
		if(coOrdRequired.equalsIgnoreCase("Yes"))
			coordDetails = getCoordDetails(filingId, section, con);

		String sql = "";
		try
		{
			if(con!=null)
			{
				con.setAutoCommit(false);
				if(con!=null)
				{
					if(!splitMerge.contains("split"))
					{
						sql =	"select po_id, po_section,po_subsection, po_index_order, po_as_rep_label "+// po_val1, po_val2, po_val3, po_val4, po_val5, po_val6, po_val7, po_val8, po_val9, po_val10, po_val11, po_val12, po_val13, po_val14, po_val15, po_val16, po_val17,po_val18, po_val19, po_val20 from parser_output where filing_id = ? and po_section = ? and po_merge = ? order by po_section, po_index_order";
								", po_as_rep_val1, po_val1, po_as_rep_val2, po_val2, po_as_rep_val3, po_val3, po_as_rep_val4, po_val4, po_as_rep_val5, po_val5, po_as_rep_val6, po_val6, po_as_rep_val7, po_val7, po_as_rep_val8, po_val8, po_as_rep_val9, po_val9,po_as_rep_val10, po_val10,"+
								"po_as_rep_val11,po_val11, po_as_rep_val12, po_val12, po_as_rep_val13, po_val13, po_as_rep_val14, po_val14, po_as_rep_val15, po_val15, po_as_rep_val16, po_val16, po_as_rep_val17, po_val17, po_as_rep_val18, po_val18, po_as_rep_val19, po_val19,po_as_rep_val20, po_val20,po_table_id,po_ycoordinates,page_no,non_english_label,fi_label,ni_item,nil_label,fi_id,po_note,po_mergent,ref_po_id from parser_output where filing_id = ? and po_section = ? and po_merge = ? order by po_section, po_id";
					}
					else
					{
						sql =	"select po_id, po_section,po_subsection, po_index_order, po_as_rep_label "+// po_val1, po_val2, po_val3, po_val4, po_val5, po_val6, po_val7, po_val8, po_val9, po_val10, po_val11, po_val12, po_val13, po_val14, po_val15, po_val16, po_val17,po_val18, po_val19, po_val20 from parser_output where filing_id = ? and po_section = ? and po_merge = ? order by po_section, po_index_order";
								", po_as_rep_val1, po_val1, po_as_rep_val2, po_val2, po_as_rep_val3, po_val3, po_as_rep_val4, po_val4, po_as_rep_val5, po_val5, po_as_rep_val6, po_val6, po_as_rep_val7, po_val7, po_as_rep_val8, po_val8, po_as_rep_val9, po_val9,po_as_rep_val10, po_val10,"+
								"po_as_rep_val11,po_val11, po_as_rep_val12, po_val12, po_as_rep_val13, po_val13, po_as_rep_val14, po_val14, po_as_rep_val15, po_val15, po_as_rep_val16, po_val16, po_as_rep_val17, po_val17, po_as_rep_val18, po_val18, po_as_rep_val19, po_val19,po_as_rep_val20, po_val20,po_table_id,po_ycoordinates,page_no,non_english_label,fi_label,ni_item,nil_label,fi_id,po_mergent,ref_po_id from parser_output where filing_id = ? and po_section = ? and po_split = ? order by po_section, po_id";
					}


					pStmt = con.prepareStatement(sql);
					pStmt.setInt(1, Integer.parseInt(filingId));
					pStmt.setString(2, section);
					pStmt.setString(3, "Y");

					final ResultSet rs = pStmt.executeQuery();
					while(rs.next())
					{
						po = new ParserOutput();
						po.setID(rs.getLong("po_id"));
						po.setSection(rs.getString("po_section"));
						po.setSubSection(rs.getString("po_subsection"));
						po.setIndexOrder(rs.getInt("po_index_order"));
						po.setAsRepLabel(rs.getString("po_as_rep_label"));
						po.setValue1(rs.getString("po_val1"));
						po.setAsRepVal1(rs.getString("po_as_rep_val1"));
						po.setValue2(rs.getString("po_val2"));
						po.setAsRepVal2(rs.getString("po_as_rep_val2"));

						po.setValue3(rs.getString("po_val3"));
						po.setAsRepVal3(rs.getString("po_as_rep_val3"));

						po.setValue4(rs.getString("po_val4"));
						po.setAsRepVal4(rs.getString("po_as_rep_val4"));

						po.setValue5(rs.getString("po_val5"));
						po.setAsRepVal5(rs.getString("po_as_rep_val5"));


						po.setValue6(rs.getString("po_val6"));
						po.setAsRepVal6(rs.getString("po_as_rep_val6"));

						po.setValue7(rs.getString("po_val7"));
						po.setAsRepVal7(rs.getString("po_as_rep_val7"));

						po.setValue8(rs.getString("po_val8"));
						po.setAsRepVal8(rs.getString("po_as_rep_val8"));

						po.setValue9(rs.getString("po_val9"));
						po.setAsRepVal9(rs.getString("po_as_rep_val9"));

						po.setValue10(rs.getString("po_val10"));
						po.setAsRepVal10(rs.getString("po_as_rep_val10"));

						po.setValue11(rs.getString("po_val11"));
						po.setAsRepVal11(rs.getString("po_as_rep_val11"));

						po.setValue12(rs.getString("po_val12"));
						po.setAsRepVal12(rs.getString("po_as_rep_val12"));

						po.setValue13(rs.getString("po_val13"));
						po.setAsRepVal13(rs.getString("po_as_rep_val13"));

						po.setValue14(rs.getString("po_val14"));
						po.setAsRepVal14(rs.getString("po_as_rep_val14"));

						po.setValue15(rs.getString("po_val15"));
						po.setAsRepVal15(rs.getString("po_as_rep_val15"));

						po.setValue16(rs.getString("po_val16"));
						po.setAsRepVal16(rs.getString("po_as_rep_val16"));

						po.setValue17(rs.getString("po_val17"));
						po.setAsRepVal17(rs.getString("po_as_rep_val17"));

						po.setValue18(rs.getString("po_val18"));
						po.setAsRepVal18(rs.getString("po_as_rep_val18"));

						po.setValue19(rs.getString("po_val19"));
						po.setAsRepVal19(rs.getString("po_as_rep_val19"));

						po.setValue20(rs.getString("po_val20"));
						po.setAsRepVal20(rs.getString("po_as_rep_val20"));

						po.setPageNo(rs.getInt("page_no"));
						po.setTableID(rs.getInt("po_table_id"));
						po.setyCoords(rs.getFloat("po_ycoordinates"));
						po.setNonEnglishLabel(rs.getString("non_english_label"));
						po.setFiLabel(rs.getString("fi_label"));
						po.setNiItem(rs.getString("ni_item"));
						po.setNilLabel(rs.getString("nil_label"));
						po.setFiID(rs.getString("fi_id"));
						po.setNotesColumn(rs.getString("po_note"));
						//
						po.setBreakupExtracted(rs.getString("po_mergent"));
						po.setRef_Po_id(rs.getLong("ref_Po_id"));
						poObjects.add(po);
					}
					if(pStmt!=null)
					{
						pStmt.close();
					}
					if(rs!=null)
					{
						rs.close();
					}
				}
			}

		} catch (SQLException e)
		{
			if(logger!=null)
			{
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(sql)));
				logger.error(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			}

		}
		try {
			if(pStmt!=null)
			{
				pStmt.close();
			}

			if(con!=null)
			{
				con.commit();
				con.close();
			}
		} catch (SQLException e) {
			if(logger!=null)
			{
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(sql)));
				logger.error(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			}

		}


		if(coordDetails!=null && coordDetails.size()>0 && poObjects.size()>0)
			setCoordsinParserOutput(poObjects, coordDetails);



		return poObjects;
	}

	private static void setCoordsinParserOutput(
			ArrayList<ParserOutput> poObjects,
			ArrayList<CoordinateDetails> coordDetails) {
		ParserOutput po;
		for(int i=0;i<poObjects.size();i++)
		{
			po = poObjects.get(i);
			for(int j=0;j<coordDetails.size();j++)
			{
				CoordinateDetails co = coordDetails.get(j);
				if(po.getID()==co.getPoID().intValue())
				{
					po.setVal1Coords(co.getCoordDetailVal1());
					po.setVal2Coords(co.getCoordDetailVal2());
					po.setVal3Coords(co.getCoordDetailVal3());
					po.setVal4Coords(co.getCoordDetailVal4());
					po.setVal5Coords(co.getCoordDetailVal5());
					po.setVal6Coords(co.getCoordDetailVal6());
					po.setVal7Coords(co.getCoordDetailVal7());
					po.setVal8Coords(co.getCoordDetailVal8());
					po.setVal9Coords(co.getCoordDetailVal9());
					po.setVal10Coords(co.getCoordDetailVal10());

				}
			}
		}
	}

	private static ArrayList<CoordinateDetails> getCoordDetails(final String filingId,
			String section,  Connection con) {
		String sqlCoordRow = "select po_id,cord_details_val1,cord_details_val2,cord_details_val3,cord_details_val4,cord_details_val5,cord_details_val6,cord_details_val7,cord_details_val8,cord_details_val9,cord_details_val10 from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ? and po_section =?";
		PreparedStatement pStmt = null;
		CoordinateDetails cd  = null;
		ArrayList<CoordinateDetails> coordDetails = new ArrayList<CoordinateDetails>();
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sqlCoordRow);
				pStmt.setInt(1, Integer.parseInt(filingId));
				pStmt.setString(2, section);

				final ResultSet rs = pStmt.executeQuery();
				while(rs.next())
				{
					cd = new CoordinateDetails();
					cd.setPoID(rs.getLong("po_id"));
					cd.setSection(section);
					cd.setStmtID(Integer.parseInt(filingId));
					cd.setCoordDetailVal1(rs.getString("cord_details_val1"));
					cd.setCoordDetailVal2(rs.getString("cord_details_val2"));
					cd.setCoordDetailVal3(rs.getString("cord_details_val3"));
					cd.setCoordDetailVal4(rs.getString("cord_details_val4"));
					cd.setCoordDetailVal5(rs.getString("cord_details_val5"));
					cd.setCoordDetailVal6(rs.getString("cord_details_val6"));
					cd.setCoordDetailVal7(rs.getString("cord_details_val7"));
					cd.setCoordDetailVal8(rs.getString("cord_details_val8"));
					cd.setCoordDetailVal9(rs.getString("cord_details_val9"));
					cd.setCoordDetailVal10(rs.getString("cord_details_val10"));
					coordDetails.add(cd);
				}

				if(rs!=null)
					rs.close();
			} catch (SQLException e) {
				if(logger!=null)
				{
					logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(sqlCoordRow)));
					logger.error(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				}
				e.getMessage();

			}

			try {
				if(pStmt!=null)
					pStmt.close();
			} catch (SQLException e) {
				if(logger!=null)
				{
					logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(sqlCoordRow)));
					logger.error(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				}
				e.getMessage();

			}
		}
		return coordDetails;
	}

	public List<ParserOutput> getStatement(int start, int end)
	{
		List<ParserOutput> st = new ArrayList<ParserOutput>();
		if (objList.size()>0)
		{
			for (int i=start; i<=end; i++)
				st.add(objList.get(i));
		}
		return st;
	}


	/** Get Distinct sections from parser output for a particular document
	 * 
	 * @throws SQLException
	 */


	public static synchronized List<String> getDistictSections(final String fileID) 
	{
		String sql = "";
		PreparedStatement pStmt = null;
		final Connection con =  MergeStatement.getCon();
		List<String> sections = new ArrayList<String>();
		ResultSet rs =null;
		try {
			sql ="select DISTINCT(po_section) from parser_output where filing_id = ? order by po_section";
			if(con!=null)
			{
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setInt(1, Integer.parseInt(fileID));
				rs = pStmt.executeQuery();
				while(rs.next())
				{
					sections.add(rs.getString("po_section"));
				}

				if(pStmt!=null)
				{
					pStmt.close();
				}
				if(rs!=null)
				{
					rs.close();
				}
				if(con!=null)
				{
					con.commit();
				}
			}
		} catch (SQLException e1) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e1.getMessage())));
			}

		}
		return sections;
	}



	public static Connection getCon() {
		return con;
	}

	public static void setCon(Connection con) {
		MergeStatement.con = con;
	}


	private static void loadLogfile(String filingID)
	{
		ReadLogProperties rlp = new ReadLogProperties();
		try {
			rlp.ReadLogPropertiesFile(filingID,"resource/Statement-Merge-Log4j.Properties");
		} catch (Exception e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
	}

	public static void main(String args[]){
		long startTime = System.currentTimeMillis();
		long endTime;

		String filingID = "";
		String debug = "";
		String coordReqd = "No";
		String language = "English";
		if(args.length>0)
		{
			filingID = args[0];
		}
		if(args.length>1)
		{
			debug = args[1];
		}

		if(args.length>2)
		{
			coordReqd = args[2];
		}

		if(args.length>3)
		{
			language = args[3].equalsIgnoreCase("English") ? "" : args[3].trim();
		}
		List<String> sections = getDistictSections(filingID);
		if(sections.size()>0)
		{

			if(debug.equalsIgnoreCase("On"))
			{
				loadLogfile(filingID);
			}	
			TreeMap<String, ArrayList<ParserOutput>> mergedMap = new TreeMap<String, ArrayList<ParserOutput>>();
			//Boolean singleStmtFound = false;
			for(String section :sections)
			{
				ArrayList<ParserOutput> poList = loadExtractedItems(filingID,section,"merge",coordReqd);
				if(poList.size()==0)
					continue;
				RecursiveMergeStatement merge = new RecursiveMergeStatement();
				poList = merge.merge(poList);
				mergedMap.put(section, poList);
			}

			System.out.println("\n\n\nWriting into db ... ") ;

			if(!DBConnection.get_JDBC_DRIVER().toLowerCase().contains("oracle"))
			{
				if(mergedMap!=null && mergedMap.size()>0)
				{
					DataWriterSql dw = new DataWriterSql() ;
					dw.writeTable(Integer.parseInt(filingID), mergedMap,true, null,false,coordReqd,language);
				}
			}
			else
			{
				if(mergedMap!=null && mergedMap.size()>0)
				{
					DataWriterOracle dw = new DataWriterOracle() ;
					dw.writeTable(Integer.parseInt(filingID), mergedMap,true, null,false,coordReqd,language);
				}
			}

			try {
				if(con!=null)
				{
					con.commit();
					con.close();
				}
			} catch (SQLException e) {
				logger.error(e.getMessage());
			}
		}
		else
		{
			logger.info("No Data in parser_ouput");
		}

		endTime = System.currentTimeMillis();
		System.out.println("Total time taken: "+((endTime-startTime)/1000.)+" seconds.");
		if(logger!=null)
			logger.info(StringEscapeUtils.escapeJava("Total time taken: "+((endTime-startTime)/1000.)+" seconds."));
		if(logger!=null)
			logger.info(StringEscapeUtils.escapeJava("Merging Completed."));
	}
}
