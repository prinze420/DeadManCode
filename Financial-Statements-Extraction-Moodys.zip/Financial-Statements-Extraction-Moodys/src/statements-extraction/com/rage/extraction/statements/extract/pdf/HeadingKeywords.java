package com.rage.extraction.statements.extract.pdf;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.TreeSet;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;



class HeadingKeywords {
	private static TreeSet<String> keywords ;
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(HeadingKeywords.class);

	static TreeSet<String> getKeywords()
	{
		if ( keywords == null )
		{
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
			fileName= "resource/section-identification/heading-keywords.txt" ;
			else
				fileName= "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/heading-keywords.txt" ;

				
			try
			{
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			keywords = loadSuffixesFromFile(fileName) ;
		}

		return keywords ;
	}

	private static TreeSet<String> loadSuffixesFromFile(String fileName) 
	{
		TreeSet<String> ret = new TreeSet<String>() ;

		BufferedReader br = null ;

		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;

				line = line.trim().toLowerCase() ;
				
				ret.add(line) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}
	
	public static void main(String[] args) 
	{
		System.out.println(HeadingKeywords.getKeywords()) ;
	}
}
