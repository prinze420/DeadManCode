package com.rage.extraction.statements.uitls;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.TreeSet;

import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.Section;

public class Utilities 
{
	public static List<String> tokenize(String line, boolean convertToLowercase) 
	{
		List<String> ret = new ArrayList<String>() ;

		StringTokenizer st = new StringTokenizer(line, " ~`!@#$%^&*()_+-={}[]|\\:;\"'<>?,./012345678") ;
		
		while ( st.hasMoreTokens() )
		{
			String token = st.nextToken() ;
			if(token.contains(" "))
			{
				String [] tokens = token.split("\\s");
				for(String tokenChanged:tokens)
				{
					if ( convertToLowercase )
					 ret.add(tokenChanged) ;
				}
				
			}
			else
			{
			if ( convertToLowercase )
				token = token.toLowerCase() ;
			ret.add(token) ;

			}
		}

		return ret ;
	}

	public static Integer findMinPageNo(Section section) 
	{
		TreeSet<Integer> pages = new TreeSet<Integer>() ;

		for ( int i=0 ; i<section.getLines().size() ; i++ )
		{
			PDFLine line = section.getLines().get(i) ;
			Integer pageNo = line.getPageNo() ;
			pages.add(pageNo) ;
		}

		LinkedList<Integer> allPageNos = new LinkedList<Integer>(pages) ;
		if(allPageNos.size()>0)
			return allPageNos.removeFirst() ;
		else return -1;
	}

	public static Integer findMaxPageNo(Section section) 
	{
		TreeSet<Integer> pages = new TreeSet<Integer>() ;

		for ( int i=0 ; i<section.getLines().size() ; i++ )
		{
			PDFLine line = section.getLines().get(i) ;
			Integer pageNo = line.getPageNo() ;
			pages.add(pageNo) ;
		}

		LinkedList<Integer> allPageNos = new LinkedList<Integer>(pages) ;
		if(allPageNos.size()>0)
			return allPageNos.removeLast() ;
		else
			return -1;
	}
}
