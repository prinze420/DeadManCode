package com.rage.extraction.statements.serialize;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;

/**
 * @author kiran.umadi
 *
 */
public class SerializeObject implements Serializable, Serializer
{
	private static final long serialVersionUID = -8747321090840159193L;
	private String fileName;
	private String home;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SerializeObject.class);

	public SerializeObject()
	{
		this.fileName="rage-objects.ser";
		this.home=System.getProperty("user.dir")+System.getProperty("file.separator");
	}

	public Object deSerialize() throws IOException, ClassNotFoundException
	{
		String file = this.home+this.fileName;
		try
		{
			new SafeFile(file);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(file);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		ObjectInputStream in=new ObjectInputStream(new BufferedInputStream(new FileInputStream(file)));
		Object obj=in.readObject();
		in.close();
		return obj;
	}

	public Object deSerialize(String fileName) throws IOException, ClassNotFoundException
	{
		this.home="";
		this.fileName=fileName;
		return this.deSerialize();
	}
	
	public void serialize(Object object) throws IOException
	{
		ObjectOutputStream out=new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(this.home+this.fileName)));
		out.writeObject(object);
		out.close();
	}
	
	public void serialize(String fileName, Object object) throws IOException
	{
		this.home="";
		this.fileName=fileName;
		this.serialize(object);
	}
}
