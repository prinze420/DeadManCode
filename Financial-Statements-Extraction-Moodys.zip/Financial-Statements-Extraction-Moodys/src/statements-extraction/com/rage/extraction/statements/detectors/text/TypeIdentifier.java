package com.rage.extraction.statements.detectors.text;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TypeIdentifier 
{
	private static String getChunk(String line) 
	{
		if (line!=null && line.isEmpty())
			return "";
		if(line.trim().startsWith("\"")){
			line=line.substring(1);
		}
		
		String numberEnumWithOutSpace=hasNumberEnumWithOutSpace(getFirstToken(line));
		if(numberEnumWithOutSpace!=null && !numberEnumWithOutSpace.trim().equals(""))
			return numberEnumWithOutSpace;
		
		
		if (line.trim().length()>8)
			return line.trim().substring(0, 8)+" ";
		
		return line+" ";
	}

	private static String hasNumberEnumWithOutSpace(String firstToken) 
	{
		String nEnum=getNumberClauseIDWithOutSpace(firstToken);
		if(nEnum!=null && !nEnum.trim().equals(""))
			return nEnum+" ";
		return "";
	}

	private static String getFirstToken(String line) 
	{
		if(line==null || line.trim().equals(""))
			return "";
		//System.out.println(line);
		String[] lineArr=line.split("\\s+");
		if(lineArr.length>0)
			return lineArr[0];
		else
			return line;
	}

	private static int patternFound(String pattern, String line) 
	{
		String lineText=getChunk(line);
		
		if (lineText.isEmpty())
			return 0;
		
		Pattern p=Pattern.compile(pattern);
		Matcher m=p.matcher(lineText);
		String grp1=null;
		String grp2=null;
		
		try
		{
			if (m.find())
			{
				grp1=m.group(1);
				grp2=m.group(3);
			}
			
			if(grp1!=null)
			{
				if(lineText.indexOf(grp1)==0)
					return 1;
			}
			else if(grp2!=null)
			{
				if(lineText.indexOf(grp2)==0)
					return 2;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		return 0;
	}

	public static EnumerationType alphabetLowerClause(String line) 
	{
		String pattern="(\\(?(\\s)?[a-z]{1,4}\\))|([a-z](\\s)?\\.\\s{1,})"; //Patterns Covered (a) and a) and a.
		
		int pt=patternFound(pattern, line);
		
		if (pt==1)
			return EnumerationType.ALPHA_LOWER_BRACKET;
		else if(pt==2)
			return EnumerationType.ALPHA_LOWER_DOT;
		
		return EnumerationType.EMPTY;
	}

	public static  EnumerationType alphabetUpperClause(String line) 
	{
		String pattern="(\\(?(\\s)?[A-Z]{1,2}\\)\\s{1,})|([A-Z]{1,2}\\.\\s{1,})"; //Patterns Covered (a) and a) and a.
		
		int pt=patternFound(pattern, line);
		
		if (pt==1)
			return EnumerationType.ALPHA_UPPER_BRACKET;
		else if(pt==2)
			return EnumerationType.ALPHA_UPPER_DOT;
		
		return EnumerationType.EMPTY;
	}

	public static EnumerationType numberClause(String line) 
	{
		//String pattern="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+\\.(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?\\s{1,})"; //Patterns Covered (1) , 1. and 1)
		String pattern="(\\(?\\d{1,4}\\.?(\\d{1,4})?\\.?\\)\\s{1,})|(\\d{1,4}(\\s+)?\\.?(\\s+)?(\\d{1,4})?\\.?(\\s+)?(\\d{1,4})?\\.?(\\s+)?(\\d{1,4})?\\.?\\s{1,})";
		int pt=patternFound(pattern, line);
		
		if (pt==1)
			return EnumerationType.NUMBER_BRACKET;
		else if(pt==2)
		{
			String clauseId=findClauseNo(line);
			if(isInValidEnumeration(clauseId.trim()))
			{
				return EnumerationType.EMPTY;
			}
			return getNumberDotEnum(clauseId, line);
		}
		
		return EnumerationType.EMPTY;
	}
	
	
	public static boolean isInValidEnumeration(String Enum) 
	{
		Enum=Enum.replaceAll("\\s+","");
		String[] enumSplit=Enum.split("\\.");
		try
		{
			for(String enm:enumSplit)
			{
				if(Integer.parseInt(enm)>100)
					return true;
			}
		}
		catch (Exception e) {}
		return false;
	}


	private static EnumerationType getNumberDotEnum(String clauseId, String line) {
		String clauseId1=clauseId.trim().replaceAll("\\s+", "");
		//String line1=line.substring(beginIndex)
		Pattern p=Pattern.compile("(\\d+)");
		Matcher m=p.matcher(clauseId1);
		int level=0; 
		String lastDigit="";
		while(m.find()){
			level++;
			lastDigit=m.group(1);
		}
		if(level==0)
			return EnumerationType.EMPTY;
		else
		{
			if(level==1)
			{
				if(clauseId1.contains("."))
				{
					return EnumerationType.NUMBER_DOT_LEVEL_ONE;
				}
				else
				{
					if(clauseId1.trim().length()==1)
						return EnumerationType.NUMBER_DOT_LEVEL_ONE;
					else
						return EnumerationType.NONE;
				}
			}
			else if(level==2)
			{
				if(!isZero(lastDigit))
					return EnumerationType.NUMBER_DOT_LEVEL_TWO;
				else
					return EnumerationType.NUMBER_DOT_LEVEL_ONE;
			}
			else if(level ==3)
				return EnumerationType.NUMBER_DOT_LEVEL_THREE;
			else if(level==4)
				return EnumerationType.NUMBER_DOT_LEVEL_FOUR;
			else if(level==5)
				return EnumerationType.NUMBER_DOT_LEVEL_FIVE;
			else
				return EnumerationType.EMPTY;
		}
	}

	private static boolean isZero(String lastDigit) 
	{
		try
		{
			int i=Integer.parseInt(lastDigit);
			if(i==0)
				return true;
		}
		catch (Exception e) 
		{}
		return false;
	}

	public static EnumerationType romanUpperClause(String line) 
	{
		//String pattern="(\\(?[IVXL]+\\))|([IVXL]+\\.\\s{1,})"; //Patterns Covered- Roman numerals- (ii) and ii) and ii.
		String pattern="(\\(?(\\s)?[IVXL]{1,4}\\)\\s{1,})|([IVXL]{1,4}\\.?\\s{1,})";
		
		int pt=patternFound(pattern, line);
		
		if (pt==1)
			return EnumerationType.ROMAN_UPPER_BRACKET;
		else if(pt==2)
			return EnumerationType.ROMAN_UPPER_DOT;
		
		return EnumerationType.EMPTY;
	}

	public static EnumerationType romanLowerClause(String line) 
	{
		String pattern="(\\(?(\\s)?[ivxl]{1,4}\\)\\s{1,})|([ivxl]{1,4}\\.?\\s{1,})"; //Patterns Covered- Roman numerals- (ii) and ii) and ii.
		
		int pt=patternFound(pattern, line);
		if (pt==1)
			return EnumerationType.ROMAN_LOWER_BRACKET;
		else if(pt==2)
			return EnumerationType.ROMAN_LOWER_DOT;
		
		return EnumerationType.EMPTY;
	}

	public static EnumerationType bulletedClause(String line) 
	{ 
		// Bulleted clause identification
		if (line!=null && line.trim().startsWith("�"))
			return EnumerationType.BULLETS;
		return EnumerationType.EMPTY;
	}

	

	private static String getClauseId(String pattern, String line) 
	{
		String lineText=getChunk(line);
		
		if (lineText.isEmpty())
			return "";
		
		Pattern p=Pattern.compile(pattern,Pattern.CASE_INSENSITIVE);
		Matcher m=p.matcher(lineText);
		
		if (m.find())
		{
			if(m.group(1)!=null && !m.group(1).trim().isEmpty() && lineText.indexOf(m.group(1))==0)
				return m.group(1); 
			if(m.group(3)!=null && !m.group(3).trim().isEmpty() && lineText.indexOf(m.group(3))==0)
				return m.group(3); 	
		}
		
		return "";
	}

	private static String getNumberClauseWithOutSpace(String pattern, String line) 
	{
		String lineText=line;
		boolean isAlphaNumeric=false;
		if (lineText.isEmpty())
			return "";
		
		String pp="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+(\\s+)?\\.(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?[a-zA-Z])";
		Pattern p1=Pattern.compile(pp,Pattern.CASE_INSENSITIVE);
		Matcher m1=p1.matcher(line);
		
		if (m1.find())
		{
			if(m1.group(1)!=null && !m1.group(1).trim().isEmpty() && line.indexOf(m1.group(1))==0)
				 isAlphaNumeric=true; 
			if(m1.group(3)!=null && !m1.group(3).trim().isEmpty() && line.indexOf(m1.group(3))==0)
				isAlphaNumeric=true; 	
		}
		
		if(!isAlphaNumeric)
			return "";
		
		Pattern p=Pattern.compile(pattern,Pattern.CASE_INSENSITIVE);
		Matcher m=p.matcher(lineText);
		
		if (m.find())
		{
			if(m.group(1)!=null && !m.group(1).trim().isEmpty() && lineText.indexOf(m.group(1))==0)
				return m.group(1); 
			if(m.group(3)!=null && !m.group(3).trim().isEmpty() && lineText.indexOf(m.group(3))==0)
				return m.group(3); 	
		}
		
		return "";
	}
	
	
	private static String getAlphabetClauseID(String line) 
	{
		//String pattern="(\\(?[a-z]\\)+\\s{1,})|([a-z]\\.\\s{1,})"; //Patterns Covered (a) and a) and a.
		String pattern="(\\(?(\\s)?[a-z]{1,4}\\))|([a-z]{1,2}(\\s)?\\.\\s{1,})";
		
		String clauseId=getClauseId(pattern, line);
		
		if (clauseId!=null && !clauseId.trim().equals(""))
			return clauseId;
		return "";
	}

	private static String getNumberClauseIDWithOutSpace(String line) 
	{
		//String pattern="(\\(?[0-9]+\\)\\s{1,})|([0-9]+\\.\\s{1,})"; //Patterns Covered (1) , 1. and 1)
		//String pattern="(\\(?\\d+\\.?(\\d+)?\\)\\s{1,})|(\\d+\\.(\\d+)?\\s{1,})";
		//String pattern="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+\\.(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?\\s{1,})";
		String pattern="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+(\\s+)?\\.(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?)";
		
		String clauseId=getNumberClauseWithOutSpace(pattern, line);
		
		if (clauseId!=null && !clauseId.trim().equals(""))
			return clauseId;
		
		return "";
	} 
	
	private static String getNumberClauseID(String line) 
	{
		//String pattern="(\\(?[0-9]+\\)\\s{1,})|([0-9]+\\.\\s{1,})"; //Patterns Covered (1) , 1. and 1)
		//String pattern="(\\(?\\d+\\.?(\\d+)?\\)\\s{1,})|(\\d+\\.(\\d+)?\\s{1,})";
		//String pattern="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+\\.(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?\\s{1,})";
		String pattern="(\\(?\\d+\\.?(\\d+)?\\.?\\)\\s{1,})|(\\d+(\\s+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?(\\s+)?(\\d+)?\\.?\\s{1,})";
		
		String clauseId=getClauseId(pattern, line);
		
		if (clauseId!=null && !clauseId.trim().equals(""))
			return clauseId;
		
		return "";
	}

	private static String getRomanClauseID(String line) 
	{
		//String pattern="(\\(?[IVXL]+\\)\\s{1,})|([IVXL]+\\.\\s{1,})"; //Patterns Covered- Roman numerals- (ii) and ii) and ii.
		String pattern="(\\(?(\\s)?[ivxl]{1,4}\\)\\s{1,})|([ivxl]{1,4}\\.?\\s{1,})";
		String clauseId=getClauseId(pattern, line);
		
		if (clauseId!=null && !clauseId.trim().equals(""))
			return clauseId;
		
		return "";
	}

	private static String getBulletedClauseID(String line) 
	{
		// Bulleted clause identification
		if (line!=null && line.trim().startsWith("�"))
			return "�";
		
		return "";
	}

	public static String findClauseNo(String line) 
	{
		String clauseId="";
		
		if (line==null || line.trim().isEmpty())
			return "";
		
		if (!(clauseId=TypeIdentifier.getBulletedClauseID(line)).equals(""))
			return clauseId;
		else if (!(clauseId=TypeIdentifier.getNumberClauseID(line)).equals(""))
			return clauseId;
		else if (!(clauseId=TypeIdentifier.getRomanClauseID(line)).equals(""))
			return clauseId;
		else if (!(clauseId=TypeIdentifier.getAlphabetClauseID(line)).equals(""))
			return clauseId;

		return "";
	}
}
