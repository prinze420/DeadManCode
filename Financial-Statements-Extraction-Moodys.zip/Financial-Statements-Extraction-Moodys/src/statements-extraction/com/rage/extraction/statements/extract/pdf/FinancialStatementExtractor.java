package com.rage.extraction.statements.extract.pdf;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.regex.Pattern;


import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.commons.logging.LogFactory;

import com.dp.hierarchy.HierarchyNode;
import com.dp.pipeline.ExtractionParser;
import com.dp.pipeline.UpdatedCharacters;
import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gyan.siapp.utils.Triplet;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.document.pdf.utils.CustomFileWriter;
import com.rage.extraction.multicolumn.MultiColumnPDFExtractor;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.associations.AssociationCreator;
import com.rage.extraction.pdf.associations.ImplicitSplit;
import com.rage.extraction.pdf.associations.InnerSplit;
import com.rage.extraction.pdf.associations.TextValuesExtraction;
import com.rage.extraction.pdf.parse.AdaptiveVerticalBlocksCreater;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.SectionStartMatch;
import com.rage.extraction.statements.analyze.ContentCategorizer;
import com.rage.extraction.statements.attributes.StatementAttributes;
import com.rage.extraction.statements.breakups.BreakupExtraction;
import com.rage.extraction.statements.breakups.InlineBreakupExtraction;
import com.rage.extraction.statements.classifier.LabelMapper;
import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.constant.DBConnection;
import com.rage.extraction.statements.constant.ReadLogProperties;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.fs.split.SplitStatement;
import com.rage.extraction.statements.index.MemIndexer.Type;
import com.rage.extraction.statements.mapping.IndustryMapReader;
import com.rage.extraction.statements.mapping.MapReader;
import com.rage.extraction.statements.reprocess.ReprocessMetadata;
import com.rage.extraction.statements.spreading.write.ExcelDataWriter;
import com.rage.extraction.statements.train.MetaTree;
import com.rage.extraction.statements.train.Tree;
import com.rage.extraction.statements.uitls.BingTranslate;
import com.rage.extraction.statements.uitls.PDFDocumentLoader;
import com.rage.extraction.statements.uitls.Utilities;
import com.rage.extraction.statements.ontology.SectionOntology;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.ontology.MetaData;

public class FinancialStatementExtractor {
	private static String docID; 
	private static String standAlone;
	private static String fileName; 
	private static String industry ;
	private static String storeLogic ;
	private static String debug;
	private static String scope;
	private static String reprocess;
	private static String companyID;
	private static String language;
	private static String year;
	private static List<String> processingScope;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(FinancialStatementExtractor.class);
	private static DBConnection dbRef = DBConnection.getInstance();
	private static String breakups;
	public static BufferedWriter writer = null;
	private static String ISBreakups;
	private static String CFBreakups;
	private static String subsectionMapping;
	private static Boolean isScheduleRequired = true;


	private static Boolean useProxy;
	private static String companyName;
	private static int startPg=-1;
	private static int endPg=-1;


	//private static List<String> notesList;
	//private static Language languageFrom;   


	private static String coordRequired;
	private static Map<String,String> languageLabelMappings;
	private static List<Integer> contentpgNos;



	public static void main(String[] args) throws Exception 
	{
		// V2 released
		System.out.println("Start");
		try
		{
			long startTime = System.currentTimeMillis();
			long endTime;
			String currentDateTimeString=getCurrentDateTimeString();
			System.out.println("Args: " + Arrays.asList(args)) ;

			Boolean isTesting = false;
			String thisFileName = "D:/Samples/_2014_Audit[2016-07-08-052949357].pdf";

			if(thisFileName.contains("\\"))
				thisFileName = thisFileName.replaceAll("\\\\","/");
			if(args.length>0)
				docID = args[0] ;

			if(args.length>1)
				isTesting = new Boolean(args[1]) ;

			if(args.length>2)
				fileName = isTesting ? thisFileName : args[2] ;

			if(args.length>3)
				standAlone =  args[3] ;

			if(args.length>4)
				industry =  args[4] ;

			if(args.length>5)
				debug = args[5];

			if(args.length>6)
				storeLogic = args[6];

			if(args.length>7)
				reprocess = args[7];

			String thisOutputFileName =  fileName.contains(".pdf") ? fileName.replace(".pdf", (reprocess+"_"+currentDateTimeString+".xlsx")) : fileName.contains(".PDF") ? fileName.replace(".PDF", (currentDateTimeString+".xlsx")) : "dummy.xlsx";

			String thisOutputTextFileName =  fileName.contains(".pdf") ? fileName.replace(".pdf", (reprocess+"_"+currentDateTimeString+".txt")) : fileName.contains(".PDF") ? fileName.replace(".PDF", (currentDateTimeString+".txt")) : "dummy.txt";

			String sectionIdentificationOutputTextFileName =  fileName.contains(".pdf") ? fileName.replace(".pdf", (reprocess+"_"+currentDateTimeString+".txt")) : fileName.contains(".PDF") ? fileName.replace(".PDF", (currentDateTimeString+".txt")) : "dummy.txt";

			if(isTesting)
				System.out.println("thisOutputFileName   :"+thisOutputFileName);

			if(args.length>8)
			{
				companyID = args[8].trim().equalsIgnoreCase("0") ? "" : args[8];
			}

			if(args.length>9)
			{
				language = /*args[9].trim().equalsIgnoreCase("English") ? "" :*/ args[9].trim();
			}
			useProxy = args.length>10 ? new Boolean(args[10].trim()) : false;;

			coordRequired = args.length>11 ? args[11] : "No";

			companyName = args.length>12 ? args[12] : "";



			/*if(notesList==null)
			{
				notesList = getNotesList();t

			}*/

			if(standAlone.equalsIgnoreCase("Yes"))
			{
				if ( new File(thisOutputFileName).exists() )
				{
					try
					{
						new File(thisOutputFileName).delete() ;
					}
					catch (Exception e)
					{
						System.err.println("Error in deleting file: " + thisOutputFileName + " : " + e.getMessage()) ;
						e.printStackTrace() ;
					}
				}

			}

			if(debug.equalsIgnoreCase("On"))
			{
				loadLogfile(docID);
			}

			FinancialStatementExtractor fs = new FinancialStatementExtractor();

			if(!(language.equalsIgnoreCase("English") || language.equalsIgnoreCase("Spanish ITR")) && standAlone.equalsIgnoreCase("No")) 
			{
				languageLabelMappings = DataWriterOracle.getMappings(language);
			}


			boolean all = true; ;
			List<Integer> pageNos = new ArrayList<Integer>(Arrays.asList(new Integer[] {86})) ;

			TreeMap<Integer, PageParse> pageParsesMap;

			boolean isAllPageMultiColRun=false;

			try
			{
				/*File fout = new File(thisOutputTextFileName);
				FileOutputStream fos = new FileOutputStream(fout);
				writer = new BufferedWriter(new OutputStreamWriter(fos));*/
			}
			catch(Exception e){}
			CustomFileWriter.writeStringToFileWithNewLine("=============Build Basic PDF Data=============", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			if(isAllPageMultiColRun)
			{
				// New Way
				Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap = UpdatedCharacters.getCharactersMap(fileName, new ArrayList<Integer>()); 

				Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);

				pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
				//
			}
			else
			{
				// OLD WAY
				// TODO: Comment this
				all = false ;
				pageNos = new ArrayList<Integer>();
				String pageNumers = "3";
				String split[] = pageNumers.split(",");
				for(int index = 0; index < split.length; index++){
					String page = split[index].trim();
					String _split[] = page.split("-");
					if(_split.length > 1){
						int start = Integer.parseInt(_split[0].trim());
						int end = Integer.parseInt(_split[1].trim());
						for(int _page = start; _page <= end; _page++){
							pageNos.add(_page);
						}
					}
					else{
						int value = Integer.parseInt(page);
						pageNos.add(value);
					}
				}
				pageParsesMap = PDFDocumentLoader.loadDocument(fileName, all, pageNos,false) ;
				//
			}
			CustomFileWriter.writeStringToFileWithNewLine("=============PDF Data built=============", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			System.out.println("Printing Page Lines----------------------------");
			/*for(Integer pgNo:pageParsesMap.keySet())
			{
				PageParse pp=pageParsesMap.get(pgNo);
				List<PDFLine> lines=pp.getPageLines();
				System.out.println();
				System.out.println("PageNO================="+pgNo);
				for(PDFLine line:lines)
				{
					//System.out.println(line.getLine());
					List<PDFChunk> chunkList = line.getChunks();
					System.out.println();
					for(PDFChunk chunk:chunkList)
					{
						System.out.print(chunk.getChunk()+"==");					
					}
				}
			}*/

			//System.exit(0);

			Connection con = null; 
			DataWriterOracle dwOracle = null;
			DataWriterSql dwSql = null;
			if(standAlone.equals("No"))
			{
				con = DBConnection.openConnection("RAGE");

				if(!DBConnection.get_JDBC_DRIVER().toLowerCase().contains("oracle"))
				{
					dwSql = new DataWriterSql();
				}
				else
				{
					dwOracle = new DataWriterOracle();
				}
			}


			if(logger!=null)
				logger.info("Args: " + Arrays.asList(args)) ;

			if (reprocess.trim().equalsIgnoreCase("Yes"))
			{
				boolean found = false;

				if(dwSql!=null)
					found = dwSql.getRunProperties(con, docID,dbRef);
				else
					found = dwOracle.getRunProperties(con, docID,dbRef);

				if(found)
				{
					if(scope==null || scope.equalsIgnoreCase("ALL"))
						scope=dbRef.getProperty("Extraction Scope");

					if(!scope.contains("znotes"))
					{
						scope = scope+", znotes";
					}

					System.out.println("Scope -- "+scope);
					processingScope = new ArrayList<String>();	
					processingScope = Arrays.asList(scope.split(","));
					debug=dbRef.getProperty("Generate Log");
					breakups = dbRef.getProperty("Extract Breakups");
					ISBreakups = dbRef.getProperty("IS Breakups");
					BSBreakups = dbRef.getProperty("BS Breakups");
					CFBreakups = dbRef.getProperty("CF Breakups");
					subsectionMapping = dbRef.getProperty("Sub-Section Mapping");
					if((subsectionMapping!=null && subsectionMapping.equalsIgnoreCase("")) || subsectionMapping==null)
						subsectionMapping="IS,BS,CF";

				}
			}
			else
			{
				// load property configuration
				int ret = dbRef.loadRunConfig("resource/PrivateProperty.properties");
				if(ret!=0)
				{
					if (logger!=null)
						logger.info(StringEscapeUtils.escapeJava(("Failure - Error  in reading resource/PrivateProperty.properties File")));

					System.out.println("Failure - Error  in reading resource/PrivateProperty.properties File");
					System.exit(1)	;
				}
				scope = dbRef.getProperty("Extraction Scope");
				processingScope = new ArrayList<String>();
				processingScope = Arrays.asList(scope.split(","));
				debug = dbRef.getProperty("Generate Log");
				setBreakups(dbRef.getProperty("Extract Breakups"));
				setISBreakups(dbRef.getProperty("IS Breakups"));
				BSBreakups = dbRef.getProperty("BS Breakups");
				CFBreakups = dbRef.getProperty("CF Breakups");
				subsectionMapping = dbRef.getProperty("Sub-Section Mapping");

				if(storeLogic.equals("Yes"))
				{
					if(dwSql!=null)
					{
						dwSql.deleteRunProperties(docID, con);
						dwSql.setRunProperties(dbRef, docID, con);
					}
					else
					{
						if(con==null)
						{
							System.out.println("Rage Connection Null");
						}
						dwOracle.deleteRunProperties(docID, con);
						dwOracle.setRunProperties(dbRef, docID, con);
					}
				}
			}

			try {
				if(con!=null)
					con.commit();
				con.close();
			} catch (Exception e) {
			}

			/*FindContentPages cp = new FindContentPages(pageParsesMap);
			cp.run();
			contentpgNos = cp.getContentpgNos();*/

			if(all)
			{
				System.out.println("Finding Content Pages...");
				FindContentPages cp = new FindContentPages(pageParsesMap);
				cp.run();
				contentpgNos = cp.getContentpgNos();

				//This class will mark the footer rows.
				FooterMarker fm = new FooterMarker(pageParsesMap);
				fm.run();
				pageParsesMap = fm.getReportPages();
				//remove footer rows from blocks and lines.     
				pageParsesMap = fm.removeFooterRowsFromPageParse(pageParsesMap);

				//Header remover
				HeaderMarker hm = new HeaderMarker(pageParsesMap);
				hm.run();
				pageParsesMap = hm.getReportPages();
				pageParsesMap = hm.removeHeaderRowsFromPageParse(pageParsesMap);

			}


			TreeMap<String, ArrayList<ParserOutput>> sectionMap = new TreeMap<String, ArrayList<ParserOutput>> ();

			Section footNotesSection=null;

			List<Section> sections = null;
			CustomFileWriter.writeStringToFileWithNewLine("=============Identification of sections=============", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			if(reprocess.equalsIgnoreCase("No") && ( companyID==null || companyID.trim().equals("")))
			{
				sections = SectionBoundaryDetector.detectSectionBoundaries(pageParsesMap) ;
				/*if(FinancialStatementExtractor.getProcessingScope().contains("SUPPL"))
				{ 
					List<MetaData> supplList = SectionOntology.getSupplMetaList();
					if(supplList!=null)
					{
						supplSections = SectionBoundaryDetector.detectSectionSupplBoundaries(pageParsesMap,supplList,sections);
					}
				}*/

				//sections = checkComprehensiveIS(sections);
			}
			else
			{
				sections = SectionBoundaryDetector.detectSectionReprocessBoundaries(pageParsesMap,dwOracle,dwSql);
				/*if(FinancialStatementExtractor.getProcessingScope().contains("SUPPL"))
				{
					supplSections = SectionBoundaryDetector.createReprocessSupplementarySections(pageParsesMap,dwOracle,dwSql, sections);
				}*/

				if(sections.size()==0 && reprocess.equalsIgnoreCase("No"))
				{
					sections = SectionBoundaryDetector.detectSectionBoundaries(pageParsesMap) ;
					/*if(FinancialStatementExtractor.getProcessingScope().contains("SUPPL"))
					{
						List<MetaData> supplList = SectionOntology.getSupplMetaList();
						if(supplList!=null)
						{
							supplSections = SectionBoundaryDetector.detectSectionSupplBoundaries(pageParsesMap,supplList,sections);
						}
					}*/
				}
			}

			/*if(supplSections!=null && supplSections.size()>0)
			{
				sections.addAll(supplSections);
			}*/

			LinkedHashSet<String> noteSectionList= new LinkedHashSet<String>();
			noteSectionList = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/footnotesSectionIdentificationKeywords.txt");

			//sections=getFnotesEndSectionsRemoved(sections);

			sections = removeSectionsWithNegativeNumbers(sections);

			sections=getNotesValidatedOnPageNos(sections,pageParsesMap,noteSectionList);

			// Notes section changes
			sections=getNoteValidatedSection(sections);

			// Remove section above IS BS CF

			sections= getSectionsBeforeMainStatementRemoved(sections);

			// Notes End (fnotes_end) Check

			sections=getNotesEndCheck(sections,pageParsesMap);

			// remove false section on page number count check

			sections=getPageCountSectionValidated(sections);


			if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No"))
			{
				System.out.println("Removing false positive sections on page numbers basis");
				sections = removeFalsePositivesOnPageNumberBasis(sections);
			}


			//	sections = removeSectionsAfterFootnotesSection(sections);
			//
			//

			/************ create blocks of section pages**************/
			/*	if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Chinese"))
			createBlocksForSectionPages(sections,fileName);*/

			/******removing sections if any two sections occur more than 1 time on same page ***************/
			if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No"))
			{
				System.out.println("Removing multiple false positive sections on  same page numbers");

				sections = removeMultipleSectionOnSamePage(sections);
			}

			boolean onlySectionIdentificationRun=false;
			if(onlySectionIdentificationRun)
			{
				try
				{
					File fout = new File(sectionIdentificationOutputTextFileName);
					FileOutputStream fos = new FileOutputStream(fout);
					writer = new BufferedWriter(new OutputStreamWriter(fos));
				}
				catch(Exception e){}
				if(sections!=null && sections.size()>0)
				{
					for(Section sec:sections)
					{
						CustomFileWriter.writeStringToFileWithNewLine("Section found=="+sec.toString(), writer);
						SectionStartMatch keyWord=sec.getKeyword();
						CustomFileWriter.writeStringToFileWithNewLine("KeyWord Matched=="+keyWord,writer);
					}
				}
				else
				{
					CustomFileWriter.writeStringToFileWithNewLine("===============No Sections Found==============", writer);
				}
				return;
			}

			if(sections == null || (sections != null && sections.size()==0))
			{
				logger.info("No sections found");
				System.exit(1);
			}
			ArrayList<ReprocessMetadata> reprocessMetaList = null;
			ArrayList<SectionType> sectionTypeList = null;
			if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
			{
				reprocessMetaList  = new ArrayList<ReprocessMetadata>();
				sectionTypeList = new ArrayList<SectionType>();
			}

			int ct=0;

			if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
			{
				getYear(sections);
			}
			String secIdenficationString="=========================Sec Identification======================";
			for(Section sec:sections)
			{
				System.out.println("Section found=="+sec);
				SectionStartMatch keyWord=sec.getKeyword();
				System.out.println("KeyWord Matched=="+keyWord);
				secIdenficationString=secIdenficationString+"\n"+"Section found=="+sec;
				secIdenficationString=secIdenficationString+"\n"+"KeyWord Matched=="+keyWord;
			}
			secIdenficationString=secIdenficationString+"\n\n============Sec Identification done========================";

			for(Section sec:sections)
			{
				CustomFileWriter.writeStringToFileWithNewLine("Section found=="+sec.toString(), writer);
			}

			CustomFileWriter.writeStringToFileWithNewLine("=============Section Identification done=============", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);

			// MultiColumn Change
			if(!isAllPageMultiColRun)
			{


				List<Section> multiColParseSection=new ArrayList<Section>();
				for ( int i=0 ; i<sections.size() ; i++ )
				{
					Section sec=sections.get(i);
					System.out.println("Multicolumn Parse for section--"+sec);
					int end=Utilities.findMaxPageNo(sec);
					int start=Utilities.findMinPageNo(sec);
					if(end==-1 || start==-1)
						continue;
					if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") || sec.getSectionName().trim().equalsIgnoreCase("fnotes_end") )
					{
						multiColParseSection.add(sec);
						continue;
					}
					MultiColumnPDFExtractor mcpe= new MultiColumnPDFExtractor();
					List<Section> section=mcpe.getMultiColumnDataFromSection(sec, fileName, dwOracle,  dwSql);
					if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("Yes"))
					{
						for(Section thisSec:section)
						{
							boolean isFound=false;
							for(Section mSec:multiColParseSection)
							{
								if(mSec.getSectionName().trim().equalsIgnoreCase(thisSec.getSectionName().trim()))
								{
									int mPageNo=Utilities.findMinPageNo(mSec);
									int thisSecPgNo=Utilities.findMinPageNo(thisSec);
									if(mPageNo==thisSecPgNo)
									{
										if(areSectionOverLapping(mSec,thisSec))
										{
											isFound=true;
											break;
										}
									}
								}
							}
							if(!isFound)
							{
								multiColParseSection.add(thisSec);
							}
						}
					}
					else
						multiColParseSection.addAll(section);
				}
				sections.clear();
				sections.addAll(multiColParseSection);
			}
			//
			System.out.println("=============Section Found After MultiColumn=========");
			for(Section sec:sections)
			{
				System.out.println("Section found=="+sec);
				SectionStartMatch keyWord=sec.getKeyword();
				System.out.println("KeyWord Matched=="+keyWord);
				secIdenficationString=secIdenficationString+"\n"+"Section found=="+sec;
				secIdenficationString=secIdenficationString+"\n"+"KeyWord Matched=="+keyWord;
			}
			CustomFileWriter.writeStringToFileWithNewLine("Going for Table Spreading====== ", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			for ( int i=0 ; i<sections.size() ; i++ )
			{
				Section section = sections.get(i) ;

				String sectionName = section.getSectionName() ;
				List<PDFLine> sectionLines = section.getLines() ;
				//SectionStartMatch keyword = section.getKeyword() ;

				System.out.println("\n\n\n\n") ;
				System.out.println("================= New Section =================="+sectionName) ;

				logger.info("\n\n\n\n") ;
				logger.info("================= New Section =================="+sectionName) ;

				TreeMap<Integer, List<PDFLine>> pageLinesMap = new TreeMap<Integer, List<PDFLine>>() ;
				for ( int j=0 ; j<sectionLines.size() ; j++ )
				{
					PDFLine line = sectionLines.get(j) ;
					Integer pageNo = line.getPageNo() ;
					logger.info(sectionName + "\t" + pageNo + "\t" + line.getLine()) ;
					System.out.println(sectionName + "\t" + pageNo + "\t" + line.getLine()) ;


					List<PDFLine> thisPageLines = pageLinesMap.containsKey(pageNo) ? pageLinesMap.get(pageNo) : new ArrayList<PDFLine>() ;
					thisPageLines.add(line) ;
					pageLinesMap.put(pageNo, thisPageLines) ;
				}

				if ( sectionName.equalsIgnoreCase("znotes") || sectionName.equalsIgnoreCase("fnotes_end") )
					continue ;

				if ( sectionName.equalsIgnoreCase("fnotes") )
				{
					footNotesSection=section;
					if(reprocess.equalsIgnoreCase("No") && standAlone.equalsIgnoreCase("No"))
					{
						if(section.getReprocessMeta()!=null)
						{
							section.getReprocessMeta().setSection("SUPPL");
							ReprocessMetadata reprocessMeta = section.getReprocessMeta();
							reprocessMeta.setStrtPage(Utilities.findMinPageNo(section));
							reprocessMeta.setEndPage(Utilities.findMaxPageNo(section));
							/*if(section.getLines().get(0).getLine()!=null)
							reprocessMeta.setStrtKeyword(section.getLines().get(0).getLine());
						else*/
							reprocessMeta.setStrtKeyword(section.getKeyword().getKeyword());
							/*if(section.getLines().get(section.getLines().size()-1).getLine()!=null)
							reprocessMeta.setEndKeyword(section.getLines().get(section.getLines().size()-1).getLine());
						else*/
							reprocessMeta.setEndKeyword(null);

							reprocessMeta.setEndPage(Utilities.findMaxPageNo(section));
						}
						else
						{

							ReprocessMetadata reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection("SUPPL");

							reprocessMeta.setStrtPage(Utilities.findMinPageNo(section));
							reprocessMeta.setEndPage(Utilities.findMaxPageNo(section));
							/*if(section.getLines().get(0).getLine()!=null)
							reprocessMeta.setStrtKeyword(section.getLines().get(0).getLine());
						else*/
							reprocessMeta.setStrtKeyword(section.getKeyword().getKeyword());
							/*if(section.getLines().get(section.getLines().size()-1).getLine()!=null)
							reprocessMeta.setEndKeyword(section.getLines().get(section.getLines().size()-1).getLine());
						else*/
							reprocessMeta.setEndKeyword(null);

							reprocessMeta.setEndPage(Utilities.findMaxPageNo(section));
							section.setReprocessMeta(reprocessMeta);
						}
						++ct;
						section.getReprocessMeta().setInstanceID(ct);
						reprocessMetaList.add(section.getReprocessMeta());
					}
					continue ;}
				//Set Statement Types 
				SectionType sType = null;

				CustomFileWriter.writeStringToFileWithNewLine("Spreading table for Section::: "+ section.toString(),writer);
				CustomFileWriter.writeStringToFileWithNewLine("", writer);

				ArrayList<ParserOutput> poList = SectionSpreader.spreadPageData(section);

				CustomFileWriter.writeStringToFileWithNewLine("", writer);
				addIndentLevelsToRows(poList);

				//Set Statement Types
				if(!section.getSectionName().equalsIgnoreCase("SUPPL"))
				{
					sType= new SectionType();
					sType.setColNo(section.getColNo());
					sType.setFilingId(Integer.parseInt(docID));
					sType.setSection(section.getSectionName());

					if(section.getIsSubsidiary())
					{
						sType.setType("SUBSIDIARY");
					}
					else
					{
						sType.setType("GROUP");
					}
				}
				//Set Statement Types

				if(poList.size()>0 && section.getKeyword()!=null && section.getKeyword().getColumnNo()!=null   && section.getKeyword().getColumnNo()>1)
				{
					SplitStatement.splitSectionColumns(FinancialStatementExtractor.getDocID(), section.getSectionName(), section.getKeyword().getColumnNo(), poList);
				}

				if(poList.size()>0 && section.getReprocessMeta()!=null)
				{
					ct=ct+1;
					if(reprocess.equalsIgnoreCase("No"))
					{
						setTableID(ct, poList);
						section.getReprocessMeta().setInstanceID(ct);
						reprocessMetaList.add(section.getReprocessMeta());
						if(sType!=null)
							sType.setTableID(ct);
					}
					else
					{
						setTableID(section.getReprocessMeta().getInstanceID(), poList);
						section.setInstanceID(section.getReprocessMeta().getInstanceID());
						if(sType!=null)
							sType.setTableID(section.getReprocessMeta().getInstanceID());
					}

				}
				if(sectionTypeList!=null && sType!=null)
					sectionTypeList.add(sType);

				if(!sectionMap.containsKey(sectionName.toUpperCase()))
				{
					sectionMap.put(sectionName.toUpperCase(), poList);
				}
				else
				{
					ArrayList<ParserOutput> thisList =  sectionMap.get(sectionName.toUpperCase());
					if(thisList!=null)
						thisList.addAll(poList);
				}
			}

			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			CustomFileWriter.writeStringToFileWithNewLine("===========Table Spreading Done============", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			// create hierarchy for footnotes section


			CustomFileWriter.writeStringToFileWithNewLine("===============Hierarchy Building for notes section==========", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);

			if(footNotesSection!=null)
			{
				startPg=Utilities.findMinPageNo(footNotesSection);
				endPg=Utilities.findMaxPageNo(footNotesSection);
			}
			/*int startPg=Utilities.findMinPageNo(footNotesSection);
			int endPg=Utilities.findMaxPageNo(footNotesSection);*/
			HierarchyNode hierarchyNode=null;
			String hNodeStr="";
			boolean isDebug=false;
			if(footNotesSection!=null || isDebug)
			{
				//int startPg=Utilities.findMinPageNo(footNotesSection);
				//int endPg=Utilities.findMaxPageNo(footNotesSection);
				// create Hierarchy for footnotes
				hierarchyNode=ExtractionParser.getHieraechyNode(startPg, endPg, fileName);
				System.out.println("Hierarchy Prepared");
				hNodeStr=HierarchyNode.toDeepString(hierarchyNode, "");
				System.out.println(hNodeStr);
				CustomFileWriter.writeStringToFileWithNewLine(hNodeStr, writer);
				CustomFileWriter.writeStringToFileWithNewLine("", writer);
			}

			// hierarchy for footnotes section done

			CustomFileWriter.writeStringToFileWithNewLine("============Hierarchy Preparation done===========", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);

			if(reprocessMetaList!=null && reprocessMetaList.size()>0 /*&& companyID.trim().equals("")*/)
			{
				if(!DBConnection.get_JDBC_DRIVER().toLowerCase().contains("oracle"))
				{
					dwSql.insertRuletoDB(reprocessMetaList);
				}
				else
				{
					dwOracle.insertRuletoDB(reprocessMetaList);
				}

			}

			//	inserted the section types to DB
			if(sectionTypeList!=null && sectionTypeList.size()>0)
			{

				if(!DBConnection.get_JDBC_DRIVER().toLowerCase().contains("oracle"))
				{
					dwSql.insertSectionTypestoDB(sectionTypeList);
				}
				else
				{
					dwOracle.insertSectionTypestoDB(sectionTypeList);
				}
			}

			if(sectionMap!=null && sectionMap.size()>0){}
			else
				System.exit(1);

			// associations 
			CustomFileWriter.writeStringToFileWithNewLine("=============Going for association=======", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			Constants.loadResourceProperty();
			/*if (Constants.getProperty("extract.breakups")!=null && reprocess.equalsIgnoreCase("No"))
			{
				breakups = (Constants.getProperty("extract.breakups"));
				ISBreakups = (Constants.getProperty("IS.breakup"));
				BSBreakups =  Constants.getProperty("BS.breakup");
			}*/
			
			// Merging of rows
			for(String section:sectionMap.keySet())
			{
				ArrayList<ParserOutput> poList = sectionMap.get(section);
				factorizeMultiLineLabels(poList);
			}
			
			
			ParserOutput remainingNodesAssociation=null;
			if(sectionMap!=null && sectionMap.size()>0 && hierarchyNode!=null && 
					FinancialStatementExtractor.getBreakups()!=null && FinancialStatementExtractor.getBreakups().contains("Yes"))			
			{
				// Go for association for each row of the section
				AssociationCreator ac= new AssociationCreator();
				ac.associationCreator(sectionMap,hierarchyNode,fileName);
				InnerSplit.setToCheckAllNodesVisited(true);
				remainingNodesAssociation=InnerSplit.getAllRemainingAssociations(hierarchyNode);
			}
			if (Constants.getProperty("schedule.required")!=null)
			{
				isScheduleRequired = new Boolean(Constants.getProperty("schedule.required"));
			}
			if ( breakups.equalsIgnoreCase("Yes") && isScheduleRequired)
			{
				fs.extractBreakups(sectionMap,pageParsesMap,remainingNodesAssociation);
			}

			TreeMap<String, List<List<ParserOutput>>> supplementaryMap = new TreeMap<String, List<List<ParserOutput>>>(); 
			ArrayList<ParserOutput> poSuppl = new ArrayList<ParserOutput>();
			if(standAlone.equalsIgnoreCase("No"))
			{/*
				for(String section:sectionMap.keySet())
				{
					ArrayList<ParserOutput> poObjects = sectionMap.get(section);
					for(int k= 0 ;k<poObjects.size();k++)
					{
						ParserOutput po = poObjects.get(k);
						if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
						{
							for(List<ParserOutput> brkups :po.getSupplementaryBreakUpItem())
							{
								if(brkups!=null)
								{

									if(supplementaryMap.containsKey(section))
									{

										for(ParserOutput brek:brkups)
										{
											if(((brek.getIsHeading()!=null && brek.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && brek.getType().equalsIgnoreCase("HEADER"))))
												brek.setSubSection("HEADER");
											brek.setBreakups("Y");
											brek.setPoRef(po);

										}
										supplementaryMap.get(section).add(brkups);
									}
									else
									{
										List<List<ParserOutput>> temp= new ArrayList<List<ParserOutput>>();

										for(ParserOutput brek:brkups)
										{
											if(((brek.getIsHeading()!=null && brek.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && brek.getType().equalsIgnoreCase("HEADER"))))
												brek.setSubSection("HEADER");

											brek.setBreakups("Y");
											brek.setPoRef(po);

										}
										temp.add(brkups);
										supplementaryMap.put(section, temp);
									}
								}
								poSuppl.addAll(brkups);
							}
						}
					}
				}



				if(poSuppl.size()>0)
				{
					for(ParserOutput po:poSuppl)
					{
						if(!po.getBreakups().equalsIgnoreCase("N"))
							po.setSection("SUPPL");
					}
					sectionMap.put("SUPPL", poSuppl);

				}
			 */}

			System.out.println("=============Association creation done=======");
			// association done

			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			CustomFileWriter.writeStringToFileWithNewLine("=============Association creation done=======", writer);

			Map<String, LabelMapper> metaMap=new HashMap<String, LabelMapper>();
			String[] taxonomies=null;

			if (Constants.getProperty("train.src")!=null)
				taxonomies=Constants.getProperty("train.src").split("\\|");

			String taxonomyPath="";
			if (Constants.getProperty("train.path")!=null)
				taxonomyPath=Constants.getProperty("train.path");

			if (!taxonomyPath.endsWith(File.separator))
			{
				if(language.equalsIgnoreCase("Spanish ITR"))
					taxonomyPath+=File.separator+language+File.separator;
				else
					taxonomyPath+=File.separator;
			}
			if (!isDataSetAvailable() && taxonomies!=null)
			{
				for(String section:sectionMap.keySet())
				{
					for (String fileName:taxonomies)
					{
						String file = "";
						/*	if(!language.equalsIgnoreCase(""))
							file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";
						else*/
						file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";

						if(!new File(taxonomyPath+file).exists())
						{
							logger.error(taxonomyPath+file+" does not exists");	
							continue;
						}
						if (file.startsWith(section) && new File(taxonomyPath+file).exists())
							metaMap.put(section.toUpperCase(), new LabelMapper(taxonomyPath+file, industry,language));
					}
				}
			} else
			{
				MapReader mapReader=new IndustryMapReader(industry, language);
				Tree tree=null;
				for(String section:sectionMap.keySet())
				{
					/*	if(section.equalsIgnoreCase("IS") ||  section.equalsIgnoreCase("BS") || section.equalsIgnoreCase("CF"))
					{
					 */	tree=new MetaTree();
					 logger.info("section :"+section+"\n");
					 tree.setRoot(mapReader.getDataSet().getTrainDataSet().get(section));
					 metaMap.put(section.toUpperCase(), new LabelMapper(tree));
					 /*	}*/
				}
			}

			// Merge rows // Issue fix, calling before association, commmenting here.
			/*for(String section:sectionMap.keySet())
			{
				ArrayList<ParserOutput> poList = sectionMap.get(section);
				factorizeMultiLineLabels(poList);
			}*/

			TreeMap<String, ArrayList<ParserOutput>> mergedMap = sectionMap;

			if(!(language.equalsIgnoreCase("English") || language.equalsIgnoreCase("Spanish ITR")) &&  standAlone.equalsIgnoreCase("No"))
			{
				mapNonEnglishLabels(mergedMap);
			}

			//mergedMap = sectionMap;

			if(metaMap.size()>0) //condition Added by Sanmati
			{
				for (String section:mergedMap.keySet())	{
					ArrayList<ParserOutput> list = mergedMap.get(section);

					/*if((language.contains("ITR") && (section.equalsIgnoreCase("CF") || section.equalsIgnoreCase("SD"))) || (section.equalsIgnoreCase("SUPPL")) || (section.equalsIgnoreCase("SE")))
						continue;
					 */	
					if(section.equalsIgnoreCase("SE"))
					{
						List<ParserOutput> poObjs = mergedMap.get(section);

						for ( int i=0; i<poObjs.size(); i++) {
							ParserOutput po = poObjs.get(i);
							if(!((po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && po.getType().equalsIgnoreCase("HEADER"))))
								po.setSubSection("SE");
							else
								po.setSubSection("HEADER");
						}
					}
					if(subsectionMapping!=null && !subsectionMapping.toUpperCase().contains(section.toUpperCase()))
					{
						continue;
					}
					mergedMap.put(section, metaMap.get(section).map(mergedMap.get(section)));
					if (mergedMap.get(section).size()==0)
						mergedMap.put(section, list);
					List<ParserOutput> poObjs = mergedMap.get(section);

					for ( int i=0; i<poObjs.size(); i++) {
						ParserOutput po = poObjs.get(i);
						// breakups
						if (po.getBreakupItems()!=null && !po.getBreakupItems().isEmpty()) {
							for (ParserOutput breakupItem : po.getBreakupItems()) 
							{
								if(!((breakupItem.getIsHeading()!=null && breakupItem.getIsHeading().equalsIgnoreCase("Y")) ||  (breakupItem.getType()!=null && breakupItem.getType().equalsIgnoreCase("HEADER"))))
									breakupItem.setSubSection(po.getSubSection());
								else
									breakupItem.setSubSection("HEADER");
								if(!breakupItem.getBreakups().equalsIgnoreCase("N"))
									breakupItem.setBreakups("Y");
							}
							//	continue;
						}
						// ### Inline BreakUp Special Case
						try {
							// in-line breakup 
							po.setInlineBreakupItems(InlineBreakupExtraction.extract(po));
						}  catch (Exception e) {
							if (logger!=null)
								logger.error(e);
						}
						// in-line breakups
						if (po.getInlineBreakupItems()!=null && !po.getInlineBreakupItems().isEmpty()) {
							for (ParserOutput supplementItem : po.getInlineBreakupItems()) {
								supplementItem.setSubSection(po.getSubSection());
								supplementItem.setBreakups("Y");
							}
						}
					}
				}
				/*if(!language.contains("ITR"))
				{
					BreakupExtraction.refineBreakupItems(mergedMap);
				}*/
			}



			if(standAlone.equalsIgnoreCase("No"))
			{
				for (String section:mergedMap.keySet())	{
					List<ParserOutput> poObjs = mergedMap.get(section);
					if(section.equalsIgnoreCase("SUPPL"))
					{
						continue;
					}
					Collections.sort(poObjs);

					for ( int i=0; i<poObjs.size(); i++) {
						ParserOutput po = poObjs.get(i);

						if(po.getMatchingBreakUpItem()!=null && po.getMatchingBreakUpItem().size()>0)
						{
							int count = 0 ;
							for(List<ParserOutput> brkups :po.getMatchingBreakUpItem())
							{
								if(brkups!=null)
								{
									for(ParserOutput brkup :brkups)
									{
										if(brkup!=null)
										{
											/*if(count==0 && po!=null && po.getAsRepLabel()!=null && brkup.getAsRepLabel()!=null && brkup.getAsRepLabel().contains(po.getAsRepLabel()) )
											{
												//count = count+1;
												continue;
											}*/
											count = count+1;
											/*if((count<=(brkups.size())) && brkup.getAsRepVal1()!=null && !brkup.getAsRepVal1().equals(po.getAsRepVal1()))
											{*/
											brkup.setPoRef(po);
											poObjs.add(i+count,brkup);
											/*}*/
										}

									}
								}
							}
							i= count + i;

						}
					}
					//inlineBreakups
					for ( int i=0; i<poObjs.size(); i++) {
						ParserOutput po = poObjs.get(i);

						if (po.getInlineBreakupItems()!=null && !po.getInlineBreakupItems().isEmpty()) 
						{
							int count=0;
							for (ParserOutput breakupItem : po.getInlineBreakupItems()) {

								breakupItem.setBreakups("Y");
								if(count==0)
									poObjs.set(i+count,breakupItem);
								else
									poObjs.add(i+count,breakupItem);
								count++;

							}
							i=count+i;
						}
					}
				}
			}
			else
			{
				//inlineBreakups
				for (String section:mergedMap.keySet())	{
					List<ParserOutput> poObjs = mergedMap.get(section);
					if(section.equalsIgnoreCase("SUPPL"))
					{
						continue;
					}
					Collections.sort(poObjs);

					for ( int i=0; i<poObjs.size(); i++) {
						ParserOutput po = poObjs.get(i);

						if (po.getInlineBreakupItems()!=null && !po.getInlineBreakupItems().isEmpty()) 
						{
							int count=0;
							for (ParserOutput breakupItem : po.getInlineBreakupItems()) {

								breakupItem.setBreakups("Y");
								if(count==0)
									poObjs.set(i+count,breakupItem);
								else
									poObjs.add(i+count,breakupItem);
								count++;

							}
							i=count+i;
						}
					}
				}
			}

			if(!(language.equalsIgnoreCase("English") || language.equalsIgnoreCase("Spanish ITR")) &&  standAlone.equalsIgnoreCase("No"))
			{
				mapBreakupsNonEnglishLabels(mergedMap);
			}

			for(String section : mergedMap.keySet())
			{
				ArrayList<ParserOutput> poList = mergedMap.get(section);
				mergedMap.put(section.toUpperCase(), poList);
			}

			addIndentLevelsToOutput(mergedMap);

			if(AssociationCreator.implicitMetadataMatchingBreakUps!=null && AssociationCreator.implicitMetadataMatchingBreakUps.size()>0)
			{
				Map<String, ArrayList<ParserOutput>> addImplicitBreakUP=AssociationCreator.implicitMetadataMatchingBreakUps;
				for(String sec:addImplicitBreakUP.keySet())
				{
					System.out.println("Implicit Metadata for=="+sec+"=="+addImplicitBreakUP.get(sec).size());
					if(!mergedMap.containsKey(sec.toUpperCase()))
					{
						System.out.println("Not Present in Merged Map for Sec="+sec.toUpperCase());
						mergedMap.put(sec.toUpperCase(), addImplicitBreakUP.get(sec));
					}
					else
					{
						System.out.println("Already Present for Sec="+sec.toUpperCase());
						mergedMap.get(sec.toUpperCase()).addAll(addImplicitBreakUP.get(sec));
					}
				}
			}

//			if(standAlone.equalsIgnoreCase("Yes"))
			if(true)
			{
				System.out.println("\n\n\nWriting into Excel ... ") ;
				ExcelDataWriter edw = new ExcelDataWriter(thisOutputFileName, fileName) ;
				if(remainingNodesAssociation!=null)
				{
					ArrayList<ParserOutput> poList= new ArrayList<ParserOutput>();
					poList.add(remainingNodesAssociation);
					mergedMap.put("JALL_SUPPL", poList);
				}
				if(AssociationCreator.implicitSUPPLMetadataMatchingBreakUps!=null && AssociationCreator.implicitSUPPLMetadataMatchingBreakUps.size()>0)
				{
					Map<String, ArrayList<ParserOutput>> addImplicitBreakUP=AssociationCreator.implicitSUPPLMetadataMatchingBreakUps;
					for(String sec:addImplicitBreakUP.keySet())
					{
						System.out.println("Implicit SUPPL Metadata for=="+sec+"=="+addImplicitBreakUP.get(sec).size());
						if(!mergedMap.containsKey("JALL_SUPPL"))
						{
							System.out.println("Not Present SUPPL in Merged Map for Sec="+sec.toUpperCase());
							mergedMap.put("JALL_SUPPL", addImplicitBreakUP.get(sec));
						}
						else
						{
							System.out.println("Already Present SUPPL for Sec="+sec.toUpperCase());
							mergedMap.get("JALL_SUPPL").addAll(addImplicitBreakUP.get(sec));
						}
					}
				}
				for(String section:mergedMap.keySet())
				{
					ArrayList<ParserOutput> poList = mergedMap.get(section);
					factorizeMultiLineLabels(poList);
				}
				edw.run(mergedMap,startPg, endPg) ;

			}
			else
			{
				System.out.println("\n\n\nWriting into db ... ") ;
				for(String section:sectionMap.keySet())
				{
					ArrayList<ParserOutput> poObjects = sectionMap.get(section);
					for(int k= 0 ;k<poObjects.size();k++)
					{
						ParserOutput po = poObjects.get(k);
						if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
						{
							for(List<ParserOutput> brkups :po.getSupplementaryBreakUpItem())
							{
								if(brkups!=null)
								{

									if(supplementaryMap.containsKey(section))
									{

										for(ParserOutput brek:brkups)
										{
											if(((brek.getIsHeading()!=null && brek.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && brek.getType().equalsIgnoreCase("HEADER"))))
												brek.setSubSection("HEADER");
											brek.setBreakups("Y");
											brek.setPoRef(po);

										}
										supplementaryMap.get(section).add(brkups);
									}
									else
									{
										List<List<ParserOutput>> temp= new ArrayList<List<ParserOutput>>();

										for(ParserOutput brek:brkups)
										{
											if(((brek.getIsHeading()!=null && brek.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && brek.getType().equalsIgnoreCase("HEADER"))))
												brek.setSubSection("HEADER");

											brek.setBreakups("Y");
											brek.setPoRef(po);

										}
										temp.add(brkups);
										supplementaryMap.put(section, temp);
									}
								}
								poSuppl.addAll(brkups);
							}
						}
					}
				}


				if(poSuppl.size()>0)
				{
					/*for(ParserOutput po:poSuppl)
					{
						if(!po.getBreakups().equalsIgnoreCase("N"))
							po.setSection("SUPPL");
					}
					//*/sectionMap.put("SUPPL", poSuppl);

				}

				if(remainingNodesAssociation!=null)
				{
					List<List<ParserOutput>> allSuppPO=remainingNodesAssociation.getSupplementaryBreakUpItem();
					ArrayList<ParserOutput> finalList= new ArrayList<ParserOutput>();
					if(allSuppPO!=null && allSuppPO.size()>0)
					{
						for(List<ParserOutput> breakUps:allSuppPO)
						{
							for(ParserOutput brek:breakUps)
							{
								if(((brek.getIsHeading()!=null && brek.getIsHeading().equalsIgnoreCase("Y")) ||  ( brek.getType().equalsIgnoreCase("HEADER"))))
									brek.setSubSection("HEADER");
								brek.setBreakups("Y");
								brek.setSection("SUPPL");
								finalList.add(brek);
							}
						}
						if(finalList.size()>0)
						{
							if(sectionMap.get("SUPPL")!=null)
							{
								sectionMap.get("SUPPL").addAll(finalList);
							}
							else
							{
								sectionMap.put("SUPPL", finalList);
							}
						}
					}
				}

				if(AssociationCreator.implicitSUPPLMetadataMatchingBreakUps!=null && AssociationCreator.implicitSUPPLMetadataMatchingBreakUps.size()>0)
				{
					Map<String, ArrayList<ParserOutput>> addImplicitBreakUP=AssociationCreator.implicitSUPPLMetadataMatchingBreakUps;
					for(String sec:addImplicitBreakUP.keySet())
					{
						System.out.println("Implicit SUPPL Metadata for=="+sec+"=="+addImplicitBreakUP.get(sec).size());
						if(!sectionMap.containsKey("SUPPL"))
						{
							System.out.println("Not Present in Merged Map for Sec="+sec.toUpperCase());
							sectionMap.put("SUPPL", addImplicitBreakUP.get(sec));
						}
						else
						{
							System.out.println("Already Present for Sec="+sec.toUpperCase());
							sectionMap.get("SUPPL").addAll(addImplicitBreakUP.get(sec));
						}
					}
				}

				for(String section:mergedMap.keySet())
				{
					ArrayList<ParserOutput> poList = mergedMap.get(section);
					factorizeMultiLineLabels(poList);
				}

				if(dwSql!=null)
					dwSql.writeTable(Integer.parseInt(docID), mergedMap,false,pageParsesMap,false,coordRequired,language);
				else
					dwOracle.writeTable(Integer.parseInt(docID), mergedMap,false,pageParsesMap,false,coordRequired,language);

				System.out.println("===========DB Done=======");
				System.out.println("===========Excel Writing Now==========");
				try{
					System.out.println("\n\n\nWriting into Excel ... ") ;
					ExcelDataWriter edw = new ExcelDataWriter(thisOutputFileName, fileName) ;
					edw.run(mergedMap,startPg, endPg) ;}catch(Exception e){}
			}
			CustomFileWriter.writeStringToFileWithNewLine("=============Ending the process=======", writer);
			try
			{
				File fout = new File(thisOutputTextFileName);
				FileOutputStream fos = new FileOutputStream(fout);
				writer = new BufferedWriter(new OutputStreamWriter(fos));
			}
			catch(Exception e){}
			CustomFileWriter.writeStringToFileWithNewLine(secIdenficationString, writer);
			CustomFileWriter.writeStringToFileWithNewLine("===========Hierarchy======", writer);
			CustomFileWriter.writeStringToFileWithNewLine(hNodeStr, writer);
			CustomFileWriter.writeStringToFileWithNewLine("", writer);
			CustomFileWriter.writeStringToFileWithNewLine("====================Implicit===============", writer);
			endTime = System.currentTimeMillis();
			System.out.println("Total time taken: "+((endTime-startTime)/1000.)+" seconds.");
			CustomFileWriter.writeStringToFileWithNewLine(ImplicitSplit.tempString, writer);
			CustomFileWriter.writeStringToFileWithNewLine("Total time taken: "+((endTime-startTime)/1000.)+" seconds.", writer);
			try
			{
				writer.close();
			}
			catch(Exception e){}

			if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Total time taken: "+((endTime-startTime)/1000.)+" seconds."));
			if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Extraction Completed."));
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		System.exit(0);

	}

	public static String getCurrentDateTimeString()
	{
		SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd_HH_mm_ss");//dd/MM/yyyy
		Date now = new Date();
		String strDate = sdfDate.format(now);
		return strDate;
	}

	private static boolean areSectionOverLapping(Section mSec, Section thisSec) 
	{
		if(mSec==null || thisSec==null || mSec.getLines()==null || mSec.getLines().size()<1 || thisSec==null || thisSec.getLines().size()<1)
			return false;
		float maxY=Float.MIN_VALUE;
		float minY=Float.MAX_VALUE;

		float thisMaxY=Float.MIN_VALUE;
		float thisMinY=Float.MAX_VALUE;

		for(PDFLine line:mSec.getLines())
		{
			if(minY>line.getY1())
				minY=line.getY1();
			if(maxY<line.getY2())
				maxY=line.getY2();
		}

		for(PDFLine line:thisSec.getLines())
		{
			if(thisMinY>line.getY1())
				thisMinY=line.getY1();
			if(thisMaxY<line.getY2())
				thisMaxY=line.getY2();
		}

		if(minY<thisMaxY && maxY>thisMinY)
			return true;

		return false;
	}

	private static List<Section> removeSectionsWithNegativeNumbers(List<Section> sections) 
	{
		List<Section> ret = new ArrayList<Section>();
		for(Section sec:sections)
		{
			int pg=Utilities.findMaxPageNo(sec);
			int pg1=Utilities.findMinPageNo(sec);
			if(pg<0 || pg1<0)
				continue;

			ret.add(sec);
		}
		return ret;
	}

	private static List<Section> getSectionsBeforeMainStatementRemoved(List<Section> sections) 
	{
		List<Section> ret= new ArrayList<Section>();
		boolean isMainSectionFound=false;
		for(int i=0;i<sections.size();i++)
		{
			if(isMainSectionFound)
			{
				ret.add(sections.get(i));
				continue;
			}
			Section temp=sections.get(i);

			if(temp.getSectionName().trim().equalsIgnoreCase("BS") || temp.getSectionName().trim().equalsIgnoreCase("CF") || temp.getSectionName().trim().equalsIgnoreCase("IS") || temp.getSectionName().trim().equalsIgnoreCase("SE"))
			{
				ret.add(temp);
				isMainSectionFound=true;
			}
		}

		return ret;
	}

	private static List<Section> getFnotesEndSectionsRemoved(List<Section> sections) 
	{
		List<Section> ret= new ArrayList<Section>();
		HashSet<Integer> notesSectionStartPageNos= new HashSet<Integer>();
		HashSet<Integer> notes_EndSectionStartPageNos= new HashSet<Integer>();
		if(sections.size()>0)
		{
			for(Section sec:sections)
			{
				if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
				{
					notesSectionStartPageNos.add(Utilities.findMinPageNo(sec));
				}
				else if(sec.getSectionName().trim().equalsIgnoreCase("fnotes_end"))
				{
					notes_EndSectionStartPageNos.add(Utilities.findMinPageNo(sec));
				}
			}
			notesSectionStartPageNos.retainAll(notes_EndSectionStartPageNos);
			if(notes_EndSectionStartPageNos.size()>0)
			{
				for(Section sec:sections)
				{
					int minPg=Utilities.findMinPageNo(sec);
					if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") && notesSectionStartPageNos.contains(minPg))
					{
						continue;
					}
					else if(sec.getSectionName().trim().equalsIgnoreCase("fnotes_end") && notesSectionStartPageNos.contains(minPg))
					{
						continue;
					}
					else
						ret.add(sec);
				}
			}
			else
				ret.addAll(sections);
		}
		return ret;
	}

	private static List<Section> removeFalsePositivesOnPageNumberBasis(List<Section> sections) 
	{
		List<Section> ret= new ArrayList<Section>();
		Section secFnotesSection=null;
		int startPg=-1;

		for(int i=sections.size()-1;i>=0;i--)
		{
			Section sec=sections.get(i);
			if(secFnotesSection==null && !sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				ret.add(sec);
				continue;
			}
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") && secFnotesSection==null)
			{
				secFnotesSection=sec;
				startPg=Utilities.findMinPageNo(sec);
				ret.add(sec);
				continue;
			}

			if((startPg-Utilities.findMaxPageNo(sec))<6)
			{
				startPg=Utilities.findMinPageNo(sec);
				ret.add(sec);
			}
		}
		return ret;
	}

	private static List<Section> getNotesValidatedOnPageNos(List<Section> sections, TreeMap<Integer, PageParse> pageParsesMap, LinkedHashSet<String> noteSectionList) 
	{
		List<Section> ret= new ArrayList<Section>();
		int numberOfFootnotesSec=0;

		for(int i=0;i<sections.size();i++)
		{
			Section sec=sections.get(i);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") )
				numberOfFootnotesSec++;
		}
		if(numberOfFootnotesSec<2)
		{
			for (Section section : sections) 
			{
				ret.add(section);
			}
			return ret;
		}
		List<Section> tempSectionList= new ArrayList<Section>();
		Section lastNoteSection=null;
		for(Section sec:sections)
		{
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				if(lastNoteSection==null)
				{
					tempSectionList.add(sec);
					lastNoteSection=sec;
					continue;
				}
				int st=Utilities.findMinPageNo(sec);
				int end=Utilities.findMaxPageNo(sec);
				int lastEnd=Utilities.findMaxPageNo(lastNoteSection);
				if((st-lastEnd)<4)
				{
					int minPage=Utilities.findMinPageNo(lastNoteSection);
					List<PDFBlock> blocks=getBlocksFromPageRange(minPage,end,pageParsesMap);
					List<PDFLine> lines=getLinesFromBlocks(blocks);
					lastNoteSection.setBlocks(blocks);
					lastNoteSection.setLines(lines);
				}
				else
				{
					tempSectionList.add(sec);
					lastNoteSection=sec;
				}
			}
			else
				tempSectionList.add(sec);
		}
		int maxPFnotePage=-1;
		List<Section> tempSectionList11= new ArrayList<Section>();
		for(Section sec:tempSectionList)
		{
			int st=Utilities.findMinPageNo(sec);
			int end=Utilities.findMaxPageNo(sec);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				tempSectionList11.add(sec);
				maxPFnotePage=end;
			}
			else
			{
				if(maxPFnotePage==-1)
					tempSectionList11.add(sec);
				else
				{
					if(st<maxPFnotePage)
						continue;
					else
						tempSectionList11.add(sec);
				}
			}
		}

		int startPage=getStartOfNotesOnKeyWordMatch(tempSectionList11,noteSectionList);
		boolean isStartFound=false;
		List<Section> finalSectionList= new ArrayList<Section>();
		for(int i=tempSectionList11.size()-1;i>=0;i--)
		{
			Section sec=tempSectionList11.get(i);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				if(!isStartFound)
				{
					int st=Utilities.findMinPageNo(sec);
					if(st==startPage)
					{
						isStartFound=true;
					}
					finalSectionList.add(sec);
				}
			}
			else
				finalSectionList.add(sec);
		}

		for(int i=finalSectionList.size()-1;i>=0;i--)
		{
			Section sec=finalSectionList.get(i);
			ret.add(sec);
		}
		/*Section footNoteSection=null;
		int footNotesContinuousSectionStartPage=Integer.MAX_VALUE;
		int footNotesContinuousSectionEndPage=Integer.MIN_VALUE;
		Section lastFootNoteSection=null;
		boolean isStartFound=false;
		for(Section sec:sections)
		{
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				int st=Utilities.findMinPageNo(sec);
				int end=Utilities.findMaxPageNo(sec);
				if(!isStartFound)
				{
					footNoteSection=sec;
					isStartFound=true;
					footNotesContinuousSectionStartPage=st;
					footNotesContinuousSectionEndPage=end;
					lastFootNoteSection=sec;
					continue;
				}
				if(isStartFound && ((st-footNotesContinuousSectionEndPage)<3) )
				{
					footNotesContinuousSectionEndPage=end;
				}
				else if(isStartFound && lastFootNoteSection!=null)
				{
					int lastStart=Utilities.findMaxPageNo(lastFootNoteSection);
					int lastEnd=Utilities.findMaxPageNo(lastFootNoteSection);
					if((st-lastEnd)<5)
					{
						footNotesContinuousSectionStartPage=lastStart;
						footNotesContinuousSectionEndPage=end;
					}
				}
				lastFootNoteSection=sec;	
			}
		}

		if(startPage!=-1 && isStartFound)
		{
			footNotesContinuousSectionStartPage=startPage;
		}

		if(isStartFound)
		{
			boolean isFnotesAdded=false;
			for(Section sec:sections)
			{
				int st=Utilities.findMinPageNo(sec);
				int end=Utilities.findMaxPageNo(sec);
				if(end<footNotesContinuousSectionStartPage || st>footNotesContinuousSectionEndPage)
				{
					ret.add(sec);
					continue;
				}
				if(!isFnotesAdded)
				{
					isFnotesAdded=true;
					List<PDFBlock> blocks=getBlocksFromPageRange(footNotesContinuousSectionStartPage,footNotesContinuousSectionEndPage,pageParsesMap);
					List<PDFLine> lines=getLinesFromBlocks(blocks);
					footNoteSection.setBlocks(blocks);
					footNoteSection.setLines(lines);
					ret.add(footNoteSection);
				}
			}
		}
		else
		{
			ret.addAll(sections);
		}*/


		return ret;
	}

	private static int getStartOfNotesOnKeyWordMatch(List<Section> sections, LinkedHashSet<String> noteSectionList) 
	{
		for(Section sec:sections)
		{
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				int minPg=Utilities.findMinPageNo(sec);
				for(PDFBlock line:sec.getBlocks())
				{
					if(line.getPageNo()==minPg)
					{
						String blockString=line.getBlock();
						for(String ky:noteSectionList)
						{
							if(blockString.trim().toLowerCase().contains(ky.trim().toLowerCase()))
								return minPg;
						}
					}
				}
			}
		}
		return -1;
	}

	private static List<Section> checkComprehensiveIS(List<Section> sections) {
		boolean actualISFound = false;
		for(Section section:sections)
		{
			if(!section.getKeyword().getKeyword().toLowerCase().contains("comprehensive") && section.getSectionName().equalsIgnoreCase("IS"))
			{
				actualISFound = true;
				break;
			}
		}

		if(actualISFound)
		{
			List<Section> actualSections = new ArrayList<Section>();
			for(Section section:sections)
			{
				if((!(section.getKeyword().getKeyword().toLowerCase().contains("comprehensive") && section.getSectionName().equalsIgnoreCase("IS"))))
				{
					actualSections.add(section);
				}
			}	
			return actualSections;


		}
		return sections;

	}

	private static List<Section> removeSectionsAfterFootnotesSection(List<Section> sections) 
	{
		// Ignore sections after footnotes
		List<Section> ret = new ArrayList<Section>();
		for (Section sec : sections) 
		{
			if (sec.getSectionName().trim().equalsIgnoreCase("fnotes")) 
			{
				ret.add(sec);
				break;
			}
			ret.add(sec);
		}
		return ret;
	}

	private static List<Section> getPageCountSectionValidated(List<Section> sections) 
	{
		List<Section> ret= new ArrayList<Section>();

		for(Section sec:sections)
		{
			int st=Utilities.findMinPageNo(sec);
			int end=Utilities.findMaxPageNo(sec);

			if(sec.getSectionName().trim().equalsIgnoreCase("is") || 
					sec.getSectionName().trim().equalsIgnoreCase("bs") || sec.getSectionName().trim().equalsIgnoreCase("cf") )
			{
				if((end-st)>5)
				{
					continue;
				}

			}
			ret.add(sec);
		}

		return ret;
	}

	private static List<Section> getNoteValidatedSection(List<Section> sections) 
	{
		List<Section> validSections= new ArrayList<Section>();
		int numberOfFootnotesSec=0;

		if(sections.size()>0 && sections.get(0).getSectionName().trim().equalsIgnoreCase("fnotes") )
			sections.remove(0);
		for(int i=0;i<sections.size();i++)
		{
			Section sec=sections.get(i);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") )
				numberOfFootnotesSec++;
		}
		if(numberOfFootnotesSec<2)
		{
			//validSections.addAll(sections);
			for (Section section : sections) 
			{
				validSections.add(section);
				/*if("fnotes".equals(section.getSectionName()))
					return validSections;*/	

			}
			return validSections;
		}
		// getting upper start and lower end page from all the the footnote section
		// with section starting
		int footNotesContinuousSectionStartPage=Integer.MAX_VALUE;
		int footNotesContinuousSectionEndPage=Integer.MIN_VALUE;
		boolean isStartFound=false;
		for(Section sec:sections)
		{
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				int st=Utilities.findMinPageNo(sec);
				int end=Utilities.findMaxPageNo(sec);
				if((end-st)>8 && !isStartFound)
				{
					isStartFound=true;
					footNotesContinuousSectionStartPage=st;
					footNotesContinuousSectionEndPage=end;
					continue;
				}
				if(isStartFound)
				{
					footNotesContinuousSectionEndPage=end;
				}
			}
		}
		isStartFound=false;
		Section footNotesSection=null;
		for(Section sec:sections)
		{
			int st=Utilities.findMinPageNo(sec);
			int end=Utilities.findMaxPageNo(sec);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") 
					&& footNotesContinuousSectionStartPage==st)
			{
				isStartFound=true;
			}
			if(isStartFound)
			{
				if(footNotesSection==null)
				{
					footNotesSection=sec;
					if(footNotesContinuousSectionEndPage==end)
					{
						footNotesSection.getBlocks().addAll(sec.getBlocks());
						footNotesSection.getLines().addAll(sec.getLines());
						validSections.add(footNotesSection);
						isStartFound=false;
					}
					continue;
				}

				if(footNotesContinuousSectionEndPage==end)
				{
					footNotesSection.getBlocks().addAll(sec.getBlocks());
					footNotesSection.getLines().addAll(sec.getLines());
					validSections.add(footNotesSection);
					isStartFound=false;
				}
				else
				{
					footNotesSection.getBlocks().addAll(sec.getBlocks());
					footNotesSection.getLines().addAll(sec.getLines());
				}
			}
			else
				validSections.add(sec);
		}

		return validSections;
	}

	private static List<Section> getNotesEndCheck(List<Section> sections, TreeMap<Integer, PageParse> pageParsesMap) 
	{
		List<Section> validSections= new ArrayList<Section>();
		int numberOfFootnotesSec=0;
		boolean isFootnotesEndSecFound=false;

		Section fnoteEndSection=null;

		if(sections.size()>0 && ( sections.get(0).getSectionName().trim().equalsIgnoreCase("fnotes") || sections.get(0).getSectionName().trim().equalsIgnoreCase("fnotes_end"))  )
			sections.remove(0);
		for(int i=0;i<sections.size();i++)
		{
			Section sec=sections.get(i);
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes") )
			{
				numberOfFootnotesSec++;
			}
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes_end") && numberOfFootnotesSec>0  )
			{
				isFootnotesEndSecFound=true;
				fnoteEndSection=sec;
				if(numberOfFootnotesSec>0)
					break;
			}
		}
		int maxPageAdded=-1;
		if(numberOfFootnotesSec<2 && isFootnotesEndSecFound)
		{
			for (Section section : sections) 
			{
				if(section.getSectionName().trim().equalsIgnoreCase("fnotes") )
				{
					int minPage=Utilities.findMinPageNo(section);
					int maxPage=(Utilities.findMinPageNo(fnoteEndSection)-1);
					if(minPage>maxPage)
					{
						validSections.add(section);
						continue;
					}
					List<PDFBlock> blocks=getBlocksFromPageRange(minPage,maxPage,pageParsesMap);
					List<PDFLine> lines=getLinesFromBlocks(blocks);
					section.setBlocks(blocks);
					section.setLines(lines);
					maxPageAdded=maxPage;
					validSections.add(section);
				}
				else
				{
					if(maxPageAdded==-1)
						validSections.add(section);
					else
					{
						if(Utilities.findMaxPageNo(section)>maxPageAdded)
							validSections.add(section);
					}
				}

			}
			return validSections;
		}

		int footNotesContinuousSectionStartPage=Integer.MAX_VALUE;
		int footNotesContinuousSectionEndPage=Integer.MIN_VALUE;
		boolean isISFound=false;
		boolean isCFFound=false;
		boolean isBSFound=false;
		boolean isStartFound=false;
		for(Section sec:sections)
		{
			if(sec.getSectionName().trim().equalsIgnoreCase("bs"))
				isBSFound=true;
			if(sec.getSectionName().trim().equalsIgnoreCase("cf"))
				isCFFound=true;
			if(sec.getSectionName().trim().equalsIgnoreCase("is"))
				isISFound=true;
			if(sec.getSectionName().trim().equalsIgnoreCase("fnotes"))
			{
				int st=Utilities.findMinPageNo(sec);
				int end=Utilities.findMaxPageNo(sec);
				if(((end-st)>8  || (isBSFound && isCFFound && isISFound) ) && !isStartFound)
				{
					isStartFound=true;
					footNotesContinuousSectionStartPage=st;
					footNotesContinuousSectionEndPage=end;
					continue;
				}
				if(isStartFound)
				{
					footNotesContinuousSectionEndPage=end;
				}
			}
		}
		maxPageAdded=-1;
		if(isStartFound && isFootnotesEndSecFound)
		{
			boolean isFootNoteAdded=false;
			for(Section section:sections)
			{
				if(section.getSectionName().trim().equalsIgnoreCase("fnotes"))
				{
					int pg=Utilities.findMinPageNo(section);
					if(!isFootNoteAdded && footNotesContinuousSectionStartPage==pg)
					{
						isFootNoteAdded=true;
						int minPage=Utilities.findMinPageNo(section);
						int maxPage=(Utilities.findMinPageNo(fnoteEndSection)-1);
						List<PDFBlock> blocks=getBlocksFromPageRange(minPage,maxPage,pageParsesMap);
						List<PDFLine> lines=getLinesFromBlocks(blocks);
						section.setBlocks(blocks);
						section.setLines(lines);
						maxPageAdded=maxPage;
						validSections.add(section);
					}
				}
				else
				{

					if(maxPageAdded==-1)
						validSections.add(section);
					else
					{
						if(Utilities.findMaxPageNo(section)>maxPageAdded)
							validSections.add(section);
					}

				}
			}
		}
		else
		{
			validSections.addAll(sections);
		}

		return validSections;
	}

	private static List<PDFLine> getLinesFromBlocks(List<PDFBlock> blocks) 
	{
		List<PDFLine> lines= new ArrayList<PDFLine>();

		for(PDFBlock block:blocks)
		{
			lines.addAll(block.getLines());
		}
		return lines;
	}

	private static List<PDFBlock> getBlocksFromPageRange(int minPage, int maxPage,
			TreeMap<Integer, PageParse> pageParsesMap) 
			{
		List<PDFBlock> blocks= new ArrayList<PDFBlock>();

		for(Integer pg:pageParsesMap.keySet())
		{
			PageParse pp=pageParsesMap.get(pg);
			if(pp.getPageLines()!=null && pp.getPageLines().size()>0)
			{
				int pageNo=pp.getPageLines().get(0).getPageNo();
				if(pageNo>=minPage && pageNo<=maxPage)
				{
					blocks.addAll(pp.getPageBlocks());
				}
			}
		}

		return blocks;
			}

	public static Map<Integer, List<PDFCharacter>> convertNativePDFCharToLocal (
			Map<Integer, List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap )
			{
		Map<Integer, List<PDFCharacter>> ret= new TreeMap<Integer, List<PDFCharacter>>(); 
		for(Integer pgNo:pageWiseCharMap.keySet())
		{
			List<com.dp.nda.pdf.beans.PDFCharacter> lst=pageWiseCharMap.get(pgNo);

			for(com.dp.nda.pdf.beans.PDFCharacter pdfCr:lst)
			{
				if(ret.containsKey(pgNo))
				{

					PDFCharacter pdfChar=getLocalPDFCharacterFromNative(pdfCr,pgNo); 
					ret.get(pgNo).add(pdfChar);		
				}
				else
				{
					PDFCharacter pdfChar= getLocalPDFCharacterFromNative(pdfCr,pgNo);
					List<PDFCharacter> charList= new ArrayList<PDFCharacter>();
					charList.add(pdfChar);
					ret.put(pgNo, charList);
				}
			}
		}

		return ret;
			}

	private static PDFCharacter getLocalPDFCharacterFromNative ( com.dp.nda.pdf.beans.PDFCharacter pdfCr, Integer pgNo )
	{
		PDFCharacter pdfChar= new PDFCharacter(pgNo,pdfCr.getRectangle().getX(),pdfCr.getRectangle().getX2()
				,pdfCr.getRectangle().getY2(),pdfCr.getRectangle().getY(),pdfCr.getStringRepresentation(),pdfCr.getFontName()
				,pdfCr.getFontFamily(),pdfCr.getFontSize(),pdfCr.getFontSizeInPt(),pdfCr.getWidthOfSpace(),pdfCr.isBold()
				,pdfCr.isItalic(),pdfCr.getMultiColumnIndex(),pdfCr.getRectangle().getWidth(),pdfCr.getRectangle().getHeight());

		return pdfChar;
	}

	public static String getCompanyName() {
		return companyName;
	}

	public static void setCompanyName(String companyName) {
		FinancialStatementExtractor.companyName = companyName;
	}

	@SuppressWarnings("deprecation")
	private static void mapNonEnglishLabels(
			TreeMap<String, ArrayList<ParserOutput>> mergedMap) {

		for (String section:mergedMap.keySet())	{
			//ArrayList<ParserOutput> list = mergedMap.get(section);
			List<ParserOutput> poObjs = mergedMap.get(section);
			List<Integer> translateStatus = new ArrayList<Integer>() ;
			for ( int i=0; i<poObjs.size(); i++)
			{
				ParserOutput po = poObjs.get(i);

				if(po.getAsRepLabel()!=null)
				{
					String colVal = po.getAsRepLabel().trim();
					if(!(language.equalsIgnoreCase("English") || FinancialStatementExtractor.getLanguage().contains("ITR")) && !colVal.startsWith("STATEMENT"))
					{
						if(!colVal.equalsIgnoreCase(""))
						{
							if(languageLabelMappings!=null &&  languageLabelMappings.size()>0)
							{
								//colVal = po.getAsRepLabel().replaceAll("[[^A-Za-z -&)(0-9-]]", "").trim();
								po.setNonEnglishLabel(colVal);
								if(languageLabelMappings.containsKey(colVal.toLowerCase().trim()))
								{
									po.setAsRepLabel(languageLabelMappings.get(colVal.toLowerCase().trim()));
									translateStatus.add(1) ;
								}
								else
								{
									po.setAsRepLabel(null);
									translateStatus.add(0) ;
								}
							}
							else
							{
								po.setAsRepLabel(null);
								po.setNonEnglishLabel(colVal);
								translateStatus.add(0) ;
							}

						}
						else
						{
							translateStatus.add(-1) ;
						}
					}
					else
					{
						translateStatus.add(-1) ;
					}
				}
				else
				{
					translateStatus.add(-1) ;
				}

			}

			List<String> inputs = new ArrayList<String>() ;
			for ( int i=0 ; i<translateStatus.size() ; i++ )
			{
				if ( translateStatus.get(i).intValue() == 0 )
					inputs.add(poObjs.get(i).getNonEnglishLabel()) ;
			}

			if ( inputs.size() != 0 )
			{
				// List<String> translations = new ArrayList<String>() ;
				// TODO Call translation function

				long translateStart = System.nanoTime() ;

				try
				{

					LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
					java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
					java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

					WebClient browser = null;
					if(useProxy)
						browser = new WebClient(BrowserVersion.CHROME, "172.20.1.20", 2020) ;
					else
						browser = new WebClient(BrowserVersion.CHROME) ;

					browser.getOptions().setJavaScriptEnabled(true) ;
					browser.getOptions().setThrowExceptionOnScriptError(false) ;
					// browser.waitForBackgroundJavaScript(10000) ;

					List<String> translations = new ArrayList<String>() ;
					try 
					{
						translations = BingTranslate.translateBingBulk(browser, inputs);
					}
					catch (Exception e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					browser.close() ;

					long translateEnd = System.nanoTime() ;

					System.out.println("Total time taken in Translation: " + ((translateEnd-translateStart)/1000000000.0)+" Seconds.") ;

					if ( translations != null && translations.size() != 0 )
					{
						for ( int i=0 ; i<inputs.size() ; i++ )
							System.out.println(inputs.get(i) + " ==== " + translations.get(i)) ;

						int index = 0 ;
						for ( int i=0 ; i<translateStatus.size() ; i++ )
						{
							if ( translateStatus.get(i).intValue() == 0 )
							{
								String translation = translations.get(index) ;
								poObjs.get(i).setAsRepLabel(translation) ;
								index++ ;
							}
						}
					}
				}
				catch (Exception e)
				{
					System.err.println("Something wrong with HtmlUnit ... " + e.getMessage()) ;
					e.printStackTrace() ;
				}

			}
		}


	}


	private static void mapBreakupsNonEnglishLabels(
			TreeMap<String, ArrayList<ParserOutput>> mergedMap) {

		for (String section:mergedMap.keySet())	{
			//ArrayList<ParserOutput> list = mergedMap.get(section);

			List<ParserOutput> poObjs = mergedMap.get(section);
			List<Integer> translateStatus = new ArrayList<Integer>() ;
			for ( int i=0; i<poObjs.size(); i++)
			{
				ParserOutput po = poObjs.get(i);

				if(po.getAsRepLabel()!=null && po.getBreakups().equalsIgnoreCase("Y"))
				{
					String colVal = po.getAsRepLabel().trim();
					if(!(language.equalsIgnoreCase("English") || FinancialStatementExtractor.getLanguage().contains("ITR")) && !colVal.startsWith("STATEMENT"))
					{
						if(!colVal.equalsIgnoreCase(""))
						{
							if(languageLabelMappings!=null &&  languageLabelMappings.size()>0)
							{
								//colVal = po.getAsRepLabel().replaceAll("[[^A-Za-z -&)(0-9-]]", "").trim();
								po.setNonEnglishLabel(colVal);
								if(languageLabelMappings.containsKey(colVal.toLowerCase().trim()))
								{
									po.setAsRepLabel(languageLabelMappings.get(colVal.toLowerCase().trim()));
									translateStatus.add(1) ;
								}
								else
								{
									po.setAsRepLabel(null);
									translateStatus.add(0) ;
								}
							}
							else
							{
								po.setAsRepLabel(null);
								po.setNonEnglishLabel(colVal);
								translateStatus.add(0) ;
							}

						}
						else
						{
							translateStatus.add(-1) ;
						}
					}
					else
					{
						translateStatus.add(-1) ;
					}
				}
				else
				{
					translateStatus.add(-1) ;
				}

			}

			List<String> inputs = new ArrayList<String>() ;
			for ( int i=0 ; i<translateStatus.size() ; i++ )
			{
				if ( translateStatus.get(i).intValue() == 0 )
					inputs.add(poObjs.get(i).getNonEnglishLabel()) ;
			}

			if ( inputs.size() != 0 )
			{
				// List<String> translations = new ArrayList<String>() ;
				// TODO Call translation function

				long translateStart = System.nanoTime() ;

				try
				{

					LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
					java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
					java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

					WebClient browser = null;
					if(useProxy)
						browser = new WebClient(BrowserVersion.CHROME, "172.20.1.20", 2020) ;
					else
						browser = new WebClient(BrowserVersion.CHROME) ;

					browser.getOptions().setJavaScriptEnabled(true) ;
					browser.getOptions().setThrowExceptionOnScriptError(false) ;
					// browser.waitForBackgroundJavaScript(10000) ;

					List<String> translations = new ArrayList<String>() ;
					try 
					{
						translations = BingTranslate.translateBingBulk(browser, inputs);
					}
					catch (Exception e) 
					{
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					browser.close() ;

					long translateEnd = System.nanoTime() ;

					System.out.println("Total time taken in Translation: " + ((translateEnd-translateStart)/1000000000.0)+" Seconds.") ;

					if ( translations != null && translations.size() != 0 )
					{
						for ( int i=0 ; i<inputs.size() ; i++ )
							System.out.println(inputs.get(i) + " ==== " + translations.get(i)) ;

						int index = 0 ;
						for ( int i=0 ; i<translateStatus.size() ; i++ )
						{
							if ( translateStatus.get(i).intValue() == 0 )
							{
								String translation = translations.get(index) ;
								poObjs.get(i).setAsRepLabel(translation) ;
								index++ ;
							}
						}
					}
				}
				catch (Exception e)
				{
					System.err.println("Something wrong with HtmlUnit ... " + e.getMessage()) ;
					e.printStackTrace() ;
				}

			}
		}


	}

	public static String getCoordRequired() {
		return coordRequired;
	}

	public static void setCoordRequired(String coordRequired) {
		FinancialStatementExtractor.coordRequired = coordRequired;
	}

	private static void getYear(List<Section> sections) throws Exception {
		for ( int i=0 ; i<sections.size() ; i++ )
		{
			Section section = sections.get(i) ;
			if(section.getSectionName().equalsIgnoreCase("SD"))
			{
				List<PDFLine> sectionLines = section.getLines() ;
				//	StatementAttributes sAttr = new StatementAttributes();
				String yearString  = "";

				if(StatementAttributes.getAttributeMap().containsKey("[YearDefault]"))
				{
					yearString = StatementAttributes.getAttributeMap().get("[YearDefault]").get(0);
				}
				for(PDFLine line:sectionLines)
				{
					String lineString = line.getLine();
					if(lineString.contains(yearString))
					{
						year = lineString.substring(lineString.indexOf(yearString)+yearString.length()+1).trim();
						break;

					}
				}

			}
		}
	}

	public static String getYear() {
		return year;
	}

	public static void setYear(String year) {
		FinancialStatementExtractor.year = year;
	}

	public static String getLanguage() {
		return language;
	}

	public static void setLanguage(String language) {
		FinancialStatementExtractor.language = language;
	}

	public static String getCompanyID() {
		return companyID;
	}

	public static void setCompanyID(String companyID) {
		FinancialStatementExtractor.companyID = companyID;
	}

	private static void setTableID(int ct, ArrayList<ParserOutput> poList) {
		for (ParserOutput po : poList)
		{
			po.setTableID(ct);
		}
	}

	private static void loadLogfile(String filingID)
	{
		ReadLogProperties rlp = new ReadLogProperties();
		try {
			rlp.ReadLogPropertiesFile(filingID,"resource/Extraction-Log4j.Properties");
		} catch (Exception e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
	}

	private static ArrayList<ParserOutput> factorizeMultiLineLabels(List<ParserOutput> list)
	{
		ArrayList<ParserOutput> newList=new ArrayList<ParserOutput>();
		ParserOutput prev=null;
		for(ParserOutput po:list)
		{
			if (po.getMaxCol()==0)
				continue;
			if (prev==null)
			{
				prev=po;
				newList.add(prev);
				continue;
			}
			String text = null;

			if( po.getLine()!=null && po.getPdfLine()!=null)
				text = po.getPdfLine().getLine().toString().replace("[", "").replace("]", "");
			/*else
				if(po.getAsRepLabel()!=null && !po.getAsRepLabel().contains("<") &&  !po.getAsRepLabel().contains(">"))
				{
					text = po.getAsRepLabel();
				}


			if(text==null)
				continue;*/
			if ((text!=null && (prev.getMaxCol()>0 && prev.getAsRepLabel()!=null && 
					(prev.getAsRepLabel().toLowerCase().endsWith(" are") || 
							prev.getAsRepLabel().toLowerCase().endsWith(" between") || prev.getAsRepLabel().toLowerCase().endsWith(" of") || 
							prev.getAsRepLabel().toLowerCase().endsWith(" and") || prev.getAsRepLabel().toLowerCase().endsWith(" at")) 
							|| (prev.getMaxCol()>0 && prev.getAsRepLabel()!=null && prev.getAsRepLabel().toLowerCase().endsWith(";"))
							|| (text!=null && text.trim().length()>0 && Pattern.matches("[a-z]", String.valueOf(text.toString().trim().charAt(0)))))
					) && !text.trim().startsWith("http"))
			{
				if(((prev.getValue1()!=null && !prev.getValue1().trim().equalsIgnoreCase("")) || (prev.getValue2()!=null && !prev.getValue2().trim().equalsIgnoreCase(""))
						|| (prev.getValue3()!=null && !prev.getValue3().trim().equalsIgnoreCase("")) || (prev.getValue4()!=null && !prev.getValue4().trim().equalsIgnoreCase("")))
						&& ((po.getValue1()==null || (po.getValue1()!=null && po.getValue1().trim().equalsIgnoreCase(""))) 
								&&  (po.getValue2()==null || (po.getValue2()!=null && po.getValue2().trim().equalsIgnoreCase(""))) 
								&& (po.getValue3()==null || (po.getValue3()!=null && po.getValue3().trim().equalsIgnoreCase("")))
								&& (po.getValue4()==null || (po.getValue4()!=null && po.getValue4().trim().equalsIgnoreCase("")))))
				{
					mergeRev(prev, po);
				}
				else
				{
					if((((po.getValue1()!=null && !po.getValue1().trim().equalsIgnoreCase("")) || (po.getValue2()!=null && !po.getValue2().trim().equalsIgnoreCase(""))
							|| (po.getValue3()!=null && !po.getValue3().trim().equalsIgnoreCase("")) || (po.getValue4()!=null && !po.getValue4().trim().equalsIgnoreCase("")))
							&& ((prev.getValue1()==null || (prev.getValue1()!=null && prev.getValue1().trim().equalsIgnoreCase(""))) 
									&&  (prev.getValue2()==null || (prev.getValue2()!=null && prev.getValue2().trim().equalsIgnoreCase(""))) 
									&& (prev.getValue3()==null || (prev.getValue3()!=null && prev.getValue3().trim().equalsIgnoreCase("")))
									&& (prev.getValue4()==null || (prev.getValue4()!=null && prev.getValue4().trim().equalsIgnoreCase(""))))) 

									|| (((po.getValue1()==null || (po.getValue1()!=null && po.getValue1().trim().equalsIgnoreCase(""))) 
											&&  (po.getValue2()==null || (po.getValue2()!=null && po.getValue2().trim().equalsIgnoreCase(""))) 
											&& (po.getValue3()==null || (po.getValue3()!=null && po.getValue3().trim().equalsIgnoreCase("")))
											&& (po.getValue4()==null || (po.getValue4()!=null && po.getValue4().trim().equalsIgnoreCase(""))))
											&& ((prev.getValue1()==null || (prev.getValue1()!=null && prev.getValue1().trim().equalsIgnoreCase(""))) 
													&&  (prev.getValue2()==null || (prev.getValue2()!=null && prev.getValue2().trim().equalsIgnoreCase(""))) 
													&& (prev.getValue3()==null || (prev.getValue3()!=null && prev.getValue3().trim().equalsIgnoreCase("")))
													&& (prev.getValue4()==null || (prev.getValue4()!=null && prev.getValue4().trim().equalsIgnoreCase(""))))) )
					{
						merge(po, prev);
					}
				}


				if (po.getMaxCol()>0)
					newList.add(po);
				prev=po;

				continue;
			}
			prev=po;
			if (prev.getMaxCol()>0)
				newList.add(prev);
		}
		return newList;
	}

	private static void mergeRev(ParserOutput source, ParserOutput target)
	{
		if (source==null || target==null) 
			return;

		String label=source.getAsRepLabel()+" "+target.getAsRepLabel();

		//String label=target.getAsRepLabel()+" "+source.getAsRepLabel();
		target.setAsRepLabel("");
		source.setAsRepLabel(label);
	}


	private static void merge(ParserOutput source, ParserOutput target)
	{
		if (source==null || target==null) 
			return;
		String label=target.getAsRepLabel()+" "+source.getAsRepLabel();
		target.setAsRepLabel("");
		source.setAsRepLabel(label);
		if(source.getNotesColumn()==null || source.getNotesColumn().trim().equals(""))
		{
			source.setNotesColumn(target.getNotesColumn());
		}

		/*	
		for (int index=0; index<source.getColumn().size(); index++) {
			if (target.getMaxCol()>index) {
				String label=target.getColumn().get(index)+" "+source.getColumn().get(index);
				target.getColumn().set(index, label.trim());
			} else if (target.getColumn().size()<index)
				target.getColumn().add(source.getColumn().get(index));
						source.setColumns(null);

		}*/
	}

	private void extractBreakups(Map<String,ArrayList<ParserOutput>> sectionMap,TreeMap<Integer, PageParse> pageParsesMap, ParserOutput remainingNodesAssociation) {
		if (sectionMap!=null) {
			if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Extracting breakups for all items ..."));
			//System.out.println("Extracting breakups for all items ...");
			ContentCategorizer contentCategorizer = null;
			try {
				contentCategorizer = new ContentCategorizer(pageParsesMap);
				//Indexer indexer = contentCategorizer.getIndexer();
			} catch (Exception e1) {
				e1.printStackTrace();
			}

			//List<String> searchList = null;
			/*try {
				contentCategorizer.getIndexer().openSearcher(contentCategorizer.getIndexer().getMemory());
			} catch (IOException e2) {
				// TODO Auto-generated catch block
				//e2.printStackTrace();
			}*/

			/*	Set<String> publicCompanyKeywords = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/public_company_keywords.txt");
			for(String keyword : publicCompanyKeywords)
			{
				try {
					searchList = contentCategorizer.getIndexer().search("\""+keyword.trim()+"\"", "englishContent", Type.ID);
				} catch (NumberFormatException e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					//e1.printStackTrace();
				}
			}

			try {
				contentCategorizer.getIndexer().closeSearcher();
			} catch (IOException e1) {
				// TODO Auto-generated catch block
				//e1.printStackTrace();
			}

			if(searchList!=null && searchList.size()==0)
			{*/
			BreakupExtraction breakup = new BreakupExtraction(sectionMap, contentCategorizer);

			breakup.findBreakups(FinancialStatementExtractor.getISBreakups(), FinancialStatementExtractor.BSBreakups,remainingNodesAssociation);


			/*if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Segmenting columns of breakups ..."));

			for (String section : sectionMap.keySet()) {
				if(section.equalsIgnoreCase("IS") || section.equalsIgnoreCase("BS"))
				{
					sectionMap.put(section, factorizeMultiLineLabels(sectionMap.get(section)));

					for (ParserOutput po : sectionMap.get(section)) {

						if (po.getMaxCol()>0 && po.getAsRepLabel()!=null && po.getAsRepLabel().trim().startsWith("STATEMENT"))
							continue;

						if (po.getBreakupItems()!=null && !po.getBreakupItems().isEmpty()) {

							try {
								if (logger!=null)
									logger.debug("Segmenting breakup items of \""+po.getLine()+"\"...");
								// breakups
								validate(po, section);

							}  catch (Exception e) {
								if (logger!=null)
									logger.error(e);
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		/*}*/
		}
	}




	private void validate(ParserOutput po, String section) {
		if (logger!=null)
			logger.debug("Validating item "+po.toString());

		int invalidBreakupCount = 0;
		po.getBreakupItems();
		for (ParserOutput cc : po.getBreakupItems()) {
			if (cc.getSection()!=null && !cc.getSection().equalsIgnoreCase(section))
				invalidBreakupCount++;
		}
		if (invalidBreakupCount==po.getBreakupItems().size())
			po.setBreakupItems(new ArrayList<ParserOutput>());
	}

	public static String getIndustry() {
		return industry;
	}


	public static void createBlocksForSectionPages ( List<Section> sections, String fileName )
	{
		for(Section eachSection : sections)
		{
			List<PDFBlock> blocks = new ArrayList<PDFBlock>() ;

			if(!eachSection.getSectionName().equalsIgnoreCase("znotes"))
			{
				Map<Integer, List<PDFLine>> map = getPageLinesMap(eachSection);

				for(Integer page : map.keySet())
				{
					List<PDFBlock> block = new ArrayList<PDFBlock>() ;

					AdaptiveVerticalBlocksCreater avbc = new AdaptiveVerticalBlocksCreater(page, map.get(page)/*,fileName2,FinancialStatementExtractor.getLanguage()*/) ;
					//avbc.run() ;
					avbc.createBlocksForNonLatin(fileName);

					block = avbc.getBlocks() ;

					blocks.addAll(block);
				}
			}
			eachSection.setBlocks(blocks); 
		}
	}



	private static Map<Integer, List<PDFLine>> getPageLinesMap ( Section eachSection )
	{
		Map<Integer, List<PDFLine>> map = new  TreeMap<Integer, List<PDFLine>>();

		for(PDFLine line : eachSection.getLines())
		{
			if(map.containsKey(line.getPageNo()))
			{
				map.get(line.getPageNo()).add(line);
			}else
			{
				List<PDFLine> newLine = new ArrayList<PDFLine>();
				newLine.add(line);
				map.put(line.getPageNo(), newLine);
			}
		}

		return map;
	}

	private static boolean isDataSetAvailable() throws Exception
	{
		String fileName=Constants.getProperty("train.path");
		if (!fileName.trim().endsWith(System.getProperty("file.separator")))
			fileName+=System.getProperty("file.separator");
		if (Constants.getProperty("train.dataset")!=null)
		{

			if(language.equalsIgnoreCase("Spanish ITR"))
				fileName+=language+"/"+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
			else
				fileName+=industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
		}
		else
			return false;
		if (new File(fileName).exists())
			return true;
		return false;
	}

	public static String getDocID() {
		return docID;
	}

	public static String getStandAlone() {
		return standAlone;
	}

	public static List<String> getProcessingScope() {
		return processingScope;
	}

	private static Map<Integer, List<Section>> getPageNoSectionsMap ( List<Section> sections )
	{
		Map<Integer,List<Section>> pageSection = new TreeMap<Integer, List<Section>>();

		for(Section sec : sections)
		{
			int pageNo = 0;

			if(sec.getLines().size()>0)
				pageNo = sec.getLines().get(0).getPageNo();

			if(pageSection.containsKey(pageNo))
			{
				pageSection.get(pageNo).add(sec);
			}else
			{
				List<Section> sect = new ArrayList<Section>();
				sect.add(sec);
				pageSection.put(pageNo, sect);
			}
		}
		return pageSection;
	}

	private static List<Section> removeMultipleSectionOnSamePage ( List<Section> sections )
	{
		Map<Integer,List<Section>> pageSection = getPageNoSectionsMap(sections);
		List<Section> newSections = new ArrayList<Section>();

		for(Integer pgNo : pageSection.keySet())
		{
			if(pageSection.get(pgNo).size()>3)
			{
				int bsCount = 0;
				int isCount = 0;
				int cfCount = 0;
				int seCount =0;

				List<Section> pageSec = pageSection.get(pgNo);

				for(Section sec : pageSec)
				{
					if(sec.getSectionName().equalsIgnoreCase("BS"))
					{
						bsCount++;
					}else if(sec.getSectionName().equalsIgnoreCase("IS"))
					{
						isCount++;
					}else if(sec.getSectionName().equalsIgnoreCase("CF"))
					{
						cfCount++;
					}else if(sec.getSectionName().equalsIgnoreCase("SE"))
					{
						seCount++;
					}
				}
				if(bsCount>1 && cfCount>1 && isCount>1)
				{
					System.out.println("more than two section found of BS and CF and IS");
				}else if(bsCount>1 && isCount>1 && seCount>1)
				{
					System.out.println("more than two section found of BS and IS and SE");
				}else if(cfCount>1 && isCount>1 && seCount>1)
				{
					System.out.println("more than two section found of CF and IS and SE");
				}else
				{
					newSections.addAll(pageSection.get(pgNo));
				}
			}else
			{
				newSections.addAll(pageSection.get(pgNo));
			}
		}
		return newSections;
	}


	private static void addIndentLevelsToRows ( ArrayList<ParserOutput> poList )
	{
		List<Float> xCorList = new ArrayList<Float>();

		for(ParserOutput po : poList)
		{
			Row row = po.getRow();

			if(row==null || po.getType().equalsIgnoreCase("ATTR") 
					|| po.getType().equalsIgnoreCase("PREV-HEADER") || po.getType().equalsIgnoreCase("HEADER")
					|| po.getAsRepLabel()==null ||po.getAsRepLabel().equalsIgnoreCase(""))
			{
				po.setIndentLevel(0);
				continue;
			}

			List<PDFLine> lines  = row.getModifiedLines();

			for(PDFLine line :  lines)
			{
				//	System.out.println("Line: "+line.getLine());
				//System.out.println("x1= "+line.getX1());

				xCorList.add(line.getX1());
			}
		}

		Map<Integer,Float> levelXCorMap = getLevelXCorMap(xCorList);

		for(ParserOutput po : poList)
		{
			Row row = po.getRow();

			if(row==null || po.getType().equalsIgnoreCase("ATTR") 
					|| po.getType().equalsIgnoreCase("PREV-HEADER") || po.getType().equalsIgnoreCase("HEADER")
					|| po.getAsRepLabel()==null ||po.getAsRepLabel().equalsIgnoreCase(""))
				continue;

			List<PDFLine> lines  = row.getModifiedLines();

			float minX = 99999999f;
			for(PDFLine line :  lines)
			{
				if(minX > line.getX1())
				{
					minX=line.getX1();
				}
			}

			for(Integer level:levelXCorMap.keySet())
			{
				if(Math.abs(levelXCorMap.get(level)-minX) < 1.5f)
				{
					po.setIndentLevel(level);
					break;
				}
			}
		}
		System.out.println("test");

	}


	private static Map<Integer, Float> getLevelXCorMap ( List<Float> xCorList )
	{
		List<Float> xCorListNew = new ArrayList<Float>();		

		Collections.sort(xCorList);

		for(int i=0;i<xCorList.size();i++)
		{
			if(i==0)
			{
				xCorListNew.add(xCorList.get(i));
				continue;
			}

			if(Math.abs(xCorListNew.get(xCorListNew.size()-1) - xCorList.get(i)) > 1.5f)
			{
				xCorListNew.add(xCorList.get(i));
			}
		}

		Map<Integer,Float> levelXCorMap =  new LinkedHashMap<Integer,Float>();

		for(int j=0;j<xCorListNew.size();j++)
		{
			levelXCorMap.put(j, xCorListNew.get(j));
		}

		return levelXCorMap;
	}



	private static void addIndentLevelsToOutput ( TreeMap<String, ArrayList<ParserOutput>> mergedMap )
	{
		for(String section : mergedMap.keySet())
		{
			ArrayList<ParserOutput> poList = mergedMap.get(section);
			int previousLavel = -1;
			String previousBreakup = "N";

			for(ParserOutput po : poList)
			{
				if(po.getBreakups().equalsIgnoreCase("Y"))
				{
					if(previousBreakup.equalsIgnoreCase("N"))
					{
						po.setIndentLevel(previousLavel+1);
						previousLavel=previousLavel+1;
					}else if(previousBreakup.equalsIgnoreCase("Y"))
					{
						po.setIndentLevel(previousLavel);
					}
				}
				previousLavel = po.getIndentLevel();
				previousBreakup = po.getBreakups();
			}

			for(ParserOutput po : poList)
			{
				Row row = po.getRow();

				if(row==null || po.getType().equalsIgnoreCase("ATTR") 
						|| po.getType().equalsIgnoreCase("PREV-HEADER") || po.getType().equalsIgnoreCase("HEADER")
						|| po.getAsRepLabel()==null ||po.getAsRepLabel().equalsIgnoreCase(""))
					continue;

				if(po.getIndentLevel()<1)
				{
					continue;
				}

				int lavel = po.getIndentLevel();

				int spaceCount = lavel*3;

				String space = "";
				for(int s=0;s<spaceCount;s++)
				{
					space = space+" ";
				}

				po.setAsRepLabel(space+po.getAsRepLabel().trim());
			}
		}
	}




	public static String getStorelogic() {
		return storeLogic;
	}

	public static String getReprocess() {
		return reprocess;
	}

	public static org.apache.log4j.Logger getLogger() {
		return logger;
	}

	public static void setStandAlone(String standAlone) {
		FinancialStatementExtractor.standAlone = standAlone;
	}

	public static void setIndustry(String industry) {
		FinancialStatementExtractor.industry = industry;
	}

	public static List<Integer> getContentpgNos() {
		return contentpgNos;
	}

	public static void setContentpgNos(List<Integer> contentpgNos) {
		FinancialStatementExtractor.contentpgNos = contentpgNos;
	}


	private static List<TextValuesExtraction> createTabularData(List<Triplet<String, String, String>> triplets)
	{

		List<TextValuesExtraction> textValuesList = new LinkedList<TextValuesExtraction>();
		for(Triplet<String, String, String> triplet:triplets)
		{
			String value = triplet.getValue2();
			String year = triplet.getValue1();
			String lineItem = triplet.getValue3();
			if(textValuesList.size()==0)
			{
				if(!addMatchedLineItem(textValuesList,lineItem,year,value))
				{
					addUnMatchedLineItem(textValuesList,lineItem,year,value);
				}
			}
		}

		return textValuesList;

	}

	private static boolean addMatchedLineItem(
			List<TextValuesExtraction> textValuesList,String lineItem,String timePeriod, String value) 
	{
		for(TextValuesExtraction textValues:textValuesList)
		{
			if(textValues.getLineItem().trim().equalsIgnoreCase(lineItem))
			{
				LinkedHashMap<String, LinkedList<String>> timePeriodValuesMap = textValues.getTimePeriodValuesMap();
				if(timePeriodValuesMap.containsKey(timePeriod))
				{
					LinkedList<String> valuesList = timePeriodValuesMap.get(timePeriod);
					valuesList.add(value);
				}
				else
				{
					LinkedList<String> valuesList = new LinkedList<String>();
					valuesList.add(value);
					timePeriodValuesMap.put(timePeriod, valuesList);
				}
				return true;
			}
		}

		return false;
	}

	private static boolean addUnMatchedLineItem(
			List<TextValuesExtraction> textValuesList,String lineItem,String timePeriod, String value) 
	{
		TextValuesExtraction textValues = new TextValuesExtraction();
		textValues.setLineItem(lineItem);
		LinkedHashMap<String, LinkedList<String>> timePeriodValuesMap = new LinkedHashMap<String, LinkedList<String>>();
		LinkedList<String> valuesList = new LinkedList<String>();
		valuesList.add(value);
		timePeriodValuesMap.put(timePeriod, valuesList);
		textValues.setTimePeriodValuesMap(timePeriodValuesMap);
		textValuesList.add(textValues);
		return true;
	}

	public static String getBreakups() {
		return breakups;
	}

	public static void setBreakups(String breakups) {
		FinancialStatementExtractor.breakups = breakups;
	}

	public static String getISBreakups() {
		return ISBreakups;
	}

	public static void setISBreakups(String iSBreakups) {
		ISBreakups = iSBreakups;
	}





	public static String getFileName() {
		return fileName;
	}

	public static void setFileName(String fileName) {
		FinancialStatementExtractor.fileName = fileName;
	}

	private static String BSBreakups;
	public static String getBSBreakups() {
		return BSBreakups;
	}

	public static void setBSBreakups(String bSBreakups) {
		BSBreakups = bSBreakups;
	}

	public static String getCFBreakups() {
		return CFBreakups;
	}

	public static void setCFBreakups(String cFBreakups) {
		CFBreakups = cFBreakups;
	}

	public static String getSubsectionMapping() {
		return subsectionMapping;
	}

	public static void setSubsectionMapping(String subsectionMapping) {
		FinancialStatementExtractor.subsectionMapping = subsectionMapping;
	}

	public static int getStartPg() {
		return startPg;
	}

	public static void setStartPg(int startPg) {
		FinancialStatementExtractor.startPg = startPg;
	}

	public static int getEndPg() {
		return endPg;
	}

	public static void setEndPg(int endPg) {
		FinancialStatementExtractor.endPg = endPg;
	}



}
