package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.detectors.text.DataType;
import com.rage.extraction.statements.detectors.text.DataTypeFinder;
import com.rage.extraction.statements.detectors.text.DateDetector;
import com.rage.extraction.statements.detectors.text.NumberDetector;


public class BlockTypeFinder 
{
	public static DataType findBlockType(PDFBlock block)
	{
		PDFLine leftmostLine = findLeftmostLine(block) ;
		leftmostLine = block.getLines().get(0) ;
		String strLine = leftmostLine.getLine() ;
		
		DataType type = findType(strLine) ;
		return type ;
	}

	public static DataType findType(String line) 
	{
		List<String> tokens = new ArrayList<String>(Arrays.asList(line.split(" "))) ;
		
		for ( int n=1 ; n<=3 ; n++ )
		{
			List<String> subTokens = createSubTokens(tokens, n) ;
			String input = "" ;
			for ( int i=0 ; i<subTokens.size() ; i++ )
				input = input.trim() + " " + subTokens.get(i).trim() ;
			input = input.trim() ;
			
			// System.out.println("Input Token: " + input) ;
			
			DataType type = findTextType(input) ;
			if ( type != null )
			{
				// System.out.println("\tFound Type: " + type) ;
				return type ;
			}
		}
		
		// System.out.println("\tSending default type ... " + DataType.TEXT) ;
		return DataType.TEXT ;
	}
	
	private static List<String> createSubTokens(List<String> tokens, int n)
	{
		List<String> ret = new ArrayList<String>() ;
		for ( int i=0 ; i<tokens.size() && i<n ; i++ )
		{
			String token = tokens.get(i) ;
			ret.add(token) ;
		}
		
		return ret ;
	}

	private static DataType findTextType(String strWord)
	{
		
	
		if ( NumberDetector.isCurrency(strWord) )
			return DataType.CURRENCY ;
		
	
		if ( DateDetector.isDate(strWord) )
			return DataType.DATE ;
			
		
		if ( NumberDetector.isNumericValue(strWord) )
			return DataType.NUMERIC_VALUE ;
		
		
		/*List<String> tokens = new ArrayList<String>(Arrays.asList(strWord.split(" "))) ;*/
		/*for ( int i=0 ; i<tokens.size() && i<1 ; i++ )
		{
			String token = tokens.get(i) ;
			if ( token.endsWith(":") || token.equalsIgnoreCase("#") )
				return DataType.KEY ;
		}*/
		
		return DataType.TEXT ;
	}

	private static PDFLine findLeftmostLine(PDFBlock block) 
	{
		PDFLine ret = null ;
		
		for ( int i=0 ; i<block.getLines().size() ; i++ )
		{
			PDFLine line = block.getLines().get(i) ;
			
			if ( ret == null )
			{
				ret = line ;
				continue ;
			}
			
			if ( ret.getX1() > line.getX1() )
			{
				ret = line ;
				continue ;
			}
		}
		
		return ret ;
	}
	
	/**
	 * @param block
	 * @param allTypes
	 * @return
	 */
	public static Pair<DataType, DataType> findAllDataTypes(PDFBlock block, HashSet<DataType> allTypes) 
	{
		List<PDFWord> allWords = createAllWordsFromBlock(block) ;
		/*System.out.println("All Words: " + allWords) ;*/
		
		List<List<PDFWord>> nGrams = createNGramWords(allWords) ;
		/*System.out.println("All N-Grams = " + nGrams) ;*/
		
		HashMap<List<PDFWord>, DataType> wordsTypeMap = new HashMap<List<PDFWord>, DataType>() ;
		
		for ( int i=0 ; i<nGrams.size() ; i++ )
		{
			List<PDFWord> thisGram = nGrams.get(i) ;
			/*System.out.println("\tThis Gram = " + thisGram) ;*/
			
			String text = "" ;
			for ( int j=0 ; j<thisGram.size() ; j++ )
				text = text.trim() + " " + thisGram.get(j).getWord().trim() ;
			text = text.trim() ;
			
			DataType type = findTextType(text) ;
			
			/*System.out.println("\t\tType = " + type) ;*/
			
			if ( type == null )
				continue ;
			
			wordsTypeMap.put(thisGram, type) ;
		}
		
		DataType firstWordType = null ;
		DataType lastWordType = null ;
		
		PDFWord firstWord = allWords.get(0) ;
		PDFWord lastWord = allWords.get(allWords.size()-1) ;
		
		/*System.out.println("First Word = " + firstWord) ;
		System.out.println("Last Word = " + lastWord) ;*/
		
		for ( List<PDFWord> thisGram : wordsTypeMap.keySet() )
		{
			if ( firstWordType == null && thisGram.contains(firstWord) && ((firstWord.toString().length()<=2 && thisGram.size()>1) || (firstWord.toString().length()>2 && thisGram.size()==1)))
				firstWordType = wordsTypeMap.get(thisGram) ;
			
			if ( lastWordType == null && thisGram.contains(lastWord) )
				lastWordType = wordsTypeMap.get(thisGram) ;
				
			allTypes.add(wordsTypeMap.get(thisGram)) ;
		}
		
		firstWordType = firstWordType == null ? DataType.TEXT : firstWordType ;
		lastWordType = lastWordType == null ? DataType.TEXT : lastWordType ;
		
		Pair<DataType, DataType> pair = new Pair<DataType, DataType>(firstWordType, lastWordType) ;
		return pair ;
	}
	
	private static List<PDFWord> createAllWordsFromBlock(PDFBlock block) {
		List<PDFWord> allWords = new ArrayList<PDFWord>() ;
		for ( int i=0 ; i<block.getLines().size() ; i++ )
		{
			PDFLine line = block.getLines().get(i) ;
			for ( int j=0 ; j<line.getChunks().size() ; j++ )
			{
				PDFChunk chunk = line.getChunks().get(j) ;
				for ( int k=0 ; k<chunk.getWords().size() ; k++ )
				{
					PDFWord word = chunk.getWords().get(k) ;
					
					if ( word.getWord().trim().equalsIgnoreCase("") )
						continue ;
					
					allWords.add(word) ;
				}
			}
		}
		return allWords;
	}
	
	private static List<List<PDFWord>> createNGramWords(List<PDFWord> allWords) 
	{		
		List<List<PDFWord>> ret = new ArrayList<List<PDFWord>>() ;
		
		for ( int i=0 ; i<allWords.size() ; i++ )
		{
			List<PDFWord> thisGram = new ArrayList<PDFWord>() ;
			for ( int j=0 ; j<3 ; j++ )
			{
				if ( (i+j) >= allWords.size() )
					continue ;
				
				PDFWord word = allWords.get(i+j) ;
				thisGram.add(word) ;
				
				ret.add(new ArrayList<PDFWord>(thisGram)) ;
			}
		}
		
		return ret ;
	}

	public static void main(String[] args) 
	{
		String line = "2014-12-30 2014-12-30 BC ABC" ;
		System.out.println(findType(line)) ;
	}
}