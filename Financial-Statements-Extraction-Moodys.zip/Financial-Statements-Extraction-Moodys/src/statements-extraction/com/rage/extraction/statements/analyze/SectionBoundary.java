package com.rage.extraction.statements.analyze;


/**
 * @author kiran.umadi
 *
 */
class SectionBoundary implements Comparable<SectionBoundary> {
	private Integer pageNo;
	private Integer lineNo;

	public SectionBoundary() {
	}
	@Override
	public int compareTo(SectionBoundary o) {
		if ((this.pageNo.intValue()*1000+this.lineNo.intValue())<=(o.pageNo.intValue()*1000+o.lineNo.intValue()))
			return 0;
		return 1;
	}

	@Override
	public String toString()
	{
		return "Page:"+String.valueOf(this.pageNo)+" Line:"+String.valueOf(this.lineNo);
	}
	public Integer getPageNo() {
		return pageNo;
	}
	public Integer getLineNo() {
		return lineNo;
	}
}
