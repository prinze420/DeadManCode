package com.rage.extraction.statements.index;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.statements.index.MemIndexer.Type;



public class TestIndex {
	
	public static void main(String[] args) throws Exception {
		String[] text = new String[] {
				"      At 1 January 2013                                                                      -",
				"      - For last year                                                                  120,727",
				"      - For current year                                                               120,728",
				"      At 31 December 2013                                                              241,455",
				"      At 31 December 2013                                                              965,821"
		};
		Indexer indexer = new MemIndexer();
		indexer.openIndexer();
		int i = 0;
		for (String str : text) 
			indexer.indexContent(String.valueOf(++i), str.toLowerCase());
		indexer.closeIndexer();
		
		String query = "241,455";

		Pattern pattern = Pattern.compile("^?[0-9]{1,3}[,]+[0-9]{1,3}(\\s+|\n|$)");
		Matcher matcher = pattern.matcher(text[3]);
		while(matcher.find()) {
			query = matcher.group();
			System.out.println(query);
		}

		indexer.openSearcher(indexer.getMemory());
		System.out.println(indexer.search(query, Type.CONTENT));
		indexer.closeSearcher();
	}

}
