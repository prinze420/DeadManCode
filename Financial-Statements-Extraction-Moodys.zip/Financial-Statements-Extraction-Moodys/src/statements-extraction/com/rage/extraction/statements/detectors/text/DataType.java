package com.rage.extraction.statements.detectors.text;

import java.util.ArrayList;
import java.util.Arrays;

public class DataType 
{
	private int code ;
	
	private DataType(int code)
	{
		setCode(code) ;
	}
	
	private static Integer CODE_TEXT = 0 ;
	private static Integer CODE_NUMBER = 1 ;
	private static Integer CODE_NUMERIC_VALUE = 2 ;
	private static Integer CODE_WHOLE_NUMBER = 3 ;
	private static Integer CODE_DATE = 4 ;
	private static Integer CODE_PERCENTAGE = 5 ;
	private static Integer CODE_CURRENCY = 6 ;
	private static Integer CODE_RANGE = 6 ;

	
	public static DataType TEXT = new DataType(CODE_TEXT) ;
	public static DataType NUMBER = new DataType(CODE_NUMBER) ;
	public static DataType NUMERIC_VALUE = new DataType(CODE_NUMERIC_VALUE) ;
	private static DataType WHOLE_NUMBER = new DataType(CODE_WHOLE_NUMBER) ;
	public static DataType DATE = new DataType(CODE_DATE) ;
	public static DataType PERCENTAGE = new DataType(CODE_PERCENTAGE) ;
	public static DataType CURRENCY = new DataType(CODE_CURRENCY) ;
	public static DataType RANGE = new DataType(CODE_RANGE) ;
	
	public static DataType[] allTypes = new DataType[] {TEXT, NUMBER, NUMERIC_VALUE, WHOLE_NUMBER, DATE, PERCENTAGE,CURRENCY} ;
	private static String[] allNames = new String[] {"TEXT", "NUMBER", "NUMERIC_VALUE", "WHOLE_NUMBER", "DATE", "PERCENTAGE","CURRENCY"} ;
	
	@Override
	public String toString() 
	{
		return  allNames[new ArrayList<DataType>(Arrays.asList(allTypes)).indexOf(this)] ;
	}
	
	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + code;
		
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		DataType other = (DataType) obj;
		
		if (code != other.code)
			return false;
		
		return true;
	}
	
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}
}
