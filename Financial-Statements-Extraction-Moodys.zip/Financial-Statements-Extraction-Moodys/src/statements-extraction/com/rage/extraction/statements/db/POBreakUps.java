package com.rage.extraction.statements.db;

import java.util.ArrayList;
import java.util.List;

import com.dp.hierarchy.HierarchyNode;
import com.dp.structures.Structure;
import com.dp.structures.StructureType;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.associations.AssociationsUtilities;
import com.rage.extraction.statements.extract.pdf.Row;

public class POBreakUps 
{
	public POBreakUps(HierarchyNode node) {
		breakUps= new ArrayList<POBreakUps>();
		setHierarchyNode(node);
	}
	
	public POBreakUps(Row rw) {
		breakUps= new ArrayList<POBreakUps>();
		setRow(rw);
	}
	
	// Structure labels
	private List<POBreakUps> breakUps;
	private Long poID;
	private Long breakUpId;
	private Long referenceBreakUpId;
	private Row row;
	private HierarchyNode hierarchyNode;
	private int startPg=-1;
	private int endPg=-1;
	private float startPgY1;
	private float startPgX1;
	private float endPgY2;
	private float endPgX2;
	private List<PDFLine> lines;
	private List<PDFBlock> blocks;
	
	// Data labels
	private String asRepLabel;
	private String asRepVal1;
	private String value1;
	private String asRepVal2;
	private String value2;
	private String asRepVal3;
	private String value3;
	private String asRepVal4;
	private String value4;
	private String asRepVal5;
	private String value5;
	private String asRepVal6;
	private String value6;
	private String asRepVal7;
	private String value7;
	private String asRepVal8;
	private String value8;
	private String asRepVal9;
	private String value9;
	private String asRepVal10;
	private String value10;
	private String asRepVal11;
	private String value11;
	private String asRepVal12;
	private String value12;
	private String asRepVal13;
	private String value13;
	private String asRepVal14;
	private String value14;
	private String asRepVal15;
	private String value15;
	private String asRepVal16;
	private String value16;
	private String asRepVal17;
	private String value17;
	private String asRepVal18;
	private String value18;
	private String asRepVal19;
	private String value19;
	private String asRepVal20;
	private String value20;
	private String asRepVal21;
	private String value21;
	private String asRepVal22;
	private String value22;
	private String asRepVal23;
	private String value23;
	private String asRepVal24;
	private String value24;
	private String asRepVal25;
	private String value25;
	private String asRepVal26;
	private String value26;
	private String asRepVal27;
	private String value27;
	private String asRepVal28;
	private String value28;
	private String asRepVal29;
	private String value29;
	private String asRepVal30;
	private String value30;
	
	public List<POBreakUps> getBreakUps() {
		return breakUps;
	}
	public void setBreakUps(List<POBreakUps> breakUps) {
		this.breakUps = breakUps;
	}
	public Long getPoID() {
		return poID;
	}
	public void setPoID(Long poID) {
		this.poID = poID;
	}
	public Long getBreakUpId() {
		return breakUpId;
	}
	public void setBreakUpId(Long breakUpId) {
		this.breakUpId = breakUpId;
	}
	public Long getReferenceBreakUpId() {
		return referenceBreakUpId;
	}
	public void setReferenceBreakUpId(Long referenceBreakUpId) {
		this.referenceBreakUpId = referenceBreakUpId;
	}
	public Row getRow() {
		return row;
	}
	public void setRow(Row row) {
		this.row = row;
	}
	public String getAsRepLabel() {
		return asRepLabel;
	}
	public void setAsRepLabel(String asRepLabel) {
		this.asRepLabel = asRepLabel;
	}
	public String getAsRepVal1() {
		return asRepVal1;
	}
	public void setAsRepVal1(String asRepVal1) {
		this.asRepVal1 = asRepVal1;
	}
	public String getValue1() {
		return value1;
	}
	public void setValue1(String value1) {
		this.value1 = value1;
	}
	public String getAsRepVal2() {
		return asRepVal2;
	}
	public void setAsRepVal2(String asRepVal2) {
		this.asRepVal2 = asRepVal2;
	}
	public String getValue2() {
		return value2;
	}
	public void setValue2(String value2) {
		this.value2 = value2;
	}
	public String getAsRepVal3() {
		return asRepVal3;
	}
	public void setAsRepVal3(String asRepVal3) {
		this.asRepVal3 = asRepVal3;
	}
	public String getValue3() {
		return value3;
	}
	public void setValue3(String value3) {
		this.value3 = value3;
	}
	public String getAsRepVal4() {
		return asRepVal4;
	}
	public void setAsRepVal4(String asRepVal4) {
		this.asRepVal4 = asRepVal4;
	}
	public String getValue4() {
		return value4;
	}
	public void setValue4(String value4) {
		this.value4 = value4;
	}
	public String getAsRepVal5() {
		return asRepVal5;
	}
	public void setAsRepVal5(String asRepVal5) {
		this.asRepVal5 = asRepVal5;
	}
	public String getValue5() {
		return value5;
	}
	public void setValue5(String value5) {
		this.value5 = value5;
	}
	public String getAsRepVal6() {
		return asRepVal6;
	}
	public void setAsRepVal6(String asRepVal6) {
		this.asRepVal6 = asRepVal6;
	}
	public String getValue6() {
		return value6;
	}
	public void setValue6(String value6) {
		this.value6 = value6;
	}
	public String getAsRepVal7() {
		return asRepVal7;
	}
	public void setAsRepVal7(String asRepVal7) {
		this.asRepVal7 = asRepVal7;
	}
	public String getValue7() {
		return value7;
	}
	public void setValue7(String value7) {
		this.value7 = value7;
	}
	public String getAsRepVal8() {
		return asRepVal8;
	}
	public void setAsRepVal8(String asRepVal8) {
		this.asRepVal8 = asRepVal8;
	}
	public String getValue8() {
		return value8;
	}
	public void setValue8(String value8) {
		this.value8 = value8;
	}
	public String getAsRepVal9() {
		return asRepVal9;
	}
	public void setAsRepVal9(String asRepVal9) {
		this.asRepVal9 = asRepVal9;
	}
	public String getValue9() {
		return value9;
	}
	public void setValue9(String value9) {
		this.value9 = value9;
	}
	public String getAsRepVal10() {
		return asRepVal10;
	}
	public void setAsRepVal10(String asRepVal10) {
		this.asRepVal10 = asRepVal10;
	}
	public String getValue10() {
		return value10;
	}
	public void setValue10(String value10) {
		this.value10 = value10;
	}
	public String getAsRepVal11() {
		return asRepVal11;
	}
	public void setAsRepVal11(String asRepVal11) {
		this.asRepVal11 = asRepVal11;
	}
	public String getValue11() {
		return value11;
	}
	public void setValue11(String value11) {
		this.value11 = value11;
	}
	public String getAsRepVal12() {
		return asRepVal12;
	}
	public void setAsRepVal12(String asRepVal12) {
		this.asRepVal12 = asRepVal12;
	}
	public String getValue12() {
		return value12;
	}
	public void setValue12(String value12) {
		this.value12 = value12;
	}
	public String getAsRepVal13() {
		return asRepVal13;
	}
	public void setAsRepVal13(String asRepVal13) {
		this.asRepVal13 = asRepVal13;
	}
	public String getValue13() {
		return value13;
	}
	public void setValue13(String value13) {
		this.value13 = value13;
	}
	public String getAsRepVal14() {
		return asRepVal14;
	}
	public void setAsRepVal14(String asRepVal14) {
		this.asRepVal14 = asRepVal14;
	}
	public String getValue14() {
		return value14;
	}
	public void setValue14(String value14) {
		this.value14 = value14;
	}
	public String getAsRepVal15() {
		return asRepVal15;
	}
	public void setAsRepVal15(String asRepVal15) {
		this.asRepVal15 = asRepVal15;
	}
	public String getValue15() {
		return value15;
	}
	public void setValue15(String value15) {
		this.value15 = value15;
	}
	public String getAsRepVal16() {
		return asRepVal16;
	}
	public void setAsRepVal16(String asRepVal16) {
		this.asRepVal16 = asRepVal16;
	}
	public String getValue16() {
		return value16;
	}
	public void setValue16(String value16) {
		this.value16 = value16;
	}
	public String getAsRepVal17() {
		return asRepVal17;
	}
	public void setAsRepVal17(String asRepVal17) {
		this.asRepVal17 = asRepVal17;
	}
	public String getValue17() {
		return value17;
	}
	public void setValue17(String value17) {
		this.value17 = value17;
	}
	public String getAsRepVal18() {
		return asRepVal18;
	}
	public void setAsRepVal18(String asRepVal18) {
		this.asRepVal18 = asRepVal18;
	}
	public String getValue18() {
		return value18;
	}
	public void setValue18(String value18) {
		this.value18 = value18;
	}
	public String getAsRepVal19() {
		return asRepVal19;
	}
	public void setAsRepVal19(String asRepVal19) {
		this.asRepVal19 = asRepVal19;
	}
	public String getValue19() {
		return value19;
	}
	public void setValue19(String value19) {
		this.value19 = value19;
	}
	public String getAsRepVal20() {
		return asRepVal20;
	}
	public void setAsRepVal20(String asRepVal20) {
		this.asRepVal20 = asRepVal20;
	}
	public String getValue20() {
		return value20;
	}
	public void setValue20(String value20) {
		this.value20 = value20;
	}
	public String getAsRepVal21() {
		return asRepVal21;
	}
	public void setAsRepVal21(String asRepVal21) {
		this.asRepVal21 = asRepVal21;
	}
	public String getValue21() {
		return value21;
	}
	public void setValue21(String value21) {
		this.value21 = value21;
	}
	public String getAsRepVal22() {
		return asRepVal22;
	}
	public void setAsRepVal22(String asRepVal22) {
		this.asRepVal22 = asRepVal22;
	}
	public String getValue22() {
		return value22;
	}
	public void setValue22(String value22) {
		this.value22 = value22;
	}
	public String getAsRepVal23() {
		return asRepVal23;
	}
	public void setAsRepVal23(String asRepVal23) {
		this.asRepVal23 = asRepVal23;
	}
	public String getValue23() {
		return value23;
	}
	public void setValue23(String value23) {
		this.value23 = value23;
	}
	public String getAsRepVal24() {
		return asRepVal24;
	}
	public void setAsRepVal24(String asRepVal24) {
		this.asRepVal24 = asRepVal24;
	}
	public String getValue24() {
		return value24;
	}
	public void setValue24(String value24) {
		this.value24 = value24;
	}
	public String getAsRepVal25() {
		return asRepVal25;
	}
	public void setAsRepVal25(String asRepVal25) {
		this.asRepVal25 = asRepVal25;
	}
	public String getValue25() {
		return value25;
	}
	public void setValue25(String value25) {
		this.value25 = value25;
	}
	public String getAsRepVal26() {
		return asRepVal26;
	}
	public void setAsRepVal26(String asRepVal26) {
		this.asRepVal26 = asRepVal26;
	}
	public String getValue26() {
		return value26;
	}
	public void setValue26(String value26) {
		this.value26 = value26;
	}
	public String getAsRepVal27() {
		return asRepVal27;
	}
	public void setAsRepVal27(String asRepVal27) {
		this.asRepVal27 = asRepVal27;
	}
	public String getValue27() {
		return value27;
	}
	public void setValue27(String value27) {
		this.value27 = value27;
	}
	public String getAsRepVal28() {
		return asRepVal28;
	}
	public void setAsRepVal28(String asRepVal28) {
		this.asRepVal28 = asRepVal28;
	}
	public String getValue28() {
		return value28;
	}
	public void setValue28(String value28) {
		this.value28 = value28;
	}
	public String getAsRepVal29() {
		return asRepVal29;
	}
	public void setAsRepVal29(String asRepVal29) {
		this.asRepVal29 = asRepVal29;
	}
	public String getValue29() {
		return value29;
	}
	public void setValue29(String value29) {
		this.value29 = value29;
	}
	public String getAsRepVal30() {
		return asRepVal30;
	}
	public void setAsRepVal30(String asRepVal30) {
		this.asRepVal30 = asRepVal30;
	}
	public String getValue30() {
		return value30;
	}
	public void setValue30(String value30) {
		this.value30 = value30;
	}
	public HierarchyNode getHierarchyNode() {
		return hierarchyNode;
	}
	public void setHierarchyNode(HierarchyNode hierarchyNode) {
		this.hierarchyNode = hierarchyNode;
	}
	
	public int getStartPg() {
		return startPg;
	}

	public void setStartPg(int startPg) {
		this.startPg = startPg;
	}

	public int getEndPg() {
		return endPg;
	}

	public void setEndPg(int endPg) {
		this.endPg = endPg;
	}

	public float getStartPgY1() {
		return startPgY1;
	}

	public void setStartPgY1(float startPgY1) {
		this.startPgY1 = startPgY1;
	}

	public float getStartPgX1() {
		return startPgX1;
	}

	public void setStartPgX1(float startPgX1) {
		this.startPgX1 = startPgX1;
	}

	public float getEndPgY2() {
		return endPgY2;
	}

	public void setEndPgY2(float endPgY2) {
		this.endPgY2 = endPgY2;
	}

	public float getEndPgX2() {
		return endPgX2;
	}

	public void setEndPgX2(float endPgX2) {
		this.endPgX2 = endPgX2;
	}
	
	public static void setCoOrdinate(POBreakUps breakUp)
	{
		if(breakUp==null)
			return;
		int startPg=Integer.MAX_VALUE;
		int endPg=Integer.MIN_VALUE;
		float x1=Float.MAX_VALUE;
		float y1=Float.MAX_VALUE;
		float x2=Float.MIN_VALUE;
		float y2=Float.MIN_VALUE;
		if(breakUp.getRow()!=null)
		{
			for(PDFLine line:breakUp.getRow().getLines())
			{
				if(startPg>line.getPageNo())
					startPg=line.getPageNo();
				if(endPg<line.getPageNo())
					endPg=line.getPageNo();
				
				if(startPg==line.getPageNo())
				{
					if(x1>line.getX1())
						x1=line.getX1();
					if(y1>line.getY1())
						y1=line.getY1();
				}
				
				if(endPg==line.getPageNo())
				{
					if(x2<line.getX2())
						x2=line.getX2();
					if(y2<line.getY2())
						y2=line.getY2();
				}
			}
		}
		else if (breakUp.getHierarchyNode()!=null)
		{
			List<HierarchyNode> nodes=AssociationsUtilities.getAllTheNodesFromANode(breakUp.getHierarchyNode());
			for(HierarchyNode node:nodes)
			{
				Structure dataNode=node.getNode();
				if(dataNode!=null)
				{
					if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.TITLE))
					{
						Title title=(Title)dataNode;
						if(startPg>title.getRectangle().getPageNo())
							startPg=title.getRectangle().getPageNo();
						if(endPg<title.getRectangle().getPageNo())
							endPg=title.getRectangle().getPageNo();
						if(startPg==title.getRectangle().getPageNo())
						{
							if(x1>title.getRectangle().getX())
								x1=title.getRectangle().getX();
							if(y1>title.getRectangle().getY2())
								y1=title.getRectangle().getY2();
						}
						if(endPg==title.getRectangle().getPageNo())
						{
							if(x2<title.getRectangle().getX2())
								x2=title.getRectangle().getX2();
							if(y2<title.getRectangle().getY())
								y2=title.getRectangle().getY();
						}
					}
					else if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.TABLE))
					{
						DPTable table=(DPTable)dataNode;
						List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
						for(PDFLine line:lines)
						{
							if(startPg>line.getPageNo())
								startPg=line.getPageNo();
							if(endPg<line.getPageNo())
								endPg=line.getPageNo();
							
							if(startPg==line.getPageNo())
							{
								if(x1>line.getX1())
									x1=line.getX1();
								if(y1>line.getY1())
									y1=line.getY1();
							}
							
							if(endPg==line.getPageNo())
							{
								if(x2<line.getX2())
									x2=line.getX2();
								if(y2<line.getY2())
									y2=line.getY2();
							}	
							
						}
					}
					else if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.PPARAGRAPH))
					{
						Paragraph paragraph=(Paragraph)dataNode;
						List<PDFLine> lines=AssociationsUtilities.getParagraphDataFromHierarchyNode(paragraph);
						for(PDFLine line:lines)
						{
							if(startPg>line.getPageNo())
								startPg=line.getPageNo();
							if(endPg<line.getPageNo())
								endPg=line.getPageNo();
							
							if(startPg==line.getPageNo())
							{
								if(x1>line.getX1())
									x1=line.getX1();
								if(y1>line.getY1())
									y1=line.getY1();
							}
							
							if(endPg==line.getPageNo())
							{
								if(x2<line.getX2())
									x2=line.getX2();
								if(y2<line.getY2())
									y2=line.getY2();
							}	
							
						}
					}
						
				}
			}
		}
		breakUp.setStartPg(startPg);
		breakUp.setEndPg(endPg);
		breakUp.setStartPgX1(x1);
		breakUp.setStartPgY1(y1);
		breakUp.setEndPgX2(x2);
		breakUp.setEndPgY2(y2);
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public List<PDFBlock> getBlocks() {
		return blocks;
	}

	public void setBlocks(List<PDFBlock> blocks) {
		this.blocks = blocks;
	}
	
	
}
