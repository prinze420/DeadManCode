package com.rage.extraction.statements.detectors.text;

import java.io.Serializable;

enum EnumerationType implements Serializable
{
	NONE,
	ALPHA, // NO_UCD (unused code)
	ALPHA_LOWER_DOT,
	ALPHA_LOWER_BRACKET,
	ALPHA_UPPER_BRACKET,
	ALPHA_UPPER_DOT,
	ROMAN, // NO_UCD (unused code)
	ROMAN_LOWER_DOT,
	ROMAN_LOWER_BRACKET,
	ROMAN_UPPER_BRACKET,
	ROMAN_UPPER_DOT,
	BULLETS,
	NUMBER_BRACKET,
	NUMBER, // NO_UCD (unused code)
	NUMBER_DOT_LEVEL_ONE,
	NUMBER_DOT_LEVEL_TWO,
	NUMBER_DOT_LEVEL_THREE,
	NUMBER_DOT_LEVEL_FOUR,
	NUMBER_DOT_LEVEL_FIVE,
	EMPTY
}
