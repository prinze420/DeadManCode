package com.rage.extraction.statements.analyze;

import java.util.List;
import java.util.Map;

import com.rage.extraction.statements.db.ParserOutput;


class ContentCluster{
	private Map<SectionBoundary, List<ParserOutput>> clusterGroups;

	public Map<SectionBoundary, List<ParserOutput>> getClusterGroups() {
		return clusterGroups;
	}
}
