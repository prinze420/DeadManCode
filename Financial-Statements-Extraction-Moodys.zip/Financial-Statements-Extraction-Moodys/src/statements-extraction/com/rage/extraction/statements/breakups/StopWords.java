package com.rage.extraction.statements.breakups;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;



class StopWords 
{
	private Set<String> stopwords = new HashSet<String>();
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StopWords.class);

	public StopWords() 
	{
		String stopwords = "";
		stopwords =  "resource/stop-words/stop-words.txt";
		try
		{
			new SafeFile(stopwords);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(stopwords);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		if (new File(stopwords).exists())
			read(stopwords);
		else
			System.err.println("stop-words.txt not found");

	}

	private void read(String fileName) 
	{
		FileInputStream fileInputStream = null;
		InputStreamReader inputStreamReader = null;
		BufferedReader br = null;

		try 
		{
			fileInputStream = new FileInputStream(new File(fileName));
			inputStreamReader = new InputStreamReader(fileInputStream, "UTF-8");
			br = new BufferedReader(inputStreamReader);

			String line ="";

			while((line = br.readLine()) != null) 
			{
				stopwords.add(line.toLowerCase());
			}
		} catch (Exception e) 
		{

		} finally 
		{
			try 
			{
				if(br!=null) 
				{
					br.close();
					inputStreamReader.close();
					fileInputStream.close();
				}
			} catch (Exception e) 
			{
			}
		}
	}

	private boolean isStopword(String word) {
		if (word !=null && !word.trim().isEmpty())
			return stopwords.contains(word);
		return false;
	}

	String remove(String text) {
		StringBuffer stringBuffer = new StringBuffer();
		String[] words = text.split("\\W");
		for (String word : words) {
			if (!isStopword(word.toLowerCase()))
				stringBuffer.append(word + " ");
		}
		return stringBuffer.toString();
	}

	public static void main(String[] args) {
		StopWords stopWords = new StopWords();
		System.out.println(stopWords.isStopword("that"));
		System.out.println(stopWords.remove("Cash and cash equivalent's at the end of the period"));
	}

}
