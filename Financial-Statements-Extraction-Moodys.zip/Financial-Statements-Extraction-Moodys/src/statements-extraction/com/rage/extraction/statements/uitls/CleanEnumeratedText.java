package com.rage.extraction.statements.uitls;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.statements.constant.Constants;


public class CleanEnumeratedText {
	private Pattern alphabetic = Pattern.compile("^[(]?[a-zA-ZIVX]{1,3}[.]?[)]?\\s*"); // "^[(]?[a-zA-Z]{1,4}[.]?[)]?\\s"
	private Pattern numeric = Pattern.compile("^[(]?[[0-9][[、]]]+[)]?\\s | ^[(]?[[0-9][.]]+[)]?\\s|^[(]?[[0-9]\\s*[.]?]+[)]|^[\\d+-]+");
			//("^[(]?[[0-9][.]?]+[)]\\s");
	
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(CleanEnumeratedText.class);


	public CleanEnumeratedText() {
		Constants.loadResourceProperty();
		if (Constants.getProperty("alphabetic.enumeration")!=null)
			alphabetic = Pattern.compile(Constants.getProperty("alphabetic.enumeration"));
		if (Constants.getProperty("numeric.enumeration")!=null)
			numeric = Pattern.compile(Constants.getProperty("numeric.enumeration"));
	}

	public String replaceEnums(String text) {
		if (text!=null && !text.trim().isEmpty()) {

			if (logger!=null)
				logger.debug("Cleaning alphabetic and numeric enumerated column values ...");

			String startws = "";
			String endws = "";
			
			//System.out.println("before :"+text);
			if (text.length()!=text.trim().length()) {
				int index = text.indexOf(text.trim());
				if (index > 25)
					return text;
				if (index > 0)
					startws =  whiteSpace(index);
				else if (index == 0)
					endws = whiteSpace(text.length() - text.trim().length());
				text = text.trim();
			}

			StringBuffer buffer = new StringBuffer(text);
			Matcher matcher = alphabetic.matcher(text.trim());
			while (matcher.find()) {
				String enumMatched = matcher.group();
				if (logger!=null)
					logger.debug("Cleaning :"+enumMatched);
				buffer.replace(matcher.start(), matcher.start()+enumMatched.length(), whiteSpace(enumMatched.length()));
			}
			text = buffer.toString();

			matcher = numeric.matcher(text.trim());
			while (matcher.find()) {
				String enumMatched = matcher.group();
				if (logger!=null)
					logger.debug("Cleaning :"+enumMatched);

				if (!enumMatched.trim().startsWith("20") && enumMatched.trim().length()!=4)
					buffer.replace(matcher.start(), matcher.start()+enumMatched.length(), whiteSpace(enumMatched.length()));
			}
			text = startws + buffer.toString().replaceAll("[,\\)\\(.]","") + endws;
		}
		return text;
	}

	private String whiteSpace(int numOfWS) {
		String text = "";
		for (int i=0; i<numOfWS; i++)
			text = text + " ";
		return text;
	}

	public static void main(String[] args) {
		String text="  (1.1) Consumo de mercader�as                   1.)     1.2)     1.1.2)                                              b.)                (36.618,49)        (L250,97)";
		text = "1、 Revenue from operations                                         17                   1,26,72,35,077.85                 93,13,55,378.89";
		text = "1、合并资产负债表";

		System.out.println(text);
		text = new CleanEnumeratedText().replaceEnums(text);
		System.out.println(text);
	}

}
