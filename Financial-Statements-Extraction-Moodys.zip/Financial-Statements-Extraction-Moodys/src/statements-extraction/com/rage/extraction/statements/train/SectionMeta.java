package com.rage.extraction.statements.train;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;



/**
 * @author kiran.umadi
 *
 */
public class SectionMeta {
	private List<String[]> rawMeta;
	private Map<String, List<String[]>> secMap;
	private static SectionMeta instance=null;
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SectionMeta.class);

	private SectionMeta() throws Exception {
		Constants.loadResourceProperty();
	}

	public static SectionMeta getInstance() throws Exception
	{
		synchronized (SectionMeta.class) {
			if (instance==null)
			{
				instance=new SectionMeta();
				instance.read();
			}
		}
		return instance;
	}

	int mapOrdinal(String subsection)
	{
		if (secMap==null)
			return -1;
		if (subsection.indexOf("-")!=-1)
		{
			String key=subsection.split("-")[0];
			for (int index=0; index<secMap.get(key).size(); index++)
			{
				if (subsection.equalsIgnoreCase(secMap.get(key).get(index)[0]))
					return index;
			}
		}
		return -1;
	}

	private void read(String fileName) throws Exception
	{
		try
		{
			new SafeFile(fileName);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(fileName);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		BufferedReader br=new BufferedReader(new FileReader(fileName));
		String line="";
		if (rawMeta==null)
		{
			rawMeta=new ArrayList<String[]>();
			while((line=br.readLine())!=null)
			{
				line=line.trim();
				if (line.trim().equals(""))
					continue;
				rawMeta.add(line.split("\t"));
			}
			br.close();
		}
	}

	private void read() throws Exception
	{
	String fileName=Constants.getProperty("train.section");

		String file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+FinancialStatementExtractor.getIndustry()+".txt";

		if (file.equals(""))
			return;
		this.read(file);

		/*if (fileName.equals(""))
			return;
		this.read(fileName);*/
		this.populateMap();
	}

	public Map<String, List<String[]>> getSecMap() {
		return secMap;
	}

	private void populateMap()
	{
		if (rawMeta!=null)
		{
			secMap=new HashMap<String, List<String[]>>();
			for(String[] tokens:rawMeta)
			{
				if (tokens[0].indexOf("-")!=-1)
				{
					String[] tok=tokens[0].split("-");
					if (!secMap.containsKey(tok[0]))
						secMap.put(tok[0], new ArrayList<String[]>());
					List<String[]> list=secMap.get(tok[0]);
					list.add(tokens);
				}
			}
		}
	}

	private String getPrevSubSection(String subSection)
	{
		String subsec="";
		if (subSection.indexOf("-")!=-1 && secMap!=null)
		{
			String section=subSection.trim().split("-")[0].toUpperCase();
			List<String[]> subSecList=secMap.get(section);
			for (String[] tokens:subSecList)
			{
				if (tokens[0].equalsIgnoreCase(subSection))
					return subsec;
				subsec=tokens[0];
			}
		}
		return subsec;
	}

	public String getNextSubSection(String subSection)
	{
		String subsec="";
		if (subSection.indexOf("-")!=-1 && secMap!=null)
		{
			String section=subSection.trim().split("-")[0];
			List<String[]> subSecList=secMap.get(section);
			for (int index=0; index<subSecList.size(); index++)
			{
				String[] tokens=subSecList.get(index);
				if (!tokens[0].equalsIgnoreCase(subSection))
					continue;
				if (subSecList.size()>index+1)
				{
					subsec=subSecList.get(index+1)[0];
					return subsec;
				}
			}
		}
		return subsec;
	}

	public static void main(String[] args) throws Exception {
		SectionMeta meta=SectionMeta.getInstance();
		System.out.println(meta.getPrevSubSection("IS-cogs"));

		SectionMeta meta1=SectionMeta.getInstance();
		System.out.println(meta1.getNextSubSection("IS-cogs"));

	}
}
