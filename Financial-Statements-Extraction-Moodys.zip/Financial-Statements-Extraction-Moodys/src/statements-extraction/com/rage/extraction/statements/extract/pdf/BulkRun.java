package com.rage.extraction.statements.extract.pdf;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class BulkRun 
{
	public static void main(String[] args) {
		String folderName="C:/Users/sm0e1016/Desktop/60Pdfs/";
		
		List<String> pdfList=getFilesList(folderName);
		int i=0;
		for(String fileName:pdfList)
		{
			System.out.println("Running for File=="+fileName);
			System.gc();
			try
			{
				String[] passArgs=new String[12];
				passArgs[0]="123";
				passArgs[1]="false";
				passArgs[2]=fileName;
				passArgs[3]="Yes";
				passArgs[4]="Corporate";
				passArgs[5]="On";
				passArgs[6]="No";
				passArgs[7]="No";
				passArgs[8]="0";
				passArgs[9]="English";
				passArgs[10]="true";
				passArgs[11]="No";
				
				FinancialStatementExtractor.main(passArgs);
				System.out.println("Done Running for File=="+fileName);
			}
			catch(Exception e)
			{
				System.out.println("Error for File======"+fileName);
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
			i++;
			System.out.println("Total PDFS done in Bulk=="+i);
			System.gc();
		}
		System.out.println("All files Done=====");
	}

	public static List<String> getFilesList(String folderPath)
	{
		List<String> ret= new ArrayList<String>();
		File folder = new File(folderPath);
		File[] listOfFiles = folder.listFiles();

		    for (int i = 0; i < listOfFiles.length; i++) 
		    {
		      if (listOfFiles[i].isFile()) 
		      {
		    	  if(listOfFiles[i].getAbsolutePath().endsWith(".pdf") || listOfFiles[i].getAbsolutePath().endsWith(".PDF"))
		    	  {
		    		  ret.add(listOfFiles[i].getAbsolutePath());
		    	  }
		      } 
		      else if (listOfFiles[i].isDirectory()) 
		      {
		       // System.out.println("Directory " + listOfFiles[i].getName());
		      }
		    }
		    return ret;
	}
	
}
