package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.statements.detectors.text.DataType;
import com.rage.extraction.statements.detectors.text.DateDetector;
import com.rage.extraction.statements.detectors.text.NumberDetector;
import com.rage.extraction.statements.ontology.MetaData;



class CellsCreater 
{
	private static Boolean FINAL_DEBUG = Boolean.FALSE ;

	private static HashSet<String> COMMON_MULTI_WORDS = new HashSet<String>(Arrays.asList(new String[] {
			"BEGINNING BALANCE", "ENDING BALANCE","TOTAL CHECKS","TOTAL # OF CHECKS",
			"TOTAL DEPOSITS, CREDITS AND INTEREST","CHASE 0" 
	})) ;


	/*public static HashSet<String> REMOVE_CHUNKS = new HashSet<String>(Arrays.asList(new String[] {
			"HISTORY", "CREDITS","DEBITS"
	})) ;*/

	/*public static HashSet<String> SPECIAL_CHARS = new HashSet<String>(Arrays.asList(new String[] {
			"$", "-"
	})) ;*/

	private Row row ;
	private TreeMap<Integer, List<PDFLine>> levelLinesMap ;

	public CellsCreater(Row row, TreeMap<Integer, List<PDFLine>> levelLinesMap)
	{
		setRow(row) ;
		setLevelLinesMap(levelLinesMap) ;
	}
	static List<Cell> sortCells(List<Cell> cells)
	{
		Cell[] arr = cells.toArray(new Cell[cells.size()]) ;
		Arrays.sort(arr) ;
		return new ArrayList<Cell>(Arrays.asList(arr)) ;
	}
	public void run(MetaData eachTable)
	{
		PDFBlock block = getRow().getBlock() ;
		List<PDFLine> lines = block.getLines() ;

		TreeMap<Integer, List<PDFLine>> levelLinesMap = createLevelLinesMap(lines) ;
		// System.out.println("Level-Lines Map = " + levelLinesMap) ;

		HashMap<DataType, List<List<PDFWord>>> typeGramsMap = new HashMap<DataType, List<List<PDFWord>>>() ;
		HashMap<List<PDFWord>, List<DataType>> gramTypesMap = new HashMap<List<PDFWord>, List<DataType>>() ;
		HashMap<PDFWord, List<List<PDFWord>>> wordGramsMap = new HashMap<PDFWord, List<List<PDFWord>>>() ;

		createMaps(levelLinesMap, typeGramsMap, wordGramsMap, gramTypesMap,eachTable) ;
		// System.out.println("Done ... Maps Creation ...") ;

		List<List<PDFWord>> wordCells = new ArrayList<List<PDFWord>>() ;
		HashMap<List<PDFWord>, DataType> cellTypesMap = new HashMap<List<PDFWord>, DataType>() ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			List<PDFChunk> chunks = line.getChunks() ;
			//	List<PDFChunk> newChunks = createNewChunks(chunks) ;
			//	List<PDFChunk> finalChunks = createFinalChunks(chunks, newChunks, typeGramsMap, gramTypesMap, wordGramsMap) ;
			
			for ( int j=0 ; j<chunks.size() ; j++ )
			{
				PDFChunk chunk = chunks.get(j) ;
				List<PDFWord> chunkWords = chunk.getWords() ;
				
					List<List<PDFWord>> chunkCells = createChunkCells(gramTypesMap, wordGramsMap, cellTypesMap, chunkWords) ;
				wordCells.addAll(chunkCells) ;
			}
		}

		List<Cell> cells = new ArrayList<Cell>() ;
		HashMap<DataType, List<Cell>> datatypeCellsMap = new HashMap<DataType, List<Cell>>() ;

		for ( int i=0 ; i<wordCells.size() ; i++ )
		{
			List<PDFWord> words = wordCells.get(i) ;
			DataType type = cellTypesMap.containsKey(words) ? cellTypesMap.get(words) : DataType.TEXT ;

			Integer level = findLevel(words, levelLinesMap) ;
			Integer lineNo = findLineNo(words, getRow().getBlock().getLines()) ;
			String strValue = createString(words) ;

			if ( strValue.trim().equalsIgnoreCase("") )
				continue ;

			words = trimSpaces(words) ;

			Cell cell = new Cell(getRow(), words, level) ;
			cell.setIndex(i) ;
			cell.setDataType(type) ;
			cell.setLineNo(lineNo) ;
			cell.setStrValue(strValue) ;

			cells.add(cell) ;

			List<Cell> thisTypeCells = datatypeCellsMap.containsKey(type) ? datatypeCellsMap.get(type) : new ArrayList<Cell>() ;
			thisTypeCells.add(cell) ;
			datatypeCellsMap.put(type, thisTypeCells) ;
		}

		getRow().setCells(cells) ;
	//	getRow().setDatatypeCellsMap(datatypeCellsMap) ;

		if ( FINAL_DEBUG )
		{
			System.out.println("\n\nv3 Row " + getRow().getRowNo() + " : " + getRow().getBlock().getBlockString()) ;
			for ( int i=0 ; i<getRow().getCells().size() ; i++ )
			{
				Cell cell = cells.get(i) ;
				System.out.println("Cell " + i + ": " + cell.getDataType() + ":\t'" + cell.getStrValue() + "'") ;
			}
		}
	}

	/*private List<PDFChunk> createFinalChunks(List<PDFChunk> chunks, List<PDFChunk> newChunks, HashMap<DataType, List<List<PDFWord>>> typeGramsMap, HashMap<List<PDFWord>, List<DataType>> gramTypesMap, HashMap<PDFWord, List<List<PDFWord>>> wordGramsMap) 
	{
		List<PDFChunk> ret = new ArrayList<PDFChunk>() ;

		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			PDFChunk chunk = chunks.get(i) ;
			List<PDFWord> chunkWords = chunk.getWords() ;

			PDFChunk correspondingNewChunk = null ;
			for ( int j=0 ; j<newChunks.size() ; j++ )
			{
				PDFChunk newChunk = newChunks.get(j) ;
				List<PDFWord> newChunkWords = newChunk.getWords() ;

				for ( int k=0 ; k<newChunkWords.size() ; k++ )
				{
					PDFWord newChunkWord = newChunkWords.get(k) ;
					if ( chunkWords.contains(newChunkWord) )
					{
						correspondingNewChunk = newChunk ;
						break ;
					}
				}

				if ( correspondingNewChunk != null )
					break ;
			}

			if ( correspondingNewChunk != null  && chunk.getWords().size() == correspondingNewChunk.getWords().size() )
			{
				ret.add(chunk) ;
				continue ;
			}
		}

		for ( List<PDFWord> gram : gramTypesMap.keySet() )
		{
			List<PDFChunk> gramContainingChunks = new ArrayList<PDFChunk>() ;
			for ( int i=0 ; i<chunks.size() ; i++ )
			{
				PDFChunk chunk = chunks.get(i) ;
				List<PDFWord> words = chunk.getWords() ;
				for ( int j=0 ; j<words.size() ; j++ )
				{
					PDFWord word = words.get(j) ;
					if ( gram.contains(word) && !gramContainingChunks.contains(chunk) )
						gramContainingChunks.add(chunk) ;
				}
			}

			if ( gramContainingChunks.size() == 0 )
				continue ;

			if ( gramContainingChunks.size() == 1 )
			{
				ret.addAll(gramContainingChunks) ;
				continue ;
			}

			List<DataType> types = gramTypesMap.get(gram) ;
			if ( types.size() == 0 )
			{

			}
		}

		return ret ;
	}*/

	private List<PDFChunk> mergeChunksNegativeSign(List<PDFChunk> chunks,
			MetaData eachTable) {
		PDFChunk prevChunk = null;
		for ( int j=0 ; j<chunks.size() ; j++ )
		{
			PDFChunk chunk = chunks.get(j) ;

			if(chunk.toString().startsWith("-") || chunk.toString().endsWith("-"))
			{
				String chk = chunk.toString().replaceAll("\\-", "").trim();
				chunk.setChunk("-"+chk);
				chunks.set(j, chunk);
				List<PDFWord> words = chunk.getWords();
				
			}
		
			prevChunk = chunk;

		}
		return chunks;
	}

	private List<List<PDFWord>> createChunkCells(HashMap<List<PDFWord>, List<DataType>> gramTypesMap, HashMap<PDFWord, List<List<PDFWord>>> wordGramsMap,
			HashMap<List<PDFWord>, DataType> cellTypesMap, List<PDFWord> chunkWords)
			{
		List<List<PDFWord>> chunkCells = new ArrayList<List<PDFWord>>() ;

		List<PDFWord> thisCell = new ArrayList<PDFWord>() ;

		for ( int i=0 ; i<chunkWords.size() ; i++ )
		{
			PDFWord word = chunkWords.get(i) ;

			boolean alreadyDone = false ;
			for ( int j=0 ; j<chunkCells.size() ; j++ )
			{
				List<PDFWord> thisCellWords = chunkCells.get(j) ;
				if ( thisCellWords.contains(word) )
				{
					alreadyDone = true ;
					break ;
				}
			}

			// Check if this word is done ..
			if ( alreadyDone )
				continue ;

			// If there is no n-gram starting with this word
			if ( !wordGramsMap.containsKey(word) )
			{
				// Commented to handle very small columns
				/*if ( thisCell.size() != 0 )
				{
					wordCells.add(new ArrayList<PDFWord>(thisCell)) ;
					thisCell = new ArrayList<PDFWord>() ;
				}*/

				thisCell.add(word) ;

				// Commented to handle very small columns
				/*wordCells.add(new ArrayList<PDFWord>(thisCell)) ;
				thisCell = new ArrayList<PDFWord>() ;*/

				continue ;
			}

			// get all the n-grams that start with this word
			List<List<PDFWord>> grams = wordGramsMap.get(word) ;
			HashSet<DataType> distinctTypes = new HashSet<DataType>() ;
			List<PDFWord> smallestGram = null ;
			List<PDFWord> biggestGram = null ;
			for ( int j=0 ; j<grams.size() ; j++ )
			{
				List<PDFWord> gram = grams.get(j) ;

				List<DataType> types = gramTypesMap.containsKey(gram) ? gramTypesMap.get(gram) : new ArrayList<DataType>() ;
				distinctTypes.addAll(types) ;

				if ( smallestGram == null || smallestGram.size() > gram.size() )
					smallestGram = gram ;

				if ( biggestGram == null || biggestGram.size() < gram.size() )
					biggestGram = gram ;
			}

			// Only 1 distinct type, add the smallest gram
			if ( distinctTypes.size() == 1 )
			{
				if ( thisCell.size() != 0 )
				{
					chunkCells.add(new ArrayList<PDFWord>(thisCell)) ;
					thisCell = new ArrayList<PDFWord>() ;
				}

				thisCell.addAll(smallestGram) ;

				chunkCells.add(new ArrayList<PDFWord>(thisCell)) ;
				thisCell = new ArrayList<PDFWord>() ;

				DataType type = new ArrayList<DataType>(distinctTypes).get(0) ;
				cellTypesMap.put(smallestGram, type) ;

				continue ;
			}

			// if more than 1 types, then take the biggest n-gram
			List<DataType> types = gramTypesMap.containsKey(biggestGram) ? gramTypesMap.get(biggestGram) : new ArrayList<DataType>() ;

			// Unlikely condition
			if ( types.size() == 0 )
			{
				thisCell.add(word) ;
				continue ;
			}

			// wrap the old cell
			if ( thisCell.size() != 0 )
			{
				chunkCells.add(new ArrayList<PDFWord>(thisCell)) ;
				thisCell = new ArrayList<PDFWord>() ;
			}

			// Create a new cell with the biggest gram
			thisCell.addAll(biggestGram) ;

			chunkCells.add(new ArrayList<PDFWord>(thisCell)) ;
			thisCell = new ArrayList<PDFWord>() ;

			DataType type = types.get(0) ;
			cellTypesMap.put(biggestGram, type) ;

			continue ;
		}

		if ( thisCell.size() != 0 )
			chunkCells.add(new ArrayList<PDFWord>(thisCell)) ;

		return chunkCells ;
			}

	private List<PDFWord> trimSpaces(List<PDFWord> words)
	{
		List<PDFWord> ret = new ArrayList<PDFWord>() ;

		int first = -1 ;
		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			if ( word.getWord().trim().equalsIgnoreCase("") )
				continue ;

			first = i ;
			break ;
		}

		int last = -1 ;
		for ( int i=words.size()-1 ; i>=0 ; i-- )
		{
			PDFWord word = words.get(i) ;
			if ( word.getWord().trim().equalsIgnoreCase("") )
				continue ;

			last = i ;
			break ;
		}

		for ( int i=first ; i<=last ; i++ )
			ret.add(words.get(i)) ;

		return ret ;
	}

	private Integer findLineNo(List<PDFWord> words, List<PDFLine> lines) 
	{
		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			List<PDFWord> lineWords = createLineWords(line) ;

			for ( int j=0 ; j<words.size() ; j++ )
			{
				PDFWord word = words.get(j) ;

				if ( lineWords.contains(word) )
					return i ;
			}
		}

		return 0 ;
	}

	private Integer findLevel(List<PDFWord> words, TreeMap<Integer, List<PDFLine>> levelLinesMap) 
	{
		for ( Integer level : levelLinesMap.keySet() )
		{
			List<PDFLine> lines = levelLinesMap.get(level) ;
			for ( int i=0 ; i<lines.size() ; i++ )
			{
				PDFLine line = lines.get(i) ;
				List<PDFWord> lineWords = createLineWords(line) ;

				for ( int j=0 ; j<words.size() ; j++ )
				{
					PDFWord word = words.get(j) ;
					if ( lineWords.contains(word) )
						return level ;
				}
			}
		}

		return 1 ;
	}

	private List<PDFWord> createLineWords(PDFLine line)
	{
		List<PDFWord> ret = new ArrayList<PDFWord>() ;

		for ( int i=0 ; i<line.getChunks().size() ; i++ )
		{
			PDFChunk chunk = line.getChunks().get(i) ;
			List<PDFWord> words = chunk.getWords() ;
			ret.addAll(words) ;
		}

		return ret ;
	}

	private void createMaps(TreeMap<Integer, List<PDFLine>> levelLinesMap, HashMap<DataType, List<List<PDFWord>>> typeGramsMap,
			HashMap<PDFWord, List<List<PDFWord>>> wordGramsMap, HashMap<List<PDFWord>,List<DataType>> gramTypesMap, MetaData eachTable) 
	{
		for ( Integer level : levelLinesMap.keySet() )
		{
			List<PDFLine> thisLevelLines = levelLinesMap.get(level) ;

			List<List<PDFWord>> nGrams = new ArrayList<List<PDFWord>>() ;

			for ( int i=0 ; i<thisLevelLines.size() ; i++ )
			{
				PDFLine line = thisLevelLines.get(i) ;
				// System.out.println("Line: " + line.getLine()) ;
				List<PDFChunk> chunks = line.getChunks() ;
				//List<PDFChunk> newChunks = createNewChunks(chunks) ;
				//chunks = mergeChunksNegativeSign(chunks,eachTable);
				/*if(eachTable.getSpecialHandling().trim().equalsIgnoreCase("special_4"))
				{
					chunks = createNewChunks(chunks);
				}*/
				for ( int j=0 ; j<chunks.size() ; j++ )
				{
					PDFChunk chunk = chunks.get(j) ;

					List<PDFWord> words = chunk.getWords() ;
					for ( int nGramSize=4 ; nGramSize>=0 ; nGramSize-- )
					{
						List<List<PDFWord>> thisNGrams = CellsCreater.createSingleLineNGrams(nGramSize, words) ;
						// System.out.println("\tThis N-Grams = " + thisNGrams) ;
						nGrams.addAll(thisNGrams) ;
					}
				}
			}

			// System.out.println("N-Grams: " + nGrams) ;

			for ( int i=0 ; i<nGrams.size() ; i++ )
			{
				List<PDFWord> nGram = nGrams.get(i) ;
				String str = createString(nGram) ;

				if ( str.trim().equalsIgnoreCase("") )
					continue ;

				// System.out.println("\nStr: " + str) ;

				boolean contains = false ;
				for ( List<PDFWord> gram : gramTypesMap.keySet() )
				{
					for ( PDFWord word : nGram )
					{
						if ( gram.contains(word) )
						{
							contains = true ;
							break ;
						}
					}

					if ( contains )
						break ;
				}

				if ( contains )
				{
					// System.out.println("\tN-gram Already Covered : " + nGram) ;
					continue ;
				}

				List<DataType> types = findDataType(str) ;
				// System.out.println("\tTypes = " + types) ;

				for ( int j=0 ; j<types.size() ; j++ )
				{
					DataType type = types.get(j) ;

					List<List<PDFWord>> thisTypeGrams = typeGramsMap.containsKey(type) ? typeGramsMap.get(type) : new ArrayList<List<PDFWord>>() ;
					thisTypeGrams.add(nGram) ;
					typeGramsMap.put(type, thisTypeGrams) ;
				}

				if ( types.size() != 0 )
				{
					PDFWord firstWord = nGram.get(0) ;

					List<List<PDFWord>> thisWordGrams = wordGramsMap.containsKey(firstWord) ? wordGramsMap.get(firstWord) : new ArrayList<List<PDFWord>>() ;
					thisWordGrams.add(nGram) ;
					wordGramsMap.put(firstWord, thisWordGrams) ;

					List<DataType> thisGramTypes = gramTypesMap.containsKey(nGram) ? gramTypesMap.get(nGram) : new ArrayList<DataType>() ;
					thisGramTypes.addAll(types) ;
					gramTypesMap.put(nGram, thisGramTypes) ;
				}
				else
				{
					boolean containsCommonMultiWords = false ;
					for ( String keyword : COMMON_MULTI_WORDS )
					{
						if ( keyword.equalsIgnoreCase(str) )
						{
							containsCommonMultiWords = true ;
							break ;
						}
					}

					if ( containsCommonMultiWords )
					{
						PDFWord firstWord = nGram.get(0) ;

						List<List<PDFWord>> thisWordGrams = wordGramsMap.containsKey(firstWord) ? wordGramsMap.get(firstWord) : new ArrayList<List<PDFWord>>() ;
						thisWordGrams.add(nGram) ;
						wordGramsMap.put(firstWord, thisWordGrams) ;

						List<DataType> thisGramTypes = gramTypesMap.containsKey(nGram) ? gramTypesMap.get(nGram) : new ArrayList<DataType>() ;
						thisGramTypes.add(DataType.TEXT) ;
						gramTypesMap.put(nGram, thisGramTypes) ;
					}					
				}
			}
		}
	}

	
	public static List<List<PDFWord>> createSingleLineNGrams(int nGramSize, List<PDFWord> line)
	{
		List<List<PDFWord>> ret = new ArrayList<List<PDFWord>>() ;

		for ( int i=0 ; i<line.size() ; i++ )
		{
			List<PDFWord> thisNGram = new ArrayList<PDFWord>() ;
			for ( int j=i ; j<line.size() ; j++ )
			{
				PDFWord word = line.get(j) ;
				if ( word.getWord().trim().equalsIgnoreCase("") )
					continue ;

				thisNGram.add(word) ;

				if ( thisNGram.size() == nGramSize )
					break ;
			}

			if ( thisNGram.size() != nGramSize )
				continue ;

			ret.add(thisNGram) ;
		}

		return ret ;
	}
	private List<PDFChunk> createNewChunks(List<PDFChunk> chunks) 
	{
		List<List<PDFWord>> newChunkWords = new ArrayList<List<PDFWord>>() ;

		List<PDFWord> thisChunkWords = new ArrayList<PDFWord>() ;
		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			PDFChunk chunk = chunks.get(i) ;
			// System.out.println("\nThis Chunk = " + chunk) ;
			List<PDFWord> words = chunk.getWords() ;
			// System.out.println("\tChunk Words = " + words) ;

			if ( words.size() > 1 )
			{
				if ( thisChunkWords.size() != 0 )
				{
					newChunkWords.add(new ArrayList<PDFWord>(thisChunkWords)) ;
					// System.out.println("\t\tWrapping Old Words : " + thisChunkWords) ;
				}

				thisChunkWords = new ArrayList<PDFWord>() ;

				newChunkWords.add(chunk.getWords()) ;
				// System.out.println("\t\tAdding a new Chunk : " + chunk.getChunk()) ;

				continue ;
			}

			// System.out.println("\t\tAdding a new word: " + words.get(0) + " : TO : " + thisChunkWords) ;
			thisChunkWords.add(words.get(0)) ;
		}

		if ( thisChunkWords.size() != 0 )
			newChunkWords.add(new ArrayList<PDFWord>(thisChunkWords)) ;

		List<PDFChunk> ret = new ArrayList<PDFChunk>() ;
		for ( int i=0 ; i<newChunkWords.size() ; i++ )
		{
			List<PDFWord> newWords = newChunkWords.get(i) ;
			for ( int i1=0 ; i1<newWords.size() ; i1++ )
			{
				List<PDFWord> nWords = new ArrayList<PDFWord>();
				if(newWords.get(i1).getWord().trim().equals(""))
					continue;
				nWords.add(newWords.get(i1));
		    	PDFChunk newChunk = new PDFChunk(chunks.get(0).getPageNo(),nWords) ;
		    	newChunk.setX1(newWords.get(i1).getX1());
		    	newChunk.setY1(newWords.get(i1).getY1());
		    	newChunk.setX2(newWords.get(i1).getX2());
		    	newChunk.setY2(newWords.get(i1).getY2());

				ret.add(newChunk) ;
				

			}
		}

		 System.out.println("New Chunks : " + ret) ;

		return ret ;
	}

	private List<DataType> findDataType(String str) 
	{
		List<DataType> ret = new ArrayList<DataType>() ;

		if ( DateDetector.isDate(str) )
			ret.add(DataType.DATE) ;

		if ( NumberDetector.isNumericValue(str) )
			ret.add(DataType.NUMBER) ;


		return ret ;
	}

	private String createString(List<PDFWord> words) 
	{
		String ret = "" ;

		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			ret = ret.trim() + " " + word.getWord() ;
		}

		return ret.trim() ;
	}

	private TreeMap<Integer, List<PDFLine>> createLevelLinesMap(List<PDFLine> lines) 
	{
		TreeMap<Integer, List<PDFLine>> ret = new TreeMap<Integer, List<PDFLine>>() ;

		for ( Integer level : getLevelLinesMap().keySet() )
		{
			List<PDFLine> thisLevelLines = getLevelLinesMap().get(level) ;
			List<PDFLine> retLines = new ArrayList<PDFLine>() ;

			for ( int i=0 ; i<thisLevelLines.size() ; i++ )
			{
				PDFLine line = thisLevelLines.get(i) ;
				if ( !lines.contains(line) )
					continue ;

				retLines.add(line) ;
			}

			ret.put(level, retLines) ;
		}

		return ret ;
	}

	public Row getRow() {
		return row;
	}

	public void setRow(Row row) {
		this.row = row;
	}

	public TreeMap<Integer, List<PDFLine>> getLevelLinesMap() {
		return levelLinesMap;
	}

	public void setLevelLinesMap(TreeMap<Integer, List<PDFLine>> levelLinesMap) {
		this.levelLinesMap = levelLinesMap;
	}

	
}
