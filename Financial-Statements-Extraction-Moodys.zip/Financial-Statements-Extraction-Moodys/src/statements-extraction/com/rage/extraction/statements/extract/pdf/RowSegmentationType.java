package com.rage.extraction.statements.extract.pdf;

public enum RowSegmentationType 
{
	ONE_LINE_ONE_ROW,
	ONE_PARA_ONE_ROW,
	PATTERN_BASED_ROWS,
	GROUP_BASED_ROWS,
	SPECIAL
}
