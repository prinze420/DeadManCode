package com.rage.extraction.statements.ontology;

import java.util.List;

import com.rage.extraction.statements.extract.pdf.RowSegmentationType;



public class MetaData implements Comparable<MetaData>{
	private String section;
	private List<String> keywords;
	private String rowSegmentationRule ;
	private RowSegmentationType rowSegmentationType ;
	private Integer columnNo;
	private String scope;
	private String subSection;
	private String keyword;
	private String parseValue;



	public MetaData(String section, List<String> keywords,RowSegmentationType rowSegmentationType, String noColumnsToSplitFrom,String scope,String subSection,String keyword,String parseValue) {
		super();
		this.section = section;
		this.keywords = keywords;
		this.rowSegmentationType = rowSegmentationType;
		this.setColumnNo(new Integer(noColumnsToSplitFrom));
		this.scope=scope;
		this.subSection=subSection;
		this.keyword=keyword;
		this.parseValue=parseValue;
	}


	public String getParseValue() {
		return parseValue;
	}


	public void setParseValue(String parseValue) {
		this.parseValue = parseValue;
	}


	public String getKeyword() {
		return keyword;
	}


	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}


	public String getScope() {
		return scope;
	}


	public void setScope(String scope) {
		this.scope = scope;
	}


	public String getSubSection() {
		return subSection;
	}


	public void setSubSection(String subSection) {
		this.subSection = subSection;
	}


	public RowSegmentationType getRowSegmentationType() {
		return rowSegmentationType;
	}


	public void setRowSegmentationType(RowSegmentationType rowSegmentationType) {
		this.rowSegmentationType = rowSegmentationType;
	}


	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}

	public List<String> getKeywords() {
		return keywords;
	}

	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

	@Override
	public int compareTo(MetaData o) {

		if(o.getSection().equals(this.getSection()))
		{

			if(o.getKeywords().size()<this.getKeywords().size())
				return 1;

		}
		return 0;
	}


	public String getRowSegmentationRule() {
		return rowSegmentationRule;
	}


	public void setRowSegmentationRule(String rowSegmentationRule) {
		this.rowSegmentationRule = rowSegmentationRule;
	}


	public Integer getColumnNo() {
		return columnNo;
	}


	public void setColumnNo(Integer columnNo) {
		this.columnNo = columnNo;
	}

}
