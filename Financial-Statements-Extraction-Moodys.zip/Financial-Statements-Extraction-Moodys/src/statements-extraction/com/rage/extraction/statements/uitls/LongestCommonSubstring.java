package com.rage.extraction.statements.uitls;


public class LongestCommonSubstring
{

	char[] firstString;
	char[] secondString;

	int[][] matrix;

	public LongestCommonSubstring(String first,String second)
	{
		firstString = first.toCharArray();
		secondString = second.toCharArray();

		matrix = new int[first.length()+1][second.length()+1];
		for(int i=0; i<=first.length(); i++)
			for(int j=0; j<=second.length(); j++)
				matrix[i][j] = -1;
	}
	

	private int lcs(int firstIdx, int secondIndex)
	{
		if(matrix[firstIdx][secondIndex] < 0)
		{

			if(firstIdx >= firstString.length || secondIndex >= secondString.length  )
				matrix[firstIdx][secondIndex] =  0;

			else if(firstString[firstIdx] == secondString[secondIndex])
				matrix[firstIdx][secondIndex] = 1 + lcs(firstIdx+1, secondIndex+1);

			else
				matrix[firstIdx][secondIndex] = Math.max(lcs(firstIdx +1, secondIndex), lcs(firstIdx, secondIndex+1));
		}
		return matrix[firstIdx][secondIndex];

	}

	public int findMaxStringMatch()
	{
		return lcs(0, 0);
	}

	public static void main(String[] args)
	{

//		System.out.println(new LongestCommonSubstring("1A/aveland 2006A	Oil exploration", "Capital Preservation Fund").findMaxStringMatch());

		System.out.println(new LongestCommonSubstring("Accounts Payable (Trade0", "AccoUrrt5 Pa hie (Trade").findMaxStringMatch());
	}


}
