package com.rage.extraction.statements.serialize;

import java.io.IOException;

/**
 * @author kiran.umadi
 *
 */
public interface Serializer {
	public Object deSerialize() throws IOException, ClassNotFoundException;
	public Object deSerialize(String fileName) throws IOException, ClassNotFoundException;
	public void serialize(Object object) throws IOException;
	public void serialize(String fileName, Object object) throws IOException;
}
