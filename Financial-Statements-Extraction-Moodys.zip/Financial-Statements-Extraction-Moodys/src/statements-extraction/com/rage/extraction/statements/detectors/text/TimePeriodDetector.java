package com.rage.extraction.statements.detectors.text;

import java.util.List;

import com.rage.extraction.statements.extract.pdf.SectionSpreader;
import com.rage.extraction.statements.ontology.TimePeriodOntology;

class TimePeriodDetector 
{
	private static String REGEX_MONTH_LONG = "january|february|march|april|may|june|july|august|september|october|november|december" ;
	private static String REGEX_MONTH_SHORT = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec" ;
	private static String REGEX_MONTH = "(" + REGEX_MONTH_LONG + ")|(" + REGEX_MONTH_SHORT + ")" ;

	private static String REGEX_YEAR = "19[0-9]{2}|2[0-9]{3}" ;

	private static String REGEX_DATE_NUMBER = "2[0-9]|3[0-1]|[1-9]{1}|0[1-9]|1[0-9]" ;
	private static String REGEX_MONTH_NUMBER = "[0-9]{1,2}" ;


	private static String REGEX_DATE_1 = "(" + REGEX_MONTH + ")\\s+(" + REGEX_DATE_NUMBER + ")\\s*,*(" + REGEX_YEAR + ")" ;
	private static String REGEX_DATE_2 = "(" + REGEX_MONTH + ")" ;
	private static String REGEX_DATE_3 = "(" + REGEX_DATE_NUMBER + ")(\\s)*,("+ REGEX_YEAR + ")" ;
	//public static String REGEX_DATE_4 = "(" + REGEX_DATE_NUMBER + ")(\\s)("+ REGEX_YEAR + ")" ;
	//public static String REGEX_DATE_3 = "(" + REGEX_DATE_NUMBER + ")(\\s)*(,)*("+ REGEX_YEAR + ")" ;
	private static String REGEX_DATE_4 = "(" + REGEX_MONTH_NUMBER + ")-(" +REGEX_DATE_NUMBER+")-("+"19[0-9]{2}|2[0-9]{3}|[0-9]{2}" + ")" ;
	private static String REGEX_DATE_5 = "(" + REGEX_MONTH + ")-("+"19[0-9]{2}|2[0-9]{3}|[0-9]{2}" + ")" ;
	private static String REGEX_DATE_6 = "("+" 19[0-9]{2}|2[0-9]{3}|20[0-9]{2}"+ ")" ;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(TimePeriodDetector.class);

	public static boolean containsTimePeriod(String input)
	{

		Boolean foundAll = true;
		input=input.replaceAll("�", "");
		input=input.replaceAll("�", " ");
		for ( List<String> keywords : TimePeriodOntology.getKeywords() )
		{
			// System.out.println("\t\tChecking TP Keyword: " + keyword) ;
			foundAll = true;
			for ( String keyword : keywords )
			{
				if ( !input.toLowerCase().contains(keyword.toLowerCase()) )
				{
					foundAll=false;
					break;
				}
				//System.out.println("Match timeperiod");
			}
			if(foundAll)
				return true;
		}

		int initSize = input.trim().length() ;

		for(String regex : TimePeriodOntology.getRegexes())
		{
			String temp = input.toLowerCase().replaceAll(regex.trim().toLowerCase(), "").trim();

			if ( temp.length() != initSize )
			{
				logger.info("Regex: " + regex+" in "+input) ;
				return true ;
			}
		}


		/*	String one = input.toLowerCase().replaceAll(REGEX_DATE_1, "").trim() ;
		// System.out.println("Regex: " + REGEX_DATE_1) ;
		int size1 = one.length() ;

		if ( size1 != initSize )
		{
			 System.out.println("Regex: " + REGEX_DATE_1+" in "+input) ;
			return true ;
		}

		String two = input.toLowerCase().replaceAll(REGEX_DATE_2, "").trim() ;
		int size2 = two.length() ;

		if ( size2 != initSize )
		{
			 System.out.println("Regex: " + REGEX_DATE_2+" in "+input) ;
			 return true ;
		}


		String three = input.toLowerCase().replaceAll(REGEX_DATE_3, "").trim() ;
		int size3 = three.length() ;

		if ( size3 != initSize )
		{
			 System.out.println("Regex: " + REGEX_DATE_3+" in "+input) ;
			 return true ;
		}


		String four = input.toLowerCase().replaceAll(REGEX_DATE_4, "").trim() ;
		int size4 = four.length() ;

		if ( size4 == 0 )
		{
			 System.out.println("Regex: " + REGEX_DATE_4+" in "+input) ;
			 return true ;
		}


		String five = input.toLowerCase().replaceAll(REGEX_DATE_5, "").trim() ;
		int size5 = five.length() ;

		if ( size5 == 0 )
		{
			 System.out.println("Regex: " + REGEX_DATE_5+" in "+input) ;
			 return true ;
		}

		String six = input.toLowerCase().replaceAll(REGEX_DATE_6, "").trim() ;
		int size6 = six.length() ;

		if ( size6 != initSize )
		{
			 System.out.println("Regex: " + REGEX_DATE_6+" in "+input) ;
			 return true ;
		}*/


		return false ;
	}
	
	

	public static void main(String[] args) 
	{
		String input = "2012   2013" ;
		//System.out.println(containsTimePeriod(input)) ;

		//System.out.println(TimePeriodOntology.getKeywords()) ;
	}
}
