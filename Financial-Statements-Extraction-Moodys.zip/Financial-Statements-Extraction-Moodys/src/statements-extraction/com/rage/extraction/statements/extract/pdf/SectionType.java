package com.rage.extraction.statements.extract.pdf;

public class SectionType {
	
	private Integer filingId;
	private Integer tableID;
	private Integer colNo;
	private String type;
	private String section;
	public Integer getFilingId() {
		return filingId;
	}
	public void setFilingId(Integer filingId) {
		this.filingId = filingId;
	}
	public Integer getTableID() {
		return tableID;
	}
	public void setTableID(Integer tableID) {
		this.tableID = tableID;
	}
	public Integer getColNo() {
		return colNo;
	}
	public void setColNo(Integer colNo) {
		this.colNo = colNo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
		

}
