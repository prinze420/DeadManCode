package com.rage.extraction.statements.similarity;

/**
 * @author kiran.umadi
 *
 */
interface Similarity {
	public float jaccardSimilarity(String arg1, String arg2);
	public boolean match(String text1, String text2);
}
