package com.rage.extraction.statements.uitls;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

import org.apache.commons.logging.LogFactory;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import com.gargoylesoftware.htmlunit.BrowserVersion;
import com.gargoylesoftware.htmlunit.WebClient;
import com.gargoylesoftware.htmlunit.html.HtmlPage;
import com.gargoylesoftware.htmlunit.html.HtmlTextArea;

public class BingTranslate 
{
	public static List<String> translateBingBulk(WebClient browser, List<String> inputs) throws Exception
	{
		List<String> ret = new ArrayList<String>() ;
		
		List<List<String>> groups = new ArrayList<List<String>>() ;
		List<String> thisGroup = new ArrayList<String>() ;
		String thisString = "" ;
		for ( int i=0 ; i<inputs.size() ; i++ )
		{
			String input = inputs.get(i) ;
			
			if ( (thisString.length() + 1 + input.length() + 1) >= 4500 )
			{
				groups.add(new ArrayList<String>(thisGroup)) ;
				thisGroup.clear() ;
				thisGroup.add(input) ;
				thisString = new String(input) ;
				
				continue ;
			}
			
			thisString = thisString.trim() + "\n" + input ;
			thisGroup.add(input) ;
		}
		
		if ( thisGroup.size() != 0 )
			groups.add(new ArrayList<String>(thisGroup)) ;
		
		for ( int i=0 ; i<groups.size() ; i++ )
		{
			List<String> thisInputs = groups.get(i) ;
			List<String> thisOutputs = translateBingClicks(browser, thisInputs) ;
			if ( thisOutputs == null )
				return null ;
			
			ret.addAll(thisOutputs) ;
		}
		
		return ret ;
	}
	
	public static List<String> translateBingClicks(WebClient browser, List<String> inputs) throws Exception
	{
		System.out.println("\n\n\nStarting translation for this batch ... ") ;
		
		String mainUrl = "https://www.bing.com/translator" ;
		HtmlPage page = browser.getPage(mainUrl) ;
		System.out.println("Found main page ... ") ;
		
		String input = "" ;
		for ( String str : inputs )
			input = input.trim() + "\n" + str ;
		input = input.trim() ;
		
		((HtmlTextArea)page.getElementById("srcText")).setText(input) ;

		System.out.println("Clicking ... ") ;
		page.getElementById("TranslateButton").click() ;
		System.out.println("Done ... ") ;

		// System.out.println("Prev-Text: '" + page2.getElementById("destText").asText() + "'") ;
		// System.out.println("Prev-Text: '" + page.getElementById("destText").asText() + "'") ;
		
		/*int tries = 10 ;
		while ( tries > 0 && page2.getElementById("destText").asText().length() == 0 )
		{
			tries -- ;
			synchronized (page2) {
				System.out.println("Waiting for 1 second ... ") ;
				page2.wait(1000) ;
			}
		}*/

		int wait = 0;
		int nbProcess = 1;
		while (nbProcess > 0 && wait < 30) {
			nbProcess = browser.waitForBackgroundJavaScript(1000) ;
			if (wait == 9) {
				System.err.println("** needs more time ** ");
			}
			wait++;
		}
		
		// System.out.println("Response: " + page2.getWebResponse().getContentAsString()) ;
		System.out.println("Response: " + page.getElementById("destText").asXml()) ;
		
		String html = page.getElementById("destText").asXml() ;
		
		List<String> output = parse(html) ;
		if ( output.size() == 0 )
			return null ;
		
		return output ;
	}
	
	public static List<String> parse(String html)
	{
		List<String> ret = new ArrayList<String>() ;
		
		// System.out.println("Parsing ... ") ;
		
		if ( html == null )
			return new ArrayList<String>() ;
		
		Document doc = Jsoup.parse(html) ;
		Element body = doc.body() ;
		Element mainElement = body.childNodes().size() == 0 ? null : body.child(0) ;
		
		if ( mainElement == null )
			return new ArrayList<String>() ;
		
		for ( Element child : mainElement.children() )
		{
			// System.out.println("Child: " + child.text()) ;
			ret.add(child.text()) ;
		}
		
		/*String[] split = html.split("<div paragraphname=\"paragraph") ;
		for ( int i=1 ; i<split.length ; i++ )
		{
			System.out.println(split[i]) ;
			String str = split[i] ;
			str = str.replaceAll("<[^>]*>", "").replaceAll("&nbsp;", "").replaceAll("\n", " ").trim() ;
			System.out.println(str) ;
		}*/
		
		return ret ;
	}

	public static void main(String[] args) throws Exception
	{
		// German
		/*List<String> inputs = new ArrayList<String>() ;
		inputs.add("Aktiva in T€") ;
		inputs.add("1. Barreserve") ;
		inputs.add("a) Kassenbestand") ;*/
		
		// Chinese
		List<String> inputs = new ArrayList<String>() ;
		inputs.add("资产") ;
		inputs.add("现金及存放中央银行款项") ;
		inputs.add("存放同业款项") ;
		inputs.add("拆出资金") ;
		inputs.add("贵金属") ;
		inputs.add("以公允价值计量且其变动计") ;
		inputs.add("入当期损益的金融资产") ;
		
		LogFactory.getFactory().setAttribute("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.NoOpLog");
		java.util.logging.Logger.getLogger("com.gargoylesoftware.htmlunit").setLevel(Level.OFF);
		java.util.logging.Logger.getLogger("org.apache.commons.httpclient").setLevel(Level.OFF);

		WebClient browser = new WebClient(BrowserVersion.CHROME, "172.20.1.20", 2020) ;
		// WebClient browser = new WebClient(BrowserVersion.FIREFOX_45) ;
		
		browser.getOptions().setJavaScriptEnabled(true) ;
		browser.getOptions().setThrowExceptionOnScriptError(false) ;
		// browser.waitForBackgroundJavaScript(10000) ;

		List<String> translations = translateBingClicks(browser, inputs) ;
		for ( int i=0 ; i<inputs.size() ; i++ )
			System.out.println(inputs.get(i) + " ==== " + translations.get(i)) ;
		
		browser.close() ;
	}
}
