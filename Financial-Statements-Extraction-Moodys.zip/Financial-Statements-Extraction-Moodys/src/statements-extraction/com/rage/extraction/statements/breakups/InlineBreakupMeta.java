package com.rage.extraction.statements.breakups;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;



class InlineBreakupMeta {
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(InlineBreakupMeta.class);

	private static List<String> read(String fileName) {
		try
		{
			new SafeFile(fileName);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(fileName);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		
		if (logger!=null)
			logger.debug("Reading in-line breakups meta file "+fileName);

		List<String> inlineBreakups = new ArrayList<String>();
		BufferedReader bufferedReader = null;
		try {
			//bufferedReader = new BufferedReader(new FileReader(new File(fileName)));
			bufferedReader = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));
			String line = "";

			if (logger!=null)
				logger.debug("In-line breakups to be extracted for items ...");
			
			while ((line = bufferedReader.readLine())!=null)  {
				inlineBreakups.add(line.trim().toLowerCase());
				if (logger!=null)
					logger.debug("Item : " + line.trim());
			}
		} catch (Exception e) {
		} finally {
			try {
				if (bufferedReader!=null)
					bufferedReader.close();
			} catch (Exception e) {
			}
		}
		return inlineBreakups;
	}

	static List<String> getInlineBreakups() {
		String fileName = "";
	if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
		 fileName = "resource/breakups/InlineBreakups.txt";
	else
		fileName = "resource/breakups/"+FinancialStatementExtractor.getLanguage().trim()+"/InlineBreakups.txt";
		
		return read(fileName);
	}

}
