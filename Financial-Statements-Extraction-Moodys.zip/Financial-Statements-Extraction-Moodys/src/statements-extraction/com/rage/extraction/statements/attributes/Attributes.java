package com.rage.extraction.statements.attributes;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import com.rage.extraction.statements.db.ParserOutput;

/**
 * @author kiran.umadi
 *
 */
public interface Attributes {
	public ArrayList<ParserOutput> getStatementAttributes(List<ParserOutput> list, String section, int valueColumnCount,int PageNo, TreeSet<Integer> columns, String statementQuality);
	public ArrayList<ParserOutput> getStatementColumnAttributes(List<ParserOutput> list, List<ParserOutput> poObjects, String section, int valueColumnCount,int PageNo,TreeSet<Integer> columns, String statementQuality);
}

