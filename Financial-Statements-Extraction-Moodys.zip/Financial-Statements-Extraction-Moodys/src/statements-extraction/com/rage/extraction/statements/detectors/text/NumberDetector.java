package com.rage.extraction.statements.detectors.text;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NumberDetector 
{
/*	private static String REGEX_NUMBER = "\\(*\\-*[0-9,\\.]+(\\)*)" ;
*/	//private static String REGEX_NUMERIC_VALUE = "\\-*\\(*(\\d{1,3}\\,)*\\d{1,3}(\\.\\d{1,9})*\\)*\\-*" ;
/*	private static String REGEX_WHOLE_NUMBER = "[-]*([0-9]{1,3}[,])*([0-9]{1,3})[-]*" ;
*/	private static String REGEX_PERCENTAGE = "([0-9]{0,2}[.][0-9]+[%])|(VAR RT)|(PFD)" ;
	private static String REGEX_NUMERIC_VALUE = "\\-*\\(*(\\d{1,3}(\\,|\\s|\\.))*\\d{0,3}((\\,|\\s|\\.)\\d{1,9})*\\)*\\-*" ;

	
	private static LinkedHashSet<String> CURRENCY_KEYWORDS = new LinkedHashSet<String>(Arrays.asList(new String[] {
			"USD", "$","HK","cents","cent"
	})) ;
	public static LinkedHashSet<String> getCURRENCY_KEYWORDS() {
		return CURRENCY_KEYWORDS;
	}

	public static void setCURRENCY_KEYWORDS(LinkedHashSet<String> cURRENCY_KEYWORDS) {
		CURRENCY_KEYWORDS = cURRENCY_KEYWORDS;
	}

	private static String REGEX_CURRENCY = ""
			+ "RUB|AFN|EUR|ALL|GBP|GGP|DZD|EUR|AOA|XCD|XCD|ARS|AMD|AWG|SHP|AUD|EUR|AZN|BSD|BHD|BDT|BBD|BYR|EUR|BZD|XOF|BMD|BTN|INR|"
			+ "BOB|USD|BAM|BWP|BRL|USD|USD|BND|SGD|BGN|XOF|MMK|BIF|KHR|USD|XAF|CAD|CVE|KYD|XAF|XAF|CLP|CNY|AUD|COP|KMF|CDF|XAF|NZD|"
			+ "CRC|XOF|HRK|CUC|CUP|ANG|EUR|CZK|DKK|DJF|XCD|DOP|USD|USD|EGP|USD|XAF|ERN|EUR|ETB|FKP|DKK|FJD|EUR|EUR|XPF|XAF|GMD|GEL|"
			+ "EUR|GHS|GIP|EUR|XCD|GTQ|GBP|GNF|XOF|GYD|HTG|HNL|HKD|HUF|ISK|INR|IDR|IRR|IQD|EUR|GBP|IMP|ILS|EUR|JMD|JPY|GBP|JEP|JOD|"
			+ "KZT|KES|AUD|KPW|KRW|EUR|KWD|KGS|LAK|EUR|LBP|LSL|ZAR|LRD|LYD|CHF|LTL|EUR|MOP|MKD|MGA|MWK|MYR|MVR|XOF|EUR|USD|MRO|MUR|"
			+ "MXN|USD|MDL|EUR|MNT|EUR|XCD|MAD|MZN|AMD|NAD|ZAR|AUD|NPR|EUR|XPF|NZD|NIO|XOF|NGN|NZD|TRY|NOK|OMR|PKR|USD|ILS|JOD|PAB|"
			+ "USD|PGK|PYG|PEN|PHP|NZD|PLN|EUR|QAR|RON|RUB|RWF|USD|DZD|MRO|MAD|SHP|XCD|XCD|XCD|WST|EUR|STD|SAR|XOF|RSD|SCR|SLL|BND|"
			+ "SGD|USD|ANG|EUR|EUR|SBD|SOS|ZAR|GBP|RUB|EUR|SSP|LKR|SDG|SRD|SZL|SEK|CHF|SYP|TWD|TJS|TZS|THB|XOF|TOP|PRB|TTD|SHP|TND|"
			+ "TRY|TMT|USD|AUD|UGX|UAH|AED|GBP|USD|UYU|UZS|VUV|EUR|VEF|VND|XPF|YER|ZMW|BWP|GBP|EUR|ZAR|USD|\\$" ;


	public static boolean isNumericValue(String input)
	{
		if ( input.trim().equalsIgnoreCase("") )
			return false ;
		
		for(String keyword : CURRENCY_KEYWORDS)
		{
			if(input.contains(keyword))
			{
				input = input.replace(keyword, "");
			}
		}
		if(input.trim().startsWith("(") && input.trim().endsWith(")") )
			input = input.trim().substring(1,input.trim().length()-1);
		if(input.trim().equals("000") || input.equalsIgnoreCase(""))
			return false;
		
		Pattern pattern1 = Pattern.compile("00\\d");
		Matcher matcher1 = pattern1.matcher(input);
		if(matcher1.matches()){
			return false;
		} 
		
		String str = REGEX_NUMERIC_VALUE ;
		
		Pattern regex = Pattern.compile(str) ;
		Matcher matcher = regex.matcher(input.trim()) ;
		if ( matcher.find() )
		{
			int start = matcher.start() ;
			int end = matcher.end() ;
			
			if ( start != 0 || end != input.trim().length() )
				return false ;
			else 
				return true ;
		}
		
		return false ;
	}
	
	public static boolean isRange(String input)
	{
		if ( input==null || input.trim().equalsIgnoreCase("") )
			return false ;
		
		Pattern p=Pattern.compile("\\d+(\\s+)?\\-(\\s+)?\\d+");
		Matcher m =p.matcher(input.trim());
		
		if(m.matches())
		{
			return true;
		}

		p=Pattern.compile("\\d+(\\s+)?to(\\s+)?\\d+");
		m =p.matcher(input.trim());
		
		if(m.matches())
		{
			return true;
		}
		
		return false ;
	}
	
	public static boolean isCurrency(String input)
	{
		if ( input.trim().equalsIgnoreCase("") || input.trim().toLowerCase().equals(input.trim()) || input.trim().length() != 3 )
			return false ;

		if ( input.toUpperCase().replaceAll(REGEX_CURRENCY, "").trim().equalsIgnoreCase("") )
			return true ;

		return false ;
	}

	
	static boolean isPercentage(String input)
	{
		if ( input.replaceAll(REGEX_PERCENTAGE, "").trim().equalsIgnoreCase("") )
			return true ;

		return false ;
	}
	
	/*private static boolean matchesRegex(String input, String regex)
	{
		if ( input.trim().equalsIgnoreCase("") )
			return false ;
		
		Pattern r = Pattern.compile(regex) ;
		Matcher matcher = r.matcher(input.trim()) ;
		if ( matcher.find() )
		{
			int start = matcher.start() ;
			int end = matcher.end() ;
			
			if ( start != 0 || end != input.trim().length() )
				return false ;
			else 
				return true ;
		}
		
		return false ;
	}*/
	
	/*private static DataType getDataType(String input)
	{
		if ( input.trim().equalsIgnoreCase("") )
			return DataType.TEXT ;
		
		if ( matchesRegex(input.trim(), REGEX_NUMERIC_VALUE) )
			return DataType.NUMERIC_VALUE ;
		
		if ( matchesRegex(input.trim(), REGEX_WHOLE_NUMBER) )
			return DataType.WHOLE_NUMBER ;
		
		if ( matchesRegex(input.trim(), REGEX_NUMBER) )
			return DataType.NUMBER ;
			
		if ( matchesRegex(input.trim(), REGEX_PERCENTAGE) )
			return DataType.PERCENTAGE ;
			
		if ( matchesRegex(input.trim(), REGEX_CURRENCY) )
			return DataType.CURRENCY ;
		
		
		return DataType.TEXT ;
	}*/
	
// TODO Remove unused code found by UCDetector
// 	public static boolean containsNumber(String input)
// 	{
// 		String[] split = input.trim().split(" ") ;
// 		for ( int i=0 ; i<split.length ; i++ )
// 		{
// 			String token = split[i] ;
// 			if ( token.equalsIgnoreCase("") )
// 				continue ;
// 			
// 			DataType type = getDataType(token) ;
// 			if ( type.equals(DataType.TEXT) )
// 				continue ;
// 			
// 			// System.out.println("Found Type: " + type + " : " + token) ;
// 			
// 			return true ;
// 		}
// 		
// 		return false ;
// 	}
	
	public static void main(String[] args) 
	{
	/*	System.out.println(containsNumber("1")) ;
		System.out.println(containsNumber("1,000 a")) ;
		System.out.println(containsNumber(" -a")) ;
		System.out.println(containsNumber(" 1,000.1 ")) ;*/
	
		System.out.println(isNumericValue(" 1,000.0 ")) ;
		System.out.println(isNumericValue(" -1,000.0 ")) ;
		System.out.println(isNumericValue(" (1,000.0) ")) ;
		System.out.println(isNumericValue(" 10000 ")) ;
		System.out.println(isNumericValue(".37")) ;
		System.out.println(isNumericValue("HK10.15 cents")) ;
	}

	
}
