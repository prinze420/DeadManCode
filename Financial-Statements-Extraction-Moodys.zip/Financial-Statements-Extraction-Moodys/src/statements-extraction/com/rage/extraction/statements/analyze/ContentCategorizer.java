package com.rage.extraction.statements.analyze;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.index.Indexer;
import com.rage.extraction.statements.index.MemIndexer;
import com.rage.extraction.statements.uitls.AccentsRemover;



public class ContentCategorizer implements ContentAnalyzer {
	private Map<Integer, List<ParserOutput>> document;
	private Map<String, List<ParserOutput>> category;
	private ContentCluster contentCluster;
	private Indexer indexer;
	private Integer maxLength=0;
	private Integer tabSize;
	private String statementQuality;

	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(ContentCategorizer.class);

	public Indexer getIndexer() {
		return indexer;
	}

	public String getStatementQuality() {
		return statementQuality;
	}

	public ContentCategorizer(TreeMap<Integer, PageParse> pageParsesMap) throws Exception {
		tabSize=3;
		indexer=new MemIndexer();
		categorize(pageParsesMap);
	}

	public ContentCategorizer() {
	}

	public ContentCluster getContentCluster() {
		return contentCluster;
	}

	public Map<Integer, List<ParserOutput>> getDocument()
	{
		return document;
	}

	public Map<SectionBoundary, List<ParserOutput>> getClusterContent()
	{
		return contentCluster.getClusterGroups();
	}

	public void categorize(TreeMap<Integer, PageParse> pageParsesMap) throws Exception
	{
		if (logger!=null)
			logger.debug("Categorizing and indexing contents ...");

		indexer.openIndexer();
		List<ParserOutput> catList=null;
		Integer pageNo=0;
		//Integer ln = 0;

		if (document==null)
			document=new LinkedHashMap<Integer, List<ParserOutput>>();
		if (category==null)
			category=new LinkedHashMap<String, List<ParserOutput>>();

		category.put("SEPARATOR", new LinkedList<ParserOutput>());
		category.put("TABLE", new LinkedList<ParserOutput>());
		category.put("NON_TABLE", new LinkedList<ParserOutput>());

		for (Integer  page:pageParsesMap.keySet())
		{
			pageNo = page;
			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFLine> lines = parse.getPageLines() ;			
			catList=new LinkedList<ParserOutput>();
			ParserOutput cc=null, prevCC=null;
			for (int line=0; line<lines.size(); line++)
			{
				String text="";
				if(lines.get(line)!=null)
					text = lines.get(line).toString();
				System.out.print(text);
				if (text.length()>maxLength)
					maxLength=text.length();
				boolean dec=isTable(lines.get(line));
				//ln = ln +1;

				if (text.trim().equals(""))
					cc=new ParserOutput("SEPARATOR", text,  pageNo, line);
				else if (dec)
					cc=new ParserOutput("TABLE", text,  pageNo, line);
				else
					cc=new ParserOutput("NON_TABLE", text,  pageNo, line);

				catList.add(cc);
				List<ParserOutput> list=category.get(cc.getType());
				list.add(cc);

				cc.setPdfLine(lines.get(line));

				if (prevCC!=null && cc.getType().equals("TABLE") && !prevCC.getType().equals("SEPARATOR"))
					prevCC.setType("TABLE");
				prevCC=cc;
				String id=String.valueOf(cc.getPageNo())+"|"+String.valueOf(cc.getLineNo())+"|"+cc.getType();
				String content=text.replace("[", "").replace("]", "").replaceAll("\\-", " ");
				indexer.indexContent(id, AccentsRemover.removeAccents(content.toLowerCase())/*.replaceAll("\\s\\s+", " ")*/); //Sanmati
			}
			
			document.put(pageNo, catList);
		}
		document.put(pageNo, catList);
		indexer.closeIndexer();

	}

	public Integer getTabSize() {
		return tabSize;
	}

	public void setTabSize(Integer tabSize) {
		this.tabSize = tabSize;
	}

	public Map<String, List<ParserOutput>> getCategorizedData()
	{
		return category;
	}

	public Map<SectionBoundary, List<ParserOutput>> getClusterGroups()
	{
		return contentCluster.getClusterGroups();
	}

	public Map<String, List<ParserOutput>> getTableData()
	{
		return null;
	}



	public boolean isTable(PDFLine text)
	{
		if(text!=null && text.getChunks().size()>0 )
			return true;
		return false;
	}

	
}
