package com.rage.extraction.statements.db;

public class CoordinateDetails {
	private Integer stmtID;
	private Long poID;
	private String section;
	private String coordDetailVal1;
	private String coordDetailVal2;
	private String coordDetailVal3;
	private String coordDetailVal4;
	private String coordDetailVal5;
	private String coordDetailVal6;
	private String coordDetailVal7;
	private String coordDetailVal8;
	private String coordDetailVal9;
	private String coordDetailVal10;
	public Integer getStmtID() {
		return stmtID;
	}
	public void setStmtID(Integer stmtID) {
		this.stmtID = stmtID;
	}
	public Long getPoID() {
		return poID;
	}
	public void setPoID(Long poID) {
		this.poID = poID;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getCoordDetailVal1() {
		return coordDetailVal1;
	}
	public void setCoordDetailVal1(String coordDetailVal1) {
		this.coordDetailVal1 = coordDetailVal1;
	}
	public String getCoordDetailVal2() {
		return coordDetailVal2;
	}
	public void setCoordDetailVal2(String coordDetailVal2) {
		this.coordDetailVal2 = coordDetailVal2;
	}
	public String getCoordDetailVal3() {
		return coordDetailVal3;
	}
	public void setCoordDetailVal3(String coordDetailVal3) {
		this.coordDetailVal3 = coordDetailVal3;
	}
	public String getCoordDetailVal4() {
		return coordDetailVal4;
	}
	public void setCoordDetailVal4(String coordDetailVal4) {
		this.coordDetailVal4 = coordDetailVal4;
	}
	public String getCoordDetailVal5() {
		return coordDetailVal5;
	}
	public void setCoordDetailVal5(String coordDetailVal5) {
		this.coordDetailVal5 = coordDetailVal5;
	}
	public String getCoordDetailVal6() {
		return coordDetailVal6;
	}
	public void setCoordDetailVal6(String coordDetailVal6) {
		this.coordDetailVal6 = coordDetailVal6;
	}
	public String getCoordDetailVal7() {
		return coordDetailVal7;
	}
	public void setCoordDetailVal7(String coordDetailVal7) {
		this.coordDetailVal7 = coordDetailVal7;
	}
	public String getCoordDetailVal8() {
		return coordDetailVal8;
	}
	public void setCoordDetailVal8(String coordDetailVal8) {
		this.coordDetailVal8 = coordDetailVal8;
	}
	public String getCoordDetailVal9() {
		return coordDetailVal9;
	}
	public void setCoordDetailVal9(String coordDetailVal9) {
		this.coordDetailVal9 = coordDetailVal9;
	}
	public String getCoordDetailVal10() {
		return coordDetailVal10;
	}
	public void setCoordDetailVal10(String coordDetailVal10) {
		this.coordDetailVal10 = coordDetailVal10;
	}
	

}
