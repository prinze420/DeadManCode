package com.rage.extraction.statements.train;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.rage.extraction.statements.classifier.LabelMapper;

/**
 * @author kiran.umadi
 *
 */
public class SortedOutcomes {
	private Tree labelTree;
	private List<Outcome> outcomes;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SortedOutcomes.class);

	public SortedOutcomes(Tree tree) throws Exception {
		this.labelTree=tree;
		SectionMeta.getInstance();
	}


	public List<Outcome> search(String label)
	{
		List<Node> result=labelTree.searchLabel(label);
		outcomes=new ArrayList<Outcome>();
		if (result==null)
			return null;
		for (Node node:result) {
			outcomes.add(new Outcome(node));
		}
		Collections.sort(outcomes);
		return outcomes;
	}

	public List<Node> getLeafNodes()
	{
		List<Node> result=new ArrayList<Node>();
		for (Outcome node:outcomes)
		{
			if (node.getNode().getChilds()==null)
				result.add(node.getNode());
		}
		return result;
	}


	public List<Node> resolveConflicts(String prevSubSection)
	{
		if (outcomes.size()>0)
		{
			Set<String> dup=new HashSet<String>();
			List<Node> searchResult=new ArrayList<Node>();
			for (Outcome out:outcomes)
			{
				String label=labelTree.getSubSection(out.getNode()).toLowerCase()+":"+out.getNode().text().toLowerCase();
				if (dup.add(label))
					searchResult.add(out.getNode());
//				System.out.println("resolveConflicts -- " + label );
				logger.debug("resolveConflicts -- " + label );
			}
			return searchResult;
		}
		logger.debug("resolveConflicts -- NULL" );
//		System.out.println("resolveConflicts -- NULL" );
		return null;
	}

}
