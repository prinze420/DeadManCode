package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.List;

import com.rage.extraction.statements.detectors.text.DataType;


class RowSegmenterPattern 
{
	enum PatternType 
	{
		STARTS_WITH,
		CONTAINS,
		ENDS_WITH
	}
	
	enum PatternProgressUnit
	{
		PARA,
		LINE
	}
	
	static List<RowSegmenterPattern> parseRowSegmentationPattern(String rule)
	{
		List<RowSegmenterPattern> ret = new ArrayList<RowSegmenterPattern>() ;
		
		String[] split = rule.split(",") ;
		for ( int i=0 ; i<split.length ; i++ )
		{
			String thisSplit = split[i] ;
			
			String[] split2 = thisSplit.split("\\|") ;
			if ( split2.length == 2 )
			{
				PatternType patternType = PatternType.STARTS_WITH ;
				//DataType dataType = DataType.valueOf(split2[0]) ;
				
				DataType dataType = BlockTypeFinder.findType(split2[0]);
				PatternProgressUnit progressUnit = PatternProgressUnit.valueOf(split2[1]) ;
				
				RowSegmenterPattern pattern = new RowSegmenterPattern(patternType, dataType, progressUnit) ;
				ret.add(pattern) ;
				
				continue ;
			}
			
			PatternType patternType = PatternType.valueOf(split2[0]) ;
			//DataType dataType = DataType.valueOf(split2[1]) ;
			DataType dataType = BlockTypeFinder.findType(split2[1]);

			PatternProgressUnit progressUnit = PatternProgressUnit.valueOf(split2[2]) ;
			
			RowSegmenterPattern pattern = new RowSegmenterPattern(patternType, dataType, progressUnit) ;
			ret.add(pattern) ;
		}
		
		return ret ;
	}
	
	private PatternType patternType ;
	private DataType dataType ;
	private PatternProgressUnit progressUnit ;
	
	private RowSegmenterPattern(PatternType patternType, DataType dataType, PatternProgressUnit progressUnit)
	{
		setPatternType(patternType) ;
		setDataType(dataType) ;
		setProgressUnit(progressUnit) ;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((dataType == null) ? 0 : dataType.hashCode());
		result = prime * result
				+ ((patternType == null) ? 0 : patternType.hashCode());
		result = prime * result
				+ ((progressUnit == null) ? 0 : progressUnit.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		RowSegmenterPattern other = (RowSegmenterPattern) obj;
		if (dataType != other.dataType)
			return false;
		if (patternType != other.patternType)
			return false;
		if (progressUnit != other.progressUnit)
			return false;
		return true;
	}

	@Override
	public String toString() 
	{
		return "[" + getPatternType() + ", " + getDataType() + ", " + getProgressUnit() + "]" ;
	}

	public PatternType getPatternType() {
		return patternType;
	}

	public void setPatternType(PatternType patternType) {
		this.patternType = patternType;
	}

	public DataType getDataType() {
		return dataType;
	}

	public void setDataType(DataType dataType) {
		this.dataType = dataType;
	}

	public PatternProgressUnit getProgressUnit() {
		return progressUnit;
	}

	public void setProgressUnit(PatternProgressUnit progressUnit) {
		this.progressUnit = progressUnit;
	}
}
