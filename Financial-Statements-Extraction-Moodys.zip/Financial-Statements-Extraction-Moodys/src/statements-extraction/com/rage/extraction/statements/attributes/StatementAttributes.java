package com.rage.extraction.statements.attributes;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;


import com.rage.extraction.pdf.utils.AccentsRemover;
import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;

/**
 * @author kiran.umadi
 *
 */
public class StatementAttributes implements Attributes {
	private ArrayList<String> months;
	private  ArrayList<String> periods;
	private  ArrayList<String> currencies;
	private  ArrayList<String> units;


	private ArrayList<String> dates;
	private static HashMap<String, ArrayList<String>> attributeMap;
	private Pattern day;
	private Pattern year;
	private Matcher matcher;
	private int pageNo;
	private String unit;
	//private static String defaultCurrency;
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(StatementAttributes.class);

	public StatementAttributes() throws Exception {
		Constants.loadResourceProperty();
		read();
		day=Pattern.compile("(0?[1-9]|[12][0-9]|3[01]{1,2})+(,|\\s|TH\\s|ST\\s|RD\\s)");
		year=Pattern.compile("19[0-9]{2}|2[0-9]{3}");
		pageNo=0;
	}

	public List<String> getStatementQuality() {
		if (attributeMap!=null && attributeMap.containsKey("[Quality]")) {
			return attributeMap.get("[Quality]");
		}
		return null;
	}


	public static HashMap<String, ArrayList<String>> getAttributeMap() {
		return attributeMap;
	}

	public static void setAttributeMap(
			HashMap<String, ArrayList<String>> attributeMap) {
		StatementAttributes.attributeMap = attributeMap;
	}

	public List<String> getStatementDate() {
		if (attributeMap!=null && attributeMap.containsKey("[Date]")) {
			return attributeMap.get("[Date]");
		}
		return null;
	}


	public List<String> getStatementMonth() {
		if (attributeMap!=null && attributeMap.containsKey("[Month]")) {
			return attributeMap.get("[Month]");
		}
		return null;
	}


	public List<String> getStatementYear() {
		if (attributeMap!=null && attributeMap.containsKey("[Year]")) {
			return attributeMap.get("[Year]");
		}
		return null;
	}

	public List<String> getStatementPeriod() {
		if (attributeMap!=null && attributeMap.containsKey("[Period]")) {
			return attributeMap.get("[Period]");
		}
		return null;
	}


	private String changePeriodsPattern(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		dates=attributeMap.get("[Date-Patterns]");
		if (dates==null)
			return "";
		String poText = po.getRow().getLines().toString();
		String temp = poText.replaceAll("\t", "    ");
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		Pattern pattern=null;
		if(text.toString().toLowerCase().contains(" From ") || text.toString().toLowerCase().contains(" to ") || text.toString().toLowerCase().contains(" through ") ||  text.toString().toLowerCase().contains(" - ") )
		{
			List<String> lstDates = new ArrayList<String>();
			for (int i=0;i<dates.size();i++)
			{
				String[] s = dates.get(i).toString().split("##########");
				String key = s[0];
				String variant = s[1];

				pattern=Pattern.compile(variant,Pattern.CASE_INSENSITIVE);
				matcher=pattern.matcher(text);
				while (matcher.find())
				{

					if (matcher.start()==0)
						continue;
					int start=matcher.start()+matcher.group().length();
					if (start==0)
						continue;

					if (!text.toString().substring(0, matcher.start()).endsWith(">")
							&& !text.toString().substring(0, matcher.start()).endsWith(":"))
					{	
						String val=matcher.group();

						if((text.toString().toLowerCase().indexOf(" through ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" through ")) || (text.toString().toLowerCase().indexOf(" - ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" - ")) || (text.toString().toLowerCase().indexOf(" to ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" to ")) )
						{
							text.insert(start, "</DATE>");
							String date = parseDate(key, val);
							text.insert(matcher.start(),"<DATE:"+date+">");
							text.insert(matcher.start(),changeDatePattern(date));
						}

						String date = parseDate(key, val);
						lstDates.add(findDatePattern(date));
					}

				}
			}

			if(lstDates.size()>1)
			{
				String y1 = lstDates.get(0).substring(lstDates.get(0).lastIndexOf(" ")+1);
				String y2 = lstDates.get(1).substring(lstDates.get(1).lastIndexOf(" ")+1);
				String mon1 = lstDates.get(0).substring(lstDates.get(0).indexOf(",")+1,lstDates.get(0).lastIndexOf(" "));
				String mon2 = lstDates.get(1).substring(lstDates.get(1).indexOf(",")+1,lstDates.get(1).lastIndexOf(" "));
				String d1 = lstDates.get(0).substring(0,lstDates.get(0).indexOf(","));
				String d2 = lstDates.get(1).substring(0,lstDates.get(1).indexOf(","));
				text = new StringBuffer(text+ " "+findPeriods(y1,y2,mon1,mon2,d1,d2));
			}
		}
		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}
	private String changePeriodsPattern(String temp)
	{
		if (attributeMap==null)
			return "";
		dates=attributeMap.get("[Date-Patterns]");
		if (dates==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		Pattern pattern=null;
		if(text.toString().toLowerCase().contains(" From ") || text.toString().toLowerCase().contains(" to ") || text.toString().toLowerCase().contains(" through ") ||  text.toString().toLowerCase().contains(" - ") )
		{
			String []  dt  = null;
			if(text.toString().toLowerCase().contains(" From "))
			{
				dt = text.toString().split(" From ");

			}
			else
				if(text.toString().toLowerCase().contains(" to "))
				{
					dt = text.toString().split(" to ");
				}
				else
					if(text.toString().toLowerCase().contains(" - "))
					{
						dt = text.toString().split(" - ");
					}
					else
						if(text.toString().toLowerCase().contains(" through "))
						{
							dt = text.toString().split(" through ");
						}
			try {
				if(dt[0].split(" ").length==1)
				{

					String yr = dt[1].trim().substring(dt[1].trim().lastIndexOf(" ")).trim();
					if(yr.trim().length()==2)
					{
						yr = "20"+yr;
					}
					if(yr.trim().length()==1)
					{
						yr = "200"+yr;
					}
					text = new StringBuffer("1, "+dt[0] +" "+yr +" - "+ dt[1]);
				}
			} catch (Exception e) {
				
			}
			List<String> lstDates = new ArrayList<String>();
			for (int i=0;i<dates.size();i++)
			{
				String[] s = dates.get(i).toString().split("##########");
				String key = s[0];
				String variant = s[1];

				pattern=Pattern.compile(variant,Pattern.CASE_INSENSITIVE);
				matcher=pattern.matcher(text);
				while (matcher.find())
				{

					/*	if (matcher.start()==0)
						continue;*/
					int start=matcher.start()+matcher.group().length();
					if (start==0)
						continue;

					if (!text.toString().substring(0, matcher.start()).endsWith(">")
							&& !text.toString().substring(0, matcher.start()).endsWith(":"))
					{	
						String val=matcher.group();

						if((text.toString().toLowerCase().indexOf(" through ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" through ")) || (text.toString().toLowerCase().indexOf(" - ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" - ")) || (text.toString().toLowerCase().indexOf(" to ")!=-1 && text.toString().toLowerCase().indexOf(val.toLowerCase())>text.toString().toLowerCase().indexOf(" to ")) )
						{
							text.insert(start, "</DATE>");
							String date = parseDate(key, val);
							text.insert(matcher.start(),"<DATE:"+date+">");
							text.insert(matcher.start(),changeDatePattern(date));
						}

						String date = parseDate(key, val);
						lstDates.add(findDatePattern(date));
					}

				}
			}

			if(lstDates.size()>1)
			{
				String y1 = lstDates.get(0).substring(lstDates.get(0).lastIndexOf(" ")+1);
				String y2 = lstDates.get(1).substring(lstDates.get(1).lastIndexOf(" ")+1);
				String mon1 = lstDates.get(0).substring(lstDates.get(0).indexOf(",")+1,lstDates.get(0).lastIndexOf(" "));
				String mon2 = lstDates.get(1).substring(lstDates.get(1).indexOf(",")+1,lstDates.get(1).lastIndexOf(" "));
				String d1 = lstDates.get(0).substring(0,lstDates.get(0).indexOf(","));
				String d2 = lstDates.get(1).substring(0,lstDates.get(1).indexOf(","));
				String period = findPeriods(y1,y2,mon1,mon2,d1,d2);
				//if(period!=null)
				if(text.toString().toLowerCase().indexOf(" through ")!=-1)
				text = new StringBuffer(text.toString().substring(text.toString().toLowerCase().indexOf(" through "))+ " "+period);
				if(text.toString().toLowerCase().indexOf(" to ")!=-1)
					text = new StringBuffer(text.toString().substring(text.toString().toLowerCase().indexOf(" to "))+ " "+period);
				if(text.toString().toLowerCase().indexOf(" - ")!=-1)
					text = new StringBuffer(text.toString().substring(text.toString().toLowerCase().indexOf(" - "))+ " "+period);
				/*else
					text= new StringBuffer(temp);;*/
			}
		}

		return text.toString();
	}
	private String changeDatePattern(String date)
	{
		int mon=-1,mdate=-1;
		String month="";
		int y=-1;

		try {
			mon = Integer.parseInt(date.substring(0,date.indexOf("/")));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}

		try {
			y = Integer.parseInt(date.substring((date.lastIndexOf("/")+1)));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}

		month = findMonth(mon);

		try {
			mdate = Integer.parseInt(date.substring(date.indexOf("/")+1,date.lastIndexOf("/")));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}
		return(mdate+" , "+month+" "+y);

	}


	private String findDatePattern(String date)
	{
		int mon=-1,mdate=-1;
		int y=-1;

		try {
			mon = Integer.parseInt(date.substring(0,date.indexOf("/")));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}

		try {
			y = Integer.parseInt(date.substring((date.lastIndexOf("/")+1)));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}

		try {
			mdate = Integer.parseInt(date.substring(date.indexOf("/")+1,date.lastIndexOf("/")));
		} catch (Exception e2) {
			// TODO Auto-generated catch block
			//e2.printStackTrace();
		}
		return(mdate+" , "+mon+" "+y);

	}



	private String findPeriods(String yr1,String yr2,String mn1,String mn2,String dt1, String dt2)
	{
		int y1 = -1,y2 =-1, mon1 = 0, mon2 = 0,d1 = 0, d2 = 0;
		try {
			y1 = Integer.parseInt(yr1.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			y2 = Integer.parseInt(yr2.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			mon1 = Integer.parseInt(mn1.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			mon2 = Integer.parseInt(mn2.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		try {
			d1 = Integer.parseInt(dt1.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		try {
			d2 = Integer.parseInt(dt2.trim());
		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		int period =-1;
		int d = 0;
		if(y1==y2 || y1==-1)
		{
			if(d2>d1)
			{
				d = d2-d1;
			}
			if(d>28)
			{
				mon2 = mon2+1;
			}
			if(mon2>mon1)
				period=mon2-mon1;
			else
				period=mon1-mon2;

		}
		else
		{
			if(y1<y2)
			{
				mon1=12-(mon1);
				mon2=mon2-1;
				period=mon1+mon2;
			}
		}
		String pd="";
		if(period==0)
		{
			period=-1;
		}
		period = period+1;
		if(period!=-1)
		{
			switch(period)
			{
			case 1:pd="ONE";
			break;
			case 2:pd="TWO";
			break;
			case 3:pd="THREE";
			break;
			case 4:pd="FOUR";
			break;
			case 5:pd="FIVE";
			break;
			case 6:pd="SIX";
			break;
			case 7:pd="SEVEN";
			break;
			case 8:pd="EIGHT";
			break;
			case 9:pd="NINE";
			break;
			case 10:pd="TEN";
			break;
			case 11:pd="ELEVEN";
			break;
			case 12:pd="TWELVE";
			break;

			case 13:pd="THIRTEEN";
			break;
			case 14:pd="FOURTEEN";
			break;
			case 15:pd="FIFTEEN";
			break;
			case 16:pd="SIXTEEN";
			break;
			case 17:pd="SEVENTEEN";
			break;
			case 18:pd="EIGHTEEN";
			break;
			case 19:pd="NINETEEN";
			break;
			case 20:pd="TWENTY";
			break;
			}

			return(pd+" MONTHS "+"$$\n");
		}
		return null;
	}

	private String findMonth(int mth)
	{
		String month ="";
		switch(mth)
		{
		case 1:month="JANUARY";
		break;
		case 2:month="FEBRUARY";
		break;
		case 3:month="MARCH";
		break;
		case 4:month="APRIL";
		break;
		case 5:month="MAY";
		break;
		case 6:month="JUNE";
		break;
		case 7:month="JULY";
		break;
		case 8:month="AUGUST";
		break;
		case 9:month="SEPTEMBER";
		break;
		case 10:month="OCTOBER";
		break;
		case 11:month="NOVEMBER";
		break;
		case 12:month="DECEMBER";
		break;
		}
		return month;
	}


	private String parseDate(String format, String value)
	{
		List<String> formats = null;
		List<String> values = null;

		try {
			formats = new ArrayList<String>(Arrays.asList(format.split("[年月於日]")));
			values = new ArrayList<String>(Arrays.asList(value.split("[年月於日]")));
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if((formats==null && values== null) || (formats.size()==1 && values.size()==1))
		{
			try {
				formats = new ArrayList<String>(Arrays.asList(format.split("[\\s,/\\-/.]")));
				values = new ArrayList<String>(Arrays.asList(value.split("[\\s,/\\-/.]")));
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}}

		if((formats==null && values== null) || (formats.size()==1 && values.size()==1))
		{
			formats = new ArrayList<String>(Arrays.asList(format.split("[^0-9a-zA-Z]")));
			values = new ArrayList<String>(Arrays.asList(value.split("^0-9a-zA-Z]")));	
		}

		if(values.size()<formats.size())
		{
			for(int i=0; i<formats.size(); i++)
			{
				if(formats.get(i).trim().equals(""))
					formats.remove(i);
			}
		}

		if(values.size()>formats.size())
		{
			for(int i=0; i<values.size(); i++)
			{
				if(values.get(i).trim().equals(""))
					values.remove(i);
			}
		}



		String mm="",dd="", yy="", month="";
		for(int i=0; i<formats.size(); i++)
		{
			String fmt=formats.get(i).trim();
			String val ="";
			try {
				val = values.get(i).trim();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			if(fmt.trim().equalsIgnoreCase(""))
				continue;
			if (fmt.toLowerCase().startsWith("mmm") && val!=null)
			{
				mm=String.valueOf(monthOrdinal(val.trim()));
				month=val.trim();
			}
			else if (val!=null && fmt.toLowerCase().equals("mm"))
				mm=val.trim();
			if (val!=null && fmt.toLowerCase().equals("dd"))
				dd=val.trim();

			dd = dd.replaceAll("[^0-9]", "");
			if (val!=null && fmt.toLowerCase().startsWith("yy"))
			{
				if (val.trim().length()==2)
					yy="20"+val.trim();
				else
					yy=val.trim();
			}
		}
		if (dd.equals("") && !month.equals(""))
			dd=maxDayOfMonth(month);
		if (!mm.equals("") && !dd.equals("") && !yy.equals(""))
		{
			return mm+"/"+dd+"/"+yy;

		}
		return "";
	}



	private int monthOrdinal(String month)
	{
		int ordinal=1;
		String[] months=new String[]{"JANUARY","FEBRUARY","MARCH","APRIL","MAY","JUNE","JULY","AUGUST","SEPTEMBER","OCTOBER","NOVEMBER","DECEMBER","JAN","FEB","MAR","APR","JUN","JUL","AUG","SEP","OCT","NOV","DEC"};
		for (String key:months)
		{
			if (key.toUpperCase().equals(month.toUpperCase()) || key.toUpperCase().startsWith(month.toUpperCase()))
				return ordinal;
			ordinal++;
		}
		return -1;
	}


	private String maxDayOfMonth(String month)
	{
		String[] months=new String[]{"JANUARY:31","FEBRUARY:28","MARCH:31","APRIL:30","MAY:31","JUNE:30","JULY:31","AUGUST:31","SEPTEMBER:30","OCTOBER:31","NOVEMBER:30","DECEMBER:31"};
		for (String key:months)
		{
			if (key.toUpperCase().equals(month.toUpperCase()) || key.toUpperCase().startsWith(month.toUpperCase()))
			{
				String[] tokens=key.split("\\:");
				if (tokens.length==2)
					return tokens[1].trim();
			}
		}
		return "";
	}


	/*private ArrayList<ParserOutput> prepare(Map<String,ArrayList<String>> attrMap, String section, int valueColumnCount,int pageNo,TreeSet<Integer> columns)
	{
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		ParserOutput po = null;
		boolean isYearFound = false;
		boolean isMonthFound = false;
		boolean isDateFound = false;
		boolean isPeriodFound = false;
		boolean isCurrencyFound = false;
		boolean isUnitsFound = false;
		boolean isForFound = false;
		for (String attr:attrMap.keySet())
		{
			ArrayList<String> attrs = attrMap.get(attr);
			int ct = 1;
			isYearFound = getStatementYear(section, valueColumnCount, pageNo,
					poObjects, isYearFound, attr, attrs, ct,columns, "N");
			isMonthFound = getStatementMonth(section, valueColumnCount, pageNo,
					poObjects, isMonthFound, attr, attrs,columns);

			isDateFound = getStatementDate(section, valueColumnCount, pageNo,
					poObjects, isDateFound, attr, attrs,columns);
			if(attr.equalsIgnoreCase("PERIOD"))
			{
				po = new ParserOutput();
				isPeriodFound = getStatementPeriod(section, valueColumnCount,
						pageNo, poObjects, po, attrs,columns);
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT FOR");
				ct = 1;
				String stmFor = "Annual";
				for (String pd:attrs)
				{
					int pds = Integer.parseInt(pd);
					if(stmFor.equals("Annual"))
					{
						switch(pds){
						case 3:stmFor="Quarterly";
						break;
						case 6:stmFor="Half Yearly";
						break;
						}
					}
					for(int i= 0;i<valueColumnCount;i++)
					{
						ct++;
						setpoObject(po, ct, stmFor);
					}

				}
				po.setLineNo(-1);
				po.setMaxCol(valueColumnCount+1);
				po.setPageNo(pageNo);
				po.setSection(section);
				isForFound = true;
				po.setType("ATTR");
				poObjects.add(po);
			}

			if(attr.equalsIgnoreCase("CURRENCY"))
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT CURRENCY");
				ct = 1;
				if(attrs.size()>0)
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						for (String cr:attrs)
						{
							if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
							{
								while(columns.contains(ct))
								{
									if(ct>valueColumnCount)
										break;
									ct++;
								}

								setpoObject(po, ct, cr);
							}
							else
							{
								setpoObject(po, ct, cr);
								ct++;
							}	
						}
					}
				}
				else
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}

							setpoObject(po, ct, "Actuals");
						}
						else
						{
							setpoObject(po, ct, "Actuals");
							ct++;
						}	
					}
				}
				po.setLineNo(-3);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setMaxCol(valueColumnCount+1);
				po.setType("ATTR");
				poObjects.add(po);
				isCurrencyFound = true;
			}

			if(attr.equalsIgnoreCase("UNITS"))
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT UNITS");
				ct = 1;
				if(attrs.size()>0)
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						for (String units:attrs)
						{
							if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
							{
								while(columns.contains(ct))
								{
									if(ct>valueColumnCount)
										break;
									ct++;
								}
								setpoObject(po, ct, units);
							}
							else
							{
								setpoObject(po, ct, units);
								ct++;
							}	

						}
					}
				}
				else
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							setpoObject(po, ct, "Actuals");
						}
						else
						{
							setpoObject(po, ct, "Actuals");
							ct++;
						}	
					}
				}
				po.setLineNo(-2);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				poObjects.add(po);
				isUnitsFound = true;
			}
		}

		if(!isYearFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT YEAR");
			po.setLineNo(-7);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isMonthFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT MONTH");
			po.setLineNo(-6);
			po.setPageNo(pageNo);
			po.setType("ATTR");
			po.setSection(section);
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isDateFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT DATE");
			po.setLineNo(-5);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isPeriodFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT PERIOD");
			po.setLineNo(-4);
			po.setPageNo(pageNo);
			po.setType("ATTR");
			po.setSection(section);
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isCurrencyFound)
		{
			po = new ParserOutput();
			int ct = 1;
			for(int i= 0;i<valueColumnCount;i++)
			{
				if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
				{
					while(columns.contains(ct))
					{
						if(ct>valueColumnCount)
							break;
						ct++;
					}
					if(ct<valueColumnCount)
						setpoObject(po, ct, "USD");
				}
				else
				{
					setpoObject(po, ct, "USD");
					ct++;
				}	

			}

			po.setAsRepLabel("STATEMENT CURRENCY");
			po.setLineNo(-3);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isUnitsFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT UNITS");
			int ct = 0;
			for(int i= 0;i<valueColumnCount;i++)
			{
				if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
				{
					while(columns.contains(ct))
					{
						if(ct>valueColumnCount)
							break;
						ct++;
					}
					if(ct<valueColumnCount)
						setpoObject(po, ct, "Actuals");
				}
				else
				{
					setpoObject(po, ct, "Actuals");
					ct++;
				}	

			}
			po.setLineNo(-2);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		if(!isForFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT FOR");
			po.setLineNo(-1);
			po.setPageNo(pageNo);parsea

			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			poObjects.add(po);
		}

		return poObjects;
	}*/
	private ArrayList<ParserOutput> prepareHeading(ArrayList<ParserOutput> poObjects,Map<String,ArrayList<String>> attrMap, String section,int pageNo,int maxCol,TreeSet<Integer> columns, boolean isYearFound,  boolean isMonthFound, boolean isDateFound, boolean isPeriodFound, boolean isForFound, boolean isCurrencyFound, boolean isUnitsFound,String statementQuality)
	{
		//	ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		ParserOutput po = null;
		boolean isStatementQuality = false;
		for (String attr:attrMap.keySet())
		{
			ArrayList<String> attrs = attrMap.get(attr);
			int ct = 1;
			if(!isYearFound)
				isYearFound = getStatementYear(section, 1, pageNo,
						poObjects, isYearFound, attr, attrs, ct,columns,"Y");
			if(!isMonthFound)
				isMonthFound = getStatementMonth(section, 1, pageNo,
						poObjects, isMonthFound, attr, attrs, columns,"Y");
			if(!isDateFound)
				isDateFound = getStatementDate(section, 1, pageNo,
						poObjects, isDateFound, attr, attrs, columns,"Y");
			if(attr.equalsIgnoreCase("PERIOD"))
			{
				po = new ParserOutput();
				if(!isPeriodFound)
					isPeriodFound = getStatementPeriod(section, 1,
							pageNo, poObjects, po, attrs, columns,"Y");
				if(!isPeriodFound)
					isForFound = getStatementFor(section, 1, pageNo,
							"Y", poObjects, attrs,columns);
			}
			if(!isCurrencyFound)
				isCurrencyFound = getStatementCurrency(section, 1,
						pageNo, "Y", poObjects, isCurrencyFound, attr, attrs,columns);
			if(!isUnitsFound)
				isUnitsFound = getStatementUnits(section, 1, pageNo,
						"Y", poObjects, isUnitsFound, attr, attrs,columns);
		}



		if(!isYearFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT YEAR");
			po.setLineNo(-8);
			po.setPageNo(pageNo);
			po.setType("ATTR");
			po.setSubSection("ATTR");
			po.setSection(section);
			po.setMaxCol(maxCol+1);
			if(attributeMap.containsKey("[YearDefault]"))
			{
				///System.out.print("YESSSSSSSS---"+attributeMap.get("[YearDefault]"));
				for(int i=0;i<maxCol+1;i++)
				{
					setpoObject(po, i,FinancialStatementExtractor.getYear());

				}
			}
			poObjects.add(po);
		}
		if(!isMonthFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT MONTH");
			po.setLineNo(-7);
			po.setPageNo(pageNo);
			po.setType("ATTR");
			po.setSubSection("ATTR");
			po.setSection(section);
			po.setMaxCol(maxCol+1);
			if(attributeMap.containsKey("[Date]"))
			{
				//					System.out.print("YESSSSSSSS---"+attributeMap.get("[Month]"));
				for(int i=0;i<maxCol+1;i++)
				{
					setpoObject(po, i, attributeMap.get("[Month]").get(0));

				}
			}
			poObjects.add(po);
		}
		if(!isDateFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT DATE");
			po.setLineNo(-6);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(maxCol+1);
			if(attributeMap.containsKey("[Date]"))
			{
				//System.out.print("YESSSSSSSS---"+attributeMap.get("[Date]"));
				for(int i=0;i<maxCol+1;i++)
				{
					setpoObject(po, i, attributeMap.get("[Date]").get(0));

				}
			}
			poObjects.add(po);
		}

		if(!isPeriodFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT PERIOD");
			po.setLineNo(-5);
			po.setPageNo(pageNo);
			po.setType("ATTR");
			po.setSection(section);
			po.setMaxCol(maxCol+1);
			po.setSubSection("ATTR");
			if(!section.equalsIgnoreCase("BS"))
			{
				if(attributeMap.containsKey("[Period]"))
				{
					//System.out.print("YESSSSSSSS---"+attributeMap.get("[Period]"));
					for(int i=0;i<maxCol+1;i++)
					{
						setpoObject(po, i, attributeMap.get("[Period]").get(0));

					}
				}
			}

			poObjects.add(po);
		}

		if(!isStatementQuality)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT QUALITY");
			po.setLineNo(-1);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setMaxCol(maxCol+1);
			po.setType("ATTR");
			po.setSubSection("ATTR");


			poObjects.add(po);
			int ct=1;
			if(attributeMap.containsKey("[QualityDefault]"))
			{
				//System.out.print("YESSSSSSSS---"+attributeMap.get("[QualityDefault]"));
				for(int i=0;i<maxCol+1;i++)
				{
					setpoObject(po, i, attributeMap.get("[QualityDefault]").get(0));

				}
			}
			else
			{
				for(int i= 0;i<maxCol;i++)
				{
					if((columns!=null && columns.contains(ct)) )
					{
						while(columns.contains(ct))
						{
							if(ct>maxCol)
								break;
							ct++;
						}
						if(ct<maxCol)
						{
							if(getUnit()!=null && getUnit().contains("-"))
							{
								setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));		
							}
							else
							{
								setpoObject(po, ct, statementQuality);
							}
						}
					}
					else
					{
						if(getUnit()!=null && getUnit().contains("-"))
						{
							setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));		
						}
						else
						{
							setpoObject(po, ct, statementQuality);
						}	
					}
					ct++;
				}
			}
		}
		if(!isCurrencyFound)
		{
			po = new ParserOutput();
			int ct =1;
			for(int i= 0;i<=maxCol;i++)
			{
				if(getUnit()!=null && getUnit().contains("-"))
				{
					setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));		
				}
				else
				{
					if(attributeMap.containsKey("[CurrencyDefault]"))
					{
						setpoObject(po, i, attributeMap.get("[CurrencyDefault]").get(0));
					}
				}
			}

			po.setAsRepLabel("STATEMENT CURRENCY");
			po.setLineNo(-4);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(maxCol+1);
			po.setSubSection("ATTR");

			poObjects.add(po);
		}

		if(!isUnitsFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT UNITS");
			int ct =1;

			for(int i= 0;i<1;i++)
			{
				setpoObject(po, ct, "Actuals");
			}

			po.setLineNo(-3);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(maxCol+1);
			po.setSubSection("ATTR");

			poObjects.add(po);
		}

		if(!isForFound)
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT FOR");
			po.setLineNo(-2);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(maxCol+1);
			po.setSubSection("ATTR");

			poObjects.add(po);
		}
		return poObjects;
	}


	private ArrayList<ParserOutput> prepare(Map<String,ArrayList<String>> attrMap, String section, int valueColumnCount,int pageNo,String isHeader,List<ParserOutput> allList, TreeSet<Integer> columns, String statementQuality,int col)
	{
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		ParserOutput po = null;
		boolean isYearFound = false;
		boolean isMonthFound = false;
		boolean isDateFound = false;
		boolean isPeriodFound = false;
		boolean isCurrencyFound = false;
		boolean isUnitsFound = false;
		boolean isForFound = false;
		boolean isStmtQualityFound = false;
		for (String attr:attrMap.keySet())
		{
			ArrayList<String> attrs = attrMap.get(attr);
			int ct = col;
			isYearFound = getStatementYear(section, valueColumnCount, pageNo,
					poObjects, isYearFound, attr, attrs, ct,columns,isHeader);
			isMonthFound = getStatementMonth(section, valueColumnCount, pageNo,
					poObjects, isMonthFound, attr, attrs, columns,isHeader);
			isDateFound = getStatementDate(section, valueColumnCount, pageNo,
					poObjects, isDateFound, attr, attrs, columns,isHeader);
			if(attr.equalsIgnoreCase("PERIOD"))
			{
				po = new ParserOutput();
				isPeriodFound = getStatementPeriod(section, valueColumnCount,
						pageNo, poObjects, po, attrs, columns,isHeader);
				isForFound = getStatementFor(section, valueColumnCount, pageNo,
						isHeader, poObjects, attrs,columns);
			}
			isCurrencyFound = getStatementCurrency(section, valueColumnCount,
					pageNo, isHeader, poObjects, isCurrencyFound, attr, attrs, columns);
			isUnitsFound = getStatementUnits(section, valueColumnCount, pageNo,
					isHeader, poObjects, isUnitsFound, attr, attrs, columns);
		}

		if(!isHeader.equalsIgnoreCase("Y") )
		{
			if(!isYearFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT YEAR");
				po.setLineNo(-8);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");
				if(attributeMap.containsKey("[YearDefault]"))
				{
					///System.out.print("YESSSSSSSS---"+attributeMap.get("[YearDefault]"));
					for(int i=0;i<valueColumnCount+1;i++)
					{
						setpoObject(po, i,FinancialStatementExtractor.getYear());

					}
				}
				poObjects.add(po);
			}

			if(!isStmtQualityFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT QUALITY");
				po.setLineNo(-1);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");

				poObjects.add(po);
				int ct=1;

				if(attributeMap.containsKey("[QualityDefault]"))
				{
					//System.out.print("YESSSSSSSS---"+attributeMap.get("[QualityDefault]"));
					for(int i=0;i<valueColumnCount+1;i++)
					{
						setpoObject(po, i, attributeMap.get("[QualityDefault]").get(0));

					}
				}
				else
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
							{
								if(getUnit()!=null && getUnit().contains("-"))
								{
									setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));		
								}
								else
								{
									setpoObject(po, ct, statementQuality);
								}
							}

						}else{

							if(getUnit()!=null && getUnit().contains("-"))
							{
								setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));		
							}
							else
							{
								setpoObject(po, ct, statementQuality);
							}	



						}
						ct++;
					}
				}
			}


			if(!isMonthFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT MONTH");
				po.setLineNo(-7);
				po.setSubSection("ATTR");
				po.setPageNo(pageNo);
				po.setType("ATTR");
				po.setSection(section);
				po.setMaxCol(valueColumnCount+1);

				if(attributeMap.containsKey("[Date]"))
				{
					//					System.out.print("YESSSSSSSS---"+attributeMap.get("[Month]"));
					for(int i=0;i<valueColumnCount+1;i++)
					{
						setpoObject(po, i, attributeMap.get("[Month]").get(0));

					}
				}
				poObjects.add(po);
			}
			if(!isDateFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT DATE");
				po.setLineNo(-6);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");
				if(attributeMap.containsKey("[Date]"))
				{
					//System.out.print("YESSSSSSSS---"+attributeMap.get("[Date]"));
					for(int i=0;i<valueColumnCount+1;i++)
					{
						setpoObject(po, i, attributeMap.get("[Date]").get(0));

					}
				}
				poObjects.add(po);
			}

			if(!isPeriodFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT PERIOD");
				po.setLineNo(-5);
				po.setPageNo(pageNo);
				po.setType("ATTR");
				po.setSection(section);
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");
				if(!section.equalsIgnoreCase("BS"))
				{
					if(attributeMap.containsKey("[Period]"))
					{
						//System.out.print("YESSSSSSSS---"+attributeMap.get("[Period]"));
						for(int i=0;i<valueColumnCount+1;i++)
						{
							setpoObject(po, i, attributeMap.get("[Period]").get(0));

						}
					}
				}
				poObjects.add(po);
			}
			if(!isCurrencyFound)
			{

				po = new ParserOutput();
				int ct = 1;
				if(attributeMap.containsKey("[CurrencyDefault]"))
				{
					//	System.out.print("YESSSSSSSS---"+attributeMap.get("[CurrencyDefault]"));
					for(int i=0;i<valueColumnCount+1;i++)
					{
						setpoObject(po, i, attributeMap.get("[CurrencyDefault]").get(0));

					}
				}
				else
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}

							if(ct<=valueColumnCount)
							{
								if(getUnit()!=null && getUnit().contains("-"))
								{
									setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));
								}
								else
									setpoObject(po, ct, "USD");
							}

						}
						else
						{
							if(getUnit()!=null && getUnit().contains("-"))
							{
								setpoObject(po, ct, getUnit().substring(0,getUnit().indexOf("-")));
							}
							else
								setpoObject(po, ct, "USD");

						}	
						ct++;

					}
				}

				po.setAsRepLabel("STATEMENT CURRENCY");
				po.setLineNo(-4);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");

				poObjects.add(po);
			}

			if(!isUnitsFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT UNITS");
				int ct = 1;
				for(int i= 0;i<valueColumnCount;i++)
				{
					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
						{
							setpoObject(po, ct, "Actuals");
						}
					}
					else
					{
						setpoObject(po, ct, "Actuals");

					}
					ct++;

				}
				po.setLineNo(-3);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");

				poObjects.add(po);
			}


			if(!isForFound)
			{
				po = new ParserOutput();
				po.setAsRepLabel("STATEMENT FOR");
				po.setLineNo(-2);
				po.setPageNo(pageNo);
				po.setSection(section);
				po.setType("ATTR");
				po.setMaxCol(valueColumnCount+1);
				po.setSubSection("ATTR");

				poObjects.add(po);
			}

		}

		if((!isMonthFound || !isYearFound  || !isPeriodFound ||!isUnitsFound  || !isCurrencyFound || !isStmtQualityFound || !isDateFound)&& isHeader.equalsIgnoreCase("Y"))
		{
			markRemainedStatementAttributes(allList,isMonthFound,isYearFound,isUnitsFound,isPeriodFound,isStmtQualityFound,isCurrencyFound,isDateFound);
			Map<String, ArrayList<String>> newAttrMap = parseAttributes(allList);
			for(String s : newAttrMap.keySet()){
				if(!attrMap.containsKey(s))
				{
					attrMap.put(s, newAttrMap.get(s));
				}
			}
			poObjects = prepareHeading(poObjects,attrMap,section,pageNo,1,columns,isYearFound,isMonthFound,isDateFound,isPeriodFound,isForFound,isCurrencyFound,isUnitsFound, statementQuality);
		}

		return poObjects;

	}

	private boolean getStatementCurrency(String section, int valueColumnCount,
			int pageNo, String isHeader, ArrayList<ParserOutput> poObjects,
			boolean isCurrencyFound, String attr, ArrayList<String> attrs, TreeSet<Integer> columns) {
		ParserOutput po;
		int ct;
		if(attr.equalsIgnoreCase("CURRENCY"))
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT CURRENCY");
			ct = 1;
			if(attrs.size()>0)
			{
				for(int i= 0;i<valueColumnCount;i++)
				{
					for (String cr:attrs)
					{	
						if(ct>valueColumnCount)
							break;
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}

							if(ct<=valueColumnCount)
								setpoObject(po, ct, cr);
							ct++;
						}
						else
						{
							setpoObject(po, ct, cr);
							ct++;
						}	
					}
				}
			}
			else
			{
				if(!isHeader.equalsIgnoreCase("Y"))
				{
					for(int i= 0;i<valueColumnCount;i++)
					{	
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							if(ct>valueColumnCount)
								break;
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
								setpoObject(po, ct, "Actuals");
						}
						else
						{
							setpoObject(po, ct, "Actuals");

						}	
						ct++;
					}
				}
				else
				{

					for(int i= 0;i<valueColumnCount;i++)
					{	
						if(ct>valueColumnCount)
							break;
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
								setpoObject(po, ct, "Actuals");
						}
						else
						{
							setpoObject(po, ct, "Actuals");
						}
						ct++;
					}

				}
			}
			po.setLineNo(-3);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setMaxCol(valueColumnCount+1);
			po.setType("ATTR");
			po.setSubSection("ATTR");

			poObjects.add(po);
			isCurrencyFound = true;
		}
		return isCurrencyFound;
	}

	private boolean getStatementUnits(String section, int valueColumnCount,
			int pageNo, String isHeader, ArrayList<ParserOutput> poObjects,
			boolean isUnitsFound, String attr, ArrayList<String> attrs, TreeSet<Integer> columns) {
		ParserOutput po;
		int ct;
		if(attr.equalsIgnoreCase("UNITS"))
		{
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT UNITS");
			ct = 1;
			if(attrs.size()>0)
			{
				for(int i= 0;i<valueColumnCount;i++)
				{
					for (String units:attrs)
					{
						if(ct>valueColumnCount)
							break;
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
							{
								if(units!=null && units.contains("-"))
								{
									setUnit(units);
									setpoObject(po, ct, units.substring(units.indexOf("-")+1));
								}
								else
									setpoObject(po, ct, units);							
							}
						}
						else
						{

							if(units!=null && units.contains("-"))
							{
								setUnit(units);
								setpoObject(po, ct, units.substring(units.indexOf("-")+1));
							}
							else
								setpoObject(po, ct, units);							
						}
						ct++;

					}
				}
			}
			else
			{
				if(!isHeader.equalsIgnoreCase("Y"))
				{
					for(int i= 0;i<valueColumnCount;i++)
					{
						if(ct>valueColumnCount)
							break;
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{

							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
								setpoObject(po, ct, "Actuals");
						}
						else
						{
							setpoObject(po, ct, "Actuals");

						}	
						ct++;

					}
				}
			}
			po.setLineNo(-2);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			po.setSubSection("ATTR");

			poObjects.add(po);
			isUnitsFound = true;
		}
		return isUnitsFound;
	}

	private boolean getStatementFor(String section, int valueColumnCount,
			int pageNo, String isHeader, ArrayList<ParserOutput> poObjects,
			ArrayList<String> attrs, TreeSet<Integer> columns) {
		ParserOutput po;
		boolean isForFound;
		int ct;
		po = new ParserOutput();
		po.setAsRepLabel("STATEMENT FOR");
		ct = 1;
		String stmFor = "Annual";
		for (String pd:attrs)
		{
			int pds = Integer.parseInt(pd);
			if(stmFor.equals("Annual"))
			{
				switch(pds){
				case 3:stmFor="Quarterly";
				break;
				case 6:stmFor="Half Yearly";
				break;
				}
			}
			if(isHeader.equalsIgnoreCase("Y"))
			{
				for(int i= 0;i<valueColumnCount;i++)
				{	
					if(ct>valueColumnCount)
						break;
					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
							setpoObject(po, ct, stmFor);
					}
					else
					{
						setpoObject(po, ct, stmFor);

					}	
					ct++;
				}
			}
			else
			{
				if(!isHeader.equalsIgnoreCase("Y"))
				{
					for(int i= 0;i<valueColumnCount;i++)
					{	
						if(ct>valueColumnCount)
							break;
						if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
						{
							while(columns.contains(ct))
							{
								if(ct>valueColumnCount)
									break;
								ct++;
							}
							if(ct<=valueColumnCount)
								setpoObject(po, ct, stmFor);
						}
						else
						{
							setpoObject(po, ct, stmFor);

						}	
						ct++;
					}


				}
			}

		}
		po.setLineNo(-1);
		po.setMaxCol(valueColumnCount+1);
		po.setPageNo(pageNo);
		po.setSection(section);
		isForFound = true;
		po.setType("ATTR");
		po.setSubSection("ATTR");

		poObjects.add(po);
		return isForFound;
	}

	private boolean getStatementPeriod(String section, int valueColumnCount,
			int pageNo, ArrayList<ParserOutput> poObjects, ParserOutput po,
			ArrayList<String> attrs, TreeSet<Integer> columns, String isHeader) {
		boolean isPeriodFound;
		int ct;
		po.setAsRepLabel("STATEMENT PERIOD");
		if(attrs.size()<=valueColumnCount)
		{
			String period = "";
			ct = 1;
			for (String pd:attrs)
			{
				period=pd;

				if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
				{
					while(columns.contains(ct))
					{
						if(ct>valueColumnCount)
							break;
						ct++;
					}
					if(ct<=valueColumnCount)

						setpoObject(po, ct, pd);
					ct++;
				}
				else
				{
					setpoObject(po, ct, pd);
					ct++;
				}	

			}
			for(int i= attrs.size();i<valueColumnCount;i++)
			{
				if(ct>valueColumnCount)
					break;
				if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
				{
					while(columns.contains(ct))
					{
						if(ct>valueColumnCount)
							break;
						ct++;
					}
					if(ct<=valueColumnCount)
						setpoObject(po, ct, period);
					ct++;

				}
				else
				{
					setpoObject(po, ct, period);
					ct++;
				}	
			}
		}
		po.setLineNo(-4);
		po.setPageNo(pageNo);
		po.setType("ATTR");
		po.setSection(section);
		po.setMaxCol(valueColumnCount+1);
		po.setSubSection("ATTR");

		poObjects.add(po);
		isPeriodFound=true;
		return isPeriodFound;
	}

	private boolean getStatementDate(String section, int valueColumnCount,
			int pageNo, ArrayList<ParserOutput> poObjects, boolean isDateFound,
			String attr, ArrayList<String> attrs, TreeSet<Integer> columns, String isHeader) {
		ParserOutput po;
		int ct;
		if(attr.equalsIgnoreCase("DAY"))
		{
			ct = 1;
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT DATE");

			if(attrs.size()<=valueColumnCount)
			{
				String day = "";

				for (String dt:attrs)
				{
					day=dt;

					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
							setpoObject(po, ct, day);
					}
					else
					{
						setpoObject(po, ct, day);
						ct++;
					}

				}
				for(int i= attrs.size();i<valueColumnCount;i++)
				{			
					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
							setpoObject(po, ct, day);
					}
					else
					{
						setpoObject(po, ct, day);
						ct++;
					}
				}
			}
			else
			{
				for (String dt:attrs)
				{
					if(ct>valueColumnCount)
						break;

					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
							setpoObject(po, ct, dt);
					}
					else
					{
						setpoObject(po, ct, dt);
						ct++;
					}		
				}
			}
			po.setLineNo(-6);
			po.setPageNo(pageNo);
			po.setSection(section);
			isDateFound=true;
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			po.setSubSection("ATTR");

			poObjects.add(po);

		}
		return isDateFound;
	}

	private boolean getStatementMonth(String section, int valueColumnCount,
			int pageNo, ArrayList<ParserOutput> poObjects,
			boolean isMonthFound, String attr, ArrayList<String> attrs,TreeSet<Integer> columns, String isHeader) {
		ParserOutput po;
		int ct;
		if(attr.equalsIgnoreCase("MONTH"))
		{
			ct = 1;
			po = new ParserOutput();
			po.setAsRepLabel("STATEMENT MONTH");

			for (String mth:attrs)
			{
				if(!FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
					mth = mapNonEnglishMonths(mth);
				if(ct>valueColumnCount)
					break;

				if((columns!=null && columns.contains(ct) &&  !isHeader.equalsIgnoreCase("Y")))
				{
					while(columns.contains(ct))
					{
						if(ct>valueColumnCount)
							break;
						ct++;
					}
					if(ct<=valueColumnCount)
						setpoObject(po, ct, mth);
				}
				else
				{
					setpoObject(po, ct, mth);
					ct++;
				}	
			}
			if(attrs.size()<valueColumnCount)
			{
				String month = "";
				for (String mth:attrs)
				{
					if(!FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
						mth = mapNonEnglishMonths(mth);
					month=mth;
				}
				for(int i= attrs.size();i<valueColumnCount;i++)
				{
					if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("y"))
					{
						while(columns.contains(ct))
						{
							if(ct>valueColumnCount)
								break;
							ct++;
						}
						if(ct<=valueColumnCount)
							setpoObject(po, ct, month);
					}
					else
					{
						setpoObject(po, ct, month);
						ct++;
					}	
				}
			}
			po.setLineNo(-7);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setType("ATTR");
			po.setMaxCol(valueColumnCount+1);
			po.setSubSection("ATTR");

			poObjects.add(po);
			isMonthFound = true;
		}
		return isMonthFound;
	}

	private boolean getStatementYear(String section, int valueColumnCount,
			int pageNo, ArrayList<ParserOutput> poObjects, boolean isYearFound,
			String attr, ArrayList<String> attrs, int ct,TreeSet<Integer> columns, String isHeader) {
		ParserOutput po;
		if(attr.equalsIgnoreCase("YEAR"))
		{
			po = new ParserOutput();

			po.setAsRepLabel("STATEMENT YEAR");
			for (String yr:attrs)
			{
				if(ct>valueColumnCount && !isHeader.equalsIgnoreCase("Y"))
					break;

				if((columns!=null && columns.contains(ct)) && !isHeader.equalsIgnoreCase("Y"))
				{
					if(columns!=null)
					{
						while(columns.contains(ct))
						{
							ct++;
							if(ct>valueColumnCount)
								break;
						}
					}
					if(ct<=valueColumnCount)
						setpoObject(po, ct, yr);

				}
				else
				{
					setpoObject(po, ct, yr);
				}	

				ct++;
			}

			if(attrs.size()<valueColumnCount)
			{
				for(int i= attrs.size();i<valueColumnCount;i++)
				{

					if(columns!=null)
					{
						while(columns.contains(ct))
						{
							ct++;
							if(ct>valueColumnCount)
								break;
						}
					}
					if(ct>valueColumnCount)
						break;
					if(attrs.size()>0)
					{
						setpoObject(po, ct, attrs.get(attrs.size()-1));
					}
					ct++;
				}
			}
			po.setLineNo(-8);
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setMaxCol(valueColumnCount+1);
			po.setType("ATTR");
			po.setSubSection("ATTR");

			poObjects.add(po);
			isYearFound = true;
		}
		return isYearFound;
	}





	// TODO Remove unused code found by UCDetector
	// 	public ArrayList<ParserOutput> getEmptyAttributes(String section, int pageNo) {
	// 		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
	// 		ParserOutput po = new ParserOutput();		
	// 		po.setAsRepLabel("STATEMENT YEAR");
	// 		po.setLineNo(-7);
	// 		po.setPageNo(0);
	// 		po.setSection(section);
	// 		po.setType("ATTR");
	// 
	// 		poObjects.add(po);
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT MONTH");
	// 		po.setLineNo(-6);
	// 		po.setPageNo(0);
	// 		po.setSection(section);
	// 		po.setType("ATTR");
	// 		poObjects.add(po);
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT DATE");
	// 		po.setLineNo(-5);
	// 		po.setPageNo(0);
	// 		po.setSection(section);
	// 		po.setType("ATTR");
	// 		poObjects.add(po);
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT PERIOD");
	// 		po.setLineNo(-4);
	// 		po.setPageNo(-4);
	// 		po.setType("ATTR");
	// 		poObjects.add(po);
	// 
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT CURRENCY");
	// 		po.setLineNo(-3);
	// 		po.setPageNo(0);
	// 		po.setSection(section);
	// 		po.setType("ATTR");
	// 		poObjects.add(po);
	// 
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT UNITS");
	// 		po.setLineNo(-2);
	// 		po.setPageNo(0);
	// 		po.setSection(section);
	// 
	// 
	// 		po = new ParserOutput();
	// 		po.setAsRepLabel("STATEMENT FOR");
	// 		po.setLineNo(-1);
	// 		po.setPageNo(0);
	// 		po.setType("ATTR");
	// 		po.setSection(section);
	// 
	// 
	// 		poObjects.add(po);
	// 		return poObjects;
	// 
	// 	}


	private void setpoObject(ParserOutput po, int ct, String val) {
		switch(ct)
		{
		case 1:	{
			po.setAsRepVal1(val);
			po.setValue1(val);
			break;
		}
		case 2:	{
			po.setAsRepVal2(val);
			po.setValue2(val);
			break;
		}
		case 3:	{
			po.setAsRepVal3(val);
			po.setValue3(val);
			break;
		}
		case 4:	{
			po.setAsRepVal4(val);
			po.setValue4(val);
			break;
		}
		case 5:	{
			po.setAsRepVal5(val);
			po.setValue5(val);
			break;
		}
		case 6:	{
			po.setAsRepVal6(val);
			po.setValue6(val);
			break;
		}
		case 7:	{
			po.setAsRepVal7(val);
			po.setValue7(val);
			break;
		}
		case 8:	{
			po.setAsRepVal8(val);
			po.setValue8(val);
			break;
		}
		case 9:	{
			po.setAsRepVal9(val);
			po.setValue9(val);
			break;
		}
		case 10:	{
			po.setAsRepVal10(val);
			po.setValue10(val);
			break;
		}
		case 11:	{
			po.setAsRepVal11(val);
			po.setValue11(val);
			break;
		}
		case 12:	{
			po.setAsRepVal12(val);
			po.setValue12(val);
			break;
		}
		case 13:	{
			po.setAsRepVal13(val);
			po.setValue13(val);
			break;
		}
		case 14:	{
			po.setAsRepVal14(val);
			po.setValue14(val);
			break;
		}
		case 15:	{
			po.setAsRepVal15(val);
			po.setValue15(val);
			break;
		}
		case 16:	{
			po.setAsRepVal16(val);
			po.setValue16(val);
			break;
		}
		case 17:	{
			po.setAsRepVal17(val);
			po.setValue17(val);
			break;
		}
		case 18:	{
			po.setAsRepVal18(val);
			po.setValue18(val);
			break;
		}
		case 19:	{
			po.setAsRepVal19(val);
			po.setValue19(val);
			break;
		}
		case 20:	{
			po.setAsRepVal20(val);
			po.setValue20(val);
			break;
		}

		}
	}

	private List<ParserOutput> markStatementAttributes(List<ParserOutput> poList)
	{
		for(ParserOutput po:poList)
		{
			if (po.getMaxCol()==0)
				continue;
			switch (po.getMaxCol()){
			case 1:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				break;
			}
			case 2:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				break;

			}
			case 3:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				break;

			}
			case 4:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				break;

			}
			case 5:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				break;

			}
			case 6:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				break;

			}
			case 7:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				break;

			}
			case 8:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				break;

			}	
			case 9:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				break;


			}
			case 10:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				break;


			}	

			case 11:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				break;
			}
			case 12:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				break;

			}
			case 13:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				break;

			}
			case 14:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				break;

			}
			case 15:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				break;

			}
			case 16:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				po.setAsRepVal16(markStatementAttributes(po.getAsRepVal16()));
				break;

			}
			case 17:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				po.setAsRepVal16(markStatementAttributes(po.getAsRepVal16()));
				po.setAsRepVal17(markStatementAttributes(po.getAsRepVal17()));
				break;

			}
			case 18:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				po.setAsRepVal16(markStatementAttributes(po.getAsRepVal16()));
				po.setAsRepVal17(markStatementAttributes(po.getAsRepVal17()));
				po.setAsRepVal18(markStatementAttributes(po.getAsRepVal18()));
				break;

			}	
			case 19:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				po.setAsRepVal16(markStatementAttributes(po.getAsRepVal16()));
				po.setAsRepVal17(markStatementAttributes(po.getAsRepVal17()));
				po.setAsRepVal18(markStatementAttributes(po.getAsRepVal18()));
				po.setAsRepVal19(markStatementAttributes(po.getAsRepVal19()));
				break;


			}
			case 20:{
				po.setAsRepVal1(markStatementAttributes(po.getAsRepVal1()));
				po.setAsRepVal2(markStatementAttributes(po.getAsRepVal2()));
				po.setAsRepVal3(markStatementAttributes(po.getAsRepVal3()));
				po.setAsRepVal4(markStatementAttributes(po.getAsRepVal4()));
				po.setAsRepVal5(markStatementAttributes(po.getAsRepVal5()));
				po.setAsRepVal6(markStatementAttributes(po.getAsRepVal6()));
				po.setAsRepVal7(markStatementAttributes(po.getAsRepVal7()));
				po.setAsRepVal8(markStatementAttributes(po.getAsRepVal8()));
				po.setAsRepVal9(markStatementAttributes(po.getAsRepVal9()));
				po.setAsRepVal10(markStatementAttributes(po.getAsRepVal10()));
				po.setAsRepVal11(markStatementAttributes(po.getAsRepVal11()));
				po.setAsRepVal12(markStatementAttributes(po.getAsRepVal12()));
				po.setAsRepVal13(markStatementAttributes(po.getAsRepVal13()));
				po.setAsRepVal14(markStatementAttributes(po.getAsRepVal14()));
				po.setAsRepVal15(markStatementAttributes(po.getAsRepVal15()));
				po.setAsRepVal16(markStatementAttributes(po.getAsRepVal16()));
				po.setAsRepVal17(markStatementAttributes(po.getAsRepVal17()));
				po.setAsRepVal18(markStatementAttributes(po.getAsRepVal18()));
				po.setAsRepVal19(markStatementAttributes(po.getAsRepVal19()));
				po.setAsRepVal20(markStatementAttributes(po.getAsRepVal20()));
				break;
			}		
			}
		}
		return poList;

	}

	private String markStatementAttributes(String text)
	{
		Pattern p=Pattern.compile("[0-9]{1,3}+[,.]{1}+[0-9]{1,3}+\\s");
		Matcher m=null;
		if(text==null)
			return text;
		m=p.matcher(text);
		if ((text.toUpperCase().indexOf(" TO ")!=-1
				&& text.toUpperCase().indexOf(" FROM ")!=-1) || text.toUpperCase().indexOf(" - ")!=-1
				|| m.find())
		{
			text = changePeriodsPattern(text);
		}
		else
		{
			String cLine = text;
			if(cLine.indexOf(":")!=-1)
			{
				String cLine1="";
				cLine1=cLine;
				int min=-1;
				int hh=-1;
				//	int sec=-1;
				try {
					hh=Integer.parseInt(cLine1.substring(cLine1.indexOf(":")-2,cLine1.indexOf(":")));
					cLine1=cLine1.substring(cLine1.indexOf(":")+1);
				} catch (Exception e) {

					if(logger!=null)
					{						
						logger.info(e.getMessage());
					}
				}
				try {
					min=Integer.parseInt(cLine1.substring(0,2));
					cLine1=cLine1.substring(cLine1.indexOf(":")+1);
				} catch (Exception e) {

					if(logger!=null)
					{						
						logger.info(e.getMessage());
					}
				}
				/*try {
					sec=Integer.parseInt(cLine1.substring(0,2));
					cLine1=cLine1.substring(cLine1.indexOf(":")+1);
				} catch (Exception e) {

					if(logger!=null)
					{						
						logger.info(e.getMessage());
					}
				}*/
				if((hh!=-1 && hh>=0 && hh<=24 && min!=-1 && min>=0 && min<=60 && cLine.indexOf("FOR THE YEAR ENDED")==-1)
						|| (cLine.toUpperCase().indexOf(" AM ")!=-1 || cLine.toUpperCase().indexOf("PM ")!=-1 || cLine.toUpperCase().indexOf(" PAGE ")!=-1))
				{
					return text;
				}
			}
			text = labelDatePattern(text);

		}

		text = labelPeriods(text);

		text = labelMonths(text);
		text = labelDayYear(text);
		text = labelCurrency(text);
		text = labelUnits(text);
		return text;
	}


	private List<ParserOutput> markRemainedStatementAttributes(List<ParserOutput> poList, boolean isMonthFound, boolean isYearFound, boolean isUnitsFound, boolean isPeriodFound, boolean isStmtQualityFound,boolean isCurrencyFound,boolean isDayFound)
	{
		Pattern p=Pattern.compile("[0-9]{1,3}+[,.]{1}+[0-9]{1,3}+\\s");
		Matcher m=null;
		for(ParserOutput po:poList)
		{
			if (po.getMaxCol()==0 || (po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")))
				continue;
			if (pageNo==0)
				pageNo=Integer.valueOf(po.getPageNo());
			String text = po.getLine();
			m=p.matcher(text);
			if ((text.toUpperCase().indexOf(" TO ")!=-1
					&& text.toUpperCase().indexOf(" FROM ")!=-1) || text.toUpperCase().indexOf(" - ")!=-1
					|| m.find())
			{
				if(!isPeriodFound)
					changePeriodsPattern(po);
			}
			else
			{
				String cLine = text;
				if(cLine.indexOf(":")!=-1)
				{
					String cLine1="";
					cLine1=cLine;
					int min=-1;
					int hh=-1;
					//int sec=-1;
					try {
						hh=Integer.parseInt(cLine1.substring(cLine1.indexOf(":")-2,cLine1.indexOf(":")));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}
					try {
						min=Integer.parseInt(cLine1.substring(0,2));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}
					/*try {
						sec=Integer.parseInt(cLine1.substring(0,2));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}*/
					if((hh!=-1 && hh>=0 && hh<=24 && min!=-1 && min>=0 && min<=60 && cLine.indexOf("FOR THE YEAR ENDED")==-1)
							|| (cLine.toUpperCase().indexOf(" AM ")!=-1 || cLine.toUpperCase().indexOf("PM ")!=-1 || cLine.toUpperCase().indexOf(" PAGE ")!=-1))
					{
						continue;
					}
				}

				if(!isYearFound )
					labelDatePattern(po);

			}
			
			if(!isPeriodFound)
				labelPeriods(po);
			if(!isMonthFound)
				labelMonths(po);
			if(!isDayFound)
				labelDayYear(po,isYearFound);
			if(!isCurrencyFound)
				labelCurrency(po);
			if(!isUnitsFound)
				labelUnits(po);
		}
		return poList;

	}

	private List<ParserOutput> markStatementAttributes(List<ParserOutput> poList, int valueColumnCount)
	{
		Pattern p=Pattern.compile("[0-9]{1,3}+[,.]{1}+[0-9]{1,3}+\\s");
		Matcher m=null;
		for(ParserOutput po:poList)
		{
			if (po.getMaxCol()==0)
				continue;
			if (pageNo==0)
				pageNo=Integer.valueOf(po.getPageNo());
			String text = po.getLine();
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y"))
			{
				text = po.getRow().getLines().toString();
			}
			m=p.matcher(text);
			if ((text.toUpperCase().indexOf(" TO ")!=-1
					&& text.toUpperCase().indexOf(" FROM ")!=-1) || text.toUpperCase().indexOf(" - ")!=-1
					|| m.find())
			{
				changePeriodsPattern(po);
			}
			else
			{
				String cLine = text;
				if(cLine.indexOf(":")!=-1)
				{
					String cLine1="";
					cLine1=cLine;
					int min=-1;
					int hh=-1;
					//	int sec=-1;
					try {
						hh=Integer.parseInt(cLine1.substring(cLine1.indexOf(":")-2,cLine1.indexOf(":")));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}
					try {
						min=Integer.parseInt(cLine1.substring(0,2));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}
					/*try {
						sec=Integer.parseInt(cLine1.substring(0,2));
						cLine1=cLine1.substring(cLine1.indexOf(":")+1);
					} catch (Exception e) {

						if(logger!=null)
						{						
							logger.info(e.getMessage());
						}
					}*/
					if((hh!=-1 && hh>=0 && hh<=24 && min!=-1 && min>=0 && min<=60 && cLine.indexOf("FOR THE YEAR ENDED")==-1)
							|| (cLine.toUpperCase().indexOf(" AM ")!=-1 || cLine.toUpperCase().indexOf("PM ")!=-1 || cLine.toUpperCase().indexOf(" PAGE ")!=-1))
					{
						continue;
					}
				}
				labelDatePattern(po);

			}
			labelMonths(po);
			labelPeriods(po);
			labelDayYear(po,false);
			labelCurrency(po);
			labelUnits(po);
		}
		return poList;
	}



	public String mapNonEnglishMonths(String month)
	{
		months=attributeMap.get("[Months-Variants]");
		if (months==null)
			return month;
		//StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " ").toUpperCase());
		for (int i=0;i<months.size();i++)
		{
			String[] s = months.get(i).toString().split("##########");
			String key = s[0].trim();
			String variant = s[1];

			if(month.equalsIgnoreCase(variant))
			{
				return key;
			}
		}

		return month;

	}

	@SuppressWarnings("deprecation")
	private String labelDayYear(String temp)
	{
		Matcher matcher=null;
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		
		
		// year
		matcher=year.matcher(text);
		Date dt = new Date();

		while(matcher.find())
		{
			int yr = Integer.parseInt(matcher.group());
			if((dt.getYear()+1900<yr))
			{
				continue;
			}

			if (text.lastIndexOf("<MONTH", matcher.start())!=-1 
					&& !text.toString().substring(0, matcher.start()).endsWith(">")
					&& !text.toString().substring(0, matcher.start()).endsWith(":"))
			{
				int start=matcher.start();
				if (!text.substring(0, start).endsWith("/") && !text.substring(0, start).endsWith("-") )
				{
					if (matcher.group().length()==4 && !matcher.group().startsWith("19") && !matcher.group().startsWith("20"))
						continue;
					text.insert(start+matcher.group().length(), "</YEAR>");
					text.insert(matcher.start(), "<YEAR:"+matcher.group()+">");
					matcher=year.matcher(text);
				}
			} else
			{
				int start=matcher.start();
				if (!text.substring(0, start).endsWith("/") 
						&& !text.substring(0, start).endsWith("-")
						&& !text.substring(0, start).endsWith(":")
						&& !text.substring(0, start).endsWith(">")
						&& !text.substring(0, start).endsWith(","))
				{
					if (matcher.group().length()==4 && !matcher.group().startsWith("19") && !matcher.group().startsWith("20"))
						continue;
					text.insert(start+matcher.group().length(), "</YEAR>");
					text.insert(matcher.start(), "<YEAR:"+matcher.group()+">");
					matcher=year.matcher(text);
				}
			}
		}



		// day
		matcher=day.matcher(text);
		while(matcher.find())
		{
			if (((text.lastIndexOf("<MONTH", matcher.start())!=-1 || text.indexOf("<MONTH", matcher.start())!=-1 ) && text.toString().substring(matcher.start()).trim().indexOf("<YEAR")!=-1)
					&& !text.toString().substring(0, matcher.start()).trim().endsWith(":"))
			{
				int start=matcher.start()+matcher.group().length();
				if (text.substring(0, start).endsWith(",") || text.substring(0, start).endsWith(" "))
					start--;
				text.insert(start, "</DAY>");
				text.insert(matcher.start(), "<DAY:"+matcher.group().replaceAll("[^0-9]", "")+">");
				matcher=day.matcher(text);
			}
		}
		if (text.indexOf("<DAY")==-1) {
			int index=text.indexOf("</MONTH>");
			if (index!=-1)
			{
				index+="</MONTH>".length();
				Pattern p=Pattern.compile("[0-9]{1,2}");
				Matcher m=p.matcher(text);
				if (m.find(index)) {
					int start=m.start();
					if (!text.substring(0, start).endsWith("/") 
							&& !text.substring(0, start).endsWith("-")
							&& !text.substring(0, start).endsWith(":")
							&& !text.substring(0, start).endsWith(">")
							&& !text.substring(0, start).endsWith(","))	{
						start=start+m.group().length();
						text.insert(start, "</DAY>");
						text.insert(m.start(), "<DAY:"+m.group().replaceAll("[^0-9]", "")+">");
					}
				}
				else
				{

					index=text.indexOf("<MONTH:");
					if(index!=-1)
					{
						m=day.matcher(text.substring(0,index));
						if (m.find()) {
							int start=m.start();
							if (!text.substring(0, start).endsWith("/") 
									&& !text.substring(0, start).endsWith("-")
									&& !text.substring(0, start).endsWith(":")
									&& !text.substring(0, start).endsWith(">")
									&& !text.substring(0, start).endsWith(","))	{
								start=start+m.group().length();
								text.insert(start, "</DAY>");
								text.insert(m.start(), "<DAY:"+m.group().replaceAll("[^0-9]", "")+">");
							}
						}
					}
				}
			}
		}
		return text.toString();
	}


	@SuppressWarnings("deprecation")
	private String labelDayYear(ParserOutput po,Boolean isYearFound)
	{
		Matcher matcher=null;
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		// year


		if(!isYearFound)
		{
			matcher=year.matcher(text);
			Date dt = new Date();
			while(matcher.find())
			{
				int yr = Integer.parseInt(matcher.group());
				if((dt.getYear()+1900<yr))
				{
					continue;
				}

				if (text.lastIndexOf("<MONTH", matcher.start())!=-1 
						&& !text.toString().substring(0, matcher.start()).endsWith(">")
						&& !text.toString().substring(0, matcher.start()).endsWith(":"))
				{
					int start=matcher.start();
					if (!text.substring(0, start).endsWith("/") && !text.substring(0, start).endsWith("-") )
					{
						if (matcher.group().length()==4 && !matcher.group().startsWith("19") && !matcher.group().startsWith("20"))
							continue;
						text.insert(start+matcher.group().length(), "</YEAR>");
						text.insert(matcher.start(), "<YEAR:"+matcher.group()+">");
						matcher=year.matcher(text);
					}
				} else
				{
					int start=matcher.start();
					if (!text.substring(0, start).endsWith("/") 
							&& !text.substring(0, start).endsWith("-")
							&& !text.substring(0, start).endsWith(":")
							&& !text.substring(0, start).endsWith(">")
							&& !text.substring(0, start).endsWith(","))
					{
						if (matcher.group().length()==4 && !matcher.group().startsWith("19") && !matcher.group().startsWith("20"))
							continue;
						text.insert(start+matcher.group().length(), "</YEAR>");
						text.insert(matcher.start(), "<YEAR:"+matcher.group()+">");
						matcher=year.matcher(text);
					}
				}
			}
		}


		// day
		matcher=day.matcher(text);
		while(matcher.find())
		{
			if (((text.lastIndexOf("<MONTH", matcher.start())!=-1 || text.indexOf("<MONTH", matcher.start())!=-1 ) && text.toString().substring(matcher.start()).trim().indexOf("<YEAR")!=-1)
					&& !text.toString().substring(0, matcher.start()).trim().endsWith(":"))
			{
				int start=matcher.start()+matcher.group().length();
				if (text.substring(0, start).endsWith(",") || text.substring(0, start).endsWith(" "))
					start--;
				text.insert(start, "</DAY>");
				text.insert(matcher.start(), "<DAY:"+matcher.group().replaceAll("[^0-9]", "")+">");
				matcher=day.matcher(text);
			}
		}
		if (text.indexOf("<DAY")==-1) {
			int index=text.indexOf("</MONTH>");
			if (index!=-1)
			{
				index+="</MONTH>".length();
				//	Pattern p=Pattern.compile("[0-9]{1,2}");
				Matcher m=day.matcher(text);
				if (m.find(index)) {
					int start=m.start();
					if (!text.substring(0, start).endsWith("/") 
							&& !text.substring(0, start).endsWith("-")
							&& !text.substring(0, start).endsWith(":")
							&& !text.substring(0, start).endsWith(">")
							&& !text.substring(0, start).endsWith(","))	{
						start=start+m.group().length();
						text.insert(start, "</DAY>");
						text.insert(m.start(), "<DAY:"+m.group().replaceAll("[^0-9]", "")+">");
					}
				}
				else
				{

					index=text.indexOf("<MONTH:");
					if(index!=-1)
					{
						//	Pattern p=Pattern.compile("[0-9]{1,2}");
						m=day.matcher(text.substring(0,index));
						if (m.find()) {
							int start=m.start();
							if (!text.substring(0, start).endsWith("/") 
									&& !text.substring(0, start).endsWith("-")
									&& !text.substring(0, start).endsWith(":")
									&& !text.substring(0, start).endsWith(">")
									&& !text.substring(0, start).endsWith(","))	{
								start=start+m.group().length();
								text.insert(start, "</DAY>");
								text.insert(m.start(), "<DAY:"+m.group().replaceAll("[^0-9]", "")+">");
							}
						}
					}


				}

			}

		}
		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}



	private String labelMonths(String temp)
	{
		if (attributeMap==null)
			return "";
		months=attributeMap.get("[Months-Variants]");
		if (months==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " ").toUpperCase());
		for (int i=0;i<months.size();i++)
		{
			String[] s = months.get(i).toString().split("##########");
			//String key = s[0];
			String variant = s[1];

			int index=text.toString().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") 
					&& !text.substring(0, index).trim().endsWith(":"))
			{
				int wordInd=text.toString().indexOf(" ", index);
				if (wordInd!=-1 && (text.toString().substring(index, wordInd).trim().equalsIgnoreCase(variant)
						|| text.toString().substring(index).trim().equalsIgnoreCase(variant))
						&& !text.toString().substring(index, wordInd).trim().startsWith("-")) 
				{
					if (text.toString().toLowerCase().substring(wordInd).trim().startsWith("through") ||
							text.toString().toLowerCase().substring(wordInd).trim().startsWith("-"))
						continue;

					text.insert(wordInd, "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");
				}
				else
				{
					text.insert(index+variant.length(), "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");	
				}
			} else if (index!=-1){
				int wordInd=text.toString().indexOf(" ", index);
				if (wordInd!=-1 && text.toString().substring(index, wordInd).trim().equalsIgnoreCase(variant)) {
					text.insert(wordInd, "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");
					continue;
				}
			}

		}

		return text.toString();
	}

	private String labelMonths(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		months=attributeMap.get("[Months-Variants]");
		if (months==null)
			return "";
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " ").toUpperCase());

		for (int i=0;i<months.size();i++)
		{
			String[] s = months.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];

			int index=text.toString().indexOf(variant.toUpperCase());
			if(index==-1)
			{
				variant = s[0];
				index=text.toString().indexOf(variant.toUpperCase());
			}
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") 
					&& !text.substring(0, index).trim().endsWith(":"))
			{
				int wordInd=text.toString().indexOf(" ", index);
				if (wordInd!=-1 && (text.toString().substring(index, wordInd).trim().equalsIgnoreCase(variant)
						|| text.toString().substring(index).trim().equalsIgnoreCase(variant))
						&& !text.toString().substring(index, wordInd).trim().startsWith("-") && po.getLineNo()<=11) 
				{
					if (text.toString().toLowerCase().substring(wordInd).trim().startsWith("through") ||
							text.toString().toLowerCase().substring(wordInd).trim().startsWith("-"))
						continue;

					text.insert(wordInd, "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");
				}
				else
				{
					text.insert(index+variant.length(), "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");	
				}
			} else if (index!=-1){
				int wordInd=text.toString().indexOf(" ", index);
				if (wordInd!=-1 && text.toString().substring(index, wordInd).trim().equalsIgnoreCase(variant)) {
					text.insert(wordInd, "</MONTH>");
					text.insert(index, "<MONTH:"+variant.trim()+">");
					continue;
				}
			}

		}

		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}

	private String labelPeriods(String temp)
	{
		if (attributeMap==null)
			return "";
		periods=attributeMap.get("[Periods]");
		if (periods==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		for (int i=0;i<periods.size();i++)
		{
			String[] s = periods.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];

			int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 /*&& !text.substring(0, index).trim().endsWith(">") */&& !text.substring(0, index).trim().endsWith(":") &&  !text.toString().contains("<PERIOD:"))
				text.insert(index, "<PERIOD:"+key.trim()+">");

		}
		return text.toString();
	}

	private String labelCurrency(String temp)
	{
		if (attributeMap==null)
			return "";
		currencies=attributeMap.get("[Currency]");
		if (currencies==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));

		for (int i=0;i<currencies.size();i++)
		{
			String[] s = currencies.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];
			//Added New
			int index = -1;
			String lines[] = text.toString().split("\\s");
			for(int j=0;j<lines.length;j++)
			{
				if(lines[j].trim().equalsIgnoreCase(variant))
				{
					index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
					break;
				}
			}
			//Added New

			//int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") && !text.substring(0, index).trim().endsWith(":") && !text.toString().contains("<CURRENCY:"))
				text.insert(index, "<CURRENCY:"+key.trim()+">");
		}

		return text.toString();
	}



	private String labelPeriods(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		periods=attributeMap.get("[Periods]");
		if (periods==null)
			return "";
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		for (int i=0;i<periods.size();i++)
		{
			String[] s = periods.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];

			int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") && !text.substring(0, index).trim().endsWith(":") && !text.toString().contains("<PERIOD:"))
				text.insert(index, "<PERIOD:"+key.trim()+">");

		}
		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}

	private String labelCurrency(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		currencies=attributeMap.get("[Currency]");
		if (currencies==null)
			return "";
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));

		for (int i=0;i<currencies.size();i++)
		{
			String[] s = currencies.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];
			//Added New
			int index = -1;
			String lines[] = text.toString().split("\\s");
			for(int j=0;j<lines.length;j++)
			{
				if(lines[j].trim().equalsIgnoreCase(variant) || lines[j].trim().contains(variant))
				{
					index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
					break;
				}
			}
			//Added New

			//int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") && !text.substring(0, index).trim().endsWith(":")  && !text.toString().contains("<CURRENCY:"))
				text.insert(index, "<CURRENCY:"+key.trim()+">");
		}

		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}

	private String labelUnits(String temp)
	{
		if (attributeMap==null)
			return "";
		units=attributeMap.get("[Units]");
		if (units==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));

		for (int i=0;i<units.size();i++)
		{
			String[] s = units.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];
			int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") && !text.substring(0, index).trim().endsWith(":") &&  !text.toString().contains("<UNITS:"))
				text.insert(index, "<UNITS:"+key.trim()+">");
		}

		return text.toString();
	}

	private String labelUnits(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		units=attributeMap.get("[Units]");
		if (units==null)
			return "";
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));

		for (int i=0;i<units.size();i++)
		{
			String[] s = units.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];
			int index=text.toString().toUpperCase().indexOf(variant.toUpperCase());
			if (index!=-1 && !text.substring(0, index).trim().endsWith(">") && !text.substring(0, index).trim().endsWith(":") && !text.toString().contains("<UNITS:"))
			{
				text.insert(index, "<UNITS:"+key.trim()+">");
				break;
			}
		}

		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}


	private String labelDatePattern(ParserOutput po)
	{
		if (attributeMap==null)
			return "";
		dates=attributeMap.get("[Date-Patterns]");
		if (dates==null)
			return "";
		String temp=po.getLine().replaceAll("\t", "    ");
		if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && !po.getLine().contains("<") && !po.getLine().contains(">"))
		{
			temp = po.getRow().getLines().toString().replaceAll("\t", "    ");;
		}
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));

		Pattern pattern=null;

		for (int i=0;i<dates.size();i++)
		{
			String[] s = dates.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];

			if(text.length()>300)
				break;

			pattern=Pattern.compile(variant,Pattern.CASE_INSENSITIVE);
			matcher=pattern.matcher(text);
			int strt = 0;
			while (matcher.find())
			{

			/*	if (matcher.start()==0)
					continue;*/
				int start=matcher.start()+matcher.group().length()+strt;
			/*	if (start==0)
					continue;*/
				if (!text.toString().substring(0, matcher.start()).endsWith(">") && !text.toString().startsWith("<DATE:") && !text.toString().endsWith(">")
						&& !text.toString().substring(0, matcher.start()).endsWith(":"))
				{
					text.insert(start, "</DATE>");
					String val=matcher.group();
					String date = parseDate(key, val);
					text.insert(matcher.start()+strt,"<DATE:"+date+">");
					String dt = changeDatePattern(date);
					if(!dt.equalsIgnoreCase("-1, -1"))
					{
						text.insert(matcher.start()+strt,dt);
						strt = strt+matcher.start()+val.length()+date.length()+14+dt.length();
					}
					else
						strt = strt+matcher.start()+val.length()+date.length()+14;
					matcher=pattern.matcher(text.toString().substring(strt));

				}
			}

		}
		if(!temp.replaceAll("\\s\\s+", " ").trim().equalsIgnoreCase(text.toString().trim()))
			po.setLine(text.toString());
		return text.toString();
	}


	private String labelDatePattern(String temp)
	{
		if (attributeMap==null)
			return "";
		dates=attributeMap.get("[Date-Patterns]");
		if (dates==null)
			return "";
		StringBuffer text=new StringBuffer(temp.replaceAll("\\s\\s+", " "));
		Pattern pattern=null;

		for (int i=0;i<dates.size();i++)
		{
			String[] s = dates.get(i).toString().split("##########");
			String key = s[0];
			String variant = s[1];

			if(temp.length()>300)
				break;

			pattern=Pattern.compile(variant,Pattern.CASE_INSENSITIVE);
			matcher=pattern.matcher(text);
			int strt = 0;
			while (matcher.find())
			{

				int start=matcher.start()+matcher.group().length()+strt;
				if (start==0)
					continue;
				if (!text.toString().substring(0, matcher.start()).endsWith(">") && !text.toString().startsWith("<DATE:") && !text.toString().endsWith(">")
						&& !text.toString().substring(0, matcher.start()).endsWith(":"))
				{
					text.insert(start, "</DATE>");
					String val=matcher.group();
					String date = parseDate(key, val);
					text.insert(matcher.start()+strt,"<DATE:"+date+">");
					String dt = changeDatePattern(date);
					if(!dt.equalsIgnoreCase("-1, -1"))
					{
						text.insert(matcher.start()+strt,dt);
						strt = strt+matcher.start()+val.length()+date.length()+14+dt.length();
					}
					else
						strt = strt+matcher.start()+val.length()+date.length()+14;
					matcher=pattern.matcher(text.toString().substring(strt));

				}
			}

		}
		return text.toString();
	}

	public boolean read() throws Exception
	{
		if(attributeMap!=null)
			return true;
		String file = "";
		if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
		{
			//file=Constants.getProperty("attribute.meta");
			file = "resource/section-identification/AttributesMeta.txt";
		}
		else
		{
			//file=Constants.getProperty(FinancialStatementExtractor.getLanguage().trim()+".attribute.meta");
			//file = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+ " - AttributesMeta.properties";

			file = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+ "/AttributesMeta.txt";
		}




		try {
			new SafeFile(file);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(file);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		/*if (file==null)
		{
			System.err.println("AttributesMeta.txt missing");
			return false;
		}*/
		//	BufferedReader br=new BufferedReader(new FileReader(file));
		BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(file), "UTF-8"));

		String line="";
		ArrayList<String> synonymList=null;
		String section="";
		while((line=br.readLine())!=null)
		{
			line = AccentsRemover.removeAccents(line.trim());
			if (line.trim().length()==0 || line.trim().startsWith("#"))
				continue;
			if (line.trim().startsWith("[") && line.trim().endsWith("]"))
			{
				if (attributeMap==null)
					attributeMap=new LinkedHashMap<String, ArrayList<String>>();
				synonymList=new ArrayList<String>();
				if (!attributeMap.containsKey(line.trim()))
				{
					attributeMap.put(line.trim(), synonymList);
					section=line.trim();
				}
				continue;
			}
			String[] map=line.trim().split("\t");
			if (map.length==2)
			{
				if(section.equalsIgnoreCase("[Date-Patterns]"))
					synonymList.add(map[0]+"##########"+map[1]);
				else
				{
					String[] newArr=map[1].split("\\|");
					if (newArr.length>0)
					{
						for(int i=0;i<newArr.length;i++)
						{
							synonymList.add(map[0]+"##########"+newArr[i]);
						}
					}
				}
			}
			else
				if (map.length==1)
				{
					synonymList.add(line.trim());
				}
		}
		br.close();
		return true;
	}




	public ArrayList<ParserOutput> getStatementAttributes(List<ParserOutput> list, String section, int valueColumnCount,int pageNo,TreeSet<Integer> columns, String statementQuality)
	{
		markStatementAttributes(list, valueColumnCount);
		return prepare(parseAttributes(list), section, valueColumnCount,pageNo,"N",list,columns, statementQuality,1);
	}

	public ArrayList<ParserOutput> getStatementColumnAttributes(List<ParserOutput> colList, List<ParserOutput> poList,String section, int valueColumnCount,int pageNo,TreeSet<Integer> columns, String statementQuality)
	{
		markStatementAttributes(colList);
		TreeMap<Integer, Map<String, ArrayList<String>>> attrColMap = parseColumnAttributes(colList,section,pageNo,valueColumnCount);
		return getAttributes(colList, section,	pageNo, attrColMap,poList,columns,statementQuality);
	}


	private TreeMap<Integer,Map<String, ArrayList<String>>> parseColumnAttributes(List<ParserOutput> list,String section,int pageNo, int valueColumnCount)
	{
		Map<String, ArrayList<String>> attrMap=new HashMap<String, ArrayList<String>>();
		TreeMap<Integer,Map<String, ArrayList<String>>> attrColMap = new TreeMap<Integer,Map<String, ArrayList<String>>>();
		ArrayList<String> attrList=null;
		Pattern pattern=null;
		String regex="<"+"(.*?)"+">";
		pattern=Pattern.compile(regex);

		for(ParserOutput po:list)
		{
			if(po.getMaxCol()<2)
				continue;
			if (!(po.getAsRepVal1()==null || (po.getAsRepVal1().indexOf("<")==-1 && po.getAsRepVal1().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal1());
				if(!attrColMap.containsKey(1))
				{
					attrColMap.put(1, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(1);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(1, attrMap);
					}
				}

			}
			if(po.getMaxCol()<3)
				continue;
			if (!(po.getAsRepVal2()==null || (po.getAsRepVal2().indexOf("<")==-1 && po.getAsRepVal2().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal2());
				if(!attrColMap.containsKey(2))
				{
					attrColMap.put(2, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(2);
					for(String str :thisAttrMap.keySet())
					{
						ArrayList<String> lst = thisAttrMap.get(str);
						if(!attrMap.containsKey(str))
						{
							attrMap.put(str, lst);
						}
						else
						{
							ArrayList<String> thisLst  = attrMap.get(str);
							thisLst.addAll(lst);
							attrMap.put(str, thisLst);
						}

					}
					attrColMap.put(2, attrMap);
				}			}
			if(po.getMaxCol()<4)
				continue;
			if (!(po.getAsRepVal3()==null || (po.getAsRepVal3().indexOf("<")==-1 && po.getAsRepVal3().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal3());
				if(!attrColMap.containsKey(3))
				{
					attrColMap.put(3, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(3);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(3, attrMap);
					}
				}
			}
			if(po.getMaxCol()<5)
				continue;
			if (!(po.getAsRepVal4()==null || (po.getAsRepVal4().indexOf("<")==-1 && po.getAsRepVal4().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal4());
				if(!attrColMap.containsKey(4))
				{
					attrColMap.put(4, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(4);
					for(String str :thisAttrMap.keySet())
					{
						ArrayList<String> lst = thisAttrMap.get(str);
						if(!attrMap.containsKey(str))
						{
							attrMap.put(str, lst);
						}
						else
						{
							ArrayList<String> thisLst  = attrMap.get(str);
							thisLst.addAll(lst);
							attrMap.put(str, thisLst);
						}
					}
					attrColMap.put(4, attrMap);
				}
			}
			if(po.getMaxCol()<6)
				continue;
			if (!(po.getAsRepVal5()==null || (po.getAsRepVal5().indexOf("<")==-1 && po.getAsRepVal5().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal5());
				if(!attrColMap.containsKey(5))
				{
					attrColMap.put(5, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(5);
					for(String str :thisAttrMap.keySet())
					{
						ArrayList<String> lst = thisAttrMap.get(str);
						if(!attrMap.containsKey(str))
						{
							attrMap.put(str, lst);
						}
						else
						{
							ArrayList<String> thisLst  = attrMap.get(str);
							thisLst.addAll(lst);
							attrMap.put(str, thisLst);
						}
					}
					attrColMap.put(5, attrMap);
				}
			}
			if(po.getMaxCol()<7)
				continue;
			if (!(po.getAsRepVal6()==null || (po.getAsRepVal6().indexOf("<")==-1 && po.getAsRepVal6().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal6());
				if(!attrColMap.containsKey(6))
				{
					attrColMap.put(6, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(6);
					for(String str :thisAttrMap.keySet())
					{
						ArrayList<String> lst = thisAttrMap.get(str);
						if(!attrMap.containsKey(str))
						{
							attrMap.put(str, lst);
						}
						else
						{
							ArrayList<String> thisLst  = attrMap.get(str);
							thisLst.addAll(lst);
							attrMap.put(str, thisLst);
						}
					}
					attrColMap.put(6, attrMap);
				}
			}
			if(po.getMaxCol()<8)
				continue;
			if (!(po.getAsRepVal7()==null || (po.getAsRepVal7().indexOf("<")==-1 && po.getAsRepVal7().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal7());
				if(!attrColMap.containsKey(7))
				{
					attrColMap.put(7, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(7);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(7, attrMap);
					}
				}
			}
			if(po.getMaxCol()<9)
				continue;
			if (!(po.getAsRepVal8()==null || (po.getAsRepVal8().indexOf("<")==-1 && po.getAsRepVal8().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal8());
				if(!attrColMap.containsKey(8))
				{
					attrColMap.put(8, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(8);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(8, attrMap);
					}
				}
			}
			if(po.getMaxCol()<10)
				continue;
			if (!(po.getAsRepVal9()==null || (po.getAsRepVal9().indexOf("<")==-1 && po.getAsRepVal9().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal9());
				if(!attrColMap.containsKey(9))
				{
					attrColMap.put(9, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(9);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(9, attrMap);
					}
				}
			}
			if(po.getMaxCol()<11)
				continue;
			if (!(po.getAsRepVal10()==null || (po.getAsRepVal10().indexOf("<")==-1 && po.getAsRepVal10().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal10());
				if(!attrColMap.containsKey(10))
				{
					attrColMap.put(10, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(10);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(10, attrMap);
					}
					else
					{
						System.out.print("");
					}
				}
			}

			if(po.getMaxCol()<12)
				continue;
			if (!(po.getAsRepVal11()==null || (po.getAsRepVal11().indexOf("<")==-1 && po.getAsRepVal11().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal11());
				if(!attrColMap.containsKey(1))
				{
					attrColMap.put(11, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(11);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}

						attrColMap.put(11, attrMap);
					}
				}

			}
			if(po.getMaxCol()<13)
				continue;
			if (!(po.getAsRepVal12()==null || (po.getAsRepVal12().indexOf("<")==-1 && po.getAsRepVal12().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal2());
				if(!attrColMap.containsKey(12))
				{
					attrColMap.put(12, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(12);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}

						}
						attrColMap.put(12, attrMap);
					}
				}			}
			if(po.getMaxCol()<4)
				continue;
			if (!(po.getAsRepVal13()==null || (po.getAsRepVal13().indexOf("<")==-1 && po.getAsRepVal13().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal13());
				if(!attrColMap.containsKey(13))
				{
					attrColMap.put(13, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(13);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(13, attrMap);
					}
				}
			}
			if(po.getMaxCol()<15)
				continue;
			if (!(po.getAsRepVal14()==null || (po.getAsRepVal14().indexOf("<")==-1 && po.getAsRepVal14().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal14());
				if(!attrColMap.containsKey(14))
				{
					attrColMap.put(14, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(14);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(14, attrMap);
					}
				}
			}
			if(po.getMaxCol()<16)
				continue;
			if (!(po.getAsRepVal15()==null || (po.getAsRepVal15().indexOf("<")==-1 && po.getAsRepVal15().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal15());
				if(!attrColMap.containsKey(15))
				{
					attrColMap.put(15, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(15);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(15, attrMap);
					}
				}
			}
			if(po.getMaxCol()<17)
				continue;
			if (!(po.getAsRepVal16()==null || (po.getAsRepVal16().indexOf("<")==-1 && po.getAsRepVal16().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal16());
				if(!attrColMap.containsKey(16))
				{
					attrColMap.put(16, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(16);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(16, attrMap);
					}
				}
			}
			if(po.getMaxCol()<18)
				continue;
			if (!(po.getAsRepVal17()==null || (po.getAsRepVal17().indexOf("<")==-1 && po.getAsRepVal17().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal17());
				if(!attrColMap.containsKey(17))
				{
					attrColMap.put(17, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(17);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(17, attrMap);
					}
				}
			}
			if(po.getMaxCol()<19)
				continue;
			if (!(po.getAsRepVal18()==null || (po.getAsRepVal18().indexOf("<")==-1 && po.getAsRepVal18().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal18());
				if(!attrColMap.containsKey(18))
				{
					attrColMap.put(18, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(18);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(18, attrMap);
					}
				}
			}
			if(po.getMaxCol()<20)
				continue;
			if (!(po.getAsRepVal19()==null || (po.getAsRepVal19().indexOf("<")==-1 && po.getAsRepVal19().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal19());
				if(!attrColMap.containsKey(19))
				{
					attrColMap.put(19, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(19);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(19, attrMap);
					}
				}
			}
			if(po.getMaxCol()<21)
				continue;
			if (!(po.getAsRepVal20()==null || (po.getAsRepVal20().indexOf("<")==-1 && po.getAsRepVal20().indexOf(">")==-1)))
			{		
				attrMap=new HashMap<String, ArrayList<String>>();
				checkPatterns(attrMap, attrList, pattern, po.getAsRepVal3());
				if(!attrColMap.containsKey(20))
				{
					attrColMap.put(20, attrMap);
				}
				else
				{
					Map<String, ArrayList<String>> thisAttrMap = attrColMap.get(20);
					if(thisAttrMap!=null)
					{
						for(String str :thisAttrMap.keySet())
						{
							ArrayList<String> lst = thisAttrMap.get(str);
							if(!attrMap.containsKey(str))
							{
								attrMap.put(str, lst);
							}
							else
							{
								ArrayList<String> thisLst  = attrMap.get(str);
								thisLst.addAll(lst);
								attrMap.put(str, thisLst);
							}
						}
						attrColMap.put(20, attrMap);
					}
				}
			}

		}

		if(valueColumnCount>attrColMap.size())
		{
			for(int k=1;k<valueColumnCount;k++)
			{
				if(!attrColMap.containsKey(k))
				{
					attrColMap.put(k, new HashMap<String, ArrayList<String>>());
				}
			}
		}

		return attrColMap;
	}

	private ArrayList<ParserOutput> getAttributes(
			List<ParserOutput> list, String section, int pageNo,
			TreeMap<Integer, Map<String, ArrayList<String>>> attrColMap, List<ParserOutput> allList,TreeSet<Integer> columns, String statementQuality) {
		TreeMap<Integer,ArrayList<ParserOutput>> poMap = new TreeMap<Integer,ArrayList<ParserOutput>>();
		for(Integer  colNo:attrColMap.keySet())
		{
			Map<String, ArrayList<String>>  attrMapCol = attrColMap.get(colNo);
			if(attrMapCol.size()>0)
				poMap.put(colNo, prepare(attrMapCol, section, 1,pageNo, "Y",allList,columns,statementQuality,1));
		}
		Map<String, ArrayList<String>>  attrMaps = new HashMap<String, ArrayList<String>>();
		for(Integer  colNo:poMap.keySet())
		{
			ArrayList<ParserOutput> poList= poMap.get(colNo);

			if(attrMaps.size()>0 & poList.size()==0)
			{
				for(String asRepLabel :attrMaps.keySet())
				{
					ArrayList<String> aList = attrMaps.get(asRepLabel);
					aList.add(null);
					attrMaps.put(asRepLabel, aList);
				} 
			}
			for(ParserOutput po : poList)
			{
				String asrepLabel = po.getAsRepLabel();
				if(!((asrepLabel!=null && asrepLabel.startsWith("STATEMENT")) || (asrepLabel==null)))
					continue;
				if(asrepLabel!=null && asrepLabel.startsWith("STATEMENT") && ! attrMaps.containsKey(asrepLabel))
				{
					ArrayList<String> lst = new ArrayList<String>();
					if(lst.size()<colNo)
					{
						for(int k=1;k<colNo;k++)
						{
							lst.add(null);
						}
					}
					lst.add(po.getValue1());
					attrMaps.put(asrepLabel,lst);
				}
				else
					if( attrMaps.containsKey(po.getAsRepLabel()))
					{
						ArrayList<String> lst = attrMaps.get(asrepLabel);
						if(lst.size()<colNo)
						{
							for(int k=lst.size()+1;k<colNo;k++)
							{
								lst.add(null);
							}
						}
						lst.add(po.getValue1());
						attrMaps.put(asrepLabel,lst);
					}


			}

		}

		ArrayList<ParserOutput> poList = new ArrayList<ParserOutput>();
		int lineNo=-8;
		for(String label:attrMaps.keySet())
		{
			ParserOutput po = new ParserOutput();
			po.setAsRepLabel(label);
			if(label.contains("STATEMENT YEAR"))
			{
				lineNo = -8;
			}

			if(label.contains("STATEMENT MONTH"))
			{
				lineNo = -7;
			}
			if(label.contains("STATEMENT DATE"))
			{
				lineNo = -6;
			}
			if(label.contains("STATEMENT PERIOD"))
			{
				lineNo = -5;
			}
			if(label.contains("STATEMENT CURRENCY"))
			{
				lineNo = -4;
			}
			if(label.contains("STATEMENT UNITS"))
			{
				lineNo = -3;
			}
			if(label.contains("STATEMENT FOR"))
			{
				lineNo = -2;
			}
			if(label.contains("STATEMENT QUALITY"))
			{
				lineNo = -1;
			}

			ArrayList<String> values = attrMaps.get(label);
			for(int i=0;i<values.size();i++)
			{
				String value = values.get(i);
				switch(i)
				{
				case 0:{
					po.setAsRepVal1(value);
					po.setValue1(value);
					break;
				}
				case 1:{
					po.setAsRepVal2(value);
					po.setValue2(value);
					break;
				}
				case 2:{
					po.setAsRepVal3(value);
					po.setValue3(value);
					break;
				}
				case 3:{
					po.setAsRepVal4(value);
					po.setValue4(value);
					break;
				}
				case 4:{
					po.setAsRepVal5(value);
					po.setValue5(value);
					break;
				}
				case 5:{
					po.setAsRepVal6(value);
					po.setValue6(value);
					break;
				}
				case 6:{
					po.setAsRepVal7(value);
					po.setValue7(value);
					break;
				}
				case 7:{
					po.setAsRepVal8(value);
					po.setValue8(value);
					break;
				}
				case 8:{
					po.setAsRepVal9(value);
					po.setValue9(value);
					break;
				}
				case 9:{
					po.setAsRepVal10(value);
					po.setValue10(value);
					break;
				}
				case 10:{
					po.setAsRepVal11(value);
					po.setValue11(value);
					break;
				}
				}

			}
			po.setPageNo(pageNo);
			po.setSection(section);
			po.setLineNo(lineNo);
			po.setSubSection("ATTR");
			po.setType("ATTR");
			po.setMaxCol(values.size()+1);
			poList.add(po);
		}
		return poList;
	}

	private void checkPatterns(Map<String, ArrayList<String>> attrMap,
			ArrayList<String> attrList, Pattern pattern, String text) {
		matcher=pattern.matcher(text);
		while(matcher.find())
		{
			String[] temp=new String[]{matcher.group()};
			temp=temp[0].substring(1, temp[0].length()-1).split(":");
			if (temp[0].startsWith("/"))
				continue;
			if (!attrMap.containsKey(temp[0]))
				attrMap.put(temp[0], new ArrayList<String>());
			attrList=attrMap.get(temp[0]);
			int twoMonth=text.toLowerCase().indexOf(" through ");
			if (twoMonth!=-1 && twoMonth>matcher.start())
				continue;
			twoMonth=text.toLowerCase().indexOf(" to ");
			if (twoMonth!=-1 && twoMonth>matcher.start())
				continue;
			if(temp[0].equals("YEAR") && !attrList.contains(temp[1]))
				attrList.add(temp[1]);
			if(!temp[0].equals("YEAR") && temp.length>1) 
				attrList.add(temp[1]);
		}

	}

	private Map<String, ArrayList<String>> parseAttributes(List<ParserOutput> list)
	{
		Map<String, ArrayList<String>> attrMap=new HashMap<String, ArrayList<String>>();
		ArrayList<String> attrList=null;
		Pattern pattern=null;
		for(ParserOutput po:list)
		{
			if (po.getLine()==null ||(po.getLine().indexOf("<")==-1 && po.getLine().indexOf(">")==-1) /*|| (po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y"))*/)
				continue;
			String regex="<"+"(.*?)"+">";
			pattern=Pattern.compile(regex);
			matcher=pattern.matcher(po.getLine());
			while(matcher.find())
			{
				String[] temp=new String[]{matcher.group()};
				temp=temp[0].substring(1, temp[0].length()-1).split(":");
				if (temp[0].startsWith("/"))
					continue;
				if (!attrMap.containsKey(temp[0]))
					attrMap.put(temp[0], new ArrayList<String>());
				attrList=attrMap.get(temp[0]);
				int twoMonth=po.getLine().toLowerCase().indexOf(" through ");
				if (twoMonth!=-1 && twoMonth>matcher.start())
					continue;
				twoMonth=po.getLine().toLowerCase().indexOf(" to ");
				if (twoMonth!=-1 && twoMonth>matcher.start())
					continue;
				if(temp[0].equals("YEAR") && !attrList.contains(temp[1]))
					attrList.add(temp[1]);
				if(!temp[0].equals("YEAR") && temp.length>1) 
					attrList.add(temp[1]);

			}
		}
		return attrMap;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}


}



