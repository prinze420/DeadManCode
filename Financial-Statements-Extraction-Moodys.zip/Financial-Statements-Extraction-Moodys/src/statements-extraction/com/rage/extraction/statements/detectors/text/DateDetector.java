package com.rage.extraction.statements.detectors.text;

public class DateDetector 
{
	private static String REGEX_DATE = "[1-9]|1[0-9]|2[0-9]|3[0-1]" ;
	
	private static String REGEX_YEAR_SHORT = "0[0-9]|1[0-9]" ;
	private static String REGEX_YEAR_LONG = "200[0-9]|201[0-9]" ;
	private static String REGEX_YEAR = "(" + REGEX_YEAR_SHORT + ")|(" + REGEX_YEAR_LONG + ")" ;
	
	private static String REGEX_MONTH_LONG = "january|february|march|april|may|june|july|august|september|october|november|december" ;
	private static String REGEX_MONTH_SHORT = "jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec" ;
	private static String REGEX_MONTH_NUMBER = "0[1-9]|1[0-2]" ;
	private static String REGEX_MONTH = "(" + REGEX_MONTH_LONG + ")|(" + REGEX_MONTH_NUMBER + ")|(" + REGEX_MONTH_SHORT + ")" ;
	
	private static String DATE_REGEX_1 = "(" + REGEX_MONTH + ")\\s+(" + REGEX_DATE + "),\\s*(" + REGEX_YEAR + ")" ;
	private static String DATE_REGEX_2 = "(" + REGEX_MONTH + ")(,)*\\s+(" + REGEX_YEAR + ")" ;
	private static String DATE_REGEX_3 = "(" + REGEX_MONTH + ")\\s*\\-\\s*(" + REGEX_MONTH + ")(,)*\\s*(" + REGEX_YEAR + ")" ;
	private static String DATE_REGEX_4 = "(" + REGEX_DATE + ")\\s*\\.\\s*(" + REGEX_MONTH + ").\\s*(" + REGEX_YEAR + ")" ;
	private static String DATE_REGEX_5 = "(" + REGEX_MONTH + ")\\s*\\.\\s*(" + REGEX_DATE + ").\\s*(" + REGEX_YEAR + ")" ;

	private static String DATE_REGEX = "(" + DATE_REGEX_1 + ")|(" + DATE_REGEX_2 +")|(" + DATE_REGEX_3 + ")|(" + DATE_REGEX_4 + ")|(" + DATE_REGEX_5 + ")" ;
	
	public static boolean isDate(String input)
	{
		if ( input==null || input.trim().equalsIgnoreCase("") )
			return false ;
		
		if ( input.toLowerCase().trim().replaceAll(DATE_REGEX, "").trim().equalsIgnoreCase("") )
			return true ;
		
		return false ;
	}
	
	static boolean isLongYear(String input)
	{
		if ( input.trim().equalsIgnoreCase("") )
			return false ;
		
		if ( input.toLowerCase().trim().replaceAll(REGEX_YEAR_LONG, "").trim().equalsIgnoreCase("") )
			return true ;
		
		return false ;
	}
	
	public static void main(String[] args) 
	{
		String input = "31.12.2015" ;
		
		System.out.println(isDate(input)) ;
	}
}
