package com.rage.extraction.statements.db;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.extract.pdf.Row;
import com.rage.extraction.statements.train.Node;




public final class ParserOutput implements Comparable<ParserOutput>, Serializable{
	private static final long serialVersionUID = -6027340279914938585L;

	private Integer stmtID;
	private Integer worqueID;
	private Long poID;
	private String NonEnglishLabel;
	private Integer indexOrder;
	private String section;
	private String subSection;
	private String subtotal;
	private String breakups;
	private String asRepLabel;
	private String asRepVal1;
	private String value1;
	private String asRepVal2;
	private String value2;
	private String asRepVal3;
	private String value3;
	private String asRepVal4;
	private String value4;
	private String asRepVal5;
	private String value5;
	private String asRepVal6;
	private String value6;
	private String asRepVal7;
	private String value7;
	private String asRepVal8;
	private String value8;
	private String asRepVal9;
	private String value9;
	private String asRepVal10;
	private String value10;
	private String asRepVal11;
	private String value11;
	private String asRepVal12;
	private String value12;
	private String asRepVal13;
	private String value13;
	private String asRepVal14;
	private String value14;
	private String asRepVal15;
	private String value15;
	private String asRepVal16;
	private String value16;
	private String asRepVal17;
	private String value17;
	private String asRepVal18;
	private String value18;
	private String asRepVal19;
	private String value19;
	private String asRepVal20;
	private String value20;
	private String asRepVal21;
	private String value21;
	private String asRepVal22;
	private String value22;
	private String asRepVal23;
	private String value23;
	private String asRepVal24;
	private String value24;
	private String asRepVal25;
	private String value25;
	private String asRepVal26;
	private String value26;
	private String asRepVal27;
	private String value27;
	private String asRepVal28;
	private String value28;
	private String asRepVal29;
	private String value29;
	private String asRepVal30;
	private String value30;
	private String PageInfo;
	private Integer tableID;
	private String line;
	private String mark;
	private String hierarchy;
	private Boolean isSplit;
	private String isHeading;
	private String uploadID;
	private String fiID;
	private ParserOutput poRef;

	private Row row;
	private Integer lineNo;
	private Integer pageNo;
	
	private String Type;
	private Node mapNode;
	private List<Node> multiMapNode;
	private String labelMap;
	private List<ParserOutput> breakupItems;
	private List<ParserOutput> inlineBreakupItems;
	private String  prevHeader;
	private String val1Coords;
	private String val2Coords;
	private String val3Coords;
	private String val4Coords;
	private String val5Coords;
	private String val6Coords;
	private String val7Coords;
	private String val8Coords;
	private String val9Coords;
	private String val10Coords;
	private String val11Coords;
	private String val12Coords;
	private String val13Coords;
	private String val14Coords;
	private String val15Coords;
	private String val16Coords;
	private String val17Coords;
	private String val18Coords;
	private String val19Coords;
	private String val20Coords;
	private String val21Coords;
	private String val22Coords;
	private String val23Coords;
	private String val24Coords;
	private String val25Coords;
	private String val26Coords;
	private String val27Coords;
	private String val28Coords;
	private String val29Coords;
	private String val30Coords;
	private String notesColumn;
	private String nilLabel;
	private String fiLabel;
	private Integer indentLevel = 0;
	private List<POBreakUps> allBreakups; 
	private List<List<ParserOutput>> matchingBreakUpItem;
	private List<List<ParserOutput>> supplementaryBreakUpItem;
	private  String breakupExtracted;
	private String breakUpMainType;// Implicit or explicit
	private String breakUpType;// Table or text breakup
	TreeMap<String, List<List<ParserOutput>>> supplementaryMap;
	private POBreakUps pageNoCoOrdinates;
	private long ref_Po_id;
	private String matchingImplicitKeyWord;
	
	
	public ParserOutput getPoRef() {
		return poRef;
	}

	public void setPoRef(ParserOutput poRef) {
		this.poRef = poRef;
	}

	public String getBreakupExtracted() {
		return breakupExtracted;
	}
	
	

	public long getRef_Po_id() {
		return ref_Po_id;
	}

	public void setRef_Po_id(long ref_Po_id) {
		this.ref_Po_id = ref_Po_id;
	}

	public TreeMap<String, List<List<ParserOutput>>> getSupplementaryMap() {
		if(supplementaryMap==null)
		supplementaryMap= new TreeMap<String, List<List<ParserOutput>>>();
		return supplementaryMap;
	}

	public void setSupplementaryMap(
			TreeMap<String, List<List<ParserOutput>>> supplementaryMap) {
		this.supplementaryMap = supplementaryMap;
	}

	public void setBreakupExtracted(String breakupExtracted) {
		this.breakupExtracted = breakupExtracted;
	}

	public Integer getIndentLevel() {
		return indentLevel;
	}

	public void setIndentLevel(Integer indentLevel) {
		this.indentLevel = indentLevel;
	}

	public String getNilLabel() {
		return nilLabel;
	}

	public void setNilLabel(String nilLabel) {
		this.nilLabel = nilLabel;
	}

	public String getFiLabel() {
		return fiLabel;
	}

	public void setFiLabel(String fiLabel) {
		this.fiLabel = fiLabel;
	}

	public String getNiItem() {
		return niItem;
	}

	public void setNiItem(String niItem) {
		this.niItem = niItem;
	}

	private String niItem;

	public String getFiID() {
		return fiID;
	}

	public void setFiID(String fiID) {
		this.fiID = fiID;
	}
	
	private int maxCol;
	public Boolean getIsSplit() {
		return isSplit;
	}

	public void setIsSplit(Boolean isSplit) {
		this.isSplit = isSplit;
	}


	
	public String getVal1Coords() {
		return val1Coords;
	}

	public String getVal21Coords() {
		return val21Coords;
	}

	public void setVal21Coords(String val21Coords) {
		this.val21Coords = val21Coords;
	}

	public String getVal22Coords() {
		return val22Coords;
	}

	public void setVal22Coords(String val22Coords) {
		this.val22Coords = val22Coords;
	}

	public String getVal23Coords() {
		return val23Coords;
	}

	public void setVal23Coords(String val23Coords) {
		this.val23Coords = val23Coords;
	}

	public String getVal24Coords() {
		return val24Coords;
	}

	public void setVal24Coords(String val24Coords) {
		this.val24Coords = val24Coords;
	}

	public String getVal25Coords() {
		return val25Coords;
	}

	public void setVal25Coords(String val25Coords) {
		this.val25Coords = val25Coords;
	}

	public String getVal26Coords() {
		return val26Coords;
	}

	public void setVal26Coords(String val26Coords) {
		this.val26Coords = val26Coords;
	}

	public String getVal27Coords() {
		return val27Coords;
	}

	public void setVal27Coords(String val27Coords) {
		this.val27Coords = val27Coords;
	}

	public String getVal28Coords() {
		return val28Coords;
	}

	public void setVal28Coords(String val28Coords) {
		this.val28Coords = val28Coords;
	}

	public String getVal29Coords() {
		return val29Coords;
	}

	public void setVal29Coords(String val29Coords) {
		this.val29Coords = val29Coords;
	}

	public String getVal30Coords() {
		return val30Coords;
	}

	public void setVal30Coords(String val30Coords) {
		this.val30Coords = val30Coords;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public void setVal1Coords(String val1Coords) {
		this.val1Coords = val1Coords;
	}

	public String getVal2Coords() {
		return val2Coords;
	}

	public void setVal2Coords(String val2Coords) {
		this.val2Coords = val2Coords;
	}

	public String getVal3Coords() {
		return val3Coords;
	}

	public void setVal3Coords(String val3Coords) {
		this.val3Coords = val3Coords;
	}

	public String getVal4Coords() {
		return val4Coords;
	}

	public void setVal4Coords(String val4Coords) {
		this.val4Coords = val4Coords;
	}

	public String getVal5Coords() {
		return val5Coords;
	}

	public void setVal5Coords(String val5Coords) {
		this.val5Coords = val5Coords;
	}

	public String getVal6Coords() {
		return val6Coords;
	}

	public void setVal6Coords(String val6Coords) {
		this.val6Coords = val6Coords;
	}

	public String getVal7Coords() {
		return val7Coords;
	}

	public void setVal7Coords(String val7Coords) {
		this.val7Coords = val7Coords;
	}

	public String getVal8Coords() {
		return val8Coords;
	}

	public void setVal8Coords(String val8Coords) {
		this.val8Coords = val8Coords;
	}

	public String getVal9Coords() {
		return val9Coords;
	}

	public void setVal9Coords(String val9Coords) {
		this.val9Coords = val9Coords;
	}

	public String getVal10Coords() {
		return val10Coords;
	}

	public void setVal10Coords(String val10Coords) {
		this.val10Coords = val10Coords;
	}

	public String getVal11Coords() {
		return val11Coords;
	}

	public void setVal11Coords(String val11Coords) {
		this.val11Coords = val11Coords;
	}

	public String getVal12Coords() {
		return val12Coords;
	}

	public void setVal12Coords(String val12Coords) {
		this.val12Coords = val12Coords;
	}

	public String getVal13Coords() {
		return val13Coords;
	}

	public void setVal13Coords(String val13Coords) {
		this.val13Coords = val13Coords;
	}

	public String getVal14Coords() {
		return val14Coords;
	}

	public void setVal14Coords(String val14Coords) {
		this.val14Coords = val14Coords;
	}

	public String getVal15Coords() {
		return val15Coords;
	}

	public void setVal15Coords(String val15Coords) {
		this.val15Coords = val15Coords;
	}

	public String getVal16Coords() {
		return val16Coords;
	}

	public void setVal16Coords(String val16Coords) {
		this.val16Coords = val16Coords;
	}

	public String getVal17Coords() {
		return val17Coords;
	}

	public void setVal17Coords(String val17Coords) {
		this.val17Coords = val17Coords;
	}

	public String getVal18Coords() {
		return val18Coords;
	}

	public void setVal18Coords(String val18Coords) {
		this.val18Coords = val18Coords;
	}

	public String getVal19Coords() {
		return val19Coords;
	}

	public void setVal19Coords(String val19Coords) {
		this.val19Coords = val19Coords;
	}

	public String getVal20Coords() {
		return val20Coords;
	}

	public void setVal20Coords(String val20Coords) {
		this.val20Coords = val20Coords;
	}

	public Float getyCoords() {
		return yCoords;
	}

	public void setyCoords(Float yCoords) {
		this.yCoords = yCoords;
	}

	public void setStmtID(Integer stmtID) {
		this.stmtID = stmtID;
	}

	public void setWorqueID(Integer worqueID) {
		this.worqueID = worqueID;
	}

	public void setPoID(Long poID) {
		this.poID = poID;
	}

	public void setIndexOrder(Integer indexOrder) {
		this.indexOrder = indexOrder;
	}

	public void setMaxCol(int maxCol) {
		this.maxCol = maxCol;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	private PDFLine pdfLine;
	private Float yCoords ;


	
	public PDFLine getPdfLine() {
		return pdfLine;
	}

	public void setPdfLine(PDFLine pdfLine) {
		this.pdfLine = pdfLine;
	}

	public List<ParserOutput> getBreakupItems() {
		if(breakupItems==null)
			breakupItems= new ArrayList<ParserOutput>();
		return breakupItems;
	}

	public void setBreakupItems(List<ParserOutput> breakupItems) {
		this.breakupItems = breakupItems;
	}

	public List<ParserOutput> getInlineBreakupItems() {
		return inlineBreakupItems;
	}

	public void setInlineBreakupItems(List<ParserOutput> inlineBreakupItems) {
		this.inlineBreakupItems = inlineBreakupItems;
	}

	public String getLabelMap() {
		return labelMap;
	}

	public void setLabelMap(String labelMap) {
		this.labelMap = labelMap;
	}

	public int getPageNo() {
		return pageNo;
	}

	public Node getMapNode() {
		return mapNode;
	}

	public void setMapNode(Node mapNode) {
		this.mapNode = mapNode;
	}

	public List<Node> getMultiMapNode() {
		return multiMapNode;
	}

	public void setMultiMapNode(List<Node> multiMapNode) {
		this.multiMapNode = multiMapNode;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}


	public String getMark() {
		return mark;
	}

	public int getMaxCol() {
		return maxCol;
	}

	public int getStmtID() {
		return stmtID;
	}

	public void setStmtID(int stmtID) {
		this.stmtID = stmtID;
	}

	public int getWorqueID() {
		return worqueID;
	}

	public void setWorqueID(int worqueID) {
		this.worqueID = worqueID;
	}

	public long getPoID() {
		return poID;
	}

	public void setPoID(long poID) {
		this.poID = poID;
	}

	public Row getRow() {
		return row;
	}

	public void setRow(Row row) {
		this.row = row;
	}

	

	public void setMark(String mark) {
		this.mark = mark;
	}

	public String getHierarchy() {
		return hierarchy;
	}

	public String getIsHeading() {
		return isHeading;
	}

	public void setIsHeading(String isHeading) {
		this.isHeading = isHeading;
	}

	public void setHierarchy(String hierarchy) {
		this.hierarchy = hierarchy;
	}

	public String getPageInfo() {
		return PageInfo;
	}

	public void setPageInfo(String pageInfo) {
		PageInfo = pageInfo;
	}

	public Integer getTableID() {
		return tableID;
	}

	public void setTableID(Integer tableID) {
		this.tableID = tableID;
	}


	public ParserOutput()
	{
		this.mark="N";
		this.hierarchy="NA";
		this.subtotal="N";
		this.breakups="N";
		this.subSection="N";
	}

	public ParserOutput(String Type, String asRepLabel, int pageNo,
			int lineNo) {
		this.Type = Type;
		this.line = asRepLabel;
		this.lineNo = lineNo;
		this.pageNo = pageNo;

	}



	public String getAsRepLabel() {
		return asRepLabel;
	}

	public void setAsRepLabel(String asRepLabel) {
		this.asRepLabel = asRepLabel;
	}

	public String getAsRepVal1() {
		return asRepVal1;
	}

	public void setAsRepVal1(String asRepVal1) {
		this.asRepVal1 = asRepVal1;
	}

	public String getAsRepVal10() {
		return asRepVal10;
	}

	public void setAsRepVal10(String asRepVal10) {
		this.asRepVal10 = asRepVal10;
	}

	public String getAsRepVal11() {
		return asRepVal11;
	}

	public void setAsRepVal11(String asRepVal11) {
		this.asRepVal11 = asRepVal11;
	}

	public String getAsRepVal12() {
		return asRepVal12;
	}

	public void setAsRepVal12(String asRepVal12) {
		this.asRepVal12 = asRepVal12;
	}

	public String getAsRepVal13() {
		return asRepVal13;
	}

	public void setAsRepVal13(String asRepVal13) {
		this.asRepVal13 = asRepVal13;
	}

	public String getAsRepVal14() {
		return asRepVal14;
	}

	public void setAsRepVal14(String asRepVal14) {
		this.asRepVal14 = asRepVal14;
	}

	public String getAsRepVal15() {
		return asRepVal15;
	}

	public void setAsRepVal15(String asRepVal15) {
		this.asRepVal15 = asRepVal15;
	}

	public String getAsRepVal16() {
		return asRepVal16;
	}

	public void setAsRepVal16(String asRepVal16) {
		this.asRepVal16 = asRepVal16;
	}

	public String getAsRepVal17() {
		return asRepVal17;
	}

	public void setAsRepVal17(String asRepVal17) {
		this.asRepVal17 = asRepVal17;
	}

	public String getAsRepVal18() {
		return asRepVal18;
	}

	public void setAsRepVal18(String asRepVal18) {
		this.asRepVal18 = asRepVal18;
	}

	public String getAsRepVal19() {
		return asRepVal19;
	}

	public void setAsRepVal19(String asRepVal19) {
		this.asRepVal19 = asRepVal19;
	}

	public String getAsRepVal2() {
		return asRepVal2;
	}

	public void setAsRepVal2(String asRepVal2) {
		this.asRepVal2 = asRepVal2;
	}

	public String getAsRepVal20() {
		return asRepVal20;
	}

	public void setAsRepVal20(String asRepVal20) {
		this.asRepVal20 = asRepVal20;
	}

	public String getAsRepVal21() {
		return asRepVal21;
	}

	public void setAsRepVal21(String asRepVal21) {
		this.asRepVal21 = asRepVal21;
	}

	public String getAsRepVal22() {
		return asRepVal22;
	}

	public void setAsRepVal22(String asRepVal22) {
		this.asRepVal22 = asRepVal22;
	}

	public String getAsRepVal23() {
		return asRepVal23;
	}

	public void setAsRepVal23(String asRepVal23) {
		this.asRepVal23 = asRepVal23;
	}

	public String getAsRepVal24() {
		return asRepVal24;
	}

	public void setAsRepVal24(String asRepVal24) {
		this.asRepVal24 = asRepVal24;
	}

	public String getAsRepVal25() {
		return asRepVal25;
	}

	public void setAsRepVal25(String asRepVal25) {
		this.asRepVal25 = asRepVal25;
	}

	public String getAsRepVal26() {
		return asRepVal26;
	}

	public void setAsRepVal26(String asRepVal26) {
		this.asRepVal26 = asRepVal26;
	}

	public String getAsRepVal27() {
		return asRepVal27;
	}

	public void setAsRepVal27(String asRepVal27) {
		this.asRepVal27 = asRepVal27;
	}

	public String getAsRepVal28() {
		return asRepVal28;
	}

	public void setAsRepVal28(String asRepVal28) {
		this.asRepVal28 = asRepVal28;
	}

	public String getAsRepVal29() {
		return asRepVal29;
	}

	public void setAsRepVal29(String asRepVal29) {
		this.asRepVal29 = asRepVal29;
	}

	public String getAsRepVal3() {
		return asRepVal3;
	}

	public void setAsRepVal3(String asRepVal3) {
		this.asRepVal3 = asRepVal3;
	}

	public String getAsRepVal30() {
		return asRepVal30;
	}

	public void setAsRepVal30(String asRepVal30) {
		this.asRepVal30 = asRepVal30;
	}

	public String getAsRepVal4() {
		return asRepVal4;
	}

	public void setAsRepVal4(String asRepVal4) {
		this.asRepVal4 = asRepVal4;
	}

	public String getAsRepVal5() {
		return asRepVal5;
	}

	public void setAsRepVal5(String asRepVal5) {
		this.asRepVal5 = asRepVal5;
	}

	public String getAsRepVal6() {
		return asRepVal6;
	}

	public void setAsRepVal6(String asRepVal6) {
		this.asRepVal6 = asRepVal6;
	}

	public String getAsRepVal7() {
		return asRepVal7;
	}

	public void setAsRepVal7(String asRepVal7) {
		this.asRepVal7 = asRepVal7;
	}

	public String getAsRepVal8() {
		return asRepVal8;
	}

	public void setAsRepVal8(String asRepVal8) {
		this.asRepVal8 = asRepVal8;
	}

	public String getAsRepVal9() {
		return asRepVal9;
	}

	public void setAsRepVal9(String asRepVal9) {
		this.asRepVal9 = asRepVal9;
	}

	public String getBreakups() {
		return breakups;
	}

	public void setBreakups(String breakups) {
		this.breakups = breakups;
	}

	public long getID() {
		return poID;
	}

	public void setID(long id) {
		poID = id;
	}

	public int getIndexOrder() {
		return indexOrder;
	}

	public void setIndexOrder(int indexOrder) {
		this.indexOrder = indexOrder;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public int getStmt_id() {
		return stmtID;
	}

	public void setStmt_id(int stmt_id) {
		this.stmtID = stmt_id;
	}

	public String getSubtotal() {
		return subtotal;
	}

	public void setSubtotal(String subtotal) {
		this.subtotal = subtotal;
	}

	public String getValue1() {
		return value1;
	}

	public void setValue1(String value1) {
		this.value1 = value1;
	}

	public String getValue10() {
		return value10;
	}

	public void setValue10(String value10) {
		this.value10 = value10;
	}

	public String getValue11() {
		return value11;
	}

	public void setValue11(String value11) {
		this.value11 = value11;
	}

	public String getValue12() {
		return value12;
	}

	public void setValue12(String value12) {
		this.value12 = value12;
	}

	public String getValue13() {
		return value13;
	}

	public void setValue13(String value13) {
		this.value13 = value13;
	}

	public String getValue14() {
		return value14;
	}

	public void setValue14(String value14) {
		this.value14 = value14;
	}

	public String getValue15() {
		return value15;
	}

	public void setValue15(String value15) {
		this.value15 = value15;
	}

	public String getValue16() {
		return value16;
	}

	public void setValue16(String value16) {
		this.value16 = value16;
	}

	public String getValue17() {
		return value17;
	}

	public void setValue17(String value17) {
		this.value17 = value17;
	}

	public String getValue18() {
		return value18;
	}

	public void setValue18(String value18) {
		this.value18 = value18;
	}

	public String getValue19() {
		return value19;
	}

	public void setValue19(String value19) {
		this.value19 = value19;
	}

	public String getValue2() {
		return value2;
	}

	public void setValue2(String value2) {
		this.value2 = value2;
	}

	public String getValue20() {
		return value20;
	}

	public void setValue20(String value20) {
		this.value20 = value20;
	}

	public String getValue21() {
		return value21;
	}

	public void setValue21(String value21) {
		this.value21 = value21;
	}

	public String getValue22() {
		return value22;
	}

	public void setValue22(String value22) {
		this.value22 = value22;
	}

	public String getValue23() {
		return value23;
	}

	public void setValue23(String value23) {
		this.value23 = value23;
	}

	public String getValue24() {
		return value24;
	}

	public void setValue24(String value24) {
		this.value24 = value24;
	}

	public String getValue25() {
		return value25;
	}

	public void setValue25(String value25) {
		this.value25 = value25;
	}

	public String getValue26() {
		return value26;
	}

	public void setValue26(String value26) {
		this.value26 = value26;
	}

	public String getValue27() {
		return value27;
	}

	public void setValue27(String value27) {
		this.value27 = value27;
	}

	public String getValue28() {
		return value28;
	}

	public void setValue28(String value28) {
		this.value28 = value28;
	}

	public String getValue29() {
		return value29;
	}

	public void setValue29(String value29) {
		this.value29 = value29;
	}

	public String getValue3() {
		return value3;
	}

	public void setValue3(String value3) {
		this.value3 = value3;
	}

	public String getValue30() {
		return value30;
	}

	public void setValue30(String value30) {
		this.value30 = value30;
	}

	public String getValue4() {
		return value4;
	}

	public void setValue4(String value4) {
		this.value4 = value4;
	}

	public String getValue5() {
		return value5;
	}

	public void setValue5(String value5) {
		this.value5 = value5;
	}

	public String getValue6() {
		return value6;
	}

	public void setValue6(String value6) {
		this.value6 = value6;
	}

	public String getValue7() {
		return value7;
	}

	public void setValue7(String value7) {
		this.value7 = value7;
	}

	public String getValue8() {
		return value8;
	}

	public void setValue8(String value8) {
		this.value8 = value8;
	}

	public String getValue9() {
		return value9;
	}

	public void setValue9(String value9) {
		this.value9 = value9;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public String getSubSection() {
		return subSection;
	}

	public void setSubSection(String subSection) {
		this.subSection = subSection;
	}


	public int getWorque_id() {
		return worqueID;
	}

	public void setWorque_id(int worque_id) {
		this.worqueID = worque_id;
	}


	public String getUploadID() {
		return uploadID;
	}

	public void setUploadID(String uploadID) {
		this.uploadID = uploadID;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(int lineNo) {
		this.lineNo = lineNo;
	}


	@Override
	public int compareTo(ParserOutput o) {
		//if ((this.pageNo*1000+this.lineNo)<=(o.pageNo*1000+o.lineNo))
		//	return 0;
		if (((this.pageNo*1000)+this.lineNo)<((o.pageNo*1000)+o.lineNo))
				return -1;
		if (((this.pageNo*1000)+this.lineNo)>((o.pageNo*1000)+o.lineNo))
			return 1;

		return 0;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	public String getPrevHeader() {
		return prevHeader;
	}

	public void setPrevHeader(String prevHeader) {
		this.prevHeader = prevHeader;
	}

	public String getNotesColumn() {
		return notesColumn;
	}

	public void setNotesColumn(String notesColumn) {
		this.notesColumn = notesColumn;
	}



	public String getNonEnglishLabel() {
		return NonEnglishLabel;
	}

	public void setNonEnglishLabel(String nonEnglishLabel) {
		NonEnglishLabel = nonEnglishLabel;
	}

	public List<POBreakUps> getAllBreakups() {
		return allBreakups;
	}

	public void setAllBreakups(List<POBreakUps> allBreakups) {
		this.allBreakups = allBreakups;
	}

	public List<List<ParserOutput>> getMatchingBreakUpItem() {
		if(matchingBreakUpItem==null)
			matchingBreakUpItem= new ArrayList<List<ParserOutput>>();
		return matchingBreakUpItem;
	}

	public void setMatchingBreakUpItem(List<List<ParserOutput>> matchingBreakUpItem) {
		this.matchingBreakUpItem = matchingBreakUpItem;
	}

	public List<List<ParserOutput>> getSupplementaryBreakUpItem() {
		if(supplementaryBreakUpItem==null)
			supplementaryBreakUpItem= new ArrayList<List<ParserOutput>>();
		return supplementaryBreakUpItem;
	}

	public void setSupplementaryBreakUpItem(List<List<ParserOutput>> supplementaryBreakUpItem) {
		this.supplementaryBreakUpItem = supplementaryBreakUpItem;
	}

	public String getBreakUpMainType() {
		return breakUpMainType;
	}

	public void setBreakUpMainType(String breakUpMainType) {
		this.breakUpMainType = breakUpMainType;
	}

	public String getBreakUpType() {
		return breakUpType;
	}

	public void setBreakUpType(String breakUpType) {
		this.breakUpType = breakUpType;
	}

	public POBreakUps getPageNoCoOrdinates() {
		return pageNoCoOrdinates;
	}

	public void setPageNoCoOrdinates(POBreakUps pageNoCoOrdinates) {
		this.pageNoCoOrdinates = pageNoCoOrdinates;
	}

	public String getMatchingImplicitKeyWord() {
		return matchingImplicitKeyWord;
	}

	public void setMatchingImplicitKeyWord(String matchingImplicitKeyWord) {
		this.matchingImplicitKeyWord = matchingImplicitKeyWord;
	}
	
	public static final int MAX_PO_VAL = 30;
	public void setPOVal(int colunmIndex, String value){
		if(colunmIndex < 1 || colunmIndex > MAX_PO_VAL){
			return;
		}
		Method method = null;
		
		try {
			method = ParserOutput.class.getMethod("setValue" + colunmIndex, String.class);
			method.invoke(this, value);
			
			method = ParserOutput.class.getMethod("setAsRepVal" + colunmIndex, String.class);
			method.invoke(this, value);
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public String toString() {
		return "ParserOutput [section=" + section + ", subSection=" + subSection + ", asRepLabel=" + asRepLabel
				+ ", value1=" + value1 + ", value2=" + value2 + ", value3=" + value3 + ", value4=" + value4 + ", value5=" + value5 + ", Type=" + Type + "]";
	}
	
	
}
