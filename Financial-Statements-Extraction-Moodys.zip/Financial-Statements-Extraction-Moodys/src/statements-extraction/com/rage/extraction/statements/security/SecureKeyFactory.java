package com.rage.extraction.statements.security;


public final class SecureKeyFactory {

    /**
     * This constant is used for initializing the AES-256 secure algorithm.
     */
    private static final int DATABASE_CONNECTION_SECURE_KEY = 1;
    /**
     * This constant is used for initializing the SHA-256 secure algorithm.
     */
    private static final int USER_LOGON_SECURE_KEY = 2;

    private SecureKeyFactory() {
    }

    public static AbstractSecureKey getInstance(int keyType) {
        switch (keyType) {
            case DATABASE_CONNECTION_SECURE_KEY:
                return new DatabaseConnectionSecureKeyImpl();
            case USER_LOGON_SECURE_KEY:
                return new UserLogonSecureKeyImpl();
        }
        return null;
    }

	public static int getDatabaseConnectionSecureKey() {
		return DATABASE_CONNECTION_SECURE_KEY;
	}

	
    
    
}
