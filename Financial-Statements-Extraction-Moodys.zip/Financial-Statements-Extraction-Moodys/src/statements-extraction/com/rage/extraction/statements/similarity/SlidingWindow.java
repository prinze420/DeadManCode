package com.rage.extraction.statements.similarity;

/**
 * @author kiran.umadi
 *
 */
public class SlidingWindow implements Similarity {

	private char[] arrText1;
	private char[] arrText2;
	private int windowSize;
	private int maxima;
	
	public boolean match(String text1, String text2)
	{
		if (text1.equals(text2))
			return true;
		if (text1.length()>text2.length())
		{
			arrText1=text2.toCharArray();
			arrText2=text1.toCharArray();
			windowSize=text2.length();
			maxima=text1.length();
		} else
		{
			arrText1=text1.toCharArray();
			arrText2=text2.toCharArray();
			windowSize=text1.length();
			maxima=text2.length();
		}
		return match();
	}
	
	private boolean match()
	{
		for (int s=0; s<=maxima-windowSize; s++)
		{
			int matchCount=0;
			for (int j=0; j<windowSize; j++)
			{
				if (arrText2[s+j]==arrText1[j])
					matchCount++;
			}
			if (matchCount==arrText1.length)
				return true;
		}
		return false;
	}


	@Override
	public float jaccardSimilarity(String arg1, String arg2) {
		return 0;
	}

}
