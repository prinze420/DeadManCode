package com.rage.extraction.statements.constant;

import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public final class Constants {
	private static ResourceBundle resource = null;
	private static final String propertiesFile="config.properties";
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Constants.class);

	private static String getPropertiesfile() {
		return propertiesFile;
	}

	public static void loadResourceProperty() {
		if(resource == null) {
			final java.io.InputStream stream = Constants.class.getClassLoader().getResourceAsStream(getPropertiesfile());
			try {
				resource = new PropertyResourceBundle(stream);
			} catch (Exception e) {
				logger.error(e);
			} finally{}
		}
	}

	public static String getProperty(final String propertyName) {
		if(resource == null)
			try {
				throw new Exception("Resource not found");
			} catch (Exception e) {
				logger.error(e);
			} finally {}
		return resource.getString(propertyName);
	}
}
