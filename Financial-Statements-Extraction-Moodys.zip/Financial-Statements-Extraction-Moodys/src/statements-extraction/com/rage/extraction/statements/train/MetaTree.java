package com.rage.extraction.statements.train;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.serialize.SerializeObject;
import com.rage.extraction.statements.serialize.Serializer;
import com.rage.extraction.statements.similarity.JaccordSimilarity;


/**
 * @author kiran.umadi
 *
 */
public class MetaTree implements Tree, Serializable {
	private static final long serialVersionUID = 1799803811894506154L;
	private List<String[]> rawMeta;
	private Node root;
	private Serializer serializer;
	private String fileName;
	private TrainDataSet metaRoot;

	private String industry;
	private String language;

	public MetaTree() throws Exception {
		Constants.loadResourceProperty();
	}

	public MetaTree(String fileName, String industry,String language) throws Exception {
		Constants.loadResourceProperty();
		this.industry=industry.toLowerCase();
		this.language=language;
		this.read(fileName, this.industry,this.language);
	}

	public Node getRoot() {
		return root;
	}

	public void setRoot(Node node) {
		root=node;
	}

	public TrainDataSet getMetaRoot() {
		return metaRoot;
	}

	private boolean isMetaSerialized(String industry,String language) throws Exception
	{
		String train=Constants.getProperty("train.path");
		if (!new File(Constants.getProperty("train.path")).exists())
			new File(Constants.getProperty("train.path")).mkdir();
		String sep=System.getProperty("file.separator");
		/*	if (train.endsWith(sep))
			train+=industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
		else
			train=train+sep+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
		 */	


		if (train.endsWith(sep))
		{
			if(language.equalsIgnoreCase("Spanish ITR"))
			{
				train+=language.trim()+"/"+this.industry+"-"+Constants.getProperty("train.dataset");
			}
			else
			{
				train+=this.industry+"-"+Constants.getProperty("train.dataset");
			}
		}
		else
			if(language.equalsIgnoreCase("Spanish ITR"))
			{
				train = train+sep+language.trim()+"/"+this.industry+"-"+Constants.getProperty("train.dataset");	
			}
			else
			{
				train=train+sep+this.industry+"-"+Constants.getProperty("train.dataset");
			}

		if (new File(train).exists())
			return true;
		return false;
	}

	public boolean loadDataSet(String industry,String language) throws Exception
	{
		this.industry=industry;
		if (isMetaSerialized(industry,language))
		{
			String train=getTrainDataSetFileName();
			serializer=new SerializeObject();
			metaRoot=(TrainDataSet)serializer.deSerialize(train);
			return true;
		}
		return false;
	}

	public void read(String fileName, String industry,String language) throws Exception
	{
		this.industry=industry;
		this.language=language;

		/*
		try
		{
			new SafeFile(fileName);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(fileName);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}*/
		this.fileName=new File(fileName).getName();
		if (isMetaSerialized(industry,language))
		{
			loadDataSet(industry,language);
			//			String train=getTrainDataSetFileName();
			//			serializer=new SerializeObject();
			//			metaRoot=(TrainDataSet)serializer.deSerialize(train);
			//			System.out.println("Last updated :"+metaRoot.getLastUpdated().toString());
			//			System.out.println("Last trained on :"+metaRoot.getFileList().get(metaRoot.getFileList().size()-1));
			String file=new File(fileName).getName();
			String[] token=file.split("-");
			String key=token[0].trim().toUpperCase();
			if (token.length>0 && !token[0].equals(""))
			{
				if (metaRoot.getTrainDataSet().containsKey(key))
				{
					this.root=metaRoot.getTrainDataSet().get(key);
					printNode(this.root);
					return;
				}
			}
		}	
		BufferedReader br=new BufferedReader(new FileReader(fileName));
		String line="";
		if (rawMeta==null)
		{
			rawMeta=new ArrayList<String[]>();
			while((line=br.readLine())!=null)
			{
				line=line.trim();
				if (line.trim().equals(""))
					continue;
				rawMeta.add(line.split("\t"));
			}
			br.close();
		}
		load();
	}
	
	private void printNode(Node node){
		List<Node> children = node.getChilds();
		if(children == null || children.isEmpty()){
			System.out.println(node);
			return;
		}
		for(Node child : children){
			printNode(child);
		}
	}

	private void load() throws Exception
	{
		for (int col=0; col<maxColumn(); col++)
		{
			String prev="";
			for (String[] tokens:rawMeta)
			{
				if (col>tokens.length-1)
					continue;
				if (!prev.equals(tokens[col]) && !tokens[col].equals(""))
					prev=tokens[col];
				if (tokens[col].equals("") && !prev.equals(""))
					tokens[col]=prev;
			}
		}
		generateTree();
		if (metaRoot==null)
			metaRoot=new TrainDataSet(industry,language);
		String train=getTrainDataSetFileName();
		serializer=new SerializeObject();
		String file=new File(this.fileName).getName();
		String[] token=file.split("-");
		String key=token[0].trim().toUpperCase();
		if (token.length>0 && !token[0].equals(""))
		{
			metaRoot.getTrainDataSet().put(key, this.root);
			metaRoot.setLastUpdated();
			metaRoot.getFileList().add(this.fileName);
			metaRoot.setIndustry(this.industry);
			serializer.serialize(train, metaRoot);
		}
	}

	public String getTrainDataSetFileName() throws Exception
	{
		String train=Constants.getProperty("train.path");
		if (!new File(Constants.getProperty("train.path")).exists())
			new File(Constants.getProperty("train.path")).mkdir();
		String sep=System.getProperty("file.separator");
		if (train.endsWith(sep))
		{
			if(language.equalsIgnoreCase("Spanish ITR"))
				train=train+sep+language+"/"+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
			else
				train=train+sep+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");


		}

		//train+=industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
		else
		{
			
			if(language.equalsIgnoreCase("Spanish ITR"))
				train=train+sep+language+"-"+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
			else
				train=train+sep+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");



		}
		return train;
	}

	private int maxColumn()
	{
		if (rawMeta==null)
			return -1;
		int max=-1;
		for (String[] tokens:rawMeta)
		{
			if (max<tokens.length)
				max=tokens.length;
		}
		return max;
	}

	private Node getParent(String[] tokens, int i)
	{
		Node node=root;
		if (i==0)
			return root;
		else if (tokens.length>0 && tokens.length>i)
		{
			for (int index=0; index<i; index++)
			{
				node=DFSearch(tokens[index],node);
				if (node==null)
					return null;
			}
			if (node!=null)
				return node;
		}
		return null;	
	}

	private boolean treeMatch(Node a, Node b)
	{
		if (this.getSubSection(a).equals(this.getSubSection(b)))
			return true;
		return false;
	}

	private Node generateTree()
	{
		if (root==null)
			root=new Node("Root", -1);
		for (int i=0; i<maxColumn(); i++)
		{
			for (String[] tokens:rawMeta)
			{
				if (root.getChilds()==null)
					root.childs=new ArrayList<Node>();
				Node node=null, parent=null;
				if (i>0 && i<tokens.length)
					parent=getParent(tokens, i);
				//parent=DFSearch(tokens[i-1]);
				if (parent==null)
					parent=root;
				if (tokens.length>i) // && search(tokens[i])==null)
				{
					Node nodeExist=DFSearch(tokens[i]);
					if (nodeExist!=null && nodeExist.level()==i && treeMatch(parent, nodeExist.parent))
						continue;
					node=new Node(tokens[i], i);
					node.parent=parent;
					if (parent.childs==null)
						parent.childs=new ArrayList<Node>();
					parent.childs.add(node);
				}
			}
		}
		return root;
	}

	public Node DFSearch(String label)
	{
		if (root==null)
			return null;
		label=label.replaceAll("\\s\\s+", " ");
		return DFSearch(label, root);
	}

	// DFS
	public Node DFSearch(String label, Node rootNode)
	{
		Node result=null;
		if (rootNode.text().toUpperCase().equals(label.toUpperCase()))
			return rootNode;
		else if (rootNode.getChilds()!=null)
		{
			for (Node node:rootNode.getChilds())
			{
				result=DFSearch(label, node);
				if (result!=null)
					break;
			}
		}
		return result;
	}


	public List<Node> searchLabel(String label)
	{
		if (root==null)
			return null;
		List<Node> outcome=new ArrayList<Node>();
		label=label.replaceAll("\\s\\s+", " ");
		searchLabel(label, root, outcome);
		return outcome;
	}


	// DFS
	private void searchLabel(String label, Node rootNode, List<Node> outcome)
	{
		if (rootNode.text().toUpperCase().equals(label.trim().toUpperCase()))
			outcome.add(rootNode);
		if (rootNode.getChilds()!=null)
		{
			for (Node node:rootNode.getChilds())
				searchLabel(label, node,outcome);
		}
	}

	public Node searchLeafNodes(String label, String section)
	{
		List<Node> nodeList=new ArrayList<Node>();
		getLeafNodes(root, nodeList);
		for (Node node:nodeList)
		{
			if (section!=null)
			{
				//System.out.println("Searching - "+node.label);
				if (node.childs==null && node.label.equalsIgnoreCase(label) && this.getSubSection(node).equals(section))
				{
					//System.out.println("Found - "+node.label);
					return node;
				}
			} else if (node.childs==null && node.label.equalsIgnoreCase(label))
			{
				//System.out.println("Found - "+node.label);
				return node;
			} else if (node.childs==null)
			{
				float accuracy=new JaccordSimilarity().jaccardSimilarity(label.toUpperCase(), node.label.toUpperCase());
				if (accuracy>0.80)
					return node;
			}
		}
		return null;
	}

	public void getLeafNodes(Node rootNode, List<Node> labels)
	{
		if (rootNode.getChilds()!=null)
		{
			for (Node node:rootNode.getChilds())
				getLeafNodes(node,labels);
		} else
		{
			if(rootNode.level>1 && rootNode.label!=null)
				labels.add(rootNode);
		}
	}

	private void getLeaves(Node rootNode,List<Node> labels)
	{
		if (rootNode.getChilds()!=null)
		{
			for (Node node:rootNode.getChilds())
			{
				if(node!=null)
				{
					if(node.level>0 && node.label!=null)
					{
						labels.add(node);
					}
					getLeaves(node,labels);
				}
			}
		}
	}

	@Override
	public List<Node> getLeaves() {
		List<Node> labels = new ArrayList<Node>();
		if (this.root==null)
			generateTree();
		getLeaves(root,labels);
		return labels;
	}

	@Override
	public String getSection(Node node) {
		if (node.level==0)
		{
			String[] sections=node.text().split("-");
			return sections[0];
		} else if (node.level>0 && node.parent!=null)
			return getSection(node.parent);
		return node.text();
	}

	public String getSubSection(Node node) {
		if (node.level==0)
		{
			return node.text();
		} else if (node.level>0 && node.parent!=null)
			return getSubSection(node.parent);
		return node.text();
	}

	public String getSubSection(String label)
	{
		Node node=DFSearch(label);
		if (node==null)
			return "";
		else {
			while(node.getParent()!=null && node.getParent().level!=0) {
				node=node.getParent();
			}
		}
		return getSubSection(node);
	}



}
