package com.rage.extraction.statements;

public class Test {/*
	
public static void main*String args[])
{
	Charset charset = Charset.forName("ISO-8859-1");
	CharsetDecoder decoder = charset.newDecoder();
	CharsetEncoder encoder = charset.newEncoder();

	try {
	    // Convert a string to ISO-LATIN-1 bytes in a ByteBuffer
	    // The new ByteBuffer is ready to be read.
	    ByteBuffer bbuf = encoder.encode(CharBuffer.wrap("a string"));

	    // Convert ISO-LATIN-1 bytes in a ByteBuffer to a character ByteBuffer and then to a string.
	    // The new ByteBuffer is ready to be read.
	    CharBuffer cbuf = decoder.decode(bbuf);
	    String s = cbuf.toString();
	} catch (CharacterCodingException e) {
	}
}

*/}
