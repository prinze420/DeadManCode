package com.rage.extraction.statements.mapping;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.serialize.SerializeObject;
import com.rage.extraction.statements.serialize.Serializer;
import com.rage.extraction.statements.train.MetaTree;
import com.rage.extraction.statements.train.Node;
import com.rage.extraction.statements.train.TrainDataSet;
import com.rage.extraction.statements.train.Tree;


/**
 * @author kiran.umadi
 *
 */
public class IndustryMapReader implements MapReader {
	private Serializer serializer;
	private String train;
	private String trainID;
	private TrainDataSet dataSet;
	private List<String[]> rawData;
	private Integer updateCount;
	private Tree tree;
	private String industry;
	private PrintWriter writer;
	private static String language;


	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(IndustryMapReader.class);

	public IndustryMapReader(String industry,String language) throws Exception {
		Constants.loadResourceProperty();
		if (industry==null || industry.trim().equals(""))
		{
			System.err.println("Industry dataset not found");
			System.exit(1);
		}
		if (industry!=null)
			this.industry=industry.toLowerCase();
		if(language!=null)
			IndustryMapReader.language = language;
		updateCount=0;
		init();
	}

	public String getTrainID() {
		return trainID;
	}

	public Tree getTree() {
		return tree;
	}

	public TrainDataSet getDataSet() {
		return dataSet;
	}

	public String getIndustry() {
		return industry;
	}

	private void init() throws Exception
	{
		train=Constants.getProperty("train.path");
		if (!new File(Constants.getProperty("train.path")).exists())
			new File(Constants.getProperty("train.path")).mkdir();
		String sep=System.getProperty("file.separator");
		if (train.endsWith(sep))
		{
			//train+=industry+"-"+Constants.getProperty("train.dataset");

			if(language.equalsIgnoreCase("Spanish ITR"))
			{
				train+=language+"/"+industry+"-"+Constants.getProperty("train.dataset");
			}
			else
				train+=industry+"-"+Constants.getProperty("train.dataset");

		}
		else
		{
			if(language.equalsIgnoreCase("Spanish ITR"))
			{
				train=train+sep+language+"/"+industry+"-"+Constants.getProperty("train.dataset");
			}
			else
				train=train+sep+industry+"-"+Constants.getProperty("train.dataset");

		}
		if (new File(train).exists())
		{
			serializer=new SerializeObject();
			dataSet=(TrainDataSet) serializer.deSerialize(train);
			tree=new MetaTree();
			updateCount=0;
			logger.info("Loading "+industry+" dataset ...");
		} else
		{
			logger.error("Dataset not found, creating skeleton data set for "+industry+" ...");
			createTaxonomySkeleton();
		}
	}

	private void loadDataSet() throws IOException, ClassNotFoundException
	{
		if (dataSet==null)
		{
			serializer=new SerializeObject();
			dataSet=(TrainDataSet) serializer.deSerialize(train);
		}
	}

	public void train(String fileName) throws Exception
	{
		writer=new PrintWriter(new FileWriter(fileName+".log"));
		this.trainID=new File(fileName).getName();
		System.out.println("Reading training data ...");
		rawData=read(fileName);
		//write(rawData);
		System.out.println("Analyzing training data ...");
		loadDataSet();
		String key, prevKey="";
		Node node=null;
		for (String[] tokens:rawData)
		{
			key=getKey(tokens);
			if (!prevKey.equals(key))
			{
				prevKey=key;
				node=dataSet.getTrainDataSet().get(key);
				if (node==null)
					continue;
				tree.setRoot(node);
			}
			updateDataSet(tree, tokens);
		}
		if (updateCount!=0)
		{
			dataSet.setLastUpdated();
			dataSet.getFileList().add(trainID);
			serializer.serialize(this.train, dataSet);
		}
		System.out.println("Changes reflected :"+updateCount+"\nComplete.");
		if (writer!=null)
		{
			writer.write("\n\nChanges reflected :"+updateCount+"\nComplete.");
			writer.flush();
			writer.close();
		}
	}

	private void updateDataSet(Tree tree, String[] tokens)
	{
		Node subRoot=tree.DFSearch(tokens[0].trim());
		if (subRoot==null)
			return;

		String label = replaceNotes(tokens[1]);
		//String label=tokens[1].toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
		//label=tokens[1].toLowerCase().replaceAll("\\(see"+"(.*?)"+"\\)", "").trim();
		label=label.replaceAll("[^a-z A-Z\\-]", "");
		label=label.replaceAll("\\s\\s+", " ");
		if (tokens.length<3)
		{
			Node subHead=tree.DFSearch(label, subRoot);
			if (subHead==null)
			{
				subRoot.addNode(label, 1);
				if (writer!=null)
					writer.write("Added sub-head :"+label.trim()+"-->"+subRoot.getLabel()+"\n");
				updateCount++;
			}
			return;
		}
		String mapNodeLabel=null;
		if (tokens.length>2)
			mapNodeLabel=tokens[2].replaceAll("\\s\\s+", " ");

		Node labelNode=tree.DFSearch(label.trim(), subRoot);
		Node mapNode=null;
		if (mapNodeLabel!=null)
			mapNode=tree.DFSearch(mapNodeLabel.trim(), subRoot);
		if (mapNode!=null  && labelNode!=null && mapNode.equals(labelNode))
		{
			boolean foundChild=false;
			if (mapNode.getChilds()!=null)
			{
				for (Node child:mapNode.getChilds())
				{
					if (child.getLabel().equalsIgnoreCase(labelNode.getLabel()))
					{
						foundChild=true;
						break;
					}
				}
			}
			if (!foundChild)
			{
				if (mapNode.getChilds()==null)
					mapNode.setChilds(new ArrayList<Node>());
				Node newNode=new Node(label.trim(), mapNode.level()+1, trainID);
				newNode.setParent(mapNode);
				mapNode.getChilds().add(newNode);
				if (writer!=null)
					writer.write("Added :"+label.trim()+"-->"+mapNode.getLabel()+"\n");
				//System.out.println(label.trim()+"-->"+mapNode.getLabel());
				updateCount++;
				return;
			}
		} else if (mapNode!=null && labelNode!=null && !mapNode.equals(labelNode) && labelNode.getChilds()==null)
		{
			mapNode.addNode(label);
			if (writer!=null)
				writer.write("Added :"+label.trim()+"-->"+mapNode.getLabel()+"\n");
			//System.out.println(label.trim()+"-->"+mapNode.getLabel());
			updateCount++;
			return;
		}
		else if (mapNode!=null && labelNode==null)
		{
			if (mapNode.getChilds()==null)
				mapNode.setChilds(new ArrayList<Node>());
			Node newNode=new Node(label.trim(), mapNode.level()+1, trainID);
			newNode.setParent(mapNode);
			mapNode.getChilds().add(newNode);
			if (writer!=null)
				writer.write("Added :"+label.trim()+"-->"+mapNode.getLabel()+"\n");
			//System.out.println(label+"-->"+mapNode.getLabel());
			updateCount++;
		}
		else if (mapNode==null)
		{
			mapNode=new Node(tokens[2].trim(), subRoot.level()+1);
			mapNode.setParent(subRoot);
			if (writer!=null)
				writer.write("Parent Added :"+"* "+mapNode.getLabel()+"-->"+mapNode.getParent().getLabel()+"\n");
			//System.out.println("* "+mapNode.getLabel()+"-->"+mapNode.getParent().getLabel());
			if (mapNode.getChilds()==null)
				mapNode.setChilds(new ArrayList<Node>());
			Node newNode=new Node(label.trim(), mapNode.level()+1, trainID);
			newNode.setParent(mapNode);
			mapNode.getChilds().add(newNode);
			subRoot.getChilds().add(mapNode);
			if (writer!=null)
				writer.write("Added :"+label.trim()+"-->"+mapNode.getLabel()+"\n");
			//System.out.println(label.trim()+"-->"+mapNode.getLabel());
			updateCount+=2;
		} else
		{
			if (writer!=null)
				writer.write("\nAlready exists :"+tokens[1]+"\n");
			//System.out.println("Already exists :"+tokens[1]);
		}

	}

	private String replaceNotes(String label) {
		if(TimePeriodOntology.getNotesList()!=null)
		{
			for(String keyword:TimePeriodOntology.getNotesList())
			{
				label=label.toLowerCase().replaceAll("\\("+keyword.trim().toLowerCase()+"(.*?)"+"\\)", "");
				label=label.toLowerCase().replaceAll("\\["+keyword.trim().toLowerCase()+"(.*?)"+"\\]", "").trim();
			}
		}

		return label;
	}

	private List<String[]> read(String fileName) throws Exception
	{

		BufferedReader br=new BufferedReader(new FileReader(fileName));
		String line="";
		Map<String, List<String[]>> map=new HashMap<String, List<String[]>>();
		List<String[]> arrList=null;
		List<String[]> rawdata=new ArrayList<String[]>();
		while((line=br.readLine())!=null)
		{
			if (line.trim().equals(""))
				continue;
			String[] column=line.split("\t");
			if (isValid(column))
			{
				if (!map.containsKey(column[0].toUpperCase()))
					map.put(column[0].toUpperCase(), new ArrayList<String[]>());
				arrList=map.get(column[0].toUpperCase());
				arrList.add(column);
			}
			else
			{
				if (writer!=null)
					writer.write("IGNORED :"+line+"\n");
				System.err.println("IGNORED :"+line);
			}
		}
		if (writer!=null)
			writer.write("\n\nSorting training data ... \n\n");

		for (String key:map.keySet())
		{
			List<String[]> list=map.get(key);
			list=sortByMappingLabel(list);
			rawdata.addAll(list);
		}
		br.close();
		return rawdata;
	}

	private List<String[]> sortByMappingLabel(List<String[]> rawData)
	{
		Map<String, List<String[]>> map=new HashMap<String, List<String[]>>();
		List<String[]> list=null;
		List<String[]> heads=null;
		for (String[] arr:rawData)
		{
			if (arr.length>2)
			{
				if (!map.containsKey(arr[2].toLowerCase()))
					map.put(arr[2].toLowerCase(), new ArrayList<String[]>());
				list=map.get(arr[2].toLowerCase());
				list.add(arr);
			} else
			{
				if (heads==null)
					heads=new ArrayList<String[]>();
					heads.add(arr);
			}
		}
		list=new ArrayList<String[]>();
		for(String key:map.keySet())
			list.addAll(map.get(key));
		if (heads!=null && list!=null)
			list.addAll(heads);
		return list;
	}


	private void createTaxonomySkeleton() throws Exception
	{
		if (Constants.getProperty("train.src")==null)
		{
			System.err.println("Cannot create taxonomy frame");
			System.exit(1);
		}
		String path=Constants.getProperty("train.path");
		if (!path.endsWith(File.separator))
			if(language.trim().equalsIgnoreCase("Spanish ITR"))
				path+=File.separator+language+File.separator;
			else
				path+=File.separator;

		String[] fileNames=Constants.getProperty("train.src").split("\\|");

		for(String fileName:fileNames)
		{
			String file = "";
			if(language.equalsIgnoreCase("Spanish ITR"))
				file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";
			else
				file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";



			if(!new File(path+file).exists())
			{
				logger.error(path+file+" does not exists");				
			}
			tree=new MetaTree(path+file, industry,language);
		}

		/*for(String fileName:fileNames)
			tree=new MetaTree(path+fileName, industry);*/
	}

	private boolean isValid(String[] tokens)
	{
		if (tokens.length<1 && tokens.length>3)
			return false;
		for(int i=0; i<tokens.length; i++)
		{
			String tok=tokens[i];
			if (tok==null || tok.trim().equals(""))
				return false;
		}
		return true;
	}

	private String getKey(String[] tokens)
	{
		if (tokens==null)
			return "Unknown";
		if (tokens.length>0 && !tokens[0].trim().equals(""))
		{
			String[] tok=tokens[0].trim().split("-");
			if (!tok[0].trim().equals(""))
				return tok[0].trim().toUpperCase();
		}
		return null;
	}

	public void export(String fileName) throws Exception
	{
		if (dataSet==null)
			return;
		StringBuffer buffer=new StringBuffer();
		for (String key:dataSet.getTrainDataSet().keySet())
		{
			System.out.println(key+" ...");
			Node node=dataSet.getTrainDataSet().get(key);
			Tree nodeTree=new MetaTree();
			nodeTree.setRoot(node);
			buffer.append(treeWalk(nodeTree));
			buffer.append("\n\n");
		}
		writeBuffer(fileName, buffer);
	}

	private StringBuffer treeWalk(Tree tree)
	{
		StringBuffer buffer=new StringBuffer();
		if(tree.getRoot().getChilds() != null){
			for (Node node:tree.getRoot().getChilds()){
				buffer.append(treeWalk(node.text(),node));
			}
		}
		return buffer;
	}

	private StringBuffer treeWalk(String prefix, Node node)
	{
		StringBuffer buffer=new StringBuffer();
		if (node!=null)
		{
			if (node.getChilds()!=null)
			{
				if (!prefix.equals(node.text()))
					buffer.append(prefix+getTabs(node.level())+node.text()+"\n");
				for (Node n:node.getChilds())
					buffer.append(treeWalk(prefix,n));
			}
			else if (!prefix.equals(node.text()))
				buffer.append(prefix+getTabs(node.level())+node.text()+"\n");
		}
		return buffer;
	}

	private String getTabs(int number)
	{
		String tab="";
		for (int i=0; i<number; i++)
			tab+="\t";
		return tab;
	}

	private void writeBuffer(String fileName, StringBuffer buffer) throws IOException
	{
		PrintWriter pw=new PrintWriter(new FileWriter(fileName));
		pw.write(buffer.toString());
		pw.close();
	}

	public static void main(String[] args) throws Exception {
		long startTime=System.currentTimeMillis();
		String industry=null, documentName=null;
		long endTime;
		// Industry type
		if (args.length>0)
			industry = args[0];
		// document name
		if (args.length>1)
			documentName = args[1];
		if (args.length<2)
		{
			System.err.println("Usage: com.rage.cru.mapping.IndustryMapReader <Industry Type> <Document Name>");
			System.exit(1);
		}
		System.out.println(industry+" "+documentName);
		MapReader st=new IndustryMapReader(industry,language);
		// train
		st.train(documentName);

		// search item
		//		Node root=st.getDataSet().getTrainDataSet().get("BS");
		//		Tree tree=new MetaTree();
		//		tree.setRoot(root);
		//		List<Node> node=tree.searchLabel("Deferred income tax");

		// export
		//st.export("E:/Extraction Projects/Amex CRU - (Credit Rating Unit)/Output/metaExport.txt");
		endTime = System.currentTimeMillis();
		System.out.println("\nTotal time taken: "+((endTime-startTime)/1000.)+" seconds.");

	}

}
