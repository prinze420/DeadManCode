package com.rage.extraction.statements.reprocess;

import com.rage.extraction.statements.extract.pdf.RowSegmentationType;

public class ReprocessMetadata {
	private Integer pid;
	private String section;
	private Integer strtPage;
	private String strtKeyword;
	private Integer endPage;
	private String endKeyword;
	private Integer instanceID;


	private RowSegmentationType rowSegmentationType;
	private Integer columnNo;
	private String scope;
	private String subSection;
	private String parseValue;




	public String getParseValue() {
		return parseValue;
	}


	public void setParseValue(String parseValue) {
		this.parseValue = parseValue;
	}


	public String getScope() {
		return scope;
	}


	public void setScope(String scope) {
		this.scope = scope;
	}


	public String getSubSection() {
		return subSection;
	}


	public void setSubSection(String subSection) {
		this.subSection = subSection;
	}


	public ReprocessMetadata(Integer pid, String section,
			Integer strtPage, String strtKeyword, Integer endPage,
			String endKeyword, RowSegmentationType rowSegmentationType,Integer columnNo,String scope,String subSection) {
		super();
		this.pid = pid;
		this.section = section;
		this.strtPage = strtPage;
		this.strtKeyword = strtKeyword;
		this.endPage = endPage;
		this.endKeyword = endKeyword;
		this.rowSegmentationType=rowSegmentationType;
		this.columnNo =  columnNo;
		this.scope = scope;
		this.subSection = subSection;
	}


	public Integer getInstanceID() {
		return instanceID;
	}

	public void setInstanceID(Integer instanceID) {
		this.instanceID = instanceID;
	}

	public ReprocessMetadata() {
		// TODO Auto-generated constructor stub
	}

	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public Integer getStrtPage() {
		return strtPage;
	}
	public void setStrtPage(Integer strtPage) {
		this.strtPage = strtPage;
	}
	public String getStrtKeyword() {
		return strtKeyword;
	}
	public void setStrtKeyword(String strtKeyword) {
		this.strtKeyword = strtKeyword;
	}
	public Integer getEndPage() {
		return endPage;
	}
	public void setEndPage(Integer endPage) {
		this.endPage = endPage;
	}
	public String getEndKeyword() {
		return endKeyword;
	}

	public void setEndKeyword(String endKeyword) {
		this.endKeyword = endKeyword;
	}


	public RowSegmentationType getRowSegmentationType() {
		return rowSegmentationType;
	}


	public void setRowSegmentationType(RowSegmentationType rowSegmentationType) {
		this.rowSegmentationType = rowSegmentationType;
	}


	public Integer getColumnNo() {
		return columnNo;
	}


	public void setColumnNo(Integer columnNo) {
		this.columnNo = columnNo;
	}




}
