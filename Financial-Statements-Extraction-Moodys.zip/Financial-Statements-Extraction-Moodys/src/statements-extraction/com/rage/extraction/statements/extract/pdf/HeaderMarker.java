package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.pdf.utils.Pair;

public class HeaderMarker {

	TreeMap<Integer, PageParse>	reportPages;
	
	public HeaderMarker(TreeMap<Integer, PageParse> pageParsesMap) {
		
		this.reportPages = pageParsesMap;
		
	}

	public TreeMap<Integer, PageParse> getReportPages ( )
	{
		return reportPages;
	}

	public void setReportPages ( TreeMap<Integer, PageParse> reportPages )
	{
		this.reportPages = reportPages;
	}

	public static void main ( String[] args )
	{
		// TODO Auto-generated method stub

	}

	public void run ( )
	{
		System.out.println("Removing Header Lines...");
		
		try
		{
			List<Float> yAxis = new ArrayList<Float>();
			String headerString = getHeaderString(reportPages,yAxis);
			
			if(headerString==null)
			return;
			
			Pair<Float, Float> pair = new Pair<Float, Float>(0f, 0f);
			if(headerString!=null)
			{
				FooterMarker fm =  new FooterMarker();
				pair = fm.computeConstantYaxis(yAxis);
			}
			
			Map<Integer,PDFLine> pageHeaderLineMap = getPageWiseHeaderRows(reportPages,pair,headerString);
			
			if(pageHeaderLineMap.isEmpty())
			return;
			
			markHeaderRows(pageHeaderLineMap,reportPages);
			
			System.out.println("Header rows##");
			
			for( int index = 0; index < reportPages.size(); index++ )
			{
				List<PDFBlock> pdfBlocks  = reportPages.get(index).getPageBlocks();
				
				for(int j = 0;j<pdfBlocks.size();j++)
				{
					List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
					
					for(PDFLine line : pdfLines)
					{
						if(line.isLineHeader())
							System.out.println("Line::"+line.getLine());
					}
				}
			}
			System.out.println("Done");
		}
		catch (Exception e)
		{
			System.out.println("Exception occured while marking Header rows...");
			e.printStackTrace();
		}
	}

	private void markHeaderRows ( Map<Integer, PDFLine> pageHeaderLineMap, TreeMap<Integer, PageParse> reportPages )
	{
		for( int index = 0; index < reportPages.size(); index++ )
		{
			if(!pageHeaderLineMap.containsKey(index))
				continue;
			
			PDFLine footerLine = pageHeaderLineMap.get(index);
			
			List<PDFBlock> pdfBlocks  = reportPages.get(index).getPageBlocks();
			
			for(int j=pdfBlocks.size()-1;j>0;j--)
			{
				List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
				
				boolean matched = false;
				for(int l=pdfLines.size()-1;l>=0;l--)
				{
					PDFLine line  = pdfLines.get(l);
					
					if(line.equals(footerLine))
					{
						line.setLineHeader(true);
						matched = true;
						break;
					}
				}
				
				if(matched)
					break;
			}
			
			List<PDFLine> pdfLines = reportPages.get(index).getPageLines();
			
			for(int l=pdfLines.size()-1;l>=0;l--)
			{
				PDFLine line  = pdfLines.get(l);
				
				if(line.equals(footerLine))
				{
					if(line.equals(footerLine))
					{
						line.setLineHeader(true);
						break;
					}
				}
			}
		}
		setReportPages(reportPages);
	}

	private Map<Integer, PDFLine> getPageWiseHeaderRows ( TreeMap<Integer, PageParse> reportPages,
			Pair<Float, Float> pair, String headerString )
	{
		
		Map<Integer,PDFLine> pageHeaderLineMap = new LinkedHashMap<>();
		
		for(Integer rp :reportPages.keySet())
		{
			PageParse page = reportPages.get(rp);
			
			float pageHeight = page.getPage().getMediaBox().getHeight();
			
			List<PDFLine> pdfLines  = page.getPageLines();
			
			if(pdfLines!=null && pdfLines.size()>0)
			{
				PDFLine line = pdfLines.get(0);
				
				//check height condition...
				float maxHight= (10*pageHeight)/100;
				
				if(line.getY1() > maxHight)
				{
					continue;
				}
				
				String strLine = line.getLine().replaceAll("\\s+", "");
				
				if(strLine.trim().equalsIgnoreCase(headerString) 
						&& (line.getY1()>=pair.getA() && line.getY1()<=pair.getB()))
				{
					pageHeaderLineMap.put(rp, line);
				}
			}
		}
		
		return pageHeaderLineMap;
	}

	private String getHeaderString ( TreeMap<Integer, PageParse> reportPages, List<Float> yAxis )
	{
		String firstLine = "";
		int counter  = 0;
		for(Integer rp :reportPages.keySet())
		{
			PageParse page = reportPages.get(rp);
			
			if(page.getPageLines() == null || page.getPageLines().isEmpty() || page.getPageLines().size()<2)
			{
				continue;
			}
			
			float pageHeight = page.getPage().getMediaBox().getHeight();
			
			List<PDFLine> pdfLines  = page.getPageLines();
			
			if(pdfLines!=null && pdfLines.size()>0)
			{
				PDFLine line = pdfLines.get(0);
				
				//System.out.println("Line:"+line.getLine());
				
				//check height condition...
				float maxHight= (10*pageHeight)/100;
				
				if(line.getY1() > maxHight)
				{
					continue;
				}
				
				String strLine = line.getLine().replaceAll("\\s+", "");
								
				if(rp==0)
				{
					firstLine = strLine;
					yAxis.add(line.getY1());
				}else
				{
					if(firstLine.trim().equalsIgnoreCase(strLine))
					{
						counter++;
						yAxis.add(line.getY1());
					}
					else
					{
						System.out.println("Not matched..");
					}
				}
			}
		}
				
		if(counter==reportPages.size() && reportPages.size()>10)
		{
			return firstLine;
		}
		
		return null;
	}

	public TreeMap<Integer, PageParse> removeHeaderRowsFromPageParse ( TreeMap<Integer, PageParse> pageParsesMap )
	{
		try
		{
			for( int index = 0; index < pageParsesMap.size(); index++ )
			{
				///remove Header Lines
				List<PDFBlock> newBlocks = new ArrayList<PDFBlock>();
				List<PDFBlock> pdfBlocks  = pageParsesMap.get(index).getPageBlocks();
				
				for(int j=0;j<pdfBlocks.size();j++)
				{
					List<PDFLine> pdfLines = pdfBlocks.get(j).getLines();
					
					for(int l=0;l<pdfLines.size();l++)
					{
						PDFLine line  = pdfLines.get(l);
						
						if(line.isLineHeader())
						{
							pdfLines.remove(l);
							break;
						}
					}
					
					if(!pdfLines.isEmpty() && pdfLines.size()>0)
					{
						PDFBlock block =  new PDFBlock(pdfLines.get(0).getPageNo(), pdfLines);
						newBlocks.add(block);
					}
				}
				pageParsesMap.get(index).setPageBlocks(newBlocks);
				
				///remove footer Lines
				List<PDFLine> pdfLines = pageParsesMap.get(index).getPageLines();
				
				for(int l=0;l<pdfLines.size();l++)
				{
					PDFLine line  = pdfLines.get(l);
					
					if(line.isLineHeader())
					{
						pdfLines.remove(l);
						break;
					}
				}
			}
		}
		catch (Exception e)
		{
			System.out.println("Error occured while removing Header rows..");
			e.printStackTrace();
			return pageParsesMap;
		}
		
		return pageParsesMap;
	}

}
