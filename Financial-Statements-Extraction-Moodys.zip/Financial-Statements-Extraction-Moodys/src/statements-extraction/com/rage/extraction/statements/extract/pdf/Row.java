package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.statements.detectors.text.DataType;

public class Row implements Comparable<Row> 
{
	private Integer id ;
	private List<PDFLine> lines ;
	private boolean transactionRow ;
	private boolean headerRow ;
	private Integer pageNo;
	private Integer rowNo;
	private List<Cell> cells ;
	public PDFBlock getBlock() {
		return block;
	}

	public void setBlock(PDFBlock block) {
		this.block = block;
	}

	private PDFBlock block ;


	public List<Cell> getCells() {
		return cells;
	}

	public void setCells(List<Cell> cells) {
		this.cells = cells;
	}

	public Integer getRowNo() {
		return rowNo;
	}

	public void setRowNo(Integer rowNo) {
		this.rowNo = rowNo;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public boolean isHeaderRow() {
		return headerRow;
	}

	public void setHeaderRow(boolean headerRow) {
		this.headerRow = headerRow;
	}

	private List<PDFWord> numericWords ;

	private List<PDFLine> modifiedLines ;
	private HashMap<DataType, List<PDFWord>> typeWordsMap ;

	public Row(Integer id, List<PDFLine> lines)
	{
		setId(id) ;
		setLines(lines) ;

		setNumericWords(new ArrayList<PDFWord>()) ;

		setModifiedLines(new ArrayList<PDFLine>()) ;
		setTypeWordsMap(new HashMap<DataType, List<PDFWord>>()) ;
	}

	Row(Integer id, PDFLine line)
	{
		List<PDFLine> lines = null;
		if(getLines()==null)
			lines = new ArrayList<PDFLine>() ;
		lines.add(line) ;

		setId(id) ;
		setLines(lines) ;

		setNumericWords(new ArrayList<PDFWord>()) ;

		setModifiedLines(new ArrayList<PDFLine>()) ;
		setTypeWordsMap(new HashMap<DataType, List<PDFWord>>()) ;
	}
	
	
	Row(Integer id, PDFBlock block)
	{
		List<PDFLine> lines = new ArrayList<PDFLine>() ;
			for(PDFLine line :block.getLines()) 
			{
				lines.add(line) ;
			}

		setId(id) ;
		setLines(lines) ;

		setNumericWords(new ArrayList<PDFWord>()) ;

		setModifiedLines(new ArrayList<PDFLine>()) ;
		setTypeWordsMap(new HashMap<DataType, List<PDFWord>>()) ;
	}

	// TODO Remove unused code found by UCDetector
	// 	public void addNumericWord(PDFWord word)
	// 	{
	// 		getNumericWords().add(word) ;
	// 	}

	public String getCombinedString()
	{
		String ret = "" ;

		for ( int i=0 ; i<getLines().size() ; i++ )
			ret = ret.trim() + " " + getLines().get(i).getLine() + " " ;

		return ret.trim() ;
	}

	@Override
	public int compareTo(Row o) 
	{
		return getId().compareTo(o.getId()) ;
	}

	@Override
	public String toString() 
	{
		return toIndentedString("") ;
	}

	private String toIndentedString(String indent)
	{
		String ret = "" ;

		ret = indent + "Row: " + getId() + " [" + (isTransactionRow() ? "Transaction" : "Non-Transaction") + "]" + "\n" ;
		for ( int i=0 ; i<getLines().size() ; i++ )
			ret = ret + indent + "\tLine " + i + ": " + getLines().get(i).getLine() + "\n" ; 

		return ret ;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public boolean isTransactionRow() {
		return transactionRow;
	}

	public void setTransactionRow(boolean transactionRow) {
		this.transactionRow = transactionRow;
	}

	public List<PDFWord> getNumericWords() {
		return numericWords;
	}

	public void setNumericWords(List<PDFWord> numericWords) {
		this.numericWords = numericWords;
	}

	public List<PDFLine> getModifiedLines() {
		return modifiedLines;
	}

	public void setModifiedLines(List<PDFLine> modifiedLines) {
		this.modifiedLines = modifiedLines;
	}

	public HashMap<DataType, List<PDFWord>> getTypeWordsMap() {
		return typeWordsMap;
	}

	public void setTypeWordsMap(HashMap<DataType, List<PDFWord>> typeWordsMap) {
		this.typeWordsMap = typeWordsMap;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((block == null) ? 0 : block.hashCode());
		result = prime * result + ((cells == null) ? 0 : cells.hashCode());
		result = prime * result + (headerRow ? 1231 : 1237);
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		result = prime * result + ((lines == null) ? 0 : lines.hashCode());
		result = prime * result
				+ ((modifiedLines == null) ? 0 : modifiedLines.hashCode());
		result = prime * result
				+ ((numericWords == null) ? 0 : numericWords.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		result = prime * result + ((rowNo == null) ? 0 : rowNo.hashCode());
		result = prime * result + (transactionRow ? 1231 : 1237);
		result = prime * result
				+ ((typeWordsMap == null) ? 0 : typeWordsMap.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Row other = (Row) obj;
		if (block == null) {
			if (other.block != null)
				return false;
		} else if (!block.equals(other.block))
			return false;
		if (cells == null) {
			if (other.cells != null)
				return false;
		} else if (!cells.equals(other.cells))
			return false;
		if (headerRow != other.headerRow)
			return false;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		if (lines == null) {
			if (other.lines != null)
				return false;
		} else if (!lines.equals(other.lines))
			return false;
		if (modifiedLines == null) {
			if (other.modifiedLines != null)
				return false;
		} else if (!modifiedLines.equals(other.modifiedLines))
			return false;
		if (numericWords == null) {
			if (other.numericWords != null)
				return false;
		} else if (!numericWords.equals(other.numericWords))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		if (rowNo == null) {
			if (other.rowNo != null)
				return false;
		} else if (!rowNo.equals(other.rowNo))
			return false;
		if (transactionRow != other.transactionRow)
			return false;
		if (typeWordsMap == null) {
			if (other.typeWordsMap != null)
				return false;
		} else if (!typeWordsMap.equals(other.typeWordsMap))
			return false;
		return true;
	}


}
