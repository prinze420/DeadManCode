package com.rage.extraction.statements.train;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;


/**
 * @author kiran.umadi
 *
 */
public class Node implements Serializable {
	protected static final long serialVersionUID = -7749712109890746947L;
	protected String label;
	protected int level;
	protected Node parent;
	protected List<Node> childs;
	private int hashCode;
	private Date date;
	private String trainFileName;
	private boolean visted;

	public Node(String label, int level) {
		this.label=label;
		this.level=level;
		this.date=new Date();
		this.hashCode=level+10;
	}

	public Node(String label, int level, String trainID) {
		this.label=label;
		this.level=level;
		this.date=new Date();
		this.trainFileName=trainID;
		this.hashCode=level+10;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public int getLevel() {
		return level;
	}

	public void setLevel(int level) {
		this.level = level;
	}

	public int getHashCode() {
		return hashCode;
	}

	public void setHashCode(int hashCode) {
		this.hashCode = hashCode;
	}

	public void setParent(Node parent) {
		this.parent = parent;
	}

	public Node getParent() {
		return parent;
	}

	public List<Node> getChilds() {
		return childs;
	}

	public String getDate() {
		return date.toString();
	}

	public void setChilds(List<Node> childs) {
		this.childs = childs;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getTrainFileName() {
		return trainFileName;
	}

	public void setTrainFileName(String trainFileName) {
		this.trainFileName = trainFileName;
	}

	public boolean isVisted() {
		return visted;
	}

	public void setVisted(boolean visted) {
		this.visted = visted;
	}

	private Node navigateTo(int level)
	{
		if (this.level==level)
			return this;
		if (this.level<level && this.getChilds()!=null)
		{
			for (Node node:this.getChilds())
				return node.navigateTo(level);
		} else if (this.level>level && this.parent!=null)
			return this.parent;
		return this;
	}

	public void addNode(String label, int level)
	{
		Node node=navigateTo(level-1);
		if (node.childs==null)
			node.childs=new ArrayList<Node>();
		Node nd=new Node(label, level);
		nd.parent=node;
		node.childs.add(nd);
	}

	public void addNode(String label)
	{
		if (this.childs==null)
			this.childs=new ArrayList<Node>();
		Node nd=new Node(label, this.level+1);
		nd.parent=this;
		this.childs.add(nd);
	}

	public boolean removeNode(Node node)
	{
		if (this.childs.size()>0 && this.childs.indexOf(node)!=-1)
			return this.childs.remove(node);
		return false;
	}

	public String text()
	{
		return this.label;
	}

	public int level()
	{
		return this.level;
	}

//	@Override
//	public String toString() {
//		if (this.childs!=null)
//			return "["+this.label+" (Level:"+this.level+" Chilrens:"+this.childs.size()+")]";
//		else
//			return "["+this.label+" (Level:"+this.level+")]";
//	}
	
	@Override
	public boolean equals(Object obj) {
		if (obj instanceof Node) {
			Node newNode = (Node) obj;
			if (newNode.label.equalsIgnoreCase(this.label) && newNode.level==this.level
					&& newNode.hashCode==this.hashCode)
				return true;
		}
		return false;
	}

	@Override
	public String toString() {
		return "Node [label=" + label + "]";
	}

	@Override
	public int hashCode() {
		return this.hashCode;
	}
}
