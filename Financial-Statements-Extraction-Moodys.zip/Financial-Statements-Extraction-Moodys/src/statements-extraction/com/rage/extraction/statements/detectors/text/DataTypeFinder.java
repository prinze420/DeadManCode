package com.rage.extraction.statements.detectors.text;


public class DataTypeFinder 
{
	public static DataType findDataType(String input)
	{
		if ( input.trim().equalsIgnoreCase("") )
			return DataType.TEXT ;
		
		if ( DateDetector.isDate(input) )
			return DataType.DATE ;
		
		if ( DateDetector.isLongYear(input) )
			return DataType.DATE ;
		
		if ( NumberDetector.isNumericValue(input) )
			return DataType.NUMERIC_VALUE ;
			
		if ( NumberDetector.isPercentage(input))
			return DataType.PERCENTAGE ;
			
		if ( NumberDetector.isCurrency(input))
			return DataType.CURRENCY ;
		
		if ( NumberDetector.isRange(input))
			return DataType.RANGE ;
		
		
		return DataType.TEXT ;
	}
}
