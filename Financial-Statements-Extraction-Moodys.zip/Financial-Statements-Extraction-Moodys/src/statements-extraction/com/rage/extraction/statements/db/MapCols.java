package com.rage.extraction.statements.db;

public class MapCols 
{
	public static String getPOValueOnIndex(ParserOutput po,int index)
	{
		String ret=null;
		if(po==null)
			return null;
		
		if(index==0)
		{
			return po.getAsRepLabel();
		}
		else if (index==1)
		{
			return po.getValue1();
		}
		else if (index==2)
		{
			return po.getValue2();
		}
		else if (index==3)
		{
			return po.getValue3();
		}
		else if (index==4)
		{
			return po.getValue4();
		}
		else if (index==5)
		{
			return po.getValue5();
		}
		else if (index==6)
		{
			return po.getValue6();
		}
		else if (index==7)
		{
			return po.getValue7();
		}
		else if (index==8)
		{
			return po.getValue8();
		}
		else if (index==9)
		{
			return po.getValue9();
		}
		else if (index==10)
		{
			return po.getValue10();
		}
		else if (index==11)
		{
			return po.getValue11();
		}
		else if (index==12)
		{
			return po.getValue12();
		}
		else if (index==13)
		{
			return po.getValue13();
		}
		else if (index==14)
		{
			return po.getValue14();
		}
		else if (index==15)
		{
			return po.getValue15();
		}
		else if (index==16)
		{
			return po.getValue16();
		}
		else if (index==17)
		{
			return po.getValue17();
		}
		else if (index==18)
		{
			return po.getValue18();
		}
		else if (index==19)
		{
			return po.getValue19();
		}
		else if (index==20)
		{
			return po.getValue20();
		}
		else if (index==21)
		{
			return po.getValue21();
		}
		else if (index==22)
		{
			return po.getValue22();
		}
		else if (index==23)
		{
			return po.getValue23();
		}
		else if (index==24)
		{
			return po.getValue24();
		}
		else if (index==25)
		{
			return po.getValue25();
		}
		else if (index==26)
		{
			return po.getValue26();
		}
		else if (index==27)
		{
			return po.getValue27();
		}
		else if (index==28)
		{
			return po.getValue28();
		}
		else if (index==29)
		{
			return po.getValue29();
		}
		else if (index==30)
		{
			return po.getValue30();
		}
		return ret;
	}
	
	public static String getPOAsRepValOnIndex(ParserOutput po,int index)
	{
		String ret=null;
		if(po==null)
			return null;
		
		if(index==0)
		{
			return po.getAsRepLabel();
		}
		else if (index==1)
		{
			return po.getAsRepVal1();
		}
		else if (index==2)
		{
			return po.getAsRepVal2();
		}
		else if (index==3)
		{
			return po.getAsRepVal3();
		}
		else if (index==4)
		{
			return po.getAsRepVal4();
		}
		else if (index==5)
		{
			return po.getAsRepVal5();
		}
		else if (index==6)
		{
			return po.getAsRepVal6();
		}
		else if (index==7)
		{
			return po.getAsRepVal7();
		}
		else if (index==8)
		{
			return po.getAsRepVal8();
		}
		else if (index==9)
		{
			return po.getAsRepVal9();
		}
		else if (index==10)
		{
			return po.getAsRepVal10();
		}
		else if (index==11)
		{
			return po.getAsRepVal11();
		}
		else if (index==12)
		{
			return po.getAsRepVal12();
		}
		else if (index==13)
		{
			return po.getAsRepVal13();
		}
		else if (index==14)
		{
			return po.getAsRepVal14();
		}
		else if (index==15)
		{
			return po.getAsRepVal15();
		}
		else if (index==16)
		{
			return po.getAsRepVal16();
		}
		else if (index==17)
		{
			return po.getAsRepVal17();
		}
		else if (index==18)
		{
			return po.getAsRepVal18();
		}
		else if (index==19)
		{
			return po.getAsRepVal19();
		}
		else if (index==20)
		{
			return po.getAsRepVal20();
		}
		else if (index==21)
		{
			return po.getAsRepVal21();
		}
		else if (index==22)
		{
			return po.getAsRepVal22();
		}
		else if (index==23)
		{
			return po.getAsRepVal23();
		}
		else if (index==24)
		{
			return po.getAsRepVal24();
		}
		else if (index==25)
		{
			return po.getAsRepVal25();
		}
		else if (index==26)
		{
			return po.getAsRepVal26();
		}
		else if (index==27)
		{
			return po.getAsRepVal27();
		}
		else if (index==28)
		{
			return po.getAsRepVal28();
		}
		else if (index==29)
		{
			return po.getAsRepVal29();
		}
		else if (index==30)
		{
			return po.getAsRepVal30();
		}
		return ret;
	}

	public static void setPOValueOnIndex(ParserOutput po,int index,String value)
	{
		if(po==null)
			return ;
		
		if(index==0)
		{
			po.setAsRepLabel(value);
		}
		else if (index==1)
		{
			po.setValue1(value);
		}
		else if (index==2)
		{
			po.setValue2(value);
		}
		else if (index==3)
		{
			po.setValue3(value);
		}
		else if (index==4)
		{
			po.setValue4(value);
		}
		else if (index==5)
		{
			po.setValue5(value);
		}
		else if (index==6)
		{
			po.setValue6(value);
		}
		else if (index==7)
		{
			po.setValue7(value);
		}
		else if (index==8)
		{
			po.setValue8(value);
		}
		else if (index==9)
		{
			po.setValue9(value);
		}
		else if (index==10)
		{
			po.setValue10(value);
		}
		else if (index==11)
		{
			po.setValue11(value);
		}
		else if (index==12)
		{
			po.setValue12(value);
		}
		else if (index==13)
		{
			po.setValue13(value);
		}
		else if (index==14)
		{
			po.setValue14(value);
		}
		else if (index==15)
		{
			po.setValue15(value);
		}
		else if (index==16)
		{
			po.setValue16(value);
		}
		else if (index==17)
		{
			po.setValue17(value);
		}
		else if (index==18)
		{
			po.setValue18(value);
		}
		else if (index==19)
		{
			po.setValue19(value);
		}
		else if (index==20)
		{
			po.setValue20(value);
		}
		else if (index==21)
		{
			po.setValue21(value);
		}
		else if (index==22)
		{
			po.setValue22(value);
		}
		else if (index==23)
		{
			po.setValue23(value);
		}
		else if (index==24)
		{
			po.setValue24(value);
		}
		else if (index==25)
		{
			po.setValue25(value);
		}
		else if (index==26)
		{
			po.setValue26(value);
		}
		else if (index==27)
		{
			po.setValue27(value);
		}
		else if (index==28)
		{
			po.setValue28(value);
		}
		else if (index==29)
		{
			po.setValue29(value);
		}
		else if (index==30)
		{
			po.setValue30(value);
		}
	}
	
	public static void setPOAsRepValueOnIndex(ParserOutput po,int index,String value)
	{
		if(po==null)
			return ;
		
		if(index==0)
		{
			po.setAsRepLabel(value);
		}
		else if (index==1)
		{
			po.setAsRepVal1(value);
		}
		else if (index==2)
		{
			po.setAsRepVal2(value);
		}
		else if (index==3)
		{
			po.setAsRepVal3(value);
		}
		else if (index==4)
		{
			po.setAsRepVal4(value);
		}
		else if (index==5)
		{
			po.setAsRepVal5(value);
		}
		else if (index==6)
		{
			po.setAsRepVal6(value);
		}
		else if (index==7)
		{
			po.setAsRepVal7(value);
		}
		else if (index==8)
		{
			po.setAsRepVal8(value);
		}
		else if (index==9)
		{
			po.setAsRepVal9(value);
		}
		else if (index==10)
		{
			po.setAsRepVal10(value);
		}
		else if (index==11)
		{
			po.setAsRepVal11(value);
		}
		else if (index==12)
		{
			po.setAsRepVal12(value);
		}
		else if (index==13)
		{
			po.setAsRepVal13(value);
		}
		else if (index==14)
		{
			po.setAsRepVal14(value);
		}
		else if (index==15)
		{
			po.setAsRepVal15(value);
		}
		else if (index==16)
		{
			po.setAsRepVal16(value);
		}
		else if (index==17)
		{
			po.setAsRepVal17(value);
		}
		else if (index==18)
		{
			po.setAsRepVal18(value);
		}
		else if (index==19)
		{
			po.setAsRepVal19(value);
		}
		else if (index==20)
		{
			po.setAsRepVal20(value);
		}
		else if (index==21)
		{
			po.setAsRepVal21(value);
		}
		else if (index==22)
		{
			po.setAsRepVal22(value);
		}
		else if (index==23)
		{
			po.setAsRepVal23(value);
		}
		else if (index==42)
		{
			po.setAsRepVal24(value);
		}
		else if (index==25)
		{
			po.setAsRepVal5(value);
		}
		else if (index==26)
		{
			po.setAsRepVal26(value);
		}
		else if (index==27)
		{
			po.setAsRepVal27(value);
		}
		else if (index==28)
		{
			po.setAsRepVal28(value);
		}
		else if (index==29)
		{
			po.setAsRepVal29(value);
		}
		else if (index==30)
		{
			po.setAsRepVal30(value);
		}
	}

	public static String getPOCordOnIndex(ParserOutput po, int index) {
		String ret=null;
		if(po==null)
			return null;
		
		
		if (index==1)
		{
			return po.getVal1Coords();
		}
		else if (index==2)
		{
			return po.getVal2Coords();
		}
		else if (index==3)
		{
			return po.getVal3Coords();
		}
		else if (index==4)
		{
			return po.getVal4Coords();
		}
		else if (index==5)
		{
			return po.getVal5Coords();
		}
		else if (index==6)
		{
			return po.getVal6Coords();
		}
		else if (index==7)
		{
			return po.getVal7Coords();
		}
		else if (index==8)
		{
			return po.getVal8Coords();
		}
		else if (index==9)
		{
			return po.getVal9Coords();
		}
		else if (index==10)
		{
			return po.getVal10Coords();
		}
		else if (index==11)
		{
			return po.getVal11Coords();
		}
		else if (index==12)
		{
			return po.getVal12Coords();
		}
		else if (index==13)
		{
			return po.getVal13Coords();
		}
		else if (index==14)
		{
			return po.getVal14Coords();
		}
		else if (index==15)
		{
			return po.getVal15Coords();
		}
		else if (index==16)
		{
			return po.getVal16Coords();
		}
		else if (index==17)
		{
			return po.getVal17Coords();
		}
		else if (index==18)
		{
			return po.getVal18Coords();
		}
		else if (index==19)
		{
			return po.getVal19Coords();
		}
		else if (index==20)
		{
			return po.getVal20Coords();
		}
		else if (index==21)
		{
			return po.getVal21Coords();
		}
		else if (index==22)
		{
			return po.getVal22Coords();
		}
		else if (index==23)
		{
			return po.getVal23Coords();
		}
		else if (index==24)
		{
			return po.getVal24Coords();
		}
		else if (index==25)
		{
			return po.getVal25Coords();
		}
		else if (index==26)
		{
			return po.getVal26Coords();
		}
		else if (index==27)
		{
			return po.getVal27Coords();
		}
		else if (index==28)
		{
			return po.getVal28Coords();
		}
		else if (index==29)
		{
			return po.getVal29Coords();
		}
		else if (index==30)
		{
			return po.getVal30Coords();
		}
		return ret;
	}

	public static void setColCoordMap(ParserOutput po, Integer index,
			String value) {
		if(po==null)
			return ;
			
		if (index==1)
		{
			po.setVal1Coords(value);
		}
		else if (index==2)
		{
			po.setVal2Coords(value);
		}
		else if (index==3)
		{
			po.setVal3Coords(value);
		}
		else if (index==4)
		{
			po.setVal4Coords(value);
		}
		else if (index==5)
		{
			po.setVal5Coords(value);
		}
		else if (index==6)
		{
			po.setVal6Coords(value);
		}
		else if (index==7)
		{
			po.setVal7Coords(value);
		}
		else if (index==8)
		{
			po.setVal8Coords(value);
		}
		else if (index==9)
		{
			po.setVal9Coords(value);
		}
		else if (index==10)
		{
			po.setVal10Coords(value);
		}
		else if (index==11)
		{
			po.setVal11Coords(value);
		}
		else if (index==12)
		{
			po.setVal12Coords(value);
		}
		else if (index==13)
		{
			po.setVal13Coords(value);
		}
		else if (index==14)
		{
			po.setVal14Coords(value);
		}
		else if (index==15)
		{
			po.setVal15Coords(value);
		}
		else if (index==16)
		{
			po.setVal16Coords(value);
		}
		else if (index==17)
		{
			po.setVal17Coords(value);
		}
		else if (index==18)
		{
			po.setVal18Coords(value);
		}
		else if (index==19)
		{
			po.setVal19Coords(value);
		}
		else if (index==20)
		{
			po.setVal20Coords(value);
		}
		else if (index==21)
		{
			po.setVal21Coords(value);
		}
		else if (index==22)
		{
			po.setVal22Coords(value);
		}
		else if (index==23)
		{
			po.setVal23Coords(value);
		}
		else if (index==24)
		{
			po.setVal24Coords(value);
		}
		else if (index==25)
		{
			po.setVal25Coords(value);
		}
		else if (index==26)
		{
			po.setVal26Coords(value);
		}
		else if (index==27)
		{
			po.setVal27Coords(value);
		}
		else if (index==28)
		{
			po.setVal28Coords(value);
		}
		else if (index==29)
		{
			po.setVal29Coords(value);
		}
		else if (index==30)
		{
			po.setVal30Coords(value);
		}
	}
		
}
