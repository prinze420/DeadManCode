package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.TreeMap;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.detectors.text.DataType;
import com.rage.extraction.statements.extract.pdf.RowSegmenterPattern.PatternProgressUnit;
import com.rage.extraction.statements.ontology.MetaData;



class RowSegmentorv3 
{
	private static Boolean ONE_LINE_ONE_ROW_DEBUG = Boolean.FALSE ;
	private static Boolean ONE_PARA_ONE_ROW_DEBUG = Boolean.FALSE ;
	private static Boolean PATTERN_SEGMENTATION_DEBUG = Boolean.FALSE ;
	private static Boolean GROUP_SEGMENTATION_DEBUG = Boolean.FALSE ;
	
	private List<PDFBlock> allBlocks ;
	private List<PDFBlock> headerBlocks ;
	private List<PDFBlock> headingBlocks ;
	private List<PDFBlock> totalStartBlocks ;
	private List<PDFBlock> totalEndBlocks ;
	private MetaData rule ;

	private List<PDFBlock> headerRemovedBlocks ;
	private List<PDFBlock> rowBlocks ;
	
	private TreeMap<Integer, List<PDFLine>> levelLinesMap ;
	
	public RowSegmentorv3(List<PDFBlock> allBlocks, List<PDFBlock> headerBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, 
			List<PDFBlock> totalEndBlocks, MetaData rule)
	{
		setAllBlocks(allBlocks) ;
		setHeaderBlocks(headerBlocks) ;
		setHeadingBlocks(headingBlocks) ;
		setTotalStartBlocks(totalStartBlocks) ;
		setTotalEndBlocks(totalEndBlocks) ;
		setRule(rule) ;

		setHeaderRemovedBlocks(new ArrayList<PDFBlock>()) ;
		setRowBlocks(new ArrayList<PDFBlock>()) ;
		setLevelLinesMap(new TreeMap<Integer, List<PDFLine>>()) ;
	}
	
	public void run()
	{	
		List<PDFBlock> headerRemovedBlocks = createHeaderRemovedBlocks(getAllBlocks(), getHeaderBlocks()) ;
		setHeaderRemovedBlocks(headerRemovedBlocks) ;

		List<PDFBlock> rowBlocks = new ArrayList<PDFBlock>() ;
		
		if ( ONE_LINE_ONE_ROW_DEBUG ||ONE_PARA_ONE_ROW_DEBUG || PATTERN_SEGMENTATION_DEBUG || GROUP_SEGMENTATION_DEBUG )
		{
			System.out.println("\n\n\nRow Segmentor Debug ....\n\n\n") ;
			System.out.println("Table Identification Rule=" + getRule()) ;
		}
		
		if ( getRule().getRowSegmentationType().equals(RowSegmentationType.ONE_LINE_ONE_ROW) )
		{
			System.out.println("Found ONE_LINE_ONE_ROW ...") ;
			rowBlocks = createOneLineOneRow(getHeaderRemovedBlocks(), getHeadingBlocks(), getTotalStartBlocks(), getTotalEndBlocks()) ;
			setAsGivenLevel(rowBlocks, 1) ;
		}
		else if ( getRule().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW) )
		{
			if ( ONE_PARA_ONE_ROW_DEBUG )
				System.out.println("Found ONE_PARA_ONE_ROW ...") ;
			
			rowBlocks = createOneParaOneRow(getHeaderRemovedBlocks()) ;
			setAsGivenLevel(rowBlocks, 1) ;
		}
		else if ( getRule().getRowSegmentationType().equals(RowSegmentationType.PATTERN_BASED_ROWS) )
		{
			rowBlocks = createPatternBasedRows(getHeaderRemovedBlocks(), getHeadingBlocks(), getTotalStartBlocks(), getTotalEndBlocks(), getRule()) ;
			setAsGivenLevel(rowBlocks, 1) ;
		}
		else if ( getRule().getRowSegmentationType().equals(RowSegmentationType.GROUP_BASED_ROWS) )
		{
			rowBlocks = createGroupBasedRows(getHeaderRemovedBlocks(), getHeadingBlocks(), getTotalStartBlocks(), getTotalEndBlocks(), getRule()) ;
		}

		setRowBlocks(rowBlocks) ;
	}

	private void setAsGivenLevel(List<PDFBlock> rowBlocks, int level) 
	{
		
		List<PDFLine> lines = new ArrayList<PDFLine>() ;
		for ( int i=0 ; i<rowBlocks.size() ; i++ )
		{
			PDFBlock block = rowBlocks.get(i) ;
			List<PDFLine> thisBlockLines = block.getLines() ;
			
			lines.addAll(thisBlockLines) ;
		}
		
		getLevelLinesMap().put(new Integer(level), lines) ;
	}

	private List<PDFBlock> createGroupBasedRows(List<PDFBlock> headerRemovedBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, List<PDFBlock> totalEndBlocks, MetaData rule) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;
		
		if ( GROUP_SEGMENTATION_DEBUG )
			System.out.println("\n\n\nGroup Segmentation Debug ....\n\n\n") ;

		List<List<RowSegmenterPattern>> groupPattern = createGroupPattern(rule.getRowSegmentationRule()) ;
		
		if ( GROUP_SEGMENTATION_DEBUG )
			System.out.println("Group Pattern: " + groupPattern) ;

		boolean allParas = arePatternsSameType(groupPattern, RowSegmenterPattern.PatternProgressUnit.PARA) ;
		boolean allLines = arePatternsSameType(groupPattern, RowSegmenterPattern.PatternProgressUnit.LINE) ;

		List<Integer> levelSizes = new ArrayList<Integer>() ;
		
		levelSizes = new ArrayList<Integer>(Arrays.asList(new Integer[] {1, 1})) ;
		boolean size211 = isGroupOfSize(2, levelSizes, groupPattern) ;

		levelSizes = new ArrayList<Integer>(Arrays.asList(new Integer[] {1, 2})) ;
		boolean size212 = isGroupOfSize(2, levelSizes, groupPattern) ;


		if ( (allParas || allLines) && size211 )
		{
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("Size = 2, <1, 1>, and is either allParas or allLines ...") ;

			List<PDFBlock> newAllBlocks = allParas ? new ArrayList<PDFBlock>(headerRemovedBlocks) : createLineBlocks(headerRemovedBlocks, headingBlocks, totalStartBlocks, totalEndBlocks) ;
			ret = createGroupBlocks211(newAllBlocks, headingBlocks, totalStartBlocks, totalEndBlocks, groupPattern) ;
		}
		else if ( (!allParas && !allLines) && size211 )
		{

		}
		else if ( (allParas || allLines) && size212 )
		{

		}
		else if ( (!allParas && !allLines) && size212 )
		{

		}

		return ret ;
	}

	private List<PDFBlock> createGroupBlocks211(List<PDFBlock> newAllBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, List<PDFBlock> totalEndBlocks, List<List<RowSegmenterPattern>> groupPattern) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		RowSegmenterPattern pattern1 = groupPattern.get(0).get(0) ;
		RowSegmenterPattern pattern2 = groupPattern.get(1).get(0) ;

		List<PDFBlock> thisGroupLevel1 = new ArrayList<PDFBlock>() ;
		List<PDFBlock> thisGroupLevel2 = new ArrayList<PDFBlock>() ;
		boolean onLevel1 = true ;

		for ( int i=0 ; i<newAllBlocks.size() ; i++ )
		{
			PDFBlock block = newAllBlocks.get(i) ;
			
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\n\nBlock = " + block.getBlockString()) ;
			
			if ( headingBlocks.contains(block) || totalStartBlocks.contains(block) || totalEndBlocks.contains(block) )
			{
				if ( GROUP_SEGMENTATION_DEBUG )
					System.out.println("\tFound a Heading of Total Row ...") ;

				if ( thisGroupLevel1.size() != 0 )
				{
					if ( GROUP_SEGMENTATION_DEBUG )
						System.out.println("\t\tClearing previous group ...") ;

					List<PDFBlock> thisGroup = createGroup(thisGroupLevel1, thisGroupLevel2) ;
					ret.addAll(thisGroup) ;
					
					thisGroupLevel1 = new ArrayList<PDFBlock>() ;
					thisGroupLevel2 = new ArrayList<PDFBlock>() ;
					onLevel1 = true ;
				}

				if ( GROUP_SEGMENTATION_DEBUG )
					System.out.println("\t\tAdding this block as a row, as is ...") ;

				ret.add(block) ;

				continue ;
			}

			RowSegmenterPattern nextPattern = onLevel1 ? pattern1 : pattern2 ;
			
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\tNext Pattern to Check = " + nextPattern) ;

			if ( doesBlockSatisfyPattern(block, nextPattern) )
			{
				if ( GROUP_SEGMENTATION_DEBUG )
					System.out.println("\t\tBlock satisfies next-pattern ...") ;

				if ( onLevel1 )
				{
					if ( GROUP_SEGMENTATION_DEBUG )
						System.out.println("\t\tAdding to Level-1 ...") ;
					
					thisGroupLevel1.add(block) ;
					onLevel1 = false ;
				}
				else
				{
					/*if ( block.getBlockString().contains(":") && thisGroupLevel2.size() != 0 )
					{
						if ( GROUP_SEGMENTATION_DEBUG )
							System.out.println("\t\tAdding to Level-2 ... After merging it with the previous level-2 block") ;
						
						PDFBlock newBlock = mergeBlocks(thisGroupLevel2.get(thisGroupLevel1.size()-1), block) ;
						thisGroupLevel2.remove(thisGroupLevel2.size()-1) ;

						thisGroupLevel2.add(newBlock) ;
					}
					else
					{
						if ( GROUP_SEGMENTATION_DEBUG )
							System.out.println("\t\tAdding to Level-2 ...") ;
						
						thisGroupLevel2.add(block) ;
					}*/
					
					if ( GROUP_SEGMENTATION_DEBUG )
						System.out.println("\t\tAdding to Level-2 ...") ;
					
					thisGroupLevel2.add(block) ;
				}
				
				continue ;
			}

			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\t\tBlock doesn't satisfy next-pattern ...") ;

			if ( thisGroupLevel1.size() != 0 )
			{
				List<PDFBlock> thisGroup = createGroup(thisGroupLevel1, thisGroupLevel2) ;
				ret.addAll(thisGroup) ;

				thisGroupLevel1 = new ArrayList<PDFBlock>() ;
				thisGroupLevel2 = new ArrayList<PDFBlock>() ;
				onLevel1 = true ;
			}
			
			nextPattern = pattern1 ;
			
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\t\tCheck is this is a valid level-1 ... : " + nextPattern) ;
			
			if ( doesBlockSatisfyPattern(block, nextPattern) )
			{
				if ( GROUP_SEGMENTATION_DEBUG )
					System.out.println("\t\t\tFound a valid Level-1 ...") ;

				thisGroupLevel1.add(block) ;
				onLevel1 = false ;

				continue ;
			}
			
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\t\t\tNot a valid Level-1 ... So adding it into the final groups as is ...") ;

			ret.add(block) ;

			continue ;
		}

		if ( thisGroupLevel1.size() != 0 )
		{
			if ( GROUP_SEGMENTATION_DEBUG )
				System.out.println("\t\tAdding left-over groups ...") ;
			
			List<PDFBlock> thisGroup = createGroup(thisGroupLevel1, thisGroupLevel2) ;
			ret.addAll(thisGroup) ;

			thisGroupLevel1 = new ArrayList<PDFBlock>() ;
			thisGroupLevel2 = new ArrayList<PDFBlock>() ;
			onLevel1 = true ;
		}

		return ret ;
	}

	private List<PDFBlock> createGroup(List<PDFBlock> level1, List<PDFBlock> level2) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;
		
		for ( int i=0 ; i<level1.size() ; i++ )
		{
			PDFBlock block1 = level1.get(i) ;
			
			List<PDFLine> level1Lines = getLevelLinesMap().containsKey(new Integer(1)) ? getLevelLinesMap().get(new Integer(1)) : new ArrayList<PDFLine>() ;
			level1Lines.addAll(block1.getLines()) ;
			getLevelLinesMap().put(new Integer(1), level1Lines) ;

			if ( level2.size() != 0 )
			{
				for ( int j=0 ; j<level2.size() ; j++ )
				{
					PDFBlock block2 = level2.get(j) ;
					
					List<PDFLine> level2Lines = getLevelLinesMap().containsKey(new Integer(2)) ? getLevelLinesMap().get(new Integer(2)) : new ArrayList<PDFLine>() ;
					level2Lines.addAll(block2.getLines()) ;
					getLevelLinesMap().put(new Integer(2), level2Lines) ;
					
					PDFBlock mergedBlock = mergeBlocks(block1, block2) ;
					ret.add(mergedBlock) ;
				}
			}
			else
			{
				ret.add(block1) ;
				continue ;
			}
		}

		return ret ;
	}

	private static PDFBlock mergeBlocks(PDFBlock block1, PDFBlock block2) 
	{
		List<PDFLine> newLines = new ArrayList<PDFLine>() ;
		newLines.addAll(block1.getLines()) ;
		newLines.addAll(block2.getLines()) ;

		Integer pageNo = newLines.get(0).getPageNo() ;

		PDFBlock newBlock = new PDFBlock(pageNo, newLines) ;

		return newBlock ;
	}

	private static boolean isGroupOfSize(int totalLevels, List<Integer> individualSizes, List<List<RowSegmenterPattern>> groupPattern) 
	{
		if ( totalLevels != groupPattern.size() )
			return false ;

		if ( groupPattern.size() != individualSizes.size() )
			return false ;

		for ( int i=0 ; i<groupPattern.size() ; i++ )
		{
			if ( groupPattern.get(i).size() != individualSizes.get(i) )
				return false ;
		}

		return true ;
	}

	private static boolean arePatternsSameType(List<List<RowSegmenterPattern>> groupPattern, PatternProgressUnit unit) 
	{
		for ( int i=0 ; i<groupPattern.size() ; i++ )
		{
			List<RowSegmenterPattern> thisLevel = groupPattern.get(i) ;
			for ( int j=0 ; j<thisLevel.size() ; j++ )
			{
				RowSegmenterPattern pattern = thisLevel.get(j) ;

				if ( !pattern.getProgressUnit().equals(unit) )
					return false ;
			}
		}

		return true ;
	}

	private static List<List<RowSegmenterPattern>> createGroupPattern(String rule) 
	{
		List<List<RowSegmenterPattern>> ret = new ArrayList<List<RowSegmenterPattern>>() ;

		String[] split = rule.split(";") ;

		for ( int i=0 ; i<split.length ; i++ )
		{
			String thisSplit = split[i] ;

			List<RowSegmenterPattern> thisLevel = RowSegmenterPattern.parseRowSegmentationPattern(thisSplit) ;

			if ( thisLevel.size() != 0 )
				ret.add(thisLevel) ;
		}

		return ret ;
	}

	private static List<PDFBlock> createPatternBasedRows(List<PDFBlock> headerRemovedBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, List<PDFBlock> totalEndBlocks, MetaData rule) 
	{
		if ( PATTERN_SEGMENTATION_DEBUG )
			System.out.println("\n\n\nPattern-based Rows Debug ....\n\n") ;

		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		List<RowSegmenterPattern> pattern = RowSegmenterPattern.parseRowSegmentationPattern(rule.getRowSegmentationRule()) ;
		boolean patternSizeOne = pattern.size() == 1 ;
		boolean allParas = arePatternSameType(pattern, RowSegmenterPattern.PatternProgressUnit.PARA) ;
		boolean allLines = arePatternSameType(pattern, RowSegmenterPattern.PatternProgressUnit.LINE) ;

		if ( PATTERN_SEGMENTATION_DEBUG )
		{
			System.out.println("Pattern: " + pattern) ;
			System.out.println("\tIs Pattern Size One: " + patternSizeOne) ;
			System.out.println("\tAre all patterns Paragraphs: " + allParas) ;
			System.out.println("\tAre all patterns Lines: " + allLines) ;
		}

		if ( !allParas && !allLines )
		{
			if ( PATTERN_SEGMENTATION_DEBUG )
				System.err.println("Un-handled Pattern ..." + pattern) ;

			return new ArrayList<PDFBlock>(headerRemovedBlocks) ;
		}
		
		List<PDFBlock> processingBlocks = allParas ? new ArrayList<PDFBlock>(headerRemovedBlocks) : createLineBlocks(headerRemovedBlocks, headingBlocks, totalStartBlocks, totalEndBlocks) ;

		List<List<PDFBlock>> groups = new ArrayList<List<PDFBlock>>() ;
		List<PDFBlock> thisGroup = new ArrayList<PDFBlock>() ;
		boolean sentAgain = false ;
		
		
		for ( int i=0 ; i<processingBlocks.size() ; i++ )
		{
			PDFBlock block = processingBlocks.get(i) ;

			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\nBlock: " + block.getBlockString()) ;
			
			if ( headingBlocks.contains(block) || totalStartBlocks.contains(block) || totalEndBlocks.contains(block) )
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\tFound Heading or Total Block ...") ;

				if ( thisGroup.size() != 0 )
				{
					if ( PATTERN_SEGMENTATION_DEBUG )
						System.out.println("\t\tCreating new group from previous blocks ... " + thisGroup) ;

					groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
					thisGroup = new ArrayList<PDFBlock>() ;
				}

				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\tCreating new Group from this block ...") ;

				thisGroup.add(block) ;
				groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
				thisGroup = new ArrayList<PDFBlock>() ;

				sentAgain = false ;

				continue ;
			}

			RowSegmenterPattern nextPattern = findAppropriatePattern(thisGroup, pattern) ;
			
			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\tAppropriate Pattern: " + nextPattern) ;

			if ( nextPattern == null )
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\t\tNext pattern is null ... so close this group and start with this block again ....") ;
				
				groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
				thisGroup = new ArrayList<PDFBlock>() ;

				sentAgain = true ;

				i-- ;

				continue ;
			}

			boolean blockSatisfiesPattern = doesBlockSatisfyPattern(block, nextPattern) ;

			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\tThis block satisfies this pattern ... " + blockSatisfiesPattern) ;

			if ( blockSatisfiesPattern && patternSizeOne)
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\t\tPattern is of size 1 and Didn't find the start of pattern ... wrap this group and create a new group with this block ...") ;
				
				groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
				thisGroup = new ArrayList<PDFBlock>() ;

				thisGroup.add(block) ;

				sentAgain = false ;

				continue ;
			}
			else if ( blockSatisfiesPattern && !patternSizeOne )
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\t\tPattern is not of size 1, therefore, add this block to the current group ...") ;
				
				thisGroup.add(block) ;
				
				sentAgain = false ;

				continue ;
			}
			
			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\tPattern didn't match ... ") ;
			
			if ( patternSizeOne )
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\t\tPattern size is 1, therefore, adding it into the current group ...") ;
				
				thisGroup.add(block) ;

				sentAgain = false ;

				continue ;
			}

			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\t\tClosing this group ....") ;
			
			groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
			thisGroup = new ArrayList<PDFBlock>() ;

			if ( sentAgain )
			{
				if ( PATTERN_SEGMENTATION_DEBUG )
					System.out.println("\tSent again ... therefore, adding this in the new group ... ") ;

				thisGroup.add(block) ;
				groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
				thisGroup = new ArrayList<PDFBlock>() ;

				sentAgain = false ;

				continue ;	
			}

			sentAgain = true ;

			i-- ;
		}

		if ( thisGroup.size() != 0 )
		{
			if ( PATTERN_SEGMENTATION_DEBUG )
				System.out.println("\n\tAdd left-over Group ...") ;
			groups.add(new ArrayList<PDFBlock>(thisGroup)) ;
			thisGroup = new ArrayList<PDFBlock>() ;
		}
		
		if ( PATTERN_SEGMENTATION_DEBUG )
		System.out.println("Done Grouping ...") ;
		
		for ( int i=0 ; i<groups.size() ; i++ )
		{
			List<PDFBlock> group = groups.get(i) ;
			if ( group.size() == 0 )
				continue ;

			List<PDFLine> newLines = new ArrayList<PDFLine>() ;
			
			for ( int j=0 ; j<group.size() ; j++ )
			{
				PDFBlock block = group.get(j) ;
				newLines.addAll(block.getLines()) ;
			}

			if ( newLines.size() == 0 )
				continue ;

			Integer pageNo = newLines.get(0).getPageNo() ;

			PDFBlock newBlock = new PDFBlock(pageNo, newLines) ;
			ret.add(newBlock) ;
		}
		
		if ( PATTERN_SEGMENTATION_DEBUG )
		System.out.println("Done ...") ;

		return ret ;
	}

	private static boolean doesBlockSatisfyPattern(PDFBlock block, RowSegmenterPattern nextPattern) 
	{	
		HashSet<DataType> allTypes = new HashSet<DataType>() ;
		Pair<DataType, DataType> firstLastType = BlockTypeFinder.findAllDataTypes(block, allTypes) ;
		
		DataType firstType = firstLastType.getA() ;
		DataType lastType = firstLastType.getB() ;

		/*System.out.println("First Type = " + firstType) ;
		System.out.println("Last Type = " + lastType) ;
		System.out.println("All Types = " + allTypes) ;*/
		
		if(block.getBlockString().toLowerCase().contains("total") || block.getBlockString().contains("Item"))
		{
			return true;
		}
		
		if ( nextPattern.getPatternType().equals(RowSegmenterPattern.PatternType.STARTS_WITH) && firstType.equals(nextPattern.getDataType()) )
			return true ;
		else if ( nextPattern.getPatternType().equals(RowSegmenterPattern.PatternType.ENDS_WITH) && lastType.equals(nextPattern.getDataType()) )
			return true ;
		else if ( nextPattern.getPatternType().equals(RowSegmenterPattern.PatternType.CONTAINS) && allTypes.contains(nextPattern.getDataType()) )
			return true ;

		return false ;
	}

	private static RowSegmenterPattern findAppropriatePattern(List<PDFBlock> thisGroup, List<RowSegmenterPattern> pattern) 
	{
		if ( pattern.size() == 1 )
			return pattern.get(0) ;

		if ( thisGroup.size() >= pattern.size() )
			return null ;

		return pattern.get(thisGroup.size()) ;
	}

	private static List<PDFBlock> createLineBlocks(List<PDFBlock> headerRemovedBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, List<PDFBlock> totalEndBlocks) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<headerRemovedBlocks.size() ; i++ )
		{
			PDFBlock block = headerRemovedBlocks.get(i) ;

			if ( headingBlocks.contains(block) || totalStartBlocks.contains(block) || totalEndBlocks.contains(block) )
			{
				ret.add(block) ;
				continue ;
			}

			List<PDFLine> lines = block.getLines() ;

			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				Integer pageNo = line.getPageNo() ;
				
				List<PDFLine> newLines = new ArrayList<PDFLine>() ;
				newLines.add(line) ;
				
				PDFBlock newBlock = new PDFBlock(pageNo, newLines) ;
				ret.add(newBlock) ;
			}
		}

		return ret ;
	}

	private static boolean arePatternSameType(List<RowSegmenterPattern> pattern, PatternProgressUnit unit) 
	{
		for ( int i=0 ; i<pattern.size() ; i++ )
		{
			RowSegmenterPattern thisPattern = pattern.get(i) ;

			if ( !thisPattern.getProgressUnit().equals(unit) )
				return false ;
		}

		return true ;
	}

	private static List<PDFBlock> createOneParaOneRow(List<PDFBlock> headerRemovedBlocks) 
	{	
		return new ArrayList<PDFBlock>(headerRemovedBlocks) ;
	}

	private static List<PDFBlock> createOneLineOneRow(List<PDFBlock> headerRemovedBlocks, List<PDFBlock> headingBlocks, List<PDFBlock> totalStartBlocks, List<PDFBlock> totalEndBlocks) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<headerRemovedBlocks.size() ; i++ )
		{
			PDFBlock block = headerRemovedBlocks.get(i) ;

			if ( headingBlocks.contains(block) || totalStartBlocks.contains(block) || totalEndBlocks.contains(block) )
			{
				ret.add(block) ;
				continue ;
			}

			List<PDFLine> lines = block.getLines() ;

			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;

				List<PDFLine> newLines = new ArrayList<PDFLine>() ;
				newLines.add(line) ;

				PDFBlock newBlock = new PDFBlock(line.getPageNo(), newLines) ;
				ret.add(newBlock) ;
			}
		}

		return ret ;
	}

	private List<PDFBlock> createHeaderRemovedBlocks(List<PDFBlock> allBlocks, List<PDFBlock> headerBlocks) 
	{
		// System.out.println("Header Blocks: " + headerBlocks) ;

		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<allBlocks.size() ; i++ )
		{
			PDFBlock block = allBlocks.get(i) ;

			if ( headerBlocks.contains(block) )
			{
				// System.out.println("Removing Header-Block: " + block.getBlockString()) ;
				continue ;
			}

			ret.add(block) ;
		}

		return ret ;
	}

	public List<PDFBlock> getAllBlocks() {
		return allBlocks;
	}

	public void setAllBlocks(List<PDFBlock> allBlocks) {
		this.allBlocks = allBlocks;
	}

	public List<PDFBlock> getHeadingBlocks() {
		return headingBlocks;
	}

	public void setHeadingBlocks(List<PDFBlock> headingBlocks) {
		this.headingBlocks = headingBlocks;
	}

	public List<PDFBlock> getTotalStartBlocks() {
		return totalStartBlocks;
	}

	public void setTotalStartBlocks(List<PDFBlock> totalStartBlocks) {
		this.totalStartBlocks = totalStartBlocks;
	}

	public List<PDFBlock> getTotalEndBlocks() {
		return totalEndBlocks;
	}

	public void setTotalEndBlocks(List<PDFBlock> totalEndBlocks) {
		this.totalEndBlocks = totalEndBlocks;
	}

	public MetaData getRule() {
		return rule;
	}

	public void setRule(MetaData rule) {
		this.rule = rule;
	}

	public List<PDFBlock> getHeaderBlocks() {
		return headerBlocks;
	}

	public void setHeaderBlocks(List<PDFBlock> headerBlocks) {
		this.headerBlocks = headerBlocks;
	}

	public List<PDFBlock> getRowBlocks() {
		return rowBlocks;
	}

	public void setRowBlocks(List<PDFBlock> rowBlocks) {
		this.rowBlocks = rowBlocks;
	}

	public List<PDFBlock> getHeaderRemovedBlocks() {
		return headerRemovedBlocks;
	}

	public void setHeaderRemovedBlocks(List<PDFBlock> headerRemovedBlocks) {
		this.headerRemovedBlocks = headerRemovedBlocks;
	}

	public TreeMap<Integer, List<PDFLine>> getLevelLinesMap() {
		return levelLinesMap;
	}

	public void setLevelLinesMap(TreeMap<Integer, List<PDFLine>> levelLinesMap) {
		this.levelLinesMap = levelLinesMap;
	}
}
