package com.rage.extraction.statements.detectors.pdf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.SectionStartMatch;
import com.rage.extraction.statements.attributes.StatementAttributes;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.detectors.text.RegularSentenceDetector;
import com.rage.extraction.statements.detectors.text.SectionsStartDetector;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.Row;
import com.rage.extraction.statements.extract.pdf.RowSegmentationType;
import com.rage.extraction.statements.extract.pdf.SectionSpreader;
import com.rage.extraction.statements.ontology.EntitySuffixOntology;
import com.rage.extraction.statements.ontology.MetaData;
import com.rage.extraction.statements.ontology.RegularSentenceOntology;
import com.rage.extraction.statements.ontology.SectionOntology;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.reprocess.ReprocessMetadata;
import com.rage.extraction.statements.uitls.AccentsRemover;
import com.rage.extraction.statements.uitls.CleanEnumeratedText;
import com.rage.extraction.statements.uitls.PDFDocumentLoader;
import com.rage.extraction.statements.uitls.Utilities;

public class SectionBoundaryDetector 
{
	private static Boolean DEBUG_PRELIMINARY = Boolean.FALSE ;
	private static Boolean DEBUG = Boolean.FALSE ;
	private static Boolean DEBUG_MERGE_SUBSEQUENT_SECTIONS = Boolean.FALSE ;
	private static Boolean DEBUG_LAST_PAGE_GARBAGE = Boolean.FALSE ;
	private static Boolean DEBUG_PAGE_TOP_X_CHECKER = Boolean.FALSE ;
	private static TreeSet<String> TABLE_KEYWORDS_CONTAINS = new TreeSet<String>(Arrays.asList(new String[] {
			"INDEX TO FINANCIAL STATEMENTS", "INDEPENDENT AUDITOR�S REPORT","INDEX TO CONSOLIDATED FINANCIAL STATEMENTS"})) ;
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SectionBoundaryDetector.class);
	private  static String statementQuality = "Co-Prepd";
	private static  List<String> statementQualityMeta;
	private static int noOfneighbourhoodLines = -1;
	private static  LinkedHashSet<String>  notesKeywords;
	private static LinkedHashSet<String> noteKeywordList= null;
	//private static TreeSet<String>  FOOTER_DATA_KEYWORDS = HeaderFooterReader.getKeywords();
	private static boolean isTableOfContentPage(String input)
	{
		for ( String keyword : TABLE_KEYWORDS_CONTAINS )
		{
			if (input.toLowerCase().trim().contains(keyword.trim().toLowerCase()))
				return true ;
		}

		return false ;
	}
	private static void getAtrributesMeta() {
		try {
			StatementAttributes attributes = new StatementAttributes();
			statementQualityMeta = attributes.getStatementQuality();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static List<Section> detectSectionBoundaries(TreeMap<Integer, PageParse> pageParsesMap)
	{
		List<Section> sections = createPreliminarySections(pageParsesMap) ;

		if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Chinese"))
			FinancialStatementExtractor.createBlocksForSectionPages(sections,FinancialStatementExtractor.getFileName());

		//Ignore section if first page is not tabular
		sections = ignoreFalsePositvesections(sections);
		//Ignore section if first page is not tabular
		sections = mergeConsecutiveSectionsOnSubsequentPages(sections) ;
		//setInstanceID(sections);
		sections = removeLastPageGarbage(sections, pageParsesMap) ;
		return sections ;
	}


	public static  List<Section> ignoreFalsePositvesections(List<Section> sections)
	{
		List<Section> curreSections = new ArrayList<Section>();
		for( Section section : sections)
		{
			List<PDFLine> lines = section.getLines() ;
			List<PDFBlock> blocks = section.getBlocks() ;
			Pair<Float,Float> sectionXBound=SectionSpreader.getSectionXBound(lines);
			Boolean isFlasePositveSection = false;
			List<Row> rows = null;
			SectionSpreader.getLanguages();
			int maxCol = 0;
			if(section.getSectionName().equalsIgnoreCase("SUPPL") || section.getSectionName().equalsIgnoreCase("znotes"))
			{
				continue;
			}
			if(section.getSectionName().equalsIgnoreCase("fnotes") || section.getSectionName().equalsIgnoreCase("fnotes_end"))
			{
				curreSections.add(section);
				continue;
			}
			if(section.getKeyword().getRowSegmentationType()!=null  && section.getKeyword().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW))
			{
				rows = SectionSpreader.createPreliminaryRowsbyPara(lines,blocks) ;
			}
			else
			{
				rows = SectionSpreader.createPreliminaryRows(lines) ;
				if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
					rows = SectionSpreader.combineRowsByCase(rows) ; 
			}
			SectionSpreader.reCreateRowLines(rows) ;
			SectionSpreader.removeFalsePositiveTypes(rows) ;
			TreeMap<Integer, List<Row>> pageRowsMap = SectionSpreader.createPageRowsMap(rows) ;
			section.setPageRowsMap(pageRowsMap);
			reCreateChunks(rows) ;
			int ct= 0;
			for ( Integer pageNo : pageRowsMap.keySet() )
			{
				if(ct==0)
				{
					List<Row> pageRows = pageRowsMap.get(pageNo) ;

					logger.info("Page No: " + pageNo) ;
					HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
					List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
					List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
					SectionSpreader.spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
					SectionSpreader.removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, rows,sectionXBound) ;
					SectionSpreader.printNumericColumns(numericColumns, numericBounds) ;
					if (FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") && SectionSpreader.isSectionFalsePositive(pageRows) &&  !section.getSectionName().equalsIgnoreCase("SUPPL") && !section.getSectionName().equalsIgnoreCase("SD") && !FinancialStatementExtractor.getLanguage().contains("ITR"))
					{
						logger.info("False Positive Section .... ") ;
						ct++;
						isFlasePositveSection = true;
						break;
					} 
					List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
					List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
					HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;
					SectionSpreader.spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, null, numericColumns, numericBounds, wordRowsMap,null) ;
					TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = SectionSpreader.createRowColumnChunksMap(pageRows, chunkColumns, chunkRowsMap, null) ;
					SectionSpreader.printRowColumnChunks(rowColumnChunksMap) ;
					maxCol = SectionSpreader.getMaxCol(rowColumnChunksMap, maxCol);

					if (maxCol == 1 || maxCol == 0)
					{
						logger.info("False Positive Section .... has MaxCol"+maxCol) ;
						System.out.println("False Positive Section .... has MaxCol"+maxCol) ;
						ct++;
						isFlasePositveSection = true;
						break;}
				}
				ct++;
			}
			if(!isFlasePositveSection)
				curreSections.add(section);

		}
		return curreSections;
	}


	private static void reCreateChunks(List<Row> rows) {
		// TODO Auto-generated method stub

	}
	public static List<Section> detectSectionSupplBoundaries(TreeMap<Integer, PageParse> pageParsesMap,List<MetaData> supplList,List<Section> prevSections)
	{
		List<Section> sections = createSupplementarySections(pageParsesMap,supplList, prevSections) ;
		return sections;
	}

	private static List<Section> createSupplementarySections(
			TreeMap<Integer, PageParse> pageParsesMap,List<MetaData> supplList,List<Section> prevSections) {
		List<Section> sections = new ArrayList<Section>() ;

		if ( pageParsesMap == null )
			return sections ;
		processParagraphs(pageParsesMap, prevSections, sections,
				supplList);

		processTabular(pageParsesMap, prevSections, sections, supplList);

		return sections;
	}




	private static void processParagraphs(
			TreeMap<Integer, PageParse> pageParsesMap,
			List<Section> prevSections, List<Section> sections,
			List<MetaData> supplList) {
		for(MetaData meta:supplList)
		{
			String scope = meta.getScope().trim();

			if(!scope.equalsIgnoreCase("Tabular"))
			{
				isSectionMatch(meta, sections, pageParsesMap,prevSections);
			}
		}
	}
	private static void processTabular(
			TreeMap<Integer, PageParse> pageParsesMap,
			List<Section> prevSections, List<Section> sections,
			List<MetaData> supplList) {
		for(MetaData meta:supplList)
		{
			String scope = meta.getScope().trim();

			if(scope.equalsIgnoreCase("Tabular"))
			{
				isSectionMatchTabular(meta, sections,pageParsesMap,prevSections);	
			}

		}
	}
	private static void isSectionMatch(MetaData mt, List<Section> sections,
			TreeMap<Integer, PageParse> pageParsesMap, List<Section> prevSections) {

		Section currentSection = null;
		ReprocessMetadata reprocessMeta = null;

		String keyword = mt.getKeyword();
		for ( Integer pageNo : pageParsesMap.keySet() )
		{
			if ( DEBUG_PRELIMINARY )
				System.out.println("Page No: " + pageNo) ;

			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFBlock> blocks = parse.getPageBlocks();
			for(PDFBlock block:blocks)	
			{
				if(!isSectionContainsBlock(prevSections, block) &&!isSectionContainsBlock(sections, block) && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(keyword.toLowerCase()) && block.getLines().size()>1 )
				{
					if(mt.getScope().equalsIgnoreCase("Paragraph"))
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

						List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
						thisLines.addAll(block.getLines()) ;

						if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection("SUPPL");
							reprocessMeta.setSubSection(mt.getSubSection());
							reprocessMeta.setScope(mt.getScope());
							reprocessMeta.setStrtKeyword(keyword);
							reprocessMeta.setStrtPage(pageNo);
							reprocessMeta.setEndPage(pageNo);
							reprocessMeta.setEndKeyword(keyword);
							reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
							reprocessMeta.setColumnNo(0);
							reprocessMeta.setParseValue(mt.getParseValue());

						}
						List<PDFBlock> thisBlocks = new ArrayList<PDFBlock> ();
						thisBlocks.add(block);
						currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),mt.getKeyword(),thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
						currentSection.setSubSection(mt.getSubSection());
						currentSection.setScope(mt.getScope());
						currentSection.setReprocessMeta(reprocessMeta);
						currentSection.setSectionName(mt.getSection());
						currentSection.setParseValue(mt.getParseValue());
						sections.add(currentSection);	
					}
					else
					{
						if(mt.getScope().equalsIgnoreCase("Sentence"))
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

							List<PDFLine> thisLines = new ArrayList<PDFLine>() ;

							for(PDFLine line: block.getLines())
							{
								if(!line.getLine().contains("."))
								{
									thisLines.add(line);
								}
								else
								{
									thisLines.add(line);
									break;
								}
							}

							if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
							{
								reprocessMeta = new ReprocessMetadata();
								reprocessMeta.setSection("SUPPL");
								reprocessMeta.setStrtKeyword(keyword);
								reprocessMeta.setStrtPage(pageNo);
								reprocessMeta.setEndPage(pageNo);
								reprocessMeta.setEndKeyword(keyword);
								reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
								reprocessMeta.setSubSection(mt.getSubSection());
								reprocessMeta.setScope(mt.getScope());
								reprocessMeta.setColumnNo(0);
								reprocessMeta.setParseValue(mt.getParseValue());
							}
							List<PDFBlock> thisBlocks = new ArrayList<PDFBlock> ();
							thisBlocks.add(block);
							currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),mt.getKeyword(),thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
							currentSection.setSubSection(mt.getSubSection());
							currentSection.setScope(mt.getScope());
							currentSection.setSectionName(mt.getSection());
							currentSection.setParseValue(mt.getParseValue());
							currentSection.setReprocessMeta(reprocessMeta);
							sections.add(currentSection);	
						}
					}
					if(currentSection!=null)
						return;
				}
			}
		}
	}


	private static void isSectionMatch(ReprocessMetadata mt, List<Section> sections,
			TreeMap<Integer, PageParse> pageParsesMap,List<Section> prevSections) {
		Section currentSection = null;
		ReprocessMetadata reprocessMeta = null;

		String keyword = mt.getStrtKeyword();
		String endKeyword = mt.getEndKeyword();
		Integer strtPage = mt.getStrtPage();
		Integer endPage = mt.getEndPage();
		List<PDFLine> thisLines = new ArrayList<PDFLine>() ;

		for ( Integer pageNo : pageParsesMap.keySet() )
		{
			if(pageNo<strtPage)
				continue;
			if ( DEBUG_PRELIMINARY )
				System.out.println("Page No: " + pageNo) ;

			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFBlock> blocks = parse.getPageBlocks();
			List<PDFBlock> thisBlocks = new ArrayList<PDFBlock> ();

			for(PDFBlock block:blocks)	
			{
				if(!keyword.toLowerCase().trim().equalsIgnoreCase(endKeyword.trim()))
				{
					if(!isSectionContainsBlock(prevSections, block) && !isSectionContainsBlock(sections, block) && pageNo.intValue()==strtPage.intValue()  && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(keyword.toLowerCase()) )
					{
						thisLines.addAll(block.getLines()) ;
					}

					if(pageNo.intValue()==endPage.intValue() && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(endKeyword.toLowerCase()))
					{
						if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection("SUPPL");
							reprocessMeta.setSubSection(mt.getSubSection());
							reprocessMeta.setScope(mt.getScope());
							reprocessMeta.setStrtKeyword(keyword);
							reprocessMeta.setStrtPage(pageNo);
							reprocessMeta.setEndPage(pageNo);
							reprocessMeta.setEndKeyword(keyword);
							reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
							reprocessMeta.setColumnNo(0);
							reprocessMeta.setParseValue(mt.getParseValue());

						}
						if(thisLines.size()>0)
						{
							thisBlocks.add(block);
							thisLines.addAll(block.getLines()) ;
						}						
						currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),keyword,thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
						currentSection.setSubSection(mt.getSubSection());
						currentSection.setScope(mt.getScope());
						currentSection.setReprocessMeta(reprocessMeta);
						currentSection.setSectionName(mt.getSection());
						currentSection.setParseValue(mt.getParseValue());
						sections.add(currentSection);	
						return;
					}

					if(thisLines.size()>0)
					{
						thisBlocks.add(block);
						thisLines.addAll(block.getLines()) ;
					}
				}
				else
				{
					if(!isSectionContainsBlock(prevSections, block)  && !isSectionContainsBlock(sections, block) && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(keyword.toLowerCase()) )
					{
						if(mt.getScope().equalsIgnoreCase("Paragraph"))
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

							thisLines = new ArrayList<PDFLine>() ;
							thisLines.addAll(block.getLines()) ;

							if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
							{
								reprocessMeta = new ReprocessMetadata();
								reprocessMeta.setSection("SUPPL");
								reprocessMeta.setSubSection(mt.getSubSection());
								reprocessMeta.setScope(mt.getScope());
								reprocessMeta.setStrtKeyword(keyword);
								reprocessMeta.setStrtPage(pageNo);
								reprocessMeta.setEndPage(pageNo);
								reprocessMeta.setEndKeyword(keyword);
								reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
								reprocessMeta.setColumnNo(0);
								reprocessMeta.setParseValue(mt.getParseValue());

							}
							thisBlocks = new ArrayList<PDFBlock> ();
							thisBlocks.add(block);
							currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),keyword,thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
							currentSection.setSubSection(mt.getSubSection());
							currentSection.setScope(mt.getScope());
							currentSection.setReprocessMeta(reprocessMeta);
							currentSection.setSectionName(mt.getSection());
							currentSection.setParseValue(mt.getParseValue());
							sections.add(currentSection);	
						}
						else
						{
							if(mt.getScope().equalsIgnoreCase("Sentence"))
							{
								if ( DEBUG_PRELIMINARY )
									System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

								thisLines = new ArrayList<PDFLine>() ;

								for(PDFLine line: block.getLines())
								{
									if(!line.getLine().contains("."))
									{
										thisLines.add(line);
									}
									else
									{
										thisLines.add(line);
										break;
									}
								}

								if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
								{
									reprocessMeta = new ReprocessMetadata();
									reprocessMeta.setSection("SUPPL");
									reprocessMeta.setStrtKeyword(keyword);
									reprocessMeta.setStrtPage(pageNo);
									reprocessMeta.setEndPage(pageNo);
									reprocessMeta.setEndKeyword(keyword);
									reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
									reprocessMeta.setSubSection(mt.getSubSection());
									reprocessMeta.setScope(mt.getScope());
									reprocessMeta.setColumnNo(0);
									reprocessMeta.setParseValue(mt.getParseValue());
								}
								thisBlocks = new ArrayList<PDFBlock> ();
								thisBlocks.add(block);
								currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),keyword,thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
								currentSection.setSubSection(mt.getSubSection());
								currentSection.setScope(mt.getScope());
								currentSection.setSectionName(mt.getSection());
								currentSection.setParseValue(mt.getParseValue());
								currentSection.setReprocessMeta(reprocessMeta);
								sections.add(currentSection);	

							}
						}

						if(currentSection!=null)
							return;
					}
				}
			}
		}
	}

	private static void isSectionMatchTabular(MetaData mt,
			List<Section> sections, TreeMap<Integer, PageParse> pageParsesMap, List<Section> prevSections) {
		Section currentSection;
		ReprocessMetadata reprocessMeta = null;
		String keyword = mt.getKeyword();
		String endKeyword = "";
		int ct=0;
		List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
		List<PDFBlock> thisBlocks = new ArrayList<PDFBlock> ();

		Boolean endFound = false,foundStart=false;
		for ( Integer pageNo : pageParsesMap.keySet() )
		{
			if ( DEBUG_PRELIMINARY )
				System.out.println("Page No: " + pageNo) ;

			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFBlock> blocks = parse.getPageBlocks();
			for(PDFBlock block:blocks)
			{
				List<PDFLine> lines = block.getLines();

				if(!isSectionContainsBlock(prevSections, block) && !isSectionContainsBlock(sections, block) && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(keyword.toLowerCase()))
				{
					ct++;
					if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
					{
						reprocessMeta = new ReprocessMetadata();
						reprocessMeta.setStrtPage(pageNo);
					}
					for(PDFLine line:lines)
					{
						if(line.getChunks().size()>0)
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;
							foundStart = true;
							continue;
							/*	thisLines.add(line) ;
							thisBlocks.add(block);*/
						}
					}
				}

				if(foundStart && !isSectionContainsBlock(sections, block) && !isSectionContainsBlock(prevSections, block))
				{
					ct++;
					for(PDFLine line:lines)
					{
						if(line.getChunks().size()>0)
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

							thisLines.add(line) ;
							thisBlocks.add(block);

						}

						if(thisLines.size()>40)
						{
							if(line.getChunks().size()==0)
							{
								endFound = true;
								endKeyword = line.getLine();
								break;
							}
						}



						if(ct>3 && isLongChunkContains(line))
						{
							endFound = true;
							endKeyword = line.getLine();
							break;
						}

					}

				}
				if(endFound)
					break;

			}

			if(thisLines.size()>0 && endFound)
			{
				if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
				{
					reprocessMeta.setSection("SUPPL");
					reprocessMeta.setSubSection(mt.getSubSection());
					reprocessMeta.setScope(mt.getScope());
					reprocessMeta.setStrtKeyword(keyword);
					reprocessMeta.setEndPage(pageNo);
					reprocessMeta.setEndKeyword(endKeyword);
					reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
					reprocessMeta.setColumnNo(0);
					reprocessMeta.setParseValue(mt.getParseValue());
				}

				currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),mt.getKeyword(),thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
				currentSection.setSubSection(mt.getSubSection());
				currentSection.setScope(mt.getScope());
				currentSection.setReprocessMeta(reprocessMeta);
				currentSection.setSectionName(mt.getSection());
				currentSection.setParseValue(mt.getParseValue());
				sections.add(currentSection);
				return;
			}
		}
	}

	private static boolean isLongChunkContains(PDFLine line) {
		if(line.getChunks().size()>10)
			return true;
		for(PDFChunk chunk:line.getChunks())
		{
			if(chunk.getChunk().trim().length()>40)
			{
				return true;
			}
		}
		return false;
	}
	private static void isSectionMatchTabular(ReprocessMetadata mt,
			List<Section> sections, TreeMap<Integer, PageParse> pageParsesMap, List<Section> prevSections) {
		Section currentSection;
		ReprocessMetadata reprocessMeta = null;
		String keyword = mt.getStrtKeyword().trim();
		String endKeyword =  mt.getEndKeyword().trim();
		Integer startPage =  mt.getStrtPage();
		Integer endPage =  mt.getEndPage();


		List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
		List<PDFBlock> thisBlocks = new ArrayList<PDFBlock> ();
		Boolean endFound = false, found =false;
		for ( Integer pageNo : pageParsesMap.keySet() )
		{
			if ( DEBUG_PRELIMINARY )
				System.out.println("Page No: " + pageNo) ;

			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFBlock> blocks = parse.getPageBlocks();
			if(pageNo.intValue()<startPage.intValue())
				continue;

			for(PDFBlock block:blocks)
			{
				List<PDFLine> lines = block.getLines();

				if(pageNo.intValue()==startPage.intValue() && !isSectionContainsBlock(prevSections, block) && !isSectionContainsBlock(sections, block) && block.toString().toLowerCase().replaceAll("\\===== ", "").contains(keyword.toLowerCase())  )
				{
					if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
					{
						reprocessMeta = new ReprocessMetadata();
						reprocessMeta.setStrtPage(pageNo);
					}
					for(PDFLine line:lines)
					{
						if(line.getChunks().size()>0)
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;
							found = true;
							/*	thisLines.add(line) ;
							thisBlocks.add(block);*/
							continue;
						}
					}
				}

				if(found && !isSectionContainsBlock(sections, block) && !isSectionContainsBlock(prevSections, block))
				{
					for(PDFLine line:lines)
					{
						if(line.getChunks().size()>0)
						{
							if ( DEBUG_PRELIMINARY )
								System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

							thisLines.add(line) ;
							thisBlocks.add(block);

						}

						if(endPage.intValue()==pageNo.intValue() && line.toString().toLowerCase().replaceAll("\\===== ", "").contains(endKeyword.toLowerCase()))
						{
							endFound = true;
							break;
						}
					}
					if(endFound)
						break;
				}

			}

			if(thisLines.size()>0 && endFound)
			{
				if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
				{
					reprocessMeta.setSection("SUPPL");
					reprocessMeta.setSubSection(mt.getSubSection());
					reprocessMeta.setScope(mt.getScope());
					reprocessMeta.setStrtKeyword(keyword);
					reprocessMeta.setEndPage(endPage);
					reprocessMeta.setEndKeyword(endKeyword);
					reprocessMeta.setRowSegmentationType(mt.getRowSegmentationType());
					reprocessMeta.setColumnNo(0);
					reprocessMeta.setParseValue(mt.getParseValue());
				}

				currentSection = new Section(keyword, thisLines, new SectionStartMatch(mt.getSection(),keyword,thisLines.get(0).getLine(),"",mt.getRowSegmentationType(),mt.getColumnNo()),0,thisBlocks) ;
				currentSection.setSubSection(mt.getSubSection());
				currentSection.setScope(mt.getScope());
				currentSection.setReprocessMeta(reprocessMeta);
				currentSection.setSectionName(mt.getSection());
				currentSection.setParseValue(mt.getParseValue());
				sections.add(currentSection);
				return;
			}
		}
	}


	private static Boolean isSectionContainsBlock(List<Section> prevSections,
			PDFBlock block) {
		for(Section prevSection : prevSections)
		{
			if(prevSection!=null && !prevSection.getSectionName().equalsIgnoreCase("znotes") && prevSection.getBlocks().contains(block))
			{
				return true;
			}

		}

		return false;
	}



	public static void setInstanceID(List<Section> sections) {
		int ct = 0;
		for(Section section : sections)
		{
			ct++;
			section.setInstanceID(Integer.valueOf(ct));
			ReprocessMetadata rm = section.getReprocessMeta();	
			rm.setInstanceID(ct);
		}
	}

	private static boolean blockContainsFooterData(PDFBlock block)
	{
		String strBlock = block.getBlockString() ;

		for ( String keyword : RegularSentenceOntology.getIgnoreKeywords() )
		{
			if ( strBlock.toUpperCase().contains(keyword.toUpperCase()) )
			{
				if ( DEBUG )
					System.out.println("\t\t\tContains Footer Text ..."+keyword) ;

				return true ;
			}
		}

		return false;
	}

	public static List<Section> detectSectionReprocessBoundaries(TreeMap<Integer, PageParse> pageParsesMap, DataWriterOracle dwOracle, DataWriterSql dwSql)
	{
		//	List<Section> sections = createPreliminarySections(pageParsesMap) ;

		List<Section> sections = createReprocessPreliminarySections(pageParsesMap,dwOracle,dwSql);
		if(sections!=null && !containsSUPPL(sections))
		{
			List<Section> fNotes = createPreliminarySections(pageParsesMap) ;
			sections.addAll(fNotes);
		}

		//	sections = removeLastPageGarbage(sections, pageParsesMap) ;
		if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Chinese"))
			FinancialStatementExtractor.createBlocksForSectionPages(sections,FinancialStatementExtractor.getFileName());

		return sections ;
	}

	private static boolean containsSUPPL(List<Section> sections) {
		for(Section section:sections)
		{
			if(section.getSectionName().equalsIgnoreCase("fnotes"))
			{
				return true;
			}
		}

		return false;
	}
	public static List<Section> createReprocessSupplementarySections(
			TreeMap<Integer, PageParse> pageParsesMap, DataWriterOracle dwOracle, DataWriterSql dwSql,List<Section> prevSections){

		List<Section> sections = new ArrayList<Section>() ;
		if ( pageParsesMap == null )
			return sections ;

		List<ReprocessMetadata> reprocessMetaList =  null;
		if(FinancialStatementExtractor.getCompanyID()!=null && !FinancialStatementExtractor.getCompanyID().trim().equals(""))
		{
			if(dwOracle!=null)
			{
				reprocessMetaList = dwOracle.loadMetaDataEntitywise("SUPPL","Yes");
				dwOracle.updateMetadData("SUPPL");
			}
			if(dwSql!=null)
			{

				reprocessMetaList = dwSql.loadMetaDataEntitywise("SUPPL","Yes");
				dwSql.updateMetadData("SUPPL");

			}
		}
		else
		{
			if(dwOracle!=null)
			{
				reprocessMetaList = dwOracle.loadMetaData("SUPPL","Yes");
			}
			if(dwSql!=null)
			{
				reprocessMetaList = dwSql.loadMetaData("SUPPL","Yes");
			}
		}

		processReprocessParagraphs(pageParsesMap, prevSections, sections,
				reprocessMetaList);

		processReprocessTabular(pageParsesMap, prevSections, sections, reprocessMetaList);



		return sections ;

	}
	private static void processReprocessTabular(
			TreeMap<Integer, PageParse> pageParsesMap,
			List<Section> prevSections, List<Section> sections,
			List<ReprocessMetadata> reprocessMetaList) {
		for(ReprocessMetadata reprocessMeta:reprocessMetaList)
		{
			String scope = reprocessMeta.getScope().trim();

			if(scope.equalsIgnoreCase("Tabular"))
			{
				isSectionMatchTabular(reprocessMeta, sections,pageParsesMap,prevSections);	
			}

		}
	}
	private static void processReprocessParagraphs(
			TreeMap<Integer, PageParse> pageParsesMap,
			List<Section> prevSections, List<Section> sections,
			List<ReprocessMetadata> reprocessMetaList) {
		for(ReprocessMetadata reprocessMeta:reprocessMetaList)
		{
			String scope = reprocessMeta.getScope().trim();

			if(!scope.equalsIgnoreCase("Tabular"))
			{
				isSectionMatch(reprocessMeta, sections, pageParsesMap,prevSections);

			}

		}
	}


	private static List<PDFBlock> restBlock(PDFBlock block,
			List<PDFBlock> blocks) {
		List<PDFBlock> thisBlocks = new ArrayList<PDFBlock>();
		Boolean found = false;
		for(PDFBlock thisBlock:blocks)
		{
			if(thisBlock==block)
			{
				found = true;
				continue;
			}

			if(found)
				thisBlocks.add(thisBlock);
		}

		return thisBlocks;
	}


	private static List<Section> createReprocessPreliminarySections(
			TreeMap<Integer, PageParse> pageParsesMap, DataWriterOracle dwOracle, DataWriterSql dwSql) {
		List<Section> sections = new ArrayList<Section>() ;
		if ( pageParsesMap == null )
			return sections ;
		getAtrributesMeta();
		Section currentSection = null ;
		Boolean endFound = false;

		for(String section:FinancialStatementExtractor.getProcessingScope())
		{
			List<ReprocessMetadata> reprocessMetaList =  null;
			/*if(section.equalsIgnoreCase("SUPPL"))
				continue;*/
			if(FinancialStatementExtractor.getCompanyID()!=null && !FinancialStatementExtractor.getCompanyID().trim().equals(""))
			{
				if(dwOracle!=null)
				{
					reprocessMetaList = dwOracle.loadMetaDataEntitywise(section,"No");
					if(!(reprocessMetaList==null || reprocessMetaList.size()==0))
						dwOracle.updateMetadData(section);

				}
				else
				{
					reprocessMetaList = dwSql.loadMetaDataEntitywise(section,"No");
					if(!(reprocessMetaList==null || reprocessMetaList.size()==0))
						dwSql.updateMetadData(section);

				}

			}
			else
			{
				if(dwOracle!=null)
				{
					reprocessMetaList = dwOracle.loadMetaData(section,"No");

				}
				else
				{
					reprocessMetaList = dwSql.loadMetaData(section,"No");
				}
			}

			if(reprocessMetaList.size()==0)
				continue;
			List<PDFLine> thisLines = null;
			List<PDFBlock> thisBlocks = null;
			endFound = false;
			for(ReprocessMetadata reprocessMeta:reprocessMetaList)
			{
				String strtKeyword = reprocessMeta.getStrtKeyword();
				String endKeyword = reprocessMeta.getEndKeyword();
				if(endKeyword!=null)			
					endKeyword = endKeyword.replaceAll("\\’", " ");
				if(strtKeyword!=null)		
					strtKeyword = strtKeyword.replaceAll("\\’", " ");
				List<String> strtKeywords = null;
				List<String> endKeywords =null;
				if(strtKeyword!=null)
				{
					strtKeywords = Utilities.tokenize(strtKeyword, true) ;
				}
				if(endKeyword!=null)	
				{
					endKeywords = Utilities.tokenize(endKeyword, true) ;
				}

				for ( Integer pageNo : pageParsesMap.keySet() )
				{
					if ( DEBUG_PRELIMINARY )
						System.out.println("Page No: " + pageNo) ;
					if((pageNo.intValue()<reprocessMeta.getStrtPage().intValue() || pageNo.intValue()>reprocessMeta.getEndPage().intValue()) )
					{
						PageParse parse = pageParsesMap.get(pageNo) ;


						List<PDFLine> lines = parse.getPageLines() ;
						//	List<PDFBlock> blocks = parse.getPageBlocks();
						for ( int i=0 ; i<lines.size() ; i++ )
						{
							PDFLine line = lines.get(i) ;

							//	boolean isRegularSentence = RegularSentenceDetector.isRegularSentence(line.toString()) ;
							if (!line.equals("") && statementQuality.equalsIgnoreCase("Co-Prepd"))
							{
								statementQuality = findStatementQuality(line.getLine());
							}
						}
						continue;
					}
					PageParse parse = pageParsesMap.get(pageNo) ;
					List<PDFLine> lines = parse.getPageLines() ;
					List<PDFBlock> blocks = parse.getPageBlocks();
					assignBlockNo(lines,blocks);
					if(pageNo.intValue()==reprocessMeta.getStrtPage().intValue())
					{
						thisLines= new ArrayList<PDFLine>() ;
						thisBlocks= new ArrayList<PDFBlock>() ;
						currentSection= null ;
					}
					int ct=0;
					for ( int k=0 ; k<blocks.size() ; k++ )
					{
						PDFBlock block = blocks.get(k) ;
						boolean isBlockCheckDone=false;

						if(	blockContainsFooterData(block) && !section.equalsIgnoreCase("SUPPL"))
						{							
							continue;
						}
						List<PDFLine> thisBlockLines  = block.getLines() ;
						for ( int i=0 ; i<thisBlockLines.size() ; i++ )
						{
							PDFLine line = thisBlockLines.get(i) ;

							if(section.equalsIgnoreCase("SUPPL") && ((strtKeyword!=null && endKeyword!=null && strtKeyword.equalsIgnoreCase("") &&  endKeyword.equalsIgnoreCase("")) || (strtKeyword!=null && endKeyword!=null && (strtKeyword.equalsIgnoreCase("") ||  endKeyword.equalsIgnoreCase(""))) ||(strtKeyword==null|| endKeyword==null)))
							{
								if(currentSection==null && pageNo.intValue()==reprocessMeta.getStrtPage().intValue() )
								{
									if(strtKeyword.equalsIgnoreCase("") || strtKeyword==null)
									{
										currentSection = new Section("fnotes", thisLines,new SectionStartMatch("fnotes",reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
										continue;
									}

								}
								else
								{
									/*if((pageNo.intValue()==(reprocessMeta.getEndPage().intValue()+1)) && ((endKeyword!=null && endKeyword.equalsIgnoreCase("")) || endKeyword==null) )
									{
										endFound = true;
										k=blocks.size();
										break;
									}*/
									if(currentSection!=null && (pageNo.intValue()==(reprocessMeta.getEndPage().intValue())) && ((endKeyword!=null && endKeyword.equalsIgnoreCase("")) || endKeyword==null) )
									{
										for ( int k1=0 ; k1<blocks.size() ; k1++ )
										{
											PDFBlock blk = blocks.get(k1) ;

											if(	blockContainsFooterData(blk) && !section.equalsIgnoreCase("SUPPL"))
											{							
												continue;
											}
											List<PDFLine> blkLines  = blk.getLines() ;
											for ( int i1=0 ; i1<blkLines.size() ; i1++ )
											{
												PDFLine ln = blkLines.get(i1) ;
												thisLines = currentSection.getLines();
												thisLines.add(ln);
												thisBlocks = currentSection.getBlocks();
												if(blk!=null && thisBlocks!=null && !thisBlocks.contains(blk))
													thisBlocks.add(blk);
											}
										}
										endFound = true;
										k=blocks.size();
										break;
									}
								}
							}

							if(FinancialStatementExtractor.getLanguage().contains("Spanish") && (line.toString().toLowerCase().contains("hoja ")))// || (line.toString().trim().startsWith("ACTIVO") || line.toString().trim().endsWith("CAPITAL CONTABLE"))) )
								continue;
							//	boolean isRegularSentence = RegularSentenceDetector.isRegularSentence(line.toString()) ;
							if (!line.equals("") && statementQuality.equalsIgnoreCase("Co-Prepd"))
							{
								statementQuality = findStatementQuality(line.getLine());
							}

							/*	if(isLineContainsMultipleTokens(line))
							{
								continue;
							}*/
							List<PDFLine> restLines = new ArrayList<PDFLine>(lines.subList(ct+1, lines.size())) ;

							ct++;
							//	String cLine = line.getLine().toLowerCase().replaceAll(" of ", " ").replaceAll(" and ", " ").replaceAll(" in ", " ");


							if(strtKeyword!=null && currentSection==null && pageNo.intValue()==reprocessMeta.getStrtPage().intValue() )
							{
								if(isLineSectionStart(line, restLines, strtKeywords,strtKeyword))
								{
									if(section.equalsIgnoreCase("SUPPL"))
										currentSection = new Section("fnotes", thisLines,new SectionStartMatch("fnotes",reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
									else
										currentSection = new Section(section, thisLines,new SectionStartMatch(section,reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
								}
								else
								{
									if(isLineContainsKeywords(line,SectionOntology.getTokenKeywords()))
									{
										if(simpleSpreadChunksColumns(line, restLines, strtKeywords, strtKeyword))
										{
											if(section.equalsIgnoreCase("SUPPL"))
												currentSection = new Section("fnotes", thisLines,new SectionStartMatch("fnotes",reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
											else
												currentSection = new Section(section, thisLines,new SectionStartMatch(section,reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;

										}
									}
									else
									{
										if(!isBlockCheckDone)
										{
											PDFBlock blk=getBlockForForSectionPresentCheck(line,restLines);
											if(doesBlockContainsSectionKeywords(line, restLines, currentSection,blk) != null)
											{
												currentSection = new Section(section, thisLines,new SectionStartMatch(section,reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
											}
											isBlockCheckDone=true;
										}
									}
								}
							}
							else
							{
								if(endKeyword!=null && (pageNo.intValue()==reprocessMeta.getEndPage().intValue()))
								{
									if(isLineSectionStart(line, restLines, endKeywords,AccentsRemover.removeAccents(endKeyword)))
									{
										endFound = true;
										k=blocks.size();
										break;
									}
									else if(isLineContainsKeywords(line,SectionOntology.getTokenKeywords()))
									{
										if(simpleSpreadChunksColumns(line, restLines, endKeywords, endKeyword))
										{
											endFound = true;
											k=blocks.size();
											break;
										}
									}
									else
									{
										if(!isBlockCheckDone)
										{
											PDFBlock blk=getBlockForForSectionPresentCheck(line,restLines);
											if(doesBlockContainsSectionKeywords(line, restLines, currentSection,blk) != null)
											{
												currentSection = new Section(section, thisLines,new SectionStartMatch(section,reprocessMeta.getStrtKeyword(),line.getLine(),"",reprocessMeta.getRowSegmentationType(),reprocessMeta.getColumnNo()), reprocessMeta.getInstanceID(),thisBlocks) ;
											}
											isBlockCheckDone=true;
										}
									}

								}


								if(currentSection!=null)
								{
									if(isLineContainsMultipleTokens(line) && !currentSection.getSectionName().equalsIgnoreCase("SUPPL"))
									{
										continue;                                              
									}
									thisLines = currentSection.getLines();
									thisLines.add(line);
									thisBlocks = currentSection.getBlocks();
									if(block!=null && thisBlocks!=null && !thisBlocks.contains(block))
										thisBlocks.add(block);

								}

							}
						}
					}

					if ( currentSection != null  && endFound)
					{

						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\tAdding residual section ... ") ;
						currentSection.setReprocessMeta(reprocessMeta);
						sections.add(new Section(currentSection)) ;

						thisLines= new ArrayList<PDFLine>() ;
						currentSection= null ;

						thisBlocks= new ArrayList<PDFBlock>() ;


					}
				}
			}
		}
		return sections ;
	}
	private static boolean isLineContainsMultipleTokens(PDFLine line) {

		Boolean foundAll = false;
		for ( List<String> keywords : RegularSentenceOntology.getMultipleTokenKeywords() )
		{
			for ( String keyword : keywords )
			{
				foundAll = true;
				String modifiedKeyword = " " + keyword.trim() + " " ;
				if ( !line.toString().toLowerCase().contains(modifiedKeyword.toLowerCase()) )
				{
					foundAll = false;
					break;				
				}
			}
			if(foundAll)
				return true;
		}

		return false;

	}




	private static List<Section> removeLastPageGarbage(List<Section> sections, TreeMap<Integer,PageParse> pageParsesMap) 
	{
		List<Section> newSections = new ArrayList<Section>() ;

		for ( int i=0 ; i<sections.size()-1 ; i++ )
		{
			Section thisSection = sections.get(i) ;
			Section nextSection = sections.get(i+1) ;

			if ( DEBUG_LAST_PAGE_GARBAGE )
			{
				System.out.println("\n\n\n") ;
				System.out.println("This Section: " + thisSection) ;
				System.out.println("Next Section: " + nextSection) ;
			}

			Integer thisSectionMaxPageNo = Utilities.findMaxPageNo(thisSection) ;
			Integer nextSectionMinPageNo = Utilities.findMinPageNo(nextSection) ;

			if (  thisSectionMaxPageNo.intValue()!=-1 && nextSectionMinPageNo!=-1 && thisSectionMaxPageNo.intValue() != nextSectionMinPageNo.intValue() )
			{
				if ( DEBUG_LAST_PAGE_GARBAGE )
					System.out.println("\tContinuing because there is no page-wise overlap ... ") ;

				newSections.add(thisSection) ;

				continue ;
			}

			PageParse pageParse = pageParsesMap.get(nextSectionMinPageNo) ;
			boolean nextSectionStartInTopXthOfPage = nextSectionStartInTopXthOfPage(nextSection, pageParse, 4) ;

			if ( !nextSectionStartInTopXthOfPage )
			{
				if ( DEBUG_LAST_PAGE_GARBAGE )
					System.out.println("\tContinuing because next-section doesn't start from the top of the page ... ") ;

				newSections.add(thisSection) ;
				continue ;
			}

			List<PDFLine> newThisSectionLines = new ArrayList<PDFLine>() ;
			List<PDFBlock> newThisSectionBlocks = new ArrayList<PDFBlock>() ;

			for ( int j=0 ; j<thisSection.getLines().size() ; j++ )
			{
				PDFLine line = thisSection.getLines().get(j) ;
				Integer pageNo = line.getPageNo() ;

				if ( pageNo.intValue() == thisSectionMaxPageNo.intValue() )
				{
					if ( DEBUG_LAST_PAGE_GARBAGE )
						System.out.println("\t\tRemoving all lines after ... " + line.getLine()) ;

					break ;
				}
				newThisSectionLines.add(line) ;
			}

			for ( int j=0 ; j<thisSection.getBlocks().size() ; j++ )
			{
				PDFBlock block = thisSection.getBlocks().get(j) ;
				Integer pageNo = block.getPageNo() ;

				if ( pageNo.intValue() == thisSectionMaxPageNo.intValue() )
				{
					if ( DEBUG_LAST_PAGE_GARBAGE )
						System.out.println("\t\tRemoving all lines after ... " + block.getBlock()) ;

					break ;
				}
				newThisSectionBlocks.add(block) ;
			}

			thisSection.setLines(newThisSectionLines) ;
			thisSection.setBlocks(newThisSectionBlocks);
			newSections.add(thisSection) ;
		}

		if ( DEBUG_LAST_PAGE_GARBAGE )
			System.out.println("\n\n\nAdding Residual Section ... ") ;
		if(sections.size()>0)
			newSections.add(sections.get(sections.size()-1)) ;

		return newSections ;
	}

	private static boolean nextSectionStartInTopXthOfPage(Section section, PageParse pageParse, int x)
	{
		if(section.getLines().size()==0 || pageParse==null)
			return false;

		PDFLine sectionLine = section.getLines().get(0) ;

		PDFLine pageFirstLine = new LinkedList<PDFLine>(pageParse.getPageLines()).removeFirst() ;
		PDFLine pageLastLine  = new LinkedList<PDFLine>(pageParse.getPageLines()).removeLast()  ;

		float minY1 = pageFirstLine.getY1() ;
		float maxY2 = pageLastLine.getY2()  ;

		float yBound = (maxY2-minY1) / (float) x ;

		if ( DEBUG_PAGE_TOP_X_CHECKER )
		{
			System.out.println("X-value         : " + x) ;
			System.out.println("Section Line Y1 : " + sectionLine.getY1()) ;
			System.out.println("Page Min Y1     : " + minY1) ;
			System.out.println("Page Max Y2     : " + maxY2) ;
			System.out.println("Page y-Bound    : " + yBound) ;
		}

		if ( sectionLine.getY1() <= yBound )
		{
			if ( DEBUG_PAGE_TOP_X_CHECKER )
				System.out.println("Starts from Top ... ") ;

			return true ;
		}

		return false;
	}

	private static List<Section> mergeConsecutiveSectionsOnSubsequentPages(List<Section> sections) 
	{
		List<Section> newSections = new ArrayList<Section>() ;

		if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
		{
			System.out.println("Sections before merging ... ") ;
			for ( int i=0 ; i<sections.size() ; i++ )
			{
				Section section = sections.get(i) ;
				Integer minPage = Utilities.findMinPageNo(section) ;
				Integer maxPage = Utilities.findMaxPageNo(section) ;

				System.out.println("\tSection: " + section.getSectionName() + "\t" + minPage + "-" + maxPage + "\t" + section.getKeyword().getKeyword()) ;
			}
		}

		Section currentSection = null ;
		for ( int i=0 ; i<sections.size() ; i++ )
		{
			Section section = sections.get(i) ;

			if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
			{
				System.out.println("\n\n") ;
				System.out.println("This Section: " + section.getSectionName() + ", " + section.getKeyword().getKeyword()) ;
				System.out.println("Curr Section: " + (currentSection == null ? null : (currentSection.getSectionName() + ", " + currentSection.getKeyword().getKeyword())) ) ;
			}

			if ( currentSection == null )
			{
				if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
					System.out.println("\tContinuing (after setting current-section as this-section) because the current-section is null ... ") ;

				currentSection = section ;
				continue ;
			}

			if ( !currentSection.getSectionName().equalsIgnoreCase(section.getSectionName()) )
			{
				if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
					System.out.println("\tSaving current-section and replacing it with this-section because the current-section and this-section are of different types ... ") ;

				newSections.add(new Section(currentSection)) ;
				currentSection = section ;
				continue ;
			}

			Integer currentMaxPageNo = Utilities.findMaxPageNo(currentSection) ;
			Integer sectionMinPageNo = Utilities.findMinPageNo(section) ;

			int difference = sectionMinPageNo.intValue() - currentMaxPageNo.intValue() ;

			if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
			{
				System.out.println("\tCurrent-section Max Page No.: " + currentMaxPageNo) ;
				System.out.println("\tThis-section Min Page No.   : " + sectionMinPageNo) ;
				System.out.println("\tDifference : " + difference) ;
			}

			if ( difference <= 1 && (currentSection.getKeyword()).getKeyword().equals((section.getKeyword()).getKeyword()))
			{
				if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
					System.out.println("\tMerging the two sections because the difference is acceptable ... ") ;
				//Ignore section if first page is not tabular
				if(currentSection.getPageRowsMap()!=null)
					currentSection.getPageRowsMap().putAll(section.getPageRowsMap());
				//Ignore section if first page is not tabular
				currentSection.getLines().addAll(section.getLines()) ;
				currentSection.getBlocks().addAll(section.getBlocks());
				if(section.getReprocessMeta()!=null && section.getReprocessMeta().getEndKeyword()!=null)
					currentSection.getReprocessMeta().setEndKeyword(section.getReprocessMeta().getEndKeyword());
				if(section.getReprocessMeta()!=null && section.getReprocessMeta().getEndPage()!=null)
					currentSection.getReprocessMeta().setEndPage(section.getReprocessMeta().getEndPage());
				continue ;
			}

			if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
				System.out.println("\tDefault Case - saving current-section and replacing it with this-section ... ") ;

			newSections.add(new Section(currentSection)) ;
			currentSection = section ;
			continue ;
		}

		if ( currentSection != null )
		{
			if ( DEBUG_MERGE_SUBSEQUENT_SECTIONS )
				System.out.println("\tAdding residual section ... ") ;

			newSections.add(currentSection) ;
		}

		return newSections ;
	}

	private static List<Section> createPreliminarySections(TreeMap<Integer, PageParse> pageParsesMap) 
	{
		List<Section> sections = new ArrayList<Section>() ;

		if ( pageParsesMap == null )
			return sections ;
		getAtrributesMeta();
		Section currentSection = null ;
		String fnoteType="";
		Set<Integer> fnotesPageNosFound=new TreeSet<Integer>();
		ReprocessMetadata reprocessMeta = null;
		Boolean foundNotes = false;
		if(noteKeywordList==null)
			noteKeywordList = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/footnotesSectionIdentificationKeywords.txt");
		Integer notePage= -1;
		for ( Integer pageNo : pageParsesMap.keySet() )
		{
			if ( DEBUG_PRELIMINARY )
				System.out.println("Page No: " + pageNo) ;
			System.out.println("Page No: " + pageNo);
			PageParse parse = pageParsesMap.get(pageNo) ;
			List<PDFLine> lines = parse.getPageLines() ;
			List<PDFBlock> blocks = parse.getPageBlocks();
			assignBlockNo(lines,blocks);

			/*if(isTableOfContentPage(lines.toString()))
			{
				logger.info("Table of content page Found");
				System.out.println("Page No----"+pageNo);
				continue;
			}*/
			/*if(isTableOfContentPage(lines.toString()) || (FinancialStatementExtractor.getContentpgNos() !=null && FinancialStatementExtractor.getContentpgNos().contains(pageNo) ))
			{
				logger.info("Table of content page Found");
				System.out.println("Page No----"+pageNo);
				continue;
			}*/
			boolean tocFound = false;
			for(PDFLine line:lines)	
			{
				if(line!=null)
				{
					if((FinancialStatementExtractor.getContentpgNos() !=null && FinancialStatementExtractor.getContentpgNos().contains(line.getPageNo())))
					{
						//	logger.info("Table of content page Found");
						//	System.out.println("Page No----"+pageNo);
						tocFound = true;
					}
					break;
				}
			}
			if(tocFound || isTableOfContentPage(lines.toString()))
			{

				logger.info("Table of content page Found");
				System.out.println("Page No----"+pageNo);
				continue;

			}
			/*if(isPageTableOfContentBasedOnSectionFound(lines))
			{
				//System.out.println("Page No----"+pageNo);
				System.out.println("==========TOC found on PAGE==="+pageNo);
				continue;
			}*/

			//System.out.println("Page No----"+pageNo);
			int ct=0;
			foundNotes = false;
			notePage= -1;
			for(int k=0;k<blocks.size();k++)
			{
				PDFBlock block = blocks.get(k);

				if(blockContainsFooterData(block) )
				{							
					continue;
				}

				boolean isBlockCheckDone=false;

				for ( int i=0 ; i<block.getLines().size() ; i++ )
				{
					PDFLine line = block.getLines().get(i) ;

					if( currentSection!=null && currentSection.getSectionName().trim().equalsIgnoreCase("fnotes")
							&&	(fnoteType==null || fnoteType.trim().equals("")))
					{
						fnoteType=getFootnoteType(pageParsesMap,pageNo,currentSection);
					}

					//If line length is fuller line length ignore identification
					if(notesKeywords==null)
						notesKeywords = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/notes-terms-variations.txt");

					if(isLineContainsNotes(line) && !foundNotes /*&& k<=4*/)
					{
						foundNotes = true;
						notePage = line.getPageNo();
					}

					//System.out.println(line);

					if(FinancialStatementExtractor.getLanguage().contains("Spanish") 
							&& (line.toString().toLowerCase().contains("hoja ")))// || (line.toString().trim().startsWith("ACTIVO") || line.toString().trim().endsWith("CAPITAL CONTABLE"))) )
						continue;

					if (!line.equals("") && statementQuality.equalsIgnoreCase("Co-Prepd"))
					{
						statementQuality = findStatementQuality(line.getLine());
					}
					/*if(isLineContainsNumber(line))
				{
					continue;
				}
					 */
					List<PDFLine> restLines = new ArrayList<PDFLine>(lines.subList(ct+1, lines.size())) ;
					ct++;
					if ( DEBUG_PRELIMINARY )
						System.out.println("\tLine: " + line.getLine()) ;

					// Regular Sentence Finder to break a current section
					String regularSentenceNeighbourhood = findRegularSentenceNeighbourhood(line, restLines, currentSection) ;
					boolean isRegularSentence = RegularSentenceDetector.isRegularSentence(regularSentenceNeighbourhood,restLines.size(),lines.size()) ;
					boolean isMultitokenPresent = RegularSentenceDetector.isMultiTokensPresent(line.getLine(),restLines.size(),lines.size()) ;

					if(isRegularSentence)
					{
						SectionStartMatch thisMatch = isLineSectionStart(line, restLines, currentSection,block) ;
						SectionStartMatch thisBlockMatch=null;
						if(!isBlockCheckDone && thisMatch==null)
						{
							PDFBlock blk=getBlockForForSectionPresentCheck(line,restLines);
							thisBlockMatch = doesBlockContainsSectionKeywords(line, restLines, currentSection,blk) ;
							//isBlockCheckDone=true;
						}
						if(thisBlockMatch!=null)
						{
							if(thisBlockMatch.getName().trim().equalsIgnoreCase("fnotes"))
								isRegularSentence=false;
						}
						else if (thisMatch!=null)
						{
							if(thisMatch.getName().trim().equalsIgnoreCase("fnotes"))
								isRegularSentence=false;
						}
						if(thisBlockMatch!=null)
						{
							if(thisBlockMatch.getName().trim().equalsIgnoreCase("fnotes_end"))
								isRegularSentence=false;
						}
						else if (thisMatch!=null)
						{
							if(thisMatch.getName().trim().equalsIgnoreCase("fnotes_end"))
								isRegularSentence=false;
						}
					}

					if ( DEBUG_PRELIMINARY )
					{
						if ( isRegularSentence )
							System.out.println("\t\tFound Regular Sentence ... ") ;
					}

					if ( isRegularSentence && currentSection == null )
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tContibuing because the current-section is null ... ") ;

						continue ;
					}
					else if ( isMultitokenPresent && currentSection != null && !currentSection.getSectionName().equalsIgnoreCase("znotes") && !currentSection.getSectionName().equalsIgnoreCase("fnotes") )
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tWrapping the current section because the current-section is not znotes ... ") ;

						if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null)
						{
							reprocessMeta.setEndKeyword(line.getLine());
							reprocessMeta.setEndPage(line.getPageNo());
							//	reprocessMetaList.add(reprocessMeta);
							currentSection.setReprocessMeta(reprocessMeta);
							//reprocessMeta = null;
						}
						sections.add(new Section(currentSection)) ;

						currentSection = null ;
						continue ;
					}
					else if ( isMultitokenPresent && currentSection != null && currentSection.getSectionName().equalsIgnoreCase("znotes") )
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tAdding to the current-section because the current-section is znotes ... ") ;

						currentSection.getLines().add(line) ;
						if(!currentSection.getBlocks().contains(block))
							currentSection.getBlocks().add(block) ;

						continue ;
					}

					// Found start of a new section, that is not a regular sentence ...

					// Found start of a new section, that is not a regular sentence ...
					//int kl=0;
					SectionStartMatch thisMatch = isLineSectionStart(line, restLines, currentSection,block) ;
					SectionStartMatch thisBlockMatch=null;

					if(thisMatch==null)
					{
						if(isLineContainsKeywords(line,SectionOntology.getTokenKeywords()))
						{
							thisMatch = simpleSpreadChunksColumns(block,line,restLines);
						}

					}
					if(!isBlockCheckDone && thisMatch==null)
					{
						PDFBlock blk=getBlockForForSectionPresentCheck(line,restLines);
						thisBlockMatch = doesBlockContainsSectionKeywords(line, restLines, currentSection,blk) ;
						isBlockCheckDone=true;
					}

					if((thisMatch!=null && thisMatch.getName().trim().equalsIgnoreCase("fnotes")) 
							|| ( thisBlockMatch!=null && thisBlockMatch.getName().trim().equalsIgnoreCase("fnotes")))
					{
						fnotesPageNosFound.add(line.getPageNo());
					}


					// Add the blocks based on footnote type
					if(thisMatch==null && thisBlockMatch==null && currentSection!=null
							&& currentSection.getSectionName().trim().equalsIgnoreCase("fnotes")
							&& fnoteType!=null && !fnoteType.trim().equals(""))
					{
						if(!fnotesPageNosFound.contains(line.getPageNo()))
						{
							if(fnoteType.equals("each"))
							{
								int currPageNo=line.getPageNo();
								int latestPageAdded=Collections.max(fnotesPageNosFound);
								if(currPageNo-latestPageAdded>1)
								{
									// break section and remove blocks of the prev page
									currentSection=getSectionTillSpecificPage(currentSection,(line.getPageNo()-2));

									if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null && reprocessMeta.getEndKeyword()==null && currentSection.getLines().size()>0)
									{
										reprocessMeta.setEndKeyword(currentSection.getLines().get(currentSection.getLines().size()-1).getLine());
										reprocessMeta.setEndPage(currentSection.getLines().get(currentSection.getLines().size()-1).getPageNo());
										//	reprocessMetaList.add(reprocessMeta);
										currentSection.setReprocessMeta(reprocessMeta);
										//reprocessMeta = null;
									}
									sections.add(new Section(currentSection)) ;

									currentSection=null;
								}

							}
							else if(fnoteType.equals("alternate"))
							{
								int currPageNo=line.getPageNo();
								int latestPageAdded=Collections.max(fnotesPageNosFound);
								if(currPageNo-latestPageAdded>2)
								{
									// break section and remove blocks of the prev two pages
									currentSection=getSectionTillSpecificPage(currentSection,(line.getPageNo()-3));
									reprocessMeta = new ReprocessMetadata();
									if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null && reprocessMeta.getEndKeyword()==null && currentSection.getLines().size()>0)
									{
										reprocessMeta.setEndKeyword(currentSection.getLines().get(currentSection.getLines().size()-1).getLine());
										reprocessMeta.setEndPage(currentSection.getLines().get(currentSection.getLines().size()-1).getPageNo());
										//	reprocessMetaList.add(reprocessMeta);
										currentSection.setReprocessMeta(reprocessMeta);
										//reprocessMeta = null;
									}
									sections.add(new Section(currentSection)) ;
									currentSection=null;
								}
							}
						}
					}


					if ( DEBUG_PRELIMINARY )
					{
						if ( thisMatch != null )
							System.out.println("\t\tFound new start ... ") ;
						else
							System.out.println("\t\tFound no new start ... ") ;
					}

					// Section block Addition changes 

					if(currentSection==null && thisBlockMatch!=null)
					{
						fnoteType="";
						List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
						thisLines.addAll(block.getLines()) ;

						List<PDFBlock> thisBlocks = new ArrayList<PDFBlock>() ;
						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection(thisBlockMatch.getName());
							reprocessMeta.setStrtKeyword(thisBlockMatch.getKeyword());
							reprocessMeta.setStrtKeyword(thisBlockMatch.getKeyword());

							reprocessMeta.setStrtPage(line.getPageNo());
							reprocessMeta.setRowSegmentationType(thisBlockMatch.getRowSegmentationType());
							reprocessMeta.setColumnNo(thisBlockMatch.getColumnNo());

						}
						currentSection = new Section(thisBlockMatch.getName(), thisLines, thisBlockMatch,0,thisBlocks) ;
						break ;
					}
					else if ( currentSection != null && thisBlockMatch != null && !currentSection.getSectionName().equalsIgnoreCase(thisBlockMatch.getName()) )
					{
						fnoteType="";
						if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null)
						{
							reprocessMeta.setEndKeyword(line.getLine());
							reprocessMeta.setEndPage(line.getPageNo());
							currentSection.setReprocessMeta(reprocessMeta);
						}
						else
							if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
							{
								reprocessMeta = new ReprocessMetadata();
								reprocessMeta.setSection(thisBlockMatch.getName());
								reprocessMeta.setStrtKeyword(thisBlockMatch.getKeyword());
								reprocessMeta.setStrtPage(line.getPageNo());
								reprocessMeta.setRowSegmentationType(thisBlockMatch.getRowSegmentationType());
								reprocessMeta.setColumnNo(thisBlockMatch.getColumnNo());

							}
						sections.add(new Section(currentSection)) ;

						List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
						thisLines.addAll(block.getLines()) ;
						List<PDFBlock> thisBlocks = new ArrayList<PDFBlock>() ;
						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						currentSection = new Section(thisBlockMatch.getName(), thisLines, thisBlockMatch,0,thisBlocks) ;
						if(reprocessMeta!=null && reprocessMeta.getEndPage()!=null && FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection(thisBlockMatch.getName());
							reprocessMeta.setStrtKeyword(thisBlockMatch.getKeyword());
							reprocessMeta.setStrtPage(line.getPageNo());
							reprocessMeta.setRowSegmentationType(thisBlockMatch.getRowSegmentationType());
							reprocessMeta.setColumnNo(thisBlockMatch.getColumnNo());

						}
						break ;
					}
					else if ( currentSection != null && thisBlockMatch != null && currentSection.getSectionName().equalsIgnoreCase(thisBlockMatch.getName()) && currentSection.getKeyword().toString().equalsIgnoreCase(thisBlockMatch.getKeyword().toString()))
					{
						currentSection.getLines().addAll(block.getLines()) ;
						List<PDFBlock> thisBlocks = currentSection.getBlocks();

						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						break;
					}


					// Section block Addition changes done 

					if ( currentSection == null && thisMatch == null )
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tContinuing without doing anything ... ") ;

						fnoteType="";
						continue ;
					}
					else if ( currentSection == null && thisMatch != null )
					{
						if(foundNotes && notePage.equals(line.getPageNo()) && (thisMatch.getName().equalsIgnoreCase("IS") || thisMatch.getName().equalsIgnoreCase("BS") || thisMatch.getName().equalsIgnoreCase("CF") ))
						{
							if(!thisMatch.getName().equalsIgnoreCase("fnotes"))
							{
								k = blocks.size();
								break;
							}
						}
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tStarting a new section because the current-section is null ... ") ;

						List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
						thisLines.add(line) ;

						List<PDFBlock> thisBlocks = new ArrayList<PDFBlock>() ;
						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection(thisMatch.getName());
							reprocessMeta.setStrtKeyword(thisMatch.getKeyword());
							reprocessMeta.setStrtKeyword(thisMatch.getKeyword());

							reprocessMeta.setStrtPage(line.getPageNo());
							reprocessMeta.setRowSegmentationType(thisMatch.getRowSegmentationType());
							reprocessMeta.setColumnNo(thisMatch.getColumnNo());

						}
						currentSection = new Section(thisMatch.getName(), thisLines, thisMatch,0,thisBlocks) ;
						fnoteType="";
						continue ;
					}
					else if ( currentSection != null && thisMatch == null )
					{
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tAdding line to the current-section because no new section is found ... ") ;
						/*if(!currentSection.getKeyword().getNeighbouringText().contains(line.toString()))
					{*/
						List<PDFBlock> thisBlocks = currentSection.getBlocks();
						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						currentSection.getLines().add(line) ;
						continue ;

						/*}*/

					}
					else if ( currentSection != null && thisMatch != null && !currentSection.getSectionName().equalsIgnoreCase(thisMatch.getName()) )
					{
						fnoteType="";
						if(foundNotes && notePage.equals(line.getPageNo()) && (thisMatch.getName().equalsIgnoreCase("IS") || thisMatch.getName().equalsIgnoreCase("BS") || thisMatch.getName().equalsIgnoreCase("CF") ))
						{
							if(!thisMatch.getName().equalsIgnoreCase("fnotes"))
							{
								k = blocks.size();
								break;
							}
						}
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tWrapping the current-section and starting a new section because the new section's name is not same as the previous section's name ... ") ;

						if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null)
						{
							reprocessMeta.setEndKeyword(line.getLine());
							reprocessMeta.setEndPage(line.getPageNo());
							//	reprocessMetaList.add(reprocessMeta);
							currentSection.setReprocessMeta(reprocessMeta);
							//reprocessMeta = null;
						}
						else
							if(FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
							{
								reprocessMeta = new ReprocessMetadata();
								reprocessMeta.setSection(thisMatch.getName());
								reprocessMeta.setStrtKeyword(thisMatch.getKeyword());
								reprocessMeta.setStrtPage(line.getPageNo());
								reprocessMeta.setRowSegmentationType(thisMatch.getRowSegmentationType());
								reprocessMeta.setColumnNo(thisMatch.getColumnNo());

							}
						sections.add(new Section(currentSection)) ;

						List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
						thisLines.add(line) ;
						List<PDFBlock> thisBlocks = new ArrayList<PDFBlock>() ;
						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						currentSection = new Section(thisMatch.getName(), thisLines, thisMatch,0,thisBlocks) ;
						if(reprocessMeta!=null && reprocessMeta.getEndPage()!=null && FinancialStatementExtractor.getStandAlone().equalsIgnoreCase("No") && FinancialStatementExtractor.getStorelogic().equalsIgnoreCase("Yes"))
						{
							reprocessMeta = new ReprocessMetadata();
							reprocessMeta.setSection(thisMatch.getName());
							reprocessMeta.setStrtKeyword(thisMatch.getKeyword());
							reprocessMeta.setStrtPage(line.getPageNo());
							reprocessMeta.setRowSegmentationType(thisMatch.getRowSegmentationType());
							reprocessMeta.setColumnNo(thisMatch.getColumnNo());

						}
						continue ;
					}
					else if ( currentSection != null && thisMatch != null && currentSection.getSectionName().equalsIgnoreCase(thisMatch.getName()) && currentSection.getKeyword().toString().equalsIgnoreCase(thisMatch.getKeyword().toString()))
					{
						if(foundNotes && notePage.equals(line.getPageNo()) && (thisMatch.getName().equalsIgnoreCase("IS") || thisMatch.getName().equalsIgnoreCase("BS") || thisMatch.getName().equalsIgnoreCase("CF")))
						{
							if(!thisMatch.getName().equalsIgnoreCase("fnotes"))
							{
								k = blocks.size();
								break;
							}
						}
						if ( DEBUG_PRELIMINARY )
							System.out.println("\t\t\tContinuing with the current-section because the new section's name is same as the previous section's name ... ") ;

						currentSection.getLines().add(line) ;
						List<PDFBlock> thisBlocks = currentSection.getBlocks();

						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						continue ;
					}
					else if(currentSection != null && currentSection.getSectionName().equalsIgnoreCase("fnotes"))
					{
						currentSection.getLines().add(line) ;
						List<PDFBlock> thisBlocks = currentSection.getBlocks();

						if(!thisBlocks.contains(block))
							thisBlocks.add(block) ;
						continue ;

					}

					continue ;
				}
			}

		}

		if ( currentSection != null )
		{
			if ( DEBUG_PRELIMINARY )
				System.out.println("\t\tAdding residual section ... ") ;
			if(reprocessMeta!=null && reprocessMeta.getStrtKeyword()!=null && reprocessMeta.getEndKeyword()==null && currentSection.getLines().size()>0)
			{
				reprocessMeta.setEndKeyword(currentSection.getLines().get(currentSection.getLines().size()-1).getLine());
				reprocessMeta.setEndPage(currentSection.getLines().get(currentSection.getLines().size()-1).getPageNo());
				//	reprocessMetaList.add(reprocessMeta);
				currentSection.setReprocessMeta(reprocessMeta);
				//reprocessMeta = null;
			}
			sections.add(currentSection) ;
		}



		return sections ;
	}
	private static boolean isPageTableOfContentBasedOnSectionFound(List<PDFLine> lines) 
	{
		List<SectionStartMatch> allSections= new ArrayList<SectionStartMatch>();
		for(PDFLine line:lines)
		{
			SectionStartMatch section=SectionsStartDetector.checkSectionStringMatch(line);
			if(section!=null)
				allSections.add(section);
		}
		if(allSections!=null && allSections.size()>0)
		{
			if(allSections.size()>2)
				return true;
		}

		return false;
	}
	private static Boolean  simpleSpreadChunksColumns(PDFLine pdfLine, List<PDFLine> restLines, List<String>keyword, String keywordExpression) {

		//	PDFLine pdfLine = block.getLines().get(0);
		List<PDFLine> lines = new ArrayList<PDFLine>();
		/*if((block.getLines().size()==1))
		{*/
		lines.add(pdfLine);
		int ct =0;
		for(PDFLine line:restLines)
		{
			if(line!=null && !line.getLine().trim().equals(""))
			{
				if(SectionsStartDetector.isSectionStart(false,line.getLine(), line.getLine(), line, restLines, keyword, keywordExpression))
				{
					return false;
				}
			}
			if(ct>3)
				break;
			lines.add(line);
			ct++;
		}

		/*}
		else
		{
			int ct =0;
			for(PDFLine line:block.getLines())
			{
				if(ct>5)
					break;
				lines.add(line);
				ct++;
			}

		}*/
		List<Row> rows = SectionSpreader.createPreliminaryRows(lines) ;

		SectionSpreader.reCreateRowLines(rows) ;
		List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
		HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;
		HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
		SectionSpreader.spreadChunkColumns(rows, chunkColumns, chunkBounds, chunkRowsMap, null, null, null, wordRowsMap,null) ;
		TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = SectionSpreader.createRowColumnChunksMap(rows, chunkColumns, chunkRowsMap, null) ;
		/*TreeMap<Integer, LinkedList<String>> chunksColMap = new TreeMap<Integer, LinkedList<String>>();
		 */							
		TreeMap<Integer,String> concatenatedStringMap = new TreeMap<Integer,String>(); 
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;

			for ( Integer column : columnChunksMap.keySet() )
			{
				List<PDFChunk> chunks = columnChunksMap.get(column) ;
				Collections.sort(chunks);
				String colVal = "" ;
				if(chunks!=null)
				{
					//Integer pgNo = 0 ;
					for ( int i1=0 ; i1<chunks.size() ; i1++ )
					{
						PDFChunk chunk = chunks.get(i1) ;
						//	pgNo = chunk.getPageNo();
						String strChunk = chunk.getChunk() ;
						/*if(SectionsStartDetector.isSectionStart(true,strChunk, strChunk, pdfLine, restLines, keyword, keywordExpression))
						{
							return false;
						}*/
						if ( strChunk.trim().equalsIgnoreCase("") )
							continue ;
						colVal = colVal.trim() + " " + strChunk  ;
					}
					if(!concatenatedStringMap.containsKey(column))
					{
						concatenatedStringMap.put(column, colVal);
					}
					else
					{
						String existingVal= concatenatedStringMap.get(column);
						colVal =  existingVal.trim()+" "+colVal.trim();
						concatenatedStringMap.put(column, colVal);

					}

					/*if(!chunksColMap.containsKey(column))
					{
						LinkedList<String> values = new LinkedList<String>();
						values.add(colVal);
						chunksColMap.put(column, values);
					}
					else
					{
						LinkedList<String> values = chunksColMap.get(column);
						values.add(colVal);
					}*/
					//System.out.println("corrds ---- "+coOrds );
				}
			}
		}

		for(Integer column: concatenatedStringMap.keySet())
		{
			String line = concatenatedStringMap.get(column);
			//if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No"))
			//{
			if(SectionsStartDetector.isSectionStart(true,line, line, pdfLine, restLines, keyword, keywordExpression))
				return true;
			//}
			/*else
			{
			if(line.contains(keywordExpression.toLowerCase()))
				return true;
			}
			 *///line = ignoreUnwatedData(line);
			//SectionStartMatch match = SectionsStartDetector.isSectionStart(line, line, line,pdfLine,restLines) ;

			/*if ( match != null )
			{
				logger.info("matched Chunk-----" +line );
				System.out.println("matched Chunk-----" +line );
				return match;
			}*/
		}
		//thisMatch = isLineSectionStart(line, restLines, currentSection,block) ;
		return false;

	}


	private static SectionStartMatch  simpleSpreadChunksColumns(PDFBlock block, PDFLine pdfLine, List<PDFLine> restLines) {
		//	PDFLine pdfLine = block.getLines().get(0);
		List<PDFLine> lines = new ArrayList<PDFLine>();
		/*if((block.getLines().size()==1))
		{*/
		lines.add(pdfLine);
		int ct =0;
		for(PDFLine line:restLines)
		{
			if(ct>3)
				break;
			lines.add(line);
			ct++;
		}

		/*}
		else
		{
			int ct =0;
			for(PDFLine line:block.getLines())
			{
				if(ct>5)
					break;
				lines.add(line);
				ct++;
			}

		}*/
		List<Row> rows = SectionSpreader.createPreliminaryRows(lines) ;

		SectionSpreader.reCreateRowLines(rows) ;
		List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
		HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;
		HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
		SectionSpreader.spreadChunkColumns(rows, chunkColumns, chunkBounds, chunkRowsMap, null, null, null, wordRowsMap,null) ;
		TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = SectionSpreader.createRowColumnChunksMap(rows, chunkColumns, chunkRowsMap, null) ;
		/*TreeMap<Integer, LinkedList<String>> chunksColMap = new TreeMap<Integer, LinkedList<String>>();
		 */							
		TreeMap<Integer,String> concatenatedStringMap = new TreeMap<Integer,String>(); 
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;

			for ( Integer column : columnChunksMap.keySet() )
			{
				List<PDFChunk> chunks = columnChunksMap.get(column) ;
				Collections.sort(chunks);
				String colVal = "" ;
				if(chunks!=null)
				{
					//Integer pgNo = 0 ;
					for ( int i1=0 ; i1<chunks.size() ; i1++ )
					{
						PDFChunk chunk = chunks.get(i1) ;
						//	pgNo = chunk.getPageNo();
						String strChunk = chunk.getChunk() ;
						if ( strChunk.trim().equalsIgnoreCase("") )
							continue ;
						colVal = colVal.trim() + " " + strChunk  ;
					}
					if(!concatenatedStringMap.containsKey(column))
					{
						concatenatedStringMap.put(column, colVal);
					}
					else
					{
						String existingVal= concatenatedStringMap.get(column);
						colVal =  existingVal.trim()+" "+colVal.trim();
						concatenatedStringMap.put(column, colVal);

					}

					/*if(!chunksColMap.containsKey(column))
					{
						LinkedList<String> values = new LinkedList<String>();
						values.add(colVal);
						chunksColMap.put(column, values);
					}
					else
					{
						LinkedList<String> values = chunksColMap.get(column);
						values.add(colVal);
					}*/
					//System.out.println("corrds ---- "+coOrds );
				}
			}
		}

		for(Integer column: concatenatedStringMap.keySet())
		{
			String line = concatenatedStringMap.get(column);
			//line = ignoreUnwatedData(line);
			SectionStartMatch match = SectionsStartDetector.isSectionStart(line, line, line,pdfLine,restLines) ;

			if ( match != null )
			{
				logger.info("matched Chunk-----" +line );
				System.out.println("matched Chunk-----" +line );
				return match;
			}
		}
		//thisMatch = isLineSectionStart(line, restLines, currentSection,block) ;
		return null;
	}

	private static Boolean isLineContainsKeywords(PDFLine line,
			Set<String> tokenKeywords) {
		for(String token:tokenKeywords)
		{
			if(com.rage.nlp.tools.stopwords.StopWords.getStopWords().toString().equalsIgnoreCase(token) && FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No"))
				continue;

			if(line.getLine().toLowerCase().contains(token.toLowerCase()))
			{
				return true;
			}
		}

		return false;
	}
	private static Section getSectionTillSpecificPage(Section currentSection, int pageNO) 
	{
		List<PDFBlock> blocks= new ArrayList<PDFBlock>();
		List<PDFLine> lines= new ArrayList<PDFLine>();
		for(PDFBlock blk:currentSection.getBlocks())
		{
			if(blk.getPageNo()<=pageNO)
			{
				blocks.add(blk);
			}
		}
		for(PDFLine line:currentSection.getLines())
		{
			if(line.getPageNo()<=pageNO)
			{
				lines.add(line);
			}
		}
		currentSection.setBlocks(blocks);
		currentSection.setLines(lines);

		return currentSection;
	}

	private static String getFootnoteType(TreeMap<Integer, PageParse> pageParsesMap, Integer pageNo,Section currentSection) 
	{
		Set<Integer> pageNoSet= new HashSet<Integer>();
		Set<Integer> donePageNoSet= new HashSet<Integer>();
		int limit=20;
		int pageChecked=0;
		int continuousPagesSecNotFound=0;
		int prevPageCountAdded =-1;

		// Adding pageNos
		for(Integer pgNo:pageParsesMap.keySet())
		{
			if(pgNo<pageNo)
				continue;
			if(pgNo==pageNo)
			{
				int pg=pageParsesMap.get(pgNo).getPageLines().get(0).getPageNo();
				pageNoSet.add(pg);
				donePageNoSet.add(pg);
				continue;
			}
			int page=-1;
			if(pageChecked>=limit)
				break;
			if(continuousPagesSecNotFound>1)
				break;
			PageParse pp=pageParsesMap.get(pgNo );
			List<PDFBlock> blocks=pp.getPageBlocks();
			List<PDFLine> lines= pp.getPageLines();
			int ct=0;
			for(PDFBlock block:blocks)
			{
				boolean isBlockCheckDone=false;

				for(PDFLine line:block.getLines() )
				{
					if(!donePageNoSet.contains(line.getPageNo()))
						pageChecked++;
					List<PDFLine> restLines = new ArrayList<PDFLine>(lines.subList(ct+1, lines.size())) ;
					donePageNoSet.add(line.getPageNo());
					page=line.getPageNo();

					SectionStartMatch thisMatch = isLineSectionStart(line, restLines, currentSection,block) ;
					SectionStartMatch thisBlockMatch=null;
					if(!isBlockCheckDone && thisMatch==null)
					{
						PDFBlock blk=getBlockForForSectionPresentCheck(line,restLines);
						thisBlockMatch = doesBlockContainsSectionKeywords(line, restLines, currentSection,blk) ;
						isBlockCheckDone=true;
					}


					if ( thisBlockMatch != null && currentSection!=null && currentSection.getSectionName().equalsIgnoreCase(thisBlockMatch.getName()) && currentSection.getKeyword().toString().equalsIgnoreCase(thisBlockMatch.getKeyword().toString()) )
					{
						pageNoSet.add(line.getPageNo());
						break;
					}
					else if ( thisMatch != null && currentSection!=null && currentSection.getSectionName().equalsIgnoreCase(thisMatch.getName()) && currentSection.getKeyword().toString().equalsIgnoreCase(thisMatch.getKeyword().toString()) )
					{
						pageNoSet.add(line.getPageNo());
					}	
					else if(thisBlockMatch != null && currentSection!=null && currentSection.getSectionName().equalsIgnoreCase(thisBlockMatch.getName()))
					{
						pageNoSet.add( line.getPageNo());
						break;
					}
					else if (thisMatch != null && currentSection!=null && currentSection.getSectionName().equalsIgnoreCase(thisMatch.getName()))
					{
						pageNoSet.add(line.getPageNo());
					}

				}
			}

			if(page!=prevPageCountAdded && !pageNoSet.contains(page))
			{
				continuousPagesSecNotFound++;
				prevPageCountAdded=page;
			}
			else
			{
				continuousPagesSecNotFound=0;
			}

		}

		if(donePageNoSet.size()>1 && pageNoSet.size()>1)
		{
			float percentPageFound=(float)(((float)pageNoSet.size())/((float)donePageNoSet.size()));
			if(percentPageFound>=0.7f)
			{
				return "each";
			}
			else if (percentPageFound>=0.3f )
				return "alternate";

		}
		return "all";
	}

	private static SectionStartMatch doesBlockContainsSectionKeywords(PDFLine line, List<PDFLine> restLines, Section currentSection,PDFBlock block)
	{
		SectionStartMatch match = null ;
		//TODO:check FullerLines in blocks and size of the block during identification
		if((block.getLines().size()>=2 && checkFullerLines(block) && line.getLine().trim().length()==PDFDocumentLoader.getFullerLineLength()) /*|| (line.toString().trim().replaceAll("\\:", "").length()< line.toString().trim().length())*/)
		{
			return match;
		}

		String strLine = line.getLine() ;
		//strLine = ignoreUnwatedData(strLine);
		//	strLine = IgnoreEnumeration(strLine);
		CleanEnumeratedText cet = new CleanEnumeratedText();
		strLine = cet.replaceEnums(strLine);


		// TODO: Ignore dates, and possibly, other data-types
		//List<PDFChunk> chunks = line.getChunks() ;

		//List<String> linesFromChunk = createLinesFromChunk(chunks) ;
		String neighbourhood = createNeighbourhoodForSectionStartDetection(line, restLines, currentSection) ;

		List<MetaData> metaList = SectionOntology.getMetaList();
		Collections.sort(metaList);

		for(MetaData m:metaList)
		{
			if(m.getKeyword()!=null && m.getKeyword().contains(";"))
			{
				boolean isFound=false;
				String[] keywordSplit= m.getKeyword().split(";");
				int i=0;
				for(String kw:keywordSplit)
				{
					List<String> kwTokens = Utilities.tokenize(kw.toLowerCase(), true) ;
					boolean kwMatch=false;
					for(;i<block.getLines().size();i++)
					{
						PDFLine tempLine=block.getLines().get(i);
						String lineStr=tempLine.getLine();
						List<String> chunkLines=Utilities.tokenize(lineStr.toLowerCase(), true) ;
						kwMatch=SectionsStartDetector.doesKeywordMatch(chunkLines, kwTokens);

						if(kwMatch && !isFound)
						{
							isFound=true;
							i++;
							break;
						}
						else if(isFound && kwMatch)
						{
							isFound=kwMatch;
							i++;
							break;
						}
						else if (!kwMatch && isFound)
						{
							isFound=false;
							i++;
							break;
						}
					}
					if(!isFound || !kwMatch)
					{
						isFound=false;
						break;
					}
				}

				if(isFound)
				{
					match=new SectionStartMatch(m.getSection(), m.getKeyword(), line.getLine(), neighbourhood,m.getRowSegmentationType(),m.getColumnNo()) ;
					return match;
				}
			}
		}

		return match;
		/*for ( int j=0 ; j<linesFromChunk.size() ; j++ )
		{
			String chunkFromLine = linesFromChunk.get(j) ;
			chunkFromLine = ignoreUnwatedData(chunkFromLine);
			//	match = SectionsStartDetector.isSectionStart(chunkFromLine, strLine, neighbourhood,line,restLines) ;
			match = SectionsStartDetector.isSectionStart(chunkFromLine, strLine, neighbourhood,line,restLines) ;


			if ( match != null )
			{
				logger.info("matched Chunk-----" +chunkFromLine );
				System.out.println("matched Chunk-----" +chunkFromLine );

				break ;
			}
		}

		return match ;*/
	}

	private static PDFBlock getBlockForForSectionPresentCheck(PDFLine line, List<PDFLine> restLines) 
	{
		PDFBlock blk= new PDFBlock();
		blk.getLines().add(line);
		if(restLines!=null && restLines.size()>1)
		{
			blk.getLines().add(restLines.get(0));
			blk.getLines().add(restLines.get(1));
		}
		else if(restLines!=null && restLines.size()>0)
		{
			blk.getLines().add(restLines.get(0));
		}

		return blk;
	}

	private static boolean isLineContainsNotes(PDFLine pdfLine) {

		String line = pdfLine.getLine().trim().toLowerCase();

		for(String  notesKeyword : getNotesKeywords())
		{

			if(line.contains(notesKeyword.toLowerCase()))
			{
				return true;
			}

		}
		return false;
	}
	public static LinkedHashSet<String> getNotesKeywords() {
		return notesKeywords;
	}
	public static void setNotesKeywords(LinkedHashSet<String> notesKeywords) {
		SectionBoundaryDetector.notesKeywords = notesKeywords;
	}
	private static boolean checkFullerLines(PDFBlock block) {
		int count = 0;
		for(PDFLine line :block.getLines())
		{
			if((line.getX2()-line.getX1())<= (PDFDocumentLoader.getFullerLineLength()-5) /*&& line.getChunks()==1*/)
			{
				count = count + 1;
			}
		}

		if(((count*1.0)/block.getLines().size())>=50)
			return true;

		return false;
	}


	/*	private static boolean isLineContainsNumber(PDFLine line) {
		for(PDFChunk chunk :line.getChunks())
		{
			if(NumberDetector.isNumericValue(chunk.getChunk()))
			{
				return true;
			}
		}
		return false;

	}
	 */
	private static void assignBlockNo(List<PDFLine> lines, List<PDFBlock> blocks) {
		for(PDFLine line :lines)
		{
			for(int i=0;i<blocks.size();i++)
			{
				for( PDFLine  blockLine: blocks.get(i).getLines())
				{
					if(blockLine.equals(line))
					{
						line.setBlockNo(i);
					}
				}
			}
		}
	}
	private static String findStatementQuality(String line) {
		if (logger!=null)
			logger.debug("Finding statement quality ...");

		if (getStatementQuality().equals("Co-Prepd") && getStatementQualityMeta()!=null && getStatementQualityMeta().size()>0) {

			for (String str : getStatementQualityMeta()) {
				String[] token = str.trim().split("##########");

				if (line.toLowerCase().indexOf(token[1].toLowerCase())!=-1)
					return token[0];
			}
		}
		return "Co-Prepd";
	}

	/*public static Boolean getDEBUG_PRELIMINARY() {
		return DEBUG_PRELIMINARY;
	}
	public static void setDEBUG_PRELIMINARY(Boolean dEBUG_PRELIMINARY) {
		DEBUG_PRELIMINARY = dEBUG_PRELIMINARY;
	}
// TODO Remove unused code found by UCDetector
// 	public static Boolean getDEBUG_MERGE_SUBSEQUENT_SECTIONS() {
// 		return DEBUG_MERGE_SUBSEQUENT_SECTIONS;
// 	}
	public static void setDEBUG_MERGE_SUBSEQUENT_SECTIONS(
			Boolean dEBUG_MERGE_SUBSEQUENT_SECTIONS) {
		DEBUG_MERGE_SUBSEQUENT_SECTIONS = dEBUG_MERGE_SUBSEQUENT_SECTIONS;
	}
	public static Boolean getDEBUG_LAST_PAGE_GARBAGE() {
		return DEBUG_LAST_PAGE_GARBAGE;
	}
	public static void setDEBUG_LAST_PAGE_GARBAGE(Boolean dEBUG_LAST_PAGE_GARBAGE) {
		DEBUG_LAST_PAGE_GARBAGE = dEBUG_LAST_PAGE_GARBAGE;
	}
// TODO Remove unused code found by UCDetector
// 	public static Boolean getDEBUG_PAGE_TOP_X_CHECKER() {
// 		return DEBUG_PAGE_TOP_X_CHECKER;
// 	}
	public static void setDEBUG_PAGE_TOP_X_CHECKER(Boolean dEBUG_PAGE_TOP_X_CHECKER) {
		DEBUG_PAGE_TOP_X_CHECKER = dEBUG_PAGE_TOP_X_CHECKER;
	}
	public static TreeSet<String> getTABLE_KEYWORDS_CONTAINS() {
		return TABLE_KEYWORDS_CONTAINS;
	}
	public static void setTABLE_KEYWORDS_CONTAINS(
			TreeSet<String> tABLE_KEYWORDS_CONTAINS) {
		TABLE_KEYWORDS_CONTAINS = tABLE_KEYWORDS_CONTAINS;
	}*/
	private static List<String> getStatementQualityMeta() {
		return statementQualityMeta;
	}



	/*	public static String IgnoreEnumeration(String line) 
	{
		if (line==null || line.trim().isEmpty())
		{
			return line;
		}

		String pattern="(\\(?(\\s)?[ivxl]{1,4}\\)\\s{1,})|([ivxl]{1,4}\\.?\\s{1,})"; //Patterns Covered- Roman numerals- (ii) and ii) and ii.
		System.out.println(line);
		String chLine = patternFound(pattern, line);


		if (line.trim().equals(chLine.trim()))
		{
			pattern="(\\(?\\d{1,4}\\.?(\\d{1,4})?\\.?\\)\\s{1,})|(\\d{1,4}(\\s+)?\\.?(\\s+)?(\\d{1,4})?\\.?(\\s+)?(\\d{1,4})?\\.?(\\s+)?(\\d{1,4})?\\.?\\s{1,})";
			chLine = patternFound(pattern, line);
		}
		if (line.trim().equals(chLine.trim()))
		{
			pattern="((?(\\s)?[a-z]{1,4}))|([a-z](\\s)?\\.\\s{1,})"; //Patterns Covered (a) and a) and a.
			chLine = patternFound(pattern, line);
		}
		if (line.trim().equals(chLine.trim()))
		{
			pattern="(\\(?(\\s)?[IVXL]{1,4}\\)\\s{1,})|([IVXL]{1,4}\\.?\\s{1,})";
			chLine = patternFound(pattern, line);
		}

		if (line.trim().equals(chLine.trim()))
		{
			pattern="(\\(?(\\s)?[A-Z]{1,2}\\)\\s{1,})|([A-Z]{1,2}\\.\\s{1,})"; //Patterns Covered (a) and a) and a.
			chLine = patternFound(pattern, line);
		}
		if (line.trim().equals(chLine.trim()))
		{
			pattern="(\\(?(\\s)?[IVXL]{1,4}\\)\\s{1,})|([IVXL]{1,4}\\.?\\s{1,})";
			chLine = patternFound(pattern, line);
		}
		if (line.trim().equals(chLine.trim()))
		{
			pattern="(\\(?(\\s)?[IVXL]{1,4}\\)\\s{1,})|([IVXL]{1,4}\\.?\\s{1,})";
			chLine = patternFound(pattern, line);
		}
		return  chLine;

	}

	 */
	private static String patternFound(String pattern, String line) {	

		if (line.isEmpty())
			return line;

		Pattern p=Pattern.compile(pattern);
		Matcher m=p.matcher(line);
		if(m.matches())
			line = line.replaceAll(m.group(), "");
		return line;
	}


	private static int getNeighbourhoodLinesThreshold ( )
	{
		LinkedHashSet<String> ret = new LinkedHashSet<String>() ;

		ret = TimePeriodOntology.loadSuffixes("resource/section-identification/neighbourhoodLinesThreshold.txt");

		if(ret!=null && ret.size()>0)
		{
			for(String str :  ret)
			{
				String splitStr[]  = str.split("\t");

				if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase(splitStr[0]))
				{
					return Integer.parseInt(splitStr[1]);
				}
			}
		}
		return -1;
	}


	private static String findRegularSentenceNeighbourhood(PDFLine line, List<PDFLine> restLines, Section currentSection) 
	{
		if(noOfneighbourhoodLines ==-1)
			noOfneighbourhoodLines = getNeighbourhoodLinesThreshold();

		int maxLinesToCheckSentenceNeighbourhood = 0;
		if(noOfneighbourhoodLines!=-1)
		{
			maxLinesToCheckSentenceNeighbourhood = currentSection != null ? 0 :noOfneighbourhoodLines ;
		}else
		{
			maxLinesToCheckSentenceNeighbourhood = currentSection != null ? 0 : 3 ;
		}


		//int maxLinesToCheckSentenceNeighbourhood = currentSection != null ? 0 : 3 ;

		String neighbourhood = line.getLine() ;
		for ( int i=0 ; i<restLines.size() && i<maxLinesToCheckSentenceNeighbourhood ; i++ )
		{
			PDFLine nextLine = restLines.get(i) ;
			neighbourhood = neighbourhood.trim() + " " + nextLine.getLine() ;
		}
		neighbourhood = neighbourhood.trim() ;

		return neighbourhood ;
	}

	private static SectionStartMatch isLineSectionStart(PDFLine line, List<PDFLine> restLines, Section currentSection,PDFBlock block)
	{
		SectionStartMatch match = null ;
		//TODO:check FullerLines in blocks and size of the block during identification
		if((block.getLines().size()>=2 && checkFullerLines(block) && line.getLine().trim().length()==PDFDocumentLoader.getFullerLineLength()) || (line.toString().trim().replaceAll("\\:", "").length()< line.toString().trim().length()))
		{
			return match;
		}		

		String strLine = line.getLine() ;
		//strLine = ignoreUnwatedData(strLine);
		//	strLine = IgnoreEnumeration(strLine);
		CleanEnumeratedText cet = new CleanEnumeratedText();
		strLine = cet.replaceEnums(strLine);


		// TODO: Ignore dates, and possibly, other data-types
		List<PDFChunk> chunks = line.getChunks() ;

		//List<String> linesFromChunk = createLinesFromChunk(chunks) ;
		List<String> linesFromChunk = new ArrayList<String>();
		linesFromChunk.add(strLine);
		String neighbourhood = createNeighbourhoodForSectionStartDetection(line, restLines, currentSection) ;

		for ( int j=0 ; j<linesFromChunk.size() ; j++ )
		{
			String chunkFromLine = linesFromChunk.get(j) ;
			chunkFromLine = ignoreUnwatedData(chunkFromLine);
			//	match = SectionsStartDetector.isSectionStart(chunkFromLine, strLine, neighbourhood,line,restLines) ;
			match = SectionsStartDetector.isSectionStart(chunkFromLine, strLine, neighbourhood,line,restLines) ;

			if ( match != null )
			{
				logger.info("matched Chunk-----" +chunkFromLine );
				System.out.println("matched Chunk-----" +chunkFromLine );

				break ;
			}
		}

		return match ;
	}

	private static String ignoreUnwatedData(String chunkFromLine) {
		CleanEnumeratedText cet = new CleanEnumeratedText();
		chunkFromLine = cet.replaceEnums(chunkFromLine);
		chunkFromLine = ignoreBrucketData(chunkFromLine);
		if(!FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Spanish ITR"))
			chunkFromLine = IgnoreDates(chunkFromLine);
		chunkFromLine = ignoreCompanyNames(chunkFromLine);

		/*	List<String> tokens = Utilities.tokenize(chunkFromLine.toLowerCase(), true) ;
		boolean foundKeyword = 
		for(String companySuffix:companySuffixes)
		{
			for(String token:tokens)
			{
				if(token.equalsIgnoreCase(token))
				{
				}
			}
		}*/

		//chunkFromLine = chunkFromLine.replaceAll("[0-9]", "");
		return chunkFromLine;
	}
	private static String ignoreCompanyNames(String chunkFromLine) {
		LinkedHashSet<String> companySuffixes = TimePeriodOntology.getCompanySuffixes();
		for(String companySuffix:companySuffixes)
		{
			if(chunkFromLine.toLowerCase().contains(" "+companySuffix.toLowerCase()+" "))
			{
				int index = chunkFromLine.toLowerCase().indexOf(" "+companySuffix.toLowerCase()+" ");
				chunkFromLine = chunkFromLine.substring(index+companySuffix.toLowerCase().length()+2);
			}

		}
		return chunkFromLine;
	}


	private static String IgnoreDates(String strLine) {
		for(String regex : TimePeriodOntology.getRegexes())
		{
			strLine = strLine.replaceAll(regex.trim(), "").trim();
		}
		return strLine;
	}
	public static String ignoreBrucketData(String strLine) {
		strLine = strLine.replaceAll("\\([^()]*\\)", "");
		strLine = strLine.replaceAll("\\([^(]*?\\)", "");
		return strLine;
	}
	private static boolean isLineSectionStart(PDFLine line, List<PDFLine> restLines,List<String> keyword, String keywordExpression)
	{
		String strLine = line.getLine() ;
		//strLine = IgnoreEnumeration(strLine);
		List<PDFChunk> chunks = line.getChunks() ;
		List<String> linesFromChunk = new ArrayList<String>();
		linesFromChunk.add(strLine);
		//List<String> linesFromChunk = createLinesFromChunk(chunks) ;
		boolean found = false;
		for ( int j=0 ; j<linesFromChunk.size() ; j++ )
		{
			String chunkFromLine = linesFromChunk.get(j) ;
			//chunkFromLine = ignoreUnwatedData(chunkFromLine);
			if(!chunkFromLine.equalsIgnoreCase(""))
				found = SectionsStartDetector.isSectionStart(false,chunkFromLine, strLine,line,restLines,keyword,keywordExpression) ;
			if(!found)
			{
				if(strLine.toLowerCase().contains(keywordExpression.toLowerCase().trim()))
				{
					return true;
				}
			}
			if ( found )
			{
				logger.info("matched Chunk-----" +chunkFromLine );
				break ;
			}
		}



		return found ;
	}

	private static String createNeighbourhoodForSectionStartDetection(PDFLine line, List<PDFLine> restLines, Section currentSection) 
	{
		String ret = line.getLine() ;

		int maxSentencesToCheck = 2 ;
		if(noOfneighbourhoodLines!=-1)
		{
			maxSentencesToCheck = noOfneighbourhoodLines;
		}
		for ( int i=0 ; i<restLines.size() && i<maxSentencesToCheck ; i++ )
		{
			PDFLine restLine = restLines.get(i) ;
			String strRestLine = restLine.getLine() ;

			List<String> tokens = Utilities.tokenize(strRestLine, true) ;
			int size1 = tokens.size() ;

			tokens.removeAll(EntitySuffixOntology.getSuffixes()) ;
			int size2 = tokens.size() ;

			if ( size1 != size2 )
			{
				maxSentencesToCheck++ ;
			}

			ret = ret.trim() + " " + strRestLine ;
		}

		return ret ;
	}

	public static List<String> createLinesFromChunk(List<PDFChunk> chunks) 
	{
		List<String> ret = new ArrayList<String>() ;

		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			String str = "" ;
			for ( int j=i ; j<chunks.size() ; j++ )
			{
				PDFChunk chunk = chunks.get(j) ;
				str = str.trim() + " " + chunk.getChunk() ;
			}

			ret.add(str.trim()) ;
		}

		return ret ;
	}
	public static String getStatementQuality() {
		return statementQuality;
	}
	public void setStatementQuality(String statementQuality) {
		SectionBoundaryDetector.statementQuality = statementQuality;
	}

	public static void main(String args[])
	{
		FinancialStatementExtractor.setLanguage("English");


	}
}
