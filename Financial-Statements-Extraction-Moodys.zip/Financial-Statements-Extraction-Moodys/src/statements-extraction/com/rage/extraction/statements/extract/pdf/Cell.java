package com.rage.extraction.statements.extract.pdf;

import java.util.List;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.detectors.text.DataType;



public class Cell implements Comparable<Cell>
{
	private String strValue ;
	private List<com.rage.extraction.pdf.PDFWord> value ;
	private Row row ;
	
	private Integer level ;
	private Integer lineNo ;
	private Integer index ;
	private DataType dataType ;
	private Column column ;
	private Integer pageNo ;
	private Integer isAssignedColumn;

	
	public Cell(Row row, List<PDFWord> value, Integer level)
	{
		setRow(row) ;
		setValue(value) ;
		setStrValue(createString(getValue())) ;
		setLevel(level) ;
		setPageNo(row.getPageNo());
	}
	
	public static Pair<Float, Float> computeCellBounds(Cell cell) 
	{
		float minX = -1.0f ;
		float maxX = -1.0f ;
		
		List<PDFWord> words = cell.getValue() ;
		
		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			// System.out.println("\nWord = " + word) ;
			List<PDFCharacter> characters = word.getCharacters() ;
			
			float wordX1 = -1.0f ;
			for ( int j=0 ; j<characters.size() ; j++ )
			{
				PDFCharacter character = characters.get(j) ;
				String strCharacter = character.getCharacter() ;
				if(strCharacter.replace("-", "").equalsIgnoreCase(""))
				{
					continue;
				}
				if ( strCharacter.replaceAll("[^a-zA-Z0-9]", "").trim().equalsIgnoreCase("") )
					continue ;
				
				wordX1 = character.getX1() ;
				// System.out.println("\tMin valid character = " + strCharacter + " : " + wordX1) ;
				break ;
			}
			
			float wordX2 = -1.0f ;
			for ( int j=characters.size()-1 ; j>=0 ; j-- )
			{
				PDFCharacter character = characters.get(j) ;
				String strCharacter = character.getCharacter() ;
				if(strCharacter.replace("-", "").equalsIgnoreCase(""))
				{
					continue;
				}
				
				if ( strCharacter.replaceAll("[^a-zA-Z0-9]", "").trim().equalsIgnoreCase("") )
					continue ;
				
				wordX2 = character.getX2() ;
				// System.out.println("\tMax valid character = " + strCharacter + " : " + wordX2) ;
				break ;
			}
			
			if ( wordX1 == -1.0f || wordX2 == -1.0f )
				continue ;
			
			minX = minX == -1.0f || minX > wordX1  ? wordX1 : minX ;
			maxX = maxX == -1.0f || maxX < wordX2 ? wordX2 : maxX ;
			// System.out.println("\tMin-Max = " + minX + " : " + maxX) ;
		}
		
		if ( minX == -1.0f || maxX == -1.0f )
			return null ;
		
		return new Pair<Float, Float>(minX, maxX) ;
	}
	
	static String createString(List<PDFWord> chunk)
	{
		String ret = "" ;
		
		for ( int i=0 ; i<chunk.size() ; i++ )
		{
			PDFWord word = chunk.get(i) ;
			String strWord = word.getWord() ;
			
			ret = ret.trim() + " " + strWord ;
		}
		
		return ret.trim() ;
	}
	
	@Override
	public String toString() 
	{
		String ret = "" ;
		
		Pair<Float, Float> bounds = computeCellBounds(this) ;
		bounds = bounds == null ? new Pair<Float, Float>(-1.0f, -1.0f) : bounds ;
		
		ret = getStrValue() + " [" +getRow().getPageNo() +","+ getRow().getRowNo() + ", " + getLineNo() + ", " + 
				(getColumn() == null ? -1 : getColumn().getColumnID()) + ", " + bounds.getA() + ", " + bounds.getB() + "]" ;
		
		return ret ;
	}
	
	@Override
	public int compareTo(Cell other) 
	{
		if ( !getRow().equals(other.getRow()) )
			return getRow().compareTo(other.getRow()) ;
		
		if ( getLineNo().intValue() != other.getLineNo().intValue() )
			return getLineNo().compareTo(other.getLineNo()) ;
		
		if ( this.getPageNo().intValue() != other.getPageNo().intValue() )
			return getPageNo().compareTo(other.getPageNo()) ;
				
		PDFWord thisFirstWord = getValue().get(0) ;
		PDFWord otherFirstWord = other.getValue().get(0) ;
		
		return new Float(thisFirstWord.getX1()).compareTo(new Float(otherFirstWord.getX1())) ;
	}

	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((row == null) ? 0 : row.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		result = prime * result + ((lineNo == null) ? 0 : lineNo.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());

		
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		Cell other = (Cell) obj;
		
		if (lineNo == null) 
		{
			if (other.lineNo != null)
				return false;
		}
		else if (!lineNo.equals(other.lineNo))
			return false;
		
		if (row == null) 
		{
			if (other.row != null)
				return false;
		} 
		else if (!row.equals(other.row))
			return false;
		
		if (value == null) 
		{
			if (other.value != null)
				return false;
		}
		else if (!value.equals(other.value))
			return false;
		
		
		
		if (pageNo == null) 
		{
			if (other.pageNo != null)
				return false;
		}
		else if (!pageNo.equals(other.pageNo))
			return false;
		
		return true;
	}

	public List<PDFWord> getValue() {
		return value;
	}

	public void setValue(List<PDFWord> value) 
	{
		this.value = value;
	}

	public DataType getDataType() {
		return dataType;
	}

	public void setDataType(DataType dataType) {
		this.dataType = dataType;
	}

	public Row getRow() {
		return row;
	}

	public void setRow(Row row) {
		this.row = row;
	}

	public Column getColumn() {
		return column;
	}

	public void setColumn(Column column) {
		this.column = column;
	}

	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public Integer getIndex() {
		return index;
	}

	public void setIndex(Integer index) {
		this.index = index;
	}

	public String getStrValue() {
		return strValue;
	}

	public void setStrValue(String strValue) {
		this.strValue = strValue;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getIsAssignedColumn() {
		return isAssignedColumn;
	}

	public void setIsAssignedColumn(Integer isAssignedColumn) {
		this.isAssignedColumn = isAssignedColumn;
	}
	
}
