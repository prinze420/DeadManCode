package com.rage.extraction.statements.index;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.DirectoryReader;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.queryparser.classic.QueryParser;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.search.TopDocs;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;
import org.apache.lucene.util.Version;


/**
 * @author kiran.umadi
 *
 */
public class MemIndexer implements Indexer {
	
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(MemIndexer.class);

	private class Outcome implements Comparable<Outcome>
	{
		private float score;

		private Outcome(String ID, String text, float score) {
			this.setID(ID);
			this.setText(text);
			this.score=score;
		}

		@Override
		public int compareTo(Outcome o) {
			if (this.score>o.score)
				return 0;
			else
				return 1;
		}

		public void setID(String iD) {
		}

		public void setText(String text) {
		}
	}
	
	private RAMDirectory memory;
	private IndexWriter writer;
	private IndexSearcher searcher;
	public enum Type {ID, CONTENT};
	private List<Outcome> outcomes;
	private List<Float> searchScore;

	public List<Float> getSearchScore() {
		return searchScore;
	}

	public MemIndexer() {
	}

	public void openIndexer() throws CorruptIndexException, LockObtainFailedException, IOException
	{
		memory=new RAMDirectory();
		writer=new IndexWriter(memory, new IndexWriterConfig(Version.LUCENE_44,new StandardAnalyzer(Version.LUCENE_44)));
	}

	public void indexContent(String id, String content) throws CorruptIndexException, IOException
	{
		if (logger!=null)
			logger.debug("Adding content to indexer :" + content);
		
		Document doc=new Document();
		doc.add(new Field("ID",id, Field.Store.YES, Field.Index.NO));
		doc.add(new Field("englishContent", content, Field.Store.YES, Field.Index.ANALYZED));
		writer.addDocument(doc);
	}

// TODO Remove unused code found by UCDetector
// 	public void indexContent(String id, String content, String nonEngContent) throws CorruptIndexException, IOException
// 	{
// 		if (logger!=null)
// 			logger.debug("Adding content to indexer :" + content);
// 
// 		Document doc=new Document();
// 		doc.add(new Field("ID",id, Field.Store.YES, Field.Index.NO));
// 		doc.add(new Field("englishContent", content, Field.Store.YES, Field.Index.ANALYZED));
// 		doc.add(new Field("nonEnglishContent", nonEngContent, Field.Store.YES, Field.Index.ANALYZED));
// 		writer.addDocument(doc);
// 	}

	public void closeIndexer() throws CorruptIndexException, IOException
	{
		if (logger!=null)
			logger.debug("Optimizing and closing indexer ...");

		//writer.optimize();
		writer.close();
	}

	public void openSearcher(RAMDirectory memory) throws CorruptIndexException, IOException
	{
		if (logger!=null)
			logger.debug("Opening searcher in-memory ...");

		searcher=new IndexSearcher(DirectoryReader.open(memory));;
	}

	public List<String> search(String queryString, String searchFieldName, Type resultType) throws NumberFormatException, Exception {
		if (logger!=null)
			logger.debug("Searching :"+queryString);


		if (searchFieldName==null || searchFieldName.isEmpty())
			searchFieldName = "englishContent";
		
		if (queryString.startsWith("\"") && queryString.endsWith("\""))
			queryString = queryString.replaceAll("\\s\\s+", " ").replaceAll("\\s", " AND ");

		Query query = new QueryParser(Version.LUCENE_44, searchFieldName, new StandardAnalyzer(Version.LUCENE_44)).parse(QueryParser.escape(queryString));
		TopDocs hits = searcher.search(query,1000);
		int hitCount = hits.totalHits;
		
		if (hitCount == 0)
			return new ArrayList<String>();
		else 
		{
			outcomes=new ArrayList<Outcome>();
			searchScore = new ArrayList<Float>();
			List<String> result=new ArrayList<String>();

			if (logger!=null)
				logger.debug("Search results [ Query :"+queryString+" ]");

			for (int i = 0; i < hitCount; i++) 
			{
			
				if (i<hits.scoreDocs.length) {
					Document doc = searcher.doc(hits.scoreDocs[i].doc);
					String id=doc.get("ID");
					String content=doc.get(searchFieldName);
					
					if (resultType.toString().toUpperCase().equals(Type.CONTENT.toString().toUpperCase()))
						result.add(content);
					
					else if (resultType.equals(Type.ID))
						result.add(id);
					
					if (logger!=null)
						logger.debug("=="+hits.scoreDocs[i].score+"\t"+content);

					outcomes.add(new Outcome(id, content, hits.scoreDocs[i].score));
					searchScore.add(hits.scoreDocs[i].score);
				} else
					break;
			}
			return result;
		}
	}

	public List<String> search(String queryString, Type resultType) throws NumberFormatException, Exception
	{
		return search(queryString, null, resultType);
	}

	public void closeSearcher() throws IOException
	{
		//searcher.close();
	}

	public RAMDirectory getMemory()
	{
		return memory;
	}

	public IndexWriter getWriter() {
		return writer;
	}

	public IndexSearcher getSearcher() {
		return searcher;
	}

}
