package com.rage.extraction.statements.similarity;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


/**
 * @author kiran.umadi
 *
 * Similarity of asymmetric binary attributes
 */

public class JaccordSimilarity implements Similarity
{
	private List<String> arg1;
	private List<String> arg2;

	public JaccordSimilarity()
	{
	}

	//1 if similar and non 0 if dissimilar
	public float jaccardSimilarity(String arg1, String arg2)
	{
		this.arg1=tokenize(arg1);
		this.arg2=tokenize(arg2);
		Set<String> union=new HashSet<String>(this.arg1);
		union.addAll(this.arg2);
		float unionSize=union.size();
		Set<String> intersection=new HashSet<String>(this.arg1);
		intersection.retainAll(this.arg2);
		float intersectSize=intersection.size();
		return intersectSize/unionSize;
	}

	public float jaccardDistance(String arg1, String arg2)
	{
		this.arg1=tokenize(arg1);
		this.arg2=tokenize(arg2);
		Set<String> union=new HashSet<String>(this.arg1);
		union.addAll(this.arg2);
		float unionSize=union.size();
		Set<String> intersection=new HashSet<String>(this.arg1);
		intersection.retainAll(this.arg2);
		float intersectSize=intersection.size();
		return (unionSize-intersectSize)/unionSize;
	}

	private List<String> tokenize(String text)
	{
		String[] tokens=text.split("\\W");
		List<String> tokenList=new ArrayList<String>();
		for (String token:tokens)
			if (!token.trim().equals(""))
				tokenList.add(token);
		return tokenList;
	}
	
	@Override
	public boolean match(String text1, String text2) {
		return false;
	}
	
	public static void main(String[] args) {
		System.out.println(new JaccordSimilarity().jaccardSimilarity("Wel    come", "Wel-come"));
	}
}
