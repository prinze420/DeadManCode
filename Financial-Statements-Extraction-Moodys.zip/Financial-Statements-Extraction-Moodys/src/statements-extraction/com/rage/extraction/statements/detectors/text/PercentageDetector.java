package com.rage.extraction.statements.detectors.text;

public class PercentageDetector 
{
	
}
