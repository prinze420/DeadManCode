package com.rage.extraction.statements.extract.pdf;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.detectors.text.DataType;


public class Column implements Comparable<Column>
{
	private Integer columnID ;
	
	private Pair<Float, Float> bounds ;
	private List<Cell> cells ;
	private DataType dataType ;
	private String complexityType ;
	
	public Column(Integer columnID)
	{
		setColumnID(columnID) ;
	}
	
	public Column(Integer columnID, List<Cell> cells)
	{
		setColumnID(columnID) ;
		setCells(cells) ;
		if(cells.size()!=0){
		Cell firstCell = cells.get(0) ;
		float x1 = firstCell.getValue().get(0).getX1() ;
		float x2 = firstCell.getValue().get(firstCell.getValue().size()-1).getX2() ;
		
		for ( int i=1 ; i<cells.size() ; i++ )
		{
			
			Cell cell = cells.get(i) ;
			cell.setColumn(this) ;
			
			float cellX1 = cell.getValue().get(0).getX1() ;
			float cellX2 = cell.getValue().get(cell.getValue().size()-1).getX2() ;
			
			if ( x1 > cellX1 )
				x1 = cellX1 ;
			
			if ( x2 < cellX2 )
				x2 = cellX2 ;
		}
		
		Pair<Float, Float> bounds = new Pair<Float, Float>(x1, x2) ;
		setBounds(bounds) ;
		}
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() 
	{
		String ret = "" ;
		
		ret = getColumnID() + " [" + (getBounds() != null ? getBounds().toString() : "") + "] [" ;
		
		List<Cell> cells = getCells() ;
		for ( int j=0 ; j<cells.size() ; j++ )
		{
			Cell cell = cells.get(j) ;
			ret = ret.trim() + " ---- " + cell ;
		}
		
		return ret + "]" ;
	}
	
	/*public Column(Integer columnID, List<Cell> cells)
	{
		setColumnID(columnID) ;
		
		if(cells.size()!=0){
		setCells(cells) ;
		Cell firstCell = cells.get(0) ;
		float x1 = firstCell.getValue().get(0).getX1() ;
		float x2 = firstCell.getValue().get(firstCell.getValue().size()-1).getX2() ;
		List<Float> x1List=new ArrayList<Float>();
		List<Float> x2List=new ArrayList<Float>();
		x1List.add(x1);
		x2List.add(x2);
		for ( int i=1 ; i<cells.size() ; i++ )
		{
			
			Cell cell = cells.get(i) ;
			cell.setColumn(this) ;
			
			float cellX1 = cell.getValue().get(0).getX1() ;
			float cellX2 = cell.getValue().get(cell.getValue().size()-1).getX2() ;
			
			if ( x1 > cellX1 )
				x1 = cellX1 ;
			
			if ( x2 < cellX2 )
				x2 = cellX2 ;
			
			x1List.add(cellX1);
			x2List.add(cellX2);
		}
		x1=mostCommon(x1List);
		x2=mostCommon(x2List);
		Pair<Float, Float> bounds = new Pair<Float, Float>(x1, x2) ;
		setBounds(bounds) ;
		}
		else
		{
			setCells(new ArrayList<Cell>());
			Pair<Float, Float> bounds = new Pair<Float, Float>(0f, 0f) ;
			setBounds(bounds) ;
		}
	}*/
	
	public static Float mostCommon(List<Float> list) {
	    Map<Float, Integer> map = new HashMap<Float,Integer>();

	    for (Float t : list) {
	        Integer val = map.get(t);
	        map.put(t, val == null ? 1 : val + 1);
	    }

	    Entry<Float, Integer> max = null;

	    for (Entry<Float, Integer> e : map.entrySet()) {
	        if (max == null || e.getValue() > max.getValue())
	            max = e;
	    }

	    return max.getKey();
	}
	
	public void addCells(List<Cell> cells)
	{
		for ( int i=0 ; i<cells.size() ; i++ )
		{
			Cell cell = cells.get(i) ;
			addCell(cell) ;
		}
	}

	void addCell(Cell cell)
	{
		cell.setColumn(this) ;
		
		getCells().add(cell) ;
		setCells(CellsCreater.sortCells(getCells())) ;
		
		// Pair<Float, Float> oldBounds = getBounds() ;
		
	}
	
	@Override
	public int compareTo(Column other) 
	{
		return getColumnID().compareTo(other.getColumnID()) ;
	}

	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((bounds == null) ? 0 : bounds.hashCode());
		result = prime * result + ((cells == null) ? 0 : cells.hashCode());
		result = prime * result + ((columnID == null) ? 0 : columnID.hashCode());
		result = prime * result + ((complexityType == null) ? 0 : complexityType.hashCode());
		result = prime * result + ((dataType == null) ? 0 : dataType.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Column other = (Column) obj;
		if (bounds == null) {
			if (other.bounds != null)
				return false;
		} else if (!bounds.equals(other.bounds))
			return false;
		if (cells == null) {
			if (other.cells != null)
				return false;
		} else if (!cells.equals(other.cells))
			return false;
		if (columnID == null) {
			if (other.columnID != null)
				return false;
		} else if (!columnID.equals(other.columnID))
			return false;
		if (complexityType == null) {
			if (other.complexityType != null)
				return false;
		} else if (!complexityType.equals(other.complexityType))
			return false;
		if (dataType != other.dataType)
			return false;
		return true;
	}

	public Integer getColumnID() {
		return columnID;
	}

	public void setColumnID(Integer columnID) {
		this.columnID = columnID;
	}

	public List<Cell> getCells() {
		return cells;
	}

	public void setCells(List<Cell> cells)
	{
		this.cells = cells;
		
		for ( int i=0 ; i<getCells().size() ; i++ )
		{
			Cell cell = getCells().get(i) ;
			cell.setColumn(this) ;
		}
	}
	
	public DataType getDataType() {
		return dataType;
	}

	public void setDataType(DataType dataType) {
		this.dataType = dataType;
	}

	public String getComplexityType() {
		return complexityType;
	}

	public void setComplexityType(String complexityType) {
		this.complexityType = complexityType;
	}

	public Pair<Float, Float> getBounds() {
		return bounds;
	}

	public void setBounds(Pair<Float, Float> bounds) {
		this.bounds = bounds;
	}
}
