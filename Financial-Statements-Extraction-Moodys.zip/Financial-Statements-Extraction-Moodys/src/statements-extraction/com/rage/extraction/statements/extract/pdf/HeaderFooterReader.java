package com.rage.extraction.statements.extract.pdf;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.TreeSet;

public class HeaderFooterReader {

	private static TreeSet<String> keywords ;
	public static TreeSet<String> getKeywords()
	{
		if ( keywords == null )
		{
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName = "resource/section-identification/ignoreKeywords.txt";
			else
			{
				//fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+" - ignoreKeywords.txt" ;
				fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/ignoreKeywords.txt" ;

			}
			keywords = loadIgnoreKeywordsFromFile(fileName) ;
		}

		return keywords ;
	}

	private static TreeSet<String> loadIgnoreKeywordsFromFile(String fileName) 
	{
		TreeSet<String> ret = new TreeSet<String>() ;

		BufferedReader br = null ;

		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;

				line = line.trim().toLowerCase() ;
		
				ret.add(line) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}

	public static void main(String[] args) 
	{
		System.out.println(HeaderFooterReader.getKeywords()) ;
	}

}
