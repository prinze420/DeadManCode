package com.rage.extraction.statements.extract.pdf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.document.pdf.utils.CustomFileWriter;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.attributes.Attributes;
import com.rage.extraction.statements.attributes.StatementAttributes;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.detectors.text.DataType;
import com.rage.extraction.statements.detectors.text.DataTypeFinder;
import com.rage.extraction.statements.detectors.text.NumberDetector;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.uitls.CleanEnumeratedText;
import com.rage.extraction.statements.uitls.Utilities;


public class SectionSpreader 
{
	public static LinkedHashSet<String> languagetoReplacefromDots;
	private static LinkedHashSet<String> stmtForList;
	private static Boolean DEBUG = Boolean.FALSE ;
	private static TreeSet<String> TOTAL_KEYWORDS_CONTAINS = new TreeSet<String>(Arrays.asList(new String[] {
			"TOTAL", "GROSS","NET"
	})) ;


	private static HashSet<String> MERGE_KEYWORDS = new HashSet<String>(Arrays.asList(new String[] {
			"institutions","ACUMULADA", "AMORTIZACI�N", "Y", "LUBRICANTES"//"AMORTIZACIN"/*"AMORTIZACIN","CAPITAL"*/

	})) ;

	private static LinkedHashSet<String> labelMergeLanguageList = null;
	//private static TreeSet<String>  FOOTER_DATA_KEYWORDS = HeaderFooterReader.getKeywords();
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SectionSpreader.class);


	public static void getLanguages()
	{
		if(labelMergeLanguageList==null)
		{
			String fileName = "resource/section-identification/languageSpecificRules.txt" ;
			if(TimePeriodOntology.getLanguageSpecificMap()==null)
			{
				TimePeriodOntology.loadRules(fileName) ;
			}

			if(TimePeriodOntology.getLanguageSpecificMap().containsKey("[Label-Merge]"))
				labelMergeLanguageList = (TimePeriodOntology.getLanguageSpecificMap().get("[Label-Merge]"));

		}
	}

	static ArrayList<ParserOutput> spreadBreakups(Section section,List<PDFLine> lines,List<PDFBlock> blocks) throws Exception
	{
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		List<Row> rows = null;
		int maxCol = 0;
		TreeMap<Integer, List<Row>> pageRowsMap =null;
		getLanguages();
		Boolean isHeaderContainsStmtFor = false;
		Pair<Float, Float> sectionXBound=getSectionXBound(lines);
		Map<Integer, String> forList = null;

		if(section.getKeyword().getRowSegmentationType()!=null  && section.getKeyword().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW))
		{
			rows = createPreliminaryRowsbyPara(lines,blocks) ;
		}
		else
		{
			rows = createPreliminaryRows(lines) ;
			if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
				rows = combineRowsByCase(rows) ; 
		}
		reCreateRowLines(rows) ;
		removeFalsePositiveTypes(rows) ;
		pageRowsMap = createPageRowsMap(rows);

		for ( Integer pageNo : pageRowsMap.keySet() )
		{
			List<Row> pageRows = pageRowsMap.get(pageNo) ;
			HashMap<Row,List<List<PDFWord>>> headerMap = new HashMap<Row,List<List<PDFWord>>>();
			HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
			List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
			List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
			removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, rows,sectionXBound) ;
			printNumericColumns(numericColumns, numericBounds) ;

			if ( FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") && isSectionFalsePositive(pageRows) &&  !section.getSectionName().equalsIgnoreCase("SUPPL") && !section.getSectionName().equalsIgnoreCase("SD") && !FinancialStatementExtractor.getLanguage().contains("ITR"))
			{
				logger.info("False Positive Section .... ") ;
				//section.setReprocessMeta(null);
				continue ;
			} 
			List<Row> headerCandidates = null;

			headerCandidates = findHeaderRowCandidatesFromNumericColumns(pageRows, wordRowsMap, numericColumns, numericBounds) ;
			logger.info("Numeric Rows ... ") ;

			HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;

			if(rows!=null)
				reCreateChunks(rows) ;

			List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
			List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, headerMap, numericColumns, numericBounds, wordRowsMap,headerCandidates) ;
			if(headerCandidates!=null && headerCandidates.size()>0)
			{
				Collections.sort(headerCandidates);
				chunkBoundsCorrection(chunkBounds);
				for(Row headerRow:headerCandidates)
				{
					List<List<PDFWord>> headerColumns = getHeaderChunkColumns(chunkColumns,chunkBounds,headerRow, wordRowsMap,chunkRowsMap) ;
					headerMap.put(headerRow, headerColumns);
				}
			}
			TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = createRowColumnChunksMap(pageRows, chunkColumns, chunkRowsMap, headerCandidates) ;
			printRowColumnChunks(rowColumnChunksMap) ;

			if(!section.getSectionName().equalsIgnoreCase("SUPPL") && !FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				removeNumbersFromLabel(rowColumnChunksMap);
			maxCol = getMaxCol(rowColumnChunksMap, maxCol);

			if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
			{
				if(isTotalColumnSeperate(rowColumnChunksMap,maxCol) && FinancialStatementExtractor.getLanguage().equals("English"))
				{
					shifTotalRowLastColumn(rowColumnChunksMap, maxCol);
				}
			}

			if (maxCol == 1 || maxCol == 0)
			{
				continue;
			}

			logger.info("Final Columns ... ") ;
			System.out.println("Final Columns ... ") ;

			printRowColumnChunks(rowColumnChunksMap) ;
			ArrayList<ParserOutput> headerObjects = null;
			ParserOutput po = null;
			if(headerMap.size()>0)
			{
				headerObjects = getPoObjectsFromHeaderColumns(headerMap,section,maxCol,pageNo);
				Collections.sort(headerObjects);
				po = combineHeaders(headerObjects);

				if(!isHeaderContainsStmtFor)
				{
					forList = isHeaderContainsStatementForKeywords(po);
					if(forList.size()>0)
						isHeaderContainsStmtFor = true;
				}
			}
			if(rowColumnChunksMap.size()>0)
			{
				ArrayList<ParserOutput> pageObjects = null;
				if(section.getKeyword()!=null)
					pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),section.getKeyword().getColumnNo(),section.getKeyword().getKeyword(),section.getSubSection());
				else
					pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),0,"","");

				Integer HeaderLineNo =-1;

				if(po!=null)
				{
					pageObjects.add(po);
					HeaderLineNo = po.getLineNo();
				}
				if(!FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					SectionSpreader ss = new SectionSpreader();

					if((headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString()))) )
					{
						maxCol = maxCol-1;
						for(ParserOutput po1 : pageObjects)
						{
							po1.setMaxCol(maxCol);
						}
						maxCol = ss.deleteNotesColumn(pageObjects,maxCol,null);
					}
					maxCol = ss.deleteEmptyColumn(pageObjects,maxCol,HeaderLineNo,0.90);
				}

				if(pageObjects!=null)
				{
					poObjects.addAll(pageObjects);
				}
				if(poObjects.size()==1)
				{
					break;	
				}
			}

			logger.info("\\ n\n\n") ;
		}
		return poObjects;
	}


	public static ArrayList<ParserOutput> spreadPageData(Section section) throws Exception
	{

		if(stmtForList==null)
			stmtForList = TimePeriodOntology.loadSuffixes("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/statement-for.txt");

		List<PDFLine> lines = section.getLines() ;
		List<PDFBlock> blocks = section.getBlocks() ; 
		Pair<Float, Float> sectionXBound=getSectionXBound(lines);
		Boolean isISBreakup =false;
		List<Row> rows = null;
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		int maxCol = 0;
		TreeMap<Integer, List<Row>> pageRowsMap =null;
		getLanguages();
		Boolean isHeaderContainsStmtFor = false;
		Map<Integer, String> forList = null;
		/*if(section.getSectionName().equalsIgnoreCase("SUPPL"))
		{
			if(section.getSubSection()!=null && section.getScope()!=null && !section.getScope().equalsIgnoreCase("tabular"))  
			{
				return getPoObjectsSuppl(section, lines, blocks, poObjects);
			}

			if(section.getKeyword().getRowSegmentationType()!=null  && section.getKeyword().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW))
			{
				rows = createPreliminaryRowsbyPara(lines,blocks) ;
			}
			else
			{

				rows = createPreliminaryRows(lines) ;
				if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
					rows = combineRowsByCase(rows) ; 

			}
			reCreateRowLines(rows) ;
			removeFalsePositiveTypes(rows) ;
			pageRowsMap = createPageRowsMap(rows);
		}
		else
		{*/
		pageRowsMap = section.getPageRowsMap(); //createPageRowsMap(rows) ;

		if(pageRowsMap==null)
		{
			if(section.getKeyword()!=null && section.getKeyword().getRowSegmentationType()!=null  && section.getKeyword().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW))
			{
				rows = createPreliminaryRowsbyPara(lines,blocks) ;
			}
			else
			{
				rows = createPreliminaryRows(lines) ;
				if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
					rows = combineRowsByCase(rows) ; 
			}
			reCreateRowLines(rows) ;
			removeFalsePositiveTypes(rows) ;
			pageRowsMap = createPageRowsMap(rows);
		}
		/*}*/
		for ( Integer pageNo : pageRowsMap.keySet() )
		{
			List<Row> pageRows = pageRowsMap.get(pageNo) ;
			if(pageRows.size()<=1 && pageRowsMap.size()==1 && pageRows.get(0).getLines().get(0).isTableID())
			{
				continue;
			}
			//Map<Integer,List<Row>> pageRowsNew  =  new LinkedHashMap<Integer,List<Row>>();

			//Map<Integer,List<Row>> pageRowsNew  = seprateSideBySideColumnRows(pageRows,lines);
			Map<Integer,List<Row>> pageRowsNew  =  new LinkedHashMap<Integer,List<Row>>();
			if(!FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase("Chinese"))
				pageRowsNew  = seprateSideBySideColumnRows(pageRows);

			logger.info("Page No: " + pageNo) ;

			logger.info("Page No: " + pageNo) ;

			if(pageRowsNew.isEmpty())
				pageRowsNew.put(1, pageRows);

			for( Integer tbl : pageRowsNew.keySet() )
			{
				pageRows = pageRowsNew.get(tbl);
				HashMap<Row,List<List<PDFWord>>> headerMap = new HashMap<Row,List<List<PDFWord>>>();

				HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
				List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
				List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
				spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
				removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, rows,sectionXBound) ;
				float minX1FromRows=getMinimumXFromRows(pageRows);
				removeFalseRowFromStart(minX1FromRows,numericColumns, numericBounds,pageRows);
				printNumericColumns(numericColumns, numericBounds) ;


				if (!FinancialStatementExtractor.getLanguage().equalsIgnoreCase("chinese") 
						&& !FinancialStatementExtractor.getLanguage().equalsIgnoreCase("italian") 
						&& FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") 
						&& isSectionFalsePositive(pageRows) 
						&&  !section.getSectionName().equalsIgnoreCase("SUPPL") 
						&& !section.getSectionName().equalsIgnoreCase("SD") 
						&& !FinancialStatementExtractor.getLanguage().contains("ITR"))
				{
					logger.info("False Positive Section .... ") ;
					//section.setReprocessMeta(null);
					continue ;
				} 
				List<Row> headerCandidates = null;

				/*if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR") && section.getSectionName().equalsIgnoreCase("IS"))
			{
				headerCandidates = findHeaderRow(pageRows) ;
			}
			else*/
				headerCandidates = findHeaderRowCandidatesFromNumericColumns(pageRows, wordRowsMap, numericColumns, numericBounds) ;
				headerCandidates = addRemainingHeaderCandidates(pageRows, wordRowsMap, numericColumns, numericBounds,headerCandidates);
				//HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;


				logger.info("Numeric Rows ... ") ;
				//	Row headerRow = pruneHeaderRows(headerCandidates, pageRows) ;
				//System.out.println("Header Row = " + headerRow) ;
				HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;

				/*if(headerCandidates!=null && headerCandidates.size()>0)
			{
				Collections.sort(headerCandidates);
				for(Row headerRow:headerCandidates)
				{
					List<List<PDFWord>> headerColumns = getHeaderColumns(numericColumns,numericBounds,headerRow, wordRowsMap,chunkRowsMap,headerCandidates) ;
					headerMap.put(headerRow, headerColumns);
				}
				//columns = getCols(headerColumns,headerRow);
			}
				 */
				if(rows!=null)
					reCreateChunks(rows) ;

				List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
				List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
				spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, headerMap, numericColumns, numericBounds, wordRowsMap,headerCandidates) ;
				if(headerCandidates!=null && headerCandidates.size()>0)
				{
					Collections.sort(headerCandidates);
					chunkBoundsCorrection(chunkBounds);
					for(Row headerRow:headerCandidates)
					{
						List<List<PDFWord>> headerColumns = getHeaderChunkColumns(chunkColumns,chunkBounds,headerRow, wordRowsMap,chunkRowsMap) ;
						headerMap.put(headerRow, headerColumns);
					}
				}
				TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = createRowColumnChunksMap(pageRows, chunkColumns, chunkRowsMap, headerCandidates) ;
				printRowColumnChunks(rowColumnChunksMap) ;

				writeRowColsToFile(rowColumnChunksMap);

				if(!section.getSectionName().equalsIgnoreCase("SUPPL") && !FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
					removeNumbersFromLabel(rowColumnChunksMap);
				maxCol = getMaxCol(rowColumnChunksMap, maxCol);

				if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
				{
					if(isTotalColumnSeperate(rowColumnChunksMap,maxCol) && FinancialStatementExtractor.getLanguage().equals("English"))
					{
						shifTotalRowLastColumn(rowColumnChunksMap, maxCol);
					}
				}

				/*	if(headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString())))
			{
				maxCol = maxCol-1;
			}
				 */
				if (maxCol == 1 || maxCol == 0)
				{
					//section.setReprocessMeta(null);
					continue;
				}

				logger.info("Final Columns ... ") ;
				System.out.println("Final Columns ... ") ;

				printRowColumnChunks(rowColumnChunksMap) ;
				ArrayList<ParserOutput> headerObjects = null;
				ParserOutput po = null;
				if(headerMap.size()>0)
				{
					headerObjects = getPoObjectsFromHeaderColumns(headerMap,section,maxCol,pageNo);
					Collections.sort(headerObjects);
					po = combineHeaders(headerObjects);

					if(!isHeaderContainsStmtFor)
					{
						forList = isHeaderContainsStatementForKeywords(po);
						if(forList.size()>0)
							isHeaderContainsStmtFor = true;
					}
				}
				if(rowColumnChunksMap.size()>0)
				{
					ArrayList<ParserOutput> pageObjects = null;
					if(section.getKeyword()!=null)
						pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),section.getKeyword().getColumnNo(),section.getKeyword().getKeyword(),section.getSubSection());
					else
						pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),0,"","");

					Integer HeaderLineNo =-1;

					if(po!=null)
					{
						pageObjects.add(0,po);
						HeaderLineNo = po.getLineNo();
					}
					if(!FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
					{
						SectionSpreader ss = new SectionSpreader();

						if((headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString()))) )
						{
							maxCol = maxCol-1;
							for(ParserOutput po1 : pageObjects)
							{
								po1.setMaxCol(maxCol);
							}
							maxCol = ss.deleteNotesColumn(pageObjects,maxCol,null);
						}
						maxCol = ss.deleteEmptyColumn(pageObjects,maxCol,HeaderLineNo,0.90);
					}
					maxCol = getMaxCol(pageObjects);

					if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
					{
						if(section.getSectionName().equalsIgnoreCase("IS") && section.getKeyword().getKeyword().toString().toUpperCase().equalsIgnoreCase("ESTADO DE RESULTADOS"))
						{
							maxCol=2;
						}
						else
						{
							if(section.getSectionName().equalsIgnoreCase("IS"))
								isISBreakup = true;
						}
					}
					if(pageObjects!=null)
					{
						poObjects.addAll(pageObjects);
					}
					if(poObjects.size()==1)
					{
						break;	
					}
				}

				logger.info("\\ n\n\n") ;
			}
			if(poObjects.size()==1)
			{
				continue;	
			}
		}

		//identifySectionType Group or subsidiary
		identifySectionType(section,poObjects);
		//identifySectionType Group or subsidiary

		ArrayList<ParserOutput> attributes  = new ArrayList<ParserOutput>();

		if(poObjects.size()>0 )
		{

			if(!isISBreakup && !section.getSectionName().equalsIgnoreCase("SUPPL"))
			{
				attributes.addAll(poObjects);
				TreeSet<String> Keywords = HeadingKeywords.getKeywords();
				if(!FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					for(ParserOutput po:poObjects)
					{
						if(po!=null)
						{
							maxCol = po.getMaxCol();
							break;
						}
					}
				}
				attributes.addAll(generateStatementAttributes(attributes,maxCol-1,Keywords,forList));
				if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
					maxCol = adjustSingleValueColumns(attributes,maxCol);
				Collections.sort(attributes);
			}
			else
				attributes.addAll(poObjects);
		}

		checkHeadings(attributes);

		return attributes;

	}




	private static void removeFalseRowFromStart(float minX1FromRows, List<List<PDFWord>> numericColumns,
			List<Pair<Float, Float>> numericBounds, List<Row> pageRows) 
	{
		if(minX1FromRows<0.1f)
			return;
		List<List<PDFWord>> newColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;
		float wordWidth=getBiggestWordWidth(pageRows);
		for(int i=0;i<numericBounds.size();i++)
		{
			Pair<Float, Float> bound=numericBounds.get(i);
			List<PDFWord> colData=numericColumns.get(i);

			float startThreshold=minX1FromRows+wordWidth;
			if(bound.getB()<startThreshold)
			{
				// remove the column
				continue;
			}
			newColumns.add(colData) ;
			newBounds.add(bound) ;
		}
		numericColumns.clear() ;
		numericColumns.addAll(newColumns) ;

		numericBounds.clear() ;
		numericBounds.addAll(newBounds) ;
	}

	private static float getBiggestWordWidth(List<Row> pageRows) 
	{
		if(pageRows==null || pageRows.size()<1)
			return 0.0f;
		float diff=0.0f;
		for(Row row:pageRows)
		{
			if(row.getLines()!=null)
			{
				for(PDFLine line:row.getLines())
				{
					for(PDFChunk chunk:line.getChunks())
					{
						for(PDFWord word:chunk.getWords())
						{
							if(!word.getWord().trim().equals(""))
							{
								float width=word.getX2()-word.getX1();
								if(diff<width)
								{
									diff=width;
								}
							}
						}
					}
				}
			}
		}
		return diff;
	}

	private static float getMinimumXFromRows(List<Row> pageRows) 
	{
		if(pageRows==null || pageRows.size()<1)
			return 0;
		float x1=Float.MAX_VALUE;
		boolean isFound=false;
		for(Row row:pageRows)
		{
			for(PDFLine line:row.getLines())
			{
				if(line.getX1()<x1)
				{
					x1=line.getX1();
					isFound=true;
				}
			}
		}
		if(isFound)
			return x1;
		return 0;
	}

	private static int getMaxCol(ArrayList<ParserOutput> pageObjects) {
		int  ct=0;
		Boolean poasRep=false;
		Boolean poVal1=false;
		Boolean poVal2=false;
		Boolean poVal3=false;
		Boolean poVal4=false;
		Boolean poVal5=false;
		Boolean poVal6=false;
		Boolean poVal7=false;
		Boolean poVal8=false;
		Boolean poVal9=false;
		Boolean poVal10=false;
		Boolean poVal11=false;
		Boolean poVal12=false;
		Boolean poVal13=false;
		Boolean poVal14=false;
		Boolean poVal15=false;
		Boolean poVal16=false;
		Boolean poVal17=false;
		Boolean poVal18=false;
		Boolean poVal19=false;
		Boolean poVal20=false;



		for(ParserOutput po:pageObjects)
		{
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") || ( po.getPrevHeader()!=null &&  po.getPrevHeader().equalsIgnoreCase("Y")))
			{
				continue;
			}
			if(po.getAsRepLabel()!=null && !po.getAsRepLabel().trim().equalsIgnoreCase("") && !poasRep)
			{
				poasRep=true;
				ct++;
			}
			if(po.getAsRepVal1()!=null && !po.getAsRepVal1().trim().equalsIgnoreCase("") && !poVal1)
			{
				poVal1=true;
				ct++;
			}
			if(po.getAsRepVal2()!=null && !po.getAsRepVal2().trim().equalsIgnoreCase("") && !poVal2)
			{
				poVal2=true;
				ct++;
			}
			if(po.getAsRepVal3()!=null && !po.getAsRepVal3().trim().equalsIgnoreCase("") && !poVal3)
			{
				poVal3=true;
				ct++;
			}
			if(po.getAsRepVal4()!=null && !po.getAsRepVal4().trim().equalsIgnoreCase("") && !poVal4)
			{
				poVal4=true;
				ct++;
			}
			if(po.getAsRepVal5()!=null && !po.getAsRepVal5().trim().equalsIgnoreCase("") && !poVal5)
			{
				poVal5=true;
				ct++;
			}
			if(po.getAsRepVal6()!=null && !po.getAsRepVal6().trim().equalsIgnoreCase("") && !poVal6)
			{
				poVal6=true;
				ct++;
			}
			if(po.getAsRepVal7()!=null && !po.getAsRepVal7().trim().equalsIgnoreCase("") && !poVal7)
			{
				poVal7=true;
				ct++;
			}
			if(po.getAsRepVal8()!=null && !po.getAsRepVal8().trim().equalsIgnoreCase("") && !poVal8)
			{
				poVal8=true;
				ct++;
			}
			if(po.getAsRepVal9()!=null && !po.getAsRepVal9().trim().equalsIgnoreCase("") && !poVal9)
			{
				poVal9=true;
				ct++;
			}
			if(po.getAsRepVal10()!=null && !po.getAsRepVal10().trim().equalsIgnoreCase("") && !poVal10)
			{
				poVal10=true;
				ct++;
			}
			if(po.getAsRepVal11()!=null && !po.getAsRepVal11().trim().equalsIgnoreCase("") && !poVal11)
			{
				poVal11=true;
				ct++;
			}
			if(po.getAsRepVal12()!=null && !po.getAsRepVal12().trim().equalsIgnoreCase("") && !poVal12)
			{
				poVal12=true;
				ct++;
			}
			if(po.getAsRepVal13()!=null && !po.getAsRepVal13().trim().equalsIgnoreCase("") && !poVal13)
			{
				poVal13=true;
				ct++;
			}
			if(po.getAsRepVal14()!=null && !po.getAsRepVal14().trim().equalsIgnoreCase("") && !poVal14)
			{
				poVal14=true;
				ct++;
			}
			if(po.getAsRepVal15()!=null && !po.getAsRepVal15().trim().equalsIgnoreCase("") && !poVal15)
			{
				poVal15=true;
				ct++;
			}
			if(po.getAsRepVal16()!=null && !po.getAsRepVal16().trim().equalsIgnoreCase("") && !poVal16)
			{
				poVal16=true;
				ct++;
			}
			if(po.getAsRepVal17()!=null && !po.getAsRepVal17().trim().equalsIgnoreCase("") && !poVal17)
			{
				poVal17=true;
				ct++;
			}
			if(po.getAsRepVal18()!=null && !po.getAsRepVal18().trim().equalsIgnoreCase("") && !poVal18)
			{
				poVal18=true;
				ct++;
			}
			if(po.getAsRepVal19()!=null && !po.getAsRepVal19().trim().equalsIgnoreCase("") && !poVal19)
			{
				poVal19=true;
				ct++;
			}
			if(po.getAsRepVal20()!=null && !po.getAsRepVal20().trim().equalsIgnoreCase("") && !poVal20)
			{
				poVal20=true;
				ct++;
			}
		}

		for(ParserOutput po1 : pageObjects)
		{
			po1.setMaxCol(ct);
		}
		return (ct);
	}





	public static void removeFalseNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds, HashMap<PDFWord,Row> wordRowsMap, List<Row> rows) 
	{
		int minValuesInFalseColumns = 1 ;

		List<List<PDFWord>> newColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			if ( column.size() >= minValuesInFalseColumns )
			{
				newColumns.add(column) ;
				newBounds.add(bound) ;

				continue ;
			}

			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFWord word = column.get(j) ;

				Row row = wordRowsMap.remove(word) ;
				if ( row == null )
					continue ;

				HashMap<DataType, List<PDFWord>> typeWordsMap = row.getTypeWordsMap() ;
				for ( DataType type : typeWordsMap.keySet() )
				{
					List<PDFWord> thisTypeWords = typeWordsMap.get(type) ;
					thisTypeWords.remove(word) ;
				}

				row.setTypeWordsMap(typeWordsMap) ;
			}
		}

		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static void checkHeadings(ArrayList<ParserOutput> stmtAttributes) {
		int colNo = isHeaderContains(TimePeriodOntology.getBalanceList(),stmtAttributes);
		if(colNo>0)
		{
			for(ParserOutput po:stmtAttributes)
			{
				if(po.getAsRepLabel().contains("STATEMENT YEAR"))
				{
					switch(colNo)
					{
					case 1:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue1());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal1(String.valueOf(yr-1));
							po.setValue1(String.valueOf(yr-1));
						}
						break;
					}
					case 2:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue2());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal2(String.valueOf(yr-1));
							po.setValue2(String.valueOf(yr-1));
						}
						break;
					}
					case 3:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue3());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal3(String.valueOf(yr-1));
							po.setValue3(String.valueOf(yr-1));
						}
						break;
					}
					case 4:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue4());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal4(String.valueOf(yr-1));
							po.setValue4(String.valueOf(yr-1));
						}
						break;
					}
					case 5:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue5());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal5(String.valueOf(yr-1));
							po.setValue5(String.valueOf(yr-1));
						}
						break;
					}
					case 6:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue6());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal6(String.valueOf(yr-1));
							po.setValue6(String.valueOf(yr-1));
						}
						break;
					}
					case 7:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue7());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal7(String.valueOf(yr-1));
							po.setValue7(String.valueOf(yr-1));
						}
						break;
					}
					case 8:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue8());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal8(String.valueOf(yr-1));
							po.setValue8(String.valueOf(yr-1));
						}
						break;
					}
					case 9:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue9());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal9(String.valueOf(yr-1));
							po.setValue9(String.valueOf(yr-1));
						}
						break;
					}
					case 10:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue10());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal10(String.valueOf(yr-1));
							po.setValue10(String.valueOf(yr-1));
						}
						break;
					}
					case 11:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue11());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal11(String.valueOf(yr-1));
							po.setValue11(String.valueOf(yr-1));
						}
						break;
					}
					case 12:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue12());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal12(String.valueOf(yr-1));
							po.setValue12(String.valueOf(yr-1));
						}
						break;
					}
					case 13:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue13());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal13(String.valueOf(yr-1));
							po.setValue13(String.valueOf(yr-1));
						}
						break;
					}
					case 14:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue14());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal14(String.valueOf(yr-1));
							po.setValue14(String.valueOf(yr-1));
						}
						break;
					}
					case 15:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue15());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal15(String.valueOf(yr-1));
							po.setValue15(String.valueOf(yr-1));
						}
						break;
					}
					case 16:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue16());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal16(String.valueOf(yr-1));
							po.setValue16(String.valueOf(yr-1));
						}
						break;
					}
					case 17:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue17());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal17(String.valueOf(yr-1));
							po.setValue17(String.valueOf(yr-1));
						}
						break;
					}
					case 18:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue18());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal18(String.valueOf(yr-1));
							po.setValue18(String.valueOf(yr-1));
						}
						break;
					}
					case 19:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue19());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal19(String.valueOf(yr-1));
							po.setValue19(String.valueOf(yr-1));
						}
						break;
					}
					case 20:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue20());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal20(String.valueOf(yr-1));
							po.setValue20(String.valueOf(yr-1));
						}
						break;
					}
					case 21:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue21());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal21(String.valueOf(yr-1));
							po.setValue21(String.valueOf(yr-1));
						}
						break;
					}
					case 22:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue22());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal22(String.valueOf(yr-1));
							po.setValue22(String.valueOf(yr-1));
						}
						break;
					}
					case 23:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue23());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal23(String.valueOf(yr-1));
							po.setValue23(String.valueOf(yr-1));
						}
						break;
					}
					case 24:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue24());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal24(String.valueOf(yr-1));
							po.setValue24(String.valueOf(yr-1));
						}
						break;
					}
					case 25:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue25());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal25(String.valueOf(yr-1));
							po.setValue25(String.valueOf(yr-1));
						}
						break;
					}
					case 26:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue26());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal26(String.valueOf(yr-1));
							po.setValue26(String.valueOf(yr-1));
						}
						break;
					}
					case 27:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue27());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal27(String.valueOf(yr-1));
							po.setValue27(String.valueOf(yr-1));
						}
						break;
					}
					case 28:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue28());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal28(String.valueOf(yr-1));
							po.setValue28(String.valueOf(yr-1));
						}
						break;
					}
					case 29:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue29());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal29(String.valueOf(yr-1));
							po.setValue29(String.valueOf(yr-1));
						}
						break;
					}
					case 30:
					{
						int yr = 0;
						try {
							yr = Integer.parseInt(po.getValue30());
						} catch (Exception e) {
							// TODO Auto-generated catch block
							//e.printStackTrace();
						}
						if(yr>0)
						{
							po.setAsRepVal30(String.valueOf(yr-1));
							po.setValue30(String.valueOf(yr-1));
						}
						break;
					}
					}
				}
			}
		}
	}






	private static void writeRowColsToFile(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap) 
	{
		System.out.println("Printing Spreaded Table ... ") ;
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;
			String colVal ="";
			//logger.info(row.getCombinedString()) ;
			for ( Integer column : columnChunksMap.keySet() )
			{
				List<PDFChunk> chunks = columnChunksMap.get(column) ;
				String strChunks = "" ;
				if(chunks!=null)
				{		

					for ( int i=0 ; i<chunks.size() ; i++ )
					{
						PDFChunk chunk = chunks.get(i) ;
						String strChunk = chunk.getChunk() ;
						if ( strChunk.trim().equalsIgnoreCase("") )
							continue ;

						strChunks = strChunks.trim() + " " + "'" + strChunk + "'" ;
					}
				}


				strChunks = strChunks.trim() ;

				colVal = colVal+("\t" + strChunks) ;
			}
			CustomFileWriter.writeStringToFileWithNewLine(colVal, FinancialStatementExtractor.writer);
		}


	}

	private static Map<Integer, String> isHeaderContainsStatementForKeywords(
			ParserOutput po) {

		Map<Integer,String> mp = new TreeMap<Integer,String>();
		checkKeyword(po, mp);
		return mp;
	}
	private static void checkKeyword(ParserOutput po, Map<Integer, String> mp) {
		if(stmtForList!=null)
		{

			if(po.getAsRepVal1()!=null && !po.getAsRepVal1().trim().equalsIgnoreCase(""))
				validateString1(po.getAsRepVal1(), mp);
			if(po.getAsRepVal2()!=null && !po.getAsRepVal2().trim().equalsIgnoreCase(""))
				validateString2(po.getAsRepVal2(), mp);
			if(po.getAsRepVal3()!=null && !po.getAsRepVal3().trim().equalsIgnoreCase(""))
				validateString3(po.getAsRepVal3(), mp);
			if(po.getAsRepVal4()!=null && !po.getAsRepVal4().trim().equalsIgnoreCase(""))
				validateString4(po.getAsRepVal4(), mp);
			if(po.getAsRepVal5()!=null && !po.getAsRepVal5().trim().equalsIgnoreCase(""))
				validateString5(po.getAsRepVal5(), mp);
			if(po.getAsRepVal6()!=null && !po.getAsRepVal6().trim().equalsIgnoreCase(""))
				validateString6(po.getAsRepVal6(), mp);
			if(po.getAsRepVal7()!=null && !po.getAsRepVal7().trim().equalsIgnoreCase(""))
				validateString7(po.getAsRepVal7(), mp);
			if(po.getAsRepVal8()!=null && !po.getAsRepVal8().trim().equalsIgnoreCase(""))
				validateString8(po.getAsRepVal8(), mp);
			if(po.getAsRepVal9()!=null && !po.getAsRepVal9().trim().equalsIgnoreCase(""))
				validateString9(po.getAsRepVal9(), mp);
			if(po.getAsRepVal10()!=null && !po.getAsRepVal10().trim().equalsIgnoreCase(""))
				validateString10(po.getAsRepVal10(), mp);




			if(po.getAsRepVal11()!=null && !po.getAsRepVal11().trim().equalsIgnoreCase(""))
				validateString11(po.getAsRepVal11(), mp);
			if(po.getAsRepVal12()!=null && !po.getAsRepVal12().trim().equalsIgnoreCase(""))
				validateString12(po.getAsRepVal12(), mp);
			if(po.getAsRepVal13()!=null && !po.getAsRepVal13().trim().equalsIgnoreCase(""))
				validateString13(po.getAsRepVal13(), mp);
			if(po.getAsRepVal14()!=null && !po.getAsRepVal14().trim().equalsIgnoreCase(""))
				validateString14(po.getAsRepVal14(), mp);
			if(po.getAsRepVal15()!=null && !po.getAsRepVal15().trim().equalsIgnoreCase(""))
				validateString15(po.getAsRepVal15(), mp);
			if(po.getAsRepVal16()!=null && !po.getAsRepVal16().trim().equalsIgnoreCase(""))
				validateString16(po.getAsRepVal16(), mp);
			if(po.getAsRepVal17()!=null && !po.getAsRepVal17().trim().equalsIgnoreCase(""))
				validateString17(po.getAsRepVal7(), mp);
			if(po.getAsRepVal18()!=null && !po.getAsRepVal18().trim().equalsIgnoreCase(""))
				validateString18(po.getAsRepVal18(), mp);
			if(po.getAsRepVal19()!=null && !po.getAsRepVal19().trim().equalsIgnoreCase(""))
				validateString19(po.getAsRepVal19(), mp);
			if(po.getAsRepVal20()!=null && !po.getAsRepVal20().trim().equalsIgnoreCase(""))
				validateString20(po.getAsRepVal20(), mp);
			/*for(String keyword:stmtForList)
			{
				isContains(po, mp, keyword);


				if( po.getAsRepVal2()!=null && po.getAsRepVal2().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(2,keyword);
				}
				if( po.getAsRepVal3()!=null && po.getAsRepVal3().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(3,keyword);
				}
				if( po.getAsRepVal4()!=null && po.getAsRepVal4().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(4,keyword);
				}
				if( po.getAsRepVal5()!=null && po.getAsRepVal5().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(5,keyword);
				}
				if( po.getAsRepVal6()!=null && po.getAsRepVal6().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(6,keyword);
				}
				if( po.getAsRepVal7()!=null && po.getAsRepVal7().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(7,keyword);
				}
				if( po.getAsRepVal8()!=null && po.getAsRepVal8().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(8,keyword);
				}
				if( po.getAsRepVal9()!=null && po.getAsRepVal9().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(9,keyword);
				}
				if( po.getAsRepVal10()!=null && po.getAsRepVal10().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(10,keyword);
				}
				if( po.getAsRepVal11()!=null && po.getAsRepVal11().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(11,keyword);
				}
				if( po.getAsRepVal12()!=null && po.getAsRepVal12().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(12,keyword);
				}if(po.getAsRepVal13()!=null &&  po.getAsRepVal13().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(13,keyword);
				}
				if(po.getAsRepVal14()!=null && po.getAsRepVal14().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(14,keyword);
				}
				if(po.getAsRepVal15()!=null && po.getAsRepVal15().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(15,keyword);
				}
				if( po.getAsRepVal16()!=null && po.getAsRepVal16().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(16,keyword);
				}
				if( po.getAsRepVal17()!=null && po.getAsRepVal17().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(17,keyword);
				}
				if( po.getAsRepVal18()!=null && po.getAsRepVal18().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(18,keyword);
				}
				if( po.getAsRepVal19()!=null && po.getAsRepVal19().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(19,keyword);
				}
				if( po.getAsRepVal20()!=null && po.getAsRepVal20().toString().toLowerCase().contains(keyword.toLowerCase()))
				{
					mp.put(20,keyword);
				}
			}*/
		}
	}

	private static void validateString1(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,1);
		}
	}

	private static void validateString2(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,2);
		}
	}
	private static void validateString3(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,3);
		}
	}

	private static void validateString4(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,4);
		}
	}

	private static void validateString5(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,5);
		}
	}

	private static void validateString6(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,6);
		}
	}	

	private static void validateString7(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,7);
		}
	}


	private static void validateString8(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,8);
		}
	}



	/*private static void validateString8(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,8);
		}
	}*/




	private static void validateString9(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,9);
		}
	}


	private static void validateString10(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,10);
		}
	}

	private static void validateString11(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,11);
		}
	}

	private static void validateString12(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,12);
		}
	}
	private static void validateString13(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,13);
		}
	}

	private static void validateString14(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,14);
		}
	}


	private static void validateString15(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,15);
		}
	}


	private static void validateString16(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,16);
		}
	}



	private static void validateString17(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,17);
		}
	}


	private static void validateString18(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,18);
		}
	}


	private static void validateString19(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,19);
		}
	}

	private static void validateString20(String value, Map<Integer, String> mp) {
		for(String keyword:stmtForList)
		{
			checkValue(value, mp, keyword,20);
		}
	}

	private static void checkValue(String value, Map<Integer, String> mp,
			String keyword,Integer col) {
		if( value!=null)
		{
			value = value.toString().toLowerCase();
			isContains(value, mp, keyword,col);
		}
	}
	private static void isContains(String val, Map<Integer, String> mp,
			String keyword,int col) {
		if(val.toString().toLowerCase().contains(keyword.toLowerCase()))
		{
			if(!mp.containsKey(col))
				mp.put(col,keyword);
		}
	}

	private static List<Row> addRemainingHeaderCandidates(List<Row> pageRows, HashMap<PDFWord, Row> wordRowsMap,
			List<List<PDFWord>> numericColumns, List<Pair<Float, Float>> numericBounds, List<Row> headerCandidates) 
			{
		if(headerCandidates==null || headerCandidates.size()<1)
			return headerCandidates;
		int min=Integer.MAX_VALUE;
		int max=Integer.MIN_VALUE;
		boolean isFound=false;
		for(Row row:headerCandidates)
		{
			int index =pageRows.indexOf(row);
			if(index!=-1)
			{
				isFound=true;
				if(min>index)
					min=index;
				if(max<index)
					max=index;
			}
		}

		if(isFound)
		{
			for(int i=min;i<=max;i++)
			{
				Row headerRow=pageRows.get(i);
				if(!headerCandidates.contains(headerRow))
					headerCandidates.add(headerRow) ;
			}
		}


		return headerCandidates;
			}


	private static void identifySectionType(Section section,
			ArrayList<ParserOutput> poObjects) {
		LinkedHashSet<String> Keywords = TimePeriodOntology.getCompanySuffixes();
		Integer colNo = -1,pgNo=-1;
		Boolean subsidiary = false;

		for(ParserOutput po:poObjects)	{
			if(po!=null && po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y"))
			{
				/*if(pgNo!=-1 && pgNo!=po.getPageNo())
					continue;
				pgNo = po.getPageNo();*/
				subsidiary = isSectionSubsidiary(po,Keywords);

				if(!FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(""))
				{
					if(po.getAsRepVal1()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal1().trim()))
					{
						colNo = 1;
					}
					if(po.getAsRepVal2()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal2().trim()))
					{
						colNo = 2;
					}
					if(po.getAsRepVal3()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal3().trim()))
					{
						colNo = 3;
					}
					if(po.getAsRepVal4()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal4().trim()))
					{
						colNo = 4;
					}
					if(po.getAsRepVal5()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal5().trim()))
					{
						colNo = 5;
					}
					if(po.getAsRepVal6()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal6().trim()))
					{
						colNo = 6;
					}
					if(po.getAsRepVal7()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal7().trim()))
					{
						colNo = 7;
					}
					if(po.getAsRepVal8()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal8().trim()))
					{
						colNo = 8;
					}

					if(po.getAsRepVal9()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal9().trim()))
					{
						colNo = 9;
					}
					if(po.getAsRepVal10()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal10().trim()))
					{
						colNo = 10;
					}
					if(po.getAsRepVal11()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal11().trim()))
					{
						colNo = 11;
					}
					if(po.getAsRepVal12()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal12().trim()))
					{
						colNo = 12;
					}
					if(po.getAsRepVal13()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal13().trim()))
					{
						colNo = 13;
					}
					if(po.getAsRepVal14()!=null &&FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal14().trim()))
					{
						colNo = 14;
					}
					if(po.getAsRepVal15()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal15().trim()))
					{
						colNo = 15;
					}
					if(po.getAsRepVal16()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal16().trim()))
					{
						colNo = 16;
					}
					if(po.getAsRepVal17()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal17().trim()))
					{
						colNo = 17;
					}
					if(po.getAsRepVal18()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal18().trim()))
					{
						colNo = 18;
					}
					if(po.getAsRepVal19()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal18().trim()))
					{
						colNo = 19;
					}
					if(po.getAsRepVal20()!=null && FinancialStatementExtractor.getCompanyName().equalsIgnoreCase(po.getAsRepVal20().trim()))
					{
						colNo = 20;
					}
				}
				//break;
			}
		}

		section.setColNo(colNo);
		section.setIsSubsidiary(subsidiary);
		return;
	}



	private static Boolean isSectionSubsidiary(ParserOutput po,
			LinkedHashSet<String> keywords) {
		int count = 0;
		for(String keyword: keywords)
		{

			if(po.getAsRepVal1()!=null && !po.getAsRepVal1().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal1().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal2()!=null && !po.getAsRepVal2().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal2().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal3()!=null && !po.getAsRepVal3().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal3().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal4()!=null && !po.getAsRepVal4().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal4().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal5()!=null && !po.getAsRepVal5().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal5().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal6()!=null && !po.getAsRepVal6().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal6().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal7()!=null && !po.getAsRepVal7().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal7().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal8()!=null && !po.getAsRepVal8().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal8().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal9()!=null && !po.getAsRepVal9().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal9().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal10()!=null && !po.getAsRepVal10().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal10().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal11()!=null && !po.getAsRepVal11().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal11().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal12()!=null && !po.getAsRepVal12().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal12().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal13()!=null && !po.getAsRepVal13().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal13().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal14()!=null && !po.getAsRepVal14().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal14().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal15()!=null && !po.getAsRepVal15().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal15().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal16()!=null && !po.getAsRepVal16().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal16().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal17()!=null && !po.getAsRepVal17().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal17().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal18()!=null && !po.getAsRepVal18().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal18().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal19()!=null && !po.getAsRepVal19().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal19().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}
			if(po.getAsRepVal20()!=null && !po.getAsRepVal20().trim().equals(""))
			{
				List<String> tokens = Utilities.tokenize(po.getAsRepVal20().toLowerCase(), true) ;
				if(tokens.contains(keyword))
				{
					count = count +1;
					if(count>1)
						return true;
				}
			}


		}
		return false;
	}
	static ArrayList<ParserOutput> spreadPageDataOld(Section section, Map<String, String> languageLabelMappings) throws Exception
	{
		List<PDFLine> lines = section.getLines() ;
		List<PDFBlock> blocks = section.getBlocks() ; 
		Pair<Float, Float> sectionXBound= getSectionXBound(lines);
		Boolean isISBreakup =false;
		List<Row> rows = null;
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		getLanguages();
		if(section.getSubSection()!=null && section.getScope()!=null && !section.getScope().equalsIgnoreCase("tabular"))  
		{
			return getPoObjectsSuppl(section, lines, blocks, poObjects);
		}

		if(section.getKeyword().getRowSegmentationType()!=null  && section.getKeyword().getRowSegmentationType().equals(RowSegmentationType.ONE_PARA_ONE_ROW))
		{
			rows = createPreliminaryRowsbyPara(lines,blocks) ;
		}
		else
		{
			rows = createPreliminaryRows(lines) ;
			if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
				rows = combineRowsByCase(rows) ; 
		}
		reCreateRowLines(rows) ;
		removeFalsePositiveTypes(rows) ;
		int maxCol = 0;

		TreeMap<Integer, List<Row>> pageRowsMap = createPageRowsMap(rows) ;
		for ( Integer pageNo : pageRowsMap.keySet() )
		{
			List<Row> pageRows = pageRowsMap.get(pageNo) ;
			System.out.println("Page No: " + pageNo) ;

			logger.info("Page No: " + pageNo) ;
			HashMap<Row,List<List<PDFWord>>> headerMap = new HashMap<Row,List<List<PDFWord>>>();

			HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
			List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
			List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
			removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, rows,sectionXBound) ;
			printNumericColumns(numericColumns, numericBounds) ;

			if ( FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") && isSectionFalsePositive(pageRows) &&  !section.getSectionName().equalsIgnoreCase("SUPPL") && !section.getSectionName().equalsIgnoreCase("SD") && !FinancialStatementExtractor.getLanguage().contains("ITR"))
			{
				logger.info("False Positive Section .... ") ;
				System.out.println("False Positive Section .... ") ;

				//section.setReprocessMeta(null);
				continue ;
			} 
			List<Row> headerCandidates = null;

			/*if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR") && section.getSectionName().equalsIgnoreCase("IS"))
			{
				headerCandidates = findHeaderRow(pageRows) ;
			}
			else*/
			headerCandidates = findHeaderRowCandidatesFromNumericColumns(pageRows, wordRowsMap, numericColumns, numericBounds) ;
			//HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;

			logger.info("Numeric Rows ... ") ;
			//	Row headerRow = pruneHeaderRows(headerCandidates, pageRows) ;
			//System.out.println("Header Row = " + headerRow) ;
			HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;

			/*if(headerCandidates!=null && headerCandidates.size()>0)
			{
				Collections.sort(headerCandidates);
				for(Row headerRow:headerCandidates)
				{
					List<List<PDFWord>> headerColumns = getHeaderColumns(numericColumns,numericBounds,headerRow, wordRowsMap,chunkRowsMap,headerCandidates) ;
					headerMap.put(headerRow, headerColumns);
				}
				//columns = getCols(headerColumns,headerRow);
			}
			 */
			reCreateChunks(rows) ;

			List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
			List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, headerMap, numericColumns, numericBounds, wordRowsMap,headerCandidates) ;
			if(headerCandidates!=null && headerCandidates.size()>0)
			{
				Collections.sort(headerCandidates);
				chunkBoundsCorrection(chunkBounds);
				for(Row headerRow:headerCandidates)
				{
					List<List<PDFWord>> headerColumns = getHeaderChunkColumns(chunkColumns,chunkBounds,headerRow, wordRowsMap,chunkRowsMap) ;
					headerMap.put(headerRow, headerColumns);
				}
			}
			TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = createRowColumnChunksMap(pageRows, chunkColumns, chunkRowsMap, headerCandidates) ;
			printRowColumnChunks(rowColumnChunksMap) ;

			if(!section.getSectionName().equalsIgnoreCase("SUPPL") && !FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				removeNumbersFromLabel(rowColumnChunksMap);
			maxCol = getMaxCol(rowColumnChunksMap, maxCol);

			if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
			{
				if(isTotalColumnSeperate(rowColumnChunksMap,maxCol) && FinancialStatementExtractor.getLanguage().equals("English"))
				{
					shifTotalRowLastColumn(rowColumnChunksMap, maxCol);
				}
			}

			/*	if(headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString())))
			{
				maxCol = maxCol-1;
			}
			 */
			if (maxCol == 1 || maxCol == 0)
			{
				//section.setReprocessMeta(null);
				continue;
			}

			logger.info("Final Columns ... ") ;
			printRowColumnChunks(rowColumnChunksMap) ;
			ArrayList<ParserOutput> headerObjects = null;
			ParserOutput po = null;
			if(headerMap.size()>0)
			{
				headerObjects = getPoObjectsFromHeaderColumns(headerMap,section,maxCol,pageNo);
				Collections.sort(headerObjects);
				po = combineHeaders(headerObjects);
			}
			if(rowColumnChunksMap.size()>0)
			{
				ArrayList<ParserOutput> pageObjects = null;
				if(section.getKeyword()!=null)
					pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),section.getKeyword().getColumnNo(),section.getKeyword().getKeyword(),section.getSubSection());
				else
					pageObjects = getPoObjects(rowColumnChunksMap,pageNo,section.getSectionName(),maxCol,po,section.getInstanceID(),0,"","");

				Integer HeaderLineNo =-1;

				if(po!=null)
				{
					pageObjects.add(po);
					HeaderLineNo = po.getLineNo();
				}
				if(!FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					SectionSpreader ss = new SectionSpreader();
					maxCol = ss.deleteEmptyColumn(pageObjects,maxCol,HeaderLineNo,0.80);


					if((headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString()))) )
					{
						maxCol = maxCol-1;
						for(ParserOutput po1 : pageObjects)
						{
							po1.setMaxCol(maxCol);
						}
						maxCol = ss.deleteNotesColumn(pageObjects,maxCol,null);
					}
				}

				if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					if(section.getSectionName().equalsIgnoreCase("IS") && section.getKeyword().getKeyword().toString().toUpperCase().equalsIgnoreCase("ESTADO DE RESULTADOS"))
					{
						maxCol=2;
					}
					else
					{
						if(section.getSectionName().equalsIgnoreCase("IS"))
							isISBreakup = true;
					}
				}
				if(pageObjects!=null)
				{
					poObjects.addAll(pageObjects);
				}
			}
			System.out.println("MaxCols in page No:"+pageNo+"and  Section:"+section);
			logger.info("\\ n\n\n") ;
		}



		ArrayList<ParserOutput> attributes  = new ArrayList<ParserOutput>();

		if(poObjects.size()>0 )
		{
			if(!isISBreakup && !section.getSectionName().equalsIgnoreCase("SUPPL"))
			{
				attributes.addAll(poObjects);
				TreeSet<String> Keywords = HeadingKeywords.getKeywords();
				if(!FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					for(ParserOutput po:poObjects)
					{
						if(po!=null)
						{
							maxCol = po.getMaxCol();
							break;
						}
					}
				}
				attributes.addAll(generateStatementAttributes(attributes,maxCol-1,Keywords,null));
				if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
					maxCol = adjustSingleValueColumns(attributes,maxCol);
				Collections.sort(attributes);
			}
			else
				attributes.addAll(poObjects);
		}
		return attributes;
	}




	private int deleteNotesColumn(ArrayList<ParserOutput> poObjects,
			int maxCol, Integer headerLineNo) {
		int colNo = isHeaderContains(TimePeriodOntology.getNotesList(),poObjects);
		if(colNo>-1)
		{
			for(ParserOutput po : poObjects)
			{
				po.setNotesColumn(getPoAsRepObject(po,colNo));
			}
		}
		switch(colNo)
		{

		/*case 0:
		{
			shiftValues(poObjects, 0, headerLineNo,true);
			break;
		}*/
		case 1:
		{
			shiftValues(poObjects, 1, headerLineNo,true);
			break;
		}
		case 2:
		{
			shiftValues(poObjects, 2, headerLineNo,true);
			break;
		}
		case 3:
		{
			shiftValues(poObjects, 3, headerLineNo,true);
			break;
		}
		case 4:
		{
			shiftValues(poObjects, 4, headerLineNo,true);
			break;
		}

		case 5:
		{
			shiftValues(poObjects, 5, headerLineNo,true);
			break;
		}
		case 6:
		{
			shiftValues(poObjects, 6, headerLineNo,true);
			break;
		}
		case 7:
		{
			shiftValues(poObjects, 7, headerLineNo,true);
			break;
		}
		case 8:
		{
			shiftValues(poObjects, 8, headerLineNo,true);
			break;
		}
		case 9:
		{
			shiftValues(poObjects, 9, headerLineNo,true);
			break;
		}
		case 10:
		{
			shiftValues(poObjects, 10, headerLineNo,true);
			break;
		}
		case 11:
		{
			shiftValues(poObjects, 11, headerLineNo,true);
			break;
		}
		case 12:
		{
			shiftValues(poObjects, 12, headerLineNo,true);
			break;
		}
		case 13:
		{
			shiftValues(poObjects, 13, headerLineNo,true);
			break;
		}
		case 14:
		{
			shiftValues(poObjects, 14, headerLineNo,true);
			break;
		}

		case 15:
		{
			shiftValues(poObjects, 15, headerLineNo,true);
			break;
		}
		case 16:
		{
			shiftValues(poObjects, 16, headerLineNo,true);
			break;
		}
		case 17:
		{
			shiftValues(poObjects, 17, headerLineNo,true);
			break;
		}
		case 18:
		{
			shiftValues(poObjects, 18, headerLineNo,true);
			break;
		}
		case 19:
		{
			shiftValues(poObjects, 19, headerLineNo,true);
			break;
		}
		case 20:
		{
			shiftValues(poObjects, 20, headerLineNo,true);
			break;
		}
		case 21:
		{
			shiftValues(poObjects, 21, headerLineNo,true);
			break;
		}
		case 22:
		{
			shiftValues(poObjects, 22, headerLineNo,true);
			break;
		}
		case 23:
		{
			shiftValues(poObjects, 23, headerLineNo,true);
			break;
		}
		case 24:
		{
			shiftValues(poObjects, 24, headerLineNo,true);
			break;
		}

		case 25:
		{
			shiftValues(poObjects, 25, headerLineNo,true);
			break;
		}
		case 26:
		{
			shiftValues(poObjects, 26, headerLineNo,true);
			break;
		}
		case 27:
		{
			shiftValues(poObjects, 27, headerLineNo,true);
			break;
		}
		case 28:
		{
			shiftValues(poObjects, 28, headerLineNo,true);
			break;
		}
		case 29:
		{
			shiftValues(poObjects, 29, headerLineNo,true);
			break;
		}
		case 30:
		{
			shiftValues(poObjects, 30, headerLineNo,true);
			break;
		}

		}



		return maxCol;
	}


	private static boolean isHeaderContains(LinkedHashSet<String> notesList,String headerString) {
		for(String keyword:TimePeriodOntology.getNotesList())
		{

			if(headerString.toLowerCase().contains(keyword.toLowerCase().trim()))
				return true;
		}

		return false;
	}


	private static ArrayList<ParserOutput> getPoObjectsSuppl(Section section,
			List<PDFLine> lines, List<PDFBlock> blocks,
			ArrayList<ParserOutput> poObjects) {
		List<Row> rows = null;
		if((section.getScope())!=null && !section.getScope().trim().equalsIgnoreCase("Tabular"))
			rows = createPreliminaryRowsbyPara(lines,blocks) ;
		/*	if((section.getScope())!=null && !section.getScope().trim().equalsIgnoreCase("Tabular"))
			rows = createPreliminaryRowsbyPara(lines,blocks) ;*/
		String s = "";

		TreeMap<Integer, List<Row>> pageRowsMap = createPageRowsMap(rows) ;
		for ( Integer pageNo : pageRowsMap.keySet() )
		{
			List<Row> pageRows = pageRowsMap.get(pageNo) ;

			if(section.getScope().equalsIgnoreCase("Paragraph"))
			{
				if(section.getParseValue()==null)
				{
					setParserOutputObject(section, poObjects, pageNo, pageRows);
				}
				else
				{
					if(section.getParseValue().trim().equalsIgnoreCase("ParseValue"))
						setParserOutputObjects(section, poObjects, pageNo, pageRows);
				}
			}
			if(section.getScope().equalsIgnoreCase("Sentence"))
			{
				if(section.getParseValue()==null)
				{
					setParserOutputObject(section, poObjects, pageNo, pageRows);
				}
				else
				{
					if(section.getParseValue().trim().equalsIgnoreCase("ParseValue"))
						setParserOutputObjects(section, poObjects, pageNo, pageRows);
				}
			}


			/*	for( Row row : pageRows)
			{
				System.out.println(row.getCombinedString());
				if(pageRows.size()>1 )
				{
					s = s+row.getCombinedString();
					continue;
				}

				if(section.getScope().equalsIgnoreCase("Paragraph"))
				{
					if(section.getParseValue()==null)
					{
						setParserOutputObject(section, poObjects, pageNo, row);
					}
					else
					{
						if(section.getParseValue().trim().equalsIgnoreCase("ParseValue"))
							setParserOutputObjects(section, poObjects, pageNo, row);
					}
				}
				if(section.getScope().equalsIgnoreCase("Sentence"))
				{
					if(section.getParseValue()==null)
					{
						setParserOutputObject(section, poObjects, pageNo, row);
					}
					else
					{
						if(section.getParseValue().trim().equalsIgnoreCase("ParseValue"))
							setParserOutputObjects(section, poObjects, pageNo, row);
					}
				}

				System.out.println("----");
			}*/
		}
		return  poObjects;
	}




	private static void getLanguageSpecificRules()
	{
		if(languagetoReplacefromDots==null)
		{
			String fileName = "resource/section-identification/languageSpecificRules.txt" ;
			if(TimePeriodOntology.getLanguageSpecificMap()==null)
			{
				TimePeriodOntology.loadRules(fileName) ;
			}
			else
			{
				if(TimePeriodOntology.getLanguageSpecificMap().containsKey("[Replace-Dots-With-Comma]"))
					languagetoReplacefromDots = (TimePeriodOntology.getLanguageSpecificMap().get("[Replace-Dots-With-Comma]"));
			}
		}

	}
	private static void setParserOutputObject(Section section,
			ArrayList<ParserOutput> poObjects, Integer pageNo, List<Row> rows ) {


		List<String> values=new ArrayList<String>();
		int ct=0;

		getLanguageSpecificRules();
		String combinedString = "";
		Row row = null;
		for(Row thisRow: rows)
		{
			if(row==null)
				row = thisRow;
			combinedString = combinedString+thisRow.getCombinedString();
		}


		ParserOutput po = new ParserOutput();
		po.setAsRepLabel(combinedString);
		po.setSubSection(section.getSubSection().toUpperCase());
		po.setSection(section.getSectionName());
		for(String value:values)
		{
			String[] sp = value.split("##");
			int col = Integer.parseInt(sp[0]);
			String colVal = sp[2];
			String coOrds = sp[1];
			if(languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && col>0)
			{
				String s ="";
				if(colVal.contains(","))
				{
					s = colVal.substring(0,colVal.indexOf(","));
					s = s.replaceAll("\\.",",");
					String s1 = colVal.substring(colVal.indexOf(",")+1); 
					colVal = s+"."+s1;
				}
				else
				{
					colVal = colVal.replaceAll("\\.",",");
				}
			}
			switch(col)
			{
			case 1:
			{
				po.setAsRepVal1(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue1("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue1((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue1(colVal);

				po.setVal1Coords(coOrds);
				break;
			}

			case 2:
			{
				po.setAsRepVal2(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue2("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue2((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue2(colVal);
				po.setVal2Coords(coOrds);

				break;
			}

			case 3:
			{
				po.setAsRepVal3(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue3("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue3((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue3(colVal);

				po.setVal3Coords(coOrds);

				break;
			}

			case 4:
			{
				po.setAsRepVal4(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue4("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue4((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue4(colVal);
				po.setVal4Coords(coOrds);

				break;
			}

			case 5:
			{
				po.setAsRepVal5(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue5("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue5((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue5(colVal);
				po.setVal5Coords(coOrds);

				break;
			}

			case 6:
			{
				po.setAsRepVal6(colVal);
				po.setVal6Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue6("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue6((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue6(colVal);
				break;
			}

			case 7:
			{
				po.setAsRepVal7(colVal);
				po.setVal7Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue7("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue7((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue7(colVal);
				break;
			}

			case 8:
			{
				po.setAsRepVal8(colVal);
				po.setVal8Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue8(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue8("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue8((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue8(colVal);
				break;
			}

			case 9:
			{
				po.setAsRepVal9(colVal);
				po.setVal9Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue9("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue9((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue9(colVal);
				break;
			}
			case 10:
			{
				po.setAsRepVal10(colVal);
				po.setVal10Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue10("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue10((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue10(colVal);
				break;
			}
			case 11:
			{
				po.setAsRepVal11(colVal);
				po.setVal11Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue11("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue11((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue11(colVal);
				break;
			}
			case 12:
			{
				po.setAsRepVal12(colVal);
				po.setVal12Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue12("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue12((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue12(colVal);
				break;
			}

			case 13:
			{
				po.setAsRepVal13(colVal);
				po.setVal13Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue13("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue13((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue13(colVal);
				break;
			}

			case 14:
			{
				po.setAsRepVal14(colVal);
				po.setVal14Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue14("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue14((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue14(colVal);
				break;
			}

			case 15:
			{
				po.setAsRepVal15(colVal);
				po.setVal15Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue15("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue15((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue15(colVal);
				break;
			}

			case 16:
			{
				po.setAsRepVal16(colVal);
				po.setVal16Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue16("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue16((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue16(colVal);
				break;
			}

			case 17:
			{
				po.setAsRepVal17(colVal);
				po.setVal17Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue17("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue17((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue17(colVal);
				break;
			}

			case 18:
			{
				po.setAsRepVal18(colVal);
				po.setVal18Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue18("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue18((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue18(colVal);
				break;
			}

			case 19:
			{
				po.setAsRepVal19(colVal);
				po.setVal19Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue19("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue19((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue19(colVal);
				break;
			}

			case 20:
			{
				po.setAsRepVal20(colVal);
				po.setVal20Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue20("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue20((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue20(colVal);
				break;
			}

			case 21:
			{
				po.setAsRepVal21(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue21("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue21((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue21(colVal);

				po.setVal21Coords(coOrds);
				break;
			}

			case 22:
			{
				po.setAsRepVal22(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue22((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue22(colVal);
				po.setVal22Coords(coOrds);

				break;
			}

			case 23:
			{
				po.setAsRepVal23(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue23("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue23((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue23(colVal);

				po.setVal23Coords(coOrds);

				break;
			}

			case 24:
			{
				po.setAsRepVal24(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue24("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue24((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue24(colVal);
				po.setVal24Coords(coOrds);

				break;
			}

			case 25:
			{
				po.setAsRepVal25(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue25("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue25((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue25(colVal);
				po.setVal25Coords(coOrds);

				break;
			}

			case 26:
			{
				po.setAsRepVal26(colVal);
				po.setVal26Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue26("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue26((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue26(colVal);
				break;
			}

			case 27:
			{
				po.setAsRepVal27(colVal);
				po.setVal27Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue27("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue27((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue27(colVal);
				break;
			}

			case 28:
			{
				po.setAsRepVal28(colVal);
				po.setVal28Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue28(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue28("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue28((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue28(colVal);
				break;
			}

			case 29:
			{
				po.setAsRepVal29(colVal);
				po.setVal29Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue29("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue29((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue29(colVal);
				break;
			}
			case 30:
			{
				po.setAsRepVal30(colVal);
				po.setVal30Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue30("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue30((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue30(colVal);
				break;
			}
			}


		}
		po.setType("ROW");
		po.setPageNo(pageNo);
		po.setRow(row);

		po.setLineNo(row.getId());
		po.setLine(getLineFromRow(row.getLines()));
		po.setIsSplit(false);
		po.setPdfLine(row.getLines().get(row.getLines().size()-1));
		//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
		//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
		po.setBreakups("N");
		po.setTableID(section.getInstanceID());
		po.setPageNo(pageNo);
		poObjects.add(po);


	}

	private static void setParserOutputObjects(Section section,
			ArrayList<ParserOutput> poObjects, Integer pageNo, List<Row> rows ) {

		List<String> values=new ArrayList<String>();
		int ct=0;

		getLanguageSpecificRules();
		String combinedString = "";
		Row row = null;

		for(Row thisRow: rows)
		{
			if(thisRow!=null)
				combinedString = combinedString+thisRow.getCombinedString();
			if(row==null)
				row =thisRow;



			for(PDFLine line:thisRow.getLines())
			{
				for(PDFChunk chunk:line.getChunks())
				{
					for(PDFWord word :chunk.getWords())
					{
						String wordString = word.getWord();
						if(wordString.endsWith("."))
						{
							wordString = wordString.substring(0,wordString.length()-1);
						}

						/*if(languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && NumberDetector.isNumericValue(wordString))
						{
							String s ="";
							if(wordString.contains(","))
							{
								s = wordString.substring(0,wordString.indexOf(","));
								s = s.replaceAll("\\.",",");
								String s1 = wordString.substring(wordString.indexOf(",")+1); 
								wordString = s+"."+s1;
							}
							else
							{
								wordString = wordString.replaceAll("\\.",",");
							}
							String value = ++ct+"##"+word.getX1()+","+word.getY1()+","+word.getX2()+","+word.getY2()+"##"+wordString;
							values.add(value);
						}
						else
						{*/
						if(NumberDetector.isNumericValue(wordString))
						{
							String value = ++ct+"##"+word.getX1()+","+word.getY1()+","+word.getX2()+","+word.getY2()+"##"+wordString/*.replaceAll("\\.", "")*/;
							values.add(value);
						}
						/*}*/
					}
				}
			}
		}




		ParserOutput po = new ParserOutput();
		po.setAsRepLabel(combinedString);
		po.setSubSection(section.getSubSection().toUpperCase());
		po.setSection(section.getSectionName());
		for(String value:values)
		{
			String[] sp = value.split("##");
			int col = Integer.parseInt(sp[0]);
			String colVal = sp[2];
			String coOrds = sp[1];
			if(languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && col>0)
			{
				String s ="";
				if(colVal.contains(","))
				{
					s = colVal.substring(0,colVal.indexOf(","));
					s = s.replaceAll("\\.",",");
					String s1 = colVal.substring(colVal.indexOf(",")+1); 
					colVal = s+"."+s1;
				}
				else
				{
					colVal = colVal.replaceAll("\\.",",");
				}
			}

			switch(col)
			{
			case 1:
			{
				po.setAsRepVal1(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue1("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue1((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue1(colVal);

				po.setVal1Coords(coOrds);
				break;
			}

			case 2:
			{
				po.setAsRepVal2(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue2("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue2((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue2(colVal);
				po.setVal2Coords(coOrds);

				break;
			}

			case 3:
			{
				po.setAsRepVal3(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue3("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue3((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue3(colVal);

				po.setVal3Coords(coOrds);

				break;
			}

			case 4:
			{
				po.setAsRepVal4(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue4("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue4((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue4(colVal);
				po.setVal4Coords(coOrds);

				break;
			}

			case 5:
			{
				po.setAsRepVal5(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue5("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue5((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue5(colVal);
				po.setVal5Coords(coOrds);

				break;
			}

			case 6:
			{
				po.setAsRepVal6(colVal);
				po.setVal6Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue6("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue6((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue6(colVal);
				break;
			}

			case 7:
			{
				po.setAsRepVal7(colVal);
				po.setVal7Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue7("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue7((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue7(colVal);
				break;
			}

			case 8:
			{
				po.setAsRepVal8(colVal);
				po.setVal8Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue8(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue8("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue8((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue8(colVal);
				break;
			}

			case 9:
			{
				po.setAsRepVal9(colVal);
				po.setVal9Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue9("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue9((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue9(colVal);
				break;
			}
			case 10:
			{
				po.setAsRepVal10(colVal);
				po.setVal10Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue10("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue10((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue10(colVal);
				break;
			}
			case 11:
			{
				po.setAsRepVal11(colVal);
				po.setVal11Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue11("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue11((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue11(colVal);
				break;
			}
			case 12:
			{
				po.setAsRepVal12(colVal);
				po.setVal12Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue12("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue12((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue12(colVal);
				break;
			}

			case 13:
			{
				po.setAsRepVal13(colVal);
				po.setVal13Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue13("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue13((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue13(colVal);
				break;
			}

			case 14:
			{
				po.setAsRepVal14(colVal);
				po.setVal14Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue14("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue14((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue14(colVal);
				break;
			}

			case 15:
			{
				po.setAsRepVal15(colVal);
				po.setVal15Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue15("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue15((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue15(colVal);
				break;
			}

			case 16:
			{
				po.setAsRepVal16(colVal);
				po.setVal16Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue16("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue16((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue16(colVal);
				break;
			}

			case 17:
			{
				po.setAsRepVal17(colVal);
				po.setVal17Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue17("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue17((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue17(colVal);
				break;
			}

			case 18:
			{
				po.setAsRepVal18(colVal);
				po.setVal18Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue18("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue18((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue18(colVal);
				break;
			}

			case 19:
			{
				po.setAsRepVal19(colVal);
				po.setVal19Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue19("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue19((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue19(colVal);
				break;
			}

			case 20:
			{
				po.setAsRepVal20(colVal);
				po.setVal20Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue20("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue20((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue20(colVal);
				break;
			}
			case 21:
			{
				po.setAsRepVal21(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue21("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue21((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue21(colVal);

				po.setVal21Coords(coOrds);
				break;
			}

			case 22:
			{
				po.setAsRepVal22(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue22((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue22(colVal);
				po.setVal22Coords(coOrds);

				break;
			}

			case 23:
			{
				po.setAsRepVal23(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue23("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue23((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue23(colVal);

				po.setVal23Coords(coOrds);

				break;
			}

			case 24:
			{
				po.setAsRepVal24(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue24("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue24((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue24(colVal);
				po.setVal24Coords(coOrds);

				break;
			}

			case 25:
			{
				po.setAsRepVal5(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue25("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue25((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue25(colVal);
				po.setVal25Coords(coOrds);

				break;
			}

			case 26:
			{
				po.setAsRepVal26(colVal);
				po.setVal26Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue26("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue26((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue26(colVal);
				break;
			}

			case 27:
			{
				po.setAsRepVal27(colVal);
				po.setVal27Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue27("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue27((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue27(colVal);
				break;
			}

			case 28:
			{
				po.setAsRepVal28(colVal);
				po.setVal28Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue28(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue28("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue28((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue28(colVal);
				break;
			}

			case 29:
			{
				po.setAsRepVal29(colVal);
				po.setVal29Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue29("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue29((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue29(colVal);
				break;
			}
			case 30:
			{
				po.setAsRepVal30(colVal);
				po.setVal30Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue30("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue30((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue30(colVal);
				break;
			}
			}


		}
		po.setType("ROW");
		po.setPageNo(pageNo);
		po.setRow(row);

		po.setLineNo(row.getId());
		po.setLine(getLineFromRow(row.getLines()));
		po.setIsSplit(false);
		po.setPdfLine(row.getLines().get(row.getLines().size()-1));
		//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
		//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
		po.setBreakups("N");
		po.setTableID(section.getInstanceID());
		po.setPageNo(pageNo);
		poObjects.add(po);

	}

	private static void setParserOutputObjects(Section section,
			ArrayList<ParserOutput> poObjects, Integer pageNo, Row row) {
		List<String> values=new ArrayList<String>();
		int ct=0;

		getLanguageSpecificRules();
		for(PDFLine line:row.getLines())
		{
			for(PDFChunk chunk:line.getChunks())
			{
				for(PDFWord word :chunk.getWords())
				{
					String wordString = word.getWord();
					if(wordString.endsWith("."))
					{
						wordString = wordString.substring(0,wordString.length()-1);
					}
					if(NumberDetector.isNumericValue(wordString))
					{
						String value = ++ct+"##"+word.getX1()+","+word.getY1()+","+word.getX2()+","+word.getY2()+"##"+wordString;
						values.add(value);
					}
				}
			}
		}
		ParserOutput po = new ParserOutput();
		po.setAsRepLabel(row.getCombinedString());
		po.setSubSection(section.getSubSection().toUpperCase());
		po.setSection(section.getSectionName());
		for(String value:values)
		{
			String[] sp = value.split("##");
			int col = Integer.parseInt(sp[0]);
			String colVal = sp[2];
			String coOrds = sp[1];
			if(languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && col>0)
			{
				String s ="";
				if(colVal.contains(","))
				{
					s = colVal.substring(0,colVal.indexOf(","));
					s = s.replaceAll("\\.",",");
					String s1 = colVal.substring(colVal.indexOf(",")+1); 
					colVal = s+"."+s1;
				}
				else
				{
					colVal = colVal.replaceAll("\\.",",");
				}
			}
			switch(col)
			{
			case 1:
			{
				po.setAsRepVal1(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue1("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue1((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue1(colVal);

				po.setVal1Coords(coOrds);
				break;
			}

			case 2:
			{
				po.setAsRepVal2(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue2("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue2((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue2(colVal);
				po.setVal2Coords(coOrds);

				break;
			}

			case 3:
			{
				po.setAsRepVal3(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue3("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue3((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue3(colVal);

				po.setVal3Coords(coOrds);

				break;
			}

			case 4:
			{
				po.setAsRepVal4(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue4("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue4((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue4(colVal);
				po.setVal4Coords(coOrds);

				break;
			}

			case 5:
			{
				po.setAsRepVal5(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue5("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue5((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue5(colVal);
				po.setVal5Coords(coOrds);

				break;
			}

			case 6:
			{
				po.setAsRepVal6(colVal);
				po.setVal6Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue6("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue6((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue6(colVal);
				break;
			}

			case 7:
			{
				po.setAsRepVal7(colVal);
				po.setVal7Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue7("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue7((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue7(colVal);
				break;
			}

			case 8:
			{
				po.setAsRepVal8(colVal);
				po.setVal8Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue8(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue8("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue8((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue8(colVal);
				break;
			}

			case 9:
			{
				po.setAsRepVal9(colVal);
				po.setVal9Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue9("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue9((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue9(colVal);
				break;
			}
			case 10:
			{
				po.setAsRepVal10(colVal);
				po.setVal10Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue10("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue10((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue10(colVal);
				break;
			}
			case 11:
			{
				po.setAsRepVal11(colVal);
				po.setVal11Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue11("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue11((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue11(colVal);
				break;
			}
			case 12:
			{
				po.setAsRepVal12(colVal);
				po.setVal12Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue12("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue12((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue12(colVal);
				break;
			}

			case 13:
			{
				po.setAsRepVal13(colVal);
				po.setVal13Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue13("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue13((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue13(colVal);
				break;
			}

			case 14:
			{
				po.setAsRepVal14(colVal);
				po.setVal14Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue14("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue14((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue14(colVal);
				break;
			}

			case 15:
			{
				po.setAsRepVal15(colVal);
				po.setVal15Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue15("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue15((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue15(colVal);
				break;
			}

			case 16:
			{
				po.setAsRepVal16(colVal);
				po.setVal16Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue16("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue16((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue16(colVal);
				break;
			}

			case 17:
			{
				po.setAsRepVal17(colVal);
				po.setVal17Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue17("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue17((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue17(colVal);
				break;
			}

			case 18:
			{
				po.setAsRepVal18(colVal);
				po.setVal18Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue18("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue18((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue18(colVal);
				break;
			}

			case 19:
			{
				po.setAsRepVal19(colVal);
				po.setVal19Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue19("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue19((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue19(colVal);
				break;
			}

			case 20:
			{
				po.setAsRepVal20(colVal);
				po.setVal20Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue20("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue20((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue20(colVal);
				break;
			}
			case 21:
			{
				po.setAsRepVal21(colVal);
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue21("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue21((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue21(colVal);

				po.setVal21Coords(coOrds);
				break;
			}

			case 22:
			{
				po.setAsRepVal22(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue22((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue22(colVal);
				po.setVal22Coords(coOrds);

				break;
			}

			case 32:
			{
				po.setAsRepVal23(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue23("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue23((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
					else
						po.setValue23(colVal);

				po.setVal23Coords(coOrds);

				break;
			}

			case 24:
			{
				po.setAsRepVal24(colVal);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue24("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue24((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue24(colVal);
				po.setVal24Coords(coOrds);

				break;
			}

			case 25:
			{
				po.setAsRepVal25(colVal);
				po.setVal25Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue25("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue25((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue25(colVal);
				po.setVal25Coords(coOrds);

				break;
			}

			case 26:
			{
				po.setAsRepVal26(colVal);
				po.setVal26Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue26((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue26(colVal);
				break;
			}

			case 27:
			{
				po.setAsRepVal27(colVal);
				po.setVal27Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue27("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue27((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue27(colVal);
				break;
			}

			case 28:
			{
				po.setAsRepVal28(colVal);
				po.setVal28Coords(coOrds);

				if(isNumber(colVal))
				{
					po.setValue28(colVal.replaceAll(" ", ""));
				}
				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue28("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue28((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue28(colVal);
				break;
			}

			case 29:
			{
				po.setAsRepVal29(colVal);
				po.setVal29Coords(coOrds);


				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue29("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue29((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue29(colVal);
				break;
			}
			case 30:
			{
				po.setAsRepVal30(colVal);
				po.setVal30Coords(coOrds);

				if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
					po.setValue30("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
				else
					if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
						po.setValue30((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
					else
						po.setValue30(colVal);
				break;
			}
			}


		}
		po.setType("ROW");
		po.setPageNo(pageNo);
		po.setRow(row);

		po.setLineNo(row.getId());
		po.setLine(getLineFromRow(row.getLines()));
		po.setIsSplit(false);
		po.setPdfLine(row.getLines().get(row.getLines().size()-1));
		//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
		//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
		po.setBreakups("N");
		po.setTableID(section.getInstanceID());
		po.setPageNo(pageNo);
		poObjects.add(po);
	}


	private static void setParserOutputObject(Section section,
			ArrayList<ParserOutput> poObjects, Integer pageNo, Row row) {
		ParserOutput po = new ParserOutput();
		po.setAsRepLabel(row.getCombinedString());
		po.setSubSection(section.getSubSection().toUpperCase());
		po.setSection(section.getSectionName());
		po.setType("ROW");
		po.setPageNo(pageNo);
		po.setRow(row);

		po.setLineNo(row.getId());
		po.setLine(getLineFromRow(row.getLines()));
		po.setIsSplit(false);
		po.setPdfLine(row.getLines().get(row.getLines().size()-1));
		//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
		//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
		po.setBreakups("N");
		po.setTableID(section.getInstanceID());
		po.setPageNo(pageNo);
		poObjects.add(po);


	}


	private static List<Row> findHeaderRow(List<Row> pageRows) {
		// TODO Auto-generated method stub
		List<Row> headerRows = new ArrayList<Row>() ;

		for ( int i=0 ; i<pageRows.size() ; i++ )
		{
			Row row = pageRows.get(i) ;
			TreeSet<String> list = HeadingKeywords.getKeywords();
			if(list.contains(row.toString()))
			{
				headerRows.add(row);
				break;
			}
		}

		return headerRows;
	}



	private static void chunkBoundsCorrection(
			List<Pair<Float, Float>> chunkBounds) {
		Pair<Float, Float> prevChunkBound = null;
		for(Pair<Float, Float>  chunkbound:chunkBounds){
			if(prevChunkBound!=null && (prevChunkBound.getB()>chunkbound.getA()))
			{
				prevChunkBound.setB(chunkbound.getA());
			}
			/*if(prevChunkBound!=null && (prevChunkBound.getB()<chunkbound.getA()))
			{
				prevChunkBound.setB(chunkbound.getA());

			}*/

			prevChunkBound = chunkbound;
		}
	}


	private static List<List<PDFWord>> getHeaderChunkColumns(
			List<List<PDFChunk>> chunkColumns,
			List<Pair<Float, Float>> chunkBounds, Row headerRow,
			HashMap<PDFWord, Row> wordRowsMap,
			HashMap<PDFChunk, Row> chunkRowsMap) {
		List<PDFLine> lines = headerRow.getLines();
		List<List<PDFWord>> headerColumns = new ArrayList<List<PDFWord>>();
		Pair<Float, Float> prevBound =  null;
		//Float prevY = Float.MIN_VALUE;
		for ( int j1=(lines.size()-1) ; j1>=0 ; j1-- )
		{
			PDFLine line = lines.get(j1);

			List<PDFChunk> chunks = line.getChunks();
			//int ct =0;
			//for ( int k=(chunks.size()-1) ; k>0 ; k-- )

			for ( int k=0 ; k<chunks.size() ; k++ )
			{
				boolean overlap = true;
				boolean found = false ;
				PDFChunk chunk = chunks.get(k);

				if(chunk.getChunk().trim().equalsIgnoreCase(""))
					continue;
				float x11 = chunk.getX1() ;
				float x12 = chunk.getX2() ;
				/*float x21 = chunk.getX1() ;
				float x22 = chunk.getX2() */;

				List<PDFWord> toBeSpreadedWords = chunk.getWords();
				for ( int i=(chunkBounds.size()-1) ; i>-1 ; i-- )
				{
					Pair<Float, Float> bound = chunkBounds.get(i) ;
					float x21 = bound.getA().floatValue() ;
					float x22 = bound.getB().floatValue() ;
					found = false ;
					overlap = true ;
					//Added for issue fix on 23/01/2017
					boolean isNoteKwFound=isNotesfound(TimePeriodOntology.getNotesList(), chunk.getChunk());
					if(prevBound!=null && prevBound.getB().floatValue()<x11 && x21 > x12 && !isNoteKwFound)
					{
						overlap = true;
					}
					else 
						//Added for issue fix on 23/01/2017
						if ( x12 < x21 || x11 > x22  )
							overlap = found ;

					if ( overlap )
					{
						chunkRowsMap.put(chunk,headerRow);
						if(headerColumns.size()<i)
						{
							for(int k1=0;k1<i;k1++)
							{
								headerColumns.add(null);
							}
						}
						/*if(headerColumns.size()>i)
						{
							List<PDFWord> words = headerColumns.get(i);
							if(words!=null)
							words.addAll(chunk.getWords());
							else
							headerColumns.add(i,words);
					}
					else
					{*/
						headerColumns.add(i,chunk.getWords());
						/*	}*/

						/*float newX1 = x11 < x21 ? x11 : x21 ;
						float newX2 = x12 > x22 ? x12 : x22 ;

						Pair<Float, Float> newBounds = new Pair<Float, Float>(newX1, newX2) ;
						bounds.set(i, newBounds) ;
						 */
						found = true ;
						prevBound = bound;

						break ;
					}
					prevBound = bound;

				}

				if ( !overlap )
				{					
					for ( int j=0 ; j<toBeSpreadedWords.size() ; j++ )
					{
						PDFWord word = toBeSpreadedWords.get(j) ;
						wordRowsMap.put(word, headerRow) ;
						if(word.getWord().trim().equalsIgnoreCase(""))
							continue;
						float x31 = word.getX1() ;
						float x32 = word.getX2() ;
						found = false ;
						overlap = true ;
						for ( int k1=(chunkBounds.size()-1) ; k1>-1 ; k1-- )
						{
							Pair<Float, Float> bound1 = chunkBounds.get(k1) ;
							float x41 = bound1.getA().floatValue() ;
							float x42 = bound1.getB().floatValue() ;

							overlap = true ;
							if ( x32 < x41 || x31 > x42 )
								overlap = found ;

							if ( !overlap )
								continue ;

							if(headerColumns.size()<k1)
							{
								for(int i=0;i<k1;i++)
								{
									headerColumns.add(null);
								}
							}

							/*	if(headerColumns.size()>k1)
						{
							List<PDFWord> words = headerColumns.get(k1);
							if(words!=null)
							words.addAll(chunk.getWords());
							else
							headerColumns.add(k1,words);
					}
					else
					{*/
							headerColumns.add(k1,chunk.getWords());
							/*}*/
							//headerColumns.add(k1,chunk.getWords());

							/*float newX1 = x31 < x41 ? x31 : x41 ;
							float newX2 = x32 > x42 ? x32 : x42 ;

							Pair<Float, Float> newBounds = new Pair<Float, Float>(newX1, newX2) ;
							bounds.set(k1, newBounds) ;*/
							found = true ;
							break ;
						}

						if ( found )
							continue ;

						/*	List<PDFWord> column1 = new ArrayList<PDFWord>() ;
						column1.add(word) ;
						columns.add(column1) ;*/

						/*	Pair<Float, Float> bound1 = new Pair<Float, Float>(word.getX1(), word.getX2()) ;
						bounds.add(bound1) ;*/
					}
				}
				//	prevY = line.getY2();

			}
		}

		System.out.print("");
		return headerColumns;
	}

	private static int adjustSingleValueColumns(
			ArrayList<ParserOutput> poObjects, int maxCol) {
		int ct = 0;
		for(ParserOutput po:poObjects)	{

			if((po.getValue1()!=null && !po.getValue1().trim().equals("")) && 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 
			{
				ct++;
			}


			if((po.getValue2()!=null && !po.getValue2().trim().equals("")) && 	
					(po.getValue1() == null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 

			{
				ct++;
			}

			if((po.getValue3()!=null && !po.getValue3().trim().equals("")) && 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue1() == null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 

			{
				ct++;
			}

			if((po.getValue4() != null && !po.getValue4().trim().equals("")) && 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue1() == null || (po.getValue1()!=null &&  po.getValue1().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 

			{
				ct++;
			}

			if((po.getValue5()!=null && !po.getValue5().trim().equals("") )&& 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue1()	== null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 

			{
				ct++;
			}
		}

		if(ct*(1.0)/poObjects.size()>0.98)
		{
			shiftValuestoFirstColumn(poObjects);
			return 1;
		}
		return maxCol;
	}

	private static void shiftValuestoFirstColumn(
			ArrayList<ParserOutput> poObjects) {
		for(ParserOutput po:poObjects)	{
			if((po.getValue2()!=null && !po.getValue2().trim().equals("")) && 	
					(po.getValue1() == null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 

			{
				po.setAsRepVal1(po.getAsRepVal2());
				po.setValue1(po.getValue2());
			}

			if((po.getValue3()!=null && !po.getValue3().trim().equals("")) && 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue1() == null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 
			{
				po.setAsRepVal1(po.getAsRepVal3());
				po.setValue1(po.getValue3());
			}				

			if((po.getValue4() != null && !po.getValue4().trim().equals("")) && 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue1() == null || (po.getValue1()!=null &&  po.getValue1().trim().equals(""))) && 
					(po.getValue5()	== null || (po.getValue5()!=null && po.getValue5().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 
			{
				po.setAsRepVal1(po.getAsRepVal4());
				po.setValue1(po.getValue4());

			}

			if((po.getValue5()!=null && !po.getValue5().trim().equals("") )&& 	
					(po.getValue2() == null || (po.getValue2()!=null && po.getValue2().trim().equals(""))) && 
					(po.getValue3() == null || (po.getValue3()!=null && po.getValue3().trim().equals(""))) && 
					(po.getValue4() == null || (po.getValue4()!=null &&  po.getValue4().trim().equals(""))) && 
					(po.getValue1()	== null || (po.getValue1()!=null && po.getValue1().trim().equals(""))) &&
					(po.getValue6() == null || (po.getValue6()!=null && po.getValue6().trim().equals(""))) &&
					(po.getValue7() == null || (po.getValue7()!=null && po.getValue7().trim().equals(""))) &&
					(po.getValue8() == null || (po.getValue8()!=null && po.getValue8().trim().equals(""))) &&
					(po.getValue9() == null || (po.getValue9()!=null && po.getValue9().trim().equals(""))) &&
					(po.getValue10() == null || (po.getValue10()!=null && po.getValue10().trim().equals(""))) &&
					(po.getValue11() == null || (po.getValue11()!=null && po.getValue11().trim().equals(""))) &&
					(po.getValue12() == null || (po.getValue12()!=null && po.getValue2().trim().equals(""))) &&
					(po.getValue13() == null || (po.getValue13()!=null && po.getValue13().trim().equals("")))) 
			{
				po.setAsRepVal1(po.getAsRepVal5());
				po.setValue1(po.getValue5());

			}

		}
	}


	private static ParserOutput combineHeaders(ArrayList<ParserOutput> headingObjects) {
		ParserOutput po = null;
		for(ParserOutput pol:headingObjects)		{

			if(po==null)
			{
				po = new ParserOutput();
				po = pol;
				po.setLineNo(pol.getLineNo());
				po.setPageNo(pol.getPageNo());
				continue;
			}

			po.getRow().getLines().addAll(pol.getRow().getLines());

			if(pol.getMaxCol()<1)
				continue;
			if(pol.getAsRepLabel()!=null)
			{
				if(po.getAsRepLabel()!=null)
					po.setAsRepLabel(po.getAsRepLabel()+" "+pol.getAsRepLabel());
				else
					po.setAsRepLabel(pol.getAsRepLabel());
			}
			if(pol.getMaxCol()<2)
				continue;


			if(pol.getPageNo()!=po.getPageNo())
				continue;
			if(pol.getAsRepVal1()!=null)
			{
				if(po.getAsRepVal1()!=null)

					po.setAsRepVal1(po.getAsRepVal1()+" "+pol.getAsRepVal1());

				else
					po.setAsRepVal1(pol.getAsRepVal1());

				po.setValue1(po.getAsRepVal1());


			}
			if(pol.getMaxCol()<3)
				continue;
			if(pol.getAsRepVal2()!=null)
			{
				if(po.getAsRepVal2()!=null)
					po.setAsRepVal2(po.getAsRepVal2()+" "+pol.getAsRepVal2());
				else
					po.setAsRepVal2(pol.getAsRepVal2());
				po.setValue2(po.getAsRepVal2());
			}
			if(pol.getMaxCol()<4)
				continue;
			if(pol.getAsRepVal3()!=null)
			{
				if(po.getAsRepVal3()!=null)
					po.setAsRepVal3(po.getAsRepVal3()+" "+pol.getAsRepVal3());
				else
					po.setAsRepVal3(pol.getAsRepVal3());
				po.setValue3(po.getAsRepVal3());

			}
			if(pol.getMaxCol()<5)
				continue;
			if(pol.getAsRepVal4()!=null)
			{
				if(po.getAsRepVal4()!=null)
					po.setAsRepVal4(po.getAsRepVal4()+" "+pol.getAsRepVal4());
				else
					po.setAsRepVal4(pol.getAsRepVal4());
				po.setValue4(po.getAsRepVal4());

			}
			if(pol.getMaxCol()<6)
				continue;
			if(pol.getAsRepVal5()!=null)
			{
				if(po.getAsRepVal5()!=null)
					po.setAsRepVal5(po.getAsRepVal5()+" "+pol.getAsRepVal5());
				else
					po.setAsRepVal5(pol.getAsRepVal5());
				po.setValue5(po.getAsRepVal5());

			}
			if(pol.getMaxCol()<7)
				continue;

			if(pol.getAsRepVal6()!=null)
			{
				if(po.getAsRepVal6()!=null)
					po.setAsRepVal6(po.getAsRepVal6()+" "+pol.getAsRepVal6());
				else
					po.setAsRepVal6(pol.getAsRepVal6());
				po.setValue6(po.getAsRepVal6());

			}
			if(pol.getMaxCol()<8)
				continue;
			if(pol.getAsRepVal7()!=null)
			{
				if(po.getAsRepVal7()!=null)
					po.setAsRepVal7(po.getAsRepVal7()+" "+pol.getAsRepVal7());
				else
					po.setAsRepVal7(pol.getAsRepVal7());
				po.setValue7(po.getAsRepVal7());

			}
			if(pol.getMaxCol()<9)
				continue;
			if(pol.getAsRepVal8()!=null)
			{
				if(po.getAsRepVal8()!=null)
					po.setAsRepVal8(po.getAsRepVal8()+" "+pol.getAsRepVal8());
				else
					po.setAsRepVal8(pol.getAsRepVal8());
				po.setValue8(po.getAsRepVal8());

			}
			if(pol.getMaxCol()<10)
				continue;
			if(pol.getAsRepVal9()!=null)
			{
				if(po.getAsRepVal9()!=null)
					po.setAsRepVal9(po.getAsRepVal9()+" "+pol.getAsRepVal9());
				else
					po.setAsRepVal9(pol.getAsRepVal9());
				po.setValue9(po.getAsRepVal9());

			}
			if(pol.getMaxCol()<11)
				continue;
			if(pol.getAsRepVal10()!=null)
			{
				if(po.getAsRepVal10()!=null)
					po.setAsRepVal10(po.getAsRepVal10()+" "+pol.getAsRepVal10());
				else
					po.setAsRepVal10(pol.getAsRepVal10());
				po.setValue10(po.getAsRepVal10());

			}

			if(pol.getMaxCol()<11)
				continue;
			if(pol.getAsRepLabel()!=null)
			{
				if(po.getAsRepLabel()!=null)
					po.setAsRepLabel(po.getAsRepLabel()+" "+pol.getAsRepLabel());
				else
					po.setAsRepLabel(pol.getAsRepLabel());
				po.setValue11(po.getAsRepVal11());
			}
			if(pol.getMaxCol()<12)
				continue;
			if(pol.getAsRepVal11()!=null)
			{
				if(po.getAsRepVal11()!=null)
					po.setAsRepVal11(po.getAsRepVal11()+" "+pol.getAsRepVal11());
				else
					po.setAsRepVal11(pol.getAsRepVal11());
				po.setValue11(po.getAsRepVal11());

			}
			if(pol.getMaxCol()<13)
				continue;
			if(pol.getAsRepVal12()!=null)
			{
				if(po.getAsRepVal12()!=null)
					po.setAsRepVal12(po.getAsRepVal12()+" "+pol.getAsRepVal12());
				else
					po.setAsRepVal12(pol.getAsRepVal12());
				po.setValue2(po.getAsRepVal12());

			}
			if(pol.getMaxCol()<14)
				continue;
			if(pol.getAsRepVal13()!=null)
			{
				if(po.getAsRepVal13()!=null)
					po.setAsRepVal13(po.getAsRepVal13()+" "+pol.getAsRepVal13());
				else
					po.setAsRepVal13(pol.getAsRepVal13());
				po.setValue13(po.getAsRepVal13());

			}
			if(pol.getMaxCol()<15)
				continue;
			if(pol.getAsRepVal14()!=null)
			{
				if(po.getAsRepVal14()!=null)
					po.setAsRepVal14(po.getAsRepVal14()+" "+pol.getAsRepVal14());
				else
					po.setAsRepVal14(pol.getAsRepVal14());
				po.setValue14(po.getAsRepVal14());

			}
			if(pol.getMaxCol()<16)
				continue;
			if(pol.getAsRepVal15()!=null)
			{
				if(po.getAsRepVal15()!=null)
					po.setAsRepVal15(po.getAsRepVal15()+" "+pol.getAsRepVal15());
				else
					po.setAsRepVal15(pol.getAsRepVal15());
				po.setValue15(po.getAsRepVal15());

			}
			if(pol.getMaxCol()<17)
				continue;

			if(pol.getAsRepVal16()!=null)
			{
				if(po.getAsRepVal16()!=null)
					po.setAsRepVal16(po.getAsRepVal16()+" "+pol.getAsRepVal16());
				else
					po.setAsRepVal16(pol.getAsRepVal16());
				po.setValue16(po.getAsRepVal16());

			}
			if(pol.getMaxCol()<18)
				continue;
			if(pol.getAsRepVal17()!=null)
			{
				if(po.getAsRepVal17()!=null)
					po.setAsRepVal7(po.getAsRepVal17()+" "+pol.getAsRepVal17());
				else
					po.setAsRepVal17(pol.getAsRepVal7());
				po.setValue17(po.getAsRepVal17());

			}
			if(pol.getMaxCol()<19)
				continue;
			if(pol.getAsRepVal18()!=null)
			{
				if(po.getAsRepVal18()!=null)
					po.setAsRepVal18(po.getAsRepVal18()+" "+pol.getAsRepVal18());
				else
					po.setAsRepVal18(pol.getAsRepVal18());
				po.setValue18(po.getAsRepVal18());

			}
			if(pol.getMaxCol()<20)
				continue;
			if(pol.getAsRepVal19()!=null)
			{
				if(po.getAsRepVal19()!=null)
					po.setAsRepVal19(po.getAsRepVal19()+" "+pol.getAsRepVal19());
				else
					po.setAsRepVal19(pol.getAsRepVal19());
				po.setValue19(po.getAsRepVal19());

			}
			if(pol.getMaxCol()<21)
				continue;
			if(pol.getAsRepVal20()!=null)
			{
				if(po.getAsRepVal20()!=null)
					po.setAsRepVal20(po.getAsRepVal20()+" "+pol.getAsRepVal20());
				else
					po.setAsRepVal20(pol.getAsRepVal20());
				po.setValue20(po.getAsRepVal20());

			}

		}
		return po;
	}


	public static ArrayList<ParserOutput> spreadBreakUpData(String section,List<PDFLine> lines, List<ParserOutput> secContent,int instanceID) 
	{

		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		Pair<Float, Float> sectionXBound= getSectionXBound(lines);
		List<Row> rows = createPreliminaryRows(lines) ;
		rows = combineRowsByCase(rows) ;
		reCreateRowLines(rows) ;
		removeFalsePositiveTypes(rows) ;
		int maxCol = 0;
		SectionSpreader ss = new SectionSpreader();


		TreeMap<Integer, List<Row>> pageRowsMap = createPageRowsMap(rows) ;
		for ( Integer pageNo : pageRowsMap.keySet() )
		{
			List<Row> pageRows = pageRowsMap.get(pageNo) ;
			logger.info("Page No: " + pageNo) ;
			HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
			List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
			List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
			removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, rows,sectionXBound) ;
			printNumericColumns(numericColumns, numericBounds) ;

			if ( isSectionFalsePositive(pageRows) )
			{
				logger.info("False Positive Section .... ") ;
				continue ;
			} 

			logger.info("Numeric Rows ... ") ;
			HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;
			List<Row> headerCandidates = findHeaderRowCandidatesFromNumericColumns(pageRows, wordRowsMap, numericColumns, numericBounds) ;

			//reCreateChunks(rows) ;


			/////////////


			List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
			List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, null, numericColumns, numericBounds, wordRowsMap,headerCandidates) ;

			TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap = createRowColumnChunksMap(pageRows, chunkColumns, chunkRowsMap, headerCandidates) ;
			//printRowColumnChunks(rowColumnChunksMap) ;

			removeNumbersFromLabel(rowColumnChunksMap);

			maxCol = getMaxCol(rowColumnChunksMap, maxCol);

			if (maxCol == 1 || maxCol == 0)
			{
				//section.setReprocessMeta(null);
				continue;
			}

			/*if(headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString())))
			{
				maxCol = maxCol-1;
			}*/

			logger.info("Final Columns ... ") ;
			printRowColumnChunks(rowColumnChunksMap) ;
			if(rowColumnChunksMap.size()>0)
			{
				poObjects.addAll(getPoObjects(rowColumnChunksMap,pageNo,section,maxCol,null,instanceID,0,"",""));
			}

			maxCol = ss.deleteEmptyColumn(poObjects,maxCol,null,0.80);

			if(headerCandidates.toString().contains("Note") || isHeaderContains(TimePeriodOntology.getNotesList(),(headerCandidates.toString())))
			{
				maxCol = maxCol-1;

				for(ParserOutput po : poObjects)
				{
					po.setMaxCol(maxCol);
				}

				maxCol = ss.deleteNotesColumn(poObjects,maxCol,null);
			}

			logger.info("\\ n\n\n") ;
		}

		return poObjects;
	}

	private int deleteEmptyColumn(ArrayList<ParserOutput> poObjects,int maxCol, Integer headerLineNo,double threshhold)
	{
		int ct0 = 0; 
		Integer totalCt= poObjects.size();
		if(maxCol>0)
			maxCol = checkColumnsCount(poObjects,"ct0", 0,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>1)
			maxCol = checkColumnsCount(poObjects,"ct1", 1,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>2)
			maxCol = checkColumnsCount(poObjects,"ct2", 2,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>3)
			maxCol = checkColumnsCount(poObjects,"ct3", 3,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>4)
			maxCol = checkColumnsCount(poObjects,"ct4", 4,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>5)
			maxCol = checkColumnsCount(poObjects,"ct5", 5,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>6)
			maxCol = checkColumnsCount(poObjects,"ct6", 6,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>7)
			maxCol = checkColumnsCount(poObjects,"ct7", 7,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>8)
			maxCol = checkColumnsCount(poObjects,"ct8", 8,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>9)
			maxCol = checkColumnsCount(poObjects,"ct9", 9,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>10)
			maxCol = checkColumnsCount(poObjects,"ct10", 10,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>11)
			maxCol = checkColumnsCount(poObjects,"ct11", 11,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>12)
			maxCol = checkColumnsCount(poObjects,"ct12", 12,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>13)
			maxCol = checkColumnsCount(poObjects,"ct13", 13,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>14)
			maxCol = checkColumnsCount(poObjects,"ct14", 14,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>15)
			maxCol = checkColumnsCount(poObjects,"ct15", 15,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>16)
			maxCol = checkColumnsCount(poObjects,"ct16", 16,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>17)
			maxCol = checkColumnsCount(poObjects,"ct17", 17,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>18)
			maxCol = checkColumnsCount(poObjects,"ct18",18, totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>19)
			maxCol = checkColumnsCount(poObjects,"ct19", 19,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>20)
			maxCol = checkColumnsCount(poObjects,"ct20", 20,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>21)
			maxCol = checkColumnsCount(poObjects,"ct21", 21,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>22)
			maxCol = checkColumnsCount(poObjects,"ct22",22,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>23)
			maxCol = checkColumnsCount(poObjects,"ct23", 23,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>24)
			maxCol = checkColumnsCount(poObjects,"ct24", 24,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>25)
			maxCol = checkColumnsCount(poObjects,"ct25", 25,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>26)
			maxCol = checkColumnsCount(poObjects,"ct26", 26,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>27)
			maxCol = checkColumnsCount(poObjects,"ct27", 27,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>28)
			maxCol = checkColumnsCount(poObjects,"ct28", 28,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>29)
			maxCol = checkColumnsCount(poObjects,"ct29", 29,totalCt,ct0,maxCol,headerLineNo,threshhold);
		if(maxCol>30)
			maxCol = checkColumnsCount(poObjects,"ct30", 30,totalCt,ct0,maxCol,headerLineNo,threshhold);

		for(ParserOutput po : poObjects)
		{
			po.setMaxCol(maxCol);
		}
		return maxCol;
	}


	private int checkColumnsCount(ArrayList<ParserOutput> poObjects, String ct, int col,
			Integer totalCt,int ct0, int maxCol, Integer headerLineNo,double threshhold) {
		ct0 =0;
		for(int i=0;i<poObjects.size();i++)
		{
			boolean valueFound= false;
			ParserOutput po = poObjects.get(i);	
			if(po.getAsRepLabel()!=null && po.getAsRepLabel().startsWith("STATEMENT"))
			{
				totalCt = (poObjects.size()-8);
				continue;
			}
			if(po!=null && headerLineNo!=null && po.getLineNo()<headerLineNo.intValue())
			{
				totalCt = totalCt -1;
				continue;
			}
			switch(col)
			{
			case 0:
			{
				if((po.getAsRepLabel()==null) || (po.getAsRepLabel()!= null && po.getAsRepLabel().trim().equals("")))
				{
					++ct0;
				}
				break;
			}
			case 1:
			{
				if(po.getValue1()==null || (po.getValue1()!= null && po.getValue1().trim().equals("")))
				{
					++ct0;
				}
				else
					if(po.getAsRepVal1()!= null && (po.getAsRepVal1().trim().contains(".") || po.getAsRepVal1().trim().contains(",")) &&  NumberDetector.isNumericValue(po.getAsRepVal1()))
					{
						ct0=0;
						valueFound = true;
					}
				break;
			}
			case 2:
			{
				if((po.getValue2()==null || (po.getValue2()!= null && po.getValue2().trim().equals(""))) && maxCol>2)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal2()!= null && NumberDetector.isNumericValue(po.getAsRepVal2()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 3:
			{
				if((po.getValue3()==null || (po.getValue3()!= null && po.getValue3().trim().equals(""))) && maxCol>3)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal3()!= null && NumberDetector.isNumericValue(po.getAsRepVal3()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 4:
			{
				if((po.getValue4()==null || (po.getValue4()!= null && po.getValue4().trim().equals(""))) && maxCol>4)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal4()!= null && NumberDetector.isNumericValue(po.getAsRepVal4()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 5:
			{
				if(po.getValue5()==null || (po.getValue5()!= null && po.getValue5().trim().equals("")) &&  maxCol>5)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal5()!= null && NumberDetector.isNumericValue(po.getAsRepVal5()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 6:
			{
				if((po.getValue6()==null || (po.getValue6()!= null && po.getValue6().trim().equals(""))) &&  maxCol>6)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal6()!= null && NumberDetector.isNumericValue(po.getAsRepVal6()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 7:
			{
				if((po.getValue7()==null || (po.getValue7()!= null && po.getValue7().trim().equals(""))) && maxCol>7)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal7()!= null && NumberDetector.isNumericValue(po.getAsRepVal7()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 8:{
				if((po.getValue8()==null || (po.getValue8()!= null && po.getValue8().trim().equals(""))) && maxCol>8)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal8()!= null && NumberDetector.isNumericValue(po.getAsRepVal8()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 9:{
				if((po.getValue9()==null || (po.getValue9()!= null && po.getValue9().trim().equals(""))) && maxCol>9)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal9()!= null && NumberDetector.isNumericValue(po.getAsRepVal9()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 10:{
				if(po.getValue10()==null || (po.getValue10()!= null && po.getValue10().trim().equals("")) && maxCol>10)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal10()!= null && NumberDetector.isNumericValue(po.getAsRepVal10()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 11:{
				if((po.getValue11()==null || (po.getValue11()!= null && po.getValue11().trim().equals(""))) && maxCol>11)
				{
					++ct0;
				}
				break;
			}
			case 12:{
				if((po.getValue12()==null || (po.getValue12()!= null && po.getValue12().trim().equals("")) && maxCol>12))
				{
					++ct0;
				}
				break;
			}
			case 13:{
				if((po.getValue13()==null || (po.getValue13()!= null && po.getValue13().trim().equals(""))&& maxCol>13))
				{
					++ct0;
				}
				break;
			}
			case 14 :{
				if((po.getValue14()==null || (po.getValue14()!= null && po.getValue14().trim().equals(""))&& maxCol>14))
				{
					++ct0;
				}
				break;
			}
			case 15:{
				if(po.getValue15()==null || (po.getValue15()!= null && po.getValue15().trim().equals("")) && maxCol>15)
				{
					++ct0;
				}
				break;
			}
			case 16:{
				if(po.getValue16()==null || (po.getValue16()!= null && po.getValue16().trim().equals("")) && maxCol>16)
				{
					++ct0;
				}
			}
			case 17:{
				if((po.getValue17()==null || (po.getValue17()!= null && po.getValue17().trim().equals("")) && maxCol>17))
				{
					++ct0;
				}
				break;
			}
			case 18:{
				if((po.getValue18()==null || (po.getValue18()!= null && po.getValue18().trim().equals("")) && maxCol>18))
				{
					++ct0;
				}
				break;
			}
			case 19:{
				if(po.getValue19()==null || (po.getValue19()!= null && po.getValue19().trim().equals("")) && maxCol>19)
				{
					++ct0;
				}
				break;
			}
			case 20:{
				if(po.getValue20()==null || (po.getValue20()!= null && po.getValue20().trim().equals("")) && maxCol>20)
				{
					++ct0;
				}
				break;
			}
			case 21:
			{
				if(po.getValue21()==null || (po.getValue21()!= null && po.getValue21().trim().equals("")))
				{
					++ct0;
				}
				else
					if(po.getAsRepVal21()!= null && (po.getAsRepVal1().trim().contains(".") || po.getAsRepVal21().trim().contains(",")) &&  NumberDetector.isNumericValue(po.getAsRepVal21()))
					{
						ct0=0;
						valueFound = true;
					}
				break;
			}
			case 22:
			{
				if((po.getValue22()==null || (po.getValue22()!= null && po.getValue22().trim().equals(""))) && maxCol>22)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal22()!= null && NumberDetector.isNumericValue(po.getAsRepVal22()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 23:
			{
				if((po.getValue23()==null || (po.getValue23()!= null && po.getValue23().trim().equals(""))) && maxCol>23)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal23()!= null && NumberDetector.isNumericValue(po.getAsRepVal23()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 24:
			{
				if((po.getValue24()==null || (po.getValue24()!= null && po.getValue24().trim().equals(""))) && maxCol>24)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal24()!= null && NumberDetector.isNumericValue(po.getAsRepVal24()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 25:
			{
				if(po.getValue25()==null || (po.getValue25()!= null && po.getValue25().trim().equals("")) &&  maxCol>25)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal25()!= null && NumberDetector.isNumericValue(po.getAsRepVal25()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 26:
			{
				if((po.getValue26()==null || (po.getValue26()!= null && po.getValue26().trim().equals(""))) &&  maxCol>26)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal26()!= null && NumberDetector.isNumericValue(po.getAsRepVal26()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 27:
			{
				if((po.getValue27()==null || (po.getValue27()!= null && po.getValue27().trim().equals(""))) && maxCol>27)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal27()!= null && NumberDetector.isNumericValue(po.getAsRepVal27()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 28:{
				if((po.getValue28()==null || (po.getValue28()!= null && po.getValue28().trim().equals(""))) && maxCol>28)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal28()!= null && NumberDetector.isNumericValue(po.getAsRepVal28()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 29:{
				if((po.getValue29()==null || (po.getValue29()!= null && po.getValue29().trim().equals(""))) && maxCol>29)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal29()!= null && NumberDetector.isNumericValue(po.getAsRepVal29()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			case 30:{
				if(po.getValue30()==null || (po.getValue30()!= null && po.getValue30().trim().equals("")) && maxCol>30)
				{
					++ct0;
				}
				else
					if(po.getAsRepVal30()!= null && NumberDetector.isNumericValue(po.getAsRepVal10()))
					{
						ct0=0;
						valueFound = true;

					}
				break;
			}
			}
			if(valueFound)
				break;

		}

		if( maxCol==0 || ct0==0 || ct0>totalCt)
		{
			return maxCol;
		}
		switch(col)
		{
		case 0:
		{
			if((ct0*1.0/totalCt.intValue())>=threshhold && ct.trim().equalsIgnoreCase("ct0"))
			{
				shiftValues(poObjects, 0, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,0,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 1:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct1"))
			{
				shiftValues(poObjects, 1, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,1,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 2:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct2"))
			{
				shiftValues(poObjects, 2, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,2,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 3:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct3"))
			{
				shiftValues(poObjects, 3, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,3,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 4:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct4"))
			{
				shiftValues(poObjects, 4, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,4,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}

		case 5:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct5"))
			{
				shiftValues(poObjects, 5, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,5,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 6:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct6"))
			{
				shiftValues(poObjects, 6, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,6,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 7:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct7"))
			{
				shiftValues(poObjects, 7, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,7,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 8:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct8"))
			{
				shiftValues(poObjects, 8, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,8,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 9:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct9"))
			{
				shiftValues(poObjects, 9, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,9,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 10:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct10"))
			{
				shiftValues(poObjects, 10, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,10,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 11:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct11"))
			{
				shiftValues(poObjects, 11, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,11,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 12:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct12"))
			{
				shiftValues(poObjects, 12, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,12,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 13:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct13"))
			{
				shiftValues(poObjects, 13, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,13,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 14:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct14"))
			{
				shiftValues(poObjects, 14, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,14,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}

		case 15:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct15"))
			{
				shiftValues(poObjects, 15, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,15,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 16:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct16"))
			{
				shiftValues(poObjects, 16, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,16,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 17:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct17"))
			{
				shiftValues(poObjects, 17, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,17,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 18:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct18"))
			{
				shiftValues(poObjects, 18, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,18,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 19:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct19"))
			{
				shiftValues(poObjects, 19, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,19,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 20:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct20"))
			{
				shiftValues(poObjects, 20, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol= checkColumnsCount(poObjects,ct,20,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 21:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct21"))
			{
				shiftValues(poObjects, 21, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,21,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 22:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct22"))
			{
				shiftValues(poObjects, 22, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,22,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 23:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct23"))
			{
				shiftValues(poObjects, 23, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,23,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 24:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct24"))
			{
				shiftValues(poObjects, 24, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,24,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}

		case 25:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct25"))
			{
				shiftValues(poObjects, 25, headerLineNo,false);
				maxCol = maxCol -1;
				checkColumnsCount(poObjects,ct,25,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 26:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct26"))
			{
				shiftValues(poObjects, 26, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,26,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 27:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct27"))
			{
				shiftValues(poObjects, 27, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,27,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 28:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct28"))
			{
				shiftValues(poObjects, 28, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,28,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 29:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct29"))
			{
				shiftValues(poObjects, 29, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,29,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		case 30:
		{
			if(ct0*1.0/totalCt.intValue()>=threshhold && ct.trim().equalsIgnoreCase("ct30"))
			{
				shiftValues(poObjects, 30, headerLineNo,false);
				maxCol = maxCol -1;
				maxCol = checkColumnsCount(poObjects,ct,30,totalCt,0,maxCol,headerLineNo,threshhold);
			}
			break;
		}
		}
		return maxCol;
	}


	private void shiftValues(ArrayList<ParserOutput> poObjects, int ct,Integer hdrLineNo,Boolean isNotesColumn) {
		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);	

			if(po != null &&  hdrLineNo!=null && hdrLineNo.intValue()>po.getLineNo())
				continue;
			switch ( ct ){
			case 0:
			{
				removefirstColumn(po,isNotesColumn,ct);
				break;
			}
			case 1:
			{
				removeSecondColumn(po,isNotesColumn,ct);
				break;
			}
			case 2:
			{
				removeThirdColumn(po,isNotesColumn,ct);
				break;
			}


			case 3:
			{
				removeFourthColumn(po,isNotesColumn,ct);
				break;
			}

			case 4:
			{
				removeFifthColumn(po,isNotesColumn,ct);
				break;
			}
			case 5:
			{
				removeSixthColumn(po,isNotesColumn,ct);
				break;
			}

			case 6:
			{
				removeSeventhColumn(po,isNotesColumn,ct);
				break;
			}
			case 7:
			{
				removeEightthColumn(po,isNotesColumn,ct);
				break;
			}
			case 8:
			{
				removeNinthColumn(po,isNotesColumn,ct);
				break;
			}
			case 9:
			{
				removeTenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 10:
			{
				removeElevethColumn(po,isNotesColumn,ct);
				break;
			}
			case 11:
			{
				removeTwelthColumn(po,isNotesColumn,ct);
				break;
			}
			case 12:
			{
				removeThirteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 13:
			{
				removeFourteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 14:
			{
				removeFifteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 15:
			{

				removeSixteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 16:
			{
				removeSeventeenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 17:
			{
				removeEighteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 18:
			{
				removeNinteenthColumn(po,isNotesColumn,ct);
				break;
			}
			case 19:
			{
				removeTwenteethColumn(po,isNotesColumn,ct);
				break;
			}
			case 20:
			{
				removeTwentyoneColumn(po,isNotesColumn,ct);
				break;
			}
			case 21:
			{
				removeTwentytwoColumn(po,isNotesColumn,ct);
				break;
			}
			case 22:
			{
				removeTwentythreeColumn(po,isNotesColumn,ct);
				break;
			}


			case 23:
			{
				removeTwentyfourColumn(po,isNotesColumn,ct);
				break;
			}

			case 24:
			{
				removeTwentyfiveColumn(po,isNotesColumn,ct);
				break;
			}
			case 55:
			{
				removeTwentytsixColumn(po,isNotesColumn,ct);
				break;
			}

			case 26:
			{
				removeTwentysevenColumn(po,isNotesColumn,ct);
				break;
			}
			case 27:
			{
				removeTwentyeightColumn(po,isNotesColumn,ct);
				break;
			}
			case 28:
			{
				removeTwentynineColumn(po,isNotesColumn,ct);
				break;
			}
			/*case 29:
			{
				removeThirtycolumn(po,isNotesColumn,ct);
				break;
			}
			case 30:
			{
				removeThirtyFirstColumn(po,isNotesColumn,ct);
				break;
			}*/
			}
		}
	}


	private void removeTwentynineColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue30(po.getValue29());
		po.setAsRepVal30(po.getAsRepVal29());
		po.setVal30Coords(po.getVal29Coords());
		//removeThirtycolumn(po,isNotesColumn,ct);
	}

	private void removeTwentyeightColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue29(po.getValue28());
		po.setAsRepVal29(po.getAsRepVal28());
		po.setVal29Coords(po.getVal28Coords());
		removeTwentynineColumn(po,isNotesColumn,ct);
	}

	private void removeTwentysevenColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue26(po.getValue27());
		po.setAsRepVal26(po.getAsRepVal27());
		po.setVal26Coords(po.getVal27Coords());
		removeTwentyeightColumn(po,isNotesColumn,ct);
	}
	private void removeTwentytsixColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue25(po.getValue26());
		po.setAsRepVal25(po.getAsRepVal26());
		po.setVal25Coords(po.getVal26Coords());
		removeTwentysevenColumn(po,isNotesColumn,ct);
	}

	private void removeTwentyfiveColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue24(po.getValue25());
		po.setAsRepVal24(po.getAsRepVal25());
		po.setVal24Coords(po.getVal25Coords());
		removeTwentytsixColumn(po,isNotesColumn,ct);
	}
	private void removeTwentyfourColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue23(po.getValue24());
		po.setAsRepVal23(po.getAsRepVal24());
		po.setVal23Coords(po.getVal24Coords());
		removeTwentyfiveColumn(po,isNotesColumn,ct);
	}

	private void removeTwentythreeColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue22(po.getValue23());
		po.setAsRepVal22(po.getAsRepVal23());
		po.setVal22Coords(po.getVal23Coords());
		removeTwentyfourColumn(po,isNotesColumn,ct);
	}
	private void removeTwentytwoColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue21(po.getValue22());
		po.setAsRepVal21(po.getAsRepVal22());
		po.setVal21Coords(po.getVal22Coords());
		removeTwentythreeColumn(po,isNotesColumn,ct);
	}

	private void removeTwentyoneColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue20(po.getValue21());
		po.setAsRepVal20(po.getAsRepVal21());
		po.setVal20Coords(po.getVal21Coords());
		removeTwentytwoColumn(po,isNotesColumn,ct);
	}

	private void removeTwenteethColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn &&ct==19)
			po.setNotesColumn(po.getAsRepVal19());*/
		po.setValue19(po.getValue20());
		po.setAsRepVal19(po.getAsRepVal20());
		po.setVal19Coords(po.getVal20Coords());
		removeTwentyoneColumn(po,isNotesColumn,ct);
	}


	private void removeNinteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==18)
			po.setNotesColumn(po.getAsRepVal18());*/
		po.setValue18(po.getValue19());
		po.setAsRepVal18(po.getAsRepVal19());
		po.setVal18Coords(po.getVal19Coords());
		removeTwenteethColumn(po,isNotesColumn,ct);
	}


	private void removeEighteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==17)
			po.setNotesColumn(po.getAsRepVal17());*/
		po.setValue17(po.getValue18());
		po.setAsRepVal17(po.getAsRepVal18());
		po.setVal17Coords(po.getVal8Coords());
		removeNinteenthColumn(po,isNotesColumn,ct);
	}


	private void removeSeventeenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==16)
			po.setNotesColumn(po.getAsRepVal16());*/
		po.setValue16(po.getValue17());
		po.setAsRepVal16(po.getAsRepVal17());
		po.setVal16Coords(po.getVal17Coords());
		removeEighteenthColumn(po,isNotesColumn,ct);
	}


	private void removeSixteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==15)
			po.setNotesColumn(po.getAsRepVal15());*/
		po.setValue15(po.getValue16());
		po.setAsRepVal15(po.getAsRepVal16());
		po.setVal15Coords(po.getVal16Coords());
		removeSeventeenthColumn(po,isNotesColumn,ct);
	}


	private void removeFifteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==14)
			po.setNotesColumn(po.getAsRepVal14());*/
		po.setValue14(po.getValue15());
		po.setAsRepVal14(po.getAsRepVal15());
		po.setVal14Coords(po.getVal15Coords());
		removeSixteenthColumn(po,isNotesColumn,ct);
	}


	private void removeFourteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==13)
			po.setNotesColumn(po.getAsRepVal13());*/
		po.setValue13(po.getValue14());
		po.setAsRepVal13(po.getAsRepVal14());
		po.setVal13Coords(po.getVal14Coords());
		removeFifteenthColumn(po,isNotesColumn,ct);
	}


	private void removeThirteenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==12)
			po.setNotesColumn(po.getAsRepVal12());*/
		po.setValue12(po.getValue13());
		po.setAsRepVal12(po.getAsRepVal13());
		po.setVal12Coords(po.getVal13Coords());
		removeFourteenthColumn(po,isNotesColumn,ct);
	}


	private void removeTwelthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==11)
			po.setNotesColumn(po.getAsRepVal11());*/
		po.setValue11(po.getValue12());
		po.setAsRepVal11(po.getAsRepVal12());
		po.setVal11Coords(po.getVal12Coords());
		removeThirteenthColumn(po,isNotesColumn,ct);
	}


	private void removeElevethColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==10)
			po.setNotesColumn(po.getAsRepVal10());*/
		po.setValue10(po.getValue11());
		po.setAsRepVal10(po.getAsRepVal11());
		po.setVal10Coords(po.getVal11Coords());
		removeTwelthColumn(po,isNotesColumn,ct);
	}


	private void removeTenthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==11)
			po.setNotesColumn(po.getAsRepVal9());*/
		po.setValue9(po.getValue10());
		po.setAsRepVal9(po.getAsRepVal10());
		po.setVal9Coords(po.getVal10Coords());
		removeElevethColumn(po,isNotesColumn,ct);
	}


	private void removeNinthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==8)
			po.setNotesColumn(po.getAsRepVal8());*/
		po.setValue8(po.getValue9());
		po.setAsRepVal8(po.getAsRepVal9());
		po.setVal8Coords(po.getVal8Coords());

		removeTenthColumn(po,isNotesColumn,ct);
	}


	private void removeEightthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==7)
			po.setNotesColumn(po.getAsRepVal7());*/
		po.setValue7(po.getValue8());
		po.setAsRepVal7(po.getAsRepVal8());
		po.setVal7Coords(po.getVal8Coords());
		removeNinthColumn(po,isNotesColumn,ct);
	}


	private void removeSeventhColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==6)
			po.setNotesColumn(po.getAsRepVal6());*/
		po.setValue6(po.getValue7());
		po.setAsRepVal6(po.getAsRepVal7());
		po.setVal6Coords(po.getVal7Coords());

		removeEightthColumn(po,isNotesColumn,ct);
	}


	private void removeSixthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==5)
			po.setNotesColumn(po.getAsRepVal5());*/
		po.setValue5(po.getValue6());
		po.setAsRepVal5(po.getAsRepVal6());
		po.setVal5Coords(po.getVal6Coords());

		removeSeventhColumn(po,isNotesColumn,ct);
	}


	private void removeFifthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==4)
			po.setNotesColumn(po.getAsRepVal4());*/
		po.setValue4(po.getValue5());
		po.setAsRepVal4(po.getAsRepVal5());
		po.setVal4Coords(po.getVal5Coords());

		removeSixthColumn(po,isNotesColumn,ct);
	}


	private void removeFourthColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==3)
			po.setNotesColumn(po.getAsRepVal3());*/
		po.setValue3(po.getValue4());
		po.setAsRepVal3(po.getAsRepVal4());
		po.setVal3Coords(po.getVal4Coords());

		removeFifthColumn(po,isNotesColumn,ct);
	}


	private void removeThirdColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==2)
			po.setNotesColumn(po.getAsRepVal2());*/
		po.setValue2(po.getValue3());
		po.setAsRepVal2(po.getAsRepVal3());
		po.setVal2Coords(po.getVal3Coords());
		removeFourthColumn(po,isNotesColumn,ct);
	}


	private void removeSecondColumn(ParserOutput po,Boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==1)
			po.setNotesColumn(po.getAsRepVal1());*/
		po.setValue1(po.getValue2());
		po.setAsRepVal1(po.getAsRepVal2());
		po.setVal1Coords(po.getVal2Coords());
		removeThirdColumn(po,isNotesColumn,ct);
	}


	private void removefirstColumn(ParserOutput po, boolean isNotesColumn,int ct) {
		/*if(isNotesColumn && ct==0)
			po.setNotesColumn(po.getAsRepLabel());*/
		isNotesColumn = false;
		po.setAsRepLabel(po.getValue1());
		po.setValue1(po.getValue2());
		po.setAsRepVal1(po.getAsRepVal2());
		po.setValue2(po.getValue3());
		po.setAsRepVal2(po.getAsRepVal3());
		po.setValue3(po.getValue4());
		po.setAsRepVal3(po.getAsRepVal4());
		po.setValue4(po.getValue5());
		po.setAsRepVal4(po.getAsRepVal5());
		po.setValue5(po.getValue6());
		po.setAsRepVal5(po.getAsRepVal6());
		po.setValue6(po.getValue7());
		po.setAsRepVal6(po.getAsRepVal7());
		po.setValue7(po.getValue8());
		po.setAsRepVal7(po.getAsRepVal8());
		po.setValue8(po.getValue9());
		po.setAsRepVal8(po.getAsRepVal9());
		po.setValue19(po.getValue10());
		po.setAsRepVal9(po.getAsRepVal10());
		po.setValue10(po.getValue11());
		po.setAsRepVal10(po.getAsRepVal11());
		po.setValue11(po.getValue12());
		po.setAsRepVal11(po.getAsRepVal12());
		po.setValue12(po.getValue13());
		po.setAsRepVal12(po.getAsRepVal13());
		po.setValue13(po.getValue14());
		po.setAsRepVal13(po.getAsRepVal14());
		po.setValue14(po.getValue15());
		po.setAsRepVal14(po.getAsRepVal15());
		po.setValue16(po.getValue17());
		po.setAsRepVal16(po.getAsRepVal17());
		po.setValue17(po.getValue18());
		po.setAsRepVal17(po.getAsRepVal18());
		po.setValue18(po.getValue19());
		po.setAsRepVal18(po.getAsRepVal19());
		po.setValue19(po.getValue20());
		po.setAsRepVal19(po.getAsRepVal20());
		po.setValue20(po.getValue21());
		po.setAsRepVal20(po.getAsRepVal21());
		po.setValue21(po.getValue22());
		po.setAsRepVal21(po.getAsRepVal22());
		po.setValue22(po.getValue23());
		po.setAsRepVal22(po.getAsRepVal23());
		po.setValue23(po.getValue24());
		po.setAsRepVal23(po.getAsRepVal24());
		po.setValue24(po.getValue25());
		po.setAsRepVal24(po.getAsRepVal25());
		po.setValue25(po.getValue26());
		po.setAsRepVal25(po.getAsRepVal26());
		po.setValue26(po.getValue27());
		po.setAsRepVal26(po.getAsRepVal27());
		po.setValue27(po.getValue28());
		po.setAsRepVal27(po.getAsRepVal28());
		po.setValue28(po.getValue29());
		po.setAsRepVal28(po.getAsRepVal29());
		po.setValue29(po.getValue30());
		po.setAsRepVal29(po.getAsRepVal30());
		po.setVal1Coords(po.getVal2Coords());
		po.setVal2Coords(po.getVal3Coords());
		po.setVal3Coords(po.getVal4Coords());
		po.setVal4Coords(po.getVal5Coords());
		po.setVal5Coords(po.getVal6Coords());
		po.setVal6Coords(po.getVal7Coords());
		po.setVal7Coords(po.getVal8Coords());
		po.setVal8Coords(po.getVal9Coords());
		po.setVal9Coords(po.getVal10Coords());
		removeSeventeenthColumn(po,isNotesColumn,ct);
	}

	/*private static void removeUnWantedColumn(ArrayList<ParserOutput> poObjects) {
		boolean notesFound = false;
		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);		
			if(po.getValue1().trim().equalsIgnoreCase("Notes") && po.getAsRepLabel().equalsIgnoreCase("Heading"))
			{
				notesFound = true;
			}
			if(notesFound)
				shiftColumns(po);
		}
	}*/





	private static ArrayList<ParserOutput> getPoObjectsFromHeaderColumns(
			HashMap<Row, List<List<PDFWord>>> headerMap, Section section,int maxCol,int pageNo) {
		int ct = 0;
		ArrayList<ParserOutput> poColumns = new ArrayList<ParserOutput>();
		ParserOutput po = null;
		for(Row headerRow : headerMap.keySet())
		{
			List<List<PDFWord>> headerColumns = headerMap.get(headerRow);
			String column = "";
			ct = 0;
			po = new ParserOutput();
			for(List<PDFWord> columnWords : headerColumns){
				column ="";
				/*if(ct==0 )
				{
					ct++;
					continue;
				}*/
				//ct = 0;

				if(columnWords!=null)
				{
					for(PDFWord word :columnWords){
						if(pageNo==0)
						{
							pageNo = word.getPageNo();
						}
						/*for(String keyword:TimePeriodOntology.getNotesList())
						{
							if(word!=null && word.getWord().equals(anObject).contains(keyword.toLowerCase()))
							{
								if(ct==0)
									ct=1;
								break;

							}
						}*/
						column = column+ " "+word.toString().trim();
					}	
				}

				setpoObject(po,ct,column.trim());
				ct++;
			}
			po.setLine(headerRow.getLines().toString());
			po.setSection(section.getSectionName());
			po.setPageNo(pageNo);
			po.setLineNo(headerRow.getId());
			po.setRow(headerRow);
			po.setIsHeading("Y");
			po.setType("HEADER");
			po.setMaxCol(maxCol);
			po.setPrevHeader("N");
			po.setPdfLine(headerRow.getLines().get(headerRow.getLines().size()-1));
			po.setTableID(section.getInstanceID());
			poColumns.add(po);
		}
		return poColumns;
	}


	private static ArrayList<ParserOutput> generateStatementAttributes( List<ParserOutput> poObjects,int maxCols, TreeSet<String> keywords, Map<Integer, String> forList) throws Exception
	{/*
		ArrayList<ParserOutput> sectionAttr=new ArrayList<ParserOutput>();
		String section = "";
		int  pgNo = -1, prevPageNo = -1instanceID= 0;

		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);
			if(i==0)
			{
				//instanceID = po.getTableID();
				section = po.getSection();
				pgNo = po.getPageNo();
			}
			if((prevPageNo>-1 &&  po.getPageNo()!=prevPageNo) || (po.getIsHeading()==null && (sectionAttr.size()>0 || i>10)) || ( po.getIsHeading()!=null && sectionAttr.size()>0  &&  !po.getIsHeading().equalsIgnoreCase("Y")))
			{
				break;
			}

			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y"))
			{
				sectionAttr.add(po);
			}
			prevPageNo = po.getPageNo();

		}
		TreeSet<Integer> columns = null;
		if(sectionAttr.size()>0)
		{
			columns = getColumnsContaining(keywords,sectionAttr);
			Attributes attributes = new StatementAttributes();
			ArrayList<ParserOutput> stmtAttributes = attributes.getStatementColumnAttributes(sectionAttr,poObjects, section, maxCols,pgNo,columns,SectionBoundaryDetector.getStatementQuality());
			//int colNo = isHeaderContains(TimePeriodOntology.getNotesList(),poObjects);
			if(stmtAttributes.size()>0)
			{
				checkForStmtFor(forList, stmtAttributes);
				return stmtAttributes;
			}

		}
		boolean headingPresent = false;
		if(sectionAttr.size()>0)
		{
			headingPresent = true;
		}
		sectionAttr.clear();
		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);
			if(i==0)
			{
				//instanceID = po.getTableID();
				section = po.getSection();
				pgNo = po.getPageNo();
			}

			if(headingPresent &&(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")))
			{
				sectionAttr.add(po);
				break;
			}
			if(i==5 && headingPresent)
				break;

			sectionAttr.add(po);
		}
		Attributes attributes=new StatementAttributes();
		//int colNo = isHeaderContains(TimePeriodOntology.getNotesList(),poObjects);

		ArrayList<ParserOutput> stmtAttributes = attributes.getStatementAttributes(sectionAttr, section, maxCols,pgNo,columns,SectionBoundaryDetector.getStatementQuality());
		checkForStmtFor(forList, stmtAttributes);

		return stmtAttributes;	

	 */

		ArrayList<ParserOutput> sectionAttr=new ArrayList<ParserOutput>();
		String section = "";
		int  pgNo = -1, prevPageNo = -1/*instanceID= 0*/;

		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);
			if(i==0)
			{
				//instanceID = po.getTableID();
				section = po.getSection();
				pgNo = po.getPageNo();
			}
			if((prevPageNo>-1 &&  po.getPageNo()!=prevPageNo) || (po.getIsHeading()==null && (sectionAttr.size()>0 || i>10)) || ( po.getIsHeading()!=null && sectionAttr.size()>0  &&  !po.getIsHeading().equalsIgnoreCase("Y")))
			{
				break;
			}

			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y"))
			{
				sectionAttr.add(po);
			}
			prevPageNo = po.getPageNo();

		}
		TreeSet<Integer> columns = null;
		ArrayList<ParserOutput> columnStmtAttributes  = new ArrayList<ParserOutput>();
		if(sectionAttr.size()>0)
		{
			columns = getColumnsContaining(keywords,sectionAttr);
			Attributes attributes = new StatementAttributes();
			columnStmtAttributes = attributes.getStatementColumnAttributes(sectionAttr,poObjects, section, maxCols,pgNo,columns,SectionBoundaryDetector.getStatementQuality());
			//int colNo = isHeaderContains(TimePeriodOntology.getNotesList(),poObjects);
			/*//			if(columnStmtAttributes.size()>0)
//			{
//				checkForStmtFor(forList, columnStmtAttributes);
//			}
			 */
		}
		boolean headingPresent = false;
		if(columnStmtAttributes!=null && columnStmtAttributes.size()>0)
		{
			headingPresent = true;
		}
		Collections.sort(poObjects);

		sectionAttr.clear();
		for(int i=0;i<poObjects.size();i++)
		{
			ParserOutput po = poObjects.get(i);
			if(i==0)
			{
				//instanceID = po.getTableID();
				section = po.getSection();
				pgNo = po.getPageNo();
			}

			if(headingPresent && (po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")))
			{
				sectionAttr.add(po);
				break;
			}
			if(i==5 && headingPresent)
				break;

			sectionAttr.add(po);
		}
		Attributes attributes=new StatementAttributes();

		ArrayList<ParserOutput> mainStmtAttributes = attributes.getStatementAttributes(sectionAttr, section, maxCols,pgNo,columns,SectionBoundaryDetector.getStatementQuality());

		if(columnStmtAttributes.size()>0)
		{
			for(int k=0;k<columnStmtAttributes.size();k++)
			{
				for(int j=0;j<mainStmtAttributes.size();j++)
				{
					ParserOutput columnStmtAttribute = columnStmtAttributes.get(k);
					ParserOutput mainStmtAttribute = mainStmtAttributes.get(j);
					if(columnStmtAttribute.getAsRepLabel().trim().equalsIgnoreCase(mainStmtAttribute.getAsRepLabel().trim()))
					{
						if((columnStmtAttribute.getValue1()==null ||columnStmtAttribute.getValue1().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue1()!=null && !mainStmtAttribute.getValue1().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue1(mainStmtAttribute.getValue1());
						}
						if((columnStmtAttribute.getValue2()==null ||columnStmtAttribute.getValue2().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue2()!=null && !mainStmtAttribute.getValue2().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue2(mainStmtAttribute.getValue2());
						}
						if((columnStmtAttribute.getValue3()==null ||columnStmtAttribute.getValue3().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue3()!=null && !mainStmtAttribute.getValue3().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue3(mainStmtAttribute.getValue3());
						}
						if((columnStmtAttribute.getValue4()==null ||columnStmtAttribute.getValue4().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue4()!=null && !mainStmtAttribute.getValue4().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue4(mainStmtAttribute.getValue4());
						}
						if((columnStmtAttribute.getValue5()==null ||columnStmtAttribute.getValue5().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue5()!=null && !mainStmtAttribute.getValue5().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue5(mainStmtAttribute.getValue5());
						}
						if((columnStmtAttribute.getValue6()==null ||columnStmtAttribute.getValue6().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue6()!=null && !mainStmtAttribute.getValue6().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue6(mainStmtAttribute.getValue6());
						}
						if((columnStmtAttribute.getValue7()==null ||columnStmtAttribute.getValue7().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue7()!=null && !mainStmtAttribute.getValue7().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue7(mainStmtAttribute.getValue7());
						}
						if((columnStmtAttribute.getValue8()==null ||columnStmtAttribute.getValue8().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue8()!=null && !mainStmtAttribute.getValue8().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue8(mainStmtAttribute.getValue8());
						}
						if((columnStmtAttribute.getValue9()==null ||columnStmtAttribute.getValue9().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue9()!=null && !mainStmtAttribute.getValue9().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue9(mainStmtAttribute.getValue9());
						}
						if((columnStmtAttribute.getValue10()==null ||columnStmtAttribute.getValue10().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue10()!=null && !mainStmtAttribute.getValue10().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue10(mainStmtAttribute.getValue10());
						}
						if((columnStmtAttribute.getValue11()==null ||columnStmtAttribute.getValue11().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue11()!=null && !mainStmtAttribute.getValue11().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue11(mainStmtAttribute.getValue11());
						}
						if((columnStmtAttribute.getValue12()==null ||columnStmtAttribute.getValue12().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue12()!=null && !mainStmtAttribute.getValue12().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue12(mainStmtAttribute.getValue12());
						}
						if((columnStmtAttribute.getValue13()==null ||columnStmtAttribute.getValue13().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue13()!=null && !mainStmtAttribute.getValue13().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue13(mainStmtAttribute.getValue13());
						}
						if((columnStmtAttribute.getValue14()==null ||columnStmtAttribute.getValue14().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue14()!=null && !mainStmtAttribute.getValue14().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue14(mainStmtAttribute.getValue14());
						}
						if((columnStmtAttribute.getValue15()==null ||columnStmtAttribute.getValue15().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue15()!=null && !mainStmtAttribute.getValue15().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue15(mainStmtAttribute.getValue15());
						}
						if((columnStmtAttribute.getValue16()==null ||columnStmtAttribute.getValue16().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue16()!=null && !mainStmtAttribute.getValue16().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue16(mainStmtAttribute.getValue16());
						}
						if((columnStmtAttribute.getValue17()==null ||columnStmtAttribute.getValue17().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue17()!=null && !mainStmtAttribute.getValue17().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue17(mainStmtAttribute.getValue17());
						}
						if((columnStmtAttribute.getValue18()==null ||columnStmtAttribute.getValue18().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue18()!=null && !mainStmtAttribute.getValue18().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue18(mainStmtAttribute.getValue18());
						}
						if((columnStmtAttribute.getValue19()==null ||columnStmtAttribute.getValue19().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue19()!=null && !mainStmtAttribute.getValue19().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue19(mainStmtAttribute.getValue19());
						}
						if((columnStmtAttribute.getValue20()==null ||columnStmtAttribute.getValue20().trim().equalsIgnoreCase(""))
								&& (mainStmtAttribute.getValue20()!=null && !mainStmtAttribute.getValue20().trim().equalsIgnoreCase("")))
						{
							columnStmtAttribute.setValue20(mainStmtAttribute.getValue20());
						}

					}
				}
			}
			checkForStmtFor(forList, columnStmtAttributes);

			return columnStmtAttributes;
		}
		checkForStmtFor(forList, mainStmtAttributes);

		return mainStmtAttributes;


		//	checkForStmtFor(forList, stmtAttributes);

		//return stmtAttributes;	

		/*if(colNo>0)
		{
			setStatementAttributesstmt(stmtAttributes,colNo);
		}*/

	}
	private static void checkForStmtFor(Map<Integer, String> forList,
			ArrayList<ParserOutput> stmtAttributes) {
		if(stmtAttributes!=null && stmtAttributes.size()>0 && forList!=null && forList.size()>0)
		{
			TreeSet<Integer> columnList = checkYearPattern(stmtAttributes);
			columnList.add(1);
			if(forList.size()+1==(columnList.size()))
			{
				for(ParserOutput po:stmtAttributes)
				{
					if(po.getAsRepLabel().toString().trim().startsWith("STATEMENT FOR"))
					{

						Integer prevColNo = null;
						for(Integer colNo:columnList)
						{

							if(prevColNo!=null)
							{
								for(Integer col:forList.keySet())
								{
									String str = forList.get(col).toUpperCase();

									for(int k=prevColNo;k<colNo;k++)
									{
										switch(k)
										{
										case 1:
										{
											po.setAsRepVal1(str);
											po.setValue1(str);
											break;
										}
										case 2:
										{
											po.setAsRepVal2(str);
											po.setValue2(str);
											break;
										}
										case 3:
										{
											po.setAsRepVal3(str);
											po.setValue3(str);
											break;
										}
										case 4:
										{
											po.setAsRepVal4(str);
											po.setValue4(str);
											break;
										}
										case 5:
										{
											po.setAsRepVal5(str);
											po.setValue5(str);
											break;
										}
										case 6:
										{
											po.setAsRepVal6(str);
											po.setValue6(str);
											break;
										}
										case 7:
										{
											po.setAsRepVal7(str);
											po.setValue7(str);
											break;
										}
										case 8:
										{
											po.setAsRepVal8(str);
											po.setValue8(str);
											break;
										}
										case 9:
										{
											po.setAsRepVal9(str);
											po.setValue9(str);
											break;
										}
										case 10:
										{
											po.setAsRepVal10(str);
											po.setValue10(str);
											break;
										}
										case 11:
										{
											po.setAsRepVal11(str);
											po.setValue11(str);
											break;
										}
										case 12:
										{
											po.setAsRepVal12(str);
											po.setValue12(str);
											break;
										}
										case 13:
										{
											po.setAsRepVal13(str);
											po.setValue13(str);
											break;
										}
										case 14:
										{
											po.setAsRepVal14(str);
											po.setValue14(str);
											break;
										}
										case 15:
										{
											po.setAsRepVal15(str);
											po.setValue15(str);
											break;
										}
										case 16:
										{
											po.setAsRepVal16(str);
											po.setValue16(str);
											break;
										}
										case 17:
										{
											po.setAsRepVal17(str);
											po.setValue17(str);
											break;
										}
										case 18:
										{
											po.setAsRepVal18(str);
											po.setValue18(str);
											break;
										}
										case 20:
										{
											po.setAsRepVal20(str);
											po.setValue20(str);
											break;
										}
										case 21:
										{
											po.setAsRepVal21(str);
											po.setValue21(str);
											break;
										}
										case 22:
										{
											po.setAsRepVal22(str);
											po.setValue22(str);
											break;
										}
										case 23:
										{
											po.setAsRepVal23(str);
											po.setValue23(str);
											break;
										}
										case 24:
										{
											po.setAsRepVal24(str);
											po.setValue24(str);
											break;
										}
										case 25:
										{
											po.setAsRepVal25(str);
											po.setValue25(str);
											break;
										}
										case 26:
										{
											po.setAsRepVal26(str);
											po.setValue26(str);
											break;
										}
										case 27:
										{
											po.setAsRepVal27(str);
											po.setValue27(str);
											break;
										}
										case 28:
										{
											po.setAsRepVal28(str);
											po.setValue28(str);
											break;
										}
										case 29:
										{
											po.setAsRepVal29(str);
											po.setValue29(str);
											break;
										}
										case 30:
										{
											po.setAsRepVal30(str);
											po.setValue30(str);
											break;
										}
										}
									}

									forList.remove(col);
									break;
								}


							}
							prevColNo = colNo;
						}
					}
				}

			}

		}
	}





	private static TreeSet<Integer>  checkYearPattern(ArrayList<ParserOutput> stmtAttributes) 
	{
		TreeSet<Integer> columnList = new TreeSet<Integer>();
		int year = 0;
		for(ParserOutput po:stmtAttributes)	{
			if(po.getAsRepLabel().toString().startsWith("STATEMENT YEAR"))
			{
				if(po.getValue1()!=null)
					year = Integer.parseInt(po.getValue1().trim());

				if(po.getValue2()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue2(),2);
					if(thisCol!=-1)
					{
						columnList.add(2);
					}

				}
				if(po.getValue3()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue3(),3);
					if(thisCol!=-1)
					{
						columnList.add(3);
					}
				}
				if(po.getValue4()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue4(),4);
					if(thisCol!=-1)
					{
						columnList.add(4);
					}
				}
				if(po.getValue5()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue5(),5);
					if(thisCol!=-1)
					{
						columnList.add(5);
					}
				}
				if(po.getValue6()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue6(),6);
					if(thisCol!=-1)
					{
						columnList.add(6);
					}
				}
				if(po.getValue7()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue7(),7);
					if(thisCol!=-1)
					{
						columnList.add(7);
					}
				}
				if(po.getValue8()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue8(),8);
					if(thisCol!=-1)
					{
						columnList.add(8);
					}
				}
				if(po.getValue9()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue9(),9);
					if(thisCol!=-1)
					{
						columnList.add(9);
					}
				}
				if(po.getValue10()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue10(),10);
					if(thisCol!=-1)
					{
						columnList.add(10);
					}
				}
				if(po.getValue11()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue11(),11);
					if(thisCol!=-1)
					{
						columnList.add(11);
					}
				}

				if(po.getValue12()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue12(),12);
					if(thisCol!=-1)
					{
						columnList.add(12);
					}

				}
				if(po.getValue13()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue13(),13);
					if(thisCol!=-1)
					{
						columnList.add(13);
					}

				}
				if(po.getValue14()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue14(),14);
					if(thisCol!=-1)
					{
						columnList.add(14);
					}
				}
				if(po.getValue15()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue15(),15);
					if(thisCol!=-1)
					{
						columnList.add(15);
					}
				}
				if(po.getValue16()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue16(),16);
					if(thisCol!=-1)
					{
						columnList.add(16);
					}
				}
				if(po.getValue17()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue17(),17);
					if(thisCol!=-1)
					{
						columnList.add(17);
					}
				}
				if(po.getValue18()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue2(),18);
					if(thisCol!=-1)
					{
						columnList.add(18);
					}
				}
				if(po.getValue19()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue19(),19);
					if(thisCol!=-1)
					{
						columnList.add(19);
					}
				}
				if(po.getValue20()!=null)
				{
					int thisCol = yearLessThanPrevious(year, po.getValue2(),20);
					if(thisCol!=-1)
					{
						columnList.add(20);
					}
				}

				columnList.add(po.getMaxCol());

			}

		}
		return columnList;
	}
	private static int yearLessThanPrevious(int year, String value,int col) {
		if(year<=Integer.parseInt(value.trim()))
		{
			year =  Integer.parseInt(value.trim());
			return year;
		}

		return -1;
	}


	private static void setStatementAttributesstmt(
			ArrayList<ParserOutput> stmtAttributes, int colNo) {

		switch(colNo)
		{
		case 1:
			for(ParserOutput po:stmtAttributes)
			{

				if(po.getMaxCol()<10)
				{
					po.setAsRepVal10(po.getAsRepVal9());
					po.setValue10(po.getValue9());
					po.setAsRepVal9(po.getAsRepVal8());
					po.setValue9(po.getValue8());
					po.setAsRepVal8(po.getAsRepVal7());
					po.setValue8(po.getValue7());
					po.setAsRepVal7(po.getAsRepVal6());
					po.setValue7(po.getValue6());
					po.setAsRepVal6(po.getAsRepVal5());
					po.setValue6(po.getValue5());
					po.setAsRepVal5(po.getAsRepVal4());
					po.setValue5(po.getValue4());
					po.setAsRepVal4(po.getAsRepVal3());
					po.setValue4(po.getValue3());

					po.setAsRepVal3(po.getAsRepVal2());
					po.setValue3(po.getValue2());
					po.setAsRepVal1("");
					po.setValue1("");

				}

			}
			break;
		case 2:
			for(ParserOutput po:stmtAttributes)
			{
				po.setAsRepVal2("");
			}
			break;
		case 3:
			for(ParserOutput po:stmtAttributes)
			{
				po.setAsRepVal3("");
			}
			break;
		case 4:
			for(ParserOutput po:stmtAttributes)
			{
				po.setAsRepVal4("");
			}
			break;
		case 5:
			for(ParserOutput po:stmtAttributes)
			{
				po.setAsRepVal5("");
			}
			break;

		}


	}

	private static Pattern pattern = null;
	static{
		try{
			pattern = Pattern.compile("(Note|Notes)\\s*\\d+\\,*\\s*\\d*");
		} catch(Exception e){

		}
	} 

	private static Boolean isNotesfound(LinkedHashSet<String> notesList,String value)
	{
		for(String lstVal :notesList)
		{
			if(value.toLowerCase().contains(lstVal.trim().toLowerCase()))
			{
				/*if(pattern != null){
					Matcher matcher = null; 
					matcher = pattern.matcher(value);
					if(matcher.find()){
						return false;
					}
				}*/
				return true;
			}
		}
		return false;
	} 

	private static Boolean isNotesfound(LinkedHashSet<String> notesList,List<PDFLine> lines)
	{
		if(lines==null || lines.size()<1)
			return false;
		for(PDFLine line:lines)
		{
			for(PDFChunk chunk:line.getChunks())
			{
				String value=chunk.getChunk();
				for(String lstVal :notesList)
				{
					if(value.toLowerCase().contains(lstVal.trim().toLowerCase()))
					{
						if(pattern != null)
						{
							Matcher matcher = null; 
							matcher = pattern.matcher(value);
							if(matcher.find())
							{
								return true;
							}
						}
					}
				}
			}
		}
		return false;
	} 

	private static int isHeaderContains(LinkedHashSet<String> notesList,
			List<ParserOutput> poObjects) {
		//Collections.sort(poObjects);

		for(ParserOutput po: poObjects)
		{
			List<PDFLine> rowLines=po.getRow()==null?null:po.getRow().getLines();
			boolean isPatternFound=isNotesfound(notesList, rowLines);
			if(isPatternFound)
				break;
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && po.getValue1()!=null &&( notesList.contains(po.getValue1().toLowerCase().trim()) || isNotesfound(notesList,po.getValue1())))
			{
				return 1;
			}
			if( po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue2()!=null && (notesList.contains(po.getValue2().toLowerCase().trim()) || isNotesfound(notesList,po.getValue2())))
			{
				return 2;
			}
			if(  po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && po.getValue3()!=null && (notesList.contains(po.getValue3().toLowerCase().trim()) || isNotesfound(notesList,po.getValue3())))
			{
				return 3;
			}
			if( po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") && po.getValue4()!=null  && (notesList.contains(po.getValue4().toLowerCase().trim())|| isNotesfound(notesList,po.getValue4())))
			{
				return 4;
			}
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue5()!=null && (notesList.contains(po.getValue5().toLowerCase().trim())|| isNotesfound(notesList,po.getValue5())))
			{
				return 5;
			}
			if( po.getIsHeading()!=null && po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue6()!=null && (notesList.contains(po.getValue6().toLowerCase().trim())|| isNotesfound(notesList,po.getValue6())))
			{
				return 6;
			}
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue7()!=null && (notesList.contains(po.getValue7().toLowerCase().trim())|| isNotesfound(notesList,po.getValue7())))
			{
				return 7;
			}
			if(po.getIsHeading()!=null && po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue8()!=null && (notesList.contains(po.getValue8().toLowerCase().trim())|| isNotesfound(notesList,po.getValue8())))
			{
				return 8;
			}
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue9()!=null && (notesList.contains(po.getValue9().toLowerCase().trim())|| isNotesfound(notesList,po.getValue9())))
			{
				return 9;
			}
			if(po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y") &&  po.getValue10()!=null && (notesList.contains(po.getValue6().toLowerCase().trim())|| isNotesfound(notesList,po.getValue10())))
			{
				return 10;
			}

		}



		//System.out.print("returnnnnnnnnnn");
		return -1;
	}


	private static TreeSet<Integer> getColumnsContaining(TreeSet<String> keywords, ArrayList<ParserOutput> sectionAttr) {
		TreeSet<Integer> columns = new TreeSet<Integer>();
		for(String keyword :keywords)
		{
			for(ParserOutput po: sectionAttr)
			{
				if(po.getAsRepVal1()!=null && po.getAsRepVal1().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(1);
				}
				if(po.getAsRepVal2()!=null && po.getAsRepVal2().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(2);
				}
				if(po.getAsRepVal3()!=null && po.getAsRepVal3().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(3);
				}
				if(po.getAsRepVal4()!=null && po.getAsRepVal4().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(4);
				}
				if(po.getAsRepVal5()!=null && po.getAsRepVal5().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(5);
				}
				if(po.getAsRepVal6()!=null && po.getAsRepVal6().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(6);
				}
				if(po.getAsRepVal7()!=null && po.getAsRepVal7().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(7);
				}
				if(po.getAsRepVal8()!=null && po.getAsRepVal8().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(8);
				}
				if(po.getAsRepVal9()!=null && po.getAsRepVal9().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(9);
				}
				if(po.getAsRepVal10()!=null && po.getAsRepVal10().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(10);
				}if(po.getAsRepVal11()!=null && po.getAsRepVal11().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(11);
				}
				if(po.getAsRepVal12()!=null && po.getAsRepVal12().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(12);
				}
				if(po.getAsRepVal13()!=null && po.getAsRepVal13().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(13);
				}
				if(po.getAsRepVal14()!=null && po.getAsRepVal14().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(14);
				}
				if(po.getAsRepVal15()!=null && po.getAsRepVal15().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(15);
				}
				if(po.getAsRepVal16()!=null && po.getAsRepVal16().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(16);
				}
				if(po.getAsRepVal17()!=null && po.getAsRepVal17().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(17);
				}
				if(po.getAsRepVal18()!=null && po.getAsRepVal18().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(18);
				}
				if(po.getAsRepVal19()!=null && po.getAsRepVal19().toLowerCase().contains(keyword.toLowerCase()))
				{
					columns.add(19);
				}

			}
		}

		return columns;
	}


	private static void setpoObject(ParserOutput po, int ct, String val) {
		switch(ct)
		{
		case 0:	{
			po.setAsRepLabel(val);
			break;
		}
		case 1:	{
			po.setAsRepVal1(val);
			po.setValue1(val);
			break;
		}
		case 2:	{
			po.setAsRepVal2(val);
			po.setValue2(val);
			break;
		}
		case 3:	{
			po.setAsRepVal3(val);
			po.setValue3(val);
			break;
		}
		case 4:	{
			po.setAsRepVal4(val);
			po.setValue4(val);
			break;
		}
		case 5:	{
			po.setAsRepVal5(val);
			po.setValue5(val);
			break;
		}
		case 6:	{
			po.setAsRepVal6(val);
			po.setValue6(val);
			break;
		}
		case 7:	{
			po.setAsRepVal7(val);
			po.setValue7(val);
			break;
		}
		case 8:	{
			po.setAsRepVal8(val);
			po.setValue8(val);
			break;
		}
		case 9:	{
			po.setAsRepVal9(val);
			po.setValue9(val);
			break;
		}
		case 10:	{
			po.setAsRepVal10(val);
			po.setValue10(val);
			break;
		}
		case 11:	{
			po.setAsRepVal11(val);
			po.setValue11(val);
			break;
		}
		case 12:	{
			po.setAsRepVal12(val);
			po.setValue12(val);
			break;
		}
		case 13:	{
			po.setAsRepVal13(val);
			po.setValue13(val);
			break;
		}
		case 14:	{
			po.setAsRepVal14(val);
			po.setValue14(val);
			break;
		}
		case 15:	{
			po.setAsRepVal15(val);
			po.setValue15(val);
			break;
		}
		case 16:	{
			po.setAsRepVal16(val);
			po.setValue16(val);
			break;
		}
		case 17:	{
			po.setAsRepVal17(val);
			po.setValue17(val);
			break;
		}
		case 18:	{
			po.setAsRepVal18(val);
			po.setValue18(val);
			break;
		}
		case 19:	{
			po.setAsRepVal19(val);
			po.setValue19(val);
			break;
		}
		case 20:	{
			po.setAsRepVal20(val);
			po.setValue20(val);
			break;
		}
		case 21:	{
			po.setAsRepVal21(val);
			po.setValue21(val);
			break;
		}
		case 22:	{
			po.setAsRepVal22(val);
			po.setValue22(val);
			break;
		}
		case 23:	{
			po.setAsRepVal23(val);
			po.setValue23(val);
			break;
		}
		case 24:	{
			po.setAsRepVal24(val);
			po.setValue24(val);
			break;
		}
		case 25:	{
			po.setAsRepVal25(val);
			po.setValue25(val);
			break;
		}
		case 26:	{
			po.setAsRepVal26(val);
			po.setValue26(val);
			break;
		}
		case 27:	{
			po.setAsRepVal27(val);
			po.setValue27(val);
			break;
		}
		case 28:	{
			po.setAsRepVal28(val);
			po.setValue28(val);
			break;
		}
		case 29:	{
			po.setAsRepVal29(val);
			po.setValue29(val);
			break;
		}
		case 30:	{
			po.setAsRepVal30(val);
			po.setValue30(val);
			break;
		}

		}
	}

	private static String getPoAsRepObject(ParserOutput po, int ct) {
		String ret=null;
		switch(ct)
		{
		case 0:	{
			ret=po.getAsRepLabel();
			break;
		}
		case 1:	{
			ret=po.getAsRepVal1();
			break;
		}
		case 2:	{

			ret=po.getAsRepVal2();
			break;
		}
		case 3:	{
			ret=po.getAsRepVal3();
			break;
		}
		case 4:	{
			ret=po.getAsRepVal4();
			break;
		}
		case 5:	{
			ret=po.getAsRepVal5();
			break;
		}
		case 6:	{
			ret=po.getAsRepVal6();
			break;
		}
		case 7:	{
			ret=po.getAsRepVal7();
			break;
		}
		case 8:	{
			ret=po.getAsRepVal8();
			break;
		}
		case 9:	{
			ret=po.getAsRepVal9();
			break;
		}
		case 10:	{
			ret=po.getAsRepVal10();
			break;
		}
		case 11:	{
			ret=po.getAsRepVal11();
			break;
		}
		case 12:	{
			ret=po.getAsRepVal12();
			break;
		}
		case 13:	{
			ret=po.getAsRepVal13();
			break;
		}
		case 14:	{
			ret=po.getAsRepVal14();
			break;
		}
		case 15:	{
			ret=po.getAsRepVal15();
			break;
		}
		case 16:	{
			ret=po.getAsRepVal16();
			break;
		}
		case 17:	{
			ret=po.getAsRepVal17();
			break;
		}
		case 18:	{
			ret=po.getAsRepVal18();
			break;
		}
		case 19:	{
			ret=po.getAsRepVal19();
			break;
		}
		case 20:	{
			ret=po.getAsRepVal20();
			break;
		}
		case 21:	{
			ret=po.getAsRepVal21();
			break;
		}
		case 22:	{

			ret=po.getAsRepVal22();
			break;
		}
		case 23:	{
			ret=po.getAsRepVal23();
			break;
		}
		case 24:	{
			ret=po.getAsRepVal24();
			break;
		}
		case 25:	{
			ret=po.getAsRepVal25();
			break;
		}
		case 26:	{
			ret=po.getAsRepVal26();
			break;
		}
		case 27:	{
			ret=po.getAsRepVal27();
			break;
		}
		case 28:	{
			ret=po.getAsRepVal28();
			break;
		}
		case 29:	{
			ret=po.getAsRepVal29();
			break;
		}
		case 30:	{
			ret=po.getAsRepVal30();
			break;
		}

		}
		return ret;
	}

	private static ArrayList<ParserOutput> getPoObjects(
			TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap, int pageNo,String section,int maxCol, ParserOutput poHeader,Integer instanceID, Integer columnNo,String keyword, String subSection) {
		ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
		TreeMap<Integer, List<PDFChunk>> columnChunksMapSpanishITR = null;
		Boolean negativeSign = false;
		getLanguageSpecificRules();

		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;
			ParserOutput po = new ParserOutput();
			negativeSign = false;
			/*if(columnChunksMapSpanishITR!=null)
				columnChunksMap = columnChunksMapSpanishITR;*/
			for ( Integer column : columnChunksMap.keySet() )
			{

				List<PDFChunk> chunks = columnChunksMap.get(column) ;

				if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR") &&  keyword.equalsIgnoreCase("ESTADO DE RESULTADOS") &&  section.equalsIgnoreCase("IS") )
				{
					if(maxCol==4)
					{
						if(column.intValue()==1 || column.intValue()==2)
							continue;
						if(column.intValue()==3)
							column=1;
					}
					else
					{
						if(maxCol!=2)
						{
							if(column.intValue()==1 )
								continue;
							if(column.intValue()==2)
								column=1;
						}


					}
				}
				Collections.sort(chunks);
				String colVal = "" ;
				String coOrds = "";
				if(chunks!=null)
				{
					Float x1=0.0f,y1=0.0f,x2=0.0f,y2=0.0f;
					Integer pgNo = 0 ;
					for ( int i=0 ; i<chunks.size() ; i++ )
					{
						PDFChunk chunk = chunks.get(i) ;
						pgNo = chunk.getPageNo();
						if(i==0)
						{
							x1 = chunk.getX1();
							y1 = chunk.getY1();
						}
						if(i==(chunks.size()-1))
						{
							x2 = chunk.getX2();
							y2 = chunk.getY2();
						}

						String strChunk = chunk.getChunk() ;
						if ( strChunk.trim().equalsIgnoreCase("") )
							continue ;
						colVal = colVal.trim() + " " + strChunk  ;
					}

					coOrds = x1+","+y1+","+x2+","+y2+","+(pgNo+1);

					//System.out.println("corrds ---- "+coOrds );
				}

				if(negativeSign && isNumber(colVal))
				{
					colVal="-"+colVal.trim();
				}
				else
				{
					colVal = colVal.trim();
				}

				if(isNumber(colVal) && ( colVal.trim().startsWith("(") &&  !colVal.trim().endsWith(")")))
				{
					colVal = colVal+")";
				}

				if(isNumber(colVal) && ( !colVal.trim().startsWith("(") &&  colVal.trim().endsWith(")")))
				{
					colVal = "("+ colVal;
				}
				if(languagetoReplacefromDots.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && column>0)
				{
					String s ="";
					if(colVal.contains(","))
					{
						s = colVal.substring(0,colVal.indexOf(","));
						s = s.replaceAll("\\.",",");
						String s1 = colVal.substring(colVal.indexOf(",")+1); 
						colVal = s+"."+s1;
					}
					else
					{
						colVal = colVal.replaceAll("\\.",",");
					}
				}
				if(colVal.equalsIgnoreCase("Inventario Final")||colVal.equalsIgnoreCase("perdida Cambiaria")||colVal.equalsIgnoreCase("Ingresos Por Partidas Discontinuas Y Extraordinarias") ||colVal.equalsIgnoreCase("Gastos Por Partidas Discontinuas Y Extraordinarias")||colVal.equalsIgnoreCase("Perdidas Acumuladas")|| colVal.equalsIgnoreCase("Perdida Del Ejercicio"))
					negativeSign = true;
				switch(column){
				case 0:
				{
					po.setAsRepLabel(colVal);
				}
				break;
				case 1:
				{
					po.setAsRepVal1(colVal);
					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue1("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue1((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue1(colVal);

					po.setVal1Coords(coOrds);
					break;
				}

				case 2:
				{
					po.setAsRepVal2(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue2("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue2((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue2(colVal);
					po.setVal2Coords(coOrds);

					break;
				}

				case 3:
				{
					po.setAsRepVal3(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue3("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue3((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue3(colVal);

					po.setVal3Coords(coOrds);

					break;
				}

				case 4:
				{
					po.setAsRepVal4(colVal);
					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue4("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue4((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue4(colVal);
					po.setVal4Coords(coOrds);

					break;
				}

				case 5:
				{
					po.setAsRepVal5(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue5("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue5((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue5(colVal);
					po.setVal5Coords(coOrds);

					break;
				}

				case 6:
				{
					po.setAsRepVal6(colVal);
					po.setVal6Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue6("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue6((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue6(colVal);
					break;
				}

				case 7:
				{
					po.setAsRepVal7(colVal);
					po.setVal7Coords(coOrds);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue7("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue7((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue7(colVal);
					break;
				}

				case 8:
				{
					po.setAsRepVal8(colVal);
					po.setVal8Coords(coOrds);

					if(isNumber(colVal))
					{
						po.setValue8(colVal.replaceAll(" ", ""));
					}
					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue8("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue8((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue8(colVal);
					break;
				}

				case 9:
				{
					po.setAsRepVal9(colVal);
					po.setVal9Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue9("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue9((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue9(colVal);
					break;
				}
				case 10:
				{
					po.setAsRepVal10(colVal);
					po.setVal10Coords(coOrds);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue10("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue10((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue10(colVal);
					break;
				}
				case 11:
				{
					po.setAsRepVal11(colVal);
					po.setVal11Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue11("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue11((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue11(colVal);
					break;
				}
				case 12:
				{
					po.setAsRepVal12(colVal);
					po.setVal12Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue12("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue12((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue12(colVal);
					break;
				}

				case 13:
				{
					po.setAsRepVal13(colVal);
					po.setVal13Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue13("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue13((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue13(colVal);
					break;
				}

				case 14:
				{
					po.setAsRepVal14(colVal);
					po.setVal14Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue14("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue14((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue14(colVal);
					break;
				}

				case 15:
				{
					po.setAsRepVal15(colVal);
					po.setVal15Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue15("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue15((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue15(colVal);
					break;
				}

				case 16:
				{
					po.setAsRepVal16(colVal);
					po.setVal16Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue16("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue16((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue16(colVal);
					break;
				}

				case 17:
				{
					po.setAsRepVal17(colVal);
					po.setVal17Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue17("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue17((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue17(colVal);
					break;
				}

				case 18:
				{
					po.setAsRepVal18(colVal);
					po.setVal18Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue18("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue18((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue18(colVal);
					break;
				}

				case 19:
				{
					po.setAsRepVal19(colVal);
					po.setVal19Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue19("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue19((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue19(colVal);
					break;
				}

				case 20:
				{
					po.setAsRepVal20(colVal);
					po.setVal20Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue20("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue20((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue20(colVal);
					break;
				}

				case 21:
				{
					po.setAsRepVal21(colVal);
					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue21("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue21((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue21(colVal);

					po.setVal21Coords(coOrds);
					break;
				}

				case 22:
				{
					po.setAsRepVal22(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue22((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue22(colVal);
					po.setVal22Coords(coOrds);

					break;
				}

				case 32:
				{
					po.setAsRepVal23(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue23("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue23((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
						else
							po.setValue23(colVal);

					po.setVal23Coords(coOrds);

					break;
				}

				case 24:
				{
					po.setAsRepVal24(colVal);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue24("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue24((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue24(colVal);
					po.setVal24Coords(coOrds);

					break;
				}

				case 25:
				{
					po.setAsRepVal25(colVal);
					po.setVal25Coords(coOrds);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue25("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue25((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue25(colVal);
					po.setVal25Coords(coOrds);

					break;
				}

				case 26:
				{
					po.setAsRepVal26(colVal);
					po.setVal26Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue22("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue26((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue26(colVal);
					break;
				}

				case 27:
				{
					po.setAsRepVal27(colVal);
					po.setVal27Coords(coOrds);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue27("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue27((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue27(colVal);
					break;
				}

				case 28:
				{
					po.setAsRepVal28(colVal);
					po.setVal28Coords(coOrds);

					if(isNumber(colVal))
					{
						po.setValue28(colVal.replaceAll(" ", ""));
					}
					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue28("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue28((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue28(colVal);
					break;
				}

				case 29:
				{
					po.setAsRepVal29(colVal);
					po.setVal29Coords(coOrds);


					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue29("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue29((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue29(colVal);
					break;
				}
				case 30:
				{
					po.setAsRepVal30(colVal);
					po.setVal30Coords(coOrds);

					if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && isNumber(colVal))
						po.setValue30("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
					else
						if(isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
							po.setValue30((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
						else
							po.setValue30(colVal);
					break;
				}
				}

			}

			if(poHeader!=null)
			{
				if(poHeader.getLineNo()>row.getId())
				{
					po.setPrevHeader("Y");
				}
			}
			else
				po.setPrevHeader("N");

			po.setType("ROW");
			po.setPageNo(pageNo);
			po.setRow(row);
			po.setSection(section);
			if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR") && section.equalsIgnoreCase("IS") && keyword.toString().toUpperCase().equalsIgnoreCase("ESTADO DE RESULTADOS"))
				po.setMaxCol(2);
			else
				po.setMaxCol(maxCol);
			po.setLineNo(row.getId());
			po.setLine(getLineFromRow(row.getLines()));
			po.setIsSplit(false);
			po.setPdfLine(row.getLines().get(row.getLines().size()-1));
			po.setSubSection(subSection);
			//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
			//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
			po.setBreakups("N");
			po.setTableID(instanceID);
			poObjects.add(po);
		}


		return poObjects;
	}

	/*private static String removeCurrency(String colVal) {
		for(String keywordCurrency:TimePeriodOntology.getCurrencyKeywords())
		{

			if(colVal.trim().startsWith(keywordCurrency.toLowerCase()))
			{
				colVal = colVal.replaceFirst(keywordCurrency, "").trim();
			}

			if(colVal.endsWith(keywordCurrency.toLowerCase()))
			{
				colVal = colVal.substring(0,colVal.indexOf(keywordCurrency)).trim();

			}
		}
		return 
	}
	 */

	private static String getLineFromRow(List<PDFLine> lines) {
		String lineStr = "";
		for(PDFLine line :lines)
		{
			lineStr = lineStr + " "+line.toString();
		}


		return lineStr.trim();
	}


	public static boolean isNumber(String val)
	{
		String number=stripUnwanted(val,"$,-()% ¥");
		try
		{
			Double.parseDouble(number);
			return true;
		}
		catch (NumberFormatException e)
		{
			return false;
		}
	}


	/** Strips UnWanted Characters 
	 * 
	 * @param sourceString
	 * @param unwantedCharSeq
	 * @return
	 */
	private static String stripUnwanted(String sourceString, String unwantedCharSeq)
	{
		String returnString="", tempString=sourceString;
		for (int s=0; s<unwantedCharSeq.length(); s++)
		{
			for (int k=0; k<tempString.length(); k++)
			{
				if (unwantedCharSeq.charAt(s)!=tempString.charAt(k))
					returnString += tempString.charAt(k);
			}
			tempString=returnString;
			returnString="";
		}
		returnString=tempString;
		return returnString;
	}




	private static boolean isTotalColumnSeperate(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap,int maxCol)
	{
		int totalRows = 0, countlastColumnValues=0;

		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;
			if(columnChunksMap!=null && columnChunksMap.size()==maxCol)
			{
				List<PDFChunk> chunks = columnChunksMap.get(maxCol-1) ;
				if(chunks!=null && !chunks.toString().equals("[]"))
					countlastColumnValues++;
			}
			totalRows++;
		}

		float percent = (countlastColumnValues * 1.0f) / totalRows  ;

		if ( percent <= 0.20 )
			return true ;

		return false;
	}


	private static boolean isTotalRow(String input)
	{
		for ( String keyword : TOTAL_KEYWORDS_CONTAINS )
		{
			if (input.toLowerCase().trim().contains(keyword.trim().toLowerCase()))
				return true ;
		}

		return false ;
	}


	public static int getMaxCol(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap,
			int maxCol) 
	{
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;
			if(maxCol<columnChunksMap.size())	
			{
				maxCol = columnChunksMap.size();
			}
		}
		return maxCol;
	}


	private static  void removeNumbersFromLabel(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap)
	{
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;

			List<PDFChunk> chunks = columnChunksMap.get(0) ;
			if(chunks==null)
				continue;

			for ( int i=0 ; i<chunks.size() ; i++ )
			{
				PDFChunk chunk = chunks.get(i) ;
				String strChunk = chunk.getChunk() ;
				if ( strChunk.trim().equalsIgnoreCase("") )
					continue ;
				//	strChunk = SectionsPREADER.IgnoreEnumeration(chunk.getChunk()).trim();


				if(strChunk.replaceAll("[�.0-9-$*]", "").trim().length()==0 )
				{
					chunks.remove(i);
					i--;
				}

				//	strChunk = strChunk.replaceAll("[�.0-9-$*]", "").trim();

				chunk.setChunk(strChunk);

			}
		}

	}
	private static void shifTotalRowLastColumn(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap,int maxCol)
	{
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;

			List<PDFChunk> chunks = columnChunksMap.get(0) ;
			if(chunks==null)
				continue;
			String strChunks = "" ;
			for ( int i=0 ; i<chunks.size() ; i++ )
			{
				PDFChunk chunk = chunks.get(i) ;
				String strChunk = chunk.getChunk() ;
				if ( strChunk.trim().equalsIgnoreCase("") )
					continue ;
				strChunks = strChunks.trim() + " " + strChunk  ;
			}

			if(strChunks.trim().equalsIgnoreCase(""))
				continue;

			if(isTotalRow(strChunks))
			{
				chunks = columnChunksMap.get(maxCol-1) ;
				if(chunks!=null && chunks.size()>0)
				{
					columnChunksMap.put(maxCol-2, chunks);
					columnChunksMap.remove(maxCol-1);
				}
			}

		}
	}



	/** * @param columns
	 * @param bounds
	 * @param headerRow
	 * @return 
	 *//*

	private static List<List<PDFWord>> getHeaderColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds,Row headerRow,HashMap<PDFWord,Row> wordRowsMap, HashMap<PDFChunk,Row> chunkRowsMap) 
	{
		List<PDFLine> lines = headerRow.getLines();
		List<List<PDFWord>> headerColumns = new ArrayList<List<PDFWord>>();
		for ( int j1=(lines.size()-1) ; j1>=0 ; j1-- )
		{
			PDFLine line = lines.get(j1);
			List<PDFChunk> chunks = line.getChunks();
			for ( int k=0 ; k<chunks.size() ; k++ )
			{
				boolean overlap = true;
				boolean found = false ;
				PDFChunk chunk = chunks.get(k);

				if(chunk.getChunk().trim().equalsIgnoreCase(""))
					continue;

				List<PDFWord> toBeSpreadedWords = chunk.getWords();
				for ( int i=0 ; i<bounds.size() ; i++ )
				{
					//List<PDFWord> column = columns.get(i) ;
					Pair<Float, Float> bound = bounds.get(i) ;
					float x11 = bound.getA().floatValue() ;
					float x12 = bound.getB().floatValue() ;

					found = false ;
					float x21 = chunk.getX1() ;
					float x22 = chunk.getX2() ;

					overlap = true ;

					if ( x12 < x21 || x11 > x22 )
						overlap = found ;

					if ( overlap )
					{
						chunkRowsMap.put(chunk,headerRow);
						if(headerColumns.size()<i)
						{
							for(int k1=0;k1<i;k1++)
							{
								headerColumns.add(null);
							}
						}
						headerColumns.add(i,chunk.getWords());
						float newX1 = x11 < x21 ? x11 : x21 ;
						float newX2 = x12 > x22 ? x12 : x22 ;

						Pair<Float, Float> newBounds = new Pair<Float, Float>(newX1, newX2) ;
						bounds.set(i, newBounds) ;

						found = true ;

						break ;
					}
				}

				if ( !overlap )
				{					
					for ( int j=0 ; j<toBeSpreadedWords.size() ; j++ )
					{
						PDFWord word = toBeSpreadedWords.get(j) ;
						wordRowsMap.put(word, headerRow) ;
						if(word.getWord().trim().equalsIgnoreCase(""))
							continue;
						float x31 = word.getX1() ;
						float x32 = word.getX2() ;
						found = false ;
						overlap = true ;
						for ( int k1=0 ; k1<bounds.size() ; k1++ )
						{
							Pair<Float, Float> bound1 = bounds.get(k1) ;
							float x41 = bound1.getA().floatValue() ;
							float x42 = bound1.getB().floatValue() ;

							overlap = true ;
							if ( x32 < x41 || x31 > x42 )
								overlap = found ;

							if ( !overlap )
								continue ;

							//columns.get(k1).add(0,word) ;
							if(headerColumns.size()<k1)
							{
								for(int i=0;i<k1;i++)
								{
									headerColumns.add(null);
								}
							}
							headerColumns.add(k1,chunk.getWords());

							float newX1 = x31 < x41 ? x31 : x41 ;
							float newX2 = x32 > x42 ? x32 : x42 ;

							Pair<Float, Float> newBounds = new Pair<Float, Float>(newX1, newX2) ;
							bounds.set(k1, newBounds) ;
							found = true ;
							break ;
						}

						if ( found )
							continue ;

							List<PDFWord> column1 = new ArrayList<PDFWord>() ;
						column1.add(word) ;
						columns.add(column1) ;

							Pair<Float, Float> bound1 = new Pair<Float, Float>(word.getX1(), word.getX2()) ;
						bounds.add(bound1) ;
					}
				}


			}
		}

		System.out.print("");
		return headerColumns;
	}


	  */
	public static boolean isSectionFalsePositive(List<Row> pageRows)
	{
		float count = 0.0f ;
		float total = 0.0f ;

		for ( Row row : pageRows )
		{
			total = total + 1.0f ;

			HashMap<DataType, List<PDFWord>> typeChunksMap = row.getTypeWordsMap() ;
			if ( !typeChunksMap.containsKey(DataType.NUMERIC_VALUE) || typeChunksMap.get(DataType.NUMERIC_VALUE).size() < 1 )
				continue ;

			count = count + 1.0f ;
		}

		float percent = count / total ;

		if ( percent <= 0.15 )
		{

			System.out.println(" Numeric Values found "+percent+"%");
			logger.info(" Numeric Values found "+percent+"%");

			return true ;
		}

		return false;
	}

	public static void printRowColumnChunks(TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> rowColumnChunksMap) 
	{
		logger.info("Printing Spreaded Table ... ") ;
		System.out.println("Printing Spreaded Table ... ") ;
		for ( Row row : rowColumnChunksMap.keySet() )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = rowColumnChunksMap.get(row) ;
			String colVal ="";
			//logger.info(row.getCombinedString()) ;
			for ( Integer column : columnChunksMap.keySet() )
			{
				List<PDFChunk> chunks = columnChunksMap.get(column) ;
				String strChunks = "" ;
				if(chunks!=null)
				{		

					for ( int i=0 ; i<chunks.size() ; i++ )
					{
						PDFChunk chunk = chunks.get(i) ;
						String strChunk = chunk.getChunk() ;
						if ( strChunk.trim().equalsIgnoreCase("") )
							continue ;

						strChunks = strChunks.trim() + " " + "'" + strChunk + "'" ;
					}
				}


				strChunks = strChunks.trim() ;

				colVal = colVal+("\t" + strChunks) ;
			}
			System.out.println(colVal);
			logger.info(colVal) ;
		}
	}

	public static TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> createRowColumnChunksMap(List<Row> pageRows, List<List<PDFChunk>> columns, HashMap<PDFChunk,Row> chunkRowsMap,List<Row> headerRows ) 
	{
		TreeMap<Row, TreeMap<Integer, List<PDFChunk>>> ret = new TreeMap<Row, TreeMap<Integer,List<PDFChunk>>>() ;
		/*boolean foundHeaderAtnextLine = false ;

	for ( int i=0 ; i<pageRows.size() ; i++ )
	{
		Row row = pageRows.get(i) ;

		if(headerRows!=null)
		{
			for( Row headerRow: headerRows)
			{
				if ( headerRow != null )
				{
					if ( row.equals(headerRow) && i>0 )
					{
						foundHeaderAtnextLine = true ;
						//foundHeaderAt = i;
						break; 
					}
				}
			}
			if(foundHeaderAtnextLine)
				break;
		}
	}*/
		for ( Row row : pageRows )
		{
			TreeMap<Integer, List<PDFChunk>> columnChunksMap = new TreeMap<Integer, List<PDFChunk>>() ;

			for ( int i=0 ; i<columns.size() ; i++ )
			{
				Integer columnID = i ;
				List<PDFChunk> column = columns.get(i) ;

				List<PDFChunk> columnChunks = new ArrayList<PDFChunk>() ;

				for ( int j=0 ; j<column.size() ; j++ )
				{
					PDFChunk chunk = column.get(j) ;
					Row chunkRow = chunkRowsMap.get(chunk) ;
					if(( chunkRow!=null &&  !chunkRow.equals(row)) || chunkRow==null)
						continue;

					if(PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
					{
						if (chunk.getChunk().equals("") ||( chunkRow ==null  && row!=null && (!isRowContainsChunk(chunk,row) || columnChunks.contains(chunk)))|| (chunkRow ==null  && row!=null && !isRowContainsChunk(chunk,row)  && columnID>0 && chunk.getChunk().replaceAll("[A-Za-z]", "").length()<chunk.getChunk().length()) || ( chunkRow!=null &&  !chunkRow.equals(row))) 
							continue ;
					}
					else
					{
						if (chunk.getChunk().equals("") ||(chunkRow ==null  && row!=null && !isRowContainsChunk(chunk,row))|| (chunkRow ==null  && row!=null && !isRowContainsChunk(chunk,row)  && columnID>0 && chunk.getChunk().replaceAll("[A-Za-z]", "").length()<chunk.getChunk().length()) || ( chunkRow!=null &&  !chunkRow.equals(row))) 
							continue ;
					}

					columnChunks.add(chunk) ;
				}

				columnChunksMap.put(columnID, columnChunks) ;
			}

			ret.put(row, columnChunksMap) ;
		}

		return ret ;
	}




	private static boolean isRowContainsChunk(PDFChunk chunk, Row row) {
		List<PDFLine> lines= row.getLines();
		for(int k=0;k<lines.size();k++)
		{
			List<PDFChunk> chunks = lines.get(k).getChunks();
			for(int l=0;l<chunks.size();l++)
			{
				if(chunks.get(l).getChunk().trim().equals(chunk.getChunk().trim()))
					return true;
			}
		}

		return false;
	}





	public static void spreadChunkColumns(List<Row> pageRows, List<List<PDFChunk>> chunkColumns, List<Pair<Float, Float>> chunkBounds, 
			HashMap<PDFChunk, Row> chunkRowsMap, HashMap<Row,List<List<PDFWord>>> headerMap, List<List<PDFWord>> numericColumns, List<Pair<Float,Float>> numericBounds, 
			HashMap<PDFWord,Row> wordRowsMap,List<Row> headerRows) 
	{
		float minYForNumericCols=0.0f;
		minYForNumericCols=getMaximumYForNumericColumns(numericColumns);
		List<List<PDFChunk>> prevNewColumns = createPreliminaryChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, headerMap,headerRows,minYForNumericCols) ;

		/*System.out.println("Preliminary Chunk Columns ... ") ;
		printChunkColumns(chunkColumns, chunkBounds) ;
		 */
		mergeChunkColumns(chunkColumns, chunkBounds) ;

		/*	System.out.println("1st d Chunk Columns ... ") ;
		printChunkColumns(chunkColumns, chunkBounds) ;*/

		List<List<PDFChunk>> finalChunkCols = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> finalBounds = new ArrayList<Pair<Float,Float>>() ;
		if(numericBounds!=null && numericColumns!=null)
		{
			createNumericChunkColumns(numericColumns, numericBounds, finalChunkCols, finalBounds, chunkRowsMap, wordRowsMap) ;
			//chunkColumns.addAll(numericChunkColumns) ;
			//chunkBounds.addAll(numericChunkBounds) ;
		}

		// Add all percentage value cols to numeric cols
		addAllPercentageColumnsInNumericCols(finalChunkCols,finalBounds,chunkBounds,chunkColumns);

		// Find all the cols from text cols which are not overlapping with numeric cols and add them in final cols
		List<List<PDFChunk>> remainingCols= new ArrayList<List<PDFChunk>>();
		List<Pair<Float, Float>> remainingBounds= new ArrayList<Pair<Float, Float>>(); 	
		addAllNonOverLappingNonNumericCols(finalChunkCols,finalBounds,chunkColumns,chunkBounds,remainingCols,remainingBounds);

		// merge cols overlapping with numeric in the best fit col from final cols 
		mergeOverLappingRemainingCols(remainingCols,remainingBounds,finalChunkCols,finalBounds,chunkRowsMap);

		// merge the notes column
		mergeNoteColumns(finalBounds,finalChunkCols,headerRows);

		chunkColumns.clear();
		chunkColumns.addAll(finalChunkCols);

		chunkBounds.clear();
		chunkBounds.addAll(finalBounds);
		//mergeColumnsBasedOnMeans(chunkColumns, chunkBounds) ;

		/*System.out.println("After merging other Columns with Numeric Columns ... ") ;
		printChunkColumns(chunkColumns, chunkBounds) ;*/

		sortChunkColumns(chunkColumns, chunkBounds) ;
		int totalCount = 0;
		for(List<PDFChunk> PDFChunks:chunkColumns)
		{
			int count = 0;
			for(int i=0;i<PDFChunks.size();i++)
			{
				PDFChunk chunk = PDFChunks.get(i);
				if(chunk!=null && chunk.getChunk()!=null && !chunk.getChunk().trim().equals(""))
				{
					count = count+1;
				}
			}
			if(count>totalCount)
				totalCount=count;

		}
		for(List<PDFChunk> prevPDFChunks:prevNewColumns)
		{
			for(PDFChunk prevChunk:prevPDFChunks)
			{
				Boolean added = false;

				for(List<PDFChunk> PDFChunks:chunkColumns)
				{
					int count = 0;
					for(int i=0;i<PDFChunks.size();i++)
					{
						PDFChunk chunk = PDFChunks.get(i);
						if(chunk!=null && chunk.getChunk()!=null && !chunk.getChunk().trim().equals(""))
						{
							count = count+1;
						}
					}
					if(((count*1.0)/totalCount)>0.80)
					{
						PDFChunks.add(prevChunk);
						added = true;
						break;
					}

				}
				if(added)
					break;
			}
		}

		cleanChunkColumns(chunkColumns, chunkBounds) ;
	}

	private static void addAllPercentageColumnsInNumericCols(List<List<PDFChunk>> finalChunkCols,
			List<Pair<Float, Float>> finalBounds, List<Pair<Float, Float>> chunkBounds,
			List<List<PDFChunk>> chunkColumns) 
	{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<chunkColumns.size() ; i++ )
		{
			Pair<Float, Float> bound = chunkBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = chunkColumns.get(i);
			if(chk.size()<1 ||  areAllChunksBlank(chk))
				continue;
			boolean isPercentageCol=isPercentageColumn(chk);
			boolean found = false ;
			if(isPercentageCol)
			{
				for ( int j=0 ; j<finalChunkCols.size() ; j++ )
				{
					Pair<Float, Float> newBound = finalBounds.get(j) ;
					float x21 = newBound.getA().floatValue() ;
					float x22 = newBound.getB().floatValue() ;

					float diff=100.0f;
					if(x12 < x21 )
					{
						diff=x21-x12;
					}
					else 
					{
						diff=x12-x21;
					}

					boolean overlap = true ;
					if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
						overlap = false ;

					if ( overlap || isCellContainsKeywords(chk.toString().trim())) //(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Spanish ITR") && isCellContainsKeywords(chk.toString().trim()/*.replaceAll("\\[", "").replaceAll("\\]", "")*/)))
					{
						List<PDFChunk> newColumn = finalChunkCols.get(j) ;
						newColumn.addAll(chunkColumns.get(i)) ;

						float newX1 = x11 < x21 ? x11 : x21 ;
						float newX2 = x12 > x22 ? x12 : x22 ;
						newBound = new Pair<Float, Float>(newX1, newX2) ;
						finalBounds.set(j, newBound) ;

						found = true ;
						break ;
					}
				}
			}
			if ( found )
				continue ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			newColumn.addAll(chunkColumns.get(i)) ;
			newColumns.add(newColumn) ;

			newBounds.add(new Pair<Float, Float>(x11, x12)) ;
		}

		chunkColumns.clear() ;
		chunkColumns.addAll(newColumns) ;

		chunkBounds.clear() ;
		chunkBounds.addAll(newBounds) ;

	}

	private static boolean isPercentageColumn(List<PDFChunk> chk) 
	{
		if(chk==null || chk.size()<1)
			return false;
		for(PDFChunk chunk:chk)
		{
			DataType dataType=DataTypeFinder.findDataType(chunk.getChunk().replaceAll("\\s+", ""));
			if(!dataType.equals(DataType.PERCENTAGE))
				return false;
		}
		return true;
	}

	private static void mergeNoteColumns(List<Pair<Float, Float>> finalBounds, List<List<PDFChunk>> finalChunkCols,
			List<Row> headerRows) 
	{
		Pair<Float,Float> noteColumnPair=findNoteColumnBounds(headerRows);
		if(noteColumnPair==null)
			return;
		float nx1=noteColumnPair.getA();
		float nx2=noteColumnPair.getB();
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<finalChunkCols.size() ; i++ )
		{
			Pair<Float, Float> bound = finalBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = finalChunkCols.get(i);
			if(chk.size()<1 ||  areAllChunksBlank(chk))
				continue;
			boolean found = false ;
			for ( int j=0 ; j<newColumns.size() ; j++ )
			{
				Pair<Float, Float> newBound = newBounds.get(j) ;
				float x21 = newBound.getA().floatValue() ;
				float x22 = newBound.getB().floatValue() ;

				float diff=100.0f;
				if(x12 < x21 )
				{
					diff=x21-x12;
				}
				else 
				{
					diff=x12-x21;
				}

				boolean overlap = true ;
				if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
					overlap = false ;
				if(!overlap && nx1<x12 && nx2>x11)
					overlap = true ;

				if ( overlap || isCellContainsKeywords(chk.toString().trim()))
				{
					if(nx1<x12 && nx2>x11)
					{
						List<PDFChunk> newColumn = newColumns.get(j) ;
						newColumn.addAll(finalChunkCols.get(i)) ;

						float newX1 = x11 < x21 ? x11 : x21 ;
						float newX2 = x12 > x22 ? x12 : x22 ;
						newBound = new Pair<Float, Float>(newX1, newX2) ;
						newBounds.set(j, newBound) ;

						found = true ;
						break ;
					}
				}
			}

			if ( found )
				continue ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			newColumn.addAll(finalChunkCols.get(i)) ;
			newColumns.add(newColumn) ;

			newBounds.add(new Pair<Float, Float>(x11, x12)) ;
		}

		finalChunkCols.clear() ;
		finalChunkCols.addAll(newColumns) ;

		finalBounds.clear() ;
		finalBounds.addAll(newBounds) ;

	}

	private static Pair<Float, Float> findNoteColumnBounds(List<Row> headerRows) 
	{
		if(headerRows==null || headerRows.size()<1)
			return null;
		for(Row row:headerRows)
		{
			List<PDFLine> rowLines=row.getLines();
			if(rowLines!=null && rowLines.size()>0)
			{
				for(PDFLine line:rowLines)
				{
					for(PDFChunk chunk:line.getChunks())
					{
						for(PDFWord word:chunk.getWords())
						{
							if(isHeaderContains(TimePeriodOntology.getNotesList(),(word.toString())))
							{
								return new Pair<Float,Float>(word.getX1(),word.getX2());
							}
						}

					}
				}
			}
		}
		return null;
	}

	public static void mergeOverLappingRemainingCols(List<List<PDFChunk>> chunkColumns,
			List<Pair<Float, Float>> chunkBounds, List<List<PDFChunk>> finalChunkCols,
			List<Pair<Float, Float>> finalBounds, HashMap<PDFChunk, Row> chunkRowsMap)
	{
		List<PDFChunk> leftOverChunks = new ArrayList<PDFChunk>() ; 

		for ( int i=0 ; i<chunkColumns.size() ; i++ )
		{
			Pair<Float, Float> bound = chunkBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = chunkColumns.get(i);
			if(chk.size()<1 ||  areAllChunksBlank(chk))
				continue;
			boolean found = false ;
			for ( int j=0 ; j<finalBounds.size() ; j++ )
			{
				Pair<Float, Float> newBound = finalBounds.get(j) ;
				float x21 = newBound.getA().floatValue() ;
				float x22 = newBound.getB().floatValue() ;

				float diff=100.0f;
				if(x12 < x21 )
				{
					diff=x21-x12;
				}
				else 
				{
					diff=x12-x21;
				}

				boolean overlap = true ;
				if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
					overlap = false ;

				if ( overlap || isCellContainsKeywords(chk.toString().trim())) //(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Spanish ITR") && isCellContainsKeywords(chk.toString().trim()/*.replaceAll("\\[", "").replaceAll("\\]", "")*/)))
				{
					List<PDFChunk> chunksToSpread=chunkColumns.get(i);
					for(PDFChunk chunk:chunksToSpread)
					{
						Row thisChunkRow=chunkRowsMap.get(chunk);
						List<PDFWord> notAddedWords = new ArrayList<PDFWord>(chunk.getWords()) ;
						for(PDFWord word:chunk.getWords())
						{
							// TODO ignore words
							DataType wordDataType=DataTypeFinder.findDataType(word.getWord());

							/*if(ignoreWords(word.getWord()))
							{
								notAddedWords.remove(word) ;
								continue;
							}*/
							for(String keyword : NumberDetector.getCURRENCY_KEYWORDS())
							{
								String wordString = word.getWord().trim();
								if(wordString.toLowerCase().equals(keyword.toLowerCase()))
								{
									continue;								
								}
							}
							if(ignoreWords(word.getWord()) || ((wordDataType!=null && !wordDataType.equals(DataType.NUMERIC_VALUE)) || (wordDataType!=null && !wordDataType.equals(DataType.CURRENCY))))
							{

								continue;
							}
							float wx1 = word.getX1() ;
							float wx2 = word.getX2();
							for ( int k=j ; k<finalBounds.size() ; k++ )
							{
								Pair<Float, Float> thisBound = finalBounds.get(k);
								float bx1 = thisBound.getA().floatValue() ;
								float bx2 = thisBound.getB().floatValue() ;
								if(wx2 > bx1 && wx1 < bx2 )
								{
									List<PDFWord> words= new ArrayList<PDFWord>();
									words.add(word);
									PDFChunk newChunk= new PDFChunk(word.getPageNo(),words );
									if(thisChunkRow!=null)
									{
										chunkRowsMap.put(newChunk, thisChunkRow);
									}
									finalChunkCols.get(k).add(newChunk);
									notAddedWords.remove(word) ;
									break;
								}
							}
						}

						if ( notAddedWords.size() == 0 )
							continue ;

						PDFChunk newChunk = new PDFChunk(notAddedWords.get(0).getPageNo(), notAddedWords) ;
						leftOverChunks.add(newChunk) ;
						chunkRowsMap.put(newChunk, thisChunkRow) ;
					}
					/*finalChunkCols.get(j).addAll(chunkColumns.get(i)) ;*/
					found = true ;
					break ;
				}	
			}

			if ( found )
				continue ;
		}

		//System.out.println("Printing left-over ... ") ;
		for ( int i=0 ; i<leftOverChunks.size() ; i++ )
		{
			PDFChunk chunk = leftOverChunks.get(i) ;
			System.out.println("\t" + chunk) ;
		}

		List<List<PDFChunk>> leftColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> leftBounds = new ArrayList<Pair<Float,Float>>() ;
		simpleSpread(leftOverChunks, leftColumns, leftBounds) ;

		finalChunkCols.addAll(leftColumns) ;
		finalBounds.addAll(leftBounds) ;
	}

	private static void simpleSpread ( List<PDFChunk> allChunks, List<List<PDFChunk>> leftColumns,
			List<Pair<Float,Float>> leftBounds )
	{
		// System.out.println("Starting simple-spread ... ") ;

		for ( int i=0 ; i<allChunks.size() ; i++ )
		{
			PDFChunk chunk = allChunks.get(i) ;

			boolean found = false ;
			for ( int j=0 ; j<leftBounds.size() ; j++ )
			{
				Pair<Float, Float> bounds = leftBounds.get(j) ;

				boolean overlap = true ;
				if ( chunk.getX2() < bounds.getA().floatValue() || chunk.getX1() > bounds.getB().floatValue() )
					overlap = false ;

				if ( !overlap )
					continue ;

				found = true ;

				float newX1 = chunk.getX1() < bounds.getA().floatValue() ? chunk.getX1() : bounds.getA().floatValue() ;
				float newX2 = chunk.getX2() > bounds.getB().floatValue() ? chunk.getX2() : bounds.getB().floatValue() ;

				bounds = new Pair<Float, Float>(newX1, newX2) ;
				leftBounds.set(j, bounds) ;

				leftColumns.get(j).add(chunk) ;

				break ;
			}

			if ( found )
				continue ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			newColumn.add(chunk) ;
			Pair<Float, Float> newBounds = new Pair<Float, Float>(chunk.getX1(), chunk.getX2()) ;

			leftColumns.add(newColumn) ;
			leftBounds.add(newBounds) ;
		}

		reSpread(leftColumns, leftBounds) ;
	}

	private static void reSpread ( List<List<PDFChunk>> leftColumns, List<Pair<Float, Float>> leftBounds )
	{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<leftColumns.size() ; i++ )
		{
			Pair<Float, Float> thisBounds = leftBounds.get(i) ;

			boolean found = false ;
			for ( int j=0 ; j<newBounds.size() ; j++ )
			{
				Pair<Float, Float> newBound = newBounds.get(j) ;

				boolean overlap = true ;
				if ( thisBounds.getB().floatValue() < newBound.getA().floatValue() || thisBounds.getA().floatValue() > newBound.getB().floatValue() )
					overlap = false ;

				if ( !overlap )
					continue ;

				found = true ;

				List<PDFChunk> thisColumn = newColumns.get(j) ;
				thisColumn.addAll(leftColumns.get(i)) ;

				float newX1 = thisBounds.getA().floatValue() < newBound.getA().floatValue() ? thisBounds.getA().floatValue() : newBound.getA().floatValue() ;
				float newX2 = thisBounds.getB().floatValue() > newBound.getB().floatValue() ? thisBounds.getB().floatValue() : newBound.getB().floatValue() ;
				newBound = new Pair<Float, Float>(newX1, newX2) ;
				newBounds.set(j, newBound) ;

				break ;
			}

			if ( found )
				continue ;

			newColumns.add(new ArrayList<PDFChunk>(leftColumns.get(i))) ;
			newBounds.add(leftBounds.get(i)) ;
		}
	}

	/*private static void mergeOverLappingRemainingCols(List<List<PDFChunk>> chunkColumns,
			List<Pair<Float, Float>> chunkBounds, List<List<PDFChunk>> finalChunkCols,
			List<Pair<Float, Float>> finalBounds, HashMap<PDFChunk, Row> chunkRowsMap) 
	{
		for ( int i=0 ; i<chunkColumns.size() ; i++ )
		{
			Pair<Float, Float> bound = chunkBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = chunkColumns.get(i);
			boolean found = false ;
			for ( int j=0 ; j<finalBounds.size() ; j++ )
			{
				Pair<Float, Float> newBound = finalBounds.get(j) ;
				float x21 = newBound.getA().floatValue() ;
				float x22 = newBound.getB().floatValue() ;

				float diff=100.0f;
				if(x12 < x21 )
				{
					diff=x21-x12;
				}
				else 
				{
					diff=x12-x21;
				}

				boolean overlap = true ;
				if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
					overlap = false ;

				if ( overlap || isCellContainsKeywords(chk.toString().trim()))
				{
					List<PDFChunk> chunksToSpread=chunkColumns.get(i);
					for(PDFChunk chunk:chunksToSpread)
					{
						Row thisChunkRow=chunkRowsMap.get(chunk);
						for(PDFWord word:chunk.getWords())
						{
							// TODO ignore words
							if(ignoreWords(word.getWord()))
								continue;
							float wx1 = word.getX1() ;
							float wx2 = word.getX2();
							for ( int k=j ; k<finalBounds.size() ; k++ )
							{
								Pair<Float, Float> thisBound = finalBounds.get(k);
								float bx1 = thisBound.getA().floatValue() ;
								float bx2 = thisBound.getB().floatValue() ;
								if(wx2 > bx1 && wx1 < bx2 )
								{
									List<PDFWord> words= new ArrayList<PDFWord>();
									words.add(word);
									PDFChunk newChunk= new PDFChunk(word.getPageNo(),words );
									if(thisChunkRow!=null)
									{
										chunkRowsMap.put(newChunk, thisChunkRow);
									}
									finalChunkCols.get(k).add(newChunk);
									break;
								}
							}
						}
					}
					finalChunkCols.get(j).addAll(chunkColumns.get(i)) ;
					found = true ;
					break ;
				}	
			}

			if ( found )
				continue ;
		}
	}*/

	private static boolean ignoreWords(String word) 
	{
		if(word==null || word.trim().equals(""))
			return true;
		if(/*word.trim().equals("$") ||*/ word.trim().equals("-"))
			return true;
		return false;
	}

	private static void addAllNonOverLappingNonNumericCols(List<List<PDFChunk>> finalChunkCols,
			List<Pair<Float, Float>> finalBounds, List<List<PDFChunk>> chunkColumns,
			List<Pair<Float, Float>> chunkBounds, List<List<PDFChunk>> remainingCols, List<Pair<Float, Float>> remainingBounds) 
	{ 		
		for ( int i=0 ; i<chunkColumns.size() ; i++ )
		{
			Pair<Float, Float> bound = chunkBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = chunkColumns.get(i);
			if(chk.size()<1 ||  areAllChunksBlank(chk))
				continue;
			boolean found = false ;
			for ( int j=0 ; j<finalBounds.size() ; j++ )
			{
				Pair<Float, Float> newBound = finalBounds.get(j) ;
				float x21 = newBound.getA().floatValue() ;
				float x22 = newBound.getB().floatValue() ;

				float diff=100.0f;
				if(x12 < x21 )
				{
					diff=x21-x12;
				}
				else 
				{
					diff=x12-x21;
				}

				boolean overlap = true ;
				if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
					overlap = false ;

				if ( overlap || isCellContainsKeywords(chk.toString().trim())) //(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Spanish ITR") && isCellContainsKeywords(chk.toString().trim()/*.replaceAll("\\[", "").replaceAll("\\]", "")*/)))
				{
					List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
					newColumn.addAll(chunkColumns.get(i)) ;
					remainingCols.add(newColumn) ;
					remainingBounds.add(new Pair<Float, Float>(x11, x12)) ;
					found = true ;
					break ;
				}	
			}

			if ( found )
				continue ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			newColumn.addAll(chunkColumns.get(i)) ;
			finalChunkCols.add(newColumn) ;

			finalBounds.add(new Pair<Float, Float>(x11, x12)) ;
		}

	}

	private static boolean areAllChunksBlank(List<PDFChunk> chk) 
	{
		if(chk==null || chk.size()<1)
			return true;
		boolean isBlank=true;
		for(PDFChunk chunk:chk)
		{
			if(!chunk.getChunk().trim().equals(""))
				return false;
		}

		return isBlank;
	}

	private static float getMaximumYForNumericColumns(List<List<PDFWord>> numericColumns) {
		if(numericColumns!=null && numericColumns.size()>0)
		{
			float ret= 0.0f;
			for(List<PDFWord> wordList:numericColumns)
			{
				for(PDFWord word:wordList)
				{
					if(word.getY2()>ret)
						ret=word.getY2();
				}
			}
			return ret;
		}
		return 0;
	}

	private static void mergeColumnsBasedOnMeans(List<List<PDFChunk>> columns, List<Pair<Float, Float>> bounds)
	{
		List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>(columns) ;
		List<Pair<Float, Float>> chunkBounds = createMeanBounds(chunkColumns) ;//new ArrayList<Pair<Float,Float>>(bounds) ; // createMeanBounds(chunkColumns) ;

		mergeChunkColumns(chunkColumns, chunkBounds) ;

		columns.clear() ;
		columns.addAll(chunkColumns) ;

		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFChunk> column = columns.get(i) ;

			float x1 = Float.MAX_VALUE ;
			float x2 = Float.MIN_VALUE ;

			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFChunk chunk = column.get(j) ;
				x1 = x1 < chunk.getX1() ? x1 : chunk.getX1() ;
				x2 = x2 > chunk.getX2() ? x2 : chunk.getX2() ;
			}

			Pair<Float, Float> pair = new Pair<Float, Float>(x1, x2) ;
			newBounds.add(pair) ;
		}

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static List<Pair<Float, Float>> createMeanBounds(List<List<PDFChunk>> columns) 
	{
		List<Pair<Float, Float>> ret = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<columns.size() ; i++ )
		{
			float x1Sum = 0.0f ;
			float x1Count = 0.0f ;

			float x2Sum = 0.0f ;
			float x2Count = 0.0f ;

			List<PDFChunk> column = columns.get(i) ;

			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFChunk chunk = column.get(j) ;
				float x1 = chunk.getX1() ;
				float x2 = chunk.getX2() ;

				x1Sum = x1Sum + x1 ;
				x1Count = x1Count + 1.0f ;

				x2Sum = x2Sum + x2 ;
				x2Count = x2Count + 1.0f ;
			}

			float x1 = x1Sum / x1Count ;
			float x2 = x2Sum / x2Count ;

			Pair<Float, Float> newBound = new Pair<Float, Float>(x1, x2) ;
			ret.add(newBound) ;
		}

		return ret ;
	}

	private static void createNumericChunkColumns(List<List<PDFWord>> numericColumns, List<Pair<Float, Float>> numericBounds, 
			List<List<PDFChunk>> numericChunkColumns, List<Pair<Float, Float>> numericChunkBounds, HashMap<PDFChunk,Row> chunkRowsMap, 
			HashMap<PDFWord,Row> wordRowsMap) 
	{
		PDFWord prevWord  = null;
		for ( int i=0 ; i<numericColumns.size() ; i++ )
		{
			List<PDFWord> numericColumn = numericColumns.get(i) ;
			Pair<Float, Float> numericBound = numericBounds.get(i) ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			boolean found  = false;

			for ( int j=0 ; j<numericColumn.size() ; j++ )
			{
				PDFWord word = numericColumn.get(j) ;

				if(TimePeriodOntology.getNotesList()!=null)
				{
					found  = false;
					for(String keyword:TimePeriodOntology.getNotesList())
					{
						if(prevWord!=null && prevWord.getWord().toLowerCase().contains(keyword.toLowerCase()))
						{
							found = true;
							break;
						}
					}
					//label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
					//label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
					//	label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();
				}
				if((prevWord!=null && prevWord.getWord()!=null && (prevWord.getWord().toLowerCase().contains("note") || (TimePeriodOntology.getNotesList()!=null && TimePeriodOntology.getNotesList().contains(prevWord.getWord().toLowerCase()))) )|| found)
				{
					continue;
				}
				List<PDFWord> words = new ArrayList<PDFWord>() ;
				words.add(word) ;

				Row row = wordRowsMap.get(word) ;

				PDFChunk chunk = new PDFChunk(word.getPageNo(), words) ;
				newColumn.add(chunk) ;

				chunkRowsMap.put(chunk, row) ;
				prevWord = word;
			}

			numericChunkColumns.add(newColumn) ;
			numericChunkBounds.add(numericBound) ;
		}
	}


	private static boolean isCellContainsKeywords(String cell) {
		for ( String keyword : MERGE_KEYWORDS )
		{
			if ( DEBUG )
				System.out.println("\tChecking Keyword: " + keyword) ;

			//	int index = cell.toString().toLowerCase().equals(keyword.toLowerCase()) ;
			if ((cell.toString().replaceAll("\\[", "")).replaceAll("\\]", "").toLowerCase().trim().equals(keyword.toLowerCase().trim()))
			{
				if ( DEBUG )
					System.out.println("\t\tFound Keyword ..."+keyword) ;
				return true;
			}

		}
		return false;
	}
	private static void mergeChunkColumns(List<List<PDFChunk>> chunkColumns, List<Pair<Float, Float>> chunkBounds) 
	{		
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<chunkColumns.size() ; i++ )
		{
			Pair<Float, Float> bound = chunkBounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;
			List<PDFChunk> chk = chunkColumns.get(i);
			if(chk.size()<1 ||  areAllChunksBlank(chk))
				continue;
			boolean found = false ;
			for ( int j=0 ; j<newColumns.size() ; j++ )
			{
				Pair<Float, Float> newBound = newBounds.get(j) ;
				float x21 = newBound.getA().floatValue() ;
				float x22 = newBound.getB().floatValue() ;

				float diff=100.0f;
				if(x12 < x21 )
				{
					diff=x21-x12;
				}
				else 
				{
					diff=x12-x21;
				}

				boolean overlap = true ;
				if ( (x12 < x21 || x11 > x22) &&  diff>1.0f )
					overlap = false ;

				if(chk.toString().trim().equals("S") || chk.toString().trim().equals("$"))
					continue;
				if ( overlap || isCellContainsKeywords(chk.toString().trim())) //(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("Spanish ITR") && isCellContainsKeywords(chk.toString().trim()/*.replaceAll("\\[", "").replaceAll("\\]", "")*/)))
				{
					List<PDFChunk> newColumn = newColumns.get(j) ;
					newColumn.addAll(chunkColumns.get(i)) ;

					float newX1 = x11 < x21 ? x11 : x21 ;
					float newX2 = x12 > x22 ? x12 : x22 ;
					newBound = new Pair<Float, Float>(newX1, newX2) ;
					newBounds.set(j, newBound) ;

					found = true ;
					break ;
				}
			}

			if ( found )
				continue ;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
			newColumn.addAll(chunkColumns.get(i)) ;
			newColumns.add(newColumn) ;

			newBounds.add(new Pair<Float, Float>(x11, x12)) ;
		}

		chunkColumns.clear() ;
		chunkColumns.addAll(newColumns) ;

		chunkBounds.clear() ;
		chunkBounds.addAll(newBounds) ;
	}

	private static List<List<PDFChunk>> createPreliminaryChunkColumns(List<Row> pageRows, 
			List<List<PDFChunk>> chunkColumns, List<Pair<Float, Float>> chunkBounds, 
			HashMap<PDFChunk, Row> chunkRowsMap, HashMap<Row,List<List<PDFWord>>> headerMap,
			List<Row> headerRows, float minYForNumericCols) 
			{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;
		boolean foundHeaderAtnextLine = false ;
		List<PDFChunk> prevNewColumn = null ;
		List<List<PDFChunk>> prevNewColumns = new ArrayList<List<PDFChunk>>() ;
		int foundHeaderAt = 0;
		for ( int i=0 ; i<pageRows.size() ; i++ )
		{
			Row row = pageRows.get(i) ;

			if(headerRows!=null)
			{
				for( Row headerRow: headerRows)
				{
					if ( headerRow != null )
					{
						if ( row.equals(headerRow) && i>0 )
						{
							foundHeaderAtnextLine = true ;
							foundHeaderAt = i;
							break; 
						}
					}
				}
				if(foundHeaderAtnextLine)
					break;
			}
		}
		boolean foundHeader = false ;
		for ( int i=0 ; i<pageRows.size() ; i++ )
		{
			Row row = pageRows.get(i) ;
			foundHeader = false ;
			if(headerRows!=null)
			{
				for( Row headerRow: headerRows)
				{
					if ( headerRow != null )
					{
						if ( row.equals(headerRow) )
						{
							foundHeader = true ;
							row.setHeaderRow(foundHeader);
							break; 
						}

						if ( !foundHeader )
						{
							continue ;
						}
					}
				}

				if(foundHeader)
					continue;
			}

			HashMap<PDFWord, DataType> wordTypeMap = createWordTypeMap(row.getTypeWordsMap(), 
					new DataType[] {DataType.NUMERIC_VALUE}) ;

			List<PDFLine> lines = row.getModifiedLines() ;

			//PDFLine prevLine = null ;
			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;
				if(FinancialStatementExtractor.getLanguage().trim().equals(""))
				{
					if(line.toString().toLowerCase().contains("page ") )
						continue;
				}
				if(FinancialStatementExtractor.getLanguage().contains("Spanish ITR"))
				{
					if(line.toString().toLowerCase().contains("hoja ") || line.getLine().contains("ACTIVO CAPITAL CONTABLE"))
						continue;
				}

				if(line.isTableID())
				{
					if(!FinancialStatementExtractor.getLanguage().contains("ITR"))
					{
						prevNewColumn = new ArrayList<PDFChunk>() ;
						prevNewColumn.addAll(chunks) ;
						prevNewColumns.add(prevNewColumn);
						continue;
					}
					else{
						prevNewColumn = new ArrayList<PDFChunk>() ;
						int ct=0;
						for(PDFChunk chnk: chunks)
						{
							if(ct>0)
							{
								chunks.get(0).setChunk(chunks.get(0) + " "+chnk.getChunk());
							}
							chunks.get(0).setX2(chunks.get(chunks.size()-1).getX2());
							ct++;
						}

					}
					prevNewColumn.add(chunks.get(0));
					prevNewColumns.add(prevNewColumn);


					continue;
				}
				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;

					if(chunk.getChunk().trim().equalsIgnoreCase("$")  || chunk.getChunk().trim().equalsIgnoreCase("(") || chunk.getChunk().trim().equalsIgnoreCase(")"))
						continue;


					if(chunk.getChunk().trim().equalsIgnoreCase("-") || chunk.getChunk().trim().equalsIgnoreCase("-") /*|| chunk.getChunk().trim().equals("ACTIVO") ||  chunk.getChunk().trim().equals("PASIVO")*/)
					{
						continue;
					}
					List<PDFWord> words = chunk.getWords() ;

					if(foundHeaderAtnextLine && foundHeaderAt>i && foundHeaderAt < 10)
					{
						prevNewColumn = new ArrayList<PDFChunk>() ;
						prevNewColumn.add(chunk) ;
						/*if(prevLine!=null && line!=null && line.equals(prevLine) )
						prevNewColumns.add(prevNewColumn);
					else*/
						prevNewColumns.add(prevNewColumn);

					}
					else
					{

						if ( words.size() == 1 )
						{
							PDFWord word = words.get(0) ;

							if ( wordTypeMap.containsKey(word) )
								continue ;
						}

						chunkRowsMap.put(chunk, row) ;

						float x11 = chunk.getX1() ;
						float x12 = chunk.getX2() ;

						boolean found = false ;
						for ( int l=0 ; l<newColumns.size() ; l++ )
						{
							Pair<Float, Float> bounds = newBounds.get(l) ;
							float x21 = bounds.getA().floatValue() ;
							float x22 = bounds.getB().floatValue() ;

							boolean overlap = true ;
							if ( x12 < x21 || x11 > x22 )
								overlap = false ;

							if ( overlap )
							{
								List<PDFChunk> column = newColumns.get(l) ;
								column.add(chunk) ;

								found = true ;

								if(chunk.getY1()>minYForNumericCols)
								{

								}
								else
								{
									float newX1 = x21 < x11 ? x21 : x11 ;
									float newX2 = x22 > x12 ? x22 : x12 ;
									Pair<Float, Float> newBound = new Pair<Float, Float>(newX1, newX2) ;
									newBounds.set(l, newBound) ;
								}

								break ;
							}
						}

						if ( found )
							continue ;

						List<PDFChunk> newColumn = new ArrayList<PDFChunk>() ;
						newColumn.add(chunk) ;
						newColumns.add(newColumn) ;

						Pair<Float, Float> newBound = new Pair<Float, Float>(chunk.getX1(), chunk.getX2()) ;
						newBounds.add(newBound) ;
					}
					//prevLine = line;
				}
			}
		}

		chunkColumns.clear() ;
		/*
	for(List<PDFChunk> prevPDFChunks:prevNewColumns)
	{
		for(PDFChunk prevChunk:prevPDFChunks)
		{
			for(List<PDFChunk> PDFChunks:newColumns)
			{
				PDFChunks.add(0,prevChunk);
				break;

			}
		}
	}*/
		chunkColumns.addAll(newColumns) ;

		chunkBounds.clear() ;
		chunkBounds.addAll(newBounds) ;
		return prevNewColumns;
			}

	private static void reCreateChunks(List<Row> rows) 
	{

		//List<String> inLinebreakups = InlineBreakupMeta.getInlineBreakups();
		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;

			HashMap<DataType, List<PDFWord>> typeWordsMap = row.getTypeWordsMap() ;
			HashMap<PDFWord, DataType> wordTypeMap = createWordTypeMap(typeWordsMap, DataType.allTypes) ;

			List<PDFLine> lines = row.getModifiedLines() ;
			List<PDFLine> newLines = new ArrayList<PDFLine>() ;

			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;

				List<PDFChunk> chunks = line.getChunks() ;
				List<PDFChunk> newChunks = new ArrayList<PDFChunk>() ;

				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;
					List<PDFWord> words = chunk.getWords() ;
					List<List<PDFWord>> wordGroups = createWordGroupsBasedOnTypes(wordTypeMap, words) ;

					for ( int l=0 ; l<wordGroups.size() ; l++ )
					{
						List<PDFWord> thisGroup = wordGroups.get(l) ;
						PDFChunk newChunk = new PDFChunk(chunk.getPageNo(), thisGroup) ;
						newChunks.add(newChunk) ;
					}
				}

				PDFLine newLine = new PDFLine(j,line.getPageNo(), newChunks) ;
				newLine.setTableID(line.isTableID());
				newLine.setBlockNo(line.getBlockNo());
				newLines.add(newLine) ;
			}

			row.setModifiedLines(newLines) ;
		}
	}

	private static HashMap<PDFWord, DataType> createWordTypeMap(HashMap<DataType, List<PDFWord>> typeWordsMap, DataType[] validTypes) 
	{
		HashMap<PDFWord, DataType> wordTypeMap = new HashMap<PDFWord, DataType>() ;

		for ( DataType type : typeWordsMap.keySet() )
		{
			if ( !new ArrayList<DataType>(Arrays.asList(validTypes)).contains(type) )
				continue ;

			List<PDFWord> words = typeWordsMap.get(type) ;
			for ( int j=0 ; j<words.size() ; j++ )
			{
				PDFWord word = words.get(j) ;
				wordTypeMap.put(word, type) ;
			}
		}

		return wordTypeMap;
	}

	private static List<List<PDFWord>> createWordGroupsBasedOnTypes(HashMap<PDFWord, DataType> wordTypeMap, List<PDFWord> words) 
	{
		List<List<PDFWord>> wordGroups = new ArrayList<List<PDFWord>>() ;
		List<PDFWord> group = new ArrayList<PDFWord>() ;

		for ( int l=0 ; l<words.size() ; l++ )
		{
			PDFWord word = words.get(l) ;

			if ( wordTypeMap.containsKey(word) )
			{
				if ( group.size() != 0 )
				{
					wordGroups.add(new ArrayList<PDFWord>(group)) ;
					group.clear() ;
				}

				group.add(word) ;
				wordGroups.add(new ArrayList<PDFWord>(group)) ;
				group.clear() ;
				continue ;
			}

			group.add(word) ;
		}

		if ( group.size() != 0 )
			wordGroups.add(new ArrayList<PDFWord>(group)) ;
		return wordGroups;
	}

	@SuppressWarnings("unused")
	private static void printChunkColumns(List<List<PDFChunk>> columns, List<Pair<Float, Float>> bounds) 
	{
		logger.info("\n\n\n") ;
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFChunk> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			String strColumn = "" ;
			for ( int j=0 ; j<column.size() ; j++ )
				strColumn = strColumn + " ---- " + column.get(j).getWordSeparatedString() ;

			logger.info("Column " + i + " : " + bound + " : " + strColumn) ;
		}
	}

	public static void printNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds) 
	{
		logger.info("\n\n\n") ;
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			String strColumn = "" ;
			for ( int j=0 ; j<column.size() ; j++ )
				strColumn = strColumn + " ---- " + column.get(j).getWord() ;

			logger.info("Column " + i + " : " + bound + " : " + strColumn) ;
			System.out.println("Column " + i + " : " + bound + " : " + strColumn) ;
		}
	}

	public static TreeMap<Integer, List<Row>> createPageRowsMap(List<Row> rows) 
	{
		TreeMap<Integer, List<Row>> pageRowsMap = new TreeMap<Integer, List<Row>>() ;

		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;
			List<PDFLine> rowLines = row.getLines() ;
			PDFLine firstLine = rowLines.get(0) ;
			Integer pageNo = firstLine.getPageNo() ;

			List<Row> thisPageRows = pageRowsMap.containsKey(pageNo) ? pageRowsMap.get(pageNo) : new ArrayList<Row>() ;
			thisPageRows.add(row) ;
			pageRowsMap.put(pageNo, thisPageRows) ;
		}

		return pageRowsMap;
	}

	public static Pair<Float, Float> getSectionXBound(List<PDFLine> lines) 
	{
		float x1=Float.MAX_VALUE;
		float x2=Float.MIN_VALUE;
		for(PDFLine line:lines)
		{
			if(line.getX1()<x1)
				x1=line.getX1();
			if(line.getX2()>x2)
				x2=line.getX2();
		}
		return new Pair<Float, Float>(x1,x2);
	}

	public static void removeFalseNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds, HashMap<PDFWord,Row> wordRowsMap, List<Row> rows, Pair<Float, Float> sectionXBound) 
	{
		int minValuesInFalseColumns = 1 ;

		List<List<PDFWord>> newColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;
		//Added By Sanmati to remove junk columns
		int maxColSize = 0;
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			//Pair<Float, Float> bound = bounds.get(i) ;
			if(column!=null && column.size()>0)
			{
				if(maxColSize<column.size())
				{
					maxColSize = column.size();
				}
			}
		}
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			//Pair<Float, Float> bound = bounds.get(i) ;
			int count=0;
			if(column!=null && column.size()>0)
			{
				for(PDFWord word: column)
				{
					if(word.toString().trim().equals("S") || word.toString().trim().equals("$") || word.toString().trim().equals("5"))
					{
						++count;
					}
				}
				if(count == column.size() && column.size()*1.0/maxColSize<=0.25)
				{
					columns.remove(i);
				}
			}
		}
		//Added By Sanmati to remove junk columns
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			boolean isValid=true;
			if ( column.size()==1 )
			{
				PDFWord word=column.get(0);
				float x1=sectionXBound.getA();
				float x2=sectionXBound.getB();
				float temp=(((x2-x1)*5)/100)+x1;
				if(!(word.getX1()>temp))
				{
					isValid=false;
				}
			}

			if ( column.size() >= minValuesInFalseColumns && isValid)
			{
				newColumns.add(column) ;
				newBounds.add(bound) ;

				continue ;
			}

			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFWord word = column.get(j) ;

				Row row = wordRowsMap.remove(word) ;
				if ( row == null )
					continue ;

				HashMap<DataType, List<PDFWord>> typeWordsMap = row.getTypeWordsMap() ;
				for ( DataType type : typeWordsMap.keySet() )
				{
					List<PDFWord> thisTypeWords = typeWordsMap.get(type) ;
					thisTypeWords.remove(word) ;
				}

				row.setTypeWordsMap(typeWordsMap) ;
			}
		}

		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	/*private static Row pruneHeaderRows(List<Row> headerRows, List<Row> pageRows)
	{
		List<Boolean> containsNumericValues = new ArrayList<Boolean>() ;
		for ( int i=0 ; i<pageRows.size() ; i++ )
		{
			Row row = pageRows.get(i) ;
			HashMap<DataType, List<PDFWord>> typeWordsMap = row.getTypeWordsMap() ;
			if ( typeWordsMap.containsKey(DataType.NUMERIC_VALUE) && typeWordsMap.get(DataType.NUMERIC_VALUE).size() > 0 )
				containsNumericValues.add(Boolean.TRUE) ;
			else
				containsNumericValues.add(Boolean.FALSE) ;
		}

		List<Integer> indexes = new ArrayList<Integer>() ;
		for ( int i=0 ; i<headerRows.size() ; i++ )
		{
			Row headerRow = headerRows.get(i) ;

			if ( headerRow == null )
				continue ;

			Integer index = pageRows.indexOf(headerRow) ;
			indexes.add(index) ;
		}

		Integer[] arr = indexes.toArray(new Integer[indexes.size()]) ;
		Arrays.sort(arr) ;
		indexes = new ArrayList<Integer>(Arrays.asList(arr)) ;

		if ( indexes.size() == 1 )
		{
			int index = indexes.get(0) ;
			return pageRows.get(index) ;
		}

		Integer headerRowIndex = -1 ;
		for ( int i=indexes.size()-1 ; i>0 ; i-- )
		{
			Integer thisIndex = indexes.get(i) ;
			Integer nextIndex = indexes.get(i-1) ;

			if ( containsNumericValues.get(thisIndex.intValue()).booleanValue() )
				continue ;

			boolean invalid = false ;
			for ( int j=nextIndex.intValue()+1 ; j<thisIndex ; j++ )
			{
				if ( containsNumericValues.get(j).booleanValue() )
				{
					invalid = true ;
					break ;
				}
			}

			if ( invalid )
				continue ;

			headerRowIndex = thisIndex.intValue() ;

			//break ;
		}

		if ( headerRowIndex.intValue() == -1 )
			return null ;

		return pageRows.get(headerRowIndex.intValue()) ;
	}
	 */
	private static List<Row> findHeaderRowCandidatesFromNumericColumns(List<Row> pageRows, HashMap<PDFWord, Row> wordRowsMap, List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<Row> headerRows = new ArrayList<Row>() ;
		Pair<Float, Float> prevBound = null; 
		chunkBoundsCorrection(bounds);
		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			int minRowIndex = findMinRowIndex(pageRows, wordRowsMap, column) ;
			// System.out.println("Min Row Index = " + minRowIndex) ;
			if ( minRowIndex == -1 )
			{
				headerRows.add(null) ;
				continue ;
			}

			boolean found = false ;
			int minHeaderIndex = -1 ;
			//Float prevY = Float.MIN_VALUE;
			if(minRowIndex>15)
				continue;

			Integer prevBlockNo = -1;
			for ( int j=minRowIndex ; j>= 0 ; j-- )
			{
				Row row = pageRows.get(j) ;
				boolean foundRow =false;
				List<PDFLine> rowLines = row.getModifiedLines() ;

				if(row.getTypeWordsMap().containsKey(DataType.NUMERIC_VALUE) && row.getTypeWordsMap().get(DataType.NUMERIC_VALUE).size() != 0 )
					continue ;

				if ( rowContainsFalseHeaderKeywords(row) )
					continue ;

				for ( int k=0 ; k<rowLines.size() ; k++ )
				{
					PDFLine line = rowLines.get(k) ;
					//if((line!=null && prevBlockNo!=null && prevBlockNo>-1 && line.getBlockNo()!=null &&/* prevBlockNo!=line.getBlockNo() &&*/ headerRows!=null && headerRows.size()>0 ) || line.getLine().contains("(Note"))
					//if(line.getLine().contains("(Note"))
					//	break;

					Boolean foundNote = false;
					if(TimePeriodOntology.getNotesList()!=null)
					{
						for(String keyword:TimePeriodOntology.getNotesList())
						{
							if(line.getLine().toLowerCase().contains("("+keyword.toLowerCase()))
							{
								foundNote = true;
								break;
							}
							//label=label.toLowerCase().replaceAll("\\(note"+"(.*?)"+"\\)", "").trim();
							//label=label.toLowerCase().replaceAll("\\[note"+"(.*?)"+"\\]", "").trim();
							//	label=label.toLowerCase().replaceAll("\\(see "+"(.*?)"+"\\)", "").trim();
						}
						if(foundNote)
							break;
					}

					List<PDFWord> words = createWords(line) ;
					prevBlockNo = line.getBlockNo();
					for ( int l=0 ; l<words.size() ; l++ )
					{
						PDFWord word = words.get(l) ;
						if ( word.getWord().trim().equalsIgnoreCase(""))
							continue ;

						boolean overlap = true ;
						/*	if(prevBound !=null  &&  prevBound.getB()>word.getX1() && word.getX2() < bound.getA().floatValue() )
						{
						}
						else*/
						if ( (prevBound !=null && prevBound.getA()>word.getX2() && word.getX2() < bound.getA().floatValue()) 
								|| (prevBound==null && word.getX2() < bound.getA().floatValue()) || word.getX1() > bound.getB().floatValue() )
							overlap = false ;


						if ( overlap )
						{
							Row headerRow = pageRows.get(j) ;
							if(!headerRows.contains(headerRow))
							{
								found = true ;
								minHeaderIndex = j ;

								break ;
							}
						}

						if ( found )
							break ;
					}

					if ( found )
						break ;
				}

				if( foundRow )
					break;

				/*	if ( found )
				break ;*/
				if(found)
				{
					Row headerRow = pageRows.get(minHeaderIndex) ;
					if(!headerRows.contains(headerRow))
						headerRows.add(headerRow) ;
					/*else
						break;*/
				}


			}
			prevBound = bound;

			/*if ( !found )
			{
				headerRows.add(null) ;
				continue ;
			}*/

			/*Row headerRow = pageRows.get(minHeaderIndex) ;
			if(!headerRows.contains(headerRow))
				headerRows.add(headerRow) ;*/
		}
		return headerRows;
	}

	private static boolean rowContainsFalseHeaderKeywords(Row row)
	{
		List<PDFLine> lines = row.getModifiedLines() ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			if(line.isTableID())
				return true;
			/*List<PDFChunk> chunks = line.getChunks() ;
		for ( int j=0 ; j<chunks.size() ; j++ )
		{
			PDFChunk chunk = chunks.get(j) ;
			if ( chunk.getChunk().equalsIgnoreCase("$") )
				return true ;
		}*/
		}

		return false ;
	}

	private static List<PDFWord> createWords(PDFLine line) 
	{
		List<PDFWord> ret = new ArrayList<PDFWord>() ;

		for ( int i=0 ; i<line.getChunks().size() ; i++ )
			ret.addAll(line.getChunks().get(i).getWords()) ;

		return ret ;
	}

	private static int findMinRowIndex(List<Row> rows, HashMap<PDFWord, Row> wordRowsMap, List<PDFWord> column) 
	{
		int ret = Integer.MAX_VALUE ;

		boolean found = false ;
		for ( int i=0 ; i<column.size() ; i++ )
		{
			PDFWord word = column.get(i) ;
			Row row = wordRowsMap.get(word) ;
			// System.out.println("Row: " + row) ;
			int index = rows.indexOf(row) ;

			// System.out.println("\tIndex: " + index) ;

			if ( index == -1 )
				continue ;

			if ( index != -1 )
				found = true ;

			ret = ret < index ? ret : index ;
		}

		if ( !found )
			return -1 ;

		return ret ;
	}

	public static void removeFalsePositiveTypes(List<Row> rows)
	{
		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;
			List<PDFLine> lines = row.getModifiedLines() ;
			HashMap<DataType, List<PDFWord>> typeWordsMap = row.getTypeWordsMap() ;
			HashMap<PDFWord, DataType> wordTypeMap = createWordTypeMap(typeWordsMap, DataType.allTypes) ;

			List<PDFWord> toBeRemovedWords = new ArrayList<PDFWord>() ;

			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;
				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;
					List<PDFWord> words = chunk.getWords() ;

					for ( int l=1 ; l<words.size()-1 ; l++ )
					{
						PDFWord prevWord = words.get(l-1) ;
						PDFWord thisWord = words.get(l) ;
						PDFWord nextWord = words.get(l+1) ;

						if ( wordTypeMap.containsKey(thisWord) && !wordTypeMap.containsKey(prevWord) && !wordTypeMap.containsKey(nextWord) )
							toBeRemovedWords.add(thisWord) ;
					}
				}
			}

			for ( int j=0 ; j<toBeRemovedWords.size() ; j++ )
			{
				PDFWord word = toBeRemovedWords.get(j) ;
				DataType type = wordTypeMap.get(word) ;
				typeWordsMap.get(type).remove(word) ;
			}

			row.setTypeWordsMap(typeWordsMap) ;
		}
	}



	public static void reCreateRowLines(List<Row> rows) 
	{
		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;
			List<PDFLine> lines = row.getLines() ;

			List<PDFLine> newLines = new ArrayList<PDFLine>() ;
			HashMap<DataType, List<PDFWord>> typeWordsMap = new HashMap<DataType, List<PDFWord>>() ;
			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;
				List<PDFChunk> newChunks = new ArrayList<PDFChunk>() ;
				PDFChunk prevChunk = null;
				chunks=combineChunks(chunks);
				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;

					// System.out.println("\n\nThis Chunk: " + chunk.getChunk()) ;
					PDFWord prevWord = null;

					List<PDFWord> words = chunk.getWords() ;
					List<PDFWord> newWords = new ArrayList<PDFWord>() ;
					DataType prevType = null;


					for ( int l=0 ; l<words.size() ; l++ )
					{
						PDFWord word = words.get(l) ;
						if ( word.getWord().trim().equalsIgnoreCase("") )
							continue ;

						// System.out.println("\tWord: " + word.getWord() + " : L=" + l) ;

						int typedNGramSize = -1 ;
						DataType nGramType = null ;
						PDFWord newWord = null ;
						boolean found = false ;

						HashSet<String> doneStrings = new HashSet<String>() ;
						List<PDFWord> wordsToAdd =null;
						for ( int m=l ; m<words.size() ; m++ )
						{
							int nGramSize = words.size()-m ;
							// System.out.println("\t\tN-Gram Size = " + nGramSize) ;

							List<PDFWord> nGram = compute3Grams(word, words, nGramSize) ;
							String strNGram = comvertWordsToString(nGram) ;
							if ( doneStrings.contains(strNGram) )
								continue ;

							doneStrings.add(strNGram) ;

							// System.out.println("\t\t\tN-Gram String: " + strNGram) ;

							DataType type = DataTypeFinder.findDataType(strNGram) ;


							if(prevWord!=null && prevWord.getWord().trim().contains("(Note") && word!=null && word.getWord().trim().endsWith(")") && containsNote(prevWord.getWord()))
							{
								type = DataType.TEXT;
							}
							if(prevChunk!=null && prevChunk.getChunk().trim().contains("(Note") && chunk!=null && chunk.getChunk().trim().endsWith(")") &&  prevWord!=null && containsNote(prevWord.getWord()))
							{
								type = DataType.TEXT;
							}
							if(prevType!=null && !type.equals(DataType.TEXT))
							{
								continue;
							}
							prevWord = word;

							prevType = type;


							if ( !type.equals(DataType.TEXT) && !type.equals(DataType.NUMERIC_VALUE) )
							{
								// System.out.println("\t\t\t\tFound: " + type.toString()) ;
								newWord = mergeWords(nGram) ;
								typedNGramSize = nGramSize ;
								found = true ;
								nGramType = type ;
								break ;
							}
							else if (type.equals(DataType.NUMERIC_VALUE))
							{
								wordsToAdd=nGram;
								typedNGramSize = nGramSize ;
								found = true ;
								nGramType = type ;
								break ;
							}
						}
						prevChunk = chunk;

						if ( found )
						{
							l = l+typedNGramSize-1 ;
							// System.out.println("\t\t\t\tSetting L=" + l) ;
							List<PDFWord> thisTypeWords = typeWordsMap.containsKey(nGramType) ? typeWordsMap.get(nGramType) : new ArrayList<PDFWord>() ;

							if(newWord==null && nGramType!=null && nGramType.equals(DataType.NUMERIC_VALUE))
							{
								List<PDFWord> nWords=getNumericWords(wordsToAdd);
								newWords.addAll(nWords);
								if(nWords!=null && nWords.size()>0)
									thisTypeWords.addAll(nWords);
								wordsToAdd=null;
							}
							else
							{
								newWords.add(newWord) ;
								thisTypeWords.add(newWord) ;
							}

							typeWordsMap.put(nGramType, thisTypeWords) ;

							continue ;
						}

						newWords.add(word) ;
					}

					PDFChunk newChunk = new PDFChunk(chunk.getPageNo(), newWords) ;
					// System.out.println("New Chunk: " + newChunk.getWordSeparatedString()) ;
					newChunks.add(newChunk) ;
				}

				PDFLine newLine = new PDFLine(j,line.getPageNo(), newChunks) ;
				newLine.setTableID(line.isTableID());
				newLine.setBlockNo(line.getBlockNo());
				newLines.add(newLine) ;
			}

			row.setModifiedLines(newLines) ;
			row.setTypeWordsMap(typeWordsMap) ;
		}
	}


	private static List<PDFWord> getNumericWords(List<PDFWord> wordsToAdd) 
	{
		List<PDFWord> ret= new ArrayList<PDFWord>();
		if(wordsToAdd==null || wordsToAdd.size()<1)
			return ret;
		for(PDFWord word:wordsToAdd)
		{
			DataType type = DataTypeFinder.findDataType(word.getWord().trim());
			if(type!=null && type.equals(DataType.NUMERIC_VALUE))
				ret.add(word);
		}
		return ret;
	}

	private static List<PDFChunk> combineChunks(List<PDFChunk> chunks) 
	{
		if(chunks==null || chunks.size()<1)
			return chunks;
		List<PDFChunk> ret= new ArrayList<PDFChunk>();
		for(int i=0;i<chunks.size();i++)
		{
			// range pattern match 1 - 3
			String toMatch="";
			DataType type=null;
			if((i+1)<chunks.size() && areChunksNear(chunks.get(i),chunks.get(i+1),null))
			{
				toMatch=chunks.get(i).getChunk().trim()+" "+chunks.get(i+1).getChunk().trim();
				type=DataTypeFinder.findDataType(toMatch);
			}

			if(type!=null && type.equals(DataType.RANGE))
			{
				List<PDFWord> wordlist= new ArrayList<PDFWord>();
				wordlist.addAll(chunks.get(i).getWords());
				wordlist.addAll(chunks.get(i+1).getWords());
				PDFChunk tempChunk= new PDFChunk(wordlist.get(0).getPageNo(), wordlist);
				ret.add(tempChunk);
				i++;
				continue;
			}

			if((i+2)<chunks.size() && areChunksNear(chunks.get(i),chunks.get(i+1),chunks.get(i+2)))
			{
				toMatch=chunks.get(i).getChunk().trim()+" "+chunks.get(i+1).getChunk().trim()+" "+chunks.get(i+2).getChunk().trim();
				type=DataTypeFinder.findDataType(toMatch);
			}

			if(type!=null && type.equals(DataType.RANGE))
			{
				List<PDFWord> wordlist= new ArrayList<PDFWord>();
				wordlist.addAll(chunks.get(i).getWords());
				wordlist.addAll(chunks.get(i+1).getWords());
				wordlist.addAll(chunks.get(i+2).getWords());
				PDFChunk tempChunk= new PDFChunk(wordlist.get(0).getPageNo(), wordlist);
				ret.add(tempChunk);
				i=i+2;
				continue;
			}
			ret.add(chunks.get(i));
		}
		return ret;
	}

	private static boolean areChunksNear(PDFChunk pdfChunk, PDFChunk pdfChunk2, PDFChunk pdfChunk3) 
	{
		if(pdfChunk==null || pdfChunk2==null)
			return false;
		List<PDFCharacter> charList= new ArrayList<PDFCharacter>();
		charList.addAll(getCharctersFromChunks(pdfChunk));
		charList.addAll(getCharctersFromChunks(pdfChunk2));
		float avgCharSize=computeAverageCharacterWidth(charList);
		float diff1=pdfChunk2.getX1()-pdfChunk.getX2();

		if(diff1<=(avgCharSize*2f))
		{
			if(pdfChunk3!=null)
			{
				float diff2=pdfChunk3.getX1()-pdfChunk2.getX2();
				if(diff2<=(avgCharSize*2f))
					return true;
			}
			else
				return true;
		}

		return false;
	}

	public static List<PDFCharacter> getCharctersFromChunks(PDFChunk chunk)
	{
		List<PDFCharacter> charList= new ArrayList<PDFCharacter>();
		if(chunk==null)
			return null;
		for(PDFWord word:chunk.getWords())
		{
			for(PDFCharacter character:word.getCharacters())
				charList.add(character);
		}
		return charList;
	}

	public static float computeAverageCharacterWidth(List<PDFCharacter> characterLine) 
	{
		float sum = 0.0f ;
		float count = 0.0f ;


		for ( int j=0 ; j<characterLine.size() ; j++ )
		{
			PDFCharacter character = characterLine.get(j) ;

			if ( character.getCharacter().trim().equalsIgnoreCase("") )
				continue ;

			float width = character.getX2() - character.getX1() ;

			sum = sum + width ;
			count = count + 1.0f ;
		}

		float average = count == 0.0f ? 0.0f : (sum/count) ;

		return average ;
	}

	private static Boolean containsNote(String word) {
		if(TimePeriodOntology.getNotesList()!=null)
		{
			for(String keyword:TimePeriodOntology.getNotesList())
			{
				if(word.toLowerCase().trim().contains("("+keyword.toLowerCase()))
					return true;
			}
		}
		return false;

	}

	private static PDFWord mergeWords(List<PDFWord> nGram)
	{
		List<PDFCharacter> newCharacters = new ArrayList<PDFCharacter>() ;


		for ( int i=0 ; i<nGram.size() ; i++ )
			newCharacters.addAll(nGram.get(i).getCharacters()) ;

		while ( newCharacters.get(0).getCharacter().trim().equalsIgnoreCase("") )
			newCharacters.remove(0) ;

		while ( newCharacters.get(newCharacters.size()-1).getCharacter().trim().equalsIgnoreCase("") )
			newCharacters.remove(newCharacters.size()-1) ;

		PDFWord word = new PDFWord(newCharacters.get(0).getPageNo(), newCharacters) ;

		return word ;
	}

	private static String comvertWordsToString(List<PDFWord> words) 
	{
		String ret = "" ;

		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			ret = ret.trim() + " " + word.getWord() ;
		}

		return ret.trim() ;
	}

	private static List<PDFWord> compute3Grams(PDFWord word, List<PDFWord> words, int n)
	{
		List<PDFWord> ret = new ArrayList<PDFWord>() ;

		int index = words.indexOf(word) ;

		for ( int i=0 ; i<words.size() && i<n ; i++ )
		{
			PDFWord thisWord = words.get(i+index) ;
			ret.add(thisWord) ;
		}

		return ret ;
	}

	public static void spreadColumnsForNumericValues(List<Row> rows, List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds, HashMap<PDFWord,Row> wordRowsMap) 
	{
		createPreliminaryNumericColumns(rows, columns, bounds, wordRowsMap) ;

		//recreateColumnsBoundsIgnoringSpecialSymbols(columns, bounds);

		mergePreliminaryNumericColumns(columns, bounds) ;

		sortNumericColumns(columns, bounds) ;

		cleanNumericColumns(columns, bounds) ;
	}

	private static void recreateColumnsBoundsIgnoringSpecialSymbols(List<List<PDFWord>> columns,
			List<Pair<Float, Float>> bounds) 
	{

		List<Pair<Float, Float>> finalBounds = new ArrayList<Pair<Float,Float>>() ;

		for(int i=0;i<columns.size();i++)
		{
			List<PDFWord> words=columns.get(i);
			boolean isWordFound=false;
			float x1=Float.MAX_VALUE;
			float x2=Float.MIN_VALUE;
			for(PDFWord word:words)
			{
				if(word.getWord()!=null && !word.getWord().trim().equals(""))
				{
					for(PDFCharacter character:word.getCharacters())
					{
						if(character.getCharacter().trim().equals("$"))
							continue;
						if(x1>character.getX1())
							x1=character.getX1();
						if(x2<character.getX2())
							x2=character.getX2();
						isWordFound=true;
					}
				}

			}
			if(isWordFound)
			{
				finalBounds.add(new Pair<Float,Float>(x1,x2));
			}
			else
			{
				columns.remove(i);
			}
		}



		bounds.clear() ;
		bounds.addAll(finalBounds) ;

	}

	private static void cleanChunkColumns(List<List<PDFChunk>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFChunk> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;


			String strColumn = "" ;
			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFChunk word = column.get(j) ;
				strColumn = strColumn.trim() + " " + word.getChunk() ;
			}
			if(strColumn.trim().replaceAll("[^0-9a-zA-Z-)(]", "").trim().equalsIgnoreCase("") && PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
			{
				continue ;
			}


			newColumns.add(column) ;
			newBounds.add(bound) ;
		}



		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static void cleanNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<List<PDFWord>> newColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<columns.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;

			String strColumn = "" ;
			for ( int j=0 ; j<column.size() ; j++ )
			{
				PDFWord word = column.get(j) ;
				strColumn = strColumn.trim() + " " + word.getWord() ;
			}

			if ( strColumn.trim().replaceAll("[^0-9a-zA-Z]", "").trim().equalsIgnoreCase("") )
				continue ;

			newColumns.add(column) ;
			newBounds.add(bound) ;
		}

		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static void sortChunkColumns(List<List<PDFChunk>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		// System.out.println("Bounds: " + bounds) ;

		TreeMap<Float, List<Pair<Float, Float>>> x1BoundsMap = new TreeMap<Float, List<Pair<Float,Float>>>() ;
		for ( int i=0 ; i<bounds.size() ; i++ )
		{
			Pair<Float, Float> bound = bounds.get(i) ;
			float x1 = bound.getA().floatValue() ;

			List<Pair<Float, Float>> thisX1Bounds = x1BoundsMap.containsKey(x1) ? x1BoundsMap.get(x1) : new ArrayList<Pair<Float,Float>>() ;
			thisX1Bounds.add(bound) ;
			x1BoundsMap.put(x1, thisX1Bounds) ;
		}

		// System.out.println("Bounds Map: " + x1BoundsMap) ;

		for ( Float x1 : x1BoundsMap.keySet() )
		{
			List<Pair<Float, Float>> thisX1Bounds = x1BoundsMap.get(x1) ;

			// System.out.println(x1 + " :::: " + thisX1Bounds) ;

			for ( int i=0 ; i<thisX1Bounds.size() ; i++ )
			{
				Pair<Float, Float> thisBound = thisX1Bounds.get(i) ;
				// System.out.println("\tThis Bound: " + thisBound) ;

				int index = bounds.indexOf(thisBound) ;
				List<PDFChunk> thisColumn = columns.get(index) ;

				newColumns.add(thisColumn) ;
				newBounds.add(thisBound) ;
			}
		}

		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static void sortNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<List<PDFWord>> newColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float,Float>>() ;

		TreeMap<Float, List<Pair<Float, Float>>> x1BoundsMap = new TreeMap<Float, List<Pair<Float,Float>>>() ;
		for ( int i=0 ; i<bounds.size() ; i++ )
		{
			Pair<Float, Float> bound = bounds.get(i) ;
			float x1 = bound.getA().floatValue() ;

			List<Pair<Float, Float>> thisX1Bounds = x1BoundsMap.containsKey(x1) ? x1BoundsMap.get(x1) : new ArrayList<Pair<Float,Float>>() ;
			thisX1Bounds.add(bound) ;
			x1BoundsMap.put(x1, thisX1Bounds) ;
		}

		for ( Float x1 : x1BoundsMap.keySet() )
		{
			List<Pair<Float, Float>> thisX1Bounds = x1BoundsMap.get(x1) ;
			for ( int i=0 ; i<thisX1Bounds.size() ; i++ )
			{
				Pair<Float, Float> thisBound = thisX1Bounds.get(i) ;

				int index = bounds.indexOf(thisBound) ;
				List<PDFWord> thisColumn = columns.get(index) ;

				newColumns.add(thisColumn) ;
				newBounds.add(thisBound) ;
			}
		}

		columns.clear() ;
		columns.addAll(newColumns) ;

		bounds.clear() ;
		bounds.addAll(newBounds) ;
	}

	private static void mergePreliminaryNumericColumns(List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds) 
	{
		List<List<PDFWord>> finalColumns = new ArrayList<List<PDFWord>>() ;
		List<Pair<Float, Float>> finalBounds = new ArrayList<Pair<Float,Float>>() ;

		for ( int i=0 ; i<bounds.size() ; i++ )
		{
			List<PDFWord> column = columns.get(i) ;
			Pair<Float, Float> bound = bounds.get(i) ;
			float x11 = bound.getA().floatValue() ;
			float x12 = bound.getB().floatValue() ;

			boolean found = false ;
			for ( int j=0 ; j<finalBounds.size() ; j++ )
			{
				Pair<Float, Float> finalBound = finalBounds.get(j) ;
				float x21 = finalBound.getA().floatValue() ;
				float x22 = finalBound.getB().floatValue() ;

				boolean overlap = true ;
				if ( x12 < x21 || x11 > x22 )
					overlap = found ;

				if ( !overlap )
					continue ;

				List<PDFWord> finalColumn = finalColumns.get(j) ;
				finalColumn.addAll(column) ;

				float newX1 = x11 < x21 ? x11 : x21 ;
				float newX2 = x12 > x22 ? x12 : x22 ;

				Pair<Float, Float> newPair = new Pair<Float, Float>(newX1, newX2) ;
				finalBounds.set(j, newPair) ;

				found = true ;

				break ;
			}

			if ( found )
				continue ;

			finalColumns.add(column) ;
			finalBounds.add(bound) ;
		}

		columns.clear() ;
		columns.addAll(finalColumns) ;

		bounds.clear() ;
		bounds.addAll(finalBounds) ;
	}




	private static void createPreliminaryNumericColumns(List<Row> rows, List<List<PDFWord>> columns, List<Pair<Float, Float>> bounds, HashMap<PDFWord,Row> wordRowsMap) 
	{
		boolean IDFound = false;
		Row prevRow= null;
		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;
			IDFound = false;
			for(PDFLine line:row.getLines())
			{
				if(line.isTableID())
				{
					IDFound = true;
				}
			}
			if(IDFound)
			{
				prevRow=row;
				continue;
			}

			List<PDFWord> toBeSpreadedWords = getToBeSpreadedWords(row) ;

			for ( int j=0 ; j<toBeSpreadedWords.size() ; j++ )
			{
				PDFWord word = toBeSpreadedWords.get(j) ;
				wordRowsMap.put(word, row) ;
				Pair<Float,Float> wordPair=getXPairForWordIgnoringSpecialCharacter(word);
				float x11 = wordPair.getA() ;
				float x12 = wordPair.getB() ;

				if(word.getWord().trim().equalsIgnoreCase("(") || word.getWord().trim().equalsIgnoreCase(")") || word.getWord().trim().equals("$") || word.getWord().trim().equals("-$"))
					continue;

				boolean found = false ;
				for ( int k=0 ; k<bounds.size() ; k++ )
				{
					Pair<Float, Float> bound = bounds.get(k) ;
					float x21 = bound.getA().floatValue() ;
					float x22 = bound.getB().floatValue() ;

					if(prevRow!=null)
					{
						PDFChunk overLapChunk=getOverlappingChunkFromPrevRow(prevRow,word);
						if(overLapChunk!=null)
						{
							if(containsRowMergeKeywords(overLapChunk))
							{
								System.out.println("Row merging condition match For word:: "+word);
								List<PDFWord> numericWords=row.getTypeWordsMap().containsKey(DataType.NUMERIC_VALUE) ? 
										row.getTypeWordsMap().get(DataType.NUMERIC_VALUE) : 
											new ArrayList<PDFWord>();
										if(numericWords!=null && numericWords.size()>0)
										{
											if(numericWords.contains(word))
											{
												row.getTypeWordsMap().get(DataType.NUMERIC_VALUE).remove(word);
												if(row.getTypeWordsMap().get(DataType.TEXT)!=null)
												{
													row.getTypeWordsMap().get(DataType.TEXT).add(word);
												}
												else
												{
													List<PDFWord> temp= new ArrayList<PDFWord>();
													temp.add(word);
													row.getTypeWordsMap().put(DataType.TEXT, temp);
												}
											}
										}
										found=true;
										break;
							}
						}
					}

					boolean overlap = true ;
					if ( x12 < x21 || x11 > x22 )
						overlap = found ;

					if ( !overlap )
						continue ;

					columns.get(k).add(word) ;

					float newX1 = x11 < x21 ? x11 : x21 ;
					float newX2 = x12 > x22 ? x12 : x22 ;

					Pair<Float, Float> newBounds = new Pair<Float, Float>(newX1, newX2) ;
					bounds.set(k, newBounds) ;

					found = true ;

					break ;
				}

				if ( found )
					continue ;

				List<PDFWord> column = new ArrayList<PDFWord>() ;
				column.add(word) ;
				columns.add(column) ;

				Pair<Float, Float> bound = new Pair<Float, Float>(x11, x12) ;
				bounds.add(bound) ;
			}
			prevRow=row;
		}
	}


	// TODO Remove unused code found by UCDetector
	// 	public static boolean isTImeperiodWord(Row row) {
	// 		for ( String keyword : TimePeriodOntology.getKeywords() )
	// 		{
	// 			// System.out.println("\t\tChecking TP Keyword: " + keyword) ;
	// 			if ( (row.getLines().toString().toLowerCase().contains(keyword) ))
	// 				return true ;
	// 			// System.out.println("\t\t\tNot Present ...") ;
	// 		}
	// 		return false;
	// 	}

	private static Pair<Float, Float> getXPairForWordIgnoringSpecialCharacter(PDFWord word) 
	{
		float x1=Float.MAX_VALUE;
		float x2=Float.MIN_VALUE;
		boolean isWordFound=false;
		for(PDFCharacter character:word.getCharacters())
		{
			if(character.getCharacter().trim().equals("$"))
				continue;
			if(x1>character.getX1())
				x1=character.getX1();
			if(x2<character.getX2())
				x2=character.getX2();
			isWordFound=true;
		}
		if(isWordFound)
		{
			return new Pair<Float,Float>(x1,x2);
		}
		else
			return new Pair<Float,Float>(word.getX1(),word.getX2());

	}

	private static PDFChunk getOverlappingChunkFromPrevRow(Row prevRow, PDFWord word) 
	{
		if(prevRow==null || word==null || prevRow.getLines()==null || prevRow.getLines().size()<1)
			return null;
		List<PDFLine> lines=prevRow.getLines();
		for(int i=(lines.size()-1);i>=0;i--)
		{
			PDFLine line=lines.get(i);
			for(PDFChunk chunk:line.getChunks())
			{
				float wx1=word.getX1();
				float wx2=word.getX2();
				float cx1=chunk.getX1();
				float cx2=chunk.getX2();
				if(wx1<cx2 && wx2>cx1)
					return chunk;
			}
		}
		return null;
	}

	private static boolean containsRowMergeKeywords(PDFChunk overLapChunk) 
	{
		if(overLapChunk==null || overLapChunk.getChunk()==null || overLapChunk.getChunk().trim().equals("") )
			return false;
		String text=overLapChunk.getChunk();
		if(text.trim().endsWith("and") || text.trim().endsWith("at"))
			return true;
		return false;
	}

	private static List<PDFWord> getToBeSpreadedWords(Row row) 
	{
		/*return row.getTypeWordsMap() == null ? 
				new ArrayList<PDFWord>() : 
					(row.getTypeWordsMap().containsKey(DataType.NUMERIC_VALUE) ? 
							row.getTypeWordsMap().get(DataType.NUMERIC_VALUE) : 
								new ArrayList<PDFWord>()) ;*/


		return row.getTypeWordsMap() == null ? 
				new ArrayList<PDFWord>() : 
					(row.getTypeWordsMap().containsKey(DataType.NUMERIC_VALUE) ? 
							row.getTypeWordsMap().get(DataType.NUMERIC_VALUE) : 
								new ArrayList<PDFWord>()) ;



	}

	public static List<Row> combineRowsByCase(List<Row> rows) 
	{

		List<List<Row>> rowGroups = new ArrayList<List<Row>>() ;

		List<Row> group = new ArrayList<Row>() ;
		PDFChunk lastChunk =  null;
		String lastLine = null;
		for ( int i=0 ; i<rows.size() ; i++ )
		{
			Row row = rows.get(i) ;

			PDFLine line = row.getLines().get(0) ;
			String strLine = line.getLine();//.replaceAll("\\(", "") ;
			String firstCharacter = strLine.substring(0, 1) ;
			CleanEnumeratedText cet = new CleanEnumeratedText();
			String strLineStr = cet.replaceEnums(strLine);
			/*if(strLineStr.trim().length()<strLine.trim().length())
				continue;*/
			if( strLineStr.trim().length()<strLine.trim().length() || strLine.trim().endsWith(":") || (strLine.trim().startsWith("-") && FinancialStatementExtractor.getLanguage().toLowerCase().equalsIgnoreCase("Italian")))
			{
			}
			else
				//if ((labelMergeLanguageList.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && (isLowercase(firstCharacter) && strLine.length()==strLine.replaceAll("[0-9-]", "").length())) || (!labelMergeLanguageList.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) && isLowercase(firstCharacter)) || (lastChunk!=null && lastChunk.getChunk().trim().endsWith(" and")) || (lastChunk!=null && lastChunk.getChunk().trim().endsWith(" for")) || (lastChunk!=null && lastChunk.getChunk().trim().endsWith(" of")))
				if ( (/*strLineStr.trim().length()==strLine.trim().length() && */
						((labelMergeLanguageList.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) 
								&& (isLowercase(firstCharacter) && strLineStr.length()==strLineStr.replaceAll("[0-9-]", "").length())) 
								|| (!labelMergeLanguageList.contains(FinancialStatementExtractor.getLanguage().toLowerCase()) 
										&& isLowercase(firstCharacter) && (lastLine!=null && lastLine.length()==lastLine.replaceAll("[0-9-]", "").length())) || (lastLine!=null && lastLine.trim().endsWith(" and")) 
										|| (lastLine!=null && lastLine.trim().endsWith(" for")) || (lastLine!=null 
										&& lastLine.trim().endsWith(" of")))) )
				{
					/*if(NumberDetector.isNumericValue(lastChunk.toString()))
				{
					strLine = firstCharacter.toUpperCase() + strLine.substring(1);
					PDFChunk firstChunk = line.getChunks().get(0);

					String FirstChunkStr = firstCharacter.toUpperCase()+firstChunk.getChunk().substring(1);
					firstChunk.setChunk(FirstChunkStr);
					line.setLine(strLine);
					continue;
				}*/
					group.add(row) ;

					lastLine = strLine;
					continue ;
				}

			lastLine = strLine;
			if ( group.size() != 0 )
			{
				rowGroups.add(new ArrayList<Row>(group)) ;
				group.clear() ;
			}

			group.add(row) ;
		}

		if ( group.size() != 0 )
			rowGroups.add(group) ;

		List<Row> newRows = new ArrayList<Row>() ;
		for ( int i=0 ; i<rowGroups.size() ; i++ )
		{
			List<PDFLine> lines = new ArrayList<PDFLine>() ;

			List<Row> thisGroup = rowGroups.get(i) ;
			for ( int j=0 ; j<thisGroup.size() ; j++ )
			{
				Row row = thisGroup.get(j) ;
				lines.addAll(row.getLines()) ;
			}

			Row row = new Row(i, lines) ;
			newRows.add(row) ;
		}

		return newRows ;
	}

	private static boolean isLowercase(String firstCharacter)
	{
		boolean isInteger = false ;
		try
		{
			Integer.parseInt(firstCharacter) ;
			isInteger = true ;
		}
		catch (Exception e)
		{
			isInteger = false ;
		}

		if ( isInteger )
			return false ;

		if ( firstCharacter.equals(firstCharacter.toUpperCase()) )
			return false ;

		return true ;
	}

	public static List<Row> createPreliminaryRows(List<PDFLine> lines) 
	{
		List<Row> rows = new ArrayList<Row>() ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;

			Row row = new Row(i, line) ;
			rows.add(row) ;
		}


		return rows ;
	}

	public static List<Row> createPreliminaryRowsbyPara(List<PDFLine> lines, List<PDFBlock> blocks) 
	{
		List<Row> rows = new ArrayList<Row>() ;

		for ( int j=0 ; j<blocks.size() ; j++ )
		{
			PDFBlock block = blocks.get(j);
			Row row = new Row(j, block) ;
			rows.add(row);

		}

		return rows ;
	}
	private static Map<Integer, List<Row>> seprateSideBySideColumnRows ( List<Row> pageRows )
	{
		Map<Integer,List<Row>> sectionRowsMap = new LinkedHashMap<Integer, List<Row>>();

		if(pageRows==null || pageRows.isEmpty() || pageRows.size()<2)
		{
			return sectionRowsMap;
		}

		try
		{
			HashMap<Row,List<List<PDFWord>>> headerMap = new HashMap<Row,List<List<PDFWord>>>();

			HashMap<PDFWord, Row> wordRowsMap = new HashMap<PDFWord, Row>() ;
			List<List<PDFWord>> numericColumns = new ArrayList<List<PDFWord>>() ;
			List<Pair<Float, Float>> numericBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadColumnsForNumericValues(pageRows, numericColumns, numericBounds, wordRowsMap) ;
			removeFalseNumericColumns(numericColumns, numericBounds, wordRowsMap, pageRows) ;
			printNumericColumns(numericColumns, numericBounds) ;

			List<Row> headerCandidates = null;

			headerCandidates = findHeaderRowCandidatesFromNumericColumns(pageRows, wordRowsMap, numericColumns, numericBounds) ;

			HashMap<PDFChunk, Row> chunkRowsMap = new HashMap<PDFChunk, Row>() ;

			if(pageRows!=null)
				reCreateChunks(pageRows) ;

			List<List<PDFChunk>> chunkColumns = new ArrayList<List<PDFChunk>>() ;
			List<Pair<Float, Float>> chunkBounds = new ArrayList<Pair<Float,Float>>() ;
			spreadChunkColumns(pageRows, chunkColumns, chunkBounds, chunkRowsMap, headerMap, numericColumns, numericBounds, wordRowsMap,headerCandidates) ;

			/*if(chunkColumns.size()> 0 && !((chunkColumns.size()%2)==0))
			{
				return sectionRowsMap;
			}*/

			Map<Pair<Float, Float> , DataType> boundDatatypeMap = getBoundsDataTypeMap(chunkBounds,numericBounds,chunkColumns);

			float y2= getMaxY2OfHeaderColumns(headerCandidates);

			boundDatatypeMap = removeFalseColumn(boundDatatypeMap,chunkColumns,y2);

			if(boundDatatypeMap.size()> 0 && !((boundDatatypeMap.size()%2)==0))
			{
				return sectionRowsMap;
			}

			if(boundDatatypeMap.size()==2)
			{
				return sectionRowsMap;
			} 

			int size = boundDatatypeMap.size();
			int halfSize = size/2;

			List<DataType> dataTypelist = new ArrayList<DataType>();
			for(Pair<Float, Float> bound : boundDatatypeMap.keySet())
			{
				dataTypelist.add(boundDatatypeMap.get(bound));
			}

			boolean isValidBreak = isValidBreak(halfSize, dataTypelist);

			if(!isValidBreak)
				return sectionRowsMap;

			Pair<Float, Float> breakBounds = new Pair<Float, Float>(0.0f, 0.0f);
			Pair<Float, Float> breakBoundsNew = new Pair<Float, Float>(0.0f, 0.0f);
			int index = 0;
			for(Pair<Float, Float> bound : boundDatatypeMap.keySet())
			{

				if(index == halfSize-1)
					breakBoundsNew = bound;

				if(index == halfSize)
					breakBounds = bound;

				index++;
			}

			boolean considerFirst = false;
			if(breakBounds.getA() > breakBoundsNew.getB())
			{
				considerFirst = true;
			}


			List<Row> firstPart = new ArrayList<Row>();
			List<Row> secondPart = new ArrayList<Row>();

			int maxRows = pageRows.get(pageRows.size()-1).getId()+1;
			for(Row eachRow : pageRows)
			{
				List<PDFLine> line  = eachRow.getLines();

				List<PDFLine> firstLinePart = new ArrayList<PDFLine>();
				List<PDFLine> secondLinePart = new ArrayList<PDFLine>();
				List<PDFLine> firstLinePartModified = new ArrayList<PDFLine>();
				List<PDFLine> secondLinePartModified = new ArrayList<PDFLine>();

				breakLineInParts(breakBounds, line, firstLinePart, secondLinePart,breakBoundsNew,considerFirst);

				List<PDFLine> modifiedLines  = eachRow.getModifiedLines();

				breakLineInParts(breakBounds, modifiedLines, firstLinePartModified, secondLinePartModified,breakBoundsNew,considerFirst);

				HashMap<DataType, List<PDFWord>> typeWordMapFirst = new HashMap<DataType, List<PDFWord>>();
				HashMap<DataType, List<PDFWord>> typeWordMapSecond = new HashMap<DataType, List<PDFWord>>();

				HashMap<DataType, List<PDFWord>> typeWordMap = eachRow.getTypeWordsMap();

				breakTypeWordMap(breakBounds, typeWordMapFirst, typeWordMapSecond, typeWordMap,breakBoundsNew,considerFirst);

				if(!firstLinePart.isEmpty())
				{
					Row newRow = new Row(eachRow.getId(), firstLinePart);
					newRow.setTypeWordsMap(typeWordMapFirst);
					newRow.setModifiedLines(firstLinePartModified); //TODO
					firstPart.add(newRow);
				}

				if(!secondLinePart.isEmpty())
				{
					Row newRow1 = new Row(maxRows++, secondLinePart);
					newRow1.setTypeWordsMap(typeWordMapSecond);
					newRow1.setModifiedLines(secondLinePartModified); //TODO
					secondPart.add(newRow1);
				}
			}
			sectionRowsMap.put(1, firstPart);
			sectionRowsMap.put(2, secondPart);
		}
		catch (Exception e)
		{
			System.out.println("Exception occured while seprating side by side sections...");
			e.printStackTrace();

			sectionRowsMap.clear();
			return sectionRowsMap;
		}

		return sectionRowsMap;
	}

	private static void breakLineInParts ( Pair<Float, Float> breakBounds, List<PDFLine> lines,
			List<PDFLine> firstLinePart, List<PDFLine> secondLinePart, Pair<Float, Float> breakBoundsNew, boolean considerFirst )
	{
		for(PDFLine eachLine : lines)
		{
			List<PDFChunk> chunks = eachLine.getChunks();

			List<PDFChunk> firstChunkPart = new ArrayList<PDFChunk>();
			List<PDFChunk> secondChunkPart = new ArrayList<PDFChunk>();

			if(considerFirst)
			{
				for(PDFChunk chunk : chunks)
				{
					if(chunk.getX1()<breakBounds.getA())
					{
						firstChunkPart.add(chunk);
					}else
					{
						secondChunkPart.add(chunk);
					}
				}	
			}else
			{
				for(PDFChunk chunk : chunks)
				{
					if(chunk.getX1() < breakBoundsNew.getB())
					{
						firstChunkPart.add(chunk);
					}else
					{
						secondChunkPart.add(chunk);
					}
				}
			}


			if(!firstChunkPart.isEmpty())
			{
				PDFLine firstLine = new PDFLine(eachLine.getLineNo(), eachLine.getPageNo(), firstChunkPart);
				firstLinePart.add(firstLine);
			}

			if(!secondChunkPart.isEmpty())
			{
				PDFLine secondLine = new PDFLine(eachLine.getLineNo(), eachLine.getPageNo(), secondChunkPart);
				secondLinePart.add(secondLine);
			}
		}
	}

	private static float getMaxY2OfHeaderColumns ( List<Row> headerCandidates )
	{
		float maxY2 = 0.0f;
		for(Row row : headerCandidates)
		{
			for(PDFLine line : row.getLines())
			{
				if(line.getY2()>maxY2)
				{
					maxY2 = line.getY2();
				}
			}
		}
		return maxY2;
	}

	private static void breakTypeWordMap ( Pair<Float, Float> breakBounds,
			HashMap<DataType, List<PDFWord>> typeWordMapFirst, HashMap<DataType, List<PDFWord>> typeWordMapSecond,
			HashMap<DataType, List<PDFWord>> typeWordMap, Pair<Float, Float> breakBoundsNew, boolean considerFirst )
	{
		for(DataType map :typeWordMap.keySet())
		{
			List<PDFWord> words = typeWordMap.get(map);

			List<PDFWord> wrd1 =  new ArrayList<PDFWord>();
			List<PDFWord> wrd2 =  new ArrayList<PDFWord>();

			if(considerFirst)
			{
				for(PDFWord eachWord : words)
				{
					if(eachWord.getX1()<breakBounds.getA())
					{
						wrd1.add(eachWord);
					}else
					{
						wrd2.add(eachWord);
					}
				}
			}else
			{
				for(PDFWord eachWord : words)
				{
					if(eachWord.getX1()<breakBoundsNew.getB())
					{
						wrd1.add(eachWord);
					}else
					{
						wrd2.add(eachWord);
					}
				}
			}



			if(typeWordMapFirst.containsKey(map))
			{
				typeWordMapFirst.get(map).addAll(wrd1);
			}else
			{
				typeWordMapFirst.put(map, wrd1);
			}

			if(typeWordMapSecond.containsKey(map))
			{
				typeWordMapSecond.get(map).addAll(wrd2);;
			}else
			{
				typeWordMapSecond.put(map, wrd2);
			}				
		}
	}

	private static Map<Pair<Float, Float>, DataType> removeFalseColumn ( Map<Pair<Float, Float>, DataType> boundDatatypeMap,
			List<List<PDFChunk>> chunkColumns, float y2 )
			{
		List<List<PDFChunk>> chunkColumnsNew = new ArrayList<List<PDFChunk>>();
		boundDatatypeMap  = removeColumnAboveHeaderRow(y2,chunkColumns,boundDatatypeMap,chunkColumnsNew);

		Map<Pair<Float, Float> , DataType> boundDatatypeMapNew = new LinkedHashMap<Pair<Float,Float>, DataType>();

		int i=0;
		for(Pair<Float, Float> p : boundDatatypeMap.keySet())
		{
			DataType type = boundDatatypeMap.get(p);

			if(!type.equals(DataType.TEXT))
			{
				boundDatatypeMapNew.put(p, type);
				i++;
				continue;
			}

			List<PDFChunk> col=chunkColumnsNew.get(i);

			if(!(col!=null && col.size()<2))
			{
				boundDatatypeMapNew.put(p, type);
			}
			i++;
		}

		return boundDatatypeMapNew;
			}

	private static Map<Pair<Float, Float>, DataType> removeColumnAboveHeaderRow ( float y2, List<List<PDFChunk>> chunkColumns,
			Map<Pair<Float, Float>, DataType> boundDatatypeMap, List<List<PDFChunk>> chunkColumnsNew)
			{
		Map<Pair<Float, Float> , DataType> boundDatatypeMapNew = new LinkedHashMap<Pair<Float,Float>, DataType>();

		int counter = -1;
		for(Pair<Float, Float> key : boundDatatypeMap.keySet())
		{
			counter = counter+1;
			int count = 0;

			List<PDFChunk> col = chunkColumns.get(counter);

			for(PDFChunk ch : col)
			{
				if(!(ch.getY1()>y2))
				{
					count++;
				}
			}

			if(!(col.size()==count))
			{
				chunkColumnsNew.add(chunkColumns.get(counter));

				boundDatatypeMapNew.put(key, boundDatatypeMap.get(key));
			}
		}

		return boundDatatypeMapNew;

			}

	private static Map<Pair<Float, Float>, DataType> getBoundsDataTypeMap(
			List<Pair<Float, Float>> chunkBounds,
			List<Pair<Float, Float>> numericBounds,
			List<List<PDFChunk>> chunkColumns) {
		Map<Pair<Float, Float>, DataType> boundDatatypeMap = new LinkedHashMap<Pair<Float, Float>, DataType>();

		for (int i = 0; i < chunkBounds.size(); i++) {
			boolean found = false;

			for (Pair<Float, Float> nBound : numericBounds) {
				if (compareFloatNumbersInThreshold(chunkBounds.get(i), nBound,
						10.0f)) {
					boundDatatypeMap.put(chunkBounds.get(i), DataType.NUMBER);
					found = true;
					break;
				}
			}

			if (!found && isColumnContainsNumber(chunkColumns.get(i))) {
				boundDatatypeMap.put(chunkBounds.get(i), DataType.NUMBER);
				found = true;
			}

			if (!found)
				boundDatatypeMap.put(chunkBounds.get(i), DataType.TEXT);
		}
		return boundDatatypeMap;
	}

	private static boolean isColumnContainsNumber ( List<PDFChunk> chunkCol )
	{
		int numCount = 0;

		for(int i=0;i<chunkCol.size();i++)
		{
			PDFChunk col = chunkCol.get(i);

			List<PDFWord> words = col.getWords();

			for(PDFWord eachWord : words)
			{
				DataType type = DataTypeFinder.findDataType(eachWord.getWord().trim());

				if(type==DataType.NUMBER || type==DataType.NUMERIC_VALUE || type==DataType.PERCENTAGE)
				{
					numCount++;
					break;
				}
			}
		}

		int threshold  = (60*chunkCol.size())/100;

		if(numCount>=threshold)
			return true;

		return false;
	}

	public static boolean compareFloatNumbersInThreshold(Pair<Float,Float> a,Pair<Float,Float> b,float threshold)
	{
		boolean ret=false;
		if(a==null || b==null)
			return ret;

		float diff1=Math.abs(a.getA()-b.getA());
		float diff2=Math.abs(a.getB()-b.getB());

		if((diff1<=threshold ) && (diff2<=threshold ))
			ret=true;

		return ret;
	}

	private static boolean isValidBreak ( int halfSize, List<DataType> dataTypelist )
	{
		boolean isStartWithText = false;
		boolean isValidBreak = true;
		for(int i=0;i<dataTypelist.size();i++)
		{
			if(i==halfSize)
				break;

			if(i==0)
			{
				DataType str = dataTypelist.get(i);
				DataType str1 = dataTypelist.get(halfSize);

				if(str.equals(DataType.TEXT) && str1.equals(DataType.TEXT))
				{
					isStartWithText=true;
					continue;
				}
				isValidBreak = false;
				break;
			}

			if(isStartWithText)
			{
				if(!(dataTypelist.get(i).equals(dataTypelist.get(halfSize+i))))
				{
					isValidBreak = false;
					break;
				}
				/*				if(dataTypelist.get(i).equals(DataType.TEXT) || dataTypelist.get(halfSize+i).equals(DataType.TEXT))
				{
					isValidBreak = false;
					break;
				}*/
			}
		}
		return isValidBreak;
	}

}
