package com.rage.extraction.statements.ontology;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;


import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.RowSegmentationType;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;
import com.rage.extraction.statements.uitls.AccentsRemover;
import com.rage.extraction.statements.uitls.Utilities;

public class SectionOntology 
{
	private static List<MetaData> metaList;
	private static List<MetaData> metaSupplList;
	private static List<MetaData> footnotemetaList;
	private static Set<String> tokenKeywords ;

	
	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(SectionOntology.class);

	private static void init()
	{
		String fileName = "";
		if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
			fileName = "resource/section-identification/section-identification-flat.txt" ;
		else
			fileName = "resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/section-identification-flat.txt";
		try {
			new SafeFile(fileName);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(fileName);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}
		readKeywordsFromFile(fileName);
	}


	private static void readKeywordsFromFile(String fileName) 
	{
		BufferedReader br = null ;
		List<MetaData> mtList = new ArrayList<MetaData>();
		List<MetaData> supplMtList = new ArrayList<MetaData>();

		try
		{
			//br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));

			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;

				String[] split = line.toLowerCase().split("\t") ;
				/*if ( split.length != 2 )
					continue ;*/

				String section = split[0] ;
				String keywordExpression =  AccentsRemover.removeAccents(split[1]) ;
				String noColumnsToSplitFrom = "0";
				String scope=null;
				String subSection=null;
				String parseValue=null;
				RowSegmentationType rowSegmentationType  =null;
				if(split.length >2)
				{
					if(split[2].trim()!=null || !split[2].trim().equalsIgnoreCase(""))
						rowSegmentationType = RowSegmentationType.valueOf(split[2].toUpperCase());
				}

				/*if(split.length >2)
					rowSegmentationType = RowSegmentationType.valueOf(split[2].toUpperCase());*/
				if(split.length >3)
					noColumnsToSplitFrom = split[3].trim();

				if(split.length >4)
				{
					scope = split[4].trim();
					if(scope.contains(","))
					{
						String[]  scopes= scope.split(",");
						scope=scopes[0].trim();
						parseValue=scopes[1].trim();
					}
				}

				if(split.length >5)
					subSection = split[5].trim();

				List<String> tokens =  Utilities.tokenize(keywordExpression.toLowerCase(), true) ;
				if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("") || FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase("English"))
				{
					try {
						if(tokens!=null)
						{
							for(int i=0;i<tokens.size();i++){
								String token =tokens.get(i);
								if(token==null)
									continue;
								if(token.trim().equals("of") || token.trim().equals("and") || token.trim().equals("in") || token.trim().equals(""))
								{
									tokens.remove(i);
									--i;
								}
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				if(scope==null && subSection==null)
				{
					MetaData md = new MetaData(section,tokens,rowSegmentationType,noColumnsToSplitFrom,scope,subSection,keywordExpression,parseValue);
					mtList.add(md);
				}
				else
				{
					MetaData md = new MetaData(section,tokens,rowSegmentationType,noColumnsToSplitFrom,scope,subSection,keywordExpression,parseValue);
					supplMtList.add(md);
				}
			}
			Collections.sort(mtList);
			Collections.sort(supplMtList);
			setMetaList(mtList);
			setMetaSupplList(supplMtList);

		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		//Collections.sort(mtList);

	}




	public static void setMetaSupplList(List<MetaData> metaSupplList) {
		SectionOntology.metaSupplList = metaSupplList;
	}

	public static org.apache.log4j.Logger getLogger() {
		return logger;
	}

	private static List<List<String>> resolveExpression(String expression)
	{
		List<String> combinedTokens = new ArrayList<String>() ;
		String thisCombination = "" ;
		boolean escaped = false ;
		for ( int i=0 ; i<expression.length() ; i++ )
		{
			String character = expression.substring(i, i+1) ;
			if ( character.equalsIgnoreCase("\\") && !escaped )
			{
				escaped = true ;
				continue ;
			}

			if ( character.equalsIgnoreCase("(") && !escaped )
			{
				if ( !thisCombination.trim().equalsIgnoreCase("") )
				{
					combinedTokens.add(new String(thisCombination.trim())) ;
					thisCombination = "" ;
					continue ;
				}

				continue ;
			}

			if ( character.equalsIgnoreCase(")") && !escaped )
			{
				if ( !thisCombination.trim().equalsIgnoreCase("") )
				{
					combinedTokens.add(new String(thisCombination.trim())) ;
					thisCombination = "" ;
					continue ;
				}

				continue ;
			}

			thisCombination = thisCombination + character ;
		}

		// System.out.println("Combinations: " + combinedTokens) ;

		List<List<String>> individualTokens = new ArrayList<List<String>>() ;
		for ( int i=0 ; i<combinedTokens.size() ; i++ )
		{
			String thisCombinedToken = combinedTokens.get(i) ;
			String[] split = thisCombinedToken.split("\\|") ;
			List<String> thisTokensList = new ArrayList<String>(Arrays.asList(split)) ;
			if ( thisCombinedToken.endsWith("|") )
				thisTokensList.add("") ;
			individualTokens.add(thisTokensList) ;
		}

		// System.out.println("Tokens: " + individualTokens) ;

		List<List<String>> keywordTokens = new ArrayList<List<String>>() ;
		for ( int i=0 ; i<individualTokens.size() ; i++ )
		{
			List<String> thisIndividualTokens = individualTokens.get(i) ;

			if ( keywordTokens.size() == 0 )
			{
				for ( int j=0 ; j<thisIndividualTokens.size() ; j++ )
				{
					List<String> thisTokens = new ArrayList<String>() ;
					thisTokens.add(thisIndividualTokens.get(j)) ;
					keywordTokens.add(new ArrayList<String>(thisTokens)) ;
				}
				continue ;
			}

			List<List<String>> newKeywordTokens = new ArrayList<List<String>>() ;
			for ( int j=0 ; j<keywordTokens.size() ; j++ )
			{
				List<String> thisKeywordTokens = keywordTokens.get(j) ;
				for ( int k=0 ; k<thisIndividualTokens.size() ; k++ )
				{
					String thisToken = thisIndividualTokens.get(k) ;
					List<String> newThisKeywordTokens = new ArrayList<String>(thisKeywordTokens) ;
					newThisKeywordTokens.add(thisToken) ;
					newKeywordTokens.add(newThisKeywordTokens) ;
				}
			}

			keywordTokens = new ArrayList<List<String>>(newKeywordTokens) ;
		}

		List<List<String>> cleanedKeywordTokens = new ArrayList<List<String>>() ;
		for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			List<String> thisTokens = keywordTokens.get(i) ;
			List<String> newTokens = new ArrayList<String>() ;

			for ( int j=0 ; j<thisTokens.size() ; j++ )
			{
				String token = thisTokens.get(j) ;
				if ( !token.trim().equalsIgnoreCase("") )
					newTokens.add(token) ;
			}

			cleanedKeywordTokens.add(newTokens) ;
		}

		// System.out.println("Final Tokens: " + cleanedKeywordTokens) ;

		return cleanedKeywordTokens ;
	}

	public static void main(String[] args) 
	{
		String input = "(Stand) (Alone) (Balance) (Sheet)" ;
		System.out.println(resolveExpression(input)) ;
	}

	public static List<MetaData> getMetaList() {
		if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("Yes"))
		{
			SectionOntology.getFootNoteMetaList();
			if(tokenKeywords==null)
			getUniqueKeywords(footnotemetaList);
			return footnotemetaList;
		}
		else
		{
			if ( metaList == null )
				init() ;
			if(tokenKeywords==null)
				getUniqueKeywords(metaList);
			return metaList ;
		}

	}
	private static Set<String> getUniqueKeywords(
			List<MetaData> metaList) {
		 tokenKeywords = new HashSet<String>();
		for(MetaData m:metaList)
		{
			tokenKeywords.addAll(m.getKeywords());
		}
		return tokenKeywords;
	}


	public static List<MetaData> getFootNoteMetaList() {

		if ( footnotemetaList == null )
		{
			if ( metaList == null )
			{
				init();
			}
			filterfNotes(metaList);
		}
		return footnotemetaList ;

	}

	private static void filterfNotes(List<MetaData> metaList) {
		footnotemetaList = new ArrayList<MetaData>();

		for(MetaData meta: metaList)
		{
			if(meta.getSection().equalsIgnoreCase("fnotes"))
			{
				footnotemetaList.add(meta);
			}
		}
	}


	public static List<MetaData> getSupplMetaList() {

		if ( metaSupplList == null )
			init() ;

		return metaSupplList ;

	}

	public static void setMetaList(List<MetaData> metaList) {
		SectionOntology.metaList = metaList;
	}
	public static Set<String> getTokenKeywords() {
		if(tokenKeywords==null)
		getMetaList();
		return tokenKeywords;
	}


	public static void setTokenKeywords(Set<String> tokenKeywords) {
		SectionOntology.tokenKeywords = tokenKeywords;
	}


}
