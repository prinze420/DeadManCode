package com.rage.extraction.statements.ontology;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.TreeSet;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.pdf.utils.AccentsRemover;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;

public class RegularSentenceOntology 
{
	private static TreeSet<String> singleTokenKeywords ;
	private static List<List<String>> multipleTokenKeywords ;
	private static TreeSet<String> ignoreKeywords ;
	private static TreeSet<String> ignorePageEndKeywords ;



	public static void setIgnorePageEndKeywords(
			TreeSet<String> ignorePageEndKeywords) {
		RegularSentenceOntology.ignorePageEndKeywords = ignorePageEndKeywords;
	}



	private final static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(RegularSentenceOntology.class);

	public static TreeSet<String> getSingleTokenKeywords()
	{
		if ( singleTokenKeywords == null )
		{
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName =  "resource/section-identification/regular-sentence-keywords.txt" ;
			else
				fileName =  "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/regular-sentence-keywords.txt" ;

			try {
				new SafeFile(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			init(fileName) ;
		}

		return singleTokenKeywords ;
	}


	public static TreeSet<String> getIgnoreKeywords()
	{
		if ( ignoreKeywords == null )
		{
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName =  "resource/section-identification/regular-sentence-keywords.txt" ;
			else
				fileName =  "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/regular-sentence-keywords.txt" ;

			try {
				new SafeFile(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			init(fileName) ;
		}

		return ignoreKeywords ;
	}
	
	
	public static TreeSet<String> getIgnorePageEndKeywords()
	{
		if ( ignorePageEndKeywords == null )
		{
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName =  "resource/section-identification/regular-sentence-keywords.txt" ;
			else
				fileName =  "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/regular-sentence-keywords.txt" ;

			try {
				new SafeFile(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			init(fileName) ;
		}

		return ignorePageEndKeywords ;
	}

	public static List<List<String>> getMultipleTokenKeywords()
	{
		if ( multipleTokenKeywords == null )
		{
			//	String fileName = "resource/section-identification/regular-sentence-keywords.txt" ;
			String fileName = "";
			if(FinancialStatementExtractor.getLanguage().trim().equalsIgnoreCase(""))
				fileName =  "resource/section-identification/regular-sentence-keywords.txt" ;
			else
				fileName =  "resource/section-identification/"+FinancialStatementExtractor.getLanguage().trim()+"/regular-sentence-keywords.txt" ;

			try {
				new SafeFile(fileName);
				PathTravesal  pt = new  PathTravesal();
				pt.failIfDirectoryTraversal(fileName);
			} catch (ValidationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
				logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
				System.exit(1);
			}
			init(fileName) ;
		}

		return multipleTokenKeywords ;
	}

	private static void init(String fileName) 
	{
		singleTokenKeywords = new TreeSet<String>() ;
		multipleTokenKeywords = new ArrayList<List<String>>() ;
		ignoreKeywords = new TreeSet<String>() ;
		ignorePageEndKeywords = new TreeSet<String>() ;

		BufferedReader br = null ;

		try
		{
			//	br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			br = new BufferedReader(new InputStreamReader(new FileInputStream(fileName), "UTF-8"));

			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				line = AccentsRemover.removeAccents(line);

				if ( line.trim().equalsIgnoreCase("") || line.trim().startsWith("#") )
					continue ;

				line = line.trim().toLowerCase() ;
				if(line.toLowerCase().contains("ignore-keyword-pageend"))
				{
					String [] ignoreKey = line.split("\t");
					ignorePageEndKeywords.add(ignoreKey[1]);
				}
				else
				if(line.toLowerCase().contains("ignore-keyword"))
				{
					String [] ignoreKey = line.split("\t");
					ignoreKeywords.add(ignoreKey[1]);
				}
				else
				
					if ( !line.contains(" ") && !line.contains(";"))
						singleTokenKeywords.add(line) ;
					else
					{
						if(line.contains(";"))
						{
							List<String> tokens = Arrays.asList(line.split(";"));
							multipleTokenKeywords.add(tokens) ;
						}
						else
						{
							if(line.contains(" "))
							{
								List<String> tokens = Arrays.asList(line.split(" "));
								multipleTokenKeywords.add(tokens) ;
							}
						}
					}
			}
		}
		catch (Exception e)
		{
			System.err.println("Error in reading file: " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("Error in closing file: " + fileName + " : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
	}



	public static void setIgnoreKeywords(TreeSet<String> ignoreKeywords) {
		RegularSentenceOntology.ignoreKeywords = ignoreKeywords;
	}
}
