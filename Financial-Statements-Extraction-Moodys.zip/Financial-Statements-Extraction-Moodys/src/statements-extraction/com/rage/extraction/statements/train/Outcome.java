package com.rage.extraction.statements.train;

/**
 * @author kiran.umadi
 *
 */
class Outcome implements Comparable<Outcome>
{
	private int ordinal;
	private Node node;

	public int getOrdinal() {
		return ordinal;
	}

	public Node getNode() {
		return node;
	}

	Outcome(Node node) {
		this.node=node;
		this.ordinal=-1;
		try{
			this.ordinal=SectionMeta.getInstance().mapOrdinal(new MetaTree().getSubSection(node));
		} catch (Exception e){e.getStackTrace();}
	}

	@Override
	public int compareTo(Outcome o) {
		if (this.ordinal<o.ordinal)
			return 0;
		return 1;
	}

	@Override
	public String toString() {
		String text="";
		if (node!=null)
		{
			text+="Sequence: "+String.valueOf(ordinal);
			text+=" --> "+node.text();
			try {
				text+=" ["+new MetaTree().getSubSection(node)+"]";
			} catch (Exception e) {
			}
		}
		return text;
	}
}
