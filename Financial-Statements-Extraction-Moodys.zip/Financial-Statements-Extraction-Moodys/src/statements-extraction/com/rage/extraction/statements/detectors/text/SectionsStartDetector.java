package com.rage.extraction.statements.detectors.text;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.statements.SectionStartMatch;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.RowSegmentationType;
import com.rage.extraction.statements.ontology.MetaData;
import com.rage.extraction.statements.ontology.SectionOntology;
import com.rage.extraction.statements.uitls.Stemmer;
import com.rage.extraction.statements.uitls.Utilities;

public class SectionsStartDetector 
{
	/*public static SectionStartMatch isSectionStart(String lineFromChunk, String line, String neighbourhood, PDFLine currLine, List<PDFLine> restLines)
	{
		if ( neighbourhood == null || neighbourhood.trim().equalsIgnoreCase("") )
			return null ;

		List<String> lineFromChunkTokens = Utilities.tokenize(lineFromChunk.toLowerCase(), true) ;

		for ( List<String> keyword : SectionOntology.getOrderedKeywords() )
		{
			String section = SectionOntology.getKeywordSectionMap().get(keyword) ;

			boolean doesKeywordMatch = doesKeywordMatch(lineFromChunkTokens, keyword) ;

			if ( !doesKeywordMatch )
			{
				doesKeywordMatch = doesKeywordMatch(keyword,currLine,restLines);
				if ( !doesKeywordMatch )
				{
					continue ;
				}
			}

			String strKeyword = keyword.toString() ;

			if ( TimePeriodDetector.containsTimePeriod(neighbourhood) )
			{
				currLine.setTableID(Boolean.TRUE);
				return new SectionStartMatch(section, strKeyword, line, neighbourhood) ;

			}
		}



		return null ;
	}
	 */


	public static SectionStartMatch checkSectionStringMatch(PDFLine line)
	{
		List<String> lineFromChunkTokens = Utilities.tokenize(line.getLine().toLowerCase(), true) ;

		List<MetaData> metaList = SectionOntology.getMetaList();
		Collections.sort(metaList);

		for(MetaData m:metaList)
		{
			String section = m.getSection();
			List<String> keyword = m.getKeywords();
			boolean doesKeywordMatch = false;
			RowSegmentationType rowSegmentType = m.getRowSegmentationType();
			Integer columnNo = m.getColumnNo();

			doesKeywordMatch = doesKeywordMatchInOther(lineFromChunkTokens, keyword) ;

			if ( !doesKeywordMatch )
			{
				if ( !doesKeywordMatch )
				{
					continue ;
				}
			}

			String strKeyword = m.getKeyword() ;
			System.out.println("Matched Keyword==="+strKeyword);
			return new SectionStartMatch(section, strKeyword, line.getLine(), null,rowSegmentType,columnNo) ;
		}
		return null ;
	}

	public static SectionStartMatch isSectionStart(String lineFromChunk, String line, String neighbourhood, PDFLine currLine, List<PDFLine> restLines)
	{
		if ( neighbourhood == null || neighbourhood.trim().equalsIgnoreCase("") )
			return null ;

		/*for(PDFChunk chunk : currLine.getChunks())
		{
			String chunkString = chunk.getChunk().trim();
			if(NumberDetector.isNumericValue(chunkString))
			return null;
		}*/

		List<String> lineFromChunkTokens = Utilities.tokenize(lineFromChunk.toLowerCase(), true) ;
		List<String> caseSensitiveTokens = Utilities.tokenize(line,false) ;

		List<MetaData> metaList = SectionOntology.getMetaList();
		Collections.sort(metaList);

		for(MetaData m:metaList)
		{
			String section = m.getSection();
			if(m.getKeyword()!=null && m.getKeyword().contains(";"))
			{
				continue;
			}
			List<String> keyword = m.getKeywords();
			boolean doesKeywordMatch = false;
			RowSegmentationType rowSegmentType = m.getRowSegmentationType();
			Integer columnNo = m.getColumnNo();

			doesKeywordMatch = doesKeywordMatchCheckCase(lineFromChunkTokens, keyword,caseSensitiveTokens) ;

			if ( !doesKeywordMatch )
			{

				//	List<PDFChunk> chunks = currLine.getChunks() ;
				//List<String> linesFromChunk = SectionBoundaryDetector.createLinesFromChunk(chunks) ;
				//doesKeywordMatch = doesKeywordMatch(keyword,currLine,restLines);
				if ( !doesKeywordMatch )
				{
					continue ;
				}
			}

			String strKeyword = m.getKeyword() ;
			if(FinancialStatementExtractor.getLanguage().contains("ITR"))
			{

				currLine.setTableID(Boolean.TRUE);

				return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;

			}
			if ( TimePeriodDetector.containsTimePeriod(neighbourhood) )
			{
				currLine.setTableID(Boolean.TRUE);
				return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;
			}
			else if (doesKeywordMatch && (section.trim().equalsIgnoreCase("fnotes") || section.trim().equalsIgnoreCase("fnotes_end") ))
			{
				currLine.setTableID(Boolean.TRUE);
				return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;
			}
		}
		// Commented by SID
		for(MetaData m : metaList)
		{
			String section = m.getSection();
			List<String> keyword =m.getKeywords();
			if(m.getKeyword()!=null && m.getKeyword().contains(";"))
			{
				continue;
			}
			RowSegmentationType rowSegmentType = m.getRowSegmentationType();
			Integer columnNo = m.getColumnNo();
			boolean doesKeywordMatch = false;

			doesKeywordMatch = doesKeywordMatchEndsWith(lineFromChunkTokens, keyword,caseSensitiveTokens);

			if ( !doesKeywordMatch )
			{
				continue ;

			}
			if(section!=null && section.trim().equalsIgnoreCase("fnotes"))
				continue;
			String strKeyword = keyword.toString() ;

			if ( TimePeriodDetector.containsTimePeriod(neighbourhood) )
			{
				currLine.setTableID(Boolean.TRUE);
				return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;
			}
			else if (doesKeywordMatch && (section.trim().equalsIgnoreCase("fnotes") || section.trim().equalsIgnoreCase("fnotes_end")))
			{
				currLine.setTableID(Boolean.TRUE);
				return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;
			}
		}
		// Commented by SID END

		/*
		if(!FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
		{
			for(MetaData m : metaList)
			{
				String section = m.getSection();
				List<String> keyword =m.getKeywords();
				RowSegmentationType rowSegmentType = m.getRowSegmentationType();
				Integer columnNo = m.getColumnNo();
				boolean doesKeywordMatch = false;
				String keywordExpression = m.getKeyword();

				doesKeywordMatch = doesKeywordMatchContains(line, keywordExpression,keyword,lineFromChunkTokens);


				if ( !doesKeywordMatch )
				{
					continue ;

				}

				String strKeyword = keyword.toString() ;

				if ( TimePeriodDetector.containsTimePeriod(neighbourhood) )
				{
					currLine.setTableID(Boolean.TRUE);
					return new SectionStartMatch(section, strKeyword, line, neighbourhood,rowSegmentType,columnNo) ;
				}
			}
		}*/

		return null ;
	}


	private static boolean doesKeywordMatchContains(
			String line, String keyword, List<String> keywordTokens, List<String> tokens) {
		if(line.toLowerCase().contains(keyword.toLowerCase()))
			return true;
		boolean found = false;

		for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				return false ;

			if ( index !=-1 )
				found = true ;
		}

		if(found)
			return true;
		return false;
	}
	//Reprocess
	public static boolean isSectionStart(Boolean ismultiLine,String lineFromChunk, String line, PDFLine currLine, List<PDFLine> restLines,List<String> keywords, String keywordExpression)
	{
		List<String> lineFromChunkTokens = Utilities.tokenize(lineFromChunk.toLowerCase(), true) ;
		boolean doesKeywordMatch = doesKeywordMatch(lineFromChunkTokens, keywords) ;
		if ( !doesKeywordMatch )
		{
			doesKeywordMatch = lineFromChunk.toLowerCase().trim().contains(keywordExpression.toLowerCase().trim());
			if ( !doesKeywordMatch )
			{
				//doesKeywordMatch = keywordExpression.replaceAll("\\,","").replaceAll("\\.","").toLowerCase().trim().contains(lineFromChunk.toLowerCase().trim().replaceAll("\\,","").replaceAll("\\.", "").trim());
				//if ( !doesKeywordMatch )
				//{
				String cleanLineChunkString=lineFromChunk.toLowerCase().replaceAll(" ", "").replaceAll("�", "").replaceAll(",", "").replaceAll("'", "");
				String cleanKwExp=keywordExpression.toLowerCase().replaceAll(" ", "").replaceAll("�", "").replaceAll(",", "").replaceAll("'", "");
				doesKeywordMatch = cleanLineChunkString.toLowerCase().replaceAll(" ", "").toLowerCase().contains(cleanKwExp.toLowerCase().replaceAll(" ", ""));
				if ( !doesKeywordMatch )
				{
					doesKeywordMatch = doesKeywordMatchReprocess(lineFromChunkTokens,keywords);
					if(!doesKeywordMatch)
						return false;
				}
				//}
				//}

			}
		}
		if(doesKeywordMatch)
			return true;
		else return false;
	}




	private static boolean doesKeywordMatchReprocess(List<String> tokens, List<String> keywordTokens) 
	{			
		//startsWith
		boolean found = true;
		int ct =0;

		for ( int i=0 ; i<tokens.size() ; i++ )
		{
			String token = tokens.get(i) ;
			for (  int j=ct ; j<keywordTokens.size() ; j++)
			{
				String keywordToken =  keywordTokens.get(j) ;
				if(token.trim().equalsIgnoreCase(keywordToken.trim()))
				{
					++ct;
					break;
				}
				else
				{
					found = false;
				}
			}

			if(found && ct==keywordTokens.size())
			{
				return true;
			}

		}

		//endsWith
		found = true;
		ct=keywordTokens.size()-1;
		for ( int i=(tokens.size()-1) ; i>0 ; i-- )
		{
			String token = tokens.get(i) ;
			for (  int j=ct ; j>0 ; j--)
			{
				String keywordToken =  keywordTokens.get(j) ;
				if(token.trim().equalsIgnoreCase(keywordToken.trim()))
				{
					--ct;
					break;
				}
				else
				{
					found = false;
				}
			}

			if(found && ct<0)
			{
				return true;
			}

		}



		return false;
	}

	private static boolean doesKeywordMatch(List<String> keywordTokens, PDFLine currLine,
			List<PDFLine> restLines) {
		boolean foundEnd = false ;
		boolean foundStart = false ;
		float minX = 0.0f;
		float maxX = 0.0f;
		List<PDFLine> lines = new ArrayList<PDFLine>();
		lines.add(currLine);
		lines.addAll(restLines);
		int s =0;
		Stemmer stem = new Stemmer();

		for ( int i=s ; i<keywordTokens.size() ; ++i )
		{
			String keywordToken = stem.getStem(keywordTokens.get(i).trim()) ;

			for(int i1=0;i1<lines.size();i1++)
			{
				List<PDFChunk> chunks = lines.get(i1).getChunks();
				for(int j=0;j<chunks.size();j++)
				{
					PDFChunk chunk = chunks.get(j);
					//List<String> tokens = Utilities.tokenize(chunk.getChunk(), true) ;
					List<PDFWord> words = chunk.getWords();

					if(!foundStart)
					{
						for(int k=0;k<words.size();k++)
						{
							PDFWord word= words.get(k);
							String token = stem.getStem(word.toString().trim());

							//token= SectionBoundaryDetector.IgnoreEnumeration(token).toLowerCase();
							if((FinancialStatementExtractor.getLanguage().equalsIgnoreCase("") || FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))&& ( token.toLowerCase().equalsIgnoreCase("of") || token.toLowerCase().equalsIgnoreCase("and") || token.toLowerCase().equalsIgnoreCase("in") || token.trim().equalsIgnoreCase("")))
								continue;
							if(token.equals(keywordToken))
							{
								foundStart = true;
								s++;
								for ( int i2=s ; i2<keywordTokens.size() ; )
								{
									keywordToken = keywordTokens.get(i2) ;
									break;
								}
							}
							else
							{
								foundStart = false;
								break;
							}
						}


						if(foundStart)
						{
							minX = chunk.getX1();
							maxX = chunk.getX2();
							j= chunks.size();
							break;
						}
						else
						{
							return false;
						}
					}
					else
						if(foundStart)
						{
							if(/*((chunk.getX1()- minX)>-0.5 && (chunk.getX1()- minX)<0.5 ) */((chunk.getX1()- minX)>-0.5 && chunk.getX1()> minX)  &&  chunk.getX1()<=maxX)
							{
								for(int k=0;k<words.size();k++)
								{
									PDFWord word= words.get(k);
									String token = word.toString().trim();
									//token= SectionBoundaryDetector.IgnoreEnumeration(token).toLowerCase();
									if((FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English") 
											|| FinancialStatementExtractor.getLanguage().equalsIgnoreCase("")) 
											&& (token.toLowerCase().equalsIgnoreCase("of") || token.toLowerCase().equalsIgnoreCase("and") || token.trim().equalsIgnoreCase("")))
										continue;
									if(token.equals(keywordToken))
									{
										foundEnd = true;
										s++;
										for ( int i2=s ; i2<keywordTokens.size() ;  )
										{
											keywordToken = keywordTokens.get(i2) ;
											break;
										}
									}
									else
									{
										foundEnd = false;
										break;
									}
								}

								if(foundEnd)
								{
									j= chunks.size();
									break;
								}
								else
								{
									return false;
								}
							}
						}

				}

				if(!foundStart)
				{
					return false;
				}
				if(foundStart && foundEnd && s == keywordTokens.size() )
				{
					for(int k1=0;k1<i1;k1++)
					{
						lines.get(k1).setTableID(Boolean.TRUE);
					}
					return true;
				}

			}
		}
		return false;
	}



	public static boolean doesKeywordMatch(List<String> tokens, List<String> keywordTokens) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		if(FinancialStatementExtractor.getLanguage().contains("") || FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
		{
			filterTokens(tokens);
			filterTokens(keywordTokens);
		}

		// Serialwise token Check
		int j=0;
		for(int i=0;i<tokens.size();i++)
		{
			String a=tokens.get(i).replaceAll(",", "").trim();
			String b="";
			if(keywordTokens.size()>j)
				b=keywordTokens.get(j).replaceAll(",", "").trim();

			if(a.trim().equalsIgnoreCase(b.trim().toLowerCase()))
			{
				j++;
			}
			else
			{
				j=0;
				break;
			}
			if(j==keywordTokens.size())
				return true;
		}

		/*for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				return false ;

			if ( index == 0 )
				foundStart = true ;
		}

		if ( foundAll && foundStart )
			return true ;*/

		return false;
	}

	public static boolean doesKeywordMatchInOther(List<String> tokens, List<String> keywordTokens) 
	{
		if(FinancialStatementExtractor.getLanguage().contains("") || FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
		{
			filterTokens(tokens);
			filterTokens(keywordTokens);
		}

		// Serialwise token Check
		int j=0;
		for(int i=0;i<tokens.size();i++)
		{
			String a=tokens.get(i).replaceAll(",", "").trim();
			String b=keywordTokens.get(j).replaceAll(",", "").trim();
			if(a.trim().equalsIgnoreCase(b.trim().toLowerCase()))
			{
				j++;
			}
			else
			{
				j=0;
			}

			if(j==keywordTokens.size())
			{
				return true;
			}
		}

		return false;
	}

	public static boolean doesKeywordMatchCheckCase(List<String> tokens, List<String> keywordTokens, List<String> caseSensitiveKeyWords) 
	{
		/*boolean foundAll = true ;
		boolean foundStart = false ;*/
		if(FinancialStatementExtractor.getLanguage().contains("") || FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
		{
			filterTokens(tokens);
			filterTokens(keywordTokens);
			filterTokens(caseSensitiveKeyWords);
		}

		// Serialwise token Check
		int j=0;
		int caseMatch=0;
		for(int i=0;i<tokens.size();i++)
		{
			String a=tokens.get(i).replaceAll(",", "").replaceAll("�", "").trim().replaceAll("�", "").trim();
			String b=keywordTokens.get(j).replaceAll(",", "").replaceAll("�", "").replaceAll("�", "").trim().trim();
			String c=caseSensitiveKeyWords.get(j).replaceAll(",", "").trim();
			if(a.trim().equalsIgnoreCase(b.trim().toLowerCase()))
			{
				j++;
				if(Character.toString(c.charAt(0)).toUpperCase().equals(Character.toString(c.charAt(0))))
					caseMatch++;
			}
			else
			{
				j=0;
				caseMatch=0;
				break;
			}
			/*			if(Character.toString(c.charAt(0)).toUpperCase().equals(Character.toString(c.charAt(0))))
				caseMatch++;*/
			if(j==keywordTokens.size())
			{
				if(caseMatch>0)
					return true;
				else
					break;
			}
		}

		/*for ( int i=0 ; i<keywordTokens.size() ; i++ )
		{
			String keywordToken = keywordTokens.get(i) ;

			int index = tokens.indexOf(keywordToken.toLowerCase()) ;

			if ( index == -1 )
				return false ;

			if ( index == 0 )
				foundStart = true ;
		}

		if ( foundAll && foundStart )
			return true ;*/

		return false;
	}

	private static boolean doesKeywordMatchEndsWith(List<String> tokens, List<String> keywordTokens, List<String> caseSensitiveTokens) 
	{
		boolean foundAll = true ;
		boolean foundStart = false ;
		if(FinancialStatementExtractor.getLanguage().equalsIgnoreCase("English"))
		{
			filterTokens(tokens);
			filterTokens(keywordTokens);
			filterTokens(caseSensitiveTokens);
		}
		int tSize=tokens.size()-1;
		int caseSensitiveFound=0;
		for ( int i=keywordTokens.size()-1 ; i>=0 ; i-- )
		{
			String keywordToken = keywordTokens.get(i) ;

			if(tokens.size()<keywordTokens.size())
				return false;

			for ( int j=tSize ; j>=0 ;  )
			{
				String token = tokens.get(j) ;
				String caseToken = caseSensitiveTokens.get(j) ;
				if ( !token.equalsIgnoreCase(keywordToken) )
				{
					return false ;
				}
				else
				{
					if(caseToken.equalsIgnoreCase(keywordToken))
					{
						if(Character.toString(caseToken.charAt(0)).toUpperCase().equals(Character.toString(caseToken.charAt(0))))
							caseSensitiveFound++;
					}
					foundStart = true ;
				}

				tSize = j-1;

				break;

			}

		}

		if(caseSensitiveFound==0)
		{
			return false;
		}
		if ( foundAll && foundStart && caseSensitiveFound>0 )
			return true ;

		return false;
	}

	private static void filterTokens(List<String> tokens) {
		try {
			if(tokens!=null)
			{
				for(int i=0;i<tokens.size();i++){
					String token =tokens.get(i).toLowerCase();
					if(token==null)
						continue;
					if(token.trim().equals("of") || token.trim().equals("and") || token.trim().equals("in") || token.trim().equals(""))
					{
						tokens.remove(i);
						--i;
					}
				}
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
