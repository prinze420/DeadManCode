package com.rage.extraction.statements.db;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringEscapeUtils;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.constant.DBConnection;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.RowSegmentationType;
import com.rage.extraction.statements.extract.pdf.SectionType;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.reprocess.ReprocessMetadata;
import com.rage.extraction.statements.uitls.AccentsRemover;
import com.rage.extraction.statements.uitls.CleanEnumeratedText;



public class DataWriterOracle {
	/** Gets the po_id from parser_output table
	 * 
	 * @param con
	 * @return
	 */
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(DataWriterOracle.class);

	private Map<String,Map<String,String>> sectionMap;

	private static boolean DEBUG = Boolean.FALSE;
	private static LinkedHashSet<String>languagetoReplacefromDots;


	private synchronized long getPOID(Connection con) {
		if( DEBUG )
		{
			System.out.println("Inside getPOID");
		}
		long sequence = 0;
		final String sql = "select SEQ_PO_ID.NEXTVAL as GPO_ID from dual";
		try
		{
			PreparedStatement stmt = con.prepareStatement(sql);
			final ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				sequence = rs.getLong("GPO_ID");
			}
			if(stmt!=null)
			{
				stmt.close();
			}
			if (rs!=null)
				rs.close();
		} catch (final SQLException e) {
			if(logger!=null) {
				logger.error(StringEscapeUtils.escapeJava(sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return sequence;
	}

	private synchronized long getSTID(Connection con) {
		if( DEBUG )
		{
			System.out.println("Inside getPOID");
		}
		long sequence = 0;
		final String sql = "select SEQ_ST_ID.NEXTVAL as GPO_ID from dual";
		try
		{
			PreparedStatement stmt = con.prepareStatement(sql);
			final ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				sequence = rs.getLong("GPO_ID");
			}
			if(stmt!=null)
			{
				stmt.close();
			}
			if (rs!=null)
				rs.close();
		} catch (final SQLException e) {
			if(logger!=null) {
				logger.error(StringEscapeUtils.escapeJava(sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return sequence;
	}


	private synchronized long getID(Connection con) {
		if( DEBUG )
		{
			System.out.println("Inside getPOID");
		}
		long sequence = 0;
		final String sql = "select SEQ_POCH_ID.NEXTVAL as GPO_ID from dual";
		try
		{
			PreparedStatement stmt = con.prepareStatement(sql);
			final ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				sequence = rs.getLong("GPO_ID");
			}
			if(stmt!=null)
			{
				stmt.close();
			}
			if (rs!=null)
				rs.close();
		} catch (final SQLException e) {
			if(logger!=null) {
				logger.error(StringEscapeUtils.escapeJava(sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return sequence;
	}


	private synchronized long getPID(Connection con) {
		if( DEBUG )
		{
			System.out.println("Inside getPOID");
		}
		long sequence = 0;
		final String sql = "select seq_pem_pid.NEXTVAL as P_ID from dual";
		try
		{
			PreparedStatement stmt = con.prepareStatement(sql);
			final ResultSet rs = stmt.executeQuery();
			while (rs.next()) {
				sequence = rs.getLong("P_ID");
			}
			if(stmt!=null)
			{
				stmt.close();
			}
			if (rs!=null)
				rs.close();
		} catch (final SQLException e) {
			if(logger!=null) {
				logger.error(StringEscapeUtils.escapeJava(sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return sequence;
	}


	public DataWriterOracle() {
	}


	private static int findMaxIndexOrder(String section,String docID, Connection con)
	{
		if( DEBUG )
		{
			System.out.println("Inside findMaxIndexOrder");
		}
		int indexOrder=0;
		String sql = "select max(po_index_order) as maxIndexOrder from parser_output where filing_id=? and po_section= ?";
		//Connection con = null;
		PreparedStatement pStmt = null;
		try {
			//con = DBConnection.openConnection();
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			System.out.println(e1.getMessage());
		}
		try
		{
			pStmt = con.prepareStatement(sql);
			pStmt.setString(1,docID);
			pStmt.setString(2, section);
			final ResultSet rs = pStmt.executeQuery();
			while (rs.next()) {
				indexOrder = rs.getInt("maxIndexOrder");
			}	if(pStmt!=null)
				pStmt.close();

		} catch (SQLException e)
		{
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
			e.printStackTrace();
		}

		try {
			if(con!=null)
			{
				con.commit();
			}
		} catch (SQLException e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava((sql)));
				logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
				e.printStackTrace();
			}
		}
		return indexOrder;
	}








	public synchronized void  writeTable(Integer docID, TreeMap<String, ArrayList<ParserOutput>> mergedMap, Boolean isMerge, TreeMap<Integer, PageParse> pageParsesMap, boolean isSplit,String coordReqd,String language ) 
	{
		Connection con = null;
		ParserOutput po = null;
		int indexOrder = 0;
		CleanEnumeratedText cet = new CleanEnumeratedText();
		//	getLanguages();
		try {
			con = DBConnection.openConnection("LIVESPREAD");
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e1.getMessage()));
			}
			System.out.println(e1.getMessage());
		}

		/*try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e1.getMessage()));
			}
			System.out.println(e1.getMessage());
		}*/
		/*	if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") )
		{
			deleteParserOutput(docID,con,isMerge,isSplit);
			if(coordReqd.equalsIgnoreCase("Yes"))
			{
				deleteCoordValues(docID,con,isMerge,isSplit);	
			}
		}*/

		/*try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {

		}*/

		if(!isMerge && !isSplit)
		{
			if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("No") )
			{
				if(coordReqd.equalsIgnoreCase("Yes"))
				{
					deleteCoordValues(docID,con,isMerge,isSplit);	
				}
				deleteParserOutput(docID,con,isMerge,isSplit);

			}
			else
				if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("Yes"))
				{
					for(String section:FinancialStatementExtractor.getProcessingScope() )
					{

						if(coordReqd.equalsIgnoreCase("Yes"))
						{
							deleteCoordValues(docID,con,section,isMerge,isSplit);	
						}
						deleteParserOutput(docID,con,section,isMerge,isSplit);


					}
				}
		}
		else
		{
			if(coordReqd.equalsIgnoreCase("Yes"))
			{
				deleteCoordValues(docID,con,isMerge,isSplit);	
			}
			deleteParserOutput(docID,con,isMerge,isSplit);

		}

		for(String section : mergedMap.keySet())
		{
			if(section.equalsIgnoreCase("SD"))
				continue;
			ArrayList<ParserOutput> poObjects = mergedMap.get(section);

			System.out.println("Writing Data for Section===="+section);
			/*if(section.equalsIgnoreCase("suppl"))
				continue;*/
			indexOrder = DataWriterOracle.findMaxIndexOrder(section, docID+"",con);

			/*if(poObjects!=null && poObjects.size()>0 && !isMerge && !DataWriterSql.isSplitTable(poObjects))
			{
				Collections.sort(poObjects);
			}*/
			ParserOutput poRef=null;
			for( int i=0; i<poObjects.size(); i++ )
			{

				po = poObjects.get(i);
				/*if(po.getBreakups().equalsIgnoreCase("N"))
				{
					poRef=po;
					if(section.equalsIgnoreCase("suppl"))
						continue;
				}*/
				if((po.getAsRepLabel()==null || (po.getAsRepLabel()!=null && po.getAsRepLabel().trim().equalsIgnoreCase("")))
						&& (po.getValue1()==null || (po.getValue1()!=null && po.getValue1().trim().equalsIgnoreCase("")))
						&& ( po.getValue2()==null || ( po.getValue2()!=null && po.getValue2().trim().equalsIgnoreCase("")))
						&& ( po.getValue3()==null || ( po.getValue3()!=null && po.getValue3().trim().equalsIgnoreCase("")))
						&& ( po.getValue4()==null || ( po.getValue4()!=null && po.getValue4().trim().equalsIgnoreCase("")))
						&& ( po.getValue5()==null || ( po.getValue5()!=null && po.getValue5().trim().equalsIgnoreCase("")))
						&& ( po.getValue6()==null || ( po.getValue6()!=null && po.getValue6().trim().equalsIgnoreCase("")))
						&& ( po.getValue7()==null || ( po.getValue7()!=null && po.getValue7().trim().equalsIgnoreCase("")))
						&& ( po.getValue8()==null || ( po.getValue8()!=null && po.getValue8().trim().equalsIgnoreCase("")))
						&& ( po.getValue9()==null || ( po.getValue9()!=null && po.getValue9().trim().equalsIgnoreCase("")))
						&& ( po.getValue10()==null || ( po.getValue10()!=null && po.getValue10().trim().equalsIgnoreCase("")))
						&& (po.getValue11()==null || (po.getValue11()!=null && po.getValue11().trim().equalsIgnoreCase("")))
						&& ( po.getValue12()==null || ( po.getValue12()!=null && po.getValue12().trim().equalsIgnoreCase("")))
						&& ( po.getValue13()==null || ( po.getValue13()!=null && po.getValue13().trim().equalsIgnoreCase("")))
						&& ( po.getValue14()==null || ( po.getValue14()!=null && po.getValue14().trim().equalsIgnoreCase("")))
						&& ( po.getValue15()==null || ( po.getValue15()!=null && po.getValue15().trim().equalsIgnoreCase("")))
						&& ( po.getValue16()==null || ( po.getValue16()!=null && po.getValue16().trim().equalsIgnoreCase("")))
						&& ( po.getValue17()==null || ( po.getValue17()!=null && po.getValue17().trim().equalsIgnoreCase("")))
						&& ( po.getValue18()==null || ( po.getValue18()!=null && po.getValue18().trim().equalsIgnoreCase("")))
						&& ( po.getValue19()==null || ( po.getValue19()!=null && po.getValue19().trim().equalsIgnoreCase("")))
						&& ( po.getValue20()==null || ( po.getValue20()!=null && po.getValue20().trim().equalsIgnoreCase("")))
						&& (po.getValue21()==null || (po.getValue21()!=null && po.getValue21().trim().equalsIgnoreCase("")))
						&& ( po.getValue22()==null || ( po.getValue22()!=null && po.getValue22().trim().equalsIgnoreCase("")))
						&& ( po.getValue23()==null || ( po.getValue23()!=null && po.getValue23().trim().equalsIgnoreCase("")))
						&& ( po.getValue24()==null || ( po.getValue24()!=null && po.getValue24().trim().equalsIgnoreCase("")))
						&& ( po.getValue25()==null || ( po.getValue25()!=null && po.getValue25().trim().equalsIgnoreCase("")))
						&& ( po.getValue26()==null || ( po.getValue26()!=null && po.getValue26().trim().equalsIgnoreCase("")))
						&& ( po.getValue27()==null || ( po.getValue27()!=null && po.getValue27().trim().equalsIgnoreCase("")))
						&& ( po.getValue28()==null || ( po.getValue28()!=null && po.getValue28().trim().equalsIgnoreCase("")))
						&& ( po.getValue29()==null || ( po.getValue29()!=null && po.getValue29().trim().equalsIgnoreCase("")))
						&& ( po.getValue30()==null || ( po.getValue30()!=null && po.getValue30().trim().equalsIgnoreCase(""))))
					continue;
				if(po!=null && (po.getSubSection()!=null && (/*po.getSubSection().trim().equals("HEADER") ||*/ po.getSubSection().trim().equals("PREV-HEADER"))/*) || (po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")*/) || (po.getPrevHeader()!=null && po.getPrevHeader().equalsIgnoreCase("Y")))
					continue;
				indexOrder = indexOrder + 20; 
				po.setIndexOrder(indexOrder);
				
				/*if(po.getBreakupItems()!=null && po.getBreakupItems().size()>0)
				{
					po.setBreakupExtracted("Y");
					writetoDB(docID, con, po, cet, pageParsesMap,coordReqd,language);

					for(ParserOutput poBreakup : po.getBreakupItems())
					{
						indexOrder = indexOrder +10;
						poBreakup.setIndexOrder(indexOrder);
						poBreakup.setBreakups("Y");
						if((poBreakup.getAsRepLabel()==null || (poBreakup.getAsRepLabel()!=null && poBreakup.getAsRepLabel().trim().equalsIgnoreCase("")))
								&& (poBreakup.getValue1()==null || (poBreakup.getValue1()!=null && poBreakup.getValue1().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue2()==null || ( poBreakup.getValue2()!=null && poBreakup.getValue2().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue3()==null || ( poBreakup.getValue3()!=null && poBreakup.getValue3().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue4()==null || ( poBreakup.getValue4()!=null && poBreakup.getValue4().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue5()==null || ( poBreakup.getValue5()!=null && poBreakup.getValue5().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue6()==null || ( poBreakup.getValue6()!=null && poBreakup.getValue6().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue7()==null || ( poBreakup.getValue7()!=null && poBreakup.getValue7().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue8()==null || ( poBreakup.getValue8()!=null && poBreakup.getValue8().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue9()==null || ( poBreakup.getValue9()!=null && poBreakup.getValue9().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue10()==null || ( poBreakup.getValue10()!=null && poBreakup.getValue10().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue11()==null || (poBreakup.getValue11()!=null && poBreakup.getValue11().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue12()==null || ( poBreakup.getValue12()!=null && poBreakup.getValue12().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue13()==null || ( poBreakup.getValue13()!=null && poBreakup.getValue13().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue14()==null || ( poBreakup.getValue14()!=null && poBreakup.getValue14().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue15()==null || ( poBreakup.getValue15()!=null && poBreakup.getValue15().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue16()==null || ( poBreakup.getValue16()!=null && poBreakup.getValue16().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue17()==null || ( poBreakup.getValue17()!=null && poBreakup.getValue17().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue18()==null || ( poBreakup.getValue18()!=null && poBreakup.getValue18().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue19()==null || ( poBreakup.getValue19()!=null && poBreakup.getValue19().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue20()==null || ( poBreakup.getValue20()!=null && poBreakup.getValue20().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue21()==null || (poBreakup.getValue21()!=null && poBreakup.getValue21().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue22()==null || ( poBreakup.getValue22()!=null && poBreakup.getValue22().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue23()==null || ( poBreakup.getValue23()!=null && poBreakup.getValue23().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue24()==null || ( poBreakup.getValue24()!=null && poBreakup.getValue24().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue25()==null || ( poBreakup.getValue25()!=null && poBreakup.getValue25().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue26()==null || ( poBreakup.getValue26()!=null && poBreakup.getValue26().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue27()==null || ( poBreakup.getValue27()!=null && poBreakup.getValue27().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue28()==null || ( poBreakup.getValue28()!=null && poBreakup.getValue28().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue29()==null || ( poBreakup.getValue29()!=null && poBreakup.getValue29().trim().equalsIgnoreCase("")))
								&& ( poBreakup.getValue30()==null || ( poBreakup.getValue30()!=null && poBreakup.getValue30().trim().equalsIgnoreCase(""))))
							continue;
						writetoDB(docID, con, poBreakup,cet, pageParsesMap,coordReqd,language);

					}
				}
				else
				{
					po.setBreakupExtracted("N");*/
				writetoDB(docID, con, po, cet, pageParsesMap,coordReqd,language,poRef,section);
				
				/*if(poSuppl!=null &&poSuppl.size()>0)
				{
					for(ParserOutput brkup:poSuppl)
					{
						if(!brkup.getBreakups().equalsIgnoreCase("N"))
						{
							writetoDB(docID, con, brkup, cet, pageParsesMap,coordReqd,language,poRef,"SUPPL");

						}
					}

				}
*/
				/*	if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0)
					{
						for(List<ParserOutput> brkups :po.getSupplementaryBreakUpItem())
						{
							if(brkups!=null)
							{
								for(ParserOutput brkup :brkups)
								{
									if(brkup.getBreakups().equalsIgnoreCase("N"))
										continue;
									indexOrder = indexOrder +10;
									brkup.setIndexOrder(indexOrder);
									brkup.setBreakups("Y");
									brkup.setSection("SUPPL");
									if(brkup!=null)
									{
										writetoDB(docID, con, brkup, cet, pageParsesMap,coordReqd,language,poRef);
									}	
								}
							}
						}
					}*/
				/*}*/

				/*if(po.getInlineBreakupItems()!=null && po.getInlineBreakupItems().size()>0)
				{
					for(ParserOutput inLineBreakup : po.getInlineBreakupItems())
					{
						indexOrder = indexOrder + 10;
						inLineBreakup.setIndexOrder(indexOrder);
						inLineBreakup.setBreakups("Y");
						writetoDB(docID, con, inLineBreakup,cet,pageParsesMap,coordReqd,language);
					}
				}*/
			}
		}

		try {
			if(con!=null)
			{
				con.commit();
				con.close();
			}
		} catch (SQLException e) {

			e.printStackTrace();
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
			}
		}

	}




	private synchronized boolean deleteCoordValues(int docID,Connection con,String section, Boolean isMerge,Boolean isSplit)
	{
		PreparedStatement pStmt = null;
		String sql = "";
		try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {

		}
		try
		{
			if(!isMerge && !isSplit)
			{
				sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ?and po_section=?";
				pStmt = con.prepareStatement(sql);
				pStmt.setLong(1,docID);
				pStmt.setString(2,section);

			}
			else
				if(isMerge)
				{
					sql = "select po_ID from parser_output where filing_id = ? and po_merge = ?";
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,"Y");
					final ResultSet rs = pStmt.executeQuery();
					String po_ids = "";
					int ct=0;
					while(rs.next())
					{
						if(rs.getString("PO_ID")!=null)
						{
							if(ct==0)
								po_ids +=rs.getString("PO_ID");
							else
								po_ids += ","+rs.getString("PO_ID");
							ct++;

						}
					}
					if(pStmt!=null)
						pStmt.close();

					sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ? and po_id in(?) and po_section=?";
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,po_ids);
					pStmt.setString(3,section);

				}
				else
					if(isSplit)
					{
						sql = "select po_ID from parser_output where filing_id = ? and po_split = ? and po_section=?";
						pStmt = con.prepareStatement(sql);
						pStmt.setLong(1,docID);
						pStmt.setString(2,"Y");
						final ResultSet rs = pStmt.executeQuery();
						String po_ids = "";
						int ct=0;
						while(rs.next())
						{
							if(rs.getString("PO_ID")!=null)
							{
								if(ct==0)
									po_ids +=rs.getString("PO_ID");
								else
									po_ids += ","+rs.getString("PO_ID");
								ct++;

							}
						}
						if(pStmt!=null)
							pStmt.close();

						sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ? and po_id in(?) and po_section=?";

						pStmt = con.prepareStatement(sql);
						pStmt.setLong(1,docID);
						pStmt.setString(2,po_ids);
						pStmt.setString(3,section);


					}

			pStmt.executeUpdate();
			if(con!=null)
			{
				con.commit();

			}
			if(pStmt!=null)
				pStmt.close();
			return true;
		} catch (SQLException e)
		{
			System.out.println(e);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return false;
	}


	/*private void getLanguages()
	{
		if(PDFCharacter.getLatinLanguageList()==null)
		{
			String fileName = "resource/section-identification/latinLanguages.txt" ;
			PDFCharacter.setLatinLanguageList(TimePeriodOntology.loadSuffixes(fileName)) ;
		}
	}*/




	private void writetoDB(int docID, Connection con,
			ParserOutput po, CleanEnumeratedText cet, TreeMap<Integer, PageParse> pageParsesMap,String coordReqd,String language, ParserOutput poRef, String section) {
		PreparedStatement pStmt = null, pStmt1 = null;
		String sqlRow="insert into parser_output (filing_id, po_id, po_section, po_index_order, po_as_rep_label, po_as_rep_val1, po_val1, po_as_rep_val2, po_val2, po_as_rep_val3, po_val3, po_as_rep_val4, po_val4, po_as_rep_val5, po_val5, po_as_rep_val6, po_val6, po_as_rep_val7, po_val7, po_as_rep_val8, po_val8, po_as_rep_val9, po_val9,po_as_rep_val10, po_val10,"+
				"po_as_rep_val11,po_val11, po_as_rep_val12, po_val12, po_as_rep_val13, po_val13, po_as_rep_val14, po_val14, po_as_rep_val15, po_val15, po_as_rep_val16, po_val16, po_as_rep_val17, po_val17, po_as_rep_val18, po_val18, po_as_rep_val19, po_val19,po_as_rep_val20, po_val20,"+
				"created_by, create_date,po_crud_account, po_subtotal, po_sign_change, po_breakup,po_subsection,page_no,po_ycoordinates,po_table_id,po_merge,fi_id,fi_label,ni_item,nil_Label,non_english_Label,po_split,po_mergent,ref_po_id,po_note) values " +
				"(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP(6),?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		int ct=0;
		long poID = getPOID(con);
		po.setPoID(poID);
		try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava(e1.getMessage()));
			}
			System.out.println(e1.getMessage());
		}

		String patternStr ="[\\\\/:*<>|]";
		Pattern pt = Pattern.compile(patternStr);
		Matcher matcher = pt.matcher(sqlRow);

		while (matcher.find())  {
			if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Unknown Characters found in command"));
			System.exit(1);
		}
		if(coordReqd.equalsIgnoreCase("Yes"))
			insertCoordinates(docID, con, po,  poID,section);

		try
		{
			pStmt = con.prepareStatement(sqlRow);
			pStmt.setInt(++ct,docID);
			pStmt.setLong(++ct, poID);
			
			pStmt.setString(++ct, section.toUpperCase());
			pStmt.setInt(++ct, po.getIndexOrder());

			/*	if(po.getNonEnglishLabel()!=null)
			{
				pStmt.setString(5, text.replaceAll("", "").trim());

			}*/

			if(po.getAsRepLabel()!=null)
			{
				String text = "";
				text = cet.replaceEnums(text);
				text = po.getAsRepLabel().replaceAll("[[^A-Za-z -&)(0-9-]]", "");//.trim();
				pStmt.setString(++ct, text);//.trim());
			}
			else
			{
				pStmt.setString(++ct, po.getAsRepLabel());
			}

			/*if(po.getAsRepLabel()!=null && PDFCharacter.getLatinLanguageList()!=null && PDFCharacter.getLatinLanguageList().contains(language.trim().toLowerCase()))
			{
				String text = "";
				text = po.getAsRepLabel().replaceAll("[[^A-Za-z -&)(0-9-]]", "").trim();
				text = cet.replaceEnums(text);
				pStmt.setString(5, text.replaceAll("", "").trim());
			}
			else
			{
				if(po.getAsRepLabel()!=null)
				{
					String text =  po.getAsRepLabel();
					text = cet.replaceEnums(text);
					pStmt.setString(5, po.getAsRepLabel());
				}
				else
					pStmt.setString(5, po.getAsRepLabel());

			}*/

			pStmt.setString(++ct, po.getAsRepVal1());
			pStmt.setString(++ct, po.getValue1());
			pStmt.setString(++ct, po.getAsRepVal2());
			pStmt.setString(++ct, po.getValue2());
			pStmt.setString(++ct, po.getAsRepVal3());
			pStmt.setString(++ct, po.getValue3());
			pStmt.setString(++ct, po.getAsRepVal4());
			pStmt.setString(++ct, po.getValue4());
			pStmt.setString(++ct, po.getAsRepVal5());
			pStmt.setString(++ct, po.getValue5());
			pStmt.setString(++ct, po.getAsRepVal6());
			pStmt.setString(++ct, po.getValue6());
			pStmt.setString(++ct, po.getAsRepVal7());
			pStmt.setString(++ct, po.getValue7());
			pStmt.setString(++ct, po.getAsRepVal8());
			pStmt.setString(++ct, po.getValue8());
			pStmt.setString(++ct, po.getAsRepVal9());
			pStmt.setString(++ct, po.getValue9());
			pStmt.setString(++ct, po.getAsRepVal10());
			pStmt.setString(++ct, po.getValue10());

			pStmt.setString(++ct, po.getAsRepVal11());
			pStmt.setString(++ct, po.getValue11());
			pStmt.setString(++ct, po.getAsRepVal12());
			pStmt.setString(++ct, po.getValue12());
			pStmt.setString(++ct, po.getAsRepVal13());
			pStmt.setString(++ct, po.getValue13());
			pStmt.setString(++ct, po.getAsRepVal14());
			pStmt.setString(++ct, po.getValue14());
			pStmt.setString(++ct, po.getAsRepVal15());
			pStmt.setString(++ct, po.getValue15());
			pStmt.setString(++ct, po.getAsRepVal16());
			pStmt.setString(++ct, po.getValue16());
			pStmt.setString(++ct, po.getAsRepVal7());
			pStmt.setString(++ct, po.getValue17());
			pStmt.setString(++ct, po.getAsRepVal18());
			pStmt.setString(++ct, po.getValue18());
			pStmt.setString(++ct, po.getAsRepVal19());
			pStmt.setString(++ct, po.getValue19());
			pStmt.setString(++ct, po.getAsRepVal20());
			pStmt.setString(++ct, po.getValue20());
			pStmt.setInt(++ct, 3);
			pStmt.setString(++ct, "C");
			pStmt.setString(++ct, "N");
			pStmt.setString(++ct, "N");
			pStmt.setString(++ct, po.getBreakups());
			if(po.getPrevHeader()!=null && po.getPrevHeader().equalsIgnoreCase("Y"))	
			{
				pStmt.setString(++ct,"PREV-HEADER") ;
			}
			else
			{
				if(po.getAsRepLabel()!=null && po.getAsRepLabel().startsWith("STATEMENT") )
					pStmt.setString(++ct,"ATTR");
				else
					if(section.equalsIgnoreCase("SUPPL"))
					{

						if(po!=null && po.getPoRef()!=null && po.getPoRef().getSubSection()!=null)
						{
							if(!((po.getIsHeading()!=null && po.getIsHeading().equalsIgnoreCase("Y")) ||  (po.getType()!=null && po.getType().equalsIgnoreCase("HEADER"))))
								pStmt.setString(++ct, po.getPoRef().getSubSection().toUpperCase());
							else
								pStmt.setString(++ct, "HEADER");

						}
						else
							pStmt.setString(++ct, po.getSubSection());

					}
					else
					{
						pStmt.setString(++ct,po.getSubSection());
					}
			}


			pStmt.setLong(++ct,  po.getPageNo()+1);


			float height = 0.0f;
			/*if(pageParsesMap!=null)
			{
				System.out.println(po.getAsRepLabel());
				if(pageParsesMap.get(po.getPageNo())!=null && pageParsesMap.get(po.getPageNo()).getPage()!=null)
				{
					height = pageParsesMap.get(po.getPageNo()).getPage().getMediaBox().getHeight();

				}
			}*/
			if(po.getPdfLine()!=null && pageParsesMap!=null)
			{
				/*System.out.println("height "+height);
				System.out.println("Y2 "+po.getPdfLine().getY2()+"\n");
				System.out.println("Media Box "+  pageParsesMap.get(po.getPageNo()).getPage().getMediaBox().getHeight());
				System.out.println("New Y coord "+ (po.getPdfLine().getY2()-pageParsesMap.get(po.getPageNo()).getPageBlocks().get(0).getY1()) );
				 */
				if(height!=0.0f)
				{
					pStmt.setFloat(++ct,(po.getPdfLine().getY2()-pageParsesMap.get(po.getPageNo()).getPageBlocks().get(0).getY1()));
				}
				else
				{
					pStmt.setFloat(++ct,(po.getPdfLine().getY1()));

				}
			}
			else
			{
				if(po.getyCoords()!=null && pageParsesMap!=null)
				{
					if(height!=0.0f)
					{
						pStmt.setFloat(++ct, (po.getyCoords()-pageParsesMap.get(po.getPageNo()).getPageBlocks().get(0).getY1()));
					}
					else
					{
						pStmt.setFloat(++ct,(po.getyCoords()));

					}
				}
				else
					pStmt.setString(++ct, null);
			}


			if(po.getTableID()!=null)
				pStmt.setInt(++ct, po.getTableID());
			else
				pStmt.setString(++ct, null);

			pStmt.setString(++ct, "N");
			pStmt.setString(++ct, po.getFiID());

			pStmt.setString(++ct, po.getFiLabel());
			pStmt.setString(++ct, po.getNiItem());
			pStmt.setString(++ct, po.getNilLabel());
			pStmt.setString(++ct, po.getNonEnglishLabel());
			pStmt.setString(++ct, "N");
			pStmt.setString(++ct, po.getBreakupExtracted());
			long refID=-1;
			/*if(poRef!=null)
				refID=poRef.getPoID();*/

			if(po!=null && po.getPoRef()!=null && po.getBreakups().equalsIgnoreCase("Y"))
			{
				String po_ID =null;
				try {
					po_ID = Long.toString(po.getPoRef().getPoID());
				} catch (Exception e) {
				
				}
				if (po_ID != null){
					refID=po.getPoRef().getPoID();		
				}
				
			}
			pStmt.setLong(++ct, refID);
			if( po.getNotesColumn()!=null)
				pStmt.setString(++ct, po.getNotesColumn());
			else
				pStmt.setString(++ct, null);			
			pStmt.executeUpdate();
			if(pStmt!=null)
				pStmt.close();
		} catch (SQLException e2) {

			e2.printStackTrace();
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava((sqlRow)));
				logger.error(StringEscapeUtils.escapeJava((e2.getMessage())));
			}
		}
	}

	private  void insertCoordinates(int docID, Connection con,
			ParserOutput po, long poID,String section) {
		String sqlCoordRow = "insert into PO_CORD_HIGHLIGHT_DETAILS (filing_id,po_id,po_section,POCH_ID,CORD_DETAILS_VAL1,CORD_DETAILS_VAL2,CORD_DETAILS_VAL3,CORD_DETAILS_VAL4,CORD_DETAILS_VAL5,CORD_DETAILS_VAL6,CORD_DETAILS_VAL7,CORD_DETAILS_VAL8,CORD_DETAILS_VAL9,CORD_DETAILS_VAL10) values ("+
				"?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement pStmt1 = null;
		int ct =0;
		try
		{
			pStmt1 = con.prepareStatement(sqlCoordRow);
			pStmt1.setLong(++ct,docID);
			pStmt1.setLong(++ct,poID);
			pStmt1.setString(++ct, section.toUpperCase());
			pStmt1.setLong(++ct, getID(con));
			pStmt1.setString(++ct, po.getVal1Coords());
			pStmt1.setString(++ct, po.getVal2Coords());
			pStmt1.setString(++ct, po.getVal3Coords());
			pStmt1.setString(++ct, po.getVal4Coords());
			pStmt1.setString(++ct, po.getVal5Coords());
			pStmt1.setString(++ct, po.getVal6Coords());
			pStmt1.setString(++ct, po.getVal7Coords());
			pStmt1.setString(++ct, po.getVal8Coords());
			pStmt1.setString(++ct, po.getVal9Coords());
			pStmt1.setString(++ct, po.getVal10Coords());
			pStmt1.executeUpdate();
			if(pStmt1!=null)
				pStmt1.close();

		}catch(Exception e)
		{

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sqlCoordRow));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
			if(pStmt1!=null)
				try {
					pStmt1.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
	}


	/*private void checkQuery(String sqlRow) {
		String patternStr ="[\\\\/:*<>|]";
		Pattern pt = Pattern.compile(patternStr);
		Matcher matcher = pt.matcher(sqlRow);

		while (matcher.find())  {
			if(logger!=null)
				logger.info(StringEscapeUtils.escapeJava("Unknown Characters found in command"));
			System.exit(-1);
		}
	}*/

	/**
	 * Get store extractor run properties
	 *
	 * @param dbRef
	 * @param stmtID
	 * @return
	 */
	public boolean getRunProperties(Connection con, String stmtID,DBConnection dbRef)
	{
		if( DEBUG )
		{
			System.out.println("Inside getRunProperties");
		}
		String name="", value="";

		PreparedStatement pStmt= null;

		String sql="select erp_property_name, erp_property_value " +
				"from extractor_run_properties where filing_id=? order by erp_sort_order asc";
		try
		{	
			pStmt = con.prepareStatement(sql);
			pStmt.setString(1, stmtID);

			ResultSet rs  = pStmt.executeQuery();
			while (rs.next())
			{
				name=rs.getString("erp_property_name");
				value=rs.getString("erp_property_value");
				dbRef.getPropertyName().add(name);
				dbRef.getPropertyValue().add(value);
			}
		}
		catch (SQLException e)
		{
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}


		if (dbRef.getPropertyName().size()>0)
			return true;
		else
			return false;
	}


	/**
	 * Set default extractor run properties
	 *
	 * @param dbRef
	 * @param stmtID
	 */
	public synchronized void  setRunProperties(DBConnection dbRef,String stmtID,Connection con)
	{
		String name="", value="", sql="";
		PreparedStatement pStmt = null;

		if( DEBUG )
		{
			System.out.println("Inside setRunProperties");
		}

		if (dbRef.getPropertyName().size()>0)
		{
			for(int i=0; i<dbRef.getPropertyName().size(); i++)
			{
				name=dbRef.getPropertyName().get(i);
				value=dbRef.getPropertyValue().get(i);
				sql="insert into extractor_run_properties (filing_id, erp_date, erp_property_name,  erp_property_value, erp_id,created_by, created_date) values (?,CURRENT_TIMESTAMP(6),?,?,SEQ_EXTRACTOR_RUN_PROPERTIES.NEXTVAL,?,CURRENT_TIMESTAMP(6))";
				try {
					pStmt = con.prepareStatement(sql);
					pStmt.setInt(1, Integer.parseInt(stmtID));
					pStmt.setString(2,name);
					pStmt.setString(3,value);
					pStmt.setString(4,"Extraction");
					pStmt.executeUpdate();
					if(pStmt!=null)
						pStmt.close();
				} catch (NumberFormatException e) {
					if (logger!=null)
					{
						logger.error(StringEscapeUtils.escapeJava((sql)));
						logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
					}
				} catch (SQLException e) {
					if (logger!=null)
					{
						logger.error(StringEscapeUtils.escapeJava((sql)));
						logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
					}
				}
			}
		}

		for(int i=0;i<FinancialStatementExtractor.getProcessingScope().size();i++)
		{
			name = FinancialStatementExtractor.getProcessingScope().get(i);
			sql="insert into extractor_run_properties (filing_id, erp_date, erp_property_name,  erp_id,created_by, created_date) values (?,CURRENT_TIMESTAMP(6),?,SEQ_EXTRACTOR_RUN_PROPERTIES.NEXTVAL,?,CURRENT_TIMESTAMP(6))";
			try {
				pStmt = con.prepareStatement(sql);
				pStmt.setInt(1, Integer.parseInt(stmtID));
				pStmt.setString(2,name);
				pStmt.setString(3,"Extraction");
				pStmt.executeUpdate();
				if(pStmt!=null)
					pStmt.close();
			} catch (NumberFormatException e) {
				if (logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava((sql)));
					logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
				}
			} catch (SQLException e) {
				if (logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava((sql)));
					logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
				}
			}
		}
	}



	/**
	 * Delete prior extracted data of specified statement
	 *
	 * @param stmtID
	 * @return boolean
	 */
	public synchronized boolean deleteRunProperties(String stmtID, Connection con)
	{

		if( DEBUG )
		{
			System.out.println("Inside deleteRunProperties");
		}
		PreparedStatement pStmt = null;
		String sql = "";
		try
		{
			if(con!=null)
			{
				con.setAutoCommit(false);
				sql = "delete from extractor_run_properties where filing_id = ? ";
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1,stmtID);

				pStmt.executeUpdate();
				if(pStmt!=null)
					pStmt.close();

				if(con!=null)
				{
					con.commit();
				}

				return true;
			}
			else
			{
				logger.error(StringEscapeUtils.escapeJava("Connection is null"));
				return false;
			}
		} catch (SQLException e)
		{
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava((sql)));
				logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
			}
		}
		try {
			if(con!=null)
			{
				con.commit();
			}
		} catch (SQLException e) {
			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava((sql)));
				logger.error(StringEscapeUtils.escapeJava((e.getMessage())));
			}
		}
		return false;
	}

	private synchronized void DeleteRule(Connection con)
	{
		//.	Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "";
		//con = DBConnection.openConnection("RAGE");
		try {
			sql = "delete from pdf_extraction_metadata where pem_filingid = ? and pem_section = ?";
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			System.out.println(e1);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e1.getMessage()));
			}
		}
		for(String section:FinancialStatementExtractor.getProcessingScope())
		{
			try
			{
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1,FinancialStatementExtractor.getDocID());
				pStmt.setString(2, section);
				pStmt.executeUpdate();

				if(pStmt!=null)
					pStmt.close();
			} catch (SQLException e)
			{
				System.out.println(e);

				if(logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava("sql "+sql));
					logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
				}
			}
			try {
				if(con!=null)
				{
					con.commit();

				}
			} catch (SQLException e) {
				System.out.println(e);

				if(logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava("sql "+sql));
					logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
				}
			}

		}
	}


	private synchronized void DeleteSectionType(Connection con)
	{
		//.	Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "";
		//con = DBConnection.openConnection("RAGE");
		try {
			sql = "delete from sectiontype where filing_id = ? and section = ?";
			con.setAutoCommit(false);
		} catch (SQLException e1) {
			System.out.println(e1);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e1.getMessage()));
			}
		}
		for(String section:FinancialStatementExtractor.getProcessingScope())
		{
			try
			{
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1,FinancialStatementExtractor.getDocID());
				pStmt.setString(2, section);
				pStmt.executeUpdate();
				if(pStmt!=null)
					pStmt.close();
			} catch (SQLException e)
			{
				System.out.println(e);

				if(logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava("sql "+sql));
					logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
				}
			}
			try {
				if(con!=null)
				{
					con.commit();

				}
			} catch (SQLException e) {
				System.out.println(e);

				if(logger!=null)
				{
					logger.error(StringEscapeUtils.escapeJava("sql "+sql));
					logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
				}
			}

		}
	}



	public synchronized void insertRuletoDB(List<ReprocessMetadata> extractorRoute)
	{
		Connection con = null;
		PreparedStatement pStmt = null;

		String filingId = FinancialStatementExtractor.getDocID();
		String sql = "insert into pdf_extraction_metadata (pem_pid,pem_filingID,pem_section,pem_begin_pageNo,pem_begin_keyword,pem_end_pageNo,pem_end_keyword,create_date,created_by,pem_value_order,pem_table_id,pem_eid,pem_row_segmentation_type,pem_column_number_to_split,pem_scope,pem_subsection) "+
				"values(?,?,?,?,?,?,?,CURRENT_TIMESTAMP(6),?,?,?,?,?,?,?,?)";
		con = DBConnection.openConnection("RAGE");
		DeleteRule(con);
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				int ct=0;
				int count =0;
				for(ReprocessMetadata route : extractorRoute)
				{
					count =0;

					if(route.getSection().trim().equalsIgnoreCase("SD"))
						continue;
					try {
						ct++;
						int strtPage = -1,endPage =-1;
						if(!route.getSection().trim().equalsIgnoreCase("SUPPL"))
						{
							if(route.getStrtPage()!=null)
							{
								strtPage = route.getStrtPage()+1;
							}
							if(route.getEndPage()!=null)
							{
								endPage = route.getEndPage()+1;
							}
						}
						else
						{

							if(route.getStrtPage()!=null)
							{
								strtPage = route.getStrtPage();
							}
							if(route.getEndPage()!=null)
							{
								endPage = route.getEndPage();
							}

						}


						pStmt = con.prepareStatement(sql);
						pStmt.setLong(++count, getPID(con));
						pStmt.setString(++count, filingId);
						pStmt.setString(++count, route.getSection().toUpperCase());
						pStmt.setLong(++count, strtPage);
						if(route.getStrtKeyword()!=null)
							pStmt.setString(++count, route.getStrtKeyword().replace("[", "").replace("]", "").replaceAll(",", ""));
						else
							pStmt.setString(++count, route.getStrtKeyword());
						pStmt.setLong(++count, endPage);
						if(route.getEndKeyword()!=null)
							pStmt.setString(++count,  route.getEndKeyword().replace("[", "").replace("]", "").replaceAll(",", ""));
						else
							pStmt.setString(++count, route.getEndKeyword());
						pStmt.setString(++count, "3");
						pStmt.setInt(++count, ct);
						if(route.getInstanceID()!=null)
							pStmt.setInt(++count, route.getInstanceID());
						else
							pStmt.setInt(++count, 1);
						pStmt.setString(++count,FinancialStatementExtractor.getCompanyID());
						pStmt.setString(++count,route.getRowSegmentationType()+"");
						if(route.getColumnNo()==null)
							pStmt.setString(++count,0+"");
						else
							pStmt.setString(++count,route.getColumnNo()+"");

						if(route.getParseValue()!=null)
						{
							pStmt.setString(++count,route.getScope()+","+route.getParseValue());
						}
						else
						{

							if(route.getScope()!=null )
							{
								pStmt.setString(++count,route.getScope());
							}
							else
								pStmt.setString(++count,null);
						}
						if(route.getSubSection()!=null)
						{
							pStmt.setString(++count,route.getSubSection());
						}
						else
							pStmt.setString(++count,null);

						pStmt.executeUpdate();

					} 
					catch (SQLException e) 
					{
						if(logger!=null)
						{
							logger.error("sql "+sql);
							logger.error(e.getMessage());
						}
					} 
					finally {

						if (pStmt!=null)
						{
							pStmt.close();
						}
					}
				}
			}catch(Exception e)
			{

				if(logger!=null)
				{
					logger.error("sql "+sql);
					logger.error(e.getMessage());
				}

			}

			finally {
				try {
					if (pStmt!=null)
					{
						pStmt.close();
					}
					if (con!=null)
					{
						con.commit();
						con.close();
					}
				} catch (SQLException e) {
					if(logger!=null)
					{
						logger.error("sql "+sql);
						logger.error(e.getMessage());
					}
				}

			}
		}

	}



	public synchronized List<ReprocessMetadata> loadMetaData(String section,String isSupplData)
	{
		Connection con = null;
		PreparedStatement pStmt = null;
		String filingId = FinancialStatementExtractor.getDocID();
		//String sql = "select  pem_section,pem_begin_pageNo,pem_begin_keyword,pem_end_pageNo,pem_end_keyword,pem_table_id from pdf_extraction_metadata where pem_filingID =? and pem_section= ? order by pem_value_order";
		String sql = "select  pem_section,pem_begin_pageNo,pem_begin_keyword,pem_end_pageNo,pem_end_keyword,pem_table_id,pem_row_segmentation_type,pem_column_number_to_split,pem_scope,pem_subsection from pdf_extraction_metadata where pem_filingID =? and pem_section= ? order by pem_value_order";

		List<ReprocessMetadata> extractorRoute = new ArrayList<ReprocessMetadata>();
		ResultSet rs = null;
		con = DBConnection.openConnection("RAGE");
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1, filingId);
				pStmt.setString(2, section);

				rs = pStmt.executeQuery();
				while (rs.next())
				{
					ReprocessMetadata er = new ReprocessMetadata();

					if((rs.getString("pem_subsection")==null && rs.getString("pem_scope")==null && isSupplData.equalsIgnoreCase("Yes")) || ((rs.getString("pem_subsection")!=null || rs.getString("pem_scope")!=null) && isSupplData.equalsIgnoreCase("No")))
					{
						continue;
					}

					if((rs.getString("pem_section"))!=null)
						er.setSection((rs.getString("pem_section")));
					if((rs.getString("pem_begin_pageNo"))!=null)
						er.setStrtPage(new Integer(rs.getInt("pem_begin_pageNo")-1));
					if(rs.getString("pem_begin_keyword")!=null)
					{
						er.setStrtKeyword(AccentsRemover.removeAccents(rs.getString("pem_begin_keyword")));
						/*	String original = rs.STring("pem_begin_keyword")
						byte[] utf8Bytes = original.getBytes("UTF-8");
					    byte[] defaultBytes = original.getBytes();

					    String roundTrip = new String(utf8Bytes, "UTF-8");
					    System.out.println("roundTrip = " + roundTrip);
					    System.out.println();*/

					}

					if((rs.getString("pem_end_pageNo"))!=null)
						er.setEndPage(new Integer(rs.getInt("pem_end_pageNo"))-1);
					if((rs.getString("pem_end_keyword"))!=null)
					{
						er.setEndKeyword(( AccentsRemover.removeAccents(rs.getString("pem_end_keyword"))));
						// AccentsRemover.removeAccents(split[1])
					}
					if((rs.getString("pem_table_id"))!=null)
						er.setInstanceID(new Integer(rs.getInt("pem_table_id")));
					if(rs.getString("pem_row_segmentation_type")!=null && !(rs.getString("pem_row_segmentation_type").trim().equals("null")))
						er.setRowSegmentationType(RowSegmentationType.valueOf(rs.getString("pem_row_segmentation_type").trim()));
					if((rs.getString("pem_column_number_to_split"))!=null)
						er.setColumnNo(new Integer(rs.getString("pem_column_number_to_split").trim()));
					if((rs.getString("pem_scope"))!=null)
					{
						String scope=rs.getString("pem_scope").trim();
						String parseValue=null;
						if(scope.contains(","))
						{
							String[] scopes=scope.split(",");
							scope = scopes[0].trim();
							parseValue  = scopes[1].trim();
						}
						er.setScope(scope);
						er.setParseValue(parseValue);
					}
					if((rs.getString("pem_subsection"))!=null)
						er.setSubSection(rs.getString("pem_subsection"));
					extractorRoute.add(er);
				}

			} catch (SQLException e)
			{
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}

			try {
				if(rs!=null)
					rs.close();

				if(pStmt!=null)
					pStmt.close();
				if(con!=null)
				{
					con.commit();
					con.close();
				}
			} catch (SQLException e) {
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}
		}
		return extractorRoute;
	}


	public synchronized void updateMetadData(String section)
	{
		Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "update pdf_extraction_metadata set pem_eid = null where pem_eid= ? and  pem_section= ?";
		con = DBConnection.openConnection("RAGE");
		try {
			con.setAutoCommit(false);
			pStmt = con.prepareStatement(sql);
			pStmt.setString(1, FinancialStatementExtractor.getCompanyID());
			pStmt.setString(2, section);
			pStmt.executeUpdate();
		} catch (SQLException e)
		{
			if (logger!=null)
			{
				logger.error(sql);
				logger.error(e.getMessage());
			}
		}

		try {
			if(pStmt!=null)
				pStmt.close();
			if(con!=null)
			{
				con.commit();
				con.close();
			}
		} catch (SQLException e) {
			if (logger!=null)
			{
				logger.error(sql);
				logger.error(e.getMessage());
			}
		}

		return;
	}
	public synchronized List<ReprocessMetadata> loadMetaDataEntitywise(String section, String isSupplData)
	{
		Connection con = null;
		PreparedStatement pStmt = null;
		//String filingId = FinancialStatementExtractor.getDocID();
		String sql = "select  pem_section,pem_begin_pageNo,pem_begin_keyword,pem_end_pageNo,pem_end_keyword,pem_table_id,pem_row_segmentation_type,pem_column_number_to_split,pem_scope,pem_subsection from pdf_extraction_metadata where  pem_EID =?  and pem_section= ? order by pem_value_order";

		//String sql = "select  pem_section,pem_begin_pageNo,pem_begin_keyword,pem_end_pageNo,pem_end_keyword,pem_table_id from pdf_extraction_metadata where pem_EID =? and pem_section= ? order by pem_value_order";
		List<ReprocessMetadata> extractorRoute = new ArrayList<ReprocessMetadata>();
		ResultSet rs = null;
		con = DBConnection.openConnection("RAGE");
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1, FinancialStatementExtractor.getCompanyID());
				pStmt.setString(2, section);

				rs = pStmt.executeQuery();
				while (rs.next())
				{
					ReprocessMetadata er = new ReprocessMetadata();

					if((rs.getString("pem_subsection")==null && rs.getString("pem_scope")==null && isSupplData.equalsIgnoreCase("Yes")) || ((rs.getString("pem_subsection")!=null || rs.getString("pem_scope")!=null) && isSupplData.equalsIgnoreCase("No")))
					{
						continue;
					}

					if((rs.getString("pem_section"))!=null)
						er.setSection((rs.getString("pem_section")));
					if((rs.getString("pem_begin_pageNo"))!=null)
						er.setStrtPage(new Integer(rs.getInt("pem_begin_pageNo")-1));

					if(rs.getString("pem_begin_keyword")!=null)
					{
						er.setStrtKeyword(AccentsRemover.removeAccents(rs.getString("pem_begin_keyword")));
						/*	String original = rs.STring("pem_begin_keyword")
						byte[] utf8Bytes = original.getBytes("UTF-8");
					    byte[] defaultBytes = original.getBytes();

					    String roundTrip = new String(utf8Bytes, "UTF-8");
					    System.out.println("roundTrip = " + roundTrip);
					    System.out.println();*/

					}

					if((rs.getString("pem_end_pageNo"))!=null)
						er.setEndPage(new Integer(rs.getInt("pem_end_pageNo"))-1);
					if((rs.getString("pem_end_keyword"))!=null)
					{
						er.setEndKeyword(( AccentsRemover.removeAccents(rs.getString("pem_end_keyword"))));
						// AccentsRemover.removeAccents(split[1])
					}
					/*if(rs.getString("pem_begin_keyword")!=null)
					{
						er.setStrtKeyword(rs.getString("pem_begin_keyword"));
							String original = rs.STring("pem_begin_keyword")
						byte[] utf8Bytes = original.getBytes("UTF-8");
					    byte[] defaultBytes = original.getBytes();

					    String roundTrip = new String(utf8Bytes, "UTF-8");
					    System.out.println("roundTrip = " + roundTrip);
					    System.out.println();

					}

					if((rs.getString("pem_end_pageNo"))!=null)
						er.setEndPage(new Integer(rs.getInt("pem_end_pageNo"))-1);
					if((rs.getString("pem_end_keyword"))!=null)
						er.setEndKeyword((rs.getString("pem_end_keyword")));*/
					if((rs.getString("pem_table_id"))!=null)
						er.setInstanceID(new Integer(rs.getInt("pem_table_id")));
					if(rs.getString("pem_row_segmentation_type")!=null && !(rs.getString("pem_row_segmentation_type").equals("null")))
						er.setRowSegmentationType(RowSegmentationType.valueOf(rs.getString("pem_row_segmentation_type")));
					if((rs.getString("pem_column_number_to_split"))!=null)
						er.setColumnNo(new Integer(rs.getString("pem_column_number_to_split")));
					if((rs.getString("pem_scope"))!=null)
					{
						String scope=rs.getString("pem_scope").trim();
						String parseValue=null;
						if(scope.contains(","))
						{
							String[] scopes=scope.split(",");
							scope = scopes[0].trim();
							parseValue  = scopes[1].trim();
						}
						er.setScope(scope);
						er.setParseValue(parseValue);
					}
					if((rs.getString("pem_subsection"))!=null)
						er.setSubSection(rs.getString("pem_subsection"));
					extractorRoute.add(er);
				}

			} catch (SQLException e)
			{
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}

			try {
				if(rs!=null)
					rs.close();

				if(pStmt!=null)
					pStmt.close();
				if(con!=null)
				{
					con.commit();
					con.close();
				}
			} catch (SQLException e) {
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}
		}
		return extractorRoute;
	}



	/*
	 *//**
	 * @param gpoRowList
	 *//*


	public boolean isNumber(String val)
	{
		String number=stripUnwanted(val,"$,-()% ");
		try
		{
			Double.parseDouble(number);
			return true;
		}
		catch (NumberFormatException e)
		{
			return false;
		}
	}*/

	/*
	 *//** Strips UnWanted Characters 
	 * 
	 * @param sourceString
	 * @param unwantedCharSeq
	 * @return
	 *//*
	private String stripUnwanted(String sourceString, String unwantedCharSeq)
	{
		String returnString="", tempString=sourceString;
		for (int s=0; s<unwantedCharSeq.length(); s++)
		{
			for (int k=0; k<tempString.length(); k++)
			{
				if (unwantedCharSeq.charAt(s)!=tempString.charAt(k))
					returnString += tempString.charAt(k);
			}
			tempString=returnString;
			returnString="";
		}
		returnString=tempString;
		return returnString;
	}*/

	/**
	 * Handle punctuation
	 *
	 * @param value
	 * @return
	 *//*
	public String handlePunctuations(String value)
	{
		value=value.replaceAll("'", "''");
		value=value.replaceAll("&", "'||'&'||'");
		return value;
	}*/

	/**
	 * Delete prior extracted data of specified statement
	 *
	 * @param stmtID
	 * @return boolean
	 */
	private synchronized boolean deleteParserOutput(int docID,Connection con,Boolean isMerge,Boolean isSplit)
	{
		PreparedStatement pStmt = null;
		String sql = "";
		try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {

		}
		try
		{
			if(!isMerge && !isSplit)
			{
				sql = "delete from parser_output where filing_id = ? and po_section in ('BS','CF','IS','SE','SUPPL') ";
				pStmt = con.prepareStatement(sql);
				pStmt.setLong(1,docID);
			}
			else

				if(isMerge)
				{

					sql = "delete from parser_output where filing_id = ? and po_merge = ? and po_section in ('BS','CF','IS','SE','SUPPL') ";

					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,"Y");
				}
				else
					if(isSplit)
					{

						sql = "delete from parser_output where filing_id = ? and po_split = ? and po_section in ('BS','CF','IS','SE','SUPPL') ";

						pStmt = con.prepareStatement(sql);
						pStmt.setLong(1,docID);
						pStmt.setString(2,"Y");
					}

			pStmt.executeUpdate();
			if(con!=null)
			{
				con.commit();

			}
			if(pStmt!=null)
				pStmt.close();
			return true;
		} catch (SQLException e)
		{
			System.out.println(e);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return false;
	}



	/**
	 * Delete prior extracted data of specified statement
	 *
	 * @param stmtID
	 * @return boolean
	 */
	private synchronized boolean deleteCoordValues(int docID,Connection con,Boolean isMerge,Boolean isSplit)
	{
		PreparedStatement pStmt = null;
		String sql = "";
		try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {

		}
		try
		{
			if(!isMerge && !isSplit)
			{
				sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ?";
				pStmt = con.prepareStatement(sql);
				pStmt.setLong(1,docID);
			}
			else
				if(isMerge)
				{
					sql = "select po_ID from parser_output where filing_id = ? and po_merge = ?";
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,"Y");
					final ResultSet rs = pStmt.executeQuery();
					String po_ids = "";
					int ct=0;
					while(rs.next())
					{
						if(rs.getString("PO_ID")!=null)
						{
							if(ct==0)
								po_ids +=rs.getString("PO_ID");
							else
								po_ids += ","+rs.getString("PO_ID");
							ct++;
						}
					}
					if(pStmt!=null)
						pStmt.close();

					sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ? and po_id in("+po_ids+")";
					System.out.print("delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id ="+docID+" and po_id in("+po_ids+")");
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					//	pStmt.setString(2,po_ids);
				}
				else
					if(isSplit)
					{
						sql = "select po_ID from parser_output where filing_id = ? and po_split = ?";
						pStmt = con.prepareStatement(sql);
						pStmt.setLong(1,docID);
						pStmt.setString(2,"Y");
						final ResultSet rs = pStmt.executeQuery();
						String po_ids = "";
						int ct=0;
						while(rs.next())
						{
							if(rs.getString("PO_ID")!=null)
							{
								if(ct==0)
									po_ids +=rs.getString("PO_ID");
								else
									po_ids += ","+rs.getString("PO_ID");
								ct++;
							}
						}
						if(pStmt!=null)
							pStmt.close();

						sql = "delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id = ? and po_id in(?)";
						System.out.print("delete from PO_CORD_HIGHLIGHT_DETAILS where filing_id ="+docID+" and po_id in("+po_ids+")");

						pStmt = con.prepareStatement(sql);
						pStmt.setLong(1,docID);
						pStmt.setString(2,po_ids);

					}

			pStmt.executeUpdate();
			if(con!=null)
			{
				con.commit();

			}
			if(pStmt!=null)
				pStmt.close();
			return true;
		} catch (SQLException e)
		{
			System.out.println(e);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return false;
	}

	/**
	 * Delete prior extracted data of specified statement
	 *
	 * @param stmtID
	 * @return boolean
	 */
	private synchronized boolean deleteParserOutput(int docID,Connection con,String section,Boolean isMerge,Boolean isSplit)
	{
		PreparedStatement pStmt = null;
		String sql = "";
		try {
			con.setAutoCommit(false);
		} catch (SQLException e1) {

		}
		try
		{
			if(!isMerge && !isSplit)
			{
				sql = "delete from parser_output where filing_id = ? and po_section=?";
				pStmt = con.prepareStatement(sql);
				pStmt.setLong(1,docID);
				pStmt.setString(2,section);
			}
			else
			{
				if(isMerge)
				{
					sql = "delete from parser_output where filing_id = ? and po_section=? and po_merge = ?";
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,section);
					pStmt.setString(3,"Y");
				}
				if(isSplit)
				{
					sql = "delete from parser_output where filing_id = ? and po_section=? and po_split = ?";
					pStmt = con.prepareStatement(sql);
					pStmt.setLong(1,docID);
					pStmt.setString(2,section);
					pStmt.setString(3,"Y");
				}
			}

			pStmt.executeUpdate();
			if(con!=null)
			{
				con.commit();

			}
			if(pStmt!=null)
				pStmt.close();
			return true;
		} catch (SQLException e)
		{
			System.out.println(e);

			if(logger!=null)
			{
				logger.error(StringEscapeUtils.escapeJava("sql "+sql));
				logger.error(StringEscapeUtils.escapeJava(e.getMessage()));
			}
		}
		return false;
	}


	public Map<String, Map<String, String>> getSectionMap() {
		return sectionMap;
	}


	public void setSectionMap(Map<String, Map<String, String>> sectionMap) {
		this.sectionMap = sectionMap;
	}

	public static Map<String, String> getMappings(String language) {
		Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "select english_label,non_english_label from language_mapping_metadata where  language =? ";

		Map<String,String> mappings = new HashMap<String,String>();
		ResultSet rs = null;
		con = DBConnection.openConnection("LIVESPREAD");
		String englishLabel="";
		String nonEnglishLabel="";
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1, language);

				rs = pStmt.executeQuery();
				while (rs.next())
				{
					if((rs.getString("english_label"))!=null)
					{
						englishLabel = (rs.getString("english_label")).trim();
					}
					if((rs.getString("non_english_label"))!=null)
					{
						nonEnglishLabel = (rs.getString("non_english_label")).trim();
					}
					if(nonEnglishLabel!=null && !nonEnglishLabel.equalsIgnoreCase(""))
					{
						nonEnglishLabel = AccentsRemover.removeAccents(nonEnglishLabel).toLowerCase();
						if(!mappings.containsKey(nonEnglishLabel))
							mappings.put(nonEnglishLabel, englishLabel);
					}
				}

			} catch (SQLException e)
			{
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}

			try {
				if(rs!=null)
					rs.close();

				if(pStmt!=null)
					pStmt.close();
				if(con!=null)
				{
					con.commit();
					con.close();
				}
			} catch (SQLException e) {
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}
		}
		return mappings;
	}

	public static Integer getColumnNumber(Integer tableID, String filingID) {
		Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "select pem_column_number_to_split from pdf_extraction_metadata where pem_filingid = ?  and pem_table_id = ?";
		ResultSet rs = null;
		Integer colNo = -1;
		con = DBConnection.openConnection("RAGE");
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1, filingID);
				pStmt.setInt(2, tableID);

				rs = pStmt.executeQuery();
				while (rs.next())
				{
					if((rs.getString("pem_column_number_to_split"))!=null)
					{
						colNo = Integer.parseInt(rs.getString("pem_column_number_to_split").trim());
					}

				}
			}catch (SQLException e)
			{
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}
			try {
				if(rs!=null)
					rs.close();

				if(pStmt!=null)
					pStmt.close();
				if(con!=null)
				{
					con.commit();
					con.close();
				}
			} catch (SQLException e) {
				if (logger!=null)
				{
					logger.error(sql);
					logger.error(e.getMessage());
				}
			}
		}
		return colNo;
	}

	public void insertSectionTypestoDB(ArrayList<SectionType> sectionTypeList) {

		Connection con = null;
		PreparedStatement pStmt = null;

		//String filingId = FinancialStatementExtractor.getDocID();
		String sql = "insert into sectionType (ST_ID,filing_id,table_id,column_number,type,section,created_date,created_by) "+
				"values(?,?,?,?,?,?,CURRENT_TIMESTAMP,?)";
		con = DBConnection.openConnection("LIVESPREAD");
		/*try {
			pStmt = con.prepareStatement(sql);
		} catch (SQLException e) {
			if(logger!=null)
			{
				logger.error("sql "+sql);
				logger.error(e.getMessage());
			}
		}*/
		DeleteSectionType(con);
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				int count =0;
				for(SectionType sType : sectionTypeList)
				{
					count =0;

					if(sType.getSection().trim().equalsIgnoreCase("SD"))
						continue;

					try {
						pStmt = con.prepareStatement(sql);
						pStmt.setLong(++count, getSTID(con));
						pStmt.setInt(++count, sType.getFilingId());
						pStmt.setInt(++count, sType.getTableID());
						pStmt.setInt(++count, sType.getColNo());
						pStmt.setString(++count, sType.getType());
						pStmt.setString(++count, sType.getSection().toUpperCase());
						pStmt.setString(++count, "Extraction");
						pStmt.executeUpdate();
						if (pStmt!=null)
						{
							pStmt.close();
						}

					} 	
					catch (SQLException e) 
					{
						if(logger!=null)
						{
							logger.error("sql "+sql);
							logger.error(e.getMessage());
						}
					}
					catch (Exception e) 
					{
						if(logger!=null)
						{
							logger.error("sql "+sql);
							logger.error(e.getMessage());
						}
					} 
				}
			}catch(Exception e)
			{

				if(logger!=null)
				{
					logger.error("sql "+sql);
					logger.error(e.getMessage());
				}

			}

			finally {
				try {
					if (pStmt!=null)
					{
						pStmt.close();
					}
					if (con!=null)
					{
						con.commit();
						con.close();
					}
				} catch (SQLException e) {
					if(logger!=null)
					{
						logger.error("sql "+sql);
						logger.error(e.getMessage());
					}
				}

			}
		}


	}

	/*public static void insertSectionType(Section section, Integer colNo,
			Boolean subsidiary) {

		Connection con = null;
		PreparedStatement pStmt = null;
		String sql = "";
		ResultSet rs = null;
		Integer colNo = -1;
		con = DBConnection.openConnection("LIVESPREAD");
		if(con!=null)
		{
			try {
				con.setAutoCommit(false);
				pStmt = con.prepareStatement(sql);
				pStmt.setString(1, filingID);
				pStmt.setInt(2, section.get);
			}catch(EXception e)
			{

			}
		}
	}*/


}
