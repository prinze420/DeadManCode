﻿
package com.rage.extraction.statements.extract.pdf;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.pdf.utils.Pair;


public class FindContentPages {

	TreeMap<Integer, PageParse>	reportPages;

	List<Integer> contentpgNos	= new ArrayList<Integer>();
	
	Map<Integer,Map<Integer, List<String>>> pageNoContentMap = new LinkedHashMap<Integer, Map<Integer,List<String>>>();

	FindContentPages(TreeMap<Integer, PageParse> reportPages) {
		setReportPages(reportPages);
	}

	public void run ( )
	{
		for( int index = 0; index < reportPages.size(); index++ )
		{
			PageParse reportPage = reportPages.get(index);
			List<List<PDFChunk>> finalColumns = extractTocs(reportPage);

			boolean isTocPage = isPageTOC(finalColumns, index, reportPages);

			if(isTocPage)
			{
				isTocPage = checkTocForOtherConditions(finalColumns);
			}
			
			Map<Integer, List<String>> pageHeadingMap = new LinkedHashMap<Integer, List<String>>();
			Map<Integer, List<String>> pdPageHeadingMap = new LinkedHashMap<Integer, List<String>>();
			if( isTocPage )
			{
				pageHeadingMap = getContentPageNoMap(finalColumns);

				if( !pageHeadingMap.isEmpty() )
				{
					pdPageHeadingMap = findPDPageNosOfContent(pageHeadingMap, reportPages, index);
				}
				
				if(pdPageHeadingMap!=null && !pdPageHeadingMap.isEmpty())
				{
					getPageNoContentMap().put(index, pdPageHeadingMap);
				}
			}

			if( isTocPage ) getContentpgNos().add(index);
			
		}
	}

	private boolean checkTocForOtherConditions ( List<List<PDFChunk>> finalColumns )
	{
		for(List<PDFChunk> column : finalColumns)
		{
			int counter = 0;
			
			for(PDFChunk chunk : column)
			{
				boolean validNum = containsValidNumber(chunk);
				
				if(validNum)
				counter++;
			}
			
			if(counter > 3)
				return false;
			
		}
		return true;
	}

	private boolean containsValidNumber ( PDFChunk chunk )
	{
		String input = chunk.getChunk();
		
		if(input.trim().equalsIgnoreCase(""))
		{
			return false;
		}
		
		String numPattern1 = "([0-9]{1,3}[,])+([0-9]{1,3})";
		String numPattern2 = "([0-9]{1,3}[,]?)+([0-9]{0,3}[.])([0-9]{1,9})";
		
		List<String> patterns  = new ArrayList<String>(Arrays.asList(numPattern1,numPattern2));
		
		for(String eachPattern : patterns)
		{
			try
			{
				Pattern p = Pattern.compile(numPattern1);
				Matcher m = p.matcher(input);
				
				if(m.find())
				{
					return true;
				}
			}
			catch (Exception e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return false;
	}

	private Map<Integer, List<String>> findPDPageNosOfContent ( Map<Integer, List<String>> headingPageNoMap,
			TreeMap<Integer, PageParse> reportPages2, int i )
	{
		Map<Integer, List<String>> ret = getPDPageNosFromPageEnd(headingPageNoMap, reportPages2, i);
		Map<Integer, List<String>> treeMap = new TreeMap<Integer, List<String>>(ret);

		return treeMap;
	}

	private Map<Integer, List<String>> getPDPageNosFromPageEnd ( Map<Integer, List<String>> headingPageNoMap,
			TreeMap<Integer, PageParse> reportPages2, int i )
	{
		Map<Integer, List<String>> ret = new HashMap<Integer, List<String>>();

		int lastIndex = -1;
		int lastPageNo = -1;
		int foundPages = 0;
		for( int j = i + 1; j < reportPages.size(); j++ )
		{
			PageParse page = reportPages.get(j);
			List<PDFLine> lines = page.getPageLines();

			/***** find page num on last 4 lines *********/
			int lCounter = 0;
			int thisPageNo = -1;
			boolean found = false;
			for( int k = lines.size() - 1; k >= 0; k-- )
			{
				lCounter++;

				PDFLine line = lines.get(k);

				List<PDFChunk> chunks = line.getChunks();

				for( PDFChunk ch : chunks )
				{
					String str = ch.getChunk().replaceAll("�", "").trim();

					if( isNumber(str) )
					{
						thisPageNo = Integer.parseInt(str);
						found = true;
					}
				}

				if( lCounter > 3 || found ) break;
			}

			int thisIndex = 0;

			if( (lastPageNo > thisPageNo) )
			{
				continue;
			}

			if( headingPageNoMap.containsKey(thisPageNo) )
			{
				if( !ret.containsKey(j) ) ret.put(j, headingPageNoMap.get(thisPageNo));
			}

			/*
			 * if(lastIndex == -1)
			 * {
			 * if(pageNos.contains(thisPageNo))
			 * {
			 * thisIndex = pageNos.indexOf(thisPageNo);
			 * foundPages++;
			 * lastIndex = thisIndex;
			 * }
			 * }else
			 * {
			 * if(pageNos.contains(thisPageNo))
			 * {
			 * thisIndex = pageNos.indexOf(thisPageNo);
			 * if(thisIndex>lastIndex)
			 * {
			 * foundPages++;
			 * lastIndex = thisIndex;
			 * }
			 * }
			 * }
			 * if(foundPages>=4)
			 * return true;
			 */
		}
		return ret;
	}

	private Map<Integer, List<String>> getContentPageNoMap ( List<List<PDFChunk>> finalColumns )
	{
		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>();
		newColumns = removeUnwantedColumns(finalColumns);

		newColumns = sortColumnsOnY(newColumns);

		Map<String, List<Integer>> headingPageNoMap = new LinkedHashMap<String, List<Integer>>();
		Map<Integer, List<String>> pageNumHeadingMap = new LinkedHashMap<Integer, List<String>>();

		int colSize = newColumns.size();

		if( colSize == 4 )
		{
			Map<Integer, List<String>> eachMap = getHeadingPageNoMap(newColumns.get(0), newColumns.get(1));
			pageNumHeadingMap.putAll(eachMap);

			eachMap = getHeadingPageNoMap(newColumns.get(2), newColumns.get(3));
			pageNumHeadingMap.putAll(eachMap);
			
			for(Integer pgNo : eachMap.keySet())
			{
				if(pageNumHeadingMap.containsKey(pgNo))
				{
					pageNumHeadingMap.put(pgNo, eachMap.get(pgNo));
				}
			}
			//pageNumHeadingMap.putAll(eachMap);
		}
		if( colSize == 2 )
		{
			Map<Integer, List<String>> eachMap = getHeadingPageNoMap(newColumns.get(0), newColumns.get(1));
			pageNumHeadingMap.putAll(eachMap);
		}
		if( colSize == 3 )
		{
			newColumns = ignoreExtraColumn(newColumns);
			Map<Integer, List<String>> eachMap = getHeadingPageNoMap(newColumns.get(0), newColumns.get(1));
			pageNumHeadingMap.putAll(eachMap);
		}

		return pageNumHeadingMap;
	}

	private List<List<PDFChunk>> ignoreExtraColumn ( List<List<PDFChunk>> newColumns )
	{
		/*
		 * for(List<PDFChunk> col : newColumns)
		 * {
		 * String type = getColumnType(col);
		 * }
		 */

		newColumns.remove(0);

		return newColumns;
	}

	private String getColumnType ( List<PDFChunk> col )
	{
		int numCount = 0;
		int txtCount = 0;
		for( PDFChunk chunk : col )
		{
			if( isNumber(chunk.getChunk().trim()) )
			{
				numCount++;
			}
			else
			{
				txtCount++;
			}
		}

		if( numCount > txtCount ) return "number";

		return "text";
	}

	private List<List<PDFChunk>> sortColumnsOnY ( List<List<PDFChunk>> newColumns )
	{
		for( List<PDFChunk> col : newColumns )
		{
			Comparator<PDFChunk> cmp = new Comparator<PDFChunk>() {

				@Override
				public int compare ( PDFChunk o1, PDFChunk o2 )
				{
					if( o1.getY2() > o2.getY2() ) return 1;

					if( o1.getY2() < o2.getY2() ) return -1;

					return 0;
				}
			};

			Collections.sort(col, cmp);
		}

		return newColumns;
	}

	private Map<Integer, List<String>> getHeadingPageNoMap ( List<PDFChunk> list, List<PDFChunk> list2 )
	{
		// TODO : TO CHECK WHICH IS PAGE_NO COLUMN AMONG TWO COLUMNS.
		Map<String, List<Integer>> headingPageNoMap = new LinkedHashMap<String, List<Integer>>();
		Map<Integer, List<String>> pageNoHeadingMap = new LinkedHashMap<Integer, List<String>>();

		Float minGap = getSmallestGapBetweenpageNos(list2);
		PDFChunk noPageNumChunk = null;

		for( int i = 0; i < list.size(); i++ )
		{
			boolean foundPgNo = false;

			PDFChunk heading = list.get(i);
			String strHeading = heading.getChunk().trim();

			if( strHeading.replaceAll("[^A-Za-z]", "").trim().equalsIgnoreCase("") ) continue;

			for( int j = 0; j < list2.size(); j++ )
			{
				PDFChunk pageNo = list2.get(j);
				int pageNum = -1;
				if( Math.abs(heading.getY2() - pageNo.getY2()) < 0.5
						|| (heading.getY2() < pageNo.getY2() && heading.getY2() > pageNo.getY1())
						|| (Math.abs(heading.getY2() - pageNo.getY2()) < 2.0
								&& Math.abs(heading.getY1() - pageNo.getY1()) < 2.0) )
				{
					String pgStr = pageNo.getChunk().replaceAll("\u00A0", "").replaceAll("\\.", "").trim();
					if( isNumber(pgStr) )
					{
						pageNum = Integer.parseInt(pgStr);
					}

					if( pageNum == -1 ) continue;

					if( noPageNumChunk != null )
					{
						if( Math.abs(heading.getY2() - noPageNumChunk.getY2()) <= minGap )
						{
							strHeading = noPageNumChunk.getChunk().trim() + " " + strHeading.trim();
						}
						noPageNumChunk = null;
					}

					if( pageNoHeadingMap.containsKey(pageNum) )
					{
						pageNoHeadingMap.get(pageNum).add(strHeading);
						foundPgNo = true;
						noPageNumChunk = null;
					}
					else
					{
						List<String> headingList = new ArrayList<String>();
						headingList.add(strHeading);
						pageNoHeadingMap.put(pageNum, headingList);
						foundPgNo = true;
						noPageNumChunk = null;
					}

					/*
					 * if(headingPageNoMap.containsKey(strHeading))
					 * {
					 * }else
					 * {
					 * List<Integer> pgNo = new ArrayList<Integer>();
					 * pgNo.add(pageNum);
					 * headingPageNoMap.put(strHeading, pgNo);
					 * foundPgNo=true;
					 * noPageNumChunk=null;
					 * }
					 */
					break;
				}
			}

			if( !foundPgNo )
			{
				noPageNumChunk = heading;
			}
		}
		return pageNoHeadingMap;
	}

	private float getSmallestGapBetweenpageNos ( List<PDFChunk> list2 )
	{
		float minGap = 9999999f;

		for( int i = 0; i < list2.size() - 1; i++ )
		{
			PDFChunk firstChunk = list2.get(i);
			PDFChunk nextChunk = list2.get(i + 1);

			float gap = Math.abs(nextChunk.getY2() - firstChunk.getY2());

			if( minGap > gap )
			{
				minGap = gap;
			}
		}

		return minGap;
	}

	private static List<List<PDFChunk>> removeUnwantedColumns ( List<List<PDFChunk>> finalColumns )
	{
		// TODO : TO ADD SOME CODE TO REMOVE UNWANTED COLUMNS.

		List<List<PDFChunk>> NewColumns = new ArrayList<List<PDFChunk>>();

		for( int i = 0; i < finalColumns.size(); i++ )
		{
			List<PDFChunk> col = finalColumns.get(i);

			List<PDFChunk> newCol = new ArrayList<PDFChunk>();

			boolean isColIndex = isColumnIndex(col);

			if( isColIndex ) continue;

			for( PDFChunk chunk : col )
			{
				if( chunk.getChunk().trim().replaceAll("[^A-Za-z0-9]", "").equalsIgnoreCase("") )
				{
					continue;
				}

				String pattern = "\\d+\\s+]";
				Pattern p = Pattern.compile(pattern);
				Matcher m = p.matcher(chunk.getChunk().trim());

				if( m.matches() )
				{
					continue;
				}

				newCol.add(chunk);
			}

			if( newCol.size() < 3 ) continue;

			NewColumns.add(newCol);
		}
		return NewColumns;
	}

	private static boolean isColumnIndex ( List<PDFChunk> col )
	{
		try
		{
			int count = 0;
			for( int i = 0; i < col.size(); i++ )
			{
				if( col.get(i).getChunk().trim().equalsIgnoreCase(String.valueOf(i + 1)) ) // Ex:-
																							// 1,2,3,4,5
				{
					count++;
				}
				else
				{
					break;
				}
			}
			if( count > 3 ) return true;

			boolean ieSeq = isColumnCompletelySequential(col);
			if( ieSeq ) return true;

			count = 0;
			String[] pattern = new String[3];
			pattern[0] = "\\d+\\.(\\d+)?"; // ex:- 2., 2.3
			pattern[1] = "\\(\\d\\)";// Ex:- (2), (23)
			pattern[2] = "0\\d"; // ex:- 01,02,03
			List<String> patternList = Arrays.asList(pattern);

			for( int i = 0; i < col.size(); i++ )
			{
				for( String pat : patternList )
				{
					Pattern p = Pattern.compile(pat);
					Matcher m = p.matcher(col.get(i).getChunk().trim());

					if( m.matches() )
					{
						count++;
						break;
					}
				}
			}

			int oneFourthSize = col.size() / 4;

			if( count >= (oneFourthSize * 3) ) return true;
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return false;
	}

	private static boolean isColumnCompletelySequential ( List<PDFChunk> col )
	{
		int value = 0;
		for( int i = 0; i < col.size(); i++ )
		{
			if( !isNumber(col.get(i).getChunk().trim()) ){ return false; }

			if( i == 0 )
			{
				value = Integer.parseInt(col.get(i).getChunk().trim());
			}
			else
			{
				value = value + 1;

				if( !(value == Integer.parseInt(col.get(i).getChunk().trim())) ) return false;
			}
		}
		return true;
	}

	private static List<List<PDFChunk>> extractTocs ( PageParse reportPage )
	{
		List<PDFLine> body = getBodyOfPage(reportPage);

		body = FilterLines(body);

		HashMap<PDFChunk, PDFLine> chunkLineMap = new HashMap<PDFChunk, PDFLine>();
		for( int i = 0; i < body.size(); i++ )
		{
			PDFLine line = body.get(i);
			for( int j = 0; j < line.getChunks().size(); j++ )
			{
				PDFChunk chunk = line.getChunks().get(j);
				chunkLineMap.put(chunk, line);
			}
		}

		List<List<PDFChunk>> finalColumns = doSimpleSpreading(body);

		// System.out.println("done with simple spreading..");

		return finalColumns;
	}

	private static List<PDFLine> getBodyOfPage ( PageParse reportPage )
	{
		List<PDFLine> pageLines = reportPage.getPageLines();

		List<PDFLine> bodyLines = new ArrayList<PDFLine>();
		List<PDFLine> restLines = new ArrayList<PDFLine>();

		boolean contentHeader = false;
		for( PDFLine line : pageLines )
		{
			if( contentHeader )
			{
				bodyLines.add(line);
			}

			List<PDFChunk> chunks = line.getChunks();

			for( PDFChunk ch : chunks )
			{
				if( ch.getChunk().trim().toLowerCase().contains("table of content")
						|| ch.getChunk().trim().toLowerCase().contains("content")
						|| ch.getChunk().trim().toLowerCase().contains("index") )
				{
					contentHeader = true;
				}
			}
			restLines.add(line);
		}

		if( !bodyLines.isEmpty() ) return bodyLines;

		return restLines;

	}

	private static List<List<PDFChunk>> doSimpleSpreading ( List<PDFLine> body )
	{
		List<List<PDFChunk>> columns = new ArrayList<List<PDFChunk>>();
		List<Pair<Float, Float>> bounds = new ArrayList<Pair<Float, Float>>();
		for( PDFLine line : body )
		{
			List<PDFChunk> chunks = line.getChunks();
			for( PDFChunk chunk : chunks )
			{
				Pair<Float, Float> chunkBounds = computeChunkBounds(chunk);

				boolean found = false;
				for( int i = 0; i < columns.size(); i++ )
				{
					Pair<Float, Float> columnBounds = bounds.get(i);

					boolean overlap = true;
					if( chunkBounds.getA().floatValue() > columnBounds.getB().floatValue()
							|| chunkBounds.getB().floatValue() < columnBounds.getA().floatValue() )
						overlap = false;

					if( !overlap ) continue;

					found = true;
					columns.get(i).add(chunk);

					float min = chunkBounds.getA().floatValue() < columnBounds.getA().floatValue()
							? chunkBounds.getA().floatValue() : columnBounds.getA().floatValue();
					float max = chunkBounds.getB().floatValue() > columnBounds.getB().floatValue()
							? chunkBounds.getB().floatValue() : columnBounds.getB().floatValue();
					bounds.set(i, new Pair<Float, Float>(min, max));
					break;
				}

				if( found ) continue;

				List<PDFChunk> newColumn = new ArrayList<PDFChunk>();
				newColumn.add(chunk);
				columns.add(newColumn);

				bounds.add(chunkBounds);
			}
		}

		List<List<PDFChunk>> newColumns = new ArrayList<List<PDFChunk>>();
		List<Pair<Float, Float>> newBounds = new ArrayList<Pair<Float, Float>>();
		for( int i = 0; i < columns.size(); i++ )
		{
			Pair<Float, Float> bound = bounds.get(i);

			boolean found = false;
			for( int j = 0; j < newColumns.size(); j++ )
			{
				Pair<Float, Float> newBound = newBounds.get(j);

				boolean overlap = true;
				if( bound.getA().floatValue() > newBound.getB().floatValue()
						|| bound.getB().floatValue() < newBound.getA().floatValue() )
					overlap = false;

				if( !overlap ) continue;

				found = true;
				newColumns.get(j).addAll(columns.get(i));

				float min = bound.getA().floatValue() < newBound.getA().floatValue() ? bound.getA().floatValue()
						: newBound.getA().floatValue();
				float max = bound.getB().floatValue() > newBound.getB().floatValue() ? bound.getB().floatValue()
						: newBound.getB().floatValue();

				if( newBounds.size() > i ) newBounds.set(i, new Pair<Float, Float>(min, max));
				else
					newBounds.add(new Pair<Float, Float>(min, max));

				break;
			}

			if( found ) continue;

			List<PDFChunk> newColumn = new ArrayList<PDFChunk>();
			newColumn.addAll(columns.get(i));
			newColumns.add(newColumn);

			newBounds.add(bound);
		}

		List<List<PDFChunk>> sortedColumns = new ArrayList<List<PDFChunk>>();
		TreeMap<Float, List<List<PDFChunk>>> xColumnsMap = new TreeMap<Float, List<List<PDFChunk>>>();
		for( int i = 0; i < newColumns.size(); i++ )
		{
			List<PDFChunk> column = newColumns.get(i);
			String str = "";
			for( int j = 0; j < column.size(); j++ )
				str = str.trim() + column.get(j).getChunk().trim();
			str = str.trim();

			if( str.equalsIgnoreCase("") ) continue;

			Float x = newBounds.get(i).getA();

			List<List<PDFChunk>> thisXColumns = xColumnsMap.containsKey(x) ? xColumnsMap.get(x)
					: new ArrayList<List<PDFChunk>>();
			thisXColumns.add(column);
			xColumnsMap.put(x, thisXColumns);
		}

		for( Float x : xColumnsMap.keySet() )
			sortedColumns.addAll(xColumnsMap.get(x));

		return sortedColumns;

	}

	private static boolean isPageTOC ( List<List<PDFChunk>> finalColumns, int i,
			TreeMap<Integer, PageParse> reportPages )
	{
		System.out.println("\nChecking whether the page "+i+" contains TOC");

		if( finalColumns == null || finalColumns.isEmpty() || finalColumns.size() < 2 ) return false;

		finalColumns = removeUnwantedColumns(finalColumns);

		List<PDFChunk> pageNoColumn = getPageNumberColumn(finalColumns);

		if( !pageNoColumn.isEmpty() ) System.out.println("pageNoCloumnFound : " + true);

		List<Integer> pageNos = new ArrayList<Integer>();

		for( PDFChunk chunk : pageNoColumn )
		{
			String str = chunk.getChunk().replaceAll("\u00A0", "").trim();

			int blen = str.length();

			// to avoide numbers like 1.2 1.3 which are not valid caontent
			if( str.replaceAll("\\d+\\.\\d+", "").trim().length() == blen )
			{
				str = str.replaceAll("\\.", "").trim();
			}

			if( isNumber(str) )
			{
				pageNos.add(Integer.parseInt(str));
			}
		}

		boolean foundPageNos = findOnPages(pageNos, reportPages, i);

	 System.out.println("\nTOC Page nos found = "+foundPageNos);

		return foundPageNos;
	}

	private static List<PDFChunk> getPageNumberColumn ( List<List<PDFChunk>> finalColumns )
	{

		List<PDFChunk> pageNoCol = new ArrayList<PDFChunk>();

		List<List<PDFChunk>> finalColumnsNew = new ArrayList<List<PDFChunk>>();

		for( int i = 0; i < finalColumns.size(); i++ )
		{
			List<PDFChunk> eachCol = finalColumns.get(i);

			int size = 0;
			for( PDFChunk ch : eachCol )
			{
				String str = ch.getChunk().replaceAll("\u00A0", "").trim().replaceAll("\\.", "").trim();

				if( !isNumber(str) ) continue;

				size = size + 1;
			}

			if( size < 3 )
			{
				continue;
			}

			finalColumnsNew.add(eachCol);
		}

		if( finalColumnsNew.size() < 1 ) return pageNoCol;

		List<PDFChunk> eachCol = finalColumnsNew.get(finalColumnsNew.size() - 1);

		if( eachCol.size() < 2 ){ return pageNoCol; }

		boolean foundNumber = false;

		float incrNumCount = 0.0f;
		int lastnum = 0;

		for( int j = 0; j < eachCol.size(); j++ )
		{
			String strValue = eachCol.get(j).getChunk().trim();

			strValue = strValue.replaceAll("\u00A0", "").trim().replaceAll("\\.", "").trim();

			if( strValue.replaceAll("�", "").trim().equalsIgnoreCase("") ) continue;

			if( foundNumber )
			{
				if( isNumber(strValue) )
				{
					if( lastnum <= Integer.parseInt(strValue) )
					{
						incrNumCount = incrNumCount + 1;
						lastnum = Integer.parseInt(strValue);
						continue;
					}
					else
					{
						break;
					}
				}
				else
				{
					break;
				}
			}

			if( strValue.equalsIgnoreCase("Notes") || strValue.equalsIgnoreCase("Notes") ) return pageNoCol;

			if( isNumber(strValue) )
			{
				foundNumber = true;
				lastnum = Integer.parseInt(strValue);
			}
		}

		float size = eachCol.size();

		if( incrNumCount > 0 && (size / incrNumCount - 1) <= 1.5 )
		{
			pageNoCol = eachCol;
		}

		return pageNoCol;
	}

	private static List<PDFLine> FilterLines ( List<PDFLine> body )
	{
		List<PDFLine> numberLines = new ArrayList<PDFLine>();

		if( body.isEmpty() ) return numberLines;

		boolean foundFirstNoLine = false;
		for( int i = 0; i < body.size() - 1; i++ )
		{
			PDFLine thisLine = body.get(i);
			PDFLine nextLine = body.get(i + 1);

			float xGap = Math.abs((thisLine.getX1() - nextLine.getX1()));

			boolean thisLineContainsNo = isLineContainsNumber(thisLine);
			boolean nextLineContainsNo = isLineContainsNumber(nextLine);

			if( thisLineContainsNo )
			{
				numberLines.add(thisLine);
				foundFirstNoLine = true;
			}
			else
				if( nextLineContainsNo && foundFirstNoLine && xGap < 1.0 )
				{
					numberLines.add(thisLine);
				}
		}

		PDFLine lastLine = body.get(body.size() - 1);
		boolean lastLineContainsNo = isLineContainsNumber(lastLine);
		if( lastLineContainsNo )
		{
			numberLines.add(lastLine);
		}

		/*
		 * for(PDFLine line:body)
		 * {
		 * List<PDFChunk> chunks = line.getChunks();
		 * for(PDFChunk ch : chunks)
		 * {
		 * String str = ch.getChunk().replaceAll("\u00A0",
		 * "").trim().replaceAll("\\.", "").trim();
		 * if(isNumber(str))
		 * {
		 * numberLines.add(line);
		 * break;
		 * }
		 * }
		 * }
		 */
		return numberLines;
	}

	private static boolean isLineContainsNumber ( PDFLine thisLine )
	{

		List<PDFChunk> chunks = thisLine.getChunks();

		for( PDFChunk ch : chunks )
		{
			String str = ch.getChunk().replaceAll("\u00A0", "").trim().replaceAll("\\.", "").trim();

			if( isNumber(str) ){ return true; }
		}

		return false;
	}

	private static Pair<Float, Float> computeChunkBounds ( PDFChunk chunk )
	{
		float min = Float.MAX_VALUE;
		float max = Float.MIN_VALUE;

		for( PDFWord word : chunk.getWords() )
		{
			if( word.getWord().trim().equalsIgnoreCase("") ) continue;

			min = min < word.getX1() ? min : word.getX1();
			max = max > word.getX2() ? max : word.getX2();
		}

		return new Pair<Float, Float>(min, max);
	}

	private static boolean isNumber ( String strValue )
	{
		try
		{
			Integer.parseInt(strValue);
			return true;
		}
		catch (NumberFormatException e)
		{
			return false;
		}
	}

	private static boolean findOnPages ( List<Integer> pageNos, TreeMap<Integer, PageParse> reportPages, int i )
	{
		if( pageNos.isEmpty() ) return false;

		boolean found = findOnPageEnd(pageNos, reportPages, i);

		if( !found )
		{
			found = findOnPageStart(pageNos, reportPages, i);
		}

		return found;

	}

	private static boolean findOnPageStart ( List<Integer> pageNos, TreeMap<Integer, PageParse> reportPages, int i )
	{
		int lastIndex = -1;
		int lastPageNo = -1;
		int foundPages = 0;
		for( int j = i + 1; j < reportPages.size(); j++ )
		{
			PageParse page = reportPages.get(j);
			List<PDFLine> lines = page.getPageLines();

			/***** find page num on first 4 lines *********/
			int lCounter = 0;
			int thisPageNo = -1;
			boolean found = false;

			for( int k = 0; k < lines.size(); k++ )
			{
				lCounter++;

				PDFLine line = lines.get(k);

				List<PDFChunk> chunks = line.getChunks();

				for( PDFChunk ch : chunks )
				{
					String str = ch.getChunk().replaceAll("�", "").trim();

					if( isNumber(str) )
					{
						thisPageNo = Integer.parseInt(str);
						found = true;
					}
				}

				if( lCounter > 3 || found ) break;
			}

			int thisIndex = 0;

			if( (lastPageNo > thisPageNo) )
			{
				continue;
			}

			if( lastIndex == -1 )
			{
				if( pageNos.contains(thisPageNo) )
				{
					thisIndex = pageNos.indexOf(thisPageNo);
					foundPages++;
					lastIndex = thisIndex;
				}
			}
			else
			{
				if( pageNos.contains(thisPageNo) )
				{
					thisIndex = pageNos.indexOf(thisPageNo);

					if( thisIndex > lastIndex )
					{
						foundPages++;
						lastIndex = thisIndex;
					}

				}
			}

			if( foundPages >= 4 ) return true;
		}

		if( foundPages >= 4 ) return true;

		return false;
	}

	private static boolean findOnPageEnd ( List<Integer> pageNos, TreeMap<Integer, PageParse> reportPages, int i )
	{
		int lastIndex = -1;
		int lastPageNo = -1;
		int foundPages = 0;
		for( int j = i + 1; j < reportPages.size(); j++ )
		{
			PageParse page = reportPages.get(j);
			List<PDFLine> lines = page.getPageLines();

			/***** find page num on last 4 lines *********/
			int lCounter = 0;
			int thisPageNo = -1;
			boolean found = false;
			for( int k = lines.size() - 1; k >= 0; k-- )
			{

				lCounter++;

				PDFLine line = lines.get(k);

				List<PDFChunk> chunks = line.getChunks();

				for( PDFChunk ch : chunks )
				{
					String str = ch.getChunk().replaceAll("�", "").trim();

					if( isNumber(str) )
					{
						thisPageNo = Integer.parseInt(str);
						found = true;
					}
				}

				if( lCounter > 3 || found ) break;
			}

			int thisIndex = 0;

			if( (lastPageNo > thisPageNo) )
			{
				continue;
			}

			if( lastIndex == -1 )
			{
				if( pageNos.contains(thisPageNo) )
				{
					thisIndex = pageNos.indexOf(thisPageNo);
					foundPages++;
					lastIndex = thisIndex;
				}
			}
			else
			{
				if( pageNos.contains(thisPageNo) )
				{
					thisIndex = pageNos.indexOf(thisPageNo);

					if( thisIndex > lastIndex )
					{
						foundPages++;
						lastIndex = thisIndex;
					}

				}
			}

			if( foundPages >= 4 ) return true;
		}

		if( foundPages >= 4 ) return true;

		return false;
	}

	public TreeMap<Integer, PageParse> getReportPages ( )
	{
		return reportPages;
	}

	public void setReportPages ( TreeMap<Integer, PageParse> reportPages )
	{
		this.reportPages = reportPages;
	}

	public List<Integer> getContentpgNos ( )
	{
		return contentpgNos;
	}

	public void setContentpgNos ( List<Integer> contentpgNos )
	{
		this.contentpgNos = contentpgNos;
	}

	public Map<Integer, Map<Integer, List<String>>> getPageNoContentMap ( )
	{
		return pageNoContentMap;
	}

	public void setPageNoContentMap ( Map<Integer, Map<Integer, List<String>>> pageNoContentMap )
	{
		this.pageNoContentMap = pageNoContentMap;
	}

}
