package com.rage.extraction.statements.constant;

import org.apache.log4j.PropertyConfigurator;

public final class ReadLogProperties {
	/** Constructor
	 * 
	 * @param wqID
	 * @param fileID
	 * @param eventGrpID
	 * @param modified_By
	 */
	public void ReadLogPropertiesFile(String fileID,String fileName) 
	{
		System.setProperty("FilingID", fileID);
		PropertyConfigurator.configure(fileName);
	}
}
