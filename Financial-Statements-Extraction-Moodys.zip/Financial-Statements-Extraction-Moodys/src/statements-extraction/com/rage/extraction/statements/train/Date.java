package com.rage.extraction.statements.train;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Calendar;


/**
 * @author kiran.umadi
 *
 */
class Date implements Serializable {
	private static final long serialVersionUID = 1L;
	private String year;
	private String month;
	private String day;
	private String hours;
	private String minutes;
	private String seconds;
	private String day_night;
	private static final String default_format="yyyy-MM-dd HH:mm:ss"; 

	public Date() {
		currentDate();
	}

	private String currentDate()
	{
		Calendar cal = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(default_format);
		parse(sdf.format(cal.getTime()));
		return sdf.format(cal.getTime());
	}

	private void parse(String dateformat)
	{
		String[] tokens=dateformat.split("\\s");
		if (tokens.length>0)
		{
			String[] dateToken=tokens[0].split("-");
			int size=dateToken.length;
			if (size>0)
				year=dateToken[0];
			if (size>1)
				month=dateToken[1];
			if (size>2)
				day=dateToken[2];
		}
		if (tokens.length>1)
		{
			String[] timeToken=tokens[1].split(":");
			int size=timeToken.length;
			if (size>0)
				hours=timeToken[0];
			if (size>1)
				minutes=timeToken[1];
			if (size>2)
				seconds=timeToken[2];
			if (!hours.trim().equals(""))
			{
				int dn=Integer.parseInt(hours);
				this.day_night=(dn<=12?"AM":"PM");
			}
		}
	}

	@Override
	public String toString() {
		return year+"-"+month+"-"+day+" "+hours+":"+minutes+":"+seconds+day_night;
	}

	public Integer getYear() {
		return Integer.parseInt(year);
	}

	public Integer getMonth() {
		return Integer.parseInt(month);
	}

	public Integer getDay() {
		return Integer.parseInt(day);
	}

	public Integer getHours() {
		return Integer.parseInt(hours);
	}

	public Integer getMinutes() {
		return Integer.parseInt(minutes);
	}

	public Integer getSeconds() {
		return Integer.parseInt(seconds);
	}

	public String getDefaultFormat() {
		return default_format;
	}

}
