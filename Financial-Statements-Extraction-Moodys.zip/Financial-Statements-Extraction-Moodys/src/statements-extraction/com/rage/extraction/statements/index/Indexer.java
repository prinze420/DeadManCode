package com.rage.extraction.statements.index;

import java.io.IOException;
import java.util.List;

import org.apache.lucene.index.CorruptIndexException;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.search.IndexSearcher;
import org.apache.lucene.store.LockObtainFailedException;
import org.apache.lucene.store.RAMDirectory;

import com.rage.extraction.statements.index.MemIndexer.Type;

/**
 * @author kiran.umadi
 *
 */
public interface Indexer {
	public void openIndexer() throws CorruptIndexException, LockObtainFailedException, IOException;
	public void indexContent(String id, String content) throws CorruptIndexException, IOException;
	public void closeIndexer() throws CorruptIndexException, IOException;
	public void openSearcher(RAMDirectory memory) throws CorruptIndexException, IOException;
	public List<String> search(String queryString, Type resultType) throws NumberFormatException, Exception;
	public List<String> search(String queryString, String searchFieldName, Type resultType) throws NumberFormatException, Exception;
	public void closeSearcher() throws IOException;
	public RAMDirectory getMemory();
	public IndexWriter getWriter();
	public IndexSearcher getSearcher();
}
