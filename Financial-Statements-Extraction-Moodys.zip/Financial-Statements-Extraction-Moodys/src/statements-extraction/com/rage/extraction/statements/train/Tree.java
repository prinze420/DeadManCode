package com.rage.extraction.statements.train;

import java.util.List;


/**
 * @author kiran.umadi
 *
 */
public interface Tree {
	public Node getRoot();
	public void setRoot(Node node);
	public void read(String fileName, String industry,String language) throws Exception;
	public Node DFSearch(String label);
	public Node DFSearch(String label, Node rootNode);
	public List<Node> searchLabel(String label);
	public String getSection(Node node);
	public String getSubSection(Node node);
	public List<Node> getLeaves();
	public void getLeafNodes(Node rootNode, List<Node> labels);
	public boolean loadDataSet(String industry,String language) throws Exception;
	public TrainDataSet getMetaRoot();
}
