package com.rage.extraction.statements.fs.merge;

import java.util.ArrayList;
import java.util.List;

import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.uitls.LongestCommonSubstring;


public class RecursiveMergeStatement extends MergeUtils
{
	private ArrayList<ParserOutput> objList;
	private List<ArrayList<ParserOutput>> stmt;
	private boolean hierarchy;
	

	public RecursiveMergeStatement()
	{
		objList=new ArrayList<ParserOutput>();
		stmt=new ArrayList<ArrayList<ParserOutput>>();
	}
	public RecursiveMergeStatement(ArrayList<ParserOutput> objLists)
	{
		objList=objLists;
		stmt=new ArrayList<ArrayList<ParserOutput>>();
	}
	public boolean isHierarchy() {
		return hierarchy;
	}

	public void setHierarchy(boolean hierarchy) {
		this.hierarchy = hierarchy;
	}

	ArrayList<ParserOutput> merge(ArrayList<ParserOutput> poList)
	{
		ArrayList<Integer> stmtIndex=getStatementStartIndex(poList);
		if (stmtIndex.size()>1)
		{
			objList=poList;
			stmt=breakStatements(stmtIndex);
			objList=mergeMappedStmt();
			resetIndexOrder(objList);
		} else
		{
			return poList;
		}
		return objList;
	}

	private ArrayList<ParserOutput> resetIndexOrder(ArrayList<ParserOutput> objList)
	{
		int order=0;
		for (ParserOutput po:objList)
		{
			order+=10;
			po.setIndexOrder(order);
			po.setBreakups("N");
			po.setMark("N");
		}
		return objList;
	}

	private ArrayList<ParserOutput> mergeMappedStmt()
	{
		int maxColumn=-1, count=-1;
		ArrayList<ParserOutput> first=null;
		for (ArrayList<ParserOutput> poStmt:stmt)
		{
			if (first!=null)
			{
				count++;
				maxColumn=getMaxColumn(first);
				int maxColumnNext=getMaxColumn(poStmt);
				for (ParserOutput po1:first)
				{
					for (ParserOutput po2:poStmt)
					{
						if (matchLabels(po1,po2))
						{
							mapValues(maxColumn+1, maxColumnNext, po1, po2);
							break;
						}
					}
				}


				// new items insertion
				for (int i=0; i<first.size(); i++)
				{
					ParserOutput po1=first.get(i);
					for (ParserOutput po2:poStmt)
					{
						if (matchLabels(po1,po2))
							mapValues(maxColumn+1, maxColumnNext, po1, po2);

					}
				}

				// new items insertion
				int pos = -1;
				

				for (ParserOutput po2:poStmt)
				{
					pos = -1;
					for (int i=0; i<first.size(); i++)
					{
						ParserOutput po1 = first.get(i);

						if(po1.getSubSection()!=null && po2.getSubSection()!=null &&po1.getSubSection().equalsIgnoreCase(po2.getSubSection()))
						{
							pos = i;
						}
					}
					if(po2.getMark()==null || !po2.getMark().equalsIgnoreCase("Y"))
					{
						ParserOutput po = new ParserOutput();
						po.setSubSection(po2.getSubSection());
						po.setAsRepLabel(po2.getAsRepLabel());
						po.setNonEnglishLabel(po2.getNonEnglishLabel());
						po.setNiItem(po2.getNiItem());
						po.setNilLabel(po2.getNilLabel());
						po.setFiID(po2.getFiID());
						po.setNilLabel(po2.getNilLabel());
						po.setSection(po2.getSection());
						po.setPageNo(po2.getPageNo());
						if(pos==-1)
						first.add(po);
						else
							first.add(pos+1,po);

						mapValues(maxColumn+1, maxColumnNext, po, po2);
					}

				}


			}
			if (count==-1)
				first=poStmt;
		}
		return first;
	}

	private String cleanLabel(String str)
	{
		if (str==null)
			return str;
		if (str.trim().equals(""))
			return str;
		List<String> items=new ArrayList<String>();
		items.add("by");
		items.add("and");
		items.add("of");
		items.add("in");
		items.add("on");
		items.add("from");
		items.add("for");
		items.add("provided");
		items.add("used");
		items.add("increase");
		items.add("decrease");
		items.add("&");
		str=str.replaceAll("[(/)]", " ");
		str=str.replaceAll("[^a-z A-Z]", "").toUpperCase();
		for (String item:items)
			str=str.replaceAll(" "+item.toUpperCase()+" ", " ");
		return str;
	}

	public boolean matchLabels(ParserOutput po1, ParserOutput po2, String boundaryType)
	{
		if (po1.getAsRepLabel()==null || po2.getAsRepLabel()==null)
			return false;
		if (po2.getMark().equals("Y"))
			return false;
		String str1=cleanLabel(po1.getAsRepLabel());
		String str2=cleanLabel(po2.getAsRepLabel());
		if (boundaryType.equals("Inner"))
		{
			if (po1.getSubSection()==null && po2.getSubSection()==null && po1.getSubtotal().equals(po2.getSubtotal()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
			} else if (po1.getSubSection().equals(po2.getSubSection()) && po1.getSubtotal().equals(po2.getSubtotal()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
				else
				{
					String[] strArr=str1.split("\\s");
					String[] strArr1=str2.split("\\s");
					int max=Math.max(strArr.length, strArr1.length);
					if ((wordMatch(str1, str2)/max)*100>90)
						return true;
					else
					{
						if (LCS(str1,str2)>=85)
							return true;
					}
				}
			}
		} else
		{
			if (po1.getSubSection()==null && po2.getSubSection()==null)
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
			} else if (po1.getSubSection().equals(po2.getSubSection()))
			{
				if (str1.equalsIgnoreCase(str2))
					return true;
				else
				{
					String[] strArr=str1.split("\\s");
					String[] strArr1=str2.split("\\s");
					int max=Math.max(strArr.length, strArr1.length);
					if ((wordMatch(str1, str2)/max)*100>90)
						return true;
					else
					{
						if (LCS(str1,str2)>=85)
							return true;
					}
				}
			}
		}
		return false;
	}

	public boolean matchLabels(ParserOutput po1, ParserOutput po2)
	{
		if (po1.getAsRepLabel()==null || po2.getAsRepLabel()==null)
			return false;
		if (po2.getMark().equals("Y"))
			return false;
		if (po1.getSubSection()!=null && po2.getSubSection()!=null && !po1.getSubSection().equals(po2.getSubSection()))
			return false;

		String str1=cleanLabel(po1.getAsRepLabel());
		String str2=cleanLabel(po2.getAsRepLabel());

		if (str1.equalsIgnoreCase(str2))
			return true;
		else
		{
			String[] strArr=str1.split("\\s");
			String[] strArr1=str2.split("\\s");
			int max=Math.max(strArr.length, strArr1.length);
			if ((wordMatch(str1, str2)/max)*100>90)
				return true;
			else
			{
				if (LCS(str1,str2)>=85)
					return true;
			}
		}

		return false;
	}

	public double LCS(String str1, String str2)
	{
		LongestCommonSubstring matcher = new LongestCommonSubstring(str1.toUpperCase(), str2.toUpperCase());
		double sMatch = matcher.findMaxStringMatch();
		double s = sMatch/(str1.length()) * sMatch/(str2.length());
		return s*100;
	}

	public int wordMatch(String str1, String str2)
	{
		if (str1.equals("") || str1==null || str2.equals("") || str2==null)
			return -1;
		int matchCount=0, max=-1;
		String[] arrStr1=str1.trim().replaceAll("[^a-zA-Z 0-9]", "").split("\\s");
		String[] arrStr2=str2.trim().replaceAll("[^a-zA-Z 0-9]", "").split("\\s");

		max=Math.max(arrStr1.length, arrStr2.length);
		for(int i=0; i<max; i++)
		{
			if (i<arrStr1.length && i<arrStr2.length)
			{
				if (arrStr1[i].equalsIgnoreCase(arrStr2[i]))
					matchCount++;
			}
		}
		return matchCount;
	}

	public String getNextValue(int start,  ParserOutput po)
	{
		switch(start)
		{
		case 1:
			return po.getValue1();
		case 2:
			return po.getValue2();
		case 3:
			return po.getValue3();
		case 4:
			return po.getValue4();
		case 5:
			return po.getValue5();
		case 6:
			return po.getValue6();
		case 7:
			return po.getValue7();
		case 8:
			return po.getValue8();
		case 9:
			return po.getValue9();
		case 10:
			return po.getValue10();
		case 11:
			return po.getValue11();
		case 12:
			return po.getValue12();
		case 13:
			return po.getValue13();
		case 14:
			return po.getValue14();
		case 15:
			return po.getValue15();
		case 16:
			return po.getValue16();
		case 17:
			return po.getValue17();
		case 18:
			return po.getValue18();
		case 19:
			return po.getValue19();
		case 20:
			return po.getValue20();
		case 21:
			return po.getValue21();
		case 22:
			return po.getValue22();
		case 23:
			return po.getValue23();
		case 24:
			return po.getValue24();
		case 25:
			return po.getValue25();
		case 26:
			return po.getValue26();
		case 27:
			return po.getValue27();
		case 28:
			return po.getValue28();
		case 29:
			return po.getValue29();
		case 30:
			return po.getValue30();
		}
		return "";
	}



	public String getNextAsRepValue(int start,  ParserOutput po)
	{
		switch(start)
		{
		case 1:
			return po.getAsRepVal1();
		case 2:
			return po.getAsRepVal2();
		case 3:
			return po.getAsRepVal3();
		case 4:
			return po.getAsRepVal4();
		case 5:
			return po.getAsRepVal5();
		case 6:
			return po.getAsRepVal6();
		case 7:
			return po.getAsRepVal7();
		case 8:
			return po.getAsRepVal8();
		case 9:
			return po.getAsRepVal9();
		case 10:
			return po.getAsRepVal10();
		case 11:
			return po.getAsRepVal11();
		case 12:
			return po.getAsRepVal12();
		case 13:
			return po.getAsRepVal13();
		case 14:
			return po.getAsRepVal14();
		case 15:
			return po.getAsRepVal15();
		case 16:
			return po.getAsRepVal16();
		case 17:
			return po.getAsRepVal17();
		case 18:
			return po.getAsRepVal18();
		case 19:
			return po.getAsRepVal19();
		case 20:
			return po.getAsRepVal20();
		case 21:
			return po.getAsRepVal21();
		case 22:
			return po.getAsRepVal22();
		case 23:
			return po.getAsRepVal23();
		case 24:
			return po.getAsRepVal24();
		case 25:
			return po.getAsRepVal25();
		case 26:
			return po.getAsRepVal26();
		case 27:
			return po.getAsRepVal27();
		case 28:
			return po.getAsRepVal28();
		case 29:
			return po.getAsRepVal29();
		case 30:
			return po.getAsRepVal30();
		}
		return "";
	}

	
	public String getNextcoOrdValue(int start,  ParserOutput po)
	{
		switch(start)
		{
		case 1:
			return po.getVal1Coords();
		case 2:
			return po.getVal2Coords();
		case 3:
			return po.getVal3Coords();
		case 4:
			return po.getVal4Coords();
		case 5:
			return po.getVal5Coords();
		case 6:
			return po.getVal6Coords();
		case 7:
			return po.getVal7Coords();
		case 8:
			return po.getVal8Coords();
		case 9:
			return po.getVal9Coords();
		case 10:
			return po.getVal10Coords();
		case 11:
			return po.getVal11Coords();
		case 12:
			return po.getVal12Coords();
		case 13:
			return po.getVal13Coords();
		case 14:
			return po.getVal14Coords();
		case 15:
			return po.getVal15Coords();
		case 16:
			return po.getVal16Coords();
		case 17:
			return po.getVal17Coords();
		case 18:
			return po.getVal18Coords();
		case 19:
			return po.getVal19Coords();
		case 20:
			return po.getVal20Coords();
		
		}
		return "";
	}
	public void mapValues(int startPoint, int maxColObj2, ParserOutput po1, ParserOutput po2)
	{
		if (po2.getMark().equals("Y"))
			return;
		int valPos=1;
		for (int i=startPoint; i<startPoint+maxColObj2; i++)
		{
			switch(i)
			{
			case 1:
				break;
			case 2:
			{
				po1.setAsRepVal2(getNextAsRepValue(valPos, po2));
				po1.setValue2(getNextValue(valPos, po2));
				po1.setVal2Coords(getNextcoOrdValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 3:
			{
				po1.setAsRepVal3(getNextAsRepValue(valPos, po2));
				po1.setValue3(getNextValue(valPos, po2));
				po1.setVal3Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 4:
			{
				po1.setAsRepVal4(getNextAsRepValue(valPos, po2));
				po1.setValue4(getNextValue(valPos, po2));
				po1.setVal4Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 5:
			{
				po1.setAsRepVal5(getNextAsRepValue(valPos, po2));
				po1.setValue5(getNextValue(valPos, po2));
				po1.setVal5Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 6:
			{
				po1.setAsRepVal6(getNextAsRepValue(valPos, po2));
				po1.setValue6(getNextValue(valPos, po2));
				po1.setVal6Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 7:
			{
				po1.setAsRepVal7(getNextAsRepValue(valPos, po2));
				po1.setValue7(getNextValue(valPos, po2));
				po1.setVal7Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 8:
			{
				po1.setAsRepVal8(getNextAsRepValue(valPos, po2));
				po1.setValue8(getNextValue(valPos, po2));
				po1.setVal8Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 9:
			{
				po1.setAsRepVal9(getNextAsRepValue(valPos, po2));
				po1.setValue9(getNextValue(valPos, po2));
				po1.setVal9Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 10:
			{
				po1.setAsRepVal10(getNextAsRepValue(valPos, po2));
				po1.setValue10(getNextValue(valPos, po2));
				po1.setVal10Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 11:
			{
				po1.setAsRepVal11(getNextAsRepValue(valPos, po2));
				po1.setValue11(getNextValue(valPos, po2));
				po1.setVal11Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 12:
			{
				po1.setAsRepVal12(getNextAsRepValue(valPos, po2));
				po1.setValue12(getNextValue(valPos, po2));
				po1.setVal12Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 13:
			{
				po1.setAsRepVal13(getNextAsRepValue(valPos, po2));
				po1.setValue13(getNextValue(valPos, po2));
				po1.setVal13Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 14:
			{
				po1.setAsRepVal14(getNextAsRepValue(valPos, po2));
				po1.setValue14(getNextValue(valPos, po2));
				po1.setVal14Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 15:
			{
				po1.setAsRepVal15(getNextAsRepValue(valPos, po2));
				po1.setValue15(getNextValue(valPos, po2));
				po1.setVal15Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 16:
			{
				po1.setAsRepVal16(getNextAsRepValue(valPos, po2));
				po1.setValue16(getNextValue(valPos, po2));
				po1.setVal16Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 17:
			{
				po1.setAsRepVal17(getNextAsRepValue(valPos, po2));
				po1.setValue17(getNextValue(valPos, po2));
				po1.setVal17Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 18:
			{
				po1.setAsRepVal18(getNextAsRepValue(valPos, po2));
				po1.setValue18(getNextValue(valPos, po2));
				po1.setVal18Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 19:
			{
				po1.setAsRepVal19(getNextAsRepValue(valPos, po2));
				po1.setValue19(getNextValue(valPos, po2));
				po1.setVal19Coords(getNextcoOrdValue(valPos, po2));

				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 20:
			{
				po1.setAsRepVal20(getNextAsRepValue(valPos, po2));
				po1.setValue20(getNextValue(valPos, po2));
				po1.setVal20Coords(getNextcoOrdValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 21:
			{
				po1.setAsRepVal21(getNextAsRepValue(valPos, po2));
				po1.setValue21(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 22:
			{
				po1.setAsRepVal22(getNextAsRepValue(valPos, po2));
				po1.setValue22(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 23:
			{
				po1.setAsRepVal23(getNextAsRepValue(valPos, po2));
				po1.setValue23(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 24:
			{
				po1.setAsRepVal24(getNextAsRepValue(valPos, po2));
				po1.setValue24(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 25:
			{
				po1.setAsRepVal25(getNextAsRepValue(valPos, po2));
				po1.setValue25(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 26:
			{
				po1.setAsRepVal26(getNextAsRepValue(valPos, po2));
				po1.setValue26(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");
				valPos++;
				break;
			}
			case 27:
			{
				po1.setAsRepVal27(getNextAsRepValue(valPos, po2));
				po1.setValue27(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 28:
			{
				po1.setAsRepVal28(getNextAsRepValue(valPos, po2));
				po1.setValue28(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 29:
			{
				po1.setAsRepVal29(getNextAsRepValue(valPos, po2));
				po1.setValue29(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}
			case 30:
			{
				po1.setAsRepVal30(getNextAsRepValue(valPos, po2));
				po1.setValue30(getNextValue(valPos, po2));
				po2.setBreakups("N");
				po2.setMark("Y");

				valPos++;
				break;
			}

			}
		}
	}


	public boolean isExist(List<ParserOutput> list, String group)
	{
		for (ParserOutput po:list)
		{
			//			if (po.getBreakups().equals("C"))
			//				continue;
			if (po.getHierarchy().equalsIgnoreCase(group))
				return true;
		}
		return false;
	}

	public ParserOutput createItemLabel(ParserOutput po)
	{
		ParserOutput poNew=new ParserOutput();
		poNew.setStmt_id(po.getStmt_id());
		poNew.setID(po.getID());
		poNew.setAsRepLabel(po.getAsRepLabel());
		poNew.setIndexOrder(po.getIndexOrder());
		poNew.setSection(po.getSection());
		poNew.setSubSection(po.getSubSection());
		poNew.setHierarchy(po.getHierarchy());
		poNew.setLine(po.getLine());
		po.setBreakups("C");
		return poNew;
	}

	private int groupIndexOf(List<ParserOutput> poStmt, String groupName)
	{
		int index=-1;
		for (ParserOutput po:poStmt)
		{
			index++;
			if (po.getHierarchy().equalsIgnoreCase(groupName) && po.getBreakups().equals("N"))
				return index;
		}
		return -1;
	}

	private int groupLastIndexOf(List<ParserOutput> poStmt, String groupName)
	{
		for (int index=poStmt.size()-1; index>=0; index--)
		{
			ParserOutput po=poStmt.get(index);
			if (po.getHierarchy().equalsIgnoreCase(groupName) && po.getBreakups().equals("N"))
				return index;
		}
		return -1;
	}

	public String getParentGroup(List<ParserOutput> poStmt, ParserOutput po)
	{
		if (isExist(poStmt, po.getHierarchy()))
			return po.getHierarchy();
		int start=groupIndexOf(poStmt, po.getHierarchy());
		int end=groupLastIndexOf(poStmt, po.getHierarchy());
		//		if (start!=-1 && start==0)
		//			return po.getHierarchy();
		//		if (end!=-1 && end==poStmt.size()-1)
		//			return po.getHierarchy();
		if (start>0 && end<poStmt.size())
		{
			String upperGroup=poStmt.get(start-1).getHierarchy();
			String lowerGroup=poStmt.get(end+1).getHierarchy();
			if (upperGroup.equalsIgnoreCase(lowerGroup))
				return upperGroup;
			else
				return lowerGroup;
		}
		return "";
	}

	public void insertParserOutputObject(List<ParserOutput> poStmt, ParserOutput po)
	{
		int index=-1;
		if (poStmt.size()>0)
		{
			String parent=getParentGroup(poStmt, po);
			if (!parent.equals(""))
			{
				if (parent.equalsIgnoreCase(po.getHierarchy()))
				{
					index=groupLastIndexOf(poStmt, parent);
					if (poStmt.get(index).getSubSection().equals("Y"))
						index-=1;
					else
						index+=1;
				}
				else
					index=groupLastIndexOf(poStmt, parent)-1;
			} else
				index=poStmt.size()-1;
			poStmt.add(index, createItemLabel(po));
		}
	}

	public int getIndex(List<ParserOutput> baseList, String parent)
	{
		int index=groupLastIndexOf(baseList, parent);
		if (index==-1)
			return -1;
		if (!baseList.get(index).getSubSection().equals("Y"))
			//			index-=1;
			//		else
			index+=1;

		return index;
	}

	public void insertParserOutputObject(List<ParserOutput> baseList, List<ParserOutput> newList, ParserOutput po)
	{
		int index=-1;
		if (baseList.size()>0)
		{
			String parent=getParentGroup(baseList, po);
			if (!parent.equals(""))
			{
				if (parent.equalsIgnoreCase(po.getHierarchy()))
				{
					index=groupLastIndexOf(baseList, parent);
					if (!baseList.get(index).getSubSection().equals("Y"))
						//						index-=1;
						//					else
						index+=1;
				}
				else
					index=groupLastIndexOf(baseList, parent)-1;
			} else
				//			if (parent.equals(""))
			{
				int last=groupLastIndexOf(newList, po.getHierarchy());
				if ((last+1)<newList.size()-1)
				{
					ParserOutput poNew=newList.get(last+1);
					parent=getParentGroup(baseList, poNew);
					index=getIndex(baseList, parent);
				}
			}
			if (index!=-1)
				baseList.add(index, createItemLabel(po));
			else
				baseList.add(baseList.size()-1, createItemLabel(po));
		}
	}


	public void markBoundaries(List<ParserOutput> poStmt)
	{
		int markBoundary=0;
		for (ParserOutput po:poStmt)
		{
			po.setSubtotal(String.valueOf(markBoundary));
			if (po.getAsRepLabel()==null)
				continue;
			if ((po.getAsRepLabel().toLowerCase().replaceAll("[^a-zA-Z 0-9]", "").trim().startsWith("total")
					//					|| po.getAsRepLabel().toLowerCase().startsWith("net ")
					|| po.getAsRepLabel().toLowerCase().replaceAll("[^a-zA-Z 0-9]", "").trim().startsWith("net cash provided by ")
					|| po.getAsRepLabel().toLowerCase().replaceAll("[^a-zA-Z 0-9]", "").trim().startsWith("net cash from "))
					&& !po.getAsRepLabel().replaceAll("[^a-zA-Z 0-9]", "").trim().equalsIgnoreCase("net income"))
			{
				po.setSubSection("Y");
				markBoundary++;
			}
		}
		this.hierarchy=true;
	}

	public List<ParserOutput> discoverHierarchy(List<ParserOutput> list, int maxItems)
	{
		String asRepLabel="";
		ParserOutput po=null;
		markBoundaries(list);
		for (int i=maxItems-1; i>=0; i--)
		{
			po=list.get(i);
			if (!po.getHierarchy().equals("NA"))
				continue;
			if (po.getAsRepLabel()==null)
				continue;
			if (po.getAsRepLabel().startsWith("STATEMENT "))
				break;
			if (po.getSubSection()==null)
				po.setSubSection("N");
			if (po.getSubSection().equals("Y"))
			{
				if(po.getAsRepLabel()!=null)
					asRepLabel=po.getAsRepLabel().trim().replaceAll("[^a-z A-Z]", "").trim();
				if (asRepLabel.toLowerCase().startsWith("total "))
					asRepLabel=asRepLabel.substring(6);
				/*if (asRepLabel.toLowerCase().startsWith("net "))
					asRepLabel=asRepLabel.substring(4);*/
				if (asRepLabel.toLowerCase().startsWith("net cash from "))
					asRepLabel=asRepLabel.substring(14);
				po.setHierarchy(asRepLabel);
				discoverHierarchy(list, i);
			} if (!asRepLabel.equals("") && po.getHierarchy().equals("NA"))
			{
				po.setHierarchy(asRepLabel);
				if (asRepLabel.equalsIgnoreCase(po.getAsRepLabel().trim().replaceAll("[^a-z A-Z]", "").trim()))
					break;
				if (asRepLabel.toLowerCase().trim().startsWith(po.getAsRepLabel().trim().replaceAll("[^a-z A-Z]", "").toLowerCase().trim()))
					break;
			}
		}
		return list;
	}

	public int getInnerBoundaries(List<ParserOutput> poStmt, String subtotal, String boundaryOf)
	{
		int index=-1;
		for (ParserOutput po:poStmt)
		{
			index++;
			if (po.getAsRepLabel()==null)
				continue;
			if (po.getSubtotal()==null || po.getAsRepLabel().startsWith("STATEMENT"))
				continue;
			if (boundaryOf.equals("Start") && po.getSubtotal().equals(String.valueOf(subtotal)))
				return index;
			if (boundaryOf.equals("End") && po.getSubtotal().equals(String.valueOf(Integer.parseInt(subtotal)+1)))
				return index-1;
		}
		return -1;
	}

	public void markBoundaryItems(int start, int end, List<ParserOutput> poStmt, String subSection)
	{
		for (int i=start; i<=end; i++)
		{
			ParserOutput po=poStmt.get(i);
			if (po.getSubSection().equals("NA") || po.getSubSection()==null)
				po.setSubSection(subSection);
		}
	}

	public List<ArrayList<ParserOutput>> breakStatements(ArrayList<Integer> stmtIndex)
	{
		List<ArrayList<ParserOutput>> st=new ArrayList<ArrayList<ParserOutput>>();
		int start=-1, end=-1;
		for (Integer index:stmtIndex)
		{
			if (start!=-1 && end==-1)
				end=index.intValue();
			if (start==-1)
				start=index.intValue();
			if (start!=-1 && end!=-1 && end>start)
			{
				st.add(resetIndexOrder(getStatement(start, end-1)));
				start=index.intValue();
				end=-1;
			}
		}
		st.add(resetIndexOrder(getStatement(start, objList.size()-1)));
		return st;
	}

	public ArrayList<ParserOutput> getStatement(int start, int end)
	{
		ArrayList<ParserOutput> st = new ArrayList<ParserOutput>();
		if (objList.size()>0)
		{
			for (int i=start; i<=end; i++)
				st.add(objList.get(i));
		}
		return st;
	}

	public static void main(String[] args)
	{
		RecursiveMergeStatement rms=new RecursiveMergeStatement();
		List<ParserOutput> items=rms.testData();
		rms.discoverHierarchy(items, items.size());
		for (ParserOutput po:items)
			System.out.println(po.getAsRepLabel()+"\t"+po.getSubSection()+"\t"+po.getHierarchy());
	}

	public List<ParserOutput> testData()
	{
		ParserOutput po;
		List<ParserOutput> items=new ArrayList<ParserOutput>();
		po=new ParserOutput();
		po.setAsRepLabel("ASSETS");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Current Assets");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Contracts Receivable");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Other Current Assets");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Total Current Assets");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Property and Equipment -Net");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Total Assets");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("LIABILITIES AND MEMBERS' EQUITY");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Current Liabilities");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Accounts Payable");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Accrued Expenses");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Revolving Credit Line");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Current Portion of Long-Term Debt");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Total Current Liabilities");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Long-Term Debt - Net of Current Portion");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Total Liabilities");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Members' Equity");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("Net Income");
		items.add(po);

		po=new ParserOutput();
		po.setAsRepLabel("TOTAL LIABILITIES AND MEMBER'S EQUITY");
		items.add(po);

		return items;
	}

}
