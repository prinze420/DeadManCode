package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.dp.hierarchy.HierarchyNode;
import com.dp.pipeline.ExtractionParser;
import com.dp.structures.Structure;
import com.dp.structures.StructureType;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.gyan.siapp.utils.Triplet;
import com.rage.document.pdf.utils.CustomFileWriter;
import com.rage.document.pdf.utils.StringUtility;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.utils.FileParseUtils;


public class AssociationCreator 
{

	public static HierarchyNode mainEnumNode;
	public static Map<String, ArrayList<ParserOutput>> implicitMetadataMatchingBreakUps;
	public static Map<String, ArrayList<ParserOutput>> implicitSUPPLMetadataMatchingBreakUps;
	public static List<TopicKeywords> BSnoteKWList=null;
	public static List<HierarchyNode> allHierarchyChildNodes= new ArrayList<HierarchyNode>();
	
	
	public void associationCreator(TreeMap<String, ArrayList<ParserOutput>> sectionMap, HierarchyNode hierarchyNode, String fileName)
	{
		// Map<Long, List<Triplet<String, String, String>>> allTextBreakUps=null;
		if(hierarchyNode!=null)
		{
			mainEnumNode=setMainEnumNodesToRoot(hierarchyNode);
			allHierarchyChildNodes= AssociationsUtilities.getAllTheNodesFromANode(hierarchyNode);
			/*NLPTextBreakUpAssociation txtBreakUp= new NLPTextBreakUpAssociation();
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			allTextBreakUps=txtBreakUp.getEachNodeAssociation(nodes);*/
		}
		Set<Long> explicitNodesAssociated= new HashSet<Long>();
		boolean isExplicitRun=false;
		for(String secType:sectionMap.keySet())
		{
			//issue fix
			if(secType.trim().equalsIgnoreCase("SE"))
				continue;
			ArrayList<ParserOutput> rows=sectionMap.get(secType);
			for(ParserOutput row:rows)
			{
				if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
					continue ;
				else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
					continue;
				else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
					continue;
				else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
					continue;
				
				String lineItemSectionStr=row.getAsRepLabel();
				if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
					continue;
				String note=row.getNotesColumn();
				if(note!=null && !note.trim().equals(""))
				{
					isExplicitRun=true;
				}
				if(note==null || note.trim().equals(""))
				{
					note=getNoteNumberFromLineItem(lineItemSectionStr);
				}
				if(note!=null && !note.trim().equals(""))
				{
					List<HierarchyNode> nodes=findMatchingHierarchyNodeWithEnum(note,hierarchyNode,explicitNodesAssociated);
					
				}
			}
			/*if(isExplicitRun)
				break;*/
		}
		
		// Implicit Association Metadata matching
		if(!isExplicitRun && hierarchyNode!=null)
		{
			String userGroup="123";
			/*Map<String, List<String>> implicitMetaData=TimePeriodOntology.loadImplicitMetdata("resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/implicitSectionKeywords.txt",userGroup);
			
			if(implicitMetaData!=null && implicitMetaData.size()>0)
			{*/
				//implicitMetadataMatchingBreakUps=getImplcitMetadataMatchingTables(implicitMetaData,hierarchyNode);
				//implicitMetadataMatchingBreakUps=getImplcitMetadataMatchingTablesWithmatchingText(implicitMetaData,hierarchyNode,sectionMap);
				implicitMetadataMatchingBreakUps=getImplicitMetadataMatchingTablesWithmatchingTextWithAllFiles(hierarchyNode,sectionMap);
				
				return;
			//}
		}
		
		for(String secType:sectionMap.keySet())
		{
			if((FinancialStatementExtractor.getISBreakups()!=null && FinancialStatementExtractor.getISBreakups().contains("No") && secType.equalsIgnoreCase("IS"))
					|| (FinancialStatementExtractor.getBSBreakups()!=null && FinancialStatementExtractor.getBSBreakups().contains("No") && secType.equalsIgnoreCase("BS"))
						|| (FinancialStatementExtractor.getCFBreakups()!=null && FinancialStatementExtractor.getCFBreakups().contains("No") && secType.equalsIgnoreCase("CF"))
						)
			{
				continue;
			}
			ImplicitSplit.tempString=ImplicitSplit.tempString+"\n\n"+"================="+secType+"=================";
			System.out.println("=============Association creation "+secType+"=======");
			CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
			CustomFileWriter.writeStringToFileWithNewLine("==============Association for Section============"+secType.toUpperCase(), FinancialStatementExtractor.writer);
			ArrayList<ParserOutput> rows=sectionMap.get(secType);
			ParserOutput yearRow= null;
			ParserOutput attributeRow= null;
			ParserOutput monthRow= null;
			List<ParserOutput> thisSectionRow=new ArrayList<ParserOutput>();
			if( !(secType.equalsIgnoreCase("se") || secType.equalsIgnoreCase("cf") || secType.equalsIgnoreCase("is") || secType.equalsIgnoreCase("bs")))
				continue;
			for(ParserOutput row:rows)
			{
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
				{
					yearRow=row;
					continue;
				}
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
				{
					attributeRow=row;
					continue;
				}
				
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
				{
					monthRow=row;
					continue;
				}
				
				if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
					continue ;
				else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
					continue;
				else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
					continue;
				else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
					continue;
				
				String lineItemSectionStr=row.getAsRepLabel();
				if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
					continue;
				thisSectionRow.add(row);
				CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
				CustomFileWriter.writeStringToFileWithNewLine("Row=="+lineItemSectionStr, FinancialStatementExtractor.writer);
				
				List<POBreakUps> poBreakUps= new ArrayList<POBreakUps>();
				// Check for super scripts
				List<PDFLine> lines=row.getRow().getLines();
				String superScript=checkForSuperScript(row,lineItemSectionStr);
				
				String note=row.getNotesColumn();
				//System.out.println(HierarchyNode.toDeepString(hierarchyNode, ""));
				
				// Super Script associations
				HierarchyNode superScriptBrkUpsNode=null;
				if(superScript!=null && !superScript.trim().equals(""))
				{
					/*List<POBreakUps> superScriptBrkUps=getSuperScriptMatchingNode(superScript, row.getRow().getLines().get(0).getPageNo(), fileName);
					poBreakUps.addAll(superScriptBrkUps);*/
					superScriptBrkUpsNode=getSuperScriptMatchingNode(superScript, row.getRow().getLines().get(0).getPageNo(), fileName);
				}

				// check for note column and get the note number
				
				if(note==null || note.trim().equals(""))
				{
					note=getNoteNumberFromLineItem(lineItemSectionStr);
				}
				
				List<Triplet<String, String, String>> lineItemMatchingTriplets=NLPTextBreakUpAssociation.getMatchingTripletsFromSentence(lineItemSectionStr);
				
				// search for note in hierarchy
				if(note!=null && !note.trim().equals(""))
				{
					// match the note with the enum from hierarchy
					System.out.println("\nSearching note="+note+" =For LineItem=="+lineItemSectionStr);
					List<HierarchyNode> nodes=findMatchingHierarchyNodeWithEnum(note,hierarchyNode,explicitNodesAssociated);
					
					for(HierarchyNode hNode:nodes)
					{
						List<POBreakUps> notesNode=AssociationsUtilities.preparePOBreakUpsFromHierarchyNode(hNode);
						CustomFileWriter.writeStringToFileWithNewLine("Found Association===="+HierarchyNode.toDeepString(hNode, ""), FinancialStatementExtractor.writer);
						poBreakUps.addAll(notesNode);
					}
					
					if(nodes!=null && nodes.size()>0)
					{
						/*CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
						CustomFileWriter.writeStringToFileWithNewLine("==Semantic BreakUps for row==", FinancialStatementExtractor.writer);
						NLPTextBreakUpAssociation txtBreakUp= new NLPTextBreakUpAssociation();
						List<Triplet<String, String, String>> breakUps1=txtBreakUp.getNodeAssociationTemp(nodes,secType);
						CustomFileWriter.writeStringToFileWithNewLine("==Semantic BreakUps for row done==", FinancialStatementExtractor.writer);*/
						/*CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
						CustomFileWriter.writeStringToFileWithNewLine("====Spreading Tables for row====", FinancialStatementExtractor.writer);
						List<Triplet<String, String, String>> breakUps=txtBreakUp.getNodeAssociationTableTemp(nodes,secType);*/
						
					}
					
					boolean isLineContainsNumber=false;
					
					for(PDFLine line:lines)
					{
						isLineContainsNumber=AssociationsUtilities.isLineContainsNumberChunk(line);
						if(isLineContainsNumber)
							break;
					}
					if(isLineContainsNumber)
					{
						List<HierarchyNode> matchingNodes=new ArrayList<HierarchyNode>();
						if(superScriptBrkUpsNode!=null)
						{
							matchingNodes.add(superScriptBrkUpsNode);
						}
						if(nodes!=null && nodes.size()>0)
						{
							matchingNodes.addAll(nodes);
						}
						/*else
						{
							ImplicitSplit isBreakUp= new ImplicitSplit();
							matchingNodes=isBreakUp.getImplicitSplitBreakUps(lineItemSectionStr,row,yearRow,attributeRow,hierarchyNode,secType,lines);
						}*/
						if(matchingNodes!=null && matchingNodes.size()>0)
						{
							InnerSplit innerSplit= new InnerSplit();
							/*List<HierarchyNode> nodeList= new ArrayList<HierarchyNode>();
							nodeList.add(matchingNode);*/
							innerSplit.runInnerSplit(matchingNodes,row,yearRow,attributeRow,monthRow,secType,"Explicit",hierarchyNode,true,explicitNodesAssociated);
						}
					}
					
					// Filter nodes based on matching priority
					//List<HierarchyNode> filteredNodes=filterNodesBasedOnPriority(new ArrayList<HierarchyNode>(nodes),lineItemSectionStr,lines);
				
					
					// Find the highest note node - (Explicit Split)
					//List<HierarchyNode> higherNoteNodes=findTheHighestNoteMatchingNode(nodes,lineItemSectionStr);
					
					// Split nodes in breakups.
					/*InnerSplit innerSplit= new InnerSplit();
					innerSplit.runInnerSplit(filteredNodes, lineItemSectionStr, lines,row,yearRow,attributeRow,secType);*/
					
					// Text breakUP with NLP process
					
					/*NLPTextBreakUpAssociation txtBreakUp= new NLPTextBreakUpAssociation();
					List<Triplet<String, String, String>> breakUps=txtBreakUp.getEachNodeAssociation(nodes);
					List<Triplet<String, String, String>> matchingBrkUp=NLPTextBreakUpAssociation.associateMatchingBreakUps(breakUps,lineItemSectionStr);
					if(matchingBrkUp==null || matchingBrkUp.size()>0)
					{
						List<Triplet<String, String, String>> titleNodeMatchingBreakUps=txtBreakUp.getTitleNodeMatchingAssociation(nodes,lineItemSectionStr);
					}
					NLPTextBreakUpAssociation.addBreakUpInRow(matchingBrkUp,row,yearRow);*/
					
					System.out.println();
				}
				else if (!isExplicitRun)
				{
					// if note column not found, search line item in hierarchy
					//List<HierarchyNode> nodes=findMatchingHierarchyNodeWithLineItem(lineItemSectionStr,hierarchyNode);
					
					boolean isLineContainsNumber=false;
					
					for(PDFLine line:lines)
					{
						isLineContainsNumber=AssociationsUtilities.isLineContainsNumberChunk(line);
						if(isLineContainsNumber)
							break;
					}
					
					if(isLineContainsNumber)
					{
						ImplicitSplit isBreakUp= new ImplicitSplit();
						List<HierarchyNode> matchingNodes= new ArrayList<HierarchyNode>();
						matchingNodes=isBreakUp.getImplicitSplitBreakUps(lineItemSectionStr,row,yearRow,attributeRow,hierarchyNode,secType,lines);
						if(matchingNodes!=null && matchingNodes.size()>0)
						{
							InnerSplit innerSplit= new InnerSplit();
							/*List<HierarchyNode> nodeList= new ArrayList<HierarchyNode>();
							nodeList.add(matchingNode);*/
							innerSplit.runInnerSplit(matchingNodes,row,yearRow,attributeRow,monthRow,secType,"Implicit",hierarchyNode,false,explicitNodesAssociated);
						}
					}
					System.out.println();
					
					
					/*List<Triplet<String, String, String>> matchingBrkUp=NLPTextBreakUpAssociation.associateMatchingBreakUps(allBreakUps,lineItemSectionStr);
					NLPTextBreakUpAssociation.addBreakUpInRow(matchingBrkUp,row,yearRow);*/
					
					// Find the highest note node - (Explicit Split)
					//List<HierarchyNode> higherNoteNodes=findTheHighestNoteMatchingNode(nodes,lineItemSectionStr);
					
					// Split nodes in breakups.
					/*ExplicitInnerSplit expSplit= new ExplicitInnerSplit();
					if(nodes!=null)
					{
						List<POBreakUps> breakups=expSplit.splitHierarchyNodes(nodes,lineItemSectionStr,false);
						poBreakUps.addAll(breakups);
					}*/
					
					System.out.println();
				}
				
				row.setAllBreakups(poBreakUps);
				
				System.out.println("");
				// check super scripts in the associated line items and do associations for them
			}
			ImplicitSplit.tempString=ImplicitSplit.tempString+"\n"+"================="+secType+" Done =================";
			CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
			CustomFileWriter.writeStringToFileWithNewLine("Association for section=="+secType.toUpperCase()+" Done..", FinancialStatementExtractor.writer);
			System.out.println("=============Association creation "+secType+" Done =======");
		}
		
	}
	
	
	
	private Map<String, ArrayList<ParserOutput>> getImplcitMetadataMatchingTablesWithmatchingText(Map<String, List<String>> implicitMetaData, HierarchyNode hierarchyNode, TreeMap<String, ArrayList<ParserOutput>> sectionMap) 
	{
		Map<String,ArrayList<ParserOutput>> ret= new HashMap<String,ArrayList<ParserOutput>>();
		Map<String,ArrayList<ParserOutput>> suppl= new HashMap<String,ArrayList<ParserOutput>>();

		for(String section:implicitMetaData.keySet())
		{
			List<String> searchList=implicitMetaData.get(section);
			// For Tables
			for(String searchString:searchList)
			{
				ImplicitSplit is= new ImplicitSplit();	
				List<HierarchyNode> matchingNodes=is.DFSMultipleMatchingImplicit(hierarchyNode,searchString,hierarchyNode);
				if(matchingNodes!=null && matchingNodes.size()>0)
				{
					for(HierarchyNode matchingNode:matchingNodes)
					{
						if(InnerSplit.nodesVisited!=null && InnerSplit.nodesVisited.contains(matchingNode.getId()))
							continue;
						ParserOutput matchingLineItem=getMatchingLineItemRowFromSection(sectionMap,searchString,section);
						List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
						nodes.add(matchingNode);
						if(matchingLineItem!=null)
						{
							runMatchingMetadataInnerSplit(nodes,matchingLineItem,section,hierarchyNode,sectionMap,searchString);
						}
						else
						{
							InnerSplit innerSplit= new InnerSplit();
							ParserOutput row= new ParserOutput();
							row.setSection(section.toUpperCase());
							innerSplit.runInnerSplitForImplicitMetadata(nodes, row, null, null, null, section.toUpperCase(), "Implicit_Metadata", hierarchyNode, false,searchString);
							if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
							{
								for(List<ParserOutput> supplRows:row.getSupplementaryBreakUpItem())
								{
									for(ParserOutput breakUp:supplRows)
									{
										breakUp.setMatchingImplicitKeyWord(searchString);
										// Add to particular section
										//breakUp.setSection(section.toUpperCase());
										breakUp.setSection("SUPPL");
										breakUp.setBreakups("Y");
										if(suppl.get("SUPPL")!=null)
										{
											suppl.get("SUPPL").add(breakUp);
										}
										else
										{
											ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
											temp.add(breakUp);
											suppl.put("SUPPL", temp);
										}
									}
								}
							}
						}
					}
				}
				/*HierarchyNode matchingNode=is.getMatchingNodesInReverseOrder(hierarchyNode,searchString,section.toUpperCase(),null);
				if(matchingNode!=null)
				{
					if(InnerSplit.nodesVisited!=null && InnerSplit.nodesVisited.contains(matchingNode.getId()))
						continue;
					List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
					nodes.add(matchingNode);
					InnerSplit innerSplit= new InnerSplit();
					ParserOutput row= new ParserOutput();
					row.setSection(section.toUpperCase());
					innerSplit.runInnerSplitForImplicitMetadata(nodes, row, null, null, null, section.toUpperCase(), "Implicit_Metadata", hierarchyNode, false,null);
					if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
					{
						for(List<ParserOutput> supplRows:row.getSupplementaryBreakUpItem())
						{
							for(ParserOutput breakUp:supplRows)
							{
								breakUp.setMatchingImplicitKeyWord(searchString);
								breakUp.setSection(section.toUpperCase());
								breakUp.setBreakups("Y");
								if(ret.get(section.trim().toLowerCase())!=null)
								{
									ret.get(section.trim().toLowerCase()).add(breakUp);
								}
								else
								{
									ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
									temp.add(breakUp);
									ret.put(section.trim().toLowerCase(), temp);
								}
							}
						}
					}
				}*/
			}
		}
		
		// For textBreakUp
		ParserOutput textBreakUps=InnerSplit.getMatchingTextBreakUP(implicitMetaData,hierarchyNode);
		
		if(textBreakUps.getSupplementaryBreakUpItem()!=null && textBreakUps.getSupplementaryBreakUpItem().size()>0)
		{
			for(List<ParserOutput> breakUps:textBreakUps.getSupplementaryBreakUpItem())
			{
				boolean isFound=false;
				for(ParserOutput po:breakUps)
				{
					if(po.getMatchingImplicitKeyWord()!=null && !po.getMatchingImplicitKeyWord().trim().equals(""))
					{
						isFound=true;
						break;
					}
				}
				if(isFound)
				{
					ParserOutput matchingLineItem=getMatchingLineItemRowFromSection(sectionMap,breakUps.get(0).getMatchingImplicitKeyWord(),breakUps.get(0).getSection());
					for(ParserOutput breakUp:breakUps)
					{						
						breakUp.setBreakups("Y");
						if(matchingLineItem!=null)
						{
							ArrayList<ParserOutput> brekUPList=(ArrayList<ParserOutput>)breakUps;
							runMatchingMetadataInnerSplitForTextBreakUp(brekUPList,matchingLineItem,breakUp.getSection(),sectionMap);
							break;
						}
						else
						{
							// Add to SUPPL section , comment in case if need to add in particular section
							breakUp.setSection("SUPPL");
							
							if(ret.get(breakUp.getSection().trim().toLowerCase())!=null)
							{
								ret.get(breakUp.getSection().trim().toLowerCase()).add(breakUp);
							}
							else
							{
								ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
								temp.add(breakUp);
								ret.put(breakUp.getSection().trim().toLowerCase(), temp);
							}
						}
					}
				}
				else
				{
					for(ParserOutput breakUp:breakUps)
					{						
						breakUp.setBreakups("Y");
						breakUp.setSection("SUPPL");
						if(suppl.get(breakUp.getSection().trim().toLowerCase())!=null)
						{
							suppl.get(breakUp.getSection().trim().toLowerCase()).add(breakUp);
						}
						else
						{
							ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
							temp.add(breakUp);
							suppl.put(breakUp.getSection().trim().toLowerCase(), temp);
						}
					}
				}
			}
		}
		
		implicitSUPPLMetadataMatchingBreakUps=suppl;
		return ret;
	}

	
	private Map<String, ArrayList<ParserOutput>> getImplicitMetadataMatchingTablesWithmatchingTextWithAllFiles(HierarchyNode hierarchyNode, TreeMap<String, ArrayList<ParserOutput>> sectionMap) 
	{
		Map<String,ArrayList<ParserOutput>> ret= new HashMap<String,ArrayList<ParserOutput>>();
		Map<String,ArrayList<ParserOutput>> suppl= new HashMap<String,ArrayList<ParserOutput>>();
		List<TopicKeywords> noteKWList= getNoteKeywordList();
		List<TopicKeywords> LIKWList= getLIKeywordList();
		
		List<NoteLineItemMatchingPriority> combineTopicList=getCombineKeywordList();
		Map<String,List<NoteLineItemMatchingPriority>> noteTopicListMap=getNoteTopicListMap(combineTopicList);
		Map<String,List<String>> liTopicListMap=getLITopicListMap(LIKWList);
		
		if(BSnoteKWList!=null)
			BSnoteKWList.clear();
		BSnoteKWList=getBSNoteKeywordList();
		
		Map<String, List<String>> lineItemIgnoreMap=getImplicitIgnoreKeywordList();
		
		/*for(TopicKeywords noteKeyword:noteKWList)
		{
			List<String> searchList=noteKeyword.getKeywords();
			String section=noteKeyword.getSection();
			String cleanedNoteTopic=noteKeyword.getCleanedTopic();
			// For Tables
			for(String searchString:searchList)
			{
				System.out.println("SS=="+searchString);
				ImplicitSplit is= new ImplicitSplit();	
				List<HierarchyNode> matchingNodes=is.DFSMultipleMatchingImplicit(hierarchyNode,searchString,hierarchyNode);
				if(matchingNodes!=null && matchingNodes.size()>0)
				{
					for(HierarchyNode matchingNode:matchingNodes)
					{
						if(InnerSplit.nodesVisited!=null && InnerSplit.nodesVisited.contains(matchingNode.getId()))
							continue;
						ParserOutput matchingLineItem=getMatchingLineItemRowFromSectionFromMetadata(sectionMap,section,cleanedNoteTopic,noteTopicListMap,liTopicListMap);
						List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
						nodes.add(matchingNode);
						if(matchingLineItem!=null)
						{
							if(!section.trim().equalsIgnoreCase("BS"))
							{
								processBSTablesSeperately(nodes,"BS",hierarchyNode,sectionMap,searchString,noteTopicListMap,liTopicListMap);
							}
							runMatchingMetadataInnerSplit(nodes,matchingLineItem,section,hierarchyNode,sectionMap,searchString);
							
						}
						else
						{
							InnerSplit innerSplit= new InnerSplit();
							ParserOutput row= new ParserOutput();
							row.setSection(section.toUpperCase());
							innerSplit.runInnerSplitForImplicitMetadata(nodes, row, null, null, null, section.toUpperCase(), "Implicit_Metadata", hierarchyNode, false,searchString);
							if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
							{
								for(List<ParserOutput> supplRows:row.getSupplementaryBreakUpItem())
								{
									for(ParserOutput breakUp:supplRows)
									{
										breakUp.setMatchingImplicitKeyWord(searchString);
										// Add to particular section
										//breakUp.setSection(section.toUpperCase());
										breakUp.setSection("SUPPL");
										breakUp.setBreakups("Y");
										if(suppl.get("SUPPL")!=null)
										{
											suppl.get("SUPPL").add(breakUp);
										}
										else
										{
											ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
											temp.add(breakUp);
											suppl.put("SUPPL", temp);
										}
									}
								}
							}
						}
					}
				}
			}
		}*/
		
		// New One
		for(String secType:sectionMap.keySet())
		{
			if((FinancialStatementExtractor.getISBreakups()!=null && FinancialStatementExtractor.getISBreakups().contains("No") && secType.equalsIgnoreCase("IS"))
					|| (FinancialStatementExtractor.getBSBreakups()!=null && FinancialStatementExtractor.getBSBreakups().contains("No") && secType.equalsIgnoreCase("BS"))
						|| (FinancialStatementExtractor.getCFBreakups()!=null && FinancialStatementExtractor.getCFBreakups().contains("No") && secType.equalsIgnoreCase("CF")))
			{
				continue;
			}
			
			/*if(secType.trim().equalsIgnoreCase("CF"))
				continue;*/
			
			ImplicitSplit.tempString=ImplicitSplit.tempString+"\n\n"+"================="+secType+"=================";
			
			System.out.println("=============Association creation "+secType+"=======");
			CustomFileWriter.writeStringToFileWithNewLine("", FinancialStatementExtractor.writer);
			CustomFileWriter.writeStringToFileWithNewLine("==============Association for Section============"+secType.toUpperCase(), FinancialStatementExtractor.writer);
			
			ArrayList<ParserOutput> rows=sectionMap.get(secType);
			
			ParserOutput yearRow= null;
			ParserOutput attributeRow= null;
			ParserOutput monthRow= null;
			
			if( !(secType.equalsIgnoreCase("se") || secType.equalsIgnoreCase("cf") || secType.equalsIgnoreCase("is") || secType.equalsIgnoreCase("bs")))
				continue;
			
			for(ParserOutput row:rows)
			{
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
				{
					yearRow=row;
					continue;
				}
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
				{
					attributeRow=row;
					continue;
				}
				
				if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
				{
					monthRow=row;
					continue;
				}
				
				if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
					continue ;
				else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
					continue;
				else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
					continue;
				else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
					continue;
				
				String lineItemSectionStr=row.getAsRepLabel();
				if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
					continue;
				if(lineItemIgnoreMap.get(secType.trim().toLowerCase())!=null)
				{
					List<String> kwList=lineItemIgnoreMap.get(secType.trim().toLowerCase());
					boolean isFound=false;
					for(String kw1:kwList)
					{
						kw1=StringUtility.cleanString(kw1);
						String lI=StringUtility.cleanString(lineItemSectionStr);
						if(lI.trim().equalsIgnoreCase(kw1.trim()))
						{
							isFound=true;
							break;
						}
					}
					if(isFound)
						continue;
				}
				ImplicitSplit is= new ImplicitSplit();
				List<HierarchyNode> matchingNodes= new ArrayList<HierarchyNode>();
				HierarchyNode mNode=is.matchMainEnumNodesInHierarchy(hierarchyNode,lineItemSectionStr);
				if(mNode!=null)
				{
					matchingNodes.add(mNode);
				}
				else
				{
					matchingNodes=is.DFSMultipleMatchingImplicitOnlyHeaders(hierarchyNode,lineItemSectionStr,hierarchyNode);
				}
				if(matchingNodes!=null && matchingNodes.size()>0)
				{
					InnerSplit innerSplit= new InnerSplit();
					innerSplit.runInnerSplitForImplicitMetadata(matchingNodes, row, yearRow, monthRow, attributeRow, secType, "Implicit_Metadata", hierarchyNode, false,lineItemSectionStr);
				}
			}
		}
		
		// For textBreakUp
		ParserOutput textBreakUps=InnerSplit.getMatchingTextBreakUPFromMetadata(noteKWList,hierarchyNode);
		
		if(textBreakUps.getSupplementaryBreakUpItem()!=null && textBreakUps.getSupplementaryBreakUpItem().size()>0)
		{
			for(List<ParserOutput> breakUps:textBreakUps.getSupplementaryBreakUpItem())
			{
				boolean isFound=false;
				for(ParserOutput po:breakUps)
				{
					if(po.getMatchingImplicitKeyWord()!=null && !po.getMatchingImplicitKeyWord().trim().equals(""))
					{
						isFound=true;
						break;
					}
				}
				if(isFound)
				{
					String cleanedNoteTopic=breakUps.get(0).getMatchingImplicitKeyWord().split(":::")[0];
					//ParserOutput matchingLineItem=getMatchingLineItemRowFromSectionFromMetadata(sectionMap,breakUps.get(0).getMatchingImplicitKeyWord(),breakUps.get(0).getSection());
					ParserOutput matchingLineItem=getMatchingLineItemRowFromSectionFromMetadata(sectionMap,breakUps.get(0).getSection(),cleanedNoteTopic,noteTopicListMap,liTopicListMap);
					for(ParserOutput breakUp:breakUps)
					{						
						breakUp.setBreakups("Y");
						if(matchingLineItem!=null)
						{
							ArrayList<ParserOutput> brekUPList=(ArrayList<ParserOutput>)breakUps;
							runMatchingMetadataInnerSplitForTextBreakUp(brekUPList,matchingLineItem,breakUp.getSection(),sectionMap);
							break;
						}
						else
						{
							// Add to SUPPL section , comment in case if need to add in particular section
							breakUp.setSection("SUPPL");
							
							if(ret.get(breakUp.getSection().trim().toLowerCase())!=null)
							{
								ret.get(breakUp.getSection().trim().toLowerCase()).add(breakUp);
							}
							else
							{
								ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
								temp.add(breakUp);
								ret.put(breakUp.getSection().trim().toLowerCase(), temp);
							}
						}
					}
				}
				else
				{
					for(ParserOutput breakUp:breakUps)
					{						
						breakUp.setBreakups("Y");
						breakUp.setSection("SUPPL");
						if(suppl.get(breakUp.getSection().trim().toLowerCase())!=null)
						{
							suppl.get(breakUp.getSection().trim().toLowerCase()).add(breakUp);
						}
						else
						{
							ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
							temp.add(breakUp);
							suppl.put(breakUp.getSection().trim().toLowerCase(), temp);
						}
					}
				}
			}
		}
		
		implicitSUPPLMetadataMatchingBreakUps=suppl;
		return ret;
	}
	

	private void processBSTablesSeperately(List<HierarchyNode> nodes, String section,
			HierarchyNode hierarchyNode, TreeMap<String, ArrayList<ParserOutput>> sectionMap, String searchString,
			Map<String, List<NoteLineItemMatchingPriority>> noteTopicListMap,
			Map<String, List<String>> liTopicListMap) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			List<Pair<TopicKeywords,HierarchyNode>> matchingNodes=InnerSplit.getMatchingTablesWithTopicKeywords(nodes,AssociationCreator.BSnoteKWList);
			if(matchingNodes!=null)
			{
				for(Pair<TopicKeywords, HierarchyNode> mPair:matchingNodes)
				{
					TopicKeywords topicPair=mPair.getA();
					HierarchyNode node=mPair.getB();
					
					ParserOutput matchingLineItem=null;
					for(String cleanedNoteTopic:topicPair.getKeywords())
					{
						matchingLineItem=getMatchingLineItemRowFromSectionFromMetadata(sectionMap,section,cleanedNoteTopic,noteTopicListMap,liTopicListMap);
						if(matchingLineItem!=null)
							break;
					}
					if(matchingLineItem!=null)
					{
						List<HierarchyNode> temp= new ArrayList<HierarchyNode>();
						temp.add(node);
						runMatchingMetadataInnerSplit(temp,matchingLineItem,section,hierarchyNode,sectionMap,topicPair.getTopic());
					}
					else
					{
						// IF to be added to suppl
					}
				}
			}
		}
	}

	private Map<String, List<String>> getLITopicListMap(List<TopicKeywords> lIKWList) 
	{
		Map<String,List<String>> ret= new HashMap<String,List<String>>();
		for(TopicKeywords each:lIKWList)
		{
			if(ret.get(each.getCleanedTopic())!=null)
			{
				ret.get(each.getCleanedTopic()).addAll(each.getKeywords());
			}
			else
			{
				ret.put(each.getCleanedTopic(),each.getKeywords());
			}
		}
		return ret;
	}



	private Map<String, List<NoteLineItemMatchingPriority>> getNoteTopicListMap(
			List<NoteLineItemMatchingPriority> combineTopicList) 
	{
		Map<String,List<NoteLineItemMatchingPriority>> ret1= new HashMap<String,List<NoteLineItemMatchingPriority>>(); 
		for(NoteLineItemMatchingPriority eachRow:combineTopicList)
		{
			String cleanedNote=eachRow.getCleanedNoteTopic();
			if(ret1.get(cleanedNote)!=null)
			{
				ret1.get(cleanedNote).add(eachRow);
			}
			else
			{
				List<NoteLineItemMatchingPriority> temp= new ArrayList<NoteLineItemMatchingPriority>();
				temp.add(eachRow);
				ret1.put(cleanedNote, temp);			
			}
		}
		
		Comparator<NoteLineItemMatchingPriority> priorityCmp= new Comparator<NoteLineItemMatchingPriority>() 
		{
			@Override
			public int compare(NoteLineItemMatchingPriority o1, NoteLineItemMatchingPriority o2) 
			{
				return new Integer(o1.getPriority()).compareTo(new Integer(o2.getPriority()));
			}
		};
		Map<String,List<NoteLineItemMatchingPriority>> ret= new HashMap<String,List<NoteLineItemMatchingPriority>>();
		for(String key:ret1.keySet())
		{
			List<NoteLineItemMatchingPriority> list=ret1.get(key);
			Collections.sort(list,priorityCmp);
			ret.put(key, list);
		}
		
		return ret;
	}



	private List<NoteLineItemMatchingPriority> getCombineKeywordList() 
	{
		String noteTopicFileName="resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/implicit_combine_prioritymatching.txt";
		List<List<String>> noteTopicList= FileParseUtils.parseFile(noteTopicFileName, "\t", 4);
		List<NoteLineItemMatchingPriority> ret= new ArrayList<NoteLineItemMatchingPriority>();
		for(List<String> row:noteTopicList)
		{
			if(row.get(0).trim().startsWith("#"))
				continue;
			String cleanedNoteTopic=StringUtility.cleanString(row.get(1)).toLowerCase();
			if(cleanedNoteTopic==null || cleanedNoteTopic.trim().equals(""))
				continue;
			String cleanedLITopic=StringUtility.cleanString(row.get(2)).toLowerCase();
			if(cleanedLITopic==null || cleanedLITopic.trim().equals(""))
				continue;
			
			if(!StringUtility.isStringNumber(row.get(3)))
				continue;
			
			NoteLineItemMatchingPriority rw= new NoteLineItemMatchingPriority(); 
			rw.setUserGroup(row.get(0));
			rw.setNoteTopic(row.get(1));
			rw.setLineItemTopic(row.get(2));
			rw.setPriority(Integer.parseInt(row.get(3)));
			rw.setCleanedLineItemTopic(cleanedLITopic);
			rw.setCleanedNoteTopic(cleanedNoteTopic);
			ret.add(rw);
		}
		return ret;
	}

	
	
	private List<TopicKeywords> getLIKeywordList() 
	{

		String noteTopicFileName="resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/implicit_lineitem_topic_keyword.txt";
		List<List<String>> noteTopicList= FileParseUtils.parseFile(noteTopicFileName, "\t", 4);
		List<TopicKeywords> ret= new ArrayList<TopicKeywords>();
		Map<String,TopicKeywords> topicMap= new HashMap<String,TopicKeywords>();
		for(List<String> row:noteTopicList)
		{
			if(row.get(0).trim().startsWith("#"))
				continue;
			String cleanedTopic=StringUtility.cleanString(row.get(2)).toLowerCase();
			if(cleanedTopic==null || cleanedTopic.trim().equals(""))
				continue;
			if(topicMap.containsKey(cleanedTopic))
			{
				topicMap.get(cleanedTopic).getKeywords().add(row.get(3));
				continue;
			}
			
			TopicKeywords kw= new TopicKeywords();
			kw.setUserGroup(row.get(0));
			kw.setSection(row.get(1));
			kw.setTopic(row.get(2));
			kw.setCleanedTopic(cleanedTopic);
			List<String> temp= new ArrayList<String>();
			temp.add(row.get(3));
			kw.setKeywords(temp);
			topicMap.put(cleanedTopic, kw);
			ret.add(kw);
		}
		return ret;
	
	}

	private Map<String,List<String>> getImplicitIgnoreKeywordList() 
	{
		String noteTopicFileName="resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/ignore_implicit_keywords_list.txt";
		List<List<String>> noteTopicList= FileParseUtils.parseFile(noteTopicFileName, "\t", 2);
		Map<String, List<String>> ret= new HashMap<String,List<String>>();
		for(List<String> row:noteTopicList)
		{
			if(row.get(0).trim().startsWith("#"))
				continue;
			
			String section= row.get(0);
			String keyword= row.get(1);
			
			if(ret.containsKey(section.toLowerCase().trim()))
			{
				ret.get(section.trim().toLowerCase()).add(keyword);
			}
			else
			{
				List<String> temp= new ArrayList<String>();
				temp.add(keyword);
				ret.put(row.get(0).toLowerCase(), temp);
			}
		}
		return ret;
	}
	
	private List<TopicKeywords> getNoteKeywordList() 
	{
		String noteTopicFileName="resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/implicit_notetopic_keyword.txt";
		List<List<String>> noteTopicList= FileParseUtils.parseFile(noteTopicFileName, "\t", 4);
		List<TopicKeywords> ret= new ArrayList<TopicKeywords>();
		Map<String,TopicKeywords> topicMap= new HashMap<String,TopicKeywords>();
		for(List<String> row:noteTopicList)
		{
			if(row.get(0).trim().startsWith("#"))
				continue;
			
			String cleanedTopic=StringUtility.cleanString(row.get(2)).toLowerCase();
			if(cleanedTopic==null || cleanedTopic.trim().equals(""))
				continue;
			if(topicMap.containsKey(cleanedTopic))
			{
				topicMap.get(cleanedTopic).getKeywords().add(row.get(3));
				continue;
			}
			
			TopicKeywords kw= new TopicKeywords();
			kw.setUserGroup(row.get(0));
			kw.setSection(row.get(1));
			kw.setTopic(row.get(2));
			kw.setCleanedTopic(cleanedTopic);
			List<String> temp= new ArrayList<String>();
			temp.add(row.get(3));
			kw.setKeywords(temp);
			topicMap.put(cleanedTopic, kw);
			ret.add(kw);
		}
		return ret;
	}

	private List<TopicKeywords> getBSNoteKeywordList() 
	{
		String noteTopicFileName="resource/section-identification/"+FinancialStatementExtractor.getLanguage()+"/implicit_notetopic_BS_keyword.txt";
		List<List<String>> noteTopicList= FileParseUtils.parseFile(noteTopicFileName, "\t", 4);
		List<TopicKeywords> ret= new ArrayList<TopicKeywords>();
		Map<String,TopicKeywords> topicMap= new HashMap<String,TopicKeywords>();
		for(List<String> row:noteTopicList)
		{
			if(row.get(0).trim().startsWith("#"))
				continue;
			
			String cleanedTopic=StringUtility.cleanString(row.get(2)).toLowerCase();
			
			if(cleanedTopic==null || cleanedTopic.trim().equals(""))
				continue;
			String cleanedKw=StringUtility.cleanString(row.get(3)).toLowerCase();
			if(topicMap.containsKey(cleanedKw))
			{
				topicMap.get(cleanedKw).getKeywords().add(cleanedTopic);
				continue;
			}
			
			TopicKeywords kw= new TopicKeywords();
			kw.setUserGroup(row.get(0));
			kw.setSection(row.get(1));
			kw.setTopic(cleanedKw);
			kw.setCleanedTopic(cleanedKw);
			List<String> temp= new ArrayList<String>();
			temp.add(cleanedTopic);
			kw.setKeywords(temp);
			topicMap.put(cleanedKw, kw);
			ret.add(kw);
		}
		return ret;
	}	
	
	private void runMatchingMetadataInnerSplitForTextBreakUp(ArrayList<ParserOutput> breakUps, ParserOutput matchingLineItem,
			String section, TreeMap<String, ArrayList<ParserOutput>> sectionMap) 
	{
		ArrayList<ParserOutput> rows= new ArrayList<ParserOutput>();
		if(sectionMap.get(section.toUpperCase())!=null || sectionMap.get(section.toLowerCase())==null)
		{
			rows=sectionMap.get(section.toUpperCase())!=null?sectionMap.get(section.toUpperCase()):sectionMap.get(section.toLowerCase());
		}

		ParserOutput yearRow=null;
		ParserOutput monthRow=null;
		ParserOutput attrRow=null;
		for(ParserOutput row:rows)
		{
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
			{
				yearRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
			{
				attrRow=row;
				continue;
			}
			
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
			{
				monthRow=row;
				continue;
			}
		}
		InnerSplit innerSplit= new InnerSplit();
		innerSplit.runInnerSplitForImplicitMetadataTextBreakUp(breakUps, matchingLineItem, yearRow, monthRow, attrRow, section.toUpperCase(), "Implicit_Metadata");
		
	}

	private void runMatchingMetadataInnerSplit(List<HierarchyNode> nodes, ParserOutput matchingLineItem, String section,
			HierarchyNode hierarchyNode, TreeMap<String, ArrayList<ParserOutput>> sectionMap, String searchString) 
	{
		ArrayList<ParserOutput> rows= new ArrayList<ParserOutput>();
		if(sectionMap.get(section.toUpperCase())!=null || sectionMap.get(section.toLowerCase())==null)
		{
			rows=sectionMap.get(section.toUpperCase())!=null?sectionMap.get(section.toUpperCase()):sectionMap.get(section.toLowerCase());
		}

		ParserOutput yearRow=null;
		ParserOutput monthRow=null;
		ParserOutput attrRow=null;
		for(ParserOutput row:rows)
		{
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
			{
				yearRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
			{
				attrRow=row;
				continue;
			}
			
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
			{
				monthRow=row;
				continue;
			}
		}
		InnerSplit innerSplit= new InnerSplit();
		innerSplit.runInnerSplitForImplicitMetadata(nodes, matchingLineItem, yearRow, monthRow, attrRow, section.toUpperCase(), "Implicit_Metadata", hierarchyNode, false,searchString);
	}

	private ParserOutput getMatchingLineItemRowFromSectionFromMetadata(TreeMap<String, ArrayList<ParserOutput>> sectionMap,String section, String cleanedNoteTopic, Map<String, List<NoteLineItemMatchingPriority>> noteTopicListMap, Map<String, List<String>> liTopicListMap) 
	{
		if(sectionMap.get(section.toUpperCase())==null && sectionMap.get(section.toLowerCase())==null)
			return null;
		ArrayList<ParserOutput> poList=sectionMap.get(section.toUpperCase())!=null?sectionMap.get(section.toUpperCase()):sectionMap.get(section.toLowerCase());
		if(poList!=null && poList.size()>0)
		{
			try
			{
				List<NoteLineItemMatchingPriority> noteTopicList=noteTopicListMap.get(cleanedNoteTopic);
				List<String> liTopicList= new ArrayList<String>();
				for(NoteLineItemMatchingPriority echNote:noteTopicList)
				{
					if(!liTopicList.contains(echNote.getCleanedLineItemTopic()))
						liTopicList.add(echNote.getCleanedLineItemTopic());
				}
				List<String> toMatchList= new ArrayList<String>();
				for(String litopic:liTopicList)
				{
					if(liTopicListMap.get(litopic)!=null)
					{
						toMatchList.addAll(liTopicListMap.get(litopic));
					}
				}
				
				
				if(toMatchList==null || toMatchList.size()<0)
					return null;
				for(String toSearch:toMatchList)
				{
					for(ParserOutput row:poList)
					{
						if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
							continue ;
						else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
							continue;
						else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
							continue;
						else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
							continue;
						else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
							continue;
						else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
							continue;
						
						String lineItemSectionStr=row.getAsRepLabel();
						if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
							continue;
						
						boolean isMatch=StringUtility.doesKeywordMatchTokenSerial(toSearch, lineItemSectionStr);
						if(isMatch)
							return row;
					}
				}
			}
			catch(Exception e)
			{
				
			}
		}
		return null;
	}
	
	private ParserOutput getMatchingLineItemRowFromSection(TreeMap<String, ArrayList<ParserOutput>> sectionMap,String searchString,String section) 
	{
		if(sectionMap.get(section.toUpperCase())==null && sectionMap.get(section.toLowerCase())==null)
			return null;
		ArrayList<ParserOutput> poList=sectionMap.get(section.toUpperCase())!=null?sectionMap.get(section.toUpperCase()):sectionMap.get(section.toLowerCase());
		if(poList!=null && poList.size()>0)
		{
			for(ParserOutput row:poList)
			{
				if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
					continue ;
				else if(row.getPrevHeader()!=null && row.getPrevHeader().equalsIgnoreCase("Y"))
					continue;
				else if(row.getAsRepLabel()!=null && row.getAsRepLabel().startsWith("STATEMENT") )
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
					continue;
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
					continue;
				else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
					continue;
				
				String lineItemSectionStr=row.getAsRepLabel();
				if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
					continue;
				boolean isMatch=StringUtility.doesKeywordMatchTokenSerial(searchString, lineItemSectionStr);
				if(isMatch)
					return row; 
			}
		}
		return null;
	}

	private Map<String, ArrayList<ParserOutput>> getImplcitMetadataMatchingTables(Map<String, List<String>> implicitMetaData, HierarchyNode hierarchyNode) 
	{
		Map<String,ArrayList<ParserOutput>> ret= new HashMap<String,ArrayList<ParserOutput>>();
		for(String section:implicitMetaData.keySet())
		{
			List<String> searchList=implicitMetaData.get(section);
			for(String searchString:searchList)
			{
				ImplicitSplit is= new ImplicitSplit();
				HierarchyNode matchingNode=is.getMatchingNodesInReverseOrder(hierarchyNode,searchString,section.toUpperCase(),null);
				if(matchingNode!=null)
				{
					if(InnerSplit.nodesVisited!=null && InnerSplit.nodesVisited.contains(matchingNode.getId()))
						continue;
					List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
					nodes.add(matchingNode);
					InnerSplit innerSplit= new InnerSplit();
					ParserOutput row= new ParserOutput();
					row.setSection(section.toUpperCase());
					innerSplit.runInnerSplit(nodes, row, null, null, null, section.toUpperCase(), "Implicit_Metadata", hierarchyNode, false, null);
					if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
					{
						for(List<ParserOutput> supplRows:row.getSupplementaryBreakUpItem())
						{
							for(ParserOutput breakUp:supplRows)
							{
								breakUp.setMatchingImplicitKeyWord(searchString);
								breakUp.setSection(section.toUpperCase());
								breakUp.setBreakups("Y");
								if(ret.get(section.trim().toLowerCase())!=null)
								{
									ret.get(section.trim().toLowerCase()).add(breakUp);
								}
								else
								{
									ArrayList<ParserOutput> temp= new ArrayList<ParserOutput>();
									temp.add(breakUp);
									ret.put(section.trim().toLowerCase(), temp);
								}
							}
						}
					}
				}
			}
		}
		return ret;
	}

	private HierarchyNode setMainEnumNodesToRoot(HierarchyNode hierarchyNode) 
	{
		Map<Integer,Integer> grpNumberMap= new HashMap<Integer,Integer>(); 
		Map<Integer,Integer> grpTitleNumberMap= new HashMap<Integer,Integer>();
		Map<Integer,Integer> grpMinPageNoMap= new HashMap<Integer,Integer>();
		List<HierarchyNode> nodes=AssociationsUtilities.getAllTheNodesFromANode(hierarchyNode);
		
		getEnumGroupDataFilled(nodes,grpNumberMap,grpMinPageNoMap,grpTitleNumberMap);
		HierarchyNode ret=null;
		for(HierarchyNode node:nodes)
		{
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
			{
				int timesOccured=grpNumberMap.get(node.getEnumFinalGroupId());
				if(timesOccured<2)
					continue;
				else
				{
					if(ret==null)
						ret=node;
					if(node.getEnumeration().getText().toLowerCase().contains("note")
							|| node.getEnumeration().getText().toLowerCase().contains("schedule") || node.getEnumeration().getText().toLowerCase().contains("section"))
					{
						ret=node;
						break;
					}
				}
			}
		}
		System.out.println("Main Enum Node=="+ret);
		if(ret!=null)
			return ret;
		/*for(HierarchyNode node:nodes)
		{
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
			{
				if(ret!=null)
				{
					if(ret.getEnumFinalGroupId()==node.getEnumFinalGroupId())
					{
						HierarchyNode parent=node.getParent();
						int removeIndex=-1;
						for(int k=0;k<parent.getChildren().size();k++)
						{
							HierarchyNode cNode=parent.getChildren().get(k);
							if(cNode.getId()==node.getId())
								removeIndex=k;
						}
						if(removeIndex!=-1)
						{
							parent.getChildren().remove(removeIndex);
							
						}
						node.setParent(hierarchyNode);
						hierarchyNode.getChildren().add(node);
						System.out.println("Assigned To Root=="+node);
					}
				}
			}
		}*/
		System.out.println("New Hierarchy====");
		System.out.println(HierarchyNode.toDeepString(hierarchyNode, ""));
		return ret;
	}

	public void getEnumGroupDataFilled(List<HierarchyNode> nodes, Map<Integer, Integer> grpNumberMap, Map<Integer, Integer> grpMinPageNoMap, Map<Integer, Integer> grpTitleNumberMap)
	{
		if(nodes!=null)
		{
			for(HierarchyNode node:nodes)
			{
				if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
				{
					if(grpNumberMap.get(node.getEnumFinalGroupId())!=null)
					{
						grpNumberMap.put(node.getEnumFinalGroupId(), (grpNumberMap.get(node.getEnumFinalGroupId())+1));
						if(node.getNode() instanceof Title)
						{
							grpTitleNumberMap.put(node.getEnumFinalGroupId(), (grpTitleNumberMap.get(node.getEnumFinalGroupId())+1));
						}
					}
					else
					{
						grpNumberMap.put(node.getEnumFinalGroupId(), 1);
						if(node.getNode() instanceof Title)
						{
							Title title=(Title)node.getNode();
							grpTitleNumberMap.put(node.getEnumFinalGroupId(), 1);
							grpMinPageNoMap.put(node.getEnumFinalGroupId(), title.getRectangle().getPageNo());
						}
						else
						{
							Paragraph para=(Paragraph)node.getNode();
							grpTitleNumberMap.put(node.getEnumFinalGroupId(), 0);
							grpMinPageNoMap.put(node.getEnumFinalGroupId(), para.getRectangles().get(0).getPageNo());
						}
					}
				}
			}
		}
	}
	
	public HierarchyNode getSuperScriptMatchingNode(String superScript,int pageNo,String fileName)
	{
		List<POBreakUps> ret= new ArrayList<POBreakUps>();
		if(superScript!=null && !superScript.trim().equals(""))
		{
			System.out.println("pageNo ="+pageNo);
			HierarchyNode hNode=ExtractionParser.getHieraechyNode(pageNo, pageNo, fileName);
			List<HierarchyNode> hNodes=AssociationsUtilities.getAllTheNodesFromANode(hNode);
			List<List<String>> noteList=AssociationsUtilities.splitEnum(superScript);
			for(List<String> eachEnum:noteList)
			{
				for(String subEnum:eachEnum)
				{
					for(HierarchyNode node:hNodes)
					{
						if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
						{
							boolean isNodeMatch=isNoteAndEnumStringCleanedMatch(subEnum, node.getEnumeration().getText().trim());
							if(isNodeMatch)
							{
								return node;
								/*List<POBreakUps> superScriptFootNotes=AssociationsUtilities.preparePOBreakUpsFromHierarchyNode(node);
								ret.addAll(superScriptFootNotes);
								CustomFileWriter.writeStringToFileWithNewLine("SuperScript Association=="+node.getNode().getStringRepresentation(), FinancialStatementExtractor.writer);
								break;*/
							}
						}
						else if(node.getNode().getStringRepresentation().trim().toLowerCase().startsWith(subEnum.trim().toLowerCase()))
						{
							return node;
							/*List<POBreakUps> superScriptFootNotes=AssociationsUtilities.preparePOBreakUpsFromHierarchyNode(node);
							ret.addAll(superScriptFootNotes);
							CustomFileWriter.writeStringToFileWithNewLine("SuperScript Association=="+node.getNode().getStringRepresentation(), FinancialStatementExtractor.writer);
							break;*/
						}
					}
				}
			}
		}
		return null;
	}

	private String getNoteNumberFromLineItem(String lineItemSectionStr) 
	{
		if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			return "";
		
		if(lineItemSectionStr.trim().contains("note"))
		{
			lineItemSectionStr=lineItemSectionStr.trim();
			
			if(lineItemSectionStr.toLowerCase().trim().contains("note"))
			{
				String ret=lineItemSectionStr.toLowerCase().substring(lineItemSectionStr.lastIndexOf("note")+4, lineItemSectionStr.length()).trim();
				ret=ret.replaceAll("\\s+", "").trim();
				if(!ret.trim().equals(""))
				{
					if(ret.contains(","))
					{
						String[] split= ret.split(",");
						String lastEnum=split[split.length-1].trim();
						if(ret.endsWith(")") && !lastEnum.contains("("))
						{
							ret=ret.substring(0, ret.length()-1);
						}
						else if(ret.endsWith("))"))
						{
							ret=ret.substring(0, ret.length()-1);
						}
					}
					else
					{
						if(ret.endsWith(")") && !ret.contains("("))
						{
							ret=ret.substring(0, ret.length()-1);
						}
						else if(ret.endsWith("))"))
						{
							ret=ret.substring(0, ret.length()-1);
						}
					}
					return ret;	
				}
			}
		
		}
		return "";
	}

	private String checkForSuperScript(ParserOutput row, String lineItemSectionStr) 
	{
		if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			return "";
		String ret="";
		String[] split=lineItemSectionStr.trim().split("\\s+");
		if(split.length>1)
		{
			String str=split[split.length-1].trim();
			if(str.indexOf("(")!=-1)
			{
				str=str.substring(str.indexOf("("), str.length());
			}
			Pattern p=Pattern.compile("(\\d+)|((\\()?(\\s+)?\\d+(\\s+)?\\))|(\\d+\\.)");
			// Alphabet
			Pattern p1=Pattern.compile("((\\()?(\\s+)?[a-h](\\s+)?\\))|([a-h]\\.)");
			// Roman
			Pattern p2=Pattern.compile("((\\()?(\\s+)?(i|ii|iii|iv|v|vi)(\\s+)?\\))|((i|ii|iii|iv|v|vi)\\.)",Pattern.CASE_INSENSITIVE);
			Matcher m=p.matcher(str);
			if(m.matches())
			{
				return str;
			}
			m=p1.matcher(str);
			if(m.matches())
			{
				return str;
			}
			m=p2.matcher(str);
			if(m.matches())
			{
				return str;
			}
			String digit=str.substring(str.length()-1, str.length());
			if(isNumber(digit))
				return digit;
		}
		return ret;
	}

	private List<HierarchyNode> findTheHighestNoteMatchingNode(List<HierarchyNode> nodes, String lineItemSectionStr) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(nodes==null) 
			return ret;
		for(HierarchyNode node:nodes)
		{
			HierarchyNode hNode=getHighestNodeForNode(node);
			if(hNode!=null)
			{
				ret.add(hNode);
			}
		}
		
		return ret;
	}
	
	private HierarchyNode getHighestNodeForNode(HierarchyNode node) 
	{
		if(node!=null)
		{
			boolean isFulfilled=isHighestNodeCriteriaFulfilled(node);
			if(isFulfilled)
				return node;
			HierarchyNode latestEnumNode=null;
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null 
					&& !node.getEnumeration().getText().trim().equals(""))
			{
				latestEnumNode=node;
			}
			
			HierarchyNode refNode=node.getParent();
			while(refNode!=null)
			{
				isFulfilled=isHighestNodeCriteriaFulfilled(refNode);
				if(refNode.getEnumeration()!=null && refNode.getEnumeration().getText()!=null 
						&& !refNode.getEnumeration().getText().trim().equals(""))
				{
					latestEnumNode=refNode;
				}
				if(isFulfilled)
					return refNode;
				refNode=refNode.getParent();
			}
			if(latestEnumNode!=null)
				return latestEnumNode;
		}
		return null;
	}

	public boolean isHighestNodeCriteriaFulfilled(HierarchyNode node)
	{
		if(node!=null)
		{
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null 
					&& !node.getEnumeration().getText().trim().equals(""))
			{
				// note 1. ,  section 1. , 1:	enums
				if(node.getEnumeration().getText().toLowerCase().contains("note"))
					return true;
				else if(node.getEnumeration().getText().toLowerCase().contains("section"))
					return true;
				else if(node.getEnumeration().getText().toLowerCase().contains("schedule"))
					return true;
				else if(node.getEnumeration().getText().toLowerCase().contains(":"))
					return true;
				
				// 1. , 2. , 3. enums 
				String enumeration=node.getEnumeration().getText();
				if(enumeration.trim().endsWith("."))
				{
					String intEnum=enumeration.trim().substring(0, enumeration.length()-1);
					if(isNumber(intEnum))
					{
						return true;
					}
				}
				
			}
		}
		return false;
	}
	

	public static boolean isNumber(String intEnum) {
		try
		{
			Integer.parseInt(intEnum.trim());
			return true;
		}
		catch(Exception e){}
		return false;
	}

	// Define Matching priorities and filter nodes.
	private List<HierarchyNode> filterNodesBasedOnPriority(List<HierarchyNode> matchingNodes,String lineItemSectionStr, List<PDFLine> lines)
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		List<String> numberWords=AssociationsUtilities.getNumberWordsFromLine(lines);
		if(numberWords==null || numberWords.size()<1)
			return ret;
		List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
		// bringing all nodes at one level 
		for(HierarchyNode node:matchingNodes)
		{
			List<HierarchyNode> hNodes=AssociationsUtilities.getAllTheNodesFromANode(node);
			nodes.addAll(hNodes);
		}
		matchingNodes.addAll(nodes);
		
		List<HierarchyNode> tables= new ArrayList<HierarchyNode>();
		List<HierarchyNode> paras= new ArrayList<HierarchyNode>();
		List<HierarchyNode> titles= new ArrayList<HierarchyNode>();
		if(matchingNodes!=null && matchingNodes.size()>0)
		{
			// adding the nodes in appropriate list according to its type
			for(HierarchyNode hierarchyNode:matchingNodes)
			{
				Structure node=hierarchyNode.getNode();
				if(node !=null && node.getType().equals(StructureType.TABLE) )
				{
					tables.add(hierarchyNode);
				}
				else if(node !=null && node.getType().equals(StructureType.TITLE) )
				{
					titles.add(hierarchyNode);
				}
				else if(node !=null && node.getType().equals(StructureType.PPARAGRAPH) )
				{
					Paragraph para= (Paragraph) node;
					if(para.getEnumeration()!=null && para.getEnumeration().getText()!=null 
							&& !para.getEnumeration().getText().equals(""))
					{
						titles.add(hierarchyNode);
					}
					else
						paras.add(hierarchyNode);
				}
			}
			
			// Tables check for appropriate node
			for(HierarchyNode node:tables)
			{
				Structure dataNode= (DPTable)node.getNode();
				DPTable table= (DPTable)dataNode;
				List<PDFLine> tableLines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
				int found=0;
				String tableStr="";
				// checking if numbers present in table lines
				for(PDFLine line:tableLines)
				{
					tableStr=tableStr+"\n"+line.getLine();
					for(PDFChunk chunk:line.getChunks())
					{
						for(PDFWord word:chunk.getWords())
						{
							boolean isNumber=AssociationsUtilities.isStringDoubleNumber(word.getWord().trim());
							if(isNumber)
							{
								String numWord=AssociationsUtilities.cleanNumberString(word.getWord());
								if(numberWords.contains(numWord))
								{
									found++;
									System.out.println("Number in table found");
								}
							}
						}
					}
				}
				
				if(((float)found/(float)numberWords.size())>=0.5f)
				{
					ret.add(node);
					break;
				}
				//System.out.println(tableStr);
				// Checking for total ends of the line item
				for(PDFLine line:tableLines)
				{
					if(checkForTotalKeyWordLine(line,lineItemSectionStr))
					{
						ret.add(node);
						break;
					}
				}	
			}
			if(ret.size()>0)
				return ret;
			
			// Paras check for appropriate node
			for(HierarchyNode node:paras)
			{
				
			}
			
			
		}
		
		return ret;
	}
	
	private boolean checkForTotalKeyWordLine(PDFLine line, String lineItemSectionStr) 
	{
		if(line.getLine().toLowerCase().contains("total"))
		{
			if(line.getLine().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
				return true;
		}
		return false;
	}
	
	private List<HierarchyNode> findMatchingHierarchyNodeWithLineItem(String lineItemSectionStr, HierarchyNode hierarchyNode) 
	{
		if(hierarchyNode==null || lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			return null;
		List<HierarchyNode> ret=new ArrayList<HierarchyNode>();
		List<HierarchyNode> nodes=new ArrayList<HierarchyNode>();
		nodes.add(hierarchyNode);
		List<HierarchyNode> tempNodes=findMatchNodesWithTheString(nodes,lineItemSectionStr);
		ret.addAll(tempNodes);
		return ret;
	}

	private List<HierarchyNode> findMatchNodesWithTheString(List<HierarchyNode> nodes, String lineItemSectionStr) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(nodes!=null && nodes.size()>0)
		{
			for(HierarchyNode node:nodes)
			{
				boolean isNodeMatch=isStringPresentInNode(node,lineItemSectionStr);
				if(isNodeMatch)
					ret.add(node);
				if(node.getChildren()!=null && node.getChildren().size()>0)
				{
					List<HierarchyNode> matchNodes= findMatchNodesWithTheString(node.getChildren(),lineItemSectionStr);
					if(matchNodes!=null && matchNodes.size()>0)
						ret.addAll(matchNodes);
				}
			}
		}
		return ret;
	}

	private boolean isStringPresentInNode(HierarchyNode node, String lineItemSectionStr) 
	{
		return AssociationsUtilities.isStringPresentInNode(node,lineItemSectionStr);
	}

	private List<HierarchyNode> findMatchingHierarchyNodeWithEnum(String note, HierarchyNode hierarchyNode,Set<Long> associatedNodes) 
	{
		List<HierarchyNode> matchingNodes= new ArrayList<HierarchyNode>();
		List<List<String>> noteList=AssociationsUtilities.splitEnum(note);
		for(List<String> noteSplit:noteList)
		{
			HierarchyNode node=matchEnumsInHierarchy(hierarchyNode,noteSplit,associatedNodes);
			if(node!=null)
			{
				matchingNodes.add(node);	
			}
		}
		return matchingNodes;
	}
	
	
	private HierarchyNode matchEnumsInHierarchy(HierarchyNode node, List<String> noteSplit, Set<Long> associatedNodes) 
	{
		HierarchyNode ret= null;
		HierarchyNode tempNode=node;
		// Find all 
		boolean isFirst=true;
		for(String note:noteSplit)
		{
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(tempNode);
			if(isFirst)
			{
				HierarchyNode firstTempNode=matchEnumInHierarchyNodeOnMaxLevelDepth(nodes,note,2,0);
				if(firstTempNode!=null)
				{
					tempNode=firstTempNode;
					ret=tempNode;
					associatedNodes.add(ret.getId());
					isFirst=false;
					continue;
				}
			}
			tempNode=matchEnumInHierarchyNode(nodes, note);
			if(tempNode!=null)
			{
				ret=tempNode;
				if(isFirst)
					associatedNodes.add(ret.getId());
			}
			else
				break;
			isFirst=false;
		}
		
		return ret;
	}
	
	private HierarchyNode matchEnumInHierarchyNodeOnMaxLevelDepth(List<HierarchyNode> nodes, 
			String note, int maxDepth,int currentDepth) 
	{
		if(nodes!=null && nodes.size()>0 && currentDepth<=maxDepth)
		{
			for(HierarchyNode childNode:nodes)
			{
				boolean isMatch=false;
				if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null)
					isMatch=AssociationCreator.isNoteAndEnumStringCleanedMatch(note, childNode.getEnumeration().getText());
				
				if(isMatch)
					return childNode;
			}
			for(HierarchyNode childNode:nodes)
			{
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchEnumInHierarchyNodeOnMaxLevelDepth(childNode.getChildren(), note,maxDepth,currentDepth+1);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		
		return null;
	}

	// Hierarchy Traversal
	private HierarchyNode matchEnumInHierarchyNode(List<HierarchyNode> nodes, String note) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			for(HierarchyNode childNode:nodes)
			{
				boolean isMatch;
				if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null)
					isMatch=isNoteAndEnumStringCleanedMatch(note, childNode.getEnumeration().getText());
				else
					isMatch=false;
				if(isMatch)
					return childNode;
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchEnumInHierarchyNode(childNode.getChildren(), note);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}
	
	public static boolean isNoteAndEnumStringCleanedMatch(String note,String enumeration)
	{
		if(note==null || enumeration==null || note.trim().equals("") || enumeration.trim().equals(""))
			return false;
		// Clean enums
		String cleanedEnum=enumeration.trim().replaceAll(":", "");
		if(cleanedEnum.trim().endsWith("."))
		{
			cleanedEnum=cleanedEnum.substring(0, cleanedEnum.length()-1);
		}
		if(cleanedEnum.trim().endsWith(","))
		{
			cleanedEnum=cleanedEnum.substring(0, cleanedEnum.length()-1);
		}
		cleanedEnum=cleanedEnum.trim().replaceAll("note", "").replaceAll("Note", "").replaceAll("NOTE", "");
		cleanedEnum=cleanedEnum.trim().replaceAll("section", "").replaceAll("Section", "").replaceAll("SECTION", "");
		cleanedEnum=cleanedEnum.trim().replaceAll("schedule", "").replaceAll("Schedule", "").replaceAll("SCHEDULE", "");
		if(cleanedEnum.trim().endsWith(")") && !cleanedEnum.trim().startsWith("("))
		{
			cleanedEnum="("+cleanedEnum;
		}
		
		String cleanedNote=note.trim().replaceAll(":", "");
		if(cleanedNote.trim().endsWith("."))
		{
			cleanedNote=cleanedNote.substring(0, cleanedNote.length()-1);
		}
		cleanedNote=cleanedNote.trim().replaceAll("note", "").replaceAll("Note", "").replaceAll("NOTE", "");
		cleanedNote=cleanedNote.trim().replaceAll("section", "").replaceAll("Section", "").replaceAll("SECTION", "");
		cleanedNote=cleanedNote.trim().replaceAll("schedule", "").replaceAll("Schedule", "").replaceAll("SCHEDULE", "");
		if(cleanedNote.trim().endsWith(")") && !cleanedNote.trim().startsWith("("))
		{
			cleanedNote="("+cleanedNote;
		}
		
		if(cleanedNote.trim().equalsIgnoreCase(cleanedEnum.trim()))
			return true;
		
		if(cleanedEnum.trim().endsWith("]"))
		{
			cleanedEnum=cleanedEnum.replaceAll("\\[", "").replaceAll("\\]", "").trim();
			cleanedNote=cleanedNote.replaceAll("\\(", "").replaceAll("\\)", "").trim();
			if(cleanedNote.trim().equalsIgnoreCase(cleanedEnum.trim()))
				return true;
		}
		else if ( (cleanedEnum.trim().contains("(") || cleanedEnum.trim().contains(")")) && !cleanedNote.contains("(") && !cleanedNote.contains(")")  ) 
		{
			if(cleanedNote.trim().toLowerCase().replaceAll("[a-z]", "").equals(""))
			{
				cleanedEnum=cleanedEnum.replaceAll("\\(", "").replaceAll("\\)", "").trim();
				if(cleanedEnum.equalsIgnoreCase(cleanedNote.trim()))
						return true;
			}
		}
		
		return false;
	}
	
}
