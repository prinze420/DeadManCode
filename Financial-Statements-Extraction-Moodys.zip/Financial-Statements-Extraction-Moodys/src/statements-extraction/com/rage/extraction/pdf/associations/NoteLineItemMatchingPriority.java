package com.rage.extraction.pdf.associations;

public class NoteLineItemMatchingPriority 
{
	private String userGroup;
	private int priority;
	private String noteTopic;
	private String lineItemTopic;
	private String cleanedNoteTopic;
	private String cleanedLineItemTopic;
	
	public int getPriority() {
		return priority;
	}
	public void setPriority(int priority) {
		this.priority = priority;
	}
	public String getNoteTopic() {
		return noteTopic;
	}
	public void setNoteTopic(String noteTopic) {
		this.noteTopic = noteTopic;
	}
	public String getLineItemTopic() {
		return lineItemTopic;
	}
	public void setLineItemTopic(String lineItemTopic) {
		this.lineItemTopic = lineItemTopic;
	}
	public String getUserGroup() {
		return userGroup;
	}
	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}
	public String getCleanedNoteTopic() {
		return cleanedNoteTopic;
	}
	public void setCleanedNoteTopic(String cleanedNoteTopic) {
		this.cleanedNoteTopic = cleanedNoteTopic;
	}
	public String getCleanedLineItemTopic() {
		return cleanedLineItemTopic;
	}
	public void setCleanedLineItemTopic(String cleanedLineItemTopic) {
		this.cleanedLineItemTopic = cleanedLineItemTopic;
	}
	
	
	
}
