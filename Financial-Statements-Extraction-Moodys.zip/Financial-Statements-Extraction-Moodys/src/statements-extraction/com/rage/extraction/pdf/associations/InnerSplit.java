package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.dp.hierarchy.HierarchyNode;
import com.dp.structures.Structure;
import com.dp.structures.StructureType;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.gyan.siapp.utils.Triplet;
import com.rage.document.pdf.utils.StringUtility;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.db.MapCols;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.SectionSpreader;

public class InnerSplit 
{

	public static Set<Long> nodesVisited=new HashSet<Long>();
	public static boolean toCheckAllNodesVisited=false; 

	public static boolean isToCheckAllNodesVisited() {
		return toCheckAllNodesVisited;
	}

	public static void setToCheckAllNodesVisited(boolean toCheckAllNodesVisited) {
		InnerSplit.toCheckAllNodesVisited = toCheckAllNodesVisited;
	}

	public void runInnerSplit(List<HierarchyNode> nodes, ParserOutput row, ParserOutput yearRow,ParserOutput monthRow , ParserOutput attributeRow, String secType, String mainBreakUpType, HierarchyNode hierarchyNode,boolean isExplicitFilterCheck, Set<Long> explicitNodesAssociated)
	{
		if(nodes==null || nodes.size()<1)
			return;
		Set<Long> doneNodes=new HashSet<Long>();
		Integer mainEnumGroup=null;
		if(AssociationCreator.mainEnumNode!=null)
		{
			HierarchyNode mainEnumNode=AssociationCreator.mainEnumNode;
			if(mainEnumNode.getEnumeration()!=null && mainEnumNode.getEnumeration().getText()!=null && !mainEnumNode.getEnumeration().getText().trim().equals(""))
			{
				mainEnumGroup=mainEnumNode.getEnumFinalGroupId();
			}
		}
		for(HierarchyNode thisNode:nodes)
		{
			List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(thisNode);

			if(isExplicitFilterCheck)
			{
				allNodes=filterNodes(allNodes,explicitNodesAssociated,thisNode);
			}
			HierarchyNode mainEnumGroupNode=null;
			for(HierarchyNode node:allNodes)
			{
				if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
				{
					if(mainEnumGroup!=null && node.getEnumFinalGroupId()==mainEnumGroup)
					{
						mainEnumGroupNode=node;
					}
				}
				if(toCheckAllNodesVisited && nodesVisited.contains(node.getId()))
					continue;
				nodesVisited.add(node.getId());
				if(doneNodes.contains(node.getId()))
					continue;
				doneNodes.add(node.getId());
				Structure dataNode= node.getNode();
				POBreakUps nodeCoOrds=new POBreakUps(node);
				POBreakUps.setCoOrdinate(nodeCoOrds);
				boolean isTable=false;
				/*if(dataNode.getType().equals(StructureType.TITLE) || dataNode instanceof Title)
				{
					Title title= (Title) dataNode;
					//List<PDFLine> lines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
				}
				else*/ 
				if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
				{
					DPTable table= (DPTable) dataNode;
					//List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
					isTable=true;
				}
				/*else if(dataNode.getType().equals(StructureType.PPARAGRAPH) ||  dataNode instanceof Paragraph)
				{
					Paragraph paragraph= (Paragraph) dataNode;
					List<PDFLine> lines=AssociationsUtilities.getParagraphDataFromHierarchyNode(paragraph);

				}*/
				
				// For Table Title get last enum node before the current node
				HierarchyNode enumeratedHeaderNode=getEnumeratedNodeBeforeThisNode(AssociationCreator.allHierarchyChildNodes,node);
				String headerString=enumeratedHeaderNode!=null?enumeratedHeaderNode.getNode().getStringRepresentation()
						.replaceFirst(Pattern.quote(enumeratedHeaderNode.getEnumeration().getText()), "").trim():null;
				
				// if Node is table, spread the table. find out appropriate rows to be merged.
				if(isTable)
				{
					DPTable table= (DPTable) dataNode ;
					List<PDFBlock> blocks=AssociationsUtilities.getTableBlocksFromHierarchyNode(table);
					List<PDFLine> lines=getLinesFromBlocks(blocks);
					Section sec= new Section(secType.toUpperCase(),lines,null,0,blocks) ;
					ArrayList<ParserOutput> poList =null;
					List<PDFBlock> tempBlocks=new ArrayList<PDFBlock>();
					List<PDFLine> tempLines= new ArrayList<PDFLine>();
					boolean isMainTableFound=false;
					boolean isHeadersWithTableFound=false;
					try
					{
						List<HierarchyNode> pageTables= AssociationsUtilities.getAllNodesForAPage(hierarchyNode,lines.get(0).getPageNo());
						for(int i=pageTables.size()-1;i>=0;i--)
						{
							HierarchyNode thisTempNode=pageTables.get(i);
							if(node.getId()==pageTables.get(i).getId() || isMainTableFound)
							{
								if(!isMainTableFound)
								{
									tempBlocks.addAll(blocks);
									tempLines.addAll(lines);
								}
								poList = SectionSpreader.spreadPageData(sec);

								if(!tableContainsHeader(poList))
								{
									DPTable thisTable= (DPTable) thisTempNode.getNode() ;
									List<PDFBlock> blocks1=AssociationsUtilities.getTableBlocksFromHierarchyNode(thisTable);
									List<PDFLine> lines1=getLinesFromBlocks(blocks1);
									if(isMainTableFound)
									{
										blocks1.addAll(tempBlocks);
										lines1.addAll(tempLines);
									}
									Section temp= new Section(secType.toUpperCase(),lines1,null,0,blocks1) ;
									poList = SectionSpreader.spreadPageData(temp);
									if(tableContainsHeader(poList))
									{
										if(node.getId()!=pageTables.get(i).getId())
											isHeadersWithTableFound=true;
										break;
									}
									tempBlocks=blocks1;
									tempLines=lines1;	

								}
								else
								{
									if(node.getId()!=pageTables.get(i).getId())
										isHeadersWithTableFound=true;
									break;
								}
								isMainTableFound=true;
							}
						}
						if(isHeadersWithTableFound)
						{
							List<PDFLine> headerLines= getHeaderLinesFromPOList(poList);
							headerLines.addAll(lines);
							Section tempSec= new Section(secType.toUpperCase(),headerLines,null,0,blocks) ;
							poList = SectionSpreader.spreadPageData(tempSec);
						}
						else
						{
							poList = SectionSpreader.spreadPageData(sec);
						}
						System.out.println("Table Spreaded for BreakUp");
					}
					catch(Exception e)
					{
						System.out.println(e.getMessage());
						e.printStackTrace();
					}
					if(poList!=null && poList.size()>0)
					{
						// assigning table id same as hierarchy node ID
						for(ParserOutput eachPO:poList)
						{
							eachPO.setTableID((int)node.getId());
						}
						List<ParserOutput> mergedBreakUp=mergingAttributes(row,yearRow,poList,mainBreakUpType,"Table",mainEnumGroupNode,headerString);

						if(mergedBreakUp!=null && mergedBreakUp.size()>0)
						{
							// break table on line item and total rows
							//mergedBreakUp=breakTableOnTotalLines(mergedBreakUp,lineItem,lines);

							for(ParserOutput po:mergedBreakUp)
							{
								po.setBreakups("Y");
								po.setPageNoCoOrdinates(nodeCoOrds);
								if(toCheckAllNodesVisited && mainEnumGroupNode!=null)
								{
									po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
								}
							}
							row.getBreakupItems().addAll(mergedBreakUp);
							row.getMatchingBreakUpItem().add(mergedBreakUp);
						}
						System.out.println("done merging");
					}
				}
				else
				{
					List<Triplet<String, String, String>> triplets = NLPTextBreakUpAssociation.getMatchingTripletsFromSentence(dataNode.getStringRepresentation());
					List<TextValuesExtraction> textValuesExtractionList = NLPTextBreakUpAssociation.createTabularData(triplets);
					ArrayList<ArrayList<ParserOutput>> poLists = createPOList(textValuesExtractionList,row,dataNode.getStringRepresentation(),nodeCoOrds);
					for(ArrayList<ParserOutput> poList:poLists)
					{
						List<ParserOutput> mergedBreakUp=mergingAttributes(row,yearRow,poList,mainBreakUpType,"TextBreakUp",mainEnumGroupNode,null);
						if(mergedBreakUp!=null && mergedBreakUp.size()>0)
						{
							for(ParserOutput po:mergedBreakUp)
							{
								po.setBreakups("Y");
								po.setPageNoCoOrdinates(nodeCoOrds);
								if(toCheckAllNodesVisited && mainEnumGroupNode!=null)
								{
									po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
								}
							}
							row.getBreakupItems().addAll(mergedBreakUp);
							row.getMatchingBreakUpItem().add(mergedBreakUp);
						}
					}

				}

			}
		}
	}

	private HierarchyNode getEnumeratedNodeBeforeThisNode(List<HierarchyNode> allHierarchyChildNodes,
			HierarchyNode node) 
	{
		if(allHierarchyChildNodes==null || allHierarchyChildNodes.size()<1 || node==null)
			return null;
		HierarchyNode ret= null;
		boolean isFound=false;
		for(HierarchyNode thisNode:allHierarchyChildNodes)
		{
			if(thisNode.getId()==node.getId())
			{
				isFound=true;
				break;
			}
			if(thisNode.getEnumeration()!=null && thisNode.getEnumeration().getText()!=null && !thisNode.getEnumeration().getText().trim().equals(""))
				ret=thisNode;
		}
		if(isFound)
			return ret;
		return null;
	}

	public void runInnerSplitForImplicitMetadata(List<HierarchyNode> nodes, ParserOutput row, ParserOutput yearRow,ParserOutput monthRow , ParserOutput attributeRow, String secType, String mainBreakUpType, HierarchyNode hierarchyNode,boolean onlyTextBreakUp, String searchString)
	{
		if(nodes==null || nodes.size()<1)
			return;
		Set<Long> doneNodes=new HashSet<Long>();
		if(!onlyTextBreakUp)
		{
			for(HierarchyNode thisNode:nodes)
			{
				List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(thisNode);
				allNodes=filterNodesBasedOnType(onlyTextBreakUp,allNodes);
				HierarchyNode mainEnumGroupNode=null;
				for(HierarchyNode node:allNodes)
				{
					if(nodesVisited.contains(node.getId()))
						continue;
					nodesVisited.add(node.getId());
					if(doneNodes.contains(node.getId()))
						continue;
					doneNodes.add(node.getId());
					Structure dataNode= node.getNode();
					POBreakUps nodeCoOrds=new POBreakUps(node);
					POBreakUps.setCoOrdinate(nodeCoOrds);
					boolean isTable=false;

					if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
					{
						isTable=true;
					}
					
					// For Table Title get last enum node before the current node
					HierarchyNode enumeratedHeaderNode=getEnumeratedNodeBeforeThisNode(AssociationCreator.allHierarchyChildNodes,node);
					String headerString=enumeratedHeaderNode!=null?enumeratedHeaderNode.getNode().getStringRepresentation()
							.replaceFirst(Pattern.quote(enumeratedHeaderNode.getEnumeration().getText()), "").trim():null;
					
					// if Node is table, spread the table. find out appropriate rows to be merged.
					if(isTable)
					{
						DPTable table= (DPTable) dataNode ;
						List<PDFBlock> blocks=AssociationsUtilities.getTableBlocksFromHierarchyNode(table);
						List<PDFLine> lines=getLinesFromBlocks(blocks);
						Section sec= new Section(secType.toUpperCase(),lines,null,0,blocks) ;
						ArrayList<ParserOutput> poList =null;
						List<PDFBlock> tempBlocks=new ArrayList<PDFBlock>();
						List<PDFLine> tempLines= new ArrayList<PDFLine>();
						boolean isMainTableFound=false;
						boolean isHeadersWithTableFound=false;
						try
						{
							List<HierarchyNode> pageTables= AssociationsUtilities.getAllNodesForAPage(hierarchyNode,lines.get(0).getPageNo());
							for(int i=pageTables.size()-1;i>=0;i--)
							{
								HierarchyNode thisTempNode=pageTables.get(i);
								if(node.getId()==pageTables.get(i).getId() || isMainTableFound)
								{
									if(!isMainTableFound)
									{
										tempBlocks.addAll(blocks);
										tempLines.addAll(lines);
									}
									poList = SectionSpreader.spreadPageData(sec);

									if(!tableContainsHeader(poList))
									{
										DPTable thisTable= (DPTable) thisTempNode.getNode() ;
										List<PDFBlock> blocks1=AssociationsUtilities.getTableBlocksFromHierarchyNode(thisTable);
										List<PDFLine> lines1=getLinesFromBlocks(blocks1);
										if(isMainTableFound)
										{
											blocks1.addAll(tempBlocks);
											lines1.addAll(tempLines);
										}
										Section temp= new Section(secType.toUpperCase(),lines1,null,0,blocks1) ;
										poList = SectionSpreader.spreadPageData(temp);
										if(tableContainsHeader(poList))
										{
											if(node.getId()!=pageTables.get(i).getId())
												isHeadersWithTableFound=true;
											break;
										}
										tempBlocks=blocks1;
										tempLines=lines1;	

									}
									else
									{
										if(node.getId()!=pageTables.get(i).getId())
											isHeadersWithTableFound=true;
										break;
									}
									isMainTableFound=true;
								}
							}
							if(isHeadersWithTableFound)
							{
								List<PDFLine> headerLines= getHeaderLinesFromPOList(poList);
								headerLines.addAll(lines);
								Section tempSec= new Section(secType.toUpperCase(),headerLines,null,0,blocks) ;
								poList = SectionSpreader.spreadPageData(tempSec);
							}
							else
							{
								poList = SectionSpreader.spreadPageData(sec);
							}
							System.out.println("Table Spreaded for BreakUp");
						}
						catch(Exception e)
						{
							System.out.println(e.getMessage());
							e.printStackTrace();
						}
						if(poList!=null && poList.size()>0)
						{
							for(ParserOutput eachPO:poList)
							{
								eachPO.setTableID((int)node.getId());
							}
							List<ParserOutput> mergedBreakUp=mergingAttributes(row,yearRow,poList,mainBreakUpType,"Table",mainEnumGroupNode,headerString);
							if(mergedBreakUp!=null && mergedBreakUp.size()>0)
							{
								// break table on line item and total rows
								//mergedBreakUp=breakTableOnTotalLines(mergedBreakUp,lineItem,lines);

								for(ParserOutput po:mergedBreakUp)
								{
									po.setBreakups("Y");
									po.setMatchingImplicitKeyWord(searchString);
									po.setPageNoCoOrdinates(nodeCoOrds);
									if(toCheckAllNodesVisited && mainEnumGroupNode!=null)
									{
										po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
									}
								}
								row.getBreakupItems().addAll(mergedBreakUp);
								row.getMatchingBreakUpItem().add(mergedBreakUp);
							}
							else
							{
								if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
								{
									for(List<ParserOutput> poL:row.getSupplementaryBreakUpItem())
									{
										for(ParserOutput po:poL)
										{
											po.setMatchingImplicitKeyWord(searchString);
										}
									}
								}
							}
							System.out.println("done merging");
						}
					}
				}
			}
		}
		else
		{/*
			for(HierarchyNode thisNode:nodes)
			{
				List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(thisNode);
				allNodes=filterNodesBasedOnType(onlyTextBreakUp,allNodes);
				HierarchyNode mainEnumGroupNode=null;
				for(HierarchyNode node:allNodes)
				{
					if(toCheckAllNodesVisited && nodesVisited.contains(node.getId()))
						continue;
					if(doneNodes.contains(node.getId()))
						continue;
					Structure dataNode= node.getNode();
					POBreakUps nodeCoOrds=new POBreakUps(node);
					POBreakUps.setCoOrdinate(nodeCoOrds);
					List<Triplet<String, String, String>> triplets = NLPTextBreakUpAssociation.getMatchingTripletsFromSentence(dataNode.getStringRepresentation());
					List<TextValuesExtraction> textValuesExtractionList = NLPTextBreakUpAssociation.createTabularData(triplets);
					ArrayList<ArrayList<ParserOutput>> poLists = createPOList(textValuesExtractionList,row,dataNode.getStringRepresentation(),nodeCoOrds);
					for(ArrayList<ParserOutput> poList:poLists)
					{
						List<ParserOutput> mergedBreakUp=mergingAttributes(row,yearRow,poList,mainBreakUpType,"TextBreakUp",mainEnumGroupNode);
						if(mergedBreakUp!=null && mergedBreakUp.size()>0)
						{
							for(ParserOutput po:mergedBreakUp)
							{
								po.setBreakups("Y");
								po.setPageNoCoOrdinates(nodeCoOrds);
								if(toCheckAllNodesVisited && mainEnumGroupNode!=null)
								{
									po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
								}
							}
							row.getBreakupItems().addAll(mergedBreakUp);
							row.getMatchingBreakUpItem().add(mergedBreakUp);
						}
					}
				}
			}
		 */}
	}

	public static List<Pair<TopicKeywords,HierarchyNode>> getMatchingTablesWithTopicKeywords(List<HierarchyNode> nodes,List<TopicKeywords> keywords)
	{
		if(nodes==null || nodes.size()<1)
			return null;
		List<Pair<TopicKeywords,HierarchyNode>> ret= new ArrayList<Pair<TopicKeywords,HierarchyNode>>();
		for(HierarchyNode thisNode:nodes)
		{
			List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(thisNode);
			allNodes=filterNodesBasedOnType(false,allNodes);
			for(HierarchyNode node:allNodes)
			{
				Structure dataNode= node.getNode();
				boolean isTable=false;

				if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
				{
					isTable=true;
				}
				if(isTable)
				{
					DPTable table= (DPTable) dataNode ;
					List<PDFBlock> blocks=AssociationsUtilities.getTableBlocksFromHierarchyNode(table);
					List<PDFLine> lines=getLinesFromBlocks(blocks);
					boolean isMatchFound=false;
					for(PDFLine line:lines)
					{
						for(TopicKeywords eachTopic:keywords)
						{
							String kw=eachTopic.getCleanedTopic();
							if(StringUtility.doesKeywordMatchTokenSerial(kw, line.getLine()))
							{
								isMatchFound=true;
								eachTopic.setMatchedKeyword(kw);
								Pair<TopicKeywords,HierarchyNode> matchedNode=new Pair<TopicKeywords, HierarchyNode>(eachTopic,node);
								System.out.println("MATCHED LINE ITEM TABLE ASSOCIATED TO BS::"+kw);
								System.out.println("NODE TO BS::"+node.getNode().getStringRepresentation());
								ret.add(matchedNode);
								break;
							}
							if(isMatchFound)
								break;
						}
						if(isMatchFound)
							break;
					}
					if(isMatchFound)
					{
						continue;
					}
				}
			}
		}
		return ret;
	}

	private boolean checkForKeywordMatchForBS(List<PDFLine> lines, List<TopicKeywords> bSnoteKWList) 
	{
		if(lines==null || lines.size()<1 || bSnoteKWList==null || bSnoteKWList.size()<1)
			return false;

		for(PDFLine line:lines)
		{
			for(TopicKeywords eachTopic:bSnoteKWList)
			{
				for(String kw:eachTopic.getKeywords())
				{
					if(StringUtility.doesKeywordMatchTokenSerial(kw, line.getLine()))
					{
						return true;
					}
				}
			}
		}
		return false;
	}

	public static List<HierarchyNode> filterNodesBasedOnType(boolean onlyTextBreakUp, List<HierarchyNode> allNodes) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		for(HierarchyNode node:allNodes)
		{
			Structure dataNode= node.getNode();
			boolean isTable=false;
			if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
			{
				isTable=true;
			}
			if(onlyTextBreakUp && isTable)
				continue;
			else if (!onlyTextBreakUp && !isTable)
				continue;
			ret.add(node);
		}
		return ret;
	}

	private List<HierarchyNode> filterNodes(List<HierarchyNode> allNodes, Set<Long> explicitNodesAssociated, HierarchyNode thisNode) 
	{
		allNodes=filterNodesBasedOnEnumsChecks(allNodes,explicitNodesAssociated,thisNode);

		return allNodes;
	}

	private List<HierarchyNode> filterNodesBasedOnEnumsChecks(List<HierarchyNode> allNodes,
			Set<Long> explicitNodesAssociated, HierarchyNode thisNode) 
			{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(allNodes==null || allNodes.size()<1)
			return ret;
		for(HierarchyNode node:allNodes)
		{
			if(explicitNodesAssociated.contains(node.getId()) && node.getId()!=thisNode.getId())
			{
				break;
			}
			ret.add(node);
		}

		return ret;
			}

	public static ParserOutput getAllRemainingAssociations(HierarchyNode node)
	{
		ParserOutput po = new ParserOutput();
		List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
		po.setSection("ALL_SUPPL");
		nodes.add(node);
		InnerSplit is= new InnerSplit();
		is.runInnerSplit(nodes, po, null, null, null, "ALL_SUPPL", null, node,false,null);
		/*Integer enumType=null;
		if(AssociationCreator.mainEnumNode!=null)
		{
			enumType=AssociationCreator.mainEnumNode.getEnumFinalGroupId();
		}
		if(po.getSupplementaryBreakUpItem()!=null && po.getSupplementaryBreakUpItem().size()>0 && AssociationCreator.mainEnumNode!=null)
		{
			HierarchyNode enumNode=null;
			for(List<ParserOutput> breakUps:po.getSupplementaryBreakUpItem())
			{
				for(ParserOutput breakUp:breakUps)
				{

				}
			}
		}*/
		return po;
	}

	private List<PDFLine> getHeaderLinesFromPOList(ArrayList<ParserOutput> poList) 
	{
		List<PDFLine> headerLines= new ArrayList<PDFLine>();
		if(poList==null || poList.size()<1)
			return headerLines;
		boolean isHeaderLineFound= false;
		boolean isYearFound= false;
		int i=0;
		for(ParserOutput row:poList)
		{
			if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
			{
				headerLines.addAll(row.getRow().getLines());
				isYearFound=isYearPresentInHeaderLines(headerLines);
				isHeaderLineFound=true;
				continue;
			}
			if(isHeaderLineFound && !isYearFound && i<4)
			{
				i++;
				List<PDFLine> lines=row.getRow().getLines();
				if(lines!=null)
				{
					isYearFound=isYearPresentInHeaderLines(lines);
				}
				if(isYearFound)
				{
					headerLines.addAll(lines);
				}
			}
		}
		return headerLines;
	}

	private boolean isYearPresentInHeaderLines(List<PDFLine> headerLines) 
	{
		if(headerLines==null || headerLines.size()<1)
			return false;

		for(PDFLine line:headerLines)
		{
			for(PDFChunk chunk:line.getChunks())
			{
				for(PDFWord word:chunk.getWords())
				{
					Pattern p= Pattern.compile("2010|2011|2012|2013|2014|2015|2016|2017|2018|2019|2020");
					Matcher m= p.matcher(word.getWord());
					if(m.matches())
						return true;
				}
			}
		}

		return false;
	}

	private boolean tableContainsHeader(ArrayList<ParserOutput> poList) 
	{
		if(poList==null || poList.size()<1)
			return false;

		for(ParserOutput row:poList)
		{
			if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
			{
				return true;
			}
		}
		return false;
	}


	private List<ParserOutput> breakTableOnTotalLines(List<ParserOutput> mergedBreakUp, String lineItem, List<PDFLine> rowLines) 
	{
		if(mergedBreakUp==null || mergedBreakUp.size()<1)
			return mergedBreakUp;
		List<ParserOutput> ret= new ArrayList<ParserOutput>();

		Pair<Integer,Integer> pair=getStartAndEndOfTableBasedOnTotalRows(mergedBreakUp,lineItem,rowLines);
		int start=pair.getA();
		int end=pair.getB();
		boolean isHeaderRowFound=false;
		for(int i=0;i<mergedBreakUp.size();i++)
		{
			ParserOutput row=mergedBreakUp.get(i);

			if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
			{
				isHeaderRowFound=true;
				ret.add(row);
				continue;
			}

			if(!isHeaderRowFound)
			{
				if(start!=-1 && end!=-1)
				{
					if(i>=start && i<=end)
						ret.add(row);
				}
				else
					ret.add(row);
				continue;
			}

			if(start!=-1 && end!=-1)
			{
				if(i>=start && i<=end)
					ret.add(row);
			}
			else
				ret.add(row);

		}

		return ret;
	}

	private Pair<Integer, Integer> getStartAndEndOfTableBasedOnTotalRows(List<ParserOutput> mergedBreakUp,
			String lineItem, List<PDFLine> rowLines) 
			{
		int start=-1;
		int end=-1;
		if(mergedBreakUp==null || mergedBreakUp.size()<1 || lineItem==null || lineItem.trim().equals(""))
			return new Pair<Integer,Integer>(start,end);

		for(int i=0;i<mergedBreakUp.size();i++)
		{
			ParserOutput row=mergedBreakUp.get(i);
			if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
				continue;
			String thisTableLineItem=row.getAsRepLabel();
			if(lineItem.trim().toLowerCase().contains(thisTableLineItem.trim().toLowerCase()))
			{
				if(start==-1)
				{
					start=i;
					continue;
				}
			}
			if(lineItem.trim().toLowerCase().contains(thisTableLineItem.trim().toLowerCase()))
			{
				if(thisTableLineItem.toLowerCase().contains("total"))
				{
					end=i;
					break;
				}
			}
			boolean areTotalValuesPresent=isRowNumberPresentInTableLines(rowLines,row.getRow().getLines());
			if(areTotalValuesPresent)
			{
				end=i;
				break;
			}
		}

		return new Pair<Integer,Integer>(start,end);
			}

	public static boolean isRowNumberPresentInTableLines(List<PDFLine> lines,List<PDFLine> tableLines)
	{
		List<String> numberWords=AssociationsUtilities.getNumberWordsFromLine(lines);
		int found=0;
		// checking if numbers present in table lines
		for(PDFLine line:tableLines)
		{
			for(PDFChunk chunk:line.getChunks())
			{
				for(PDFWord word:chunk.getWords())
				{
					boolean isNumber=AssociationsUtilities.isStringDoubleNumber(word.getWord().trim());
					if(isNumber)
					{
						String numWord=AssociationsUtilities.cleanNumberString(word.getWord());
						if(numberWords.contains(numWord))
						{
							found++;
							//System.out.println("Number in table found");
						}
					}
				}
			}
		}

		if(((float)found/(float)numberWords.size())>=0.5f)
		{
			return true;
		}

		return false;
	}

	public static ArrayList<ArrayList<ParserOutput>> createPOList(
			List<TextValuesExtraction> textValuesExtractionList, ParserOutput row, String nodeString, POBreakUps nodeCoOrds) {
		ArrayList<ArrayList<ParserOutput>> ret= new ArrayList<ArrayList<ParserOutput>>();
		for(TextValuesExtraction textValuesExtraction:textValuesExtractionList)
		{
			//TextValuesExtraction textValuesExtraction;
			ArrayList<ParserOutput> poObjects = new ArrayList<ParserOutput>();
			String lineItem = textValuesExtraction.getLineItem();
			LinkedHashMap<String, LinkedList<String>> timeperiodvalueMap = textValuesExtraction.getTimePeriodValuesMap();
			int ct = 1;
			//InsertHeadersFirst
			ParserOutput po = new ParserOutput();
			//po.setMatchingImplicitKeyWord(textValuesExtraction.getMatchedImplicitItem());
			po.setSubSection("HEADER");
			po.setIsHeading("Y");
			boolean isFirst=true;
			for(String timeperiod: timeperiodvalueMap.keySet())
			{
				//	LinkedList<String> values = timeperiodvalueMap.get(timeperiod);
				setPoObject(row, poObjects, po, ct, timeperiod,isFirst,nodeCoOrds);
				isFirst=false;
				ct++;
			}
			//InsertLineItems and Values
			po = new ParserOutput();
			//po.setMatchingImplicitKeyWord(textValuesExtraction.getMatchedImplicitItem());
			po.setAsRepLabel(lineItem);
			isFirst=true;
			ct=1;
			for(String timeperiod: timeperiodvalueMap.keySet())
			{
				LinkedList<String> values = timeperiodvalueMap.get(timeperiod);
				String combinedValues = "";
				for(int i=0;i<values.size();i++)
				{
					String value = values.get(i);
					if(i==0)
						combinedValues = value;
					else
						combinedValues = combinedValues +";"+value;

				}
				setPoObject(row, poObjects, po, ct, combinedValues,isFirst,nodeCoOrds);
				isFirst=false;
				ct++;
			}
			if(poObjects.size()>0)
				ret.add(poObjects);
		}
		/*if(textValuesExtractionList==null || textValuesExtractionList.size()<1)
		{
			ParserOutput po = new ParserOutput();
			setPoObject(row, poObjects, po, 0, nodeString,true);
		}*/
		return ret;
	}

	public static void setPoObject(ParserOutput row, List<ParserOutput> poObjects,
			ParserOutput po, int ct, String colVal,boolean isAddInList, POBreakUps nodeCoOrds) {
		String coOrds = null;
		if(nodeCoOrds!=null)
		{
			coOrds = nodeCoOrds.getStartPgX1()+","+nodeCoOrds.getStartPgY1()+","+nodeCoOrds.getEndPgX2()+","+nodeCoOrds.getEndPgY2()+","+(nodeCoOrds.getStartPg()+1);
			po.setyCoords(nodeCoOrds.getEndPgY2());
			po.setPageNo(nodeCoOrds.getStartPg());
		}
		switch(ct)
		{

		case 0:
		{
			po.setAsRepLabel(colVal);
		}
		break;
		case 1:
		{
			po.setAsRepVal1(colVal);
			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue1("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue1((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
				else
					po.setValue1(colVal);

			po.setVal1Coords(coOrds);
			break;
		}

		case 2:
		{
			po.setAsRepVal2(colVal);

			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue2("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue2((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
				else
					po.setValue2(colVal);
			po.setVal2Coords(coOrds);

			break;
		}

		case 3:
		{
			po.setAsRepVal3(colVal);

			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue3("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue3((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", ""));
				else
					po.setValue3(colVal);

			po.setVal3Coords(coOrds);

			break;
		}

		case 4:
		{
			po.setAsRepVal4(colVal);
			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue4("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue4((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue4(colVal);
			po.setVal4Coords(coOrds);

			break;
		}

		case 5:
		{
			po.setAsRepVal5(colVal);

			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue5("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue5((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue5(colVal);
			po.setVal5Coords(coOrds);

			break;
		}

		case 6:
		{
			po.setAsRepVal6(colVal);
			po.setVal6Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue6("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue6((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue6(colVal);
			break;
		}

		case 7:
		{
			po.setAsRepVal7(colVal);
			po.setVal7Coords(coOrds);

			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue7("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue7((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue7(colVal);
			break;
		}

		case 8:
		{
			po.setAsRepVal8(colVal);
			po.setVal8Coords(coOrds);

			if(SectionSpreader.isNumber(colVal))
			{
				po.setValue8(colVal.replaceAll(" ", ""));
			}
			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue8("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue8((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue8(colVal);
			break;
		}

		case 9:
		{
			po.setAsRepVal9(colVal);
			po.setVal9Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue9("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue9((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue9(colVal);
			break;
		}
		case 10:
		{
			po.setAsRepVal10(colVal);
			po.setVal10Coords(coOrds);

			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue10("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue10((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue10(colVal);
			break;
		}
		case 11:
		{
			po.setAsRepVal11(colVal);
			po.setVal11Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue11("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue11((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue11(colVal);
			break;
		}
		case 12:
		{
			po.setAsRepVal12(colVal);
			po.setVal12Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue12("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue12((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue12(colVal);
			break;
		}

		case 13:
		{
			po.setAsRepVal13(colVal);
			po.setVal13Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue13("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue13((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue13(colVal);
			break;
		}

		case 14:
		{
			po.setAsRepVal14(colVal);
			po.setVal14Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue14("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue14((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue14(colVal);
			break;
		}

		case 15:
		{
			po.setAsRepVal15(colVal);
			po.setVal15Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue15("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue15((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue15(colVal);
			break;
		}

		case 16:
		{
			po.setAsRepVal16(colVal);
			po.setVal16Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue16("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue16((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue16(colVal);
			break;
		}

		case 17:
		{
			po.setAsRepVal17(colVal);
			po.setVal17Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue17("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue17((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue17(colVal);
			break;
		}

		case 18:
		{
			po.setAsRepVal18(colVal);
			po.setVal18Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue18("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue18((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue18(colVal);
			break;
		}

		case 19:
		{
			po.setAsRepVal19(colVal);
			po.setVal19Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue19("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue19((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue19(colVal);
			break;
		}

		case 20:
		{
			po.setAsRepVal20(colVal);
			po.setVal20Coords(coOrds);


			if (colVal.replaceAll("[,¥$]", "").trim().startsWith("(") && SectionSpreader.isNumber(colVal))
				po.setValue20("-"+colVal.replaceAll("[,¥$()]", "").replaceAll(" ", "").trim());
			else
				if(SectionSpreader.isNumber(colVal) && !colVal.replaceAll("[,¥$]", "").trim().startsWith("("))
					po.setValue20((colVal.replaceAll("[,¥$]", "")).replaceAll(" ", "").trim());
				else
					po.setValue20(colVal);
			break;
		}

		}

		po.setType("ROW");
		//	System.out.println(" POASRPLABEL  "+po.getAsRepLabel());
		//	System.out.println("PDFLINE   "+po.getPdfLine().getLine()+"\n");
		po.setBreakups("Y");
		po.setSection(row.getSection());
		if(isAddInList)
			poObjects.add(po);
	}

	public static List<ParserOutput> mergingAttributes(ParserOutput mainPO, ParserOutput yearRow,
			ArrayList<ParserOutput> poList, String mainBreakUpType,String breakUpType, HierarchyNode mainEnumGroupNode, String headerString) 
			{
		ParserOutput thisYearRow=null;
		ParserOutput thisAttributeRow=null;
		ParserOutput thisMonthRow=null;
		Map<Integer, Integer> thisAttrMap=null;
		ArrayList<ParserOutput> ret= new ArrayList<ParserOutput>();

		if(poList==null || poList.size()<1)
		{
			return null;
		}
		// Creating matching attribute map
		for(ParserOutput row:poList)
		{
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT YEAR") )
			{
				thisYearRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT FOR") )
			{
				thisAttributeRow=row;
				continue;
			}
			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT MONTH") )
			{
				thisMonthRow=row;
				continue;
			}
			if(breakUpType!=null && breakUpType.equalsIgnoreCase("TextBreakUp"))
			{
				thisYearRow=poList.get(0);
			}
			if(/*thisAttributeRow!=null && */thisYearRow!=null /*&& thisMonthRow!=null*/)
			{
				thisAttrMap=getAttrYearMatchingValueMap(thisYearRow,yearRow,mainPO);
				break;
			}
		}

		for(ParserOutput po:poList)
		{
			boolean isHeader=false;
			if(po.getIsHeading()!=null && po.getIsHeading().toLowerCase().contains("y"))
			{
				isHeader=true;
			}
			else if(po.getType()!=null && po.getType().trim().equalsIgnoreCase("HEADER"))
			{
				isHeader=true;
			}
			else if (po.getSubSection()!=null && po.getSubSection().trim().equalsIgnoreCase("header"))
			{
				isHeader=true;
			}
			if(isHeader && headerString!=null && !headerString.trim().equals(""))
			{
				po.setAsRepLabel(headerString);
			}
		}

		boolean isSupplementary=false;
		if(thisAttrMap==null || thisAttrMap.size()<1)
			isSupplementary=true;

		for(Integer col:thisAttrMap.keySet())
		{
			if(thisAttrMap.get(col)==null)
				isSupplementary=true;
		}

		int maxCol = mainPO.getMaxCol();
		int thisBreakUpMaxCol=0;

		for(ParserOutput row:poList)
		{
			if(row.getMaxCol()>thisBreakUpMaxCol)
				thisBreakUpMaxCol=row.getMaxCol();
		}

		// Assigning the values to be merged from the matching map
		boolean isFirstFound = false;
		ret = mapColumnsMatches(poList, mainBreakUpType, breakUpType, thisAttrMap,
				isSupplementary,true,headerString);
		if(isSupplementary && thisBreakUpMaxCol>0 && mainBreakUpType!=null && mainBreakUpType.equalsIgnoreCase("explicit"))
		{
			if(maxCol==thisBreakUpMaxCol)
				isSupplementary=false;
		}

		if(isSupplementary && ret!=null && ret.size()>0)
		{
			//Add to all_suppl
			if(mainEnumGroupNode!=null)
			{
				for(ParserOutput po:ret)
				{
					boolean isHeader=false;
					if(po.getIsHeading()!=null && po.getIsHeading().toLowerCase().contains("y"))
					{
						isHeader=true;
					}
					else if(po.getType()!=null && po.getType().trim().equalsIgnoreCase("HEADER"))
					{
						isHeader=true;
					}
					else if (po.getSubSection()!=null && po.getSubSection().trim().equalsIgnoreCase("header"))
					{
						isHeader=true;
					}
					if(isHeader && headerString!=null && !headerString.trim().equals(""))
					{
						po.setAsRepLabel(headerString);
					}
					po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
				}
			}
			mainPO.getSupplementaryBreakUpItem().add(ret);

			//check values of all columns to values in the suppl (ie total match) and map accordingly
			List<ParserOutput> poMatches = null;
			if(breakUpType.equalsIgnoreCase("Table"))
			{
				System.out.println("====Values Check starts for "+mainPO.getAsRepLabel());

				Map<Integer, Integer> columnsMatchMap = getTotalColumnMatchMap(mainPO,ret);
				if(columnsMatchMap!=null && columnsMatchMap.size()>0)
				{
					poMatches =  mapColumnsMatches(poList, mainBreakUpType, breakUpType, columnsMatchMap,
							isSupplementary,false,headerString);
				}
				System.out.println("====Values Check ends for "+mainPO.getAsRepLabel());

			}
			if(poMatches!=null && poMatches.size()>0 )
				return poMatches;
			else
				return null;
		}

		/*	if(isSupplementary && ret!=null && ret.size()>0)
		{
			if(mainEnumGroupNode!=null)
			{
				for(ParserOutput po:ret)
					po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
			}
			mainPO.getSupplementaryBreakUpItem().add(ret);
			return null;
		}*/

		return ret;
			}

	public static ArrayList<ParserOutput> mapColumnsMatches(ArrayList<ParserOutput> poList,
			String mainBreakUpType, String breakUpType,
			Map<Integer, Integer> thisAttrMap, 
			boolean isSupplementary, boolean isAttributeMatch, String headerString) {
		ArrayList<ParserOutput> ret = new ArrayList<ParserOutput>() ;
		for(ParserOutput row:poList)
		{
			row.setBreakUpMainType(mainBreakUpType);
			row.setBreakUpType(breakUpType);

			if(row.getAsRepLabel()!=null && row.getAsRepLabel().toUpperCase().startsWith("STATEMENT") )
				continue;
			else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("ATTR"))
				continue;

			if((!isSupplementary && isAttributeMatch)  )
			{
				Map<Integer,String> colValueMap=getColumnValueMap(row,"val");
				Map<Integer,String> colAsRepValueMap=getColumnValueMap(row,"as_rep");
				if(thisAttrMap!=null && thisAttrMap.size()>0)
				{
					clearAllColumnValueMap(row);
					MapCols.setPOValueOnIndex(row, 0, colValueMap.get(0));
					for(Integer fromColNo:thisAttrMap.keySet())
					{
						Integer toColNo=thisAttrMap.get(fromColNo);
						String val=colValueMap.get(fromColNo);
						String asRepVal=colAsRepValueMap.get(fromColNo);
						MapCols.setPOValueOnIndex(row, toColNo, val);
						MapCols.setPOAsRepValueOnIndex(row, toColNo, asRepVal);
					}

				}
				boolean isHeader=false;
				if(row.getIsHeading()!=null && row.getIsHeading().toLowerCase().contains("y"))
				{
					isHeader=true;
				}
				else if(row.getType()!=null && row.getType().trim().equalsIgnoreCase("HEADER"))
				{
					isHeader=true;
				}
				else if (row.getSubSection()!=null && row.getSubSection().trim().equalsIgnoreCase("header"))
				{
					isHeader=true;
				}
				if(isHeader && headerString!=null && !headerString.trim().equals(""))
				{
					row.setAsRepLabel(headerString);
				}
			}
			else		
				if((isSupplementary && !isAttributeMatch) )
				{
					ParserOutput newRow = new ParserOutput();
					Map<Integer,String> colValueMap=getColumnValueMap(row,"val");
					Map<Integer,String> colAsRepValueMap=getColumnValueMap(row,"as_rep");
					Map<Integer,String> colCoordMap=getColumnCoordMap(row);

					if(thisAttrMap!=null && thisAttrMap.size()>0)
					{
						//clearAllColumnValueMap(row);
						copyPoRow(row, newRow);
						
						MapCols.setPOValueOnIndex(newRow, 0, colValueMap.get(0));
						for(Integer toColNo:thisAttrMap.keySet())
						{
							Integer fromColNo = thisAttrMap.get(toColNo);
							String val=colValueMap.get(fromColNo);
							String asRepVal=colAsRepValueMap.get(fromColNo);
							String coOrd=colCoordMap.get(fromColNo);
							MapCols.setPOValueOnIndex(newRow, toColNo, val);
							MapCols.setPOAsRepValueOnIndex(newRow, toColNo, asRepVal);
							MapCols.setColCoordMap(newRow, toColNo, coOrd);
						}
						boolean isHeader=false;
						if(newRow.getIsHeading()!=null && newRow.getIsHeading().toLowerCase().contains("y"))
						{
							isHeader=true;
						}
						else if(newRow.getType()!=null && newRow.getType().trim().equalsIgnoreCase("HEADER"))
						{
							isHeader=true;
						}
						else if (newRow.getSubSection()!=null && newRow.getSubSection().trim().equalsIgnoreCase("header"))
						{
							isHeader=true;
						}
						if(isHeader && headerString!=null && !headerString.trim().equals(""))
						{
							newRow.setAsRepLabel(headerString);
						}
						ret.add(newRow);
					}
					continue;

				}
			if(isAttributeMatch)
			{
				ret.add(row);
			}
		}

		return ret;
	}

	private static Map<Integer, String> getColumnCoordMap(ParserOutput row
			) {
		Map<Integer,String> ret= new HashMap<Integer,String>();
		for(int i=0;i<=30;i++)
		{
			ret.put(i, MapCols.getPOCordOnIndex(row, i));

		}
		return ret;
	}

	public static Map<Integer,Integer> getTotalColumnMatchMap(ParserOutput mainPO,
			ArrayList<ParserOutput> ret) {
		Map<Integer,Integer> columnMatchMap = null;
		Map<Integer,Integer>  retColumnMatchMap = new HashMap<Integer,Integer>();
		String val1 = mainPO.getValue1();
		String val2 = mainPO.getValue2();
		String val3 = mainPO.getValue3();
		String val4 = mainPO.getValue4();
		String val5 = mainPO.getValue5();
		String val6 = mainPO.getValue6();
		String val7 = mainPO.getValue7();
		String val8 = mainPO.getValue8();
		String val9 = mainPO.getValue9();
		String val10 = mainPO.getValue10();
		String val11 = mainPO.getValue11();
		String val12 = mainPO.getValue12();
		String val13 = mainPO.getValue13();
		String val14 = mainPO.getValue14();
		String val15 = mainPO.getValue15();
		String val16 = mainPO.getValue16();
		String val17 = mainPO.getValue17();
		String val18 = mainPO.getValue18();
		String val19 = mainPO.getValue19();
		String val20 = mainPO.getValue20();
		String val21 = mainPO.getValue21();
		String val22 = mainPO.getValue22();
		String val23 = mainPO.getValue23();
		String val24 = mainPO.getValue24();
		String val25 = mainPO.getValue25();
		String val26 = mainPO.getValue26();
		String val27 = mainPO.getValue27();
		String val28 = mainPO.getValue28();
		String val29 = mainPO.getValue29();
		String val30 = mainPO.getValue30();
		Set<Integer> columnAssociated =null;
		List<Map<Integer,Integer>> columnsMaplist = new LinkedList<Map<Integer,Integer>> ();

		for(int i=0;i<ret.size();i++)	
		{
			ParserOutput po = ret.get(i);
			columnMatchMap = new HashMap<Integer,Integer>();
			columnAssociated = new LinkedHashSet<Integer>();

			if(val1!=null && !val1.trim().equalsIgnoreCase("") && val1.trim().replaceAll("[0-9]", "").length()<val1.trim().length())
			{
				mapColumns(po,val1,1,columnMatchMap,columnAssociated);
			}
			if(val2!=null && !val2.trim().equalsIgnoreCase("") && val2.trim().replaceAll("[0-9]", "").length()<val2.trim().length())
			{
				mapColumns(po,val2,2,columnMatchMap,columnAssociated);
			}
			if(val3!=null && !val3.trim().equalsIgnoreCase("") && val3.trim().replaceAll("[0-9]", "").length()<val3.trim().length() )
			{
				mapColumns(po,val3,3,columnMatchMap,columnAssociated);
			}
			if(val4!=null && !val4.trim().equalsIgnoreCase("")&& val4.trim().replaceAll("[0-9]", "").length()<val4.trim().length())
			{
				mapColumns(po,val4,4,columnMatchMap,columnAssociated);
			}
			if(val5!=null && !val5.trim().equalsIgnoreCase("") && val5.trim().replaceAll("[0-9]", "").length()<val5.trim().length())
			{
				mapColumns(po,val5,5,columnMatchMap,columnAssociated);
			}
			if(val6!=null && !val6.trim().equalsIgnoreCase("") && val6.trim().replaceAll("[0-9]", "").length()<val6.trim().length())
			{
				mapColumns(po,val6,6,columnMatchMap,columnAssociated);
			}
			if(val7!=null && !val7.trim().equalsIgnoreCase("") && val7.trim().replaceAll("[0-9]", "").length()<val7.trim().length())
			{
				mapColumns(po,val7,7,columnMatchMap,columnAssociated);
			}
			if(val8!=null && !val8.trim().equalsIgnoreCase("") && val8.trim().replaceAll("[0-9]", "").length()<val8.trim().length())
			{
				mapColumns(po,val8,8,columnMatchMap,columnAssociated);
			}
			if(val9!=null && !val9.trim().equalsIgnoreCase("") && val9.trim().replaceAll("[0-9]", "").length()<val9.trim().length())
			{
				mapColumns(po,val9,9,columnMatchMap,columnAssociated);
			}
			if(val10!=null && !val10.trim().equalsIgnoreCase("") && val10.trim().replaceAll("[0-9]", "").length()<val10.trim().length())
			{
				mapColumns(po,val10,10,columnMatchMap,columnAssociated);
			}
			if(val11!=null && !val11.trim().equalsIgnoreCase("") && val11.trim().replaceAll("[0-9]", "").length()<val11.trim().length())
			{
				mapColumns(po,val11,11,columnMatchMap,columnAssociated);
			}
			if(val12!=null && !val12.trim().equalsIgnoreCase("")&& val12.trim().replaceAll("[0-9]", "").length()<val12.trim().length())
			{
				mapColumns(po,val12,12,columnMatchMap,columnAssociated);
			}
			if(val13!=null && !val13.trim().equalsIgnoreCase("")&& val13.trim().replaceAll("[0-9]", "").length()<val13.trim().length())
			{
				mapColumns(po,val13,13,columnMatchMap,columnAssociated);
			}
			if(val14!=null && !val14.trim().equalsIgnoreCase("")&& val14.trim().replaceAll("[0-9]", "").length()<val14.trim().length())
			{
				mapColumns(po,val14,14,columnMatchMap,columnAssociated);
			}
			if(val15!=null && !val15.trim().equalsIgnoreCase("")&& val15.trim().replaceAll("[0-9]", "").length()<val15.trim().length())
			{
				mapColumns(po,val15,15,columnMatchMap,columnAssociated);
			}
			if(val16!=null && !val16.trim().equalsIgnoreCase("")&& val16.trim().replaceAll("[0-9]", "").length()<val16.trim().length())
			{
				mapColumns(po,val16,16,columnMatchMap,columnAssociated);
			}
			if(val17!=null && !val17.trim().equalsIgnoreCase("")&& val17.trim().replaceAll("[0-9]", "").length()<val17.trim().length())
			{
				mapColumns(po,val17,17,columnMatchMap,columnAssociated);
			}
			if(val18!=null && !val18.trim().equalsIgnoreCase("")&& val18.trim().replaceAll("[0-9]", "").length()<val18.trim().length())
			{
				mapColumns(po,val18,18,columnMatchMap,columnAssociated);
			}
			if(val19!=null && !val19.trim().equalsIgnoreCase("")&& val19.trim().replaceAll("[0-9]", "").length()<val19.trim().length())
			{
				mapColumns(po,val19,19,columnMatchMap,columnAssociated);
			}
			if(val20!=null && !val20.trim().equalsIgnoreCase("")&& val20.trim().replaceAll("[0-9]", "").length()<val20.trim().length())
			{
				mapColumns(po,val20,20,columnMatchMap,columnAssociated);
			}
			if(val21!=null && !val21.trim().equalsIgnoreCase("")&& val21.trim().replaceAll("[0-9]", "").length()<val21.trim().length())
			{
				mapColumns(po,val21,21,columnMatchMap,columnAssociated);
			}
			if(val22!=null && !val22.trim().equalsIgnoreCase("")&& val22.trim().replaceAll("[0-9]", "").length()<val22.trim().length())
			{
				mapColumns(po,val22,22,columnMatchMap,columnAssociated);
			}
			if(val23!=null && !val23.trim().equalsIgnoreCase("")&& val23.trim().replaceAll("[0-9]", "").length()<val23.trim().length())
			{
				mapColumns(po,val23,23,columnMatchMap,columnAssociated);
			}
			if(val24!=null && !val24.trim().equalsIgnoreCase("") && val24.trim().replaceAll("[0-9]", "").length()<val24.trim().length())
			{
				mapColumns(po,val24,24,columnMatchMap,columnAssociated);
			}
			if(val25!=null && !val25.trim().equalsIgnoreCase("") && val25.trim().replaceAll("[0-9]", "").length()<val25.trim().length())
			{
				mapColumns(po,val25,25,columnMatchMap,columnAssociated);
			}
			if(val26!=null && !val26.trim().equalsIgnoreCase("") && val26.trim().replaceAll("[0-9]", "").length()<val26.trim().length())
			{
				mapColumns(po,val26,26,columnMatchMap,columnAssociated);
			}
			if(val27!=null && !val27.trim().equalsIgnoreCase("") && val27.trim().replaceAll("[0-9]", "").length()<val27.trim().length())
			{
				mapColumns(po,val27,27,columnMatchMap,columnAssociated);
			}
			if(val28!=null && !val28.trim().equalsIgnoreCase("") && val28.trim().replaceAll("[0-9]", "").length()<val28.trim().length())
			{
				mapColumns(po,val28,28,columnMatchMap,columnAssociated);
			}
			if(val29!=null && !val29.trim().equalsIgnoreCase("") && val29.trim().replaceAll("[0-9]", "").length()<val29.trim().length())
			{
				mapColumns(po,val29,29,columnMatchMap,columnAssociated);
			}
			if(val30!=null && !val30.trim().equalsIgnoreCase("") && val29.trim().replaceAll("[0-9]", "").length()<val29.trim().length())
			{
				mapColumns(po,val30,30,columnMatchMap,columnAssociated);
			}
			/*if(columnMatchMap.size()==(mainPO.getMaxCol()-1))*/
			if(columnMatchMap.size()>0)
			{
				//System.out.println("Values matched with number of columns");
				//return columnMatchMap;

				columnsMaplist.add(columnMatchMap);
			}
		}

		if(columnsMaplist.size()>0)
		{
			retColumnMatchMap = getMaxColumnMap(columnsMaplist);
		}

		return retColumnMatchMap;
	}

	private static Map<Integer, Integer> getMaxColumnMap(
			List<Map<Integer, Integer>> columnsMaplist) {
		Map<Integer, Integer> ret = new HashMap<Integer, Integer>();
		int sz = 0;
		for(Map<Integer, Integer> mp:columnsMaplist)	
		{
			if(sz<mp.size())
			{
				sz=mp.size();
				ret=mp;
			}
		}
		return ret;
	}

	private static Map<Integer, Integer> mapColumns(ParserOutput po, String val1, int i, Map<Integer,Integer> columnMatchMap,Set<Integer> columnAssociated) {
		//Map<Integer,Integer> columnMatchMap = new HashMap<Integer,Integer>();
		Boolean matchFound = false;
		val1 = val1.replaceAll("[^0-9]", "");
		for(int k=1;k<=30;k++)
		{
			switch(k)
			{
			case 1:
			{
				if(po.getValue1()!=null && !po.getValue1().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue1().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(1))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,1);
						matchFound = true;
						columnAssociated.add(1);
					}
				}
				break;
			}
			case 2:
			{
				if(po.getValue2()!=null && !po.getValue2().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue2().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(2))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,2);
						matchFound = true;
						columnAssociated.add(2);

					}
				}
				break;
			}
			case 3:
			{
				if(po.getValue3()!=null && !po.getValue3().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue3().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(3))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,3);
						matchFound = true;
						columnAssociated.add(3);
					}
				}
				break;
			}
			case 4:
			{
				if(po.getValue4()!=null && !po.getValue4().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue4().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(4))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,4);
						matchFound = true;
						columnAssociated.add(4);
					}
				}
				break;
			}
			case 5:
			{
				if(po.getValue5()!=null && !po.getValue5().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue5().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(5))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,5);
						matchFound = true;
						columnAssociated.add(5);
					}
				}
				break;
			}
			case 6:
			{
				if(po.getValue6()!=null && !po.getValue6().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue6().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(6))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,6);
						matchFound = true;
						columnAssociated.add(6);
					}
				}
				break;
			}
			case 7:
			{
				if(po.getValue7()!=null && !po.getValue7().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue7().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(7))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,7);
						matchFound = true;
						columnAssociated.add(7);
					}
				}
				break;
			}
			case 8:
			{
				if(po.getValue8()!=null && !po.getValue8().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue8().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(8))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,8);
						matchFound = true;
						columnAssociated.add(8);
					}
				}
				break;
			}
			case 9:
			{
				if(po.getValue9()!=null && !po.getValue9().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue9().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(9))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,9);
						matchFound = true;
						columnAssociated.add(9);
					}
				}
				break;
			}
			case 10:
			{
				if(po.getValue10()!=null && !po.getValue10().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue10().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(10))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,10);
						matchFound = true;
						columnAssociated.add(10);
					}
				}
				break;
			}

			case 11:
			{
				if(po.getValue11()!=null && !po.getValue11().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue11().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(11))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,11);
						matchFound = true;
						columnAssociated.add(11);
					}
				}
				break;
			}
			case 12:
			{
				if(po.getValue12()!=null && !po.getValue12().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue12().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(12))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,12);
						matchFound = true;
						columnAssociated.add(12);
					}
				}
				break;
			}
			case 13:
			{
				if(po.getValue13()!=null && !po.getValue13().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue13().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(13))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,13);
						matchFound = true;
						columnAssociated.add(13);
					}
				}
				break;
			}
			case 14:
			{
				if(po.getValue14()!=null && !po.getValue14().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue14().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(14))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,14);
						matchFound = true;
						columnAssociated.add(14);
					}
				}
				break;
			}
			case 15:
			{
				if(po.getValue15()!=null && !po.getValue15().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue15().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(15))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,15);
						matchFound = true;
						columnAssociated.add(15);
					}
				}
				break;
			}
			case 16:
			{
				if(po.getValue16()!=null && !po.getValue16().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue16().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(16))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,16);
						matchFound = true;
						columnAssociated.add(16);
					}
				}
				break;
			}
			case 17:
			{
				if(po.getValue17()!=null && !po.getValue17().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue17().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(17))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,17);
						matchFound = true;
						columnAssociated.add(17);
					}
				}
				break;
			}
			case 18:
			{
				if(po.getValue18()!=null && !po.getValue18().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue18().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(18))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,18);
						matchFound = true;
						columnAssociated.add(18);
					}
				}
				break;
			}
			case 19:
			{
				if(po.getValue19()!=null && !po.getValue19().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue19().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(19))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,19);
						matchFound = true;
						columnAssociated.add(19);
					}
				}
				break;
			}
			case 20:
			{
				if(po.getValue20()!=null && !po.getValue20().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue20().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(20))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,20);
						matchFound = true;
						columnAssociated.add(20);
					}
				}
				break;
			}

			case 21:
			{
				if(po.getValue21()!=null && !po.getValue21().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue21().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(21))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,21);
						matchFound = true;
						columnAssociated.add(21);
					}
				}
				break;
			}
			case 22:
			{
				if(po.getValue22()!=null && !po.getValue22().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue22().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(22))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,22);
						matchFound = true;
						columnAssociated.add(22);
					}
				}
				break;
			}
			case 23:
			{
				if(po.getValue23()!=null && !po.getValue23().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue23().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(23))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,23);
						matchFound = true;
						columnAssociated.add(23);
					}
				}
				break;
			}
			case 24:
			{
				if(po.getValue24()!=null && !po.getValue24().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue24().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(24))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,24);
						matchFound = true;
						columnAssociated.add(24);
					}
				}
				break;
			}
			case 25:
			{
				if(po.getValue25()!=null && !po.getValue25().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue25().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(25))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,25);
						matchFound = true;
						columnAssociated.add(25);
					}
				}
				break;
			}
			case 26:
			{
				if(po.getValue26()!=null && !po.getValue26().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue26().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(26))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,26);
						matchFound = true;
						columnAssociated.add(26);
					}
				}
				break;
			}
			case 27:
			{
				if(po.getValue27()!=null && !po.getValue27().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue27().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(27))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,27);
						matchFound = true;
						columnAssociated.add(27);
					}
				}
				break;
			}
			case 28:
			{
				if(po.getValue28()!=null && !po.getValue28().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue28().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(28))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,28);
						matchFound = true;
						columnAssociated.add(28);
					}
				}
				break;
			}
			case 29:
			{
				if(po.getValue29()!=null && !po.getValue29().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue29().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(29))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,29);
						matchFound = true;
						columnAssociated.add(29);
					}
				}
				break;
			}
			case 30:
			{
				if(po.getValue30()!=null && !po.getValue30().trim().equalsIgnoreCase("") && val1.trim().equalsIgnoreCase(po.getValue30().replaceAll("[^0-9]", "").trim()))
				{
					if(!columnAssociated.contains(30))
					{
						System.out.print("column"+i+" matched to column"+k);
						columnMatchMap.put(i,30);
						matchFound = true;
						columnAssociated.add(30);
					}
				}
				break;
			}

			}
			if(matchFound)
				break;
		}


		return columnMatchMap;
	}


	public static Map<Integer, String> getColumnValueMap(ParserOutput row,String type) 
	{
		Map<Integer,String> ret= new HashMap<Integer,String>();
		for(int i=0;i<=30;i++)
		{
			if(type!=null && type.equalsIgnoreCase("val"))
				ret.put(i, MapCols.getPOValueOnIndex(row, i));
			if(type!=null && type.equalsIgnoreCase("as_rep"))
				ret.put(i, MapCols.getPOAsRepValOnIndex(row, i));
		}
		return ret;
	}

	public static void clearAllColumnValueMap(ParserOutput row) 
	{
		for(int i=0;i<=30;i++)
		{
			MapCols.setPOValueOnIndex(row, i, null);
			MapCols.setPOAsRepValueOnIndex(row, i, null);
		}
	}

	public static void copyPoRow(ParserOutput row,ParserOutput newRow)
	{
		if(row.getType()!=null)
		{
			newRow.setType(row.getType());
		}
		if(row.getTableID()!=null)
		{
			newRow.setTableID(row.getTableID());
		}
		if(row.getMapNode()!=null)
		{
			newRow.setMapNode(row.getMapNode());
		}
		if(row.getMultiMapNode()!=null)
		{
			newRow.setMultiMapNode(row.getMultiMapNode());
		}
		if(row.getHierarchy()!=null)
		{
			newRow.setHierarchy(row.getHierarchy());
		}
		if(row.getMaxCol()>0)
		{
			newRow.setMaxCol(row.getMaxCol());
		}

		if(row.getSection()!=null)
		{
			newRow.setSection(row.getSection());
		}
		if(row.getIsHeading()!=null)
		{
			newRow.setIsHeading(row.getIsHeading());
		}
		if(row.getPrevHeader()!=null)
		{
			newRow.setPrevHeader(row.getPrevHeader());
		}
		if(row.getPageNoCoOrdinates()!=null){
			newRow.setPageNoCoOrdinates(row.getPageNoCoOrdinates());
		}
		if(row.getPageInfo()!=null)
		{
			newRow.setPageInfo(row.getPageInfo());

		}

		if(row.getyCoords()!=null)
		{
			newRow.setyCoords(row.getyCoords());
		}
		if(row.getLine()!=null)
		{
			newRow.setLine(row.getLine());
		}
		if(row.getPdfLine()!=null)
		{
			newRow.setPdfLine(row.getPdfLine());
		}
		if(row.getPageNo()>-1)
		{
			newRow.setPageNo(row.getPageNo());

		}
		if(row.getPageInfo()!=null)
		{
			newRow.setPageInfo(row.getPageInfo());

		}
		if(row.getPageNoCoOrdinates()!=null)
		{
			newRow.setPageNoCoOrdinates(row.getPageNoCoOrdinates());

		}
		if(row.getRef_Po_id()>-1)
		{
			newRow.setRef_Po_id(row.getRef_Po_id());
		}
		if(row.getIndentLevel()!=null)
		{
			newRow.setIndentLevel(row.getIndentLevel());
		}
		if(row.getBreakUpMainType()!=null)
		{
			newRow.setBreakUpMainType(row.getBreakUpMainType());

		}
		if(row.getBreakUpType()!=null)
		{
			newRow.setBreakUpMainType(row.getBreakUpType());
		}



	}

	public static Map<Integer, Integer> getAttrYearMatchingValueMap(ParserOutput thisYearRow,
			ParserOutput yearRow, ParserOutput mainPO) 
			{
		int yearCols=0;
		int thisYearCols=0;
		int thisYearIndexPresent=0;
		int yearIndexPresent=0;
		for(int i=1;i<=30;i++)
		{
			String thisYearVal=MapCols.getPOValueOnIndex(thisYearRow,i);
			String yearVal=MapCols.getPOValueOnIndex(yearRow,i);
			if(thisYearVal!=null && !thisYearVal.trim().equals(""))
			{
				thisYearCols++;
				thisYearIndexPresent=i;
			}
			if(yearVal!=null && !yearVal.trim().equals(""))
			{
				yearCols++;
				yearIndexPresent=i;
			}
		}


		Map<Integer,Integer> ret = new HashMap<Integer,Integer>();
		if(yearCols<1 || thisYearCols<1  || thisYearCols!=yearCols)
			return ret;
		else if((thisYearIndexPresent-yearIndexPresent)>1)
			return ret;

		int maxCol = mainPO.getMaxCol();

		if((maxCol-1)>yearCols)
			return ret;

		Set<Integer> alreadyAssociatedValues=new HashSet<Integer>();

		for(int i=1;i<=30;i++)
		{
			String thisYearVal=MapCols.getPOValueOnIndex(thisYearRow,i);
			//String thisAttrVal=MapCols.getPOValueOnIndex(thisAttributeRow,i);;
			//String thisMonthVal=MapCols.getPOValueOnIndex(thisMonthRow,i);

			if(thisYearVal==null /*&& thisAttrVal==null && thisMonthVal==null*/)
				continue;
			Boolean columnMatched = false;
			for(int j=1;j<=30;j++)
			{
				if(alreadyAssociatedValues.contains(j))
					continue;
				boolean isYearMatch=false;
				boolean isAttrMatch=false;
				boolean isMonthMatch=false;
				//				String monthVal=MapCols.getPOValueOnIndex(monthRow,j);;
				String yearVal=MapCols.getPOValueOnIndex(yearRow,j);;
				//			String attrVal=MapCols.getPOValueOnIndex(attributeRow,j);;
				/*if(thisMonthVal!=null && monthVal!=null && !thisMonthVal.trim().equals("") && !monthVal.trim().equals(""))
				{
					if(thisMonthVal.trim().equalsIgnoreCase(monthVal.trim()))
						isMonthMatch=true;
				}*/
				if(thisYearVal!=null && yearVal!=null && !thisYearVal.trim().equals("") && !yearVal.trim().equals(""))
				{
					if(thisYearVal.trim().equalsIgnoreCase(yearVal.trim()))
						isYearMatch=true;
					else if(yearVal.toLowerCase().trim().contains(thisYearVal.toLowerCase().trim()))
						isYearMatch=true;		
					else if(thisYearVal.toLowerCase().trim().contains(yearVal.toLowerCase().trim()))
						isYearMatch=true;
				}

				/*if(thisAttrVal!=null && attrVal!=null && !thisAttrVal.trim().equals("") && !attrVal.trim().equals(""))
				{
					if(thisAttrVal.trim().equalsIgnoreCase(attrVal.trim()))
						isAttrMatch=true;
				}
				else if((thisAttrVal==null || thisAttrVal.trim().equals("")) 
						&& (attrVal==null || attrVal.trim().equals("")))
				{
					isAttrMatch=true;
				}*/

				if(isAttrMatch && isYearMatch && isMonthMatch)
				{
					alreadyAssociatedValues.add(j);
					ret.put(i,j);
					columnMatched = true;
					break;
				}
				else if(isYearMatch && isMonthMatch)
				{
					alreadyAssociatedValues.add(j);
					ret.put(i,j);
					columnMatched = true;
					break;
				}
				else if(isYearMatch)
				{
					alreadyAssociatedValues.add(j);
					ret.put(i,j);
					columnMatched = true;
					break;
				}
			}

			if(!columnMatched)
			{
				//ret.put(i,++maxCol);
				ret.put(i,null);
			}
		}

		return ret;
			}

	public static List<PDFLine> getLinesFromBlocks(List<PDFBlock> blocks) 
	{
		List<PDFLine> ret= new ArrayList<PDFLine>();
		if(blocks!=null && blocks.size()>0)
		{
			for(PDFBlock blk:blocks)
			{
				ret.addAll(blk.getLines());
			}
		}

		return ret;
	}

	public static ParserOutput getMatchingTextBreakUP(
			Map<String, List<String>> implicitMetaData, HierarchyNode hierarchyNode) 
	{
		List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(hierarchyNode);
		allNodes=InnerSplit.filterNodesBasedOnType(true,allNodes);
		Integer mainEnumGroup=null;
		if(AssociationCreator.mainEnumNode!=null)
		{
			HierarchyNode mainEnumNode=AssociationCreator.mainEnumNode;
			if(mainEnumNode.getEnumeration()!=null && mainEnumNode.getEnumeration().getText()!=null && !mainEnumNode.getEnumeration().getText().trim().equals(""))
			{
				mainEnumGroup=mainEnumNode.getEnumFinalGroupId();
			}
		}
		HierarchyNode mainEnumGroupNode=null;
		ParserOutput row= new ParserOutput();
		for(HierarchyNode node:allNodes)
		{
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
			{
				if(mainEnumGroup!=null && node.getEnumFinalGroupId()==mainEnumGroup)
				{
					mainEnumGroupNode=node;
				}
			}
			if(nodesVisited.contains(node.getId()))
			{
				continue;
			}
			nodesVisited.add(node.getId());
			Structure dataNode= node.getNode();
			POBreakUps nodeCoOrds=new POBreakUps(node);
			POBreakUps.setCoOrdinate(nodeCoOrds);
			//List<Triplet<String, String, String>> triplets = NLPTextBreakUpAssociation.getMatchingTripletsFromSentence(dataNode.getStringRepresentation());
			List<List<Triplet<String, String, String>>> triplets= NLPTextBreakUpAssociation.getSentenceWiseTriplets(dataNode.getStringRepresentation());
			for(List<Triplet<String, String, String>> perSentenceTrips:triplets)
			{
				String sentence=perSentenceTrips.get(0).getSentence();
				String section="";
				String matchingKeyword="";
				boolean isFound=false;
				for(String sec:implicitMetaData.keySet())
				{
					List<String> keywords=implicitMetaData.get(sec);
					for(String searchWord:keywords)
					{
						isFound=StringUtility.doesKeywordMatchTokenSerial(searchWord.trim().toLowerCase(),sentence);
						if(isFound)
						{
							section=sec.toUpperCase();
							matchingKeyword=searchWord;
							break;
						}
					}
					if(isFound)
						break;
				}
				List<TextValuesExtraction> textValuesExtractionList = NLPTextBreakUpAssociation.createTabularData(perSentenceTrips);
				ArrayList<ArrayList<ParserOutput>> poLists = createPOList(textValuesExtractionList,row,dataNode.getStringRepresentation(),nodeCoOrds);
				if(isFound)
				{
					for(ArrayList<ParserOutput> poList:poLists)
					{
						for(ParserOutput po:poList)
						{
							po.setSection(section);
							po.setMatchingImplicitKeyWord(matchingKeyword);
						}
					}
				}
				//setSectionAndImplicitMatchingKeyword(poLists,implicitMetaData);
				for(ArrayList<ParserOutput> poList:poLists)
				{
					List<ParserOutput> mergedBreakUp=mergingAttributes(row,null,poList, "Implicit_Metadata","TextBreakUp",mainEnumGroupNode,null);
					if(mergedBreakUp!=null && mergedBreakUp.size()>0)
					{
						for(ParserOutput po:mergedBreakUp)
						{
							po.setBreakups("Y");
							po.setPageNoCoOrdinates(nodeCoOrds);
							if(mainEnumGroupNode!=null)
							{
								po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
							}
						}
						row.getBreakupItems().addAll(mergedBreakUp);
						row.getMatchingBreakUpItem().add(mergedBreakUp);
					}
				}
			}


		}
		return row;
	}

	public static ParserOutput getMatchingTextBreakUPFromMetadata(
			List<TopicKeywords> noteKWList, HierarchyNode hierarchyNode) 
	{
		List<HierarchyNode> allNodes=AssociationsUtilities.getAllTheNodesFromANode(hierarchyNode);
		allNodes=InnerSplit.filterNodesBasedOnType(true,allNodes);
		Integer mainEnumGroup=null;
		if(AssociationCreator.mainEnumNode!=null)
		{
			HierarchyNode mainEnumNode=AssociationCreator.mainEnumNode;
			if(mainEnumNode.getEnumeration()!=null && mainEnumNode.getEnumeration().getText()!=null && !mainEnumNode.getEnumeration().getText().trim().equals(""))
			{
				mainEnumGroup=mainEnumNode.getEnumFinalGroupId();
			}
		}
		HierarchyNode mainEnumGroupNode=null;
		ParserOutput row= new ParserOutput();
		for(HierarchyNode node:allNodes)
		{
			if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals(""))
			{
				if(mainEnumGroup!=null && node.getEnumFinalGroupId()==mainEnumGroup)
				{
					mainEnumGroupNode=node;
				}
			}
			if(nodesVisited.contains(node.getId()))
			{
				continue;
			}
			nodesVisited.add(node.getId());
			Structure dataNode= node.getNode();
			POBreakUps nodeCoOrds=new POBreakUps(node);
			POBreakUps.setCoOrdinate(nodeCoOrds);
			//List<Triplet<String, String, String>> triplets = NLPTextBreakUpAssociation.getMatchingTripletsFromSentence(dataNode.getStringRepresentation());
			List<List<Triplet<String, String, String>>> triplets= NLPTextBreakUpAssociation.getSentenceWiseTriplets(dataNode.getStringRepresentation());
			for(List<Triplet<String, String, String>> perSentenceTrips:triplets)
			{
				String sentence=perSentenceTrips.get(0).getSentence();
				String section="";
				String matchingKeyword="";
				boolean isFound=false;
				for(TopicKeywords eachKw:noteKWList)
				{
					List<String> keywords=eachKw.getKeywords();
					for(String searchWord:keywords)
					{
						isFound=StringUtility.doesKeywordMatchTokenSerial(searchWord.trim().toLowerCase(),sentence);
						if(isFound)
						{
							section=eachKw.getSection().toUpperCase();
							matchingKeyword=(eachKw.getCleanedTopic()+":::"+searchWord);
							break;
						}
					}
					if(isFound)
						break;
				}
				List<TextValuesExtraction> textValuesExtractionList = NLPTextBreakUpAssociation.createTabularData(perSentenceTrips);
				ArrayList<ArrayList<ParserOutput>> poLists = createPOList(textValuesExtractionList,row,dataNode.getStringRepresentation(),nodeCoOrds);
				if(isFound)
				{
					for(ArrayList<ParserOutput> poList:poLists)
					{
						for(ParserOutput po:poList)
						{
							po.setSection(section);
							po.setMatchingImplicitKeyWord(matchingKeyword);
						}
					}
				}
				//setSectionAndImplicitMatchingKeyword(poLists,implicitMetaData);
				for(ArrayList<ParserOutput> poList:poLists)
				{
					List<ParserOutput> mergedBreakUp=mergingAttributes(row,null,poList, "Implicit_Metadata","TextBreakUp",mainEnumGroupNode,null);
					if(mergedBreakUp!=null && mergedBreakUp.size()>0)
					{
						for(ParserOutput po:mergedBreakUp)
						{
							po.setBreakups("Y");
							po.setPageNoCoOrdinates(nodeCoOrds);
							if(mainEnumGroupNode!=null)
							{
								po.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
							}
						}
						row.getBreakupItems().addAll(mergedBreakUp);
						row.getMatchingBreakUpItem().add(mergedBreakUp);
					}
					if(row.getSupplementaryBreakUpItem()!=null && row.getSupplementaryBreakUpItem().size()>0)
					{
						for(List<ParserOutput> breakUps:row.getSupplementaryBreakUpItem())
						{
							for(ParserOutput brkUp:breakUps)
							{
								brkUp.setBreakups("Y");
								brkUp.setPageNoCoOrdinates(nodeCoOrds);
								if(mainEnumGroupNode!=null)
								{
									brkUp.setNotesColumn(mainEnumGroupNode.getEnumeration().getText());
								}
							}
						}
					}
				}
			}


		}
		return row;
	}

	private static void setSectionAndImplicitMatchingKeyword(ArrayList<ArrayList<ParserOutput>> poLists,
			Map<String, List<String>> implicitMetaData) 
	{
		for(ArrayList<ParserOutput> poList:poLists)
		{
			String section="";
			String matchingKeyWord="";
			boolean isMatch=false;
			for(ParserOutput po:poList)
			{
				if(po.getIsHeading().equalsIgnoreCase("Y") || po.getAsRepLabel()==null || po.getAsRepLabel().trim().equals(""))
					continue;			
				for(String sec:implicitMetaData.keySet())
				{
					List<String> keywords=implicitMetaData.get(sec);
					for(String searchWord:keywords)
					{
						isMatch=StringUtility.doesKeywordMatchTokenSerial(searchWord.trim().toLowerCase(),po.getAsRepLabel().trim().toLowerCase());
						if(isMatch)
						{
							section=sec.toUpperCase();
							matchingKeyWord=searchWord;
							break;
						}
					}
				}
			}
			if(isMatch)
			{
				for(ParserOutput po:poList)
				{
					po.setSection(section);
					po.setMatchingImplicitKeyWord(matchingKeyWord);
				}
			}
		}

	}

	public void runInnerSplitForImplicitMetadataTextBreakUp(ArrayList<ParserOutput> breakUps, ParserOutput matchingLineItem,
			ParserOutput yearRow, ParserOutput monthRow, ParserOutput attrRow, String upperCase, String string) 
	{
		if (breakUps == null || breakUps.size() < 1)
			return;

		List<ParserOutput> mergedBreakUp = mergingAttributes(matchingLineItem, yearRow, breakUps, "Implicit_Metadata", "TextBreakUp",null,null);
		if (mergedBreakUp != null && mergedBreakUp.size() > 0) 
		{
			for (ParserOutput po : mergedBreakUp) 
			{
				po.setBreakups("Y");
			}
			matchingLineItem.getBreakupItems().addAll(mergedBreakUp);
			matchingLineItem.getMatchingBreakUpItem().add(mergedBreakUp);
		}
	}


}
