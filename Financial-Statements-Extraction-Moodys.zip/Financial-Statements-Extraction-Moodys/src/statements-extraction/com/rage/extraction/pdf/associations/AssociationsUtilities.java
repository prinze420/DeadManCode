package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.dp.hierarchy.HierarchyNode;
import com.dp.nda.pdf.beans.PDFSegment;
import com.dp.structures.BasicStructure;
import com.dp.structures.ComplexStructure;
import com.dp.structures.Structure;
import com.dp.structures.StructureType;
import com.dp.structures.basicstructures.DPCell;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.uitls.PDFDocumentLoader;

public class AssociationsUtilities 
{

	public static List<List<String>> splitEnum(String note)
	{
		if(note==null || note.trim().equals(""))
			return null;
		// 1.(a),2(b)      1,2 
		List<List<String>> ret= new ArrayList<List<String>>();
		String[] notesplit=note.split(",");
		if(notesplit.length==1)
			notesplit=note.split("&");
		if(notesplit.length==1)
			notesplit=note.split("\\+");
		for(String eachNote:notesplit)
		{
			if(eachNote.trim().equals(""))
				continue;
			eachNote=eachNote.replaceAll(",", "").replaceAll("&", "").replaceAll("\\+", "");
			String[] innerSplit=eachNote.split("\\(");
			List<String> strLst= new ArrayList<String>();
			if(innerSplit.length>1)
			{
				for(String split:innerSplit)
				{
					if(!split.trim().equals(""))
					{
						if(split.contains(")"))
							strLst.add(("("+split));
						else
							strLst.add(split);
					}
				}
				ret.add(strLst);
				continue;
			}
			innerSplit=eachNote.split("\\[");
			if(innerSplit.length>1)
			{
				for(String split:innerSplit)
				{
					if(!split.trim().equals(""))
					{
						if(split.contains("]"))
							strLst.add(("["+split));
						else
							strLst.add(split);
					}
				}
				ret.add(strLst);
				continue;
			}
			if(isStringAlphaNumeric(eachNote))
			{
				String numStr="";
				String charStr="";
				if(isStringAlphaNumeric(eachNote))
				{
					for(int i=0;i<eachNote.length();i++)
					{
						String charI=Character.toString(eachNote.charAt(i));
						if(charI.toLowerCase().replaceAll("[a-z]", "").equals(""))
						{
							charStr=charStr+charI;
							continue;
						}
						numStr=numStr+charI;
					}
				}
				strLst.add(numStr);
				strLst.add(charStr);
				ret.add(strLst);
				continue;
			}
			strLst.add(eachNote);
			ret.add(strLst);
		}
		return ret;
	}
	
	public static boolean isStringAlphaNumeric(String ip)
	{
		if(ip==null || ip.trim().equals(""))
			return false;
		boolean isAlpha=false;
		boolean isNumeric=false;
		if(ip.trim().toLowerCase().replaceAll("[a-z]", "").length()<ip.trim().length())
			isAlpha=true;
		if(ip.trim().toLowerCase().replaceAll("[0-9]", "").length()<ip.trim().length())
			isNumeric=true;
		
		if(isAlpha && isNumeric)
			return true;
		return false;
	}
	
	public static boolean isStringPresentInNode(HierarchyNode node, String lineItemSectionStr) 
	{
		Structure dataNode= node.getNode();
		if(dataNode==null)
			return false;
		if(dataNode.getType().equals(StructureType.TITLE) || dataNode instanceof Title)
		{
			Title title= (Title) dataNode;
			if(title.getStringRepresentation().trim().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
			{
				return true;
			}
		}
		else if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
		{
			DPTable table= (DPTable) dataNode;
			List<PDFLine> lines=getTableDataFromHierarchyNode(table);
			boolean isMatches=matchLineStringWithinLines(lines,lineItemSectionStr);
			if(isMatches)
				return true;
		}
		else if(dataNode.getType().equals(StructureType.PPARAGRAPH) ||  dataNode instanceof Paragraph)
		{
			Paragraph paragraph= (Paragraph) dataNode;
			List<PDFLine> lines=getParagraphDataFromHierarchyNode(paragraph);
			boolean isMatches=matchLineStringWithinLines(lines,lineItemSectionStr);
			if(isMatches)
				return true;
		}
		return false;
	}
	
	private static boolean matchLineStringWithinLines(List<PDFLine> lines, String lineItemSectionStr) 
	{
		if(lines!=null && lines.size()>0)
		{
			for(PDFLine line:lines)
			{
				if(line.getLine().trim().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
					return true;
			}
		}
		
		return false;
	}

	public static List<PDFLine> getTableDataFromHierarchyNode(DPTable table)
	{
		List<DPCell> cells=table.getTableCells();
		Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap= new TreeMap<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>>();
		List<com.dp.nda.pdf.beans.PDFCharacter> charList1 = new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
		for(DPCell cell:cells)
		{
			List<BasicStructure> paraList= cell.getParaList();
			for(BasicStructure word:paraList)
			{
				com.dp.nda.pdf.beans.PDFWord cWord= (com.dp.nda.pdf.beans.PDFWord) word;
				for(com.dp.nda.pdf.beans.PDFCharacter charcter:cWord.getCharacters())
				{
					//charList.add(charcter);
					if(pageWiseCharMap.containsKey(charcter.getRectangle().getPageNo()))
					{
						pageWiseCharMap.get(charcter.getRectangle().getPageNo()).add(charcter);	
					}
					else
					{
						List<com.dp.nda.pdf.beans.PDFCharacter> characterList= new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
						characterList.add(charcter);
						pageWiseCharMap.put(charcter.getRectangle().getPageNo(),characterList);
					}
				}
			}
		}
		//pageWiseCharMap.put(0, charList);
		Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);
		
		TreeMap<Integer, PageParse> pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
		List<PDFLine> ret= new ArrayList<PDFLine>();
		for(Integer pgNO:pageParsesMap.keySet())
		{
			List<PDFLine> lines=pageParsesMap.get(pgNO).getPageLines();
			ret.addAll(lines);
		}
		return ret;
	}
	
	public static List<PDFBlock> getTableBlocksFromHierarchyNode(DPTable table)
	{
		List<DPCell> cells=table.getTableCells();
		Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap= new TreeMap<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>>();
		List<com.dp.nda.pdf.beans.PDFCharacter> charList1 = new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
		for(DPCell cell:cells)
		{
			List<BasicStructure> paraList= cell.getParaList();
			for(BasicStructure word:paraList)
			{
				com.dp.nda.pdf.beans.PDFWord cWord= (com.dp.nda.pdf.beans.PDFWord) word;
				for(com.dp.nda.pdf.beans.PDFCharacter charcter:cWord.getCharacters())
				{
					//charList.add(charcter);
					if(pageWiseCharMap.containsKey(charcter.getRectangle().getPageNo()))
					{
						pageWiseCharMap.get(charcter.getRectangle().getPageNo()).add(charcter);	
					}
					else
					{
						List<com.dp.nda.pdf.beans.PDFCharacter> characterList= new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
						characterList.add(charcter);
						pageWiseCharMap.put(charcter.getRectangle().getPageNo(),characterList);
					}
				}
			}
		}
		//pageWiseCharMap.put(0, charList);
		Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);
		
		TreeMap<Integer, PageParse> pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
		List<PDFBlock> ret= new ArrayList<PDFBlock>();
		for(Integer pgNO:pageParsesMap.keySet())
		{
			List<PDFBlock> blocks=pageParsesMap.get(pgNO).getPageBlocks();
			ret.addAll(blocks);
		}
		return ret;
	}
	
	public static List<POBreakUps> preparePOBreakUpsFromHierarchyNode(HierarchyNode node) 
	{
		List<POBreakUps> ret = new ArrayList<POBreakUps>();
		
		POBreakUps breakUps= new POBreakUps(node);
		breakUps.setCoOrdinate(breakUps);
		//String nodeStr=node.getNode().getStringRepresentation();
		//System.out.println(nodeStr);
		String nodeStr=HierarchyNode.toDeepString(node, "");
		breakUps.setAsRepLabel(nodeStr);
		ret.add(breakUps);
		
		return ret;
	}
	
	public static List<PDFLine> getParagraphDataFromHierarchyNode(Paragraph paragraph)
	{
		Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap= new TreeMap<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>>();
		List<PDFSegment> wordList=paragraph.getInputStructureList();
		for(PDFSegment segment:wordList)
		{
			for(com.dp.nda.pdf.beans.PDFWord word:segment.getWords())
			{
				com.dp.nda.pdf.beans.PDFWord cWord=  word;
				for(com.dp.nda.pdf.beans.PDFCharacter charcter:cWord.getCharacters())
				{
					if(pageWiseCharMap.containsKey(charcter.getRectangle().getPageNo()))
					{
						pageWiseCharMap.get(charcter.getRectangle().getPageNo()).add(charcter);	
					}
					else
					{
						List<com.dp.nda.pdf.beans.PDFCharacter> characterList= new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
						characterList.add(charcter);
						pageWiseCharMap.put(charcter.getRectangle().getPageNo(),characterList);
					}
				}
			}
		}
		Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);
		
		TreeMap<Integer, PageParse> pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
		List<PDFLine> ret= new ArrayList<PDFLine>();
		for(Integer pgNO:pageParsesMap.keySet())
		{
			List<PDFLine> lines=pageParsesMap.get(pgNO).getPageLines();
			ret.addAll(lines);
		}
		return ret;	
	}
	
	public static Map<Integer, List<PDFCharacter>> convertNativePDFCharToLocal (
			Map<Integer, List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap )
	{
		Map<Integer, List<PDFCharacter>> ret= new TreeMap<Integer, List<PDFCharacter>>(); 
		for(Integer pgNo:pageWiseCharMap.keySet())
		{
			List<com.dp.nda.pdf.beans.PDFCharacter> lst=pageWiseCharMap.get(pgNo);
			
			for(com.dp.nda.pdf.beans.PDFCharacter pdfCr:lst)
			{
				if(ret.containsKey(pgNo))
				{
					
					PDFCharacter pdfChar=getLocalPDFCharacterFromNative(pdfCr,pgNo); 
					ret.get(pgNo).add(pdfChar);		
				}
				else
				{
					PDFCharacter pdfChar= getLocalPDFCharacterFromNative(pdfCr,pgNo);
					List<PDFCharacter> charList= new ArrayList<PDFCharacter>();
					charList.add(pdfChar);
					ret.put(pgNo, charList);
				}
			}
		}
		
		return ret;
	}
	
	public static PDFCharacter getLocalPDFCharacterFromNative ( com.dp.nda.pdf.beans.PDFCharacter pdfCr, Integer pgNo )
	{
		PDFCharacter pdfChar= new PDFCharacter(pgNo,pdfCr.getRectangle().getX(),pdfCr.getRectangle().getX2()
				,pdfCr.getRectangle().getY2(),pdfCr.getRectangle().getY(),pdfCr.getStringRepresentation(),pdfCr.getFontName()
				,pdfCr.getFontFamily(),pdfCr.getFontSize(),pdfCr.getFontSizeInPt(),pdfCr.getWidthOfSpace(),pdfCr.isBold()
				,pdfCr.isItalic(),pdfCr.getMultiColumnIndex(),pdfCr.getRectangle().getWidth(),pdfCr.getRectangle().getHeight());

		return pdfChar;
	}

	public static List<HierarchyNode> getAllNodesForPageNoFromHierarchyNode(Integer pageNo,
			HierarchyNode hierarchyNode) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(hierarchyNode!=null)
		{
			Structure node=hierarchyNode.getNode();
			if(node !=null && node.getType().equals(StructureType.TABLE) )
			{
				DPTable table= (DPTable) node;
				int pg=table.getRectangles().get(0).getPageNo();
				if(pg==pageNo)
					ret.add(hierarchyNode);
			}
			else if(node !=null && node.getType().equals(StructureType.TITLE) )
			{
				Title title= (Title) node;
				int pg=title.getRectangle().getPageNo();
				if(pg==pageNo)
					ret.add(hierarchyNode);
			}
			else if(node !=null && node.getType().equals(StructureType.PPARAGRAPH) )
			{
				Paragraph table= (Paragraph) node;
				int pg=table.getRectangles().get(0).getPageNo();
				if(pg==pageNo)
					ret.add(hierarchyNode);
			}
			if(hierarchyNode.getChildren()!=null && hierarchyNode.getChildren().size()>0)
			{
				for(HierarchyNode cNode:hierarchyNode.getChildren())
				{
					List<HierarchyNode> hNodeRet=getAllNodesForPageNoFromHierarchyNode(pageNo,cNode);
					if(hNodeRet!=null && hNodeRet.size()>0)
						ret.addAll(hNodeRet);
				}
			}
			
		}
		return ret;
	}

	public static List<HierarchyNode> getAllTheNodesFromANode(HierarchyNode hierarchyNode) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(hierarchyNode!=null)
		{
			Structure node=hierarchyNode.getNode();
			if(node !=null)
			{
				ret.add(hierarchyNode);
			}
			
			if(hierarchyNode.getChildren()!=null && hierarchyNode.getChildren().size()>0)
			{
				for(HierarchyNode cNode:hierarchyNode.getChildren())
				{
					List<HierarchyNode> hNodeRet=getAllTheNodesFromANode(cNode);
					if(hNodeRet!=null && hNodeRet.size()>0)
						ret.addAll(hNodeRet);
				}
			}
		}
		
		return ret;
	}

	public static List<PDFLine> getListOfLinesFromHierarchyNode(HierarchyNode node)
	{
		List<PDFLine> ret = new ArrayList<PDFLine>();
		if(node==null)
			return ret;
		Structure dataNode=node.getNode();
		if(dataNode.getType().equals(StructureType.TITLE) || dataNode instanceof Title)
		{
			Title title= (Title) dataNode;
			List<PDFLine> lines=getTitleDataFromHierarchyNode(title);
			ret= lines;
		}
		else if(dataNode.getType().equals(StructureType.TABLE) || dataNode instanceof DPTable)
		{
			DPTable table= (DPTable) dataNode;
			List<PDFLine> lines=getTableDataFromHierarchyNode(table);
			ret =lines;
		}
		else if(dataNode.getType().equals(StructureType.PPARAGRAPH) ||  dataNode instanceof Paragraph)
		{
			Paragraph paragraph= (Paragraph) dataNode;
			List<PDFLine> lines=getParagraphDataFromHierarchyNode(paragraph);
			ret= lines;
			
		}
		return ret;
	}
	
	public static List<String> getNumberWordsFromLine(List<PDFLine> lines) 
	{
		List<String> ret= new ArrayList<String>();
		if(lines==null)
			return ret;
		for(PDFLine line:lines)
		{
			for(PDFChunk chunk:line.getChunks())
			{
				/*for(PDFWord word:chunk.getWords())
				{
					String strWord=word.getWord();
					boolean isNumber=isStringDoubleNumber(strWord);*/
					String strChunk=chunk.getChunk();
					boolean isNumber=isStringDoubleNumber(strChunk);
					if(isNumber)
					{
						ret.add(AssociationsUtilities.cleanNumberString(strChunk.trim()));
					}
					
				//}
			}
		}
		return ret;
	}
	
	public static boolean isStringDoubleNumber(String input)
	{
		if(input==null || input.trim().equals(""))
			return false;
		try
		{
			input=cleanNumberString(input);
			Double.parseDouble(input);
			return true;
		}
		catch(Exception e){}
		return false;
	}

	public static String cleanNumberString(String input) 
	{
		if(input==null || input.trim().equals(""))
			return input;
		input=input.replaceAll("\\(", "").replaceAll("\\)", "");
		input=input.replaceAll("\\$", "").replaceAll(",", "");
		input=input.replaceAll("\\s+", "");
		return input;
	}

	public static List<PDFLine> getTitleDataFromHierarchyNode(Title title) 
	{
		Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap= new TreeMap<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>>();
		Paragraph para=title.getInputStructure();
		List<PDFSegment> segmentList= para.getInputStructureList();
		for(PDFSegment segment:segmentList)
		{
			for(com.dp.nda.pdf.beans.PDFWord word:segment.getWords())
			{
				com.dp.nda.pdf.beans.PDFWord cWord= (com.dp.nda.pdf.beans.PDFWord) word;
				for(com.dp.nda.pdf.beans.PDFCharacter charcter:cWord.getCharacters())
				{
					if(pageWiseCharMap.containsKey(charcter.getRectangle().getPageNo()))
					{
						pageWiseCharMap.get(charcter.getRectangle().getPageNo()).add(charcter);	
					}
					else
					{
						List<com.dp.nda.pdf.beans.PDFCharacter> characterList= new ArrayList<com.dp.nda.pdf.beans.PDFCharacter>();
						characterList.add(charcter);
						pageWiseCharMap.put(charcter.getRectangle().getPageNo(),characterList);
					}
				}
			}
		}
		Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);
		
		TreeMap<Integer, PageParse> pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
		List<PDFLine> ret= new ArrayList<PDFLine>();
		for(Integer pgNO:pageParsesMap.keySet())
		{
			List<PDFLine> lines=pageParsesMap.get(pgNO).getPageLines();
			ret.addAll(lines);
		}
		return ret;	
	}
	

	public static boolean isLineContainsNumberChunk(PDFLine line) 
	{
		if(line==null)
			return false;
		for(PDFChunk chunk:line.getChunks())
		{
			String chunkStr=chunk.getChunk();
			if(isStringDoubleNumber(chunkStr))
				return true;
		}
			
		return false;
	}
	
	public static boolean isRowNumberPresentInTable(List<PDFLine> lines,HierarchyNode node)
	{
		List<String> numberWords=AssociationsUtilities.getNumberWordsFromLine(lines);
		Structure dataNode= (DPTable)node.getNode();
		DPTable table= (DPTable)dataNode;
		List<PDFLine> tableLines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
		int found=0;
		// checking if numbers present in table lines
		for(PDFLine line:tableLines)
		{
			for(PDFChunk chunk:line.getChunks())
			{
				for(PDFWord word:chunk.getWords())
				{
					boolean isNumber=AssociationsUtilities.isStringDoubleNumber(word.getWord().trim());
					if(isNumber)
					{
						String numWord=AssociationsUtilities.cleanNumberString(word.getWord());
						if(numberWords.contains(numWord))
						{
							found++;
							//System.out.println("Number in table found");
						}
					}
				}
			}
		}
		
		if(((float)found/(float)numberWords.size())>=0.5f)
		{
			return true;
		}
		
		return false;
	}

	public static List<HierarchyNode> getAllNodesForAPage(HierarchyNode hierarchyNode, Integer pageNo) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(hierarchyNode!=null)
		{
			if(hierarchyNode.getNode()!=null && hierarchyNode.getNode() instanceof DPTable)
			{
				DPTable dataNode=(DPTable) hierarchyNode.getNode();
				if(dataNode.getRectangles().get(0).getPageNo()==pageNo)
					ret.add(hierarchyNode);
			}
			if(hierarchyNode.getChildren()!=null && hierarchyNode.getChildren().size()>0)
			{
				for(HierarchyNode cNode:hierarchyNode.getChildren())
				{
					List<HierarchyNode> nodes=getAllNodesForAPage(cNode,pageNo);
					if(nodes!=null && nodes.size()>0)
						ret.addAll(nodes);
				}
				
			}
		}
		return ret;
	}
}
