package com.rage.extraction.pdf.associations;

import com.gyan.siapp.utils.Triplet;

public class ImplicitTextBreakUP 
{

	private String matchingKeyword;
	private Triplet<String, String, String> triplet;
	public String getMatchingKeyword() {
		return matchingKeyword;
	}
	public void setMatchingKeyword(String matchingKeyword) {
		this.matchingKeyword = matchingKeyword;
	}
	public Triplet<String, String, String> getTriplet() {
		return triplet;
	}
	public void setTriplet(Triplet<String, String, String> triplet) {
		this.triplet = triplet;
	}
	
	
	
}
