package com.rage.extraction.pdf.associations;

import java.util.List;

public class TopicKeywords 
{
	private String userGroup;
	private String section;
	private String topic;
	private List<String> keywords;
	private String cleanedTopic;
	private String matchedKeyword;
	
	public String getUserGroup() {
		return userGroup;
	}
	public void setUserGroup(String userGroup) {
		this.userGroup = userGroup;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getTopic() {
		return topic;
	}
	public void setTopic(String topic) {
		this.topic = topic;
	}
	public List<String> getKeywords() {
		return keywords;
	}
	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}
	public String getCleanedTopic() {
		return cleanedTopic;
	}
	public void setCleanedTopic(String cleanedTopic) {
		this.cleanedTopic = cleanedTopic;
	}
	public String getMatchedKeyword() {
		return matchedKeyword;
	}
	public void setMatchedKeyword(String matchedKeyword) {
		this.matchedKeyword = matchedKeyword;
	}
	
}
