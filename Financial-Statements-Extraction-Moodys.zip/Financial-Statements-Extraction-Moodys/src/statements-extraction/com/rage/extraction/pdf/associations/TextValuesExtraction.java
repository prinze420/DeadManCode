package com.rage.extraction.pdf.associations;

import java.util.LinkedHashMap;
import java.util.LinkedList;

public class TextValuesExtraction {
	
	private  String lineItem;
	private  LinkedHashMap<String,LinkedList<String>> timePeriodValuesMap;
	private String matchedImplicitItem;
	public String getLineItem() {
		return lineItem;
	}
	public void setLineItem(String lineItem) {
		this.lineItem = lineItem;
	}
	public LinkedHashMap<String, LinkedList<String>> getTimePeriodValuesMap() {
		return timePeriodValuesMap;
	}
	public void setTimePeriodValuesMap(
			LinkedHashMap<String, LinkedList<String>> timePeriodValuesMap) {
		this.timePeriodValuesMap = timePeriodValuesMap;
	}
	public String getMatchedImplicitItem() {
		return matchedImplicitItem;
	}
	public void setMatchedImplicitItem(String matchedImplicitItem) {
		this.matchedImplicitItem = matchedImplicitItem;
	}
	
	
}
