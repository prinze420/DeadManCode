package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.Vector;

import com.dp.hierarchy.HierarchyNode;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.gyan.siapp.tools.sentdetect.SentenceBoundaryDetector;
import com.gyan.siapp.utils.Triplet;
import com.rage.document.pdf.utils.CustomFileWriter;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.db.MapCols;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.extract.pdf.SectionSpreader;
import com.rage.extraction.statements.similarity.JaccordSimilarity;
import com.rage.extraction.statements.similarity.SlidingWindow;
import com.rage.footnote.extraction.FootnoteExtraction;

public class NLPTextBreakUpAssociation 
{
	public Map<Long,List<Triplet<String, String, String>>>  getEachNodeAssociation(List<HierarchyNode> nodes) 
	{
		Map<Long,List<Triplet<String, String, String>>> ret= new TreeMap<Long,List<Triplet<String, String, String>>>();
		for(HierarchyNode node:nodes)
		{
			if(node.getNode()!=null && node.getNode() instanceof Paragraph)
			{
				String nodeString=node.getNode().getStringRepresentation();
				List<Triplet<String, String, String>> temp=getMatchingTripletsFromSentence(nodeString);
				if(temp!=null && temp.size()>0)
					ret.put(node.getId(), temp);
			}
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				Map<Long, List<Triplet<String, String, String>>> temp=getEachNodeAssociation(node.getChildren());
				if(temp!=null && temp.size()>0)
					ret.putAll(temp);
			}
		}
		return ret;
	}
	
	public List<Triplet<String, String, String>> getNodeAssociationTemp(List<HierarchyNode> nodes,String secType) 
	{
		List<Triplet<String, String, String>> ret= new ArrayList<Triplet<String, String, String>>();
		for(HierarchyNode node:nodes)
		{
			if(node.getNode()!=null && node.getNode() instanceof Paragraph)
			{
				if(node.getEnumeration()!=null && node.getEnumeration().getText()!=null && !node.getEnumeration().getText().trim().equals("") )
				{
					//continue;
				}
				else
				{
					String nodeString=node.getNode().getStringRepresentation();
					List<Triplet<String, String, String>> temp=getMatchingTripletsFromSentence(nodeString);
					if(temp!=null && temp.size()>0)
						ret.addAll(temp);
					
					if(temp!=null && temp.size()>0)
					{
						CustomFileWriter.writeStringToFileWithNewLine("\tParagraph="+nodeString, FinancialStatementExtractor.writer);
						for(Triplet<String, String, String> trip:temp)
						{
							CustomFileWriter.writeStringToFileWithNewLine("\t\tQuantity="+trip.getValue2()+"\tPeriod="+trip.getValue1()+"\tLineItem="+trip.getValue3(), FinancialStatementExtractor.writer);	
						}
					}
					
				}
			}
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				List<Triplet<String, String, String>> temp=getNodeAssociationTemp(node.getChildren(),secType);
				if(temp!=null && temp.size()>0)
					ret.addAll(temp);
			}
		}
		return ret;
	}

	public List<Triplet<String, String, String>> getNodeAssociationTableTemp(List<HierarchyNode> nodes,String secType) 
	{
		List<Triplet<String, String, String>> ret= new ArrayList<Triplet<String, String, String>>();
		for(HierarchyNode node:nodes)
		{
			if(node.getNode()!=null && node.getNode() instanceof DPTable)
			{
				CustomFileWriter.writeStringToFileWithNewLine("==Spreading Table==", FinancialStatementExtractor.writer);
				DPTable table= (DPTable) node.getNode();
				List<PDFBlock> blocks=AssociationsUtilities.getTableBlocksFromHierarchyNode(table);
				List<PDFLine> lines=InnerSplit.getLinesFromBlocks(blocks);
				Section sec= new Section(secType.toUpperCase(),lines,null,0,blocks);
				ArrayList<ParserOutput> poList =null;
				try
				{
					poList = SectionSpreader.spreadPageData(sec);
					System.out.println("Table Spreaded for BreakUp");
				}
				catch(Exception e)
				{
					System.out.println(e.getMessage());
					e.printStackTrace();
				}
				CustomFileWriter.writeStringToFileWithNewLine("==Table Spreaded==", FinancialStatementExtractor.writer);
			}
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				List<Triplet<String, String, String>> temp=getNodeAssociationTableTemp(node.getChildren(),secType);
				if(temp!=null && temp.size()>0)
					ret.addAll(temp);
			}
		}
		return ret;
	}
	
	public List<Triplet<String, String, String>> getTitleNodeMatchingAssociation(List<HierarchyNode> nodes, String lineItemSectionStr) 
	{
		List<Triplet<String, String, String>> ret= new ArrayList<Triplet<String, String, String>>();
		for(HierarchyNode node:nodes)
		{
			if(node.getNode()!=null && !(node.getNode() instanceof DPTable))
			{
				String nodeString=node.getNode().getStringRepresentation();
				if(nodeString.trim().equalsIgnoreCase(lineItemSectionStr.trim()))
				{
					
				}
				List<Triplet<String, String, String>> temp=getMatchingTripletsFromSentence(nodeString);
				if(temp!=null && temp.size()>0)
					ret.addAll(temp);
			}
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				List<Triplet<String, String, String>> temp=getTitleNodeMatchingAssociation(node.getChildren(),lineItemSectionStr);
				if(temp!=null && temp.size()>0)
					ret.addAll(temp);
			}
		}
		return ret;
	}
	
	public static List<Triplet<String, String, String>> getMatchingTripletsFromSentence(String sentence)
	{
		List<Triplet<String, String, String>> triplets = FootnoteExtraction.extractFootnote(sentence);
		List<Triplet<String, String, String>> ret= new ArrayList<Triplet<String, String, String>>();
		if(triplets!=null)
		{
			for(Triplet<String, String, String> trip:triplets)
			{
				if(trip.getValue1()==null || trip.getValue1().trim().equals(""))
					continue;
				ret.add(trip);
			}
		}
		
		return ret;
	}

	public static List<Triplet<String, String, String>> associateMatchingBreakUps(List<Triplet<String, String, String>> breakUps, String lineItemSectionStr) 
	{
		List<Triplet<String, String, String>> ret= new ArrayList<Triplet<String, String, String>>();
		for(Triplet<String, String, String> each:breakUps)
		{
			String quantity=each.getValue2();
			String year=each.getValue1();
			String lineItem=each.getValue3();
			boolean isLineItemMatch=checkIfNearMatch(lineItem,lineItemSectionStr);
			if(isLineItemMatch)
			{
				ret.add(each);
			}
		}
		
		return ret;
	}

	public static boolean checkIfNearMatch(String lineItem, String lineItemSectionStr) 
	{
		if(lineItem==null || lineItem.trim().equals(""))
			return false;
		if(lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			return false;
		
		if(lineItem.trim().equalsIgnoreCase(lineItemSectionStr.trim()))
			return true;
		if(lineItem.trim().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
			return true;
		
		JaccordSimilarity js= new JaccordSimilarity();
		float match=js.jaccardSimilarity(lineItem, lineItemSectionStr);
		if(match>0.75f)
		{
			return true;
		}
		
		
		return false;
	}

	public static void addBreakUpInRow(List<Triplet<String, String, String>> matchingBrkUp, ParserOutput row, ParserOutput yearRow) 
	{
		if(matchingBrkUp!=null && matchingBrkUp.size()>0 && row!=null && yearRow!=null)
		{
			for(Triplet<String, String, String> each:matchingBrkUp)
			{
				String quantity=each.getValue1();
				String year=each.getValue2();
				String lineItem=each.getValue3();
				for(int i=1;i<11;i++)
				{
					String tableYr=MapCols.getPOAsRepValOnIndex(yearRow, i);
					if(tableYr!=null && year!=null 
							&& !tableYr.trim().equals("") && !year.trim().equals(""))
					{
						if(tableYr.trim().equalsIgnoreCase(year.trim()))
						{
							ParserOutput po= new ParserOutput();
							MapCols.setPOValueOnIndex(po, i, quantity);
							MapCols.setPOValueOnIndex(po, 0, lineItem);
							row.getBreakupItems().add(po);
							break;
						}
					}
				}
				
				
			}
		}
		
	}
	
	
	
	static List<TextValuesExtraction> createTabularData(List<Triplet<String, String, String>> triplets)
	{
		
		List<TextValuesExtraction> textValuesList = new LinkedList<TextValuesExtraction>();
		for(Triplet<String, String, String> triplet:triplets)
		{
			String value = triplet.getValue2();
			String year = triplet.getValue1();
			String lineItem = triplet.getValue3().trim().toLowerCase();
			/*if(textValuesList.size()==0)
			{*/
			if(!addMatchedLineItem(textValuesList,lineItem,year,value))
			{
				addUnMatchedLineItem(textValuesList,lineItem,year,value);
			}
			//}
		}
		return textValuesList;

	}

	private static boolean addMatchedLineItem(
			List<TextValuesExtraction> textValuesList,String lineItem,String timePeriod, String value) 
	{
		for(TextValuesExtraction textValues:textValuesList)
		{
			if(textValues.getLineItem().trim().equalsIgnoreCase(lineItem))
			{
				LinkedHashMap<String, LinkedList<String>> timePeriodValuesMap = textValues.getTimePeriodValuesMap();
				if(timePeriodValuesMap.containsKey(timePeriod))
				{
					return false;
					/*LinkedList<String> valuesList = timePeriodValuesMap.get(timePeriod);
					valuesList.add(value);*/
				}
				else
				{
					LinkedList<String> valuesList = new LinkedList<String>();
					valuesList.add(value);
					timePeriodValuesMap.put(timePeriod, valuesList);
				}
				return true;
			}
		}

		return false;
	}

	private static boolean addUnMatchedLineItem(
			List<TextValuesExtraction> textValuesList,String lineItem,String timePeriod, String value) 
	{
		TextValuesExtraction textValues = new TextValuesExtraction();
		textValues.setLineItem(lineItem);
		LinkedHashMap<String, LinkedList<String>> timePeriodValuesMap = new LinkedHashMap<String, LinkedList<String>>();
		LinkedList<String> valuesList = new LinkedList<String>();
		valuesList.add(value);
		timePeriodValuesMap.put(timePeriod, valuesList);
		textValues.setTimePeriodValuesMap(timePeriodValuesMap);
		textValuesList.add(textValues);
		return true;
	}
	public static void main(String[] args) 
	{
		List<Triplet<String, String, String>> triplets = getMatchingTripletsFromSentence("Included in the Group�s trade and other receivables at 31 March 2013, are balances of �32.1m (2012: �32.0m) which are past due at the reporting date but not impaired because");
		for(Triplet<String, String, String> trip:triplets)
		{
			System.out.println("trip=="+trip.getValue1()+"=="+trip.getValue2()+"=="+trip.getValue3());
		}
	}

	public static List<List<Triplet<String, String, String>>> getSentenceWiseTriplets(String stringRepresentation) 
	{
		List<List<Triplet<String, String, String>>> ret= new ArrayList<List<Triplet<String, String, String>>>();
		Vector<String> sentences = SentenceBoundaryDetector.detectSentenceBoundary(stringRepresentation); 
		for(String sentence:sentences)
		{
			List<Triplet<String, String, String>> triplets = FootnoteExtraction.extractFootnote(sentence);
			List<Triplet<String, String, String>> temp= new ArrayList<Triplet<String, String, String>>();
			for(Triplet<String, String, String> trip:triplets)
			{
				if(trip.getValue1()==null || trip.getValue1().trim().equals(""))
					continue;
				temp.add(trip);
			}
			if(temp.size()>0)
				ret.add(temp);
		}
		return ret;
	}	
}
