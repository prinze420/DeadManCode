package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import com.dp.hierarchy.HierarchyNode;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.gyan.siapp.tools.sentdetect.SentenceBoundaryDetector;
import com.rage.document.pdf.utils.StringUtility;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.db.ParserOutput;

public class ImplicitSplit 
{
	public static String tempString="";
	
	public List<HierarchyNode> getImplicitSplitBreakUps(String lineItemSectionStr, ParserOutput row, ParserOutput yearRow, ParserOutput attributeRow, HierarchyNode hierarchyNode, String secType, List<PDFLine> rowLines)
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		
		tempString=tempString+"\n\n"+"===ROW==="+lineItemSectionStr;
		
		HierarchyNode allRulesRunMatchNode=getMatchingNodeRunningAllRules(hierarchyNode,lineItemSectionStr,secType,rowLines);
		if(allRulesRunMatchNode!=null)
			ret.add(allRulesRunMatchNode);
		
		
		HierarchyNode matchingTitleNode=getOnlyTitleMatchingNode(hierarchyNode, lineItemSectionStr,secType,rowLines);
		if(matchingTitleNode!=null)
			ret.add(matchingTitleNode);
		
		return ret;
	}

	private HierarchyNode getOnlyTitleMatchingNode(HierarchyNode hierarchyNode, String lineItemSectionStr,String secType, List<PDFLine> rowLines) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> tempNodeList= new ArrayList<HierarchyNode>();
			tempNodeList.add(hierarchyNode);
			HierarchyNode matchingNode=matchOnlyTitles(tempNodeList, lineItemSectionStr,hierarchyNode,rowLines);
			if(matchingNode!=null)
			{
				// textBreakups for paras, decomposition for tables
				// merging both the breakups with the row
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 1");
				tempString=tempString+"\nImplicit matching found==Rule 5 matched-Only Title Match Rule";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
				
			}
			return matchingNode;
		}
		return null;
	}

	private HierarchyNode getMatchingNodeRunningAllRules(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType, List<PDFLine> rowLines) 
	{
		HierarchyNode matchingNode=null;
		HierarchyNode tempMatchingNode1=null;
		HierarchyNode tempMatchingNode2=null;
		HierarchyNode tempMatchingNode3=null;
		
		// checking main enums hierarchy nodes for matching
		matchingNode=checkMainEnumsNodesInHierarchy(hierarchyNode,lineItemSectionStr,secType);
		
		
		// Check title and all enumerated nodes
		if(matchingNode==null)
			matchingNode=checkTitleAndEnumeratedNodes(hierarchyNode,lineItemSectionStr,secType);
		else
			tempMatchingNode1=checkTitleAndEnumeratedNodes(matchingNode,lineItemSectionStr,secType);
		
		// check table headings with colons followed by table
		if(matchingNode==null)
			matchingNode=checkTableHeadingWithTable(hierarchyNode,lineItemSectionStr,secType,rowLines);
		else if (tempMatchingNode1 == null) 
			tempMatchingNode2=checkTableHeadingWithTable(matchingNode,lineItemSectionStr,secType,rowLines);
		else
			tempMatchingNode2=checkTableHeadingWithTable(tempMatchingNode1,lineItemSectionStr,secType,rowLines);
		
		// Checking table for lineitems without values
		if(matchingNode==null)
			matchingNode=checkTableRowWithOutValues(hierarchyNode,lineItemSectionStr,secType);
		else if (tempMatchingNode2 != null) 
			tempMatchingNode3=checkTableRowWithOutValues(tempMatchingNode2,lineItemSectionStr,secType);
		else if(tempMatchingNode1!=null)
			tempMatchingNode3=checkTableRowWithOutValues(tempMatchingNode1,lineItemSectionStr,secType);
		else
			tempMatchingNode3=checkTableRowWithOutValues(matchingNode,lineItemSectionStr,secType);
		
		if(tempMatchingNode3!=null)
			return tempMatchingNode3;
		else if (tempMatchingNode2!=null)
			return tempMatchingNode2;
		else if (tempMatchingNode1!=null)
			return tempMatchingNode1;
		else if (matchingNode!=null)
			return matchingNode;
		else 
			return null;
		
	}

	public HierarchyNode getImplicitMatchingNodes(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType) 
	{
		HierarchyNode matchingNode=null;
		HierarchyNode tempMatchingNode1=null;
		HierarchyNode tempMatchingNode2=null;
		HierarchyNode tempMatchingNode3=null;
		
		// Checking table for lineitems without values
		tempMatchingNode3=checkTableRowWithOutValues(hierarchyNode,lineItemSectionStr,secType);
		
		// check table headings with colons followed by table
		
		if(tempMatchingNode3==null)
			tempMatchingNode2=checkTableHeadingWithTableWithOutValues(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode3;
		
		// Check title and all enumerated nodes
		if(tempMatchingNode2==null)
			tempMatchingNode1=checkTitleAndEnumeratedNodes(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode2;
		
		// checking main enums hierarchy nodes for matching
		if(tempMatchingNode1==null)
			matchingNode=checkMainEnumsNodesInHierarchy(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode1;
		
		if(matchingNode!=null)
			return matchingNode;
		
		return null;
	}
	
	public HierarchyNode getMatchingNodesInReverseOrder(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType, List<PDFLine> rowLines) 
	{
		HierarchyNode matchingNode=null;
		HierarchyNode tempMatchingNode1=null;
		HierarchyNode tempMatchingNode2=null;
		HierarchyNode tempMatchingNode3=null;
		
		// Checking table for lineitems without values
		tempMatchingNode3=checkTableRowWithOutValues(hierarchyNode,lineItemSectionStr,secType);
		
		// check table headings with colons followed by table
		
		if(tempMatchingNode3==null)
			tempMatchingNode2=checkTableHeadingWithTableWithOutValues(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode3;
		
		// Check title and all enumerated nodes
		if(tempMatchingNode2==null)
			tempMatchingNode1=checkTitleAndEnumeratedNodes(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode2;
		
		// checking main enums hierarchy nodes for matching
		if(tempMatchingNode1==null)
			matchingNode=checkMainEnumsNodesInHierarchy(hierarchyNode,lineItemSectionStr,secType);
		else
			return tempMatchingNode1;
		
		if(matchingNode!=null)
			return matchingNode;
		
		return null;
	}
	
	public List<HierarchyNode> DFSMultipleMatchingImplicit(HierarchyNode node,String toMatch,HierarchyNode rootNode)
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(node!=null)
		{
			boolean isMatchFound=false;
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				for(HierarchyNode childNode:node.getChildren())
				{
					List<HierarchyNode> matchingNodes=DFSMultipleMatchingImplicit(childNode,toMatch,rootNode);
					if(matchingNodes!=null && matchingNodes.size()>0)
					{
						isMatchFound=true;
						ret.addAll(matchingNodes);
					}
				}
			}
			HierarchyNode mNode=matchTableStringWithoutValues(node,toMatch);
			if(mNode!=null && !isMatchFound)
			{
				isMatchFound=true;
				ret.add(mNode);
			}
			
			if(!isMatchFound)
			{
				mNode=matchTableTitleFollowedByTable(node,toMatch,rootNode);
				if(mNode!=null && !isMatchFound)
				{
					isMatchFound=true;
					ret.add(mNode);
				}
			}
			
			/*if(!isMatchFound)
			{
				mNode=matchTableStringWithLineItem(node,toMatch);
				if(mNode!=null && !isMatchFound)
				{
					System.out.println("TABLE STRING MATCHED:::: "+toMatch);
					isMatchFound=true;
					ret.add(mNode);
				}
			}*/
			
			if(!isMatchFound)
			{
				mNode=matchTitleAndEnumNodes(node,toMatch);
				if(mNode!=null && !isMatchFound)
				{
					isMatchFound=true;
					ret.add(mNode);
				}
			}
			
			/*if(!isMatchFound)
			{
				mNode=matchMainEnumNodesInHierarchy(node,toMatch);
				if(mNode!=null && !isMatchFound)
				{
					isMatchFound=true;
					ret.add(mNode);
				}
			}*/
		}
		return ret;
	}
	
	public List<HierarchyNode> DFSMultipleMatchingImplicitOnlyHeaders(HierarchyNode node,String toMatch,HierarchyNode rootNode)
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(node!=null)
		{
			boolean isMatchFound=false;
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				for(HierarchyNode childNode:node.getChildren())
				{
					List<HierarchyNode> matchingNodes=DFSMultipleMatchingImplicitOnlyHeaders(childNode,toMatch,rootNode);
					if(matchingNodes!=null && matchingNodes.size()>0)
					{
						isMatchFound=true;
						ret.addAll(matchingNodes);
					}
				}
			}
			HierarchyNode mNode=null;
			/*HierarchyNode mNode=matchTableStringWithoutValues(node,toMatch);
			if(mNode!=null && !isMatchFound)
			{
				isMatchFound=true;
				ret.add(mNode);
			}
			
			if(!isMatchFound)
			{
				mNode=matchTableTitleFollowedByTable(node,toMatch,rootNode);
				if(mNode!=null && !isMatchFound)
				{
					isMatchFound=true;
					ret.add(mNode);
				}
			}*/
			
			if(!isMatchFound)
			{
				mNode=matchTitleAndEnumNodesOnWordCountConstraint(node,toMatch);
				if(mNode!=null && !isMatchFound)
				{
					isMatchFound=true;
					ret.add(mNode);
				}
			}
		}
		return ret;
	}
	
	public HierarchyNode matchMainEnumNodesInHierarchy(HierarchyNode node, String lineItemSectionStr) 
	{
		List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
		nodes.add(node);
		
		HierarchyNode matchingNode=matchTopNodesInHierarchyNodeOnMaxLevelDepthWithLineNoConstraint(nodes, lineItemSectionStr, 3, 0);
		return matchingNode;
	}

	private HierarchyNode matchTitleAndEnumNodes(HierarchyNode childNode, String lineItemString) 
	{
		boolean isMatch=false;
		if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null && !childNode.getEnumeration().getText().equals(""))
		{
			isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
			if(isMatch)
				return childNode;
		}
		
		if(childNode.getNode()!=null && childNode.getNode() instanceof Title)
		{
			Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
			Title title=(Title) childNode.getNode();
			List<PDFLine> titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
			if(sentences!=null && sentences.size()>1)
			{}
			else if (titleLines!=null && titleLines.size()>1)
			{}
			else
			{
				isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
				if(isMatch)
					return childNode;
			}
		}
		
		if(childNode.getNode()!=null && childNode.getNode().getStringRepresentation()!=null)
		{
			if(childNode.getNode().getStringRepresentation().trim().equalsIgnoreCase(lineItemString.trim()))
			{
				isMatch=true;
				return childNode;
			}
			
		}
		return null;
	}

	
	private HierarchyNode matchTitleAndEnumNodesOnWordCountConstraint(HierarchyNode childNode, String lineItemString) 
	{
		boolean isMatch=false;
		if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null && !childNode.getEnumeration().getText().equals(""))
		{
			isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
			String nodeStr=childNode.getNode().getStringRepresentation();
			if(!isWordLengthInLimit(nodeStr,10))
			{
				isMatch=false;
			}
			if(isMatch)
				return childNode;
		}
		
		if(childNode.getNode()!=null && childNode.getNode() instanceof Title)
		{
			Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
			Title title=(Title) childNode.getNode();
			List<PDFLine> titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
			if(sentences!=null && sentences.size()>1)
			{}
			else if (titleLines!=null && titleLines.size()>1)
			{}
			else
			{
				isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
				String nodeStr=childNode.getNode().getStringRepresentation();
				if(!isWordLengthInLimit(nodeStr,10))
				{
					isMatch=false;
				}
				if(isMatch)
					return childNode;
			}
		}
		
		if(childNode.getNode()!=null && childNode.getNode().getStringRepresentation()!=null)
		{
			if(childNode.getNode().getStringRepresentation().trim().equalsIgnoreCase(lineItemString.trim()))
			{
				isMatch=true;
				return childNode;
			}
			
		}
		return null;
	}
	
	private HierarchyNode matchTableTitleFollowedByTable(HierarchyNode childNode, String lineItemSectionStr, HierarchyNode rootNode) 
	{
		boolean isMatch=false;
		if(childNode.getNode()!=null && (childNode.getNode() instanceof Title || childNode.getNode() instanceof Paragraph))
		{
			
			isMatch=StringUtility.doesKeywordMatchTokenSerial(lineItemSectionStr,childNode.getNode().getStringRepresentation());
			if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
			{
				HierarchyNode nextNode=getNextHierarchyNodeWithUsingId(rootNode,childNode.getId(),false);
				if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
				{
					//return nextNode;
					return childNode;
				}
			}
			// partial match and match table totals
			//isMatch=StringUtility.isPartialMatch(childNode.getNode().getStringRepresentation(),lineItemSectionStr);
			if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
			{
				// check for title checks if sentences not more than 2 
				// and lines not more 2 
				Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
				List<PDFLine> titleLines=null;
				if(childNode.getNode() instanceof Title)
				{
					Title title=(Title) childNode.getNode();
					titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
				}
				else if (childNode.getNode() instanceof Paragraph)
				{
					Paragraph para=(Paragraph) childNode.getNode();
					titleLines=AssociationsUtilities.getParagraphDataFromHierarchyNode(para);
				}
				
				if(sentences!=null && sentences.size()>2)
				{}
				else if (titleLines!=null && titleLines.size()>2)
				{}
				else
				{
					HierarchyNode nextNode=getNextHierarchyNodeWithUsingId(rootNode,childNode.getId(),false);
					if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
					{
						return childNode;
					}
				}
			}
		}
		return null;
	}

	private HierarchyNode matchTableStringWithoutValues(HierarchyNode childNode,String lineItemSectionStr)
	{
		boolean isMatch=false;
		if(childNode.getNode()!=null && childNode.getNode() instanceof DPTable)
		{
			DPTable table= (DPTable) childNode.getNode();
			List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
			if(lines!=null && lines.size()>0)
			{
				for(PDFLine line:lines)
				{
					isMatch=StringUtility.tokenizeRandomContains(lineItemSectionStr,line.getLine());
					boolean isLineContainsNumberChunk=AssociationsUtilities.isLineContainsNumberChunk(line);
					if(isMatch && !isLineContainsNumberChunk)
					{
						return childNode;
					}
				}
			}
		}
		return null;
	}
	
	private HierarchyNode matchTableStringWithLineItem(HierarchyNode childNode,String lineItemSectionStr)
	{
		boolean isMatch=false;
		if(childNode.getNode()!=null && childNode.getNode() instanceof DPTable)
		{
			DPTable table= (DPTable) childNode.getNode();
			List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
			if(lines!=null && lines.size()>0)
			{
				for(PDFLine line:lines)
				{
					isMatch=StringUtility.doesKeywordMatchTokenSerial(lineItemSectionStr,line.getLine());
					if(isMatch)
					{
						return childNode;
					}
				}
			}
		}
		return null;
	}
	
	private HierarchyNode checkTableRowWithOutValues(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			HierarchyNode matchingNode=matchRowInTableWithNoValues(nodes,lineItemSectionStr,hierarchyNode);
			//System.out.println("");
			if(matchingNode!=null)
			{
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 4");
				tempString=tempString+"\nImplicit matching found==Rule 4 matched";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
			}
			return matchingNode;
		}
		return null;
	}

	private HierarchyNode checkTableHeadingWithTable(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType, List<PDFLine> rowLines) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			HierarchyNode matchingNode=matchTableTitleAndNextTable(nodes,lineItemSectionStr,hierarchyNode,rowLines);
			//System.out.println("");
			if(matchingNode!=null)
			{
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 3");
				tempString=tempString+"\nImplicit matching found==Rule 3 matched";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
			}
			return matchingNode;
		}
		return null;
	}

	private HierarchyNode checkTableHeadingWithTableWithOutValues(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			HierarchyNode matchingNode=matchTableTitleAndNextTableWithOutValues(nodes,lineItemSectionStr,hierarchyNode);
			//System.out.println("");
			if(matchingNode!=null)
			{
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 3");
				tempString=tempString+"\nImplicit matching found==Rule 3 matched";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
			}
			return matchingNode;
		}
		return null;
	}
	
	private HierarchyNode matchRowInTableWithNoValues(List<HierarchyNode> nodes, String lineItemSectionStr,HierarchyNode mainHNode) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			for(int i=0;i<nodes.size();i++)
			{
				HierarchyNode childNode=nodes.get(i);
				boolean isMatch=false;
				if(childNode.getNode()!=null && childNode.getNode() instanceof DPTable)
				{
					DPTable table= (DPTable) childNode.getNode();
					List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
					if(lines!=null && lines.size()>0)
					{
						for(PDFLine line:lines)
						{
							isMatch=StringUtility.tokenizeRandomContains(lineItemSectionStr,line.getLine());
							boolean isLineContainsNumberChunk=AssociationsUtilities.isLineContainsNumberChunk(line);
							if(isMatch && !isLineContainsNumberChunk)
							{
								return childNode;
							}
						}
					}
				}
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchRowInTableWithNoValues(childNode.getChildren(), lineItemSectionStr,mainHNode);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}

	private HierarchyNode matchTableTitleAndNextTable(List<HierarchyNode> nodes, String lineItemSectionStr, HierarchyNode mainHNode, List<PDFLine> rowLines) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			for(int i=0;i<nodes.size();i++)
			{
				HierarchyNode childNode=nodes.get(i);
				boolean isMatch=false;
				if(childNode.getNode()!=null && (childNode.getNode() instanceof Title || childNode.getNode() instanceof Paragraph))
				{
					isMatch=StringUtility.sentenceTokenizeRandomContains(lineItemSectionStr,childNode.getNode().getStringRepresentation());
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
						if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
						{
							//return nextNode;
							return childNode;
						}
					}
					// partial match and match table totals
					isMatch=StringUtility.isPartialMatch(childNode.getNode().getStringRepresentation(),lineItemSectionStr);
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						// check for title checks if sentences not more than 2 
						// and lines not more 2 
						Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
						List<PDFLine> titleLines=null;
						if(childNode.getNode() instanceof Title)
						{
							Title title=(Title) childNode.getNode();
							titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
						}
						else if (childNode.getNode() instanceof Paragraph)
						{
							Paragraph para=(Paragraph) childNode.getNode();
							titleLines=AssociationsUtilities.getParagraphDataFromHierarchyNode(para);
						}
						
						if(sentences!=null && sentences.size()>2)
						{}
						else if (titleLines!=null && titleLines.size()>2)
						{}
						else
						{
							HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
							if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
							{
								// total values match in table
								boolean isValuesPresent=AssociationsUtilities.isRowNumberPresentInTable(rowLines,nextNode);
								if(isValuesPresent)
									return childNode;
							}
						}
					}
				}

				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchTableTitleAndNextTable(childNode.getChildren(), lineItemSectionStr,mainHNode,rowLines);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}

	private HierarchyNode matchTableTitleAndNextTableWithOutValues(List<HierarchyNode> nodes, String lineItemSectionStr, HierarchyNode mainHNode) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			for(int i=0;i<nodes.size();i++)
			{
				HierarchyNode childNode=nodes.get(i);
				boolean isMatch=false;
				if(childNode.getNode()!=null && (childNode.getNode() instanceof Title || childNode.getNode() instanceof Paragraph))
				{
					
					isMatch=StringUtility.doesKeywordMatchTokenSerial(lineItemSectionStr,childNode.getNode().getStringRepresentation());
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
						if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
						{
							//return nextNode;
							return childNode;
						}
					}
					// partial match and match table totals
					//isMatch=StringUtility.isPartialMatch(childNode.getNode().getStringRepresentation(),lineItemSectionStr);
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						// check for title checks if sentences not more than 2 
						// and lines not more 2 
						Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
						List<PDFLine> titleLines=null;
						if(childNode.getNode() instanceof Title)
						{
							Title title=(Title) childNode.getNode();
							titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
						}
						else if (childNode.getNode() instanceof Paragraph)
						{
							Paragraph para=(Paragraph) childNode.getNode();
							titleLines=AssociationsUtilities.getParagraphDataFromHierarchyNode(para);
						}
						
						if(sentences!=null && sentences.size()>2)
						{}
						else if (titleLines!=null && titleLines.size()>2)
						{}
						else
						{
							HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
							if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
							{
								return childNode;
							}
						}
					}
				}

				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchTableTitleAndNextTableWithOutValues(childNode.getChildren(), lineItemSectionStr,mainHNode);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}
	
	private HierarchyNode getNextNode(HierarchyNode node, List<HierarchyNode> nodes, int currentNodeID, HierarchyNode mainHNode) 
	{
		if(node.getChildren()!=null && node.getChildren().size()>0 )
		{
			return node.getChildren().get(0);
		}
		if(nodes!=null)
		{
			for(int i=currentNodeID;i<nodes.size();i++)
			{
				return nodes.get(i);
			}
		}
		HierarchyNode nextNode=getNextHierarchyNodeWithUsingId(mainHNode,node.getId(),false);
		if(nextNode!=null)
			return nextNode;
		
		return null;
				
	}

	private HierarchyNode getNextHierarchyNodeWithUsingId(HierarchyNode node, long nodeId, boolean isNextNodeToBeReturned) 
	{
		if(node!=null)
		{
			if(isNextNodeToBeReturned)
				return node;
			if(node.getId()==nodeId)
			{
				isNextNodeToBeReturned=true;
			}
			if(node.getChildren()!=null && node.getChildren().size()>0)
			{
				for(HierarchyNode childNode:node.getChildren())
				{
					HierarchyNode nextNode=getNextHierarchyNodeWithUsingId(childNode, nodeId, isNextNodeToBeReturned);
					if(nextNode!=null)
						return nextNode;
				}
			}
		}
		return null;
	}

	private HierarchyNode checkTitleAndEnumeratedNodes(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> nodes= new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			HierarchyNode matchingNode=matchTitleAndEnumsNodeString(nodes,lineItemSectionStr);
			//System.out.println("");
			if(matchingNode!=null)
			{
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 2");
				tempString=tempString+"\nImplicit matching found==Rule 2 matched";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
			}
		
			return matchingNode;
		}
		
		return null;
	}
	
	private HierarchyNode matchOnlyTitles(List<HierarchyNode> nodes, String lineItemString, HierarchyNode mainHNode, List<PDFLine> rowLines) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			int i=0;
			for(HierarchyNode childNode:nodes)
			{
				boolean isMatch=false;
				
				if(childNode.getNode()!=null && childNode.getNode() instanceof Title)
				{
					Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
					Title title=(Title) childNode.getNode();
					List<PDFLine> titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
					if(sentences!=null && sentences.size()>1)
					{}
					else if (titleLines!=null && titleLines.size()>1)
					{}
					else
					{
						isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
						if(isMatch)
							return childNode;
					}
				}
				
				if(childNode.getNode()!=null && (childNode.getNode() instanceof Title || childNode.getNode() instanceof Paragraph))
				{
					isMatch=StringUtility.sentenceTokenizeRandomContains(lineItemString,childNode.getNode().getStringRepresentation());
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
						if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
						{
							//return nextNode;
							return childNode;
						}
					}
					// partial match and match table totals
					isMatch=StringUtility.isPartialMatch(childNode.getNode().getStringRepresentation(),lineItemString);
					if(isMatch && childNode.getNode().getStringRepresentation().trim().endsWith(":") ) 
					{
						// check for title checks if sentences not more than 2 
						// and lines not more 2 
						Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
						List<PDFLine> titleLines=null;
						if(childNode.getNode() instanceof Title)
						{
							Title title=(Title) childNode.getNode();
							titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
						}
						else if (childNode.getNode() instanceof Paragraph)
						{
							Paragraph para=(Paragraph) childNode.getNode();
							titleLines=AssociationsUtilities.getParagraphDataFromHierarchyNode(para);
						}
						
						if(sentences!=null && sentences.size()>2)
						{}
						else if (titleLines!=null && titleLines.size()>2)
						{}
						else
						{
							HierarchyNode nextNode=getNextNode(childNode,nodes,i+1,mainHNode);
							if(nextNode!=null && nextNode.getNode()!=null && nextNode.getNode() instanceof DPTable)
							{
								// total values match in table
								boolean isValuesPresent=AssociationsUtilities.isRowNumberPresentInTable(rowLines,nextNode);
								if(isValuesPresent)
									return childNode;
							}
						}
					}
				}
				
				if(childNode.getNode()!=null && childNode.getNode().getStringRepresentation()!=null)
				{
					if(childNode.getNode().getStringRepresentation().trim().equalsIgnoreCase(lineItemString.trim()))
					{
						isMatch=true;
						return childNode;
					}
					
				}
				
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchOnlyTitles(childNode.getChildren(), lineItemString,mainHNode,rowLines);
					if(matchedNode!=null)
						return matchedNode;
				}
				i++;
			}
		}
		return null;
	}
	
	private HierarchyNode matchTitleAndEnumsNodeString(List<HierarchyNode> nodes, String lineItemString) 
	{
		if(nodes!=null && nodes.size()>0)
		{
			for(HierarchyNode childNode:nodes)
			{
				boolean isMatch=false;
				if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null && !childNode.getEnumeration().getText().equals(""))
				{
					isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
					if(isMatch)
						return childNode;
				}
				
				if(childNode.getNode()!=null && childNode.getNode() instanceof Title)
				{
					Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(childNode.getNode().getStringRepresentation());
					Title title=(Title) childNode.getNode();
					List<PDFLine> titleLines=AssociationsUtilities.getTitleDataFromHierarchyNode(title);
					if(sentences!=null && sentences.size()>1)
					{}
					else if (titleLines!=null && titleLines.size()>1)
					{}
					else
					{
						isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItemString,childNode.getNode().getStringRepresentation());
						if(isMatch)
							return childNode;
					}
				}
				
				if(childNode.getNode()!=null && childNode.getNode().getStringRepresentation()!=null)
				{
					if(childNode.getNode().getStringRepresentation().trim().equalsIgnoreCase(lineItemString.trim()))
					{
						isMatch=true;
						return childNode;
					}
					
				}
				
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchTitleAndEnumsNodeString(childNode.getChildren(), lineItemString);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}

	private HierarchyNode checkMainEnumsNodesInHierarchy(HierarchyNode hierarchyNode, String lineItemSectionStr, String secType) 
	{
		if(hierarchyNode!=null && lineItemSectionStr!=null && !lineItemSectionStr.trim().equals(""))
		{
			List<HierarchyNode> nodes=new ArrayList<HierarchyNode>();
			nodes.add(hierarchyNode);
			HierarchyNode matchingNode=matchTopNodesInHierarchyNodeOnMaxLevelDepth(nodes, lineItemSectionStr, 3, 0);
			//System.out.println("");
			if(matchingNode!=null)
			{
				// textBreakups for paras, decomposition for tables
				// merging both the breakups with the row
				System.out.println("Found Node==="+lineItemSectionStr+"==Section="+secType+", Rule 1");
				tempString=tempString+"\nImplicit matching found==Rule 1 matched";
				POBreakUps poBreakUp= new POBreakUps(matchingNode);
				poBreakUp.setCoOrdinate(poBreakUp);
				tempString=tempString+"\n Page No="+(poBreakUp.getStartPg()+1)+"-"+(poBreakUp.getEndPg()+1);
				tempString=tempString+"\n"+HierarchyNode.toDeepString(matchingNode, "");
				tempString=tempString+"\n";
				
			}
			return matchingNode;
		}
		return null;
	}
	
	public static HierarchyNode matchTopNodesInHierarchyNodeOnMaxLevelDepthWithLineNoConstraint(List<HierarchyNode> nodes, 
			String lineItem, int maxDepth,int currentDepth) 
	{
		if(nodes!=null && nodes.size()>0 && currentDepth<=maxDepth)
		{
			for(HierarchyNode childNode:nodes)
			{
				//List<PDFLine> lines=AssociationsUtilities.getListOfLinesFromHierarchyNode(childNode);
				boolean isMatch=false;
				if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null && !childNode.getEnumeration().getText().trim().equals("") /*&& lines!=null && lines.size()>0 && lines.size()<3*/)
				{
					
					isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItem,childNode.getNode().getStringRepresentation());
					if(isMatch)
					{
						String nodeStr=childNode.getNode().getStringRepresentation();
						
						if(!isWordLengthInLimit(nodeStr,10))
						{
							isMatch=false;
						}
					}
				}
				
				if(isMatch)
					return childNode ;
			}
			for(HierarchyNode childNode:nodes)
			{
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchTopNodesInHierarchyNodeOnMaxLevelDepthWithLineNoConstraint(childNode.getChildren(), lineItem,maxDepth,currentDepth+1);
					if(matchedNode!=null)
						return matchedNode ;
				}
			}
		}
		
		return null;
	}
	
	private static boolean isWordLengthInLimit(String nodeStr,int lengthToCheck) 
	{
		if(nodeStr==null || nodeStr.trim().equals(""))
			return false;
		String[] lk=nodeStr.trim().split("\\W");
		int length=0;
		for(String k:lk)
		{
			if(k.trim().equals(""))
				continue;
			length++;
		}
		if(length<=lengthToCheck)
			return true;
		return false;
	}

	public static HierarchyNode matchTopNodesInHierarchyNodeOnMaxLevelDepth(List<HierarchyNode> nodes, 
			String lineItem, int maxDepth,int currentDepth) 
	{
		if(nodes!=null && nodes.size()>0 && currentDepth<=maxDepth)
		{
			for(HierarchyNode childNode:nodes)
			{
				boolean isMatch=false;
				if(childNode.getEnumeration()!=null && childNode.getEnumeration().getText()!=null && !childNode.getEnumeration().getText().trim().equals(""))
				{
					isMatch=StringUtility.tokenizeRandomContainsBothWay(lineItem,childNode.getNode().getStringRepresentation());
				}
				
				if(isMatch)
					return childNode;
			}
			for(HierarchyNode childNode:nodes)
			{
				if(childNode.getChildren()!=null && childNode.getChildren().size()>0)
				{
					HierarchyNode matchedNode=matchTopNodesInHierarchyNodeOnMaxLevelDepth(childNode.getChildren(), lineItem,maxDepth,currentDepth+1);
					if(matchedNode!=null)
						return matchedNode;
				}
			}
		}
		return null;
	}
	
	public static void main(String[] args) {
		String l="asdkjb asdkjh,asdkj $1289.9 asdiuhn kl";
		String[] k=l.split("\\W");
		for (String j : k) {
			System.out.println(j);	
		}
		System.out.println("asd");
		Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary("this is one. this is second.");
		for(String h:sentences)
		{
			System.out.println("S=="+h);
		}
	}
}
