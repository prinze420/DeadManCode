package com.rage.extraction.pdf.associations;

import java.util.ArrayList;
import java.util.List;

import com.dp.hierarchy.HierarchyNode;
import com.dp.structures.Structure;
import com.dp.structures.StructureType;
import com.dp.structures.basicstructures.Title;
import com.dp.structures.complexstructures.DPTable;
import com.dp.structures.complexstructures.Paragraph;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.statements.db.POBreakUps;
import com.rage.extraction.statements.extract.pdf.Row;

public class ExplicitInnerSplit 
{
	public List<POBreakUps> splitHierarchyNodes(List<HierarchyNode> nodes, String lineItemSectionStr, boolean searchForInnerNodes)
	{
		List<POBreakUps> ret= new ArrayList<POBreakUps>();
		if(nodes!=null && nodes.size()>0)
		{
			for(HierarchyNode node:nodes)
			{
				List<HierarchyNode> mNodes=null;
				/*if(searchForInnerNodes)
					mNodes=findMatchingHierarchyNodeWithLineItem(lineItemSectionStr,node);
				else*/
				mNodes=nodes;
				if(mNodes!=null && mNodes.size()>0)
				{
					for(HierarchyNode hnode:mNodes)
					{
						Structure dataNode=hnode.getNode();
						if(dataNode!=null)
						{
							if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.TITLE))
							{
								Title title=(Title)dataNode;
								List<POBreakUps> breakUps=preparePOBreakUpsFromHierarchyNode(hnode);
								ret.addAll(breakUps);
							}
							else if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.TABLE))
							{
								DPTable table=(DPTable)dataNode;
								//List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
								List<POBreakUps> breakUps=preparePOBreakUpsFromHierarchyNode(hnode);
								//List<POBreakUps> breakUps=preparePOBreakUpsFromTable(table,lineItemSectionStr);
								ret.addAll(breakUps);
							}
							else if(dataNode.getType()!=null && dataNode.getType().equals(StructureType.PPARAGRAPH))
							{
								Paragraph paragraph=(Paragraph)dataNode;
								//List<PDFLine> lines=AssociationsUtilities.getParagraphDataFromHierarchyNode(paragraph);
								List<POBreakUps> breakUps=preparePOBreakUpsFromHierarchyNode(hnode);
								ret.addAll(breakUps);
							}
						}	
					}
				}
				else
				{
					List<POBreakUps> breakUps=preparePOBreakUpsFromHierarchyNode(node);
					ret.addAll(breakUps);
				}
			}
		}
		return ret;
	}
	
	private List<POBreakUps> preparePOBreakUpsFromTable(DPTable table, String lineItemSectionStr) 
	{
		List<POBreakUps> ret=  new ArrayList<POBreakUps>();
		List<PDFLine> lines=AssociationsUtilities.getTableDataFromHierarchyNode(table);
		boolean isStartsWith=false;
		List<PDFLine> matchLines= new ArrayList<PDFLine>();
		List<PDFLine> tempLines= new ArrayList<PDFLine>();
		// Match for startswith and equals first. 
		// If not found then check for contains check
		
		// StartsWith and equals check.
		for (PDFLine line:lines)
		{
			if(line.getLine().trim().toLowerCase().startsWith(lineItemSectionStr.trim().toLowerCase()))
			{
				isStartsWith=true;
				matchLines.add(line);
				continue;
			}
			if(line.getLine().trim().toLowerCase().equals(lineItemSectionStr.trim().toLowerCase()))
			{
				isStartsWith=true;
				matchLines.clear();
				matchLines.add(line);
				continue;
			}
			if(matchLines.size()>0)
			{
				// Check for total line for line item
				boolean isTotalLineMatch=checkForTotalKeyWordLine(line,matchLines,lineItemSectionStr);
				if(isTotalLineMatch)
				{
					tempLines.addAll(matchLines);
					matchLines.add(line);
				}
				else
					tempLines.add(line);
			}
		}

		// Contains check
		if(!isStartsWith)
		{
			for (PDFLine line:lines)
			{
				if(line.getLine().trim().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
				{
					isStartsWith=true;
					matchLines.add(line);
					continue;
				}
				
				if(matchLines.size()>0)
				{
					// Check for total line for line item
					boolean isTotalLineMatch=checkForTotalKeyWordLine(line,matchLines,lineItemSectionStr);
					if(isTotalLineMatch)
					{
						tempLines.addAll(matchLines);
						matchLines.add(line);
					}
					else
						tempLines.add(line);
				}
			}
		}
		
		if(matchLines.size()>0)
		{
			Row rw=new Row(0,matchLines);
			POBreakUps breakUps= new POBreakUps(rw);
			breakUps.setCoOrdinate(breakUps);
			String combinedStr=rw.getCombinedString();
			breakUps.setAsRepLabel(combinedStr);
			ret.add(breakUps);
		}
		else
		{
			Row rw=new Row(0,lines);
			POBreakUps breakUps= new POBreakUps(rw);
			breakUps.setCoOrdinate(breakUps);
			String combinedStr=rw.getCombinedString();
			breakUps.setAsRepLabel(combinedStr);
			ret.add(breakUps);
		}
		
		return ret;
	}
	
	private boolean checkForTotalKeyWordLine(PDFLine line, List<PDFLine> matchLines, String lineItemSectionStr) 
	{
		if(line.getLine().toLowerCase().contains("total"))
		{
			if(line.getLine().toLowerCase().contains(lineItemSectionStr.trim().toLowerCase()))
				return true;
		}
		return false;
	}

	public List<POBreakUps> preparePOBreakUpsFromHierarchyNode(HierarchyNode node) 
	{
		List<POBreakUps> ret = new ArrayList<POBreakUps>();
		
		POBreakUps breakUps= new  POBreakUps(node);
		breakUps.setCoOrdinate(breakUps);
		String nodeStr=node.getNode().getStringRepresentation();
		//System.out.println(nodeStr);
		breakUps.setAsRepLabel(node.getNode().getStringRepresentation());
		ret.add(breakUps);
		
		return ret;
	}

	private List<HierarchyNode> findMatchingHierarchyNodeWithLineItem(String lineItemSectionStr, HierarchyNode hierarchyNode) 
	{
		if(hierarchyNode==null || lineItemSectionStr==null || lineItemSectionStr.trim().equals(""))
			return null;
		List<HierarchyNode> ret=new ArrayList<HierarchyNode>();
		List<HierarchyNode> nodes=new ArrayList<HierarchyNode>();
		nodes.add(hierarchyNode);
		List<HierarchyNode> tempNodes=findMatchNodesWithTheString(nodes,lineItemSectionStr);
		ret.addAll(tempNodes);
		return ret;
	}

	private List<HierarchyNode> findMatchNodesWithTheString(List<HierarchyNode> nodes, String lineItemSectionStr) 
	{
		List<HierarchyNode> ret= new ArrayList<HierarchyNode>();
		if(nodes!=null && nodes.size()>0)
		{
			for(HierarchyNode node:nodes)
			{
				boolean isNodeMatch=isStringPresentInNode(node,lineItemSectionStr);
				if(isNodeMatch)
					ret.add(node);
				if(node.getChildren()!=null && node.getChildren().size()>0)
				{
					List<HierarchyNode> matchNodes= findMatchNodesWithTheString(node.getChildren(),lineItemSectionStr);
					if(matchNodes!=null && matchNodes.size()>0)
						ret.addAll(matchNodes);
				}
			}
		}
		return ret;
	}

	private boolean isStringPresentInNode(HierarchyNode node, String lineItemSectionStr) 
	{
		return AssociationsUtilities.isStringPresentInNode(node,lineItemSectionStr);
	}
}
