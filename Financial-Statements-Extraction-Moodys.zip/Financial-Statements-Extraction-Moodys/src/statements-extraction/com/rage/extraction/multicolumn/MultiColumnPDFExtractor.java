package com.rage.extraction.multicolumn;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.dp.pipeline.UpdatedCharacters;
import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.Section;
import com.rage.extraction.statements.db.DataWriterOracle;
import com.rage.extraction.statements.db.DataWriterSql;
import com.rage.extraction.statements.detectors.pdf.SectionBoundaryDetector;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.uitls.PDFDocumentLoader;

public class MultiColumnPDFExtractor 
{

	public List<Section> getMultiColumnDataFromSection(Section section,String fileName, DataWriterOracle dwOracle, DataWriterSql dwSql)
	{
		System.out.println("Multicolumn check for section pages starts");

		List<Section> ret= new ArrayList<Section>();
		Map<Integer,Pair<Float,Float>> pageNoMinMaxYMap= getPageWiseMinMaxYAxisMap(section);
		TreeMap<Integer, PageParse> pageParserMap;
		try {
			Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap = UpdatedCharacters.getCharactersMap(fileName,new ArrayList<Integer>(pageNoMinMaxYMap.keySet()) ); 
			Map<Integer,List<PDFCharacter>> pageWiseCharMap1=convertNativePDFCharToLocal(pageWiseCharMap);
			pageParserMap = PDFDocumentLoader.createPageParsePageWise(pageWiseCharMap1,true);
			if(pageNoMinMaxYMap.size()!=pageParserMap.size())
			{
				if(FinancialStatementExtractor.getReprocess().equalsIgnoreCase("Yes"))
				{
					pageParserMap = PDFDocumentLoader.createPageParsePageWisePageNos(pageWiseCharMap1,true);
					ret = SectionBoundaryDetector.detectSectionReprocessBoundaries(pageParserMap, dwOracle, dwSql); ;
				}
				else
				{
					ret = SectionBoundaryDetector.detectSectionBoundaries(pageParserMap) ;
				}
			}
			else
			{
				ret.add(section);
			}
		} catch (Exception e) {
			System.out.println("Exception during multicolumn");
			ret.add(section);
			System.out.println(e.getMessage());
			System.out.println(e.getStackTrace());
		}
		System.out.println("Multicolumn check for section pages ends");
			
		//Section retSection=prepareSectionBasedOnMultiColOutput(pageParserMap,section,pageNoMinMaxYMap);
		return ret;
		
	}

	private Map<Integer, Pair<Float, Float>> getPageWiseMinMaxYAxisMap(Section section) 
	{
		Map<Integer, Pair<Float, Float>> ret= new TreeMap<Integer, Pair<Float, Float>>();
		List<PDFBlock> blocks=section.getBlocks();
		List<PDFLine> lines=section.getLines();
		
		
		for(PDFBlock block:blocks)
		{
			Integer pageNo=block.getPageNo();
			float y1=block.getY1();
			float y2=block.getY2();
			if(ret.containsKey(pageNo))
			{
				Pair<Float,Float> yCoordinatesPair=ret.get(pageNo);
				float newY1=0.0f;
				float newY2=0.0f;
				
				if(yCoordinatesPair.getA()<y1)
					newY1=yCoordinatesPair.getA();
				else
					newY1=y1;
				
				if(yCoordinatesPair.getB()>y2)
					newY2=yCoordinatesPair.getB();
				else
					newY2=y2;
				
				ret.put(pageNo, new Pair<Float,Float>(newY1,newY2));
				
			}
			else
			{
				ret.put(pageNo, new Pair<Float,Float>(y1,y2));
			}
		}
		
		for(PDFLine line:lines)
		{
			Integer pageNo=line.getPageNo();
			float y1=line.getY1();
			float y2=line.getY2();
			if(ret.containsKey(pageNo))
			{
				Pair<Float,Float> yCoordinatesPair=ret.get(pageNo);
				float newY1=0.0f;
				float newY2=0.0f;
				
				if(yCoordinatesPair.getA()<y1)
					newY1=yCoordinatesPair.getA();
				else
					newY1=y1;
				
				if(yCoordinatesPair.getB()>y2)
					newY2=yCoordinatesPair.getB();
				else
					newY2=y2;
				
				ret.put(pageNo, new Pair<Float,Float>(newY1,newY2));
				
			}
			else
			{
				ret.put(pageNo, new Pair<Float,Float>(y1,y2));
			}
		}
		
		return ret;
	}

	private Section prepareSectionBasedOnMultiColOutput(Map<Integer, PageParse> pageParserMap, Section section, Map<Integer, Pair<Float, Float>> pageNoMinMaxYMap) 
	{
		List<PDFLine> secLines= new ArrayList<PDFLine>();
		List<PDFBlock> secBlocks= new ArrayList<PDFBlock>();
		for(Integer colNo:pageParserMap.keySet())
		{
			PageParse pp=pageParserMap.get(colNo);
			List<PDFLine> lines=pp.getPageLines();
			List<PDFBlock> blocks=pp.getPageBlocks();
			for(PDFLine line:lines)
			{
				Pair<Float, Float> yCoordinates=pageNoMinMaxYMap.get(line.getPageNo());
				if(yCoordinates!=null && line.getY1()<yCoordinates.getB() && line.getY2()>yCoordinates.getA())
					secLines.add(line);
			}
			
			for(PDFBlock block:blocks)
			{
				Pair<Float, Float> yCoordinates=pageNoMinMaxYMap.get(block.getPageNo());
				if(yCoordinates!=null && block.getY1()<yCoordinates.getB() && block.getY2()>yCoordinates.getA())
					secBlocks.add(block);
			}
		}
		Section retSection= new Section(section.getSectionName(),secLines,section.getKeyword(),section.getInstanceID(),secBlocks);
		return retSection;
	}

	private static Map<Integer, List<PDFCharacter>> convertNativePDFCharToLocal (
			Map<Integer, List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap )
	{
		Map<Integer, List<PDFCharacter>> ret= new TreeMap<Integer, List<PDFCharacter>>(); 
		for(Integer pgNo:pageWiseCharMap.keySet())
		{
			List<com.dp.nda.pdf.beans.PDFCharacter> lst=pageWiseCharMap.get(pgNo);
			
			for(com.dp.nda.pdf.beans.PDFCharacter pdfCr:lst)
			{
				if(ret.containsKey(pgNo))
				{
					
					PDFCharacter pdfChar=getLocalPDFCharacterFromNative(pdfCr,pgNo); 
					ret.get(pgNo).add(pdfChar);		
				}
				else
				{
					PDFCharacter pdfChar= getLocalPDFCharacterFromNative(pdfCr,pgNo);
					List<PDFCharacter> charList= new ArrayList<PDFCharacter>();
					charList.add(pdfChar);
					ret.put(pgNo, charList);
				}
			}
		}
		
		return ret;
	}
	
	private static PDFCharacter getLocalPDFCharacterFromNative ( com.dp.nda.pdf.beans.PDFCharacter pdfCr, Integer pgNo )
	{
		PDFCharacter pdfChar= new PDFCharacter(pgNo,pdfCr.getRectangle().getX(),pdfCr.getRectangle().getX2()
				,pdfCr.getRectangle().getY2(),pdfCr.getRectangle().getY(),pdfCr.getStringRepresentation(),pdfCr.getFontName()
				,pdfCr.getFontFamily(),pdfCr.getFontSize(),pdfCr.getFontSizeInPt(),pdfCr.getWidthOfSpace(),pdfCr.isBold()
				,pdfCr.isItalic(),pdfCr.getMultiColumnIndex(),pdfCr.getRectangle().getWidth(),pdfCr.getRectangle().getHeight());

		return pdfChar;
	}
}
