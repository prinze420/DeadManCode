package com.rage.extraction.multicolumn;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.dp.pipeline.UpdatedCharacters;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.parse.PageParse;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.uitls.PDFDocumentLoader;

public class MultiColumnTester
{

	
	public static void main(String[] args) throws IOException 
	{
		List<String> files= new ArrayList<String>();
		
		String folder= "C:/Users/sm0e1016/Desktop/Financial_statement_extraction/footnotes_test/foot_note_test_1/";
	//	String folder= "C:/Users/sm0e1016/Desktop/Financial_statement_extraction/English/multi_Col/";
		files=getFilesList(folder);
		for(int i=0;i<files.size();i++)
		{
			String fileName=files.get(i);
			try
			{
				System.gc();
				BufferedWriter writer = null;
				TreeMap<Integer, PageParse> pageParsesMap;
				
				long startTime = System.currentTimeMillis();
				long endTime;
				Map<Integer,List<com.dp.nda.pdf.beans.PDFCharacter>> pageWiseCharMap = UpdatedCharacters.getCharactersMap(fileName,new ArrayList<Integer>());
				String outFileName=fileName.replace(".pdf", ".txt");
				writer = new BufferedWriter( new FileWriter( outFileName));
				Map<Integer,List<PDFCharacter>> pageWiseCharMap1=FinancialStatementExtractor.convertNativePDFCharToLocal(pageWiseCharMap);
					
				pageParsesMap = PDFDocumentLoader.loadDocument(pageWiseCharMap1,true) ;
				
				for(Integer pgNo:pageParsesMap.keySet())
				{
					PageParse pp=pageParsesMap.get(pgNo);
					List<PDFLine> lines=pp.getPageLines();
					String linesText="";
					if(lines==null || lines.isEmpty())
						continue;
					linesText=linesText+"\n\n"+"PageNO=="+lines.get(0).getPageNo();
					for(PDFLine line:lines)
					{
						linesText=linesText+"\n"+line;
					}
					try
					{
					    writer.write( linesText);
					}
					catch ( IOException e)
					{
					}
				}
				endTime = System.currentTimeMillis();
	
				writer.write("\n\n\nTotal time taken: "+((endTime-startTime)/1000.)+" seconds.");
	
				writer.close();
			}
			catch(Exception e)
			{
				System.out.println("Error in File"+fileName);
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		
	}
	
	public static List<String> getFilesList(String folderPath)
	{
		List<String> ret= new ArrayList<String>();
		File folder = new File(folderPath);
		File[] listOfFiles = folder.listFiles();

		    for (int i = 0; i < listOfFiles.length; i++) 
		    {
		      if (listOfFiles[i].isFile()) 
		      {
		    	  if(listOfFiles[i].getAbsolutePath().endsWith(".pdf"))
		    	  {
		    		  ret.add(listOfFiles[i].getAbsolutePath());
		    	  }
		      } 
		      else if (listOfFiles[i].isDirectory()) 
		      {
		       // System.out.println("Directory " + listOfFiles[i].getName());
		      }
		    }
		    return ret;
	}
}
