package com.rage.extraction.test;

import java.util.List;
import java.util.Vector;

import com.gyan.siapp.tools.sentdetect.SentenceBoundaryDetector;
import com.gyan.siapp.utils.Triplet;
import com.rage.footnote.extraction.FootnoteExtraction;

public class TestFootNoteExtraction 
{
	public static void main(String[] args) 
	{

		String sentence = "The Company held common stocks of subsidiaries and affiliates for which the transfer_of_ownership was restricted by contractual requirements with carrying values of $ 461 million as of December 31 , 2013 and $ 23 million as of December 31 , 2012 .";
		Vector<String> sentences = SentenceBoundaryDetector.detectSentenceBoundary(sentence);
		for(String sentence1 : sentences)
		{
			List<Triplet<String, String, String>> triplets = FootnoteExtraction.extractFootnote(sentence1);
			for(Triplet<String,String,String> triplet : triplets)
			{
				System.out.println("op=="+triplet);
				
			}
		}
		
		
	}
}
