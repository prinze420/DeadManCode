package com.rage.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;

class CharacterLinesCreater 
{
	private static Boolean INTERNAL_DEBUG = Boolean.FALSE ;
	private static Boolean REMOVE_SAME_CHARATER_LINE_DEBUG = Boolean.FALSE ;

	private static HashSet<String> GARBAGE_CHARACTER_SET = new HashSet<String>(Arrays.asList(new String[] {"m", "i"})) ;

	private List<PDFCharacter> characters ;
	private List<List<PDFCharacter>> characterLines ;

	CharacterLinesCreater(List<PDFCharacter> characters)
	{
		setCharacters(characters) ;
		setCharacterLines(new ArrayList<List<PDFCharacter>>()) ;
	}

	void run()
	{
		List<List<PDFCharacter>> characterLines = new ArrayList<List<PDFCharacter>>() ;
		List<PDFCharacter> lineLowestCharacter = new ArrayList<PDFCharacter>() ;



		createLinesOnY2(characterLines, lineLowestCharacter) ;
		characterLines = sortLinesOnY2(characterLines, lineLowestCharacter) ;
		characterLines = cleanupOverlappingCharacters(characterLines) ;
		characterLines = cleanupAllSameCharacter(characterLines) ;
		characterLines = cleanupMultipleCharacters(characterLines) ;
		characterLines = cleanupSuperScripts(characterLines) ;
		characterLines = cleanupGarbageLines(characterLines) ;
		characterLines = markSuperScriptsCharacters(characterLines);
		
		if ( INTERNAL_DEBUG )
		{
			for ( int i=0 ; i<characterLines.size() ; i++ )
			{
				List<PDFCharacter> line = characterLines.get(i) ;

				//				System.out.println("\n\nLINE " + i + " : ") ;
				for ( int j=0 ; j<line.size() ; j++ )
				{
					System.out.println("\t" + j + " : " + line.get(j).toCompleteString()) ;
				}
			}
		}

		setCharacterLines(characterLines) ;
	}

	private List<List<PDFCharacter>> markSuperScriptsCharacters(List<List<PDFCharacter>> characterLines2) {
		List<List<PDFCharacter>> ret= new ArrayList<List<PDFCharacter>>();
		List<PDFCharacter> prevLine=null;
		for(int i=0;i<characterLines2.size();i++)
		{
			List<PDFCharacter> line=characterLines2.get(i);
			if(prevLine!=null)
			{
				PDFWord prevWord= new PDFWord(prevLine.get(0).getPageNo(), prevLine);
				PDFWord thisWord= new PDFWord(line.get(0).getPageNo(), line);
				boolean isLineAdded=false;
				if(prevWord.getY1()<thisWord.getY2() && prevWord.getY2()>thisWord.getY1() )
				{
					String word=prevWord.getWord();
					String[] wordSplit=word.split(",");
					boolean isEnum=false;
					
					for(String enumeration:wordSplit)
					{
						if(isEnumeration(enumeration.trim()))
						{
							isEnum=true;
							continue;
						}
						isEnum=false;
						ret.add(line);
						isLineAdded=true;
						break;
					}
					if(isEnum && prevLine.size()<5)
					{
						System.out.println("Super Script Identified");
						if(ret.size()>0)
							ret.remove(ret.size()-1);
						line.addAll(prevLine);
						Comparator<PDFCharacter> cmp= new Comparator<PDFCharacter>() {

							@Override
							public int compare(PDFCharacter c1, PDFCharacter c2) 
							{
								if(c1.getX1()>c2.getX1())
									return 1;
								else if(c1.getX1()<c2.getX1())
									return -1;
								else
									return 0;
								
							}
							
						};
						
						Collections.sort(line,cmp);
						isLineAdded=true;
						ret.add(line);
					}
					else 
					{
						if(isLineAdded)
							ret.add(line);
					}
				}
				else
					ret.add(line);
			}
			else
				ret.add(line);

		prevLine=line;
		}
		return ret;
	}

	private boolean isEnumeration(String enumStr) 
	{
		if(enumStr==null || enumStr.trim().equals(""))
			return false;
		// Number
		Pattern p=Pattern.compile("(\\d+)|((\\()?(\\s+)?\\d+(\\s+)?\\))|(\\d+\\.)");
		// Alphabet
		Pattern p1=Pattern.compile("((\\()?(\\s+)?[a-h](\\s+)?\\))|([a-h]\\.)");
		// Roman
		Pattern p2=Pattern.compile("((\\()?(\\s+)?(i|ii|iii|iv|v|vi)(\\s+)?\\))|((i|ii|iii|iv|v|vi)\\.)",Pattern.CASE_INSENSITIVE);
		Matcher m=p.matcher(enumStr);
		if(m.matches())
			return true;
		m=p1.matcher(enumStr);
		if(m.matches())
			return true;
		m=p2.matcher(enumStr);
		if(m.matches())
			return true;
		return false;
	}

	private List<List<PDFCharacter>> cleanupGarbageLines(List<List<PDFCharacter>> characterLines) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			String strLine = "" ;

			for ( int j=0 ; j<line.size() ; j++ )
			{
				PDFCharacter character = line.get(j) ;
				strLine = strLine.trim() + character.toString() ;
			}

			if ( isLineGarbage(strLine) )
				continue ;

			ret.add(line) ;
		}

		return ret ;
	}

	private boolean isLineGarbage(String line)
	{
		String cleanString = "" ;
		StringTokenizer st = new StringTokenizer(line, "~`!@#$%^&*()_+-={}[]|\\:;\"'<>?,./ ") ;
		while ( st.hasMoreTokens() )
			cleanString = cleanString.trim() + st.nextToken() ;

		if ( cleanString.length() == 0 ) 
			return true ;

		return false;
	}

	private List<List<PDFCharacter>> cleanupSuperScripts(List<List<PDFCharacter>> characterLines) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			/*if ( line.size()!=2 )
			{
				ret.add(line) ;
				continue ;
			}*/

			String str = "" ;
			for ( int j=0 ; j<line.size() ; j++ )
			{
				PDFCharacter character = line.get(j) ;
				str = str.trim() + character.getCharacter() ;
			}

			str = str.trim() ;


			if ( str.equals("th") || str.equals("st") || str.equals("rd") )
				continue ;

			ret.add(line) ;
		}

		return ret ;
	}

	private List<List<PDFCharacter>> cleanupMultipleCharacters(List<List<PDFCharacter>> characterLines) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			List<Pair<Integer, Integer>> sameCharacterRange = findSameCharactersRange(line) ;
			List<PDFCharacter> cleanedLine = cleanLine(line, sameCharacterRange) ;
			ret.add(cleanedLine) ;
		}

		return ret ;
	}

	private List<PDFCharacter> cleanLine(List<PDFCharacter> line, List<Pair<Integer, Integer>> sameCharacterRange) 
	{
		List<PDFCharacter> ret = new ArrayList<PDFCharacter>() ;

		for ( int i=0 ; i<line.size() ; i++ )
		{
			Integer index = i ;
			Pair<Integer, Integer> pair = null ;
			for ( int j=0 ; j<sameCharacterRange.size() ; j++ )
			{
				Pair<Integer, Integer> thisPair = sameCharacterRange.get(j) ;
				if ( thisPair.getA().intValue() == index )
				{
					pair = thisPair ;
					break ;
				}
			}

			if ( pair == null )
			{
				ret.add(line.get(i)) ;
				continue ;
			}

			i = pair.getB().intValue() ;
		}

		return ret ;
	}

	private List<Pair<Integer, Integer>> findSameCharactersRange(List<PDFCharacter> line) 
	{
		List<Pair<Integer, Integer>> ret = new ArrayList<Pair<Integer,Integer>>() ;

		PDFCharacter prevPrevPrevCharacter = null ;
		PDFCharacter prevPrevCharacter = null ;
		PDFCharacter prevCharacter = null ;
		Integer startIndex = -1 ;
		for ( int i=0 ; i<line.size() ; i++ )
		{
			PDFCharacter thisCharacter = line.get(i) ;
			if ( prevCharacter == null )
			{
				prevCharacter = thisCharacter ;
				continue ;
			}

			if ( prevPrevCharacter == null )
			{
				prevPrevCharacter = prevCharacter ;
				prevCharacter = thisCharacter ;
				continue ;
			}

			if ( prevPrevPrevCharacter == null )
			{
				prevPrevPrevCharacter = prevPrevCharacter ;
				prevPrevCharacter = prevCharacter ;
				prevCharacter = thisCharacter ;
				continue ;
			}

			if ( ! (prevCharacter.getCharacter().equalsIgnoreCase(prevPrevCharacter.getCharacter()) 
					&& prevCharacter.getCharacter().equalsIgnoreCase(thisCharacter.getCharacter())
					&& prevPrevCharacter.getCharacter().equalsIgnoreCase(prevPrevPrevCharacter.getCharacter())
					&& GARBAGE_CHARACTER_SET.contains(prevCharacter.getCharacter())) )
			{
				if ( startIndex != -1 )
				{
					Pair<Integer, Integer> pair = new Pair<Integer, Integer>(new Integer(startIndex), new Integer(i-1)) ;
					ret.add(pair) ;

					startIndex = -1 ;
				}

				prevPrevCharacter = prevCharacter ;
				prevCharacter = thisCharacter ;
				continue ;
			}
			else if ( prevCharacter.getCharacter().equalsIgnoreCase(prevPrevCharacter.getCharacter()) && prevCharacter.getCharacter().equalsIgnoreCase(thisCharacter.getCharacter()) )
			{
				if ( startIndex == -1 )
					startIndex = line.indexOf(prevPrevCharacter) ;
			}

			prevPrevCharacter = prevCharacter ;
			prevCharacter = thisCharacter ;
			continue ;
		}

		return ret ;
	}

	private List<List<PDFCharacter>> cleanupAllSameCharacter(List<List<PDFCharacter>> characterLines) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			if ( areAllCharactersInLineSame(line) )
			{
				if ( REMOVE_SAME_CHARATER_LINE_DEBUG )
					System.out.println("Leaving line: " + line) ;

				continue ;
			}
			ret.add(line) ;
		}

		return ret ;
	}

	private boolean areAllCharactersInLineSame(List<PDFCharacter> line) 
	{
		boolean ret = false ;

		HashSet<String> set = new HashSet<String>() ;
		for ( int i=0 ; i<line.size() ; i++ )
		{
			PDFCharacter character = line.get(i) ;
			String strCharacter = character.getCharacter() ;

			if ( strCharacter.trim().equalsIgnoreCase("") )
				continue ;

			set.add(strCharacter) ;
		}

		ret = set.size() == 1 ? true : false ;

		if ( ret && line.size() <= 4 )
		{
			if ( REMOVE_SAME_CHARATER_LINE_DEBUG )
				System.out.println("Line size less than 4 ...") ;

			String character = new ArrayList<String>(set).get(0) ;

			if ( REMOVE_SAME_CHARATER_LINE_DEBUG )
				System.out.println("\tCharacter = " + character) ;

			if ( !GARBAGE_CHARACTER_SET.contains(character) )
				ret = false ;
		}
		else if ( ret && line.size() > 4 )
		{
			if ( REMOVE_SAME_CHARATER_LINE_DEBUG )
				System.out.println("Line size greater than 4 ...") ;

			String character = new ArrayList<String>(set).get(0) ;

			if ( REMOVE_SAME_CHARATER_LINE_DEBUG )
				System.out.println("\tCharacter = " + character) ;

			if ( !character.trim().equalsIgnoreCase("") && character.replaceAll("[a-zA-Z0-9]", "").trim().equalsIgnoreCase("") )
				ret = false ;
		}

		return ret ;
	}

	private List<List<PDFCharacter>> cleanupOverlappingCharacters(List<List<PDFCharacter>> characterLines) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			List<PDFCharacter> cleanedLine = cleanOverlappingSameCharacters(line) ;
			ret.add(cleanedLine) ;
		}

		return ret ;
	}

	private List<PDFCharacter> cleanOverlappingSameCharacters(List<PDFCharacter> thisLine) 
	{
		Vector<PDFCharacter> ret = new Vector<PDFCharacter>() ;

		PDFCharacter prevCharacter = null ;
		for ( int i=0 ; i<thisLine.size() ; i++ )
		{
			PDFCharacter thisCharacter = thisLine.get(i) ;

			if ( prevCharacter == null )
			{
				prevCharacter = thisCharacter ;
				ret.addElement(thisCharacter) ;

				continue ;
			}

			if ( !prevCharacter.getCharacter().trim().equalsIgnoreCase(thisCharacter.getCharacter().trim()) )
			{
				if ( thisCharacter.getCharacter().trim().equalsIgnoreCase("") && isCompleteOverlap(prevCharacter, thisCharacter) )
				{
					prevCharacter = thisCharacter ;
					continue ;
				}

				prevCharacter = thisCharacter ;
				ret.addElement(thisCharacter) ;

				continue ;
			}

			if ( isCompleteOverlap(prevCharacter, thisCharacter) )
			{
				prevCharacter = thisCharacter ;
				continue ;
			}

			prevCharacter = thisCharacter ;
			ret.addElement(thisCharacter) ;
		}

		return ret ;
	}

	private boolean isCompleteOverlap(PDFCharacter prevCharacter, PDFCharacter character) 
	{
		if ( character.getX1() <= prevCharacter.getMidX() )
			return true ;


		/*if ( character.getX1() >= prevCharacter.getX1() && character.getX1() <= prevCharacter.getMidX() 
					&& character.getY1() >= prevCharacter.getY1() && character.getY1() <= prevCharacter.getMidY() )
				return true ;*/


		return false ;
	}

	private boolean isSuperScript(PDFCharacter prevCharacter, PDFCharacter character) 
	{/*
		if ( character.getX1() <= prevCharacter.getMidX() )
			return true ;*/


		if ( character.getX1() >= prevCharacter.getX1() && character.getX1() <= prevCharacter.getMidX() 
				&& character.getY1() >= prevCharacter.getY1() && character.getY1() <= prevCharacter.getMidY() )
			return true ;


		return false ;
	}

	private List<List<PDFCharacter>> sortLinesOnY2(List<List<PDFCharacter>> characterLines, List<PDFCharacter> lineLowestCharacter) 
	{
		List<YCharactersPair> pairs = new ArrayList<YCharactersPair>() ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			PDFCharacter lowestCharacter = lineLowestCharacter.get(i) ;

			YCharactersPair pair = new YCharactersPair(lowestCharacter.getY2(), line) ;
			pairs.add(pair) ;
		}

		YCharactersPair[] arr3 = pairs.toArray(new YCharactersPair[pairs.size()]) ;
		Arrays.sort(arr3) ;
		pairs = new ArrayList<YCharactersPair>(Arrays.asList(arr3)) ;

		characterLines = new ArrayList<List<PDFCharacter>>() ;
		for ( int i=0 ; i<pairs.size() ; i++ )
		{
			YCharactersPair pair = pairs.get(i) ;

			List<PDFCharacter> line = pair.getLine() ;

			PDFCharacter[] arr = line.toArray(new PDFCharacter[line.size()]) ;
			try
			{
				Arrays.sort(arr) ;
			}
			catch(Exception e)
			{

			}
			line = new ArrayList<PDFCharacter>(Arrays.asList(arr)) ;

			characterLines.add(line) ;
		}
		return characterLines;
	}

	private void createLinesOnY2(List<List<PDFCharacter>> characterLines, List<PDFCharacter> lineLowestCharacter) 
	{
		
		PDFCharacter prevCharacter = null;
		for ( int i=0 ; i<getCharacters().size() ; i++ )
		{
			PDFCharacter thisCharacter = getCharacters().get(i) ;
			if ( prevCharacter!=null  && thisCharacter!=null 
				&& thisCharacter.getY2() >= prevCharacter.getY1() && thisCharacter.getY2() <= prevCharacter.getMidY() ) 
			{
				thisCharacter.setY2(prevCharacter.getY2());
				//thisCharacter.setY1(prevCharacter.getY1());
				thisCharacter.setMidY(prevCharacter.getMidY());
			}
			if(!thisCharacter.toString().trim().equals("") && !thisCharacter.toString().trim().equals(".")  && !thisCharacter.toString().trim().equals(",")  )
			prevCharacter = thisCharacter;
		}
		
		for ( int i=0 ; i<getCharacters().size() ; i++ )
		{
			PDFCharacter thisCharacter = getCharacters().get(i) ;

			boolean found = false ;
			for ( int j=0 ; j<characterLines.size() ; j++ )
			{
				List<PDFCharacter> line = characterLines.get(j) ;

				PDFCharacter lowestCharacter = lineLowestCharacter.get(j) ;

				PDFCharacter lowerCharacter = thisCharacter.getY2() >  lowestCharacter.getY2() ? thisCharacter : lowestCharacter ;
				PDFCharacter upperCharacter = thisCharacter.getY2() <= lowestCharacter.getY2() ? thisCharacter : lowestCharacter ;

				float gap = lowerCharacter.getY2() - upperCharacter.getY2() ;
	
					if ( gap <= (lowerCharacter.getHeight()/2) )
					{					
						line.add(thisCharacter) ;
						lineLowestCharacter.set(j, lowerCharacter) ;

						found = true ;
					}
		
				if ( found )
					break ;
			}
			//if(!thisCharacter.getCharacter().trim().equalsIgnoreCase(""))
			//prevCharacter = thisCharacter;

			if ( found )
				continue ;

			

			List<PDFCharacter> newLine = new ArrayList<PDFCharacter>() ;
			newLine.add(thisCharacter) ;
			lineLowestCharacter.add(thisCharacter) ;
			
			characterLines.add(newLine) ;
		}
	}

	public List<PDFCharacter> getCharacters() {
		return characters;
	}

	public void setCharacters(List<PDFCharacter> characters) {
		this.characters = characters;
	}

	public List<List<PDFCharacter>> getCharacterLines() {
		return characterLines;
	}

	public void setCharacterLines(List<List<PDFCharacter>> characterLines) {
		this.characterLines = characterLines;
	}
}
