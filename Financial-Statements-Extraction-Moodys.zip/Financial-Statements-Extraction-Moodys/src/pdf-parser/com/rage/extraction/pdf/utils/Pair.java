package com.rage.extraction.pdf.utils;



public class Pair<A,B> implements Comparable<Pair<A,B>>
{
	private A a ;
	private B b ;
	
	public Pair(A a, B b)
	{
		setA(a) ;
		setB(b) ;
	}

	@Override
	public String toString() 
	{
		return "[" + getA() + ", " + getB() + "]" ;
	}
	
	public A getA() {
		return a;
	}

	public void setA(A a) {
		this.a = a;
	}

	public B getB() {
		return b;
	}

	public void setB(B b) {
		this.b = b;
	}
	
	public int compareTo(Pair<A, B> o) {
		if (o.getA() instanceof Float && o.getB() instanceof Float) {
				Float a1 = (Float)getA();
				Float a2 = (Float)o.getA();
				if (a1>a2)
					return 1;
				else if (a1<a2)
					return -1;
			
		}
		return 0;

	}
}
