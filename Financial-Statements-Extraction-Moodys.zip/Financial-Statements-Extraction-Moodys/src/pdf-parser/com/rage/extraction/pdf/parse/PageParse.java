package com.rage.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDPage;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;

public class PageParse 
{
	private Integer pageNo ;
	private List<PDFBlock> pageBlocks ;
	private List<PDFLine> pageLines ;
	private List<List<PDFChunk>> pageLineChunks ;
	private List<List<PDFWord>> pageLineWords ;
	private PDPage page;
	PageParse(Integer pageNo, PDPage page)
	{
		setPageNo(pageNo) ;
		
		setPageBlocks(new ArrayList<PDFBlock>()) ;
		setPageLines(new ArrayList<PDFLine>()) ;
		setPageLineChunks(new ArrayList<List<PDFChunk>>()) ;
		setPageLineWords(new ArrayList<List<PDFWord>>()) ;
		setPage(page);
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((pageBlocks == null) ? 0 : pageBlocks.hashCode()) ;
		result = prime * result + ((pageLineChunks == null) ? 0 : pageLineChunks.hashCode()) ;
		result = prime * result + ((pageLineWords == null) ? 0 : pageLineWords.hashCode()) ;
		result = prime * result + ((pageLines == null) ? 0 : pageLines.hashCode()) ;
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode()) ;
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PageParse other = (PageParse) obj;
		if (pageBlocks == null) {
			if (other.pageBlocks != null)
				return false;
		} else if (!pageBlocks.equals(other.pageBlocks))
			return false;
		if (pageLineChunks == null) {
			if (other.pageLineChunks != null)
				return false;
		} else if (!pageLineChunks.equals(other.pageLineChunks))
			return false;
		if (pageLineWords == null) {
			if (other.pageLineWords != null)
				return false;
		} else if (!pageLineWords.equals(other.pageLineWords))
			return false;
		if (pageLines == null) {
			if (other.pageLines != null)
				return false;
		} else if (!pageLines.equals(other.pageLines))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		return true;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public List<PDFBlock> getPageBlocks() {
		return pageBlocks;
	}

	public void setPageBlocks(List<PDFBlock> pageBlocks) {
		this.pageBlocks = pageBlocks;
	}

	public List<PDFLine> getPageLines() {
		return pageLines;
	}

	public void setPageLines(List<PDFLine> pageLines) {
		this.pageLines = pageLines;
	}

	public List<List<PDFChunk>> getPageLineChunks() {
		return pageLineChunks;
	}

	public void setPageLineChunks(List<List<PDFChunk>> pageLineChunks) {
		this.pageLineChunks = pageLineChunks;
	}

	public List<List<PDFWord>> getPageLineWords() {
		return pageLineWords;
	}

	public void setPageLineWords(List<List<PDFWord>> pageLineWords) {
		this.pageLineWords = pageLineWords;
	}

	public static void main(String[] args) 
	{
		
	}

	public PDPage getPage() {
		return page;
	}

	public void setPage(PDPage page) {
		this.page = page;
	}

	
}
