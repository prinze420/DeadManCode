package com.rage.extraction.pdf.parse;

import java.util.List;

import com.rage.extraction.pdf.PDFCharacter;

class YCharactersPair implements Comparable<YCharactersPair>
{
	private float y1 ;
	private List<PDFCharacter> line ;
	
	YCharactersPair(float y1, List<PDFCharacter> line)
	{
		setY1(y1) ;
		setLine(line) ;
	}
	
	@Override
	public int compareTo(YCharactersPair other) 
	{
		if ( getY1() != other.getY1() )
			return new Float(getY1()).compareTo(new Float(other.getY1())) ;
		
		return 0;
	}

	public float getY1() {
		return y1;
	}

	public void setY1(float y1) {
		this.y1 = y1;
	}

	public List<PDFCharacter> getLine() {
		return line;
	}

	public void setLine(List<PDFCharacter> line) {
		this.line = line;
	}
}
