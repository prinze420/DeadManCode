package com.rage.extraction.pdf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.pdf.utils.PDFBoundedObjectUtils;

public class PDFBlock extends PDFBoundedObject implements Serializable
{
	private static final long serialVersionUID = 5040351415977507843L;
	private Integer pageNo ;
	private List<PDFLine> lines ;
	private String block ;
	private Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap ;
	
	public PDFBlock(Integer pageNo, List<PDFLine> lines)
	{
		setPageNo(pageNo) ;
		setLines(lines) ;
		setBounds("PDF-BLOCK", PDFBoundedObjectUtils.findBoundingRectangle(getLines())) ;
		setBlock(createStringFromLines(getLines())) ;
		setFontSizeCharactersMap(createFontSizeCharactersMap(getLines())) ;
	}
	
	public PDFBlock()
	{
		lines=new ArrayList<PDFLine>();
	}
	
// TODO Remove unused code found by UCDetector
// 	public void addLine(PDFLine pdfLine){
// 		if(lines==null)
// 			lines=new ArrayList<PDFLine>();
// 		lines.add(pdfLine);
// 		setBounds("PDF-BLOCK", PDFBoundedObjectUtils.findBoundingRectangle(getLines())) ;
// 		setBlock(createStringFromLines(getLines())) ;
// 		setFontSizeCharactersMap(createFontSizeCharactersMap(getLines())) ;
// 	}
	
	// added by Kiran 10th Sept 2014 to merge all table paragraphs into one paragraph
// TODO Remove unused code found by UCDetector
// 	public void addLines(List<PDFLine> pdfLines){
// 		if(lines==null)
// 			lines=new ArrayList<PDFLine>();
// 		lines.addAll(pdfLines);
// 		setBounds("PDF-BLOCK", PDFBoundedObjectUtils.findBoundingRectangle(getLines())) ;
// 		setBlock(createStringFromLines(getLines())) ;
// 		setFontSizeCharactersMap(createFontSizeCharactersMap(getLines())) ;
// 	}
	
// TODO Remove unused code found by UCDetector
// 	public void setParameters()
// 	{
// 		setBounds("PDF-BLOCK", PDFBoundedObjectUtils.findBoundingRectangle(getLines())) ;
// 		setBlock(createStringFromLines(getLines())) ;
// 		setFontSizeCharactersMap(createFontSizeCharactersMap(getLines())) ;
// 	}
	
	
	public String getBlockString()
	{
		String ret = "" ;
		
		for ( int i=0 ; i<getLines().size() ; i++ )
		{
			PDFLine line = getLines().get(i) ;
			ret = ret.trim() + " " + line.getLine() ;
		}
		
		return ret ;
	}
	
	private static Map<String, Map<Float, List<PDFCharacter>>> createFontSizeCharactersMap(List<PDFLine> lines) 
	{
		Map<String, Map<Float, List<PDFCharacter>>> map = new HashMap<String, Map<Float,List<PDFCharacter>>>() ;
		
		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			
			Map<String, Map<Float, List<PDFCharacter>>> lineMap = line.getFontSizeCharactersMap() ;
			
			for ( String font : lineMap.keySet() )
			{
				Map<Float, List<PDFCharacter>> lineSubMap = lineMap.get(font) ;
				Map<Float, List<PDFCharacter>> subMap = map.containsKey(font) ? map.get(font) : new HashMap<Float, List<PDFCharacter>>() ;
				
				for ( Float size : lineSubMap.keySet() )
				{
					List<PDFCharacter> lineList = lineSubMap.get(size) ;
					
					List<PDFCharacter> list = subMap.containsKey(size) ? subMap.get(size) : new ArrayList<PDFCharacter>() ;
					list.addAll(lineList) ;
					
					subMap.put(size, list) ;
				}
				
				map.put(font, subMap) ;
			}
		}
		
		return map ;
	}
	
	private static String createStringFromLines(List<PDFLine> lines) 
	{
		String ret = "" ;
		
		float indent = 0.0f ;
		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			if ( i==0 )
				indent = line.getX1() ;
			
			String strLine = line.getLine() ;
			
			ret = ret + (ret.trim().equalsIgnoreCase("") || ret.trim().endsWith(" =====") ? "" : " ===== ") + strLine ;
		}
		
		ret = indent + "\t" + ret.trim() ;
		
		return ret.trim() ;
	}

	@Override
	public String toString() 
	{
		return getBlock() ;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((block == null) ? 0 : block.hashCode());
		result = prime
				* result
				+ ((fontSizeCharactersMap == null) ? 0 : fontSizeCharactersMap
						.hashCode());
		result = prime * result + ((lines == null) ? 0 : lines.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFBlock other = (PDFBlock) obj;
		if (block == null) {
			if (other.block != null)
				return false;
		} else if (!block.equals(other.block))
			return false;
		if (fontSizeCharactersMap == null) {
			if (other.fontSizeCharactersMap != null)
				return false;
		} else if (!fontSizeCharactersMap.equals(other.fontSizeCharactersMap))
			return false;
		if (lines == null) {
			if (other.lines != null)
				return false;
		} else if (!lines.equals(other.lines))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		return true;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public String getBlock() {
		return block;
	}

	public void setBlock(String block) {
		this.block = block;
	}

	public Map<String, Map<Float, List<PDFCharacter>>> getFontSizeCharactersMap() {
		return fontSizeCharactersMap;
	}

	public void setFontSizeCharactersMap(
			Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap) {
		this.fontSizeCharactersMap = fontSizeCharactersMap;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
