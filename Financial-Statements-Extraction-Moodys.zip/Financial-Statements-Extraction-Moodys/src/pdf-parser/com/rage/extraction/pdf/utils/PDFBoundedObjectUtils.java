package com.rage.extraction.pdf.utils;

import java.util.ArrayList;
import java.util.List;

import com.rage.extraction.pdf.PDFBoundedObject;

public class PDFBoundedObjectUtils 
{
	public static List<Float> findBoundingRectangle(List<? extends PDFBoundedObject> boundedObjects)
	{
		float x1 = Float.MAX_VALUE ;
		float x2 = Float.MIN_VALUE ;
		float y1 = Float.MAX_VALUE ;
		float y2 = Float.MIN_VALUE ;
		
		for ( int i=0 ; i<boundedObjects.size() ; i++ )
		{
			PDFBoundedObject bo = boundedObjects.get(i) ;
			
			if ( x1 > bo.getX1() )
				x1 = bo.getX1() ;
			
			if ( y1 > bo.getY1() )
				y1 = bo.getY1() ;
			
			if ( x2 < bo.getX2() )
				x2 = bo.getX2() ;
			
			if ( y2 < bo.getY2() )
				y2 = bo.getY2() ;
		}
		
		List<Float> bounds = new ArrayList<Float>() ;
		bounds.add(x1) ;
		bounds.add(y1) ;
		bounds.add(x2) ;
		bounds.add(y2) ;
		
		return bounds ;
	}
}
