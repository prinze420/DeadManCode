package com.rage.extraction.pdf.parse;

import java.awt.Rectangle;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.TreeSet;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFFont;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;
import com.rage.table.data.DetectLines;

public class AdaptiveVerticalBlocksCreater 
{	
	private Integer pageNo ;
	private List<PDFLine> lines ;

	private List<List<PDFLine>> lineBlocks ;
	private List<PDFBlock> blocks ;
	private static Boolean DEBUG = Boolean.FALSE ;

	//private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(AdaptiveVerticalBlocksCreater.class);
	public AdaptiveVerticalBlocksCreater(Integer pageNo, List<PDFLine> lines)
	{
		setPageNo(pageNo) ;

		List<PDFLine> thisLines = new ArrayList<PDFLine>() ;
		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			if ( line.getLine().trim().equalsIgnoreCase("") )
				continue ;

			thisLines.add(line) ;
		}

		setLines(thisLines) ;

		setLineBlocks(new ArrayList<List<PDFLine>>()) ;
		setBlocks(new ArrayList<PDFBlock>()) ;
	}


	private List<List<PDFLine>> createVerticalBlocksChinese(String fileName) 
	{
		List<List<PDFLine>> groups = createDefaultBlocks(getLines()) ;

		if ( groups.size() == 1 )
			return groups ;

		List<List<PDFLine>> newGroups = new ArrayList<List<PDFLine>>() ;
		List<PDFLine> thisGroup = new ArrayList<PDFLine>() ;
		float minX1=0.0f;

		for ( int i=0 ; i<groups.size()-1 ; i++ )
		{
			List<PDFLine> thisBlock = groups.get(i) ;

			PDFLine thisLine = thisBlock.get(0) ;
			if(minX1==0.0f)
				minX1=thisLine.getX1();

			if(minX1>thisLine.getX1())
				minX1=thisLine.getX1();

		}

		Map<Integer, List<Rectangle>>CellsData = new LinkedHashMap<Integer, List<Rectangle>>();

		try
		{
			CellsData = DetectLines.Cells_Extraction(pageNo+1,  fileName);
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<Integer, Pair<Float, Float>>  lineDistanceMap = new LinkedHashMap<Integer, Pair<Float,Float>>();

		for(Integer index : CellsData.keySet())
		{
			List<Rectangle> table = CellsData.get(index); 

			for(int i=0;i<table.size();i++)
			{
				Rectangle rect = table.get(i);
				float y1 = (float)rect.getY();
				float y2 = (float) (y1+ rect.getHeight());

				Pair<Float, Float>  distanceRange = new Pair<Float, Float>(y1,y2);
				lineDistanceMap.put(index, distanceRange);
				break;
			}
		}

		// float distance = getMostRepeatedGapDistance(groups);
		// Pair<Float, Float> distanceRange = getMostRepeatedGapDistance1(groups) ;
		Pair<Float, Float> distanceRange = getMostRepeatedGapDistance1NonLatin(groups) ;
		System.out.println("Distance Range: " + distanceRange) ;

		Pair<Float, Float> tableDistanceRange = new Pair<Float, Float>(0.0f,0.0f);

		for ( int i=0 ; i<groups.size()-1 ; i++ )
		{
			List<PDFLine> thisBlock = groups.get(i) ;
			List<PDFLine> nextBlock = groups.get(i+1) ;

			PDFLine thisLine = thisBlock.get(0) ;
			PDFLine nextLine = nextBlock.get(0) ;
			PDFLine prevLine = null;
			PDFLine secondNextLine=null;
			if(i>0)
			{
				prevLine=groups.get(i-1).get(0);
			}
			if(i<groups.size()-2)
			{
				secondNextLine=groups.get(i+2).get(0);
			}


			/********************************/
			boolean inCurrentCell = false;
			boolean linesInTable = checkLinesScope(thisLine,nextLine,lineDistanceMap);
			if(linesInTable)
			{
				inCurrentCell = checkLineInCurrentCell(thisLine,nextLine,tableDistanceRange,lineDistanceMap);
			}
			/********************************/

			/*********create block if lines are in table*********/
			if(linesInTable)
			{
				if(inCurrentCell)
				{
					if ( !thisGroup.contains(thisLine) )
						thisGroup.add(thisLine) ;

					if ( !thisGroup.contains(nextLine) )
						thisGroup.add(nextLine) ;

					if ( DEBUG )
					{
						System.out.println("ADDING IN THE CURRENT GROUP .... ") ;
					}
					continue ;
				}else
				{
					if ( !thisGroup.contains(thisLine) )
						thisGroup.add(thisLine) ;

					if ( DEBUG )
					{
						System.out.println("CREATING NEW GROUP .... ") ;
					}

					newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

					thisGroup = new ArrayList<PDFLine>(nextBlock) ;

					continue ;
				}
			}
			/**************************************/

			if ( DEBUG )
			{
				System.out.println("\n\n") ;
				System.out.println("THIS LINE : " + thisLine.getLine()) ;
				System.out.println("NEXT LINE : " + nextLine.getLine()) ;
			}

			boolean isGapOK = isGapOK(thisLine, nextLine, prevLine , minX1, secondNextLine,distanceRange) ;

			/*new Changes*/
			if ( distanceRange.getB().floatValue() == 0.0f )
			{
				float gap = nextLine.getY1() - thisLine.getY2();
				if(gap <= 2.0f)
					isGapOK = true;
			}


			if ( DEBUG )
			{
				System.out.println("\tGAP : " + isGapOK) ;
			}

			// Non-Latin Characters should not be checked for Font Changes.
			boolean isFontOK = true ; // isFontValid(thisLine, nextLine) ;

			if ( DEBUG )
			{
				System.out.println("\tFONT : " + isFontOK) ;
			}

			boolean isLineOK = isLineNotCompletelySameCharacter(thisLine) || isLineNotCompletelySameCharacter(nextLine) ? true : false ;

			if ( DEBUG )
			{
				System.out.println("\tLINE : " + isLineOK) ;
			}
			boolean isIndentOK = true ; // isIndentSimilar(thisLine, nextLine, getLines()) ;
			if ( DEBUG )
			{
				System.out.println("\tINDENT : " + isIndentOK) ;
			}

			boolean isTabularDataOK = isTabularNumberOK(thisLine, thisGroup) ;
			isTabularDataOK = isTabularNumberOKNew(nextLine, thisGroup) ;
			if ( DEBUG )
			{
				System.out.println("\tTABULAR-CONDITION : " + isTabularDataOK) ;
				for ( PDFLine line : thisGroup )
					System.out.println("\t\t" + line.getLine()) ;
			}

			boolean closeGapOk = isGapCloseCompareToSecondNextLine(thisLine,nextLine,secondNextLine,thisGroup,distanceRange);
			if ( DEBUG )
			{
				System.out.println("\tClose Gap : " + closeGapOk) ;
			}

			boolean endsWithColon = isLineEndsWithColon(thisLine,nextLine);

			if ( !isLineOK )
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( DEBUG )
				{
					System.out.println("CREATING NEW GROUP .... ") ;
				}

				newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

				thisGroup = new ArrayList<PDFLine>(nextBlock) ;

			}
			else if ( (isGapOK && isFontOK && isIndentOK && isTabularDataOK && closeGapOk) && !(endsWithColon))
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( !thisGroup.contains(nextLine) )
					thisGroup.add(nextLine) ;

				if ( DEBUG )
				{
					System.out.println("ADDING IN THE CURRENT GROUP .... ") ;
				}

				continue ;
			}
			else
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( DEBUG )
				{
					System.out.println("CREATING NEW GROUP .... ") ;
				}

				newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

				thisGroup = new ArrayList<PDFLine>(nextBlock) ;

				continue ;
			}
		}

		if ( thisGroup.size() != 0 )
			newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

		groups = new ArrayList<List<PDFLine>>(newGroups) ;

		return groups;
	}


	private boolean isTabularNumberOKNew ( PDFLine thisLine, List<PDFLine> thisGroup )
	{
		List<PDFLine> group = new ArrayList<PDFLine>(thisGroup) ;
		//group.remove(thisLine) ;

		if ( group.size() == 0 )
			return true ;

		for ( PDFChunk thisChunk : thisLine.getChunks() )
		{
			if ( thisChunk.getChunk().trim().equalsIgnoreCase("") )
				continue ;

			if ( !thisChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
				continue ;

			for ( PDFLine groupLine : group )
			{
				for ( PDFChunk nextChunk : groupLine.getChunks() )
				{
					if ( nextChunk.getChunk().trim().equalsIgnoreCase("") 
							|| !nextChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
						continue ;

					if ( thisChunk.getX2() < nextChunk.getX1() || thisChunk.getX1() > nextChunk.getX2() )
						continue ;

					System.out.println("Selecting Chunks: " + thisChunk + "\t" + nextChunk) ;

					return false ;
				}
			}
		}

		return true ;
	}

	private boolean checkLinesScope ( PDFLine thisLine, PDFLine nextLine, Map<Integer, Pair<Float, Float>> lineDistanceMap )
	{

		Pair<Float,Float> pair = isLineInCell(thisLine,lineDistanceMap);

		if(pair.getA()>0.0f && pair.getB()>0.0f)
		{
			return true;
		}

		Pair<Float,Float> pair2 = isLineInCell(nextLine,lineDistanceMap);

		if(pair2.getA()>0.0f && pair2.getB()>0.0f)
		{
			return true;
		}


		return false;
	}


	private Pair<Float, Float> isLineInCell ( PDFLine thisLine, Map<Integer, Pair<Float, Float>> lineDistanceMap )
	{
		float y1=thisLine.getY1();
		float y2=thisLine.getY2();
		
		for(Integer row : lineDistanceMap.keySet())
		{
			Pair<Float, Float> pair = lineDistanceMap.get(row);
			
			if(pair.getA()<y1 && pair.getB()>y2)
			{
				return pair;
			}
		}
		return new Pair<Float, Float>(0.0f,0.0f);
	}
	public Pair<Float, Float> getMostRepeatedGapDistance1NonLatin(List<List<PDFLine>> groups)
	{
		List<PDFLine> lines = new ArrayList<PDFLine>() ;
		for ( int i=0 ; i<groups.size() ; i++ )
			lines.addAll(groups.get(i)) ;

		// Create Distances
		List<Float> distances = new ArrayList<Float>() ;
		for ( int i=0 ; i<lines.size()-1 ; i++ )
		{
			PDFLine thisLine = lines.get(i) ;
			PDFLine nextLine = lines.get(i+1) ;

			float gap = nextLine.getY1() - thisLine.getY2() ;

			if ( gap < 0.0f )
				continue ;

			distances.add(gap) ;
		}

		// Create Gap Groups.
		List<List<Float>> gapGroups = new ArrayList<List<Float>>() ;
		for ( int i=0 ; i<distances.size() ; i++ )
		{
			float thisGap = distances.get(i) ;

			boolean foundGroup = false ;
			for ( int j=0 ; j<gapGroups.size() ; j++ )
			{
				List<Float> thisGroup = gapGroups.get(j) ;
				Pair<Float, Float> pair = findMinMaxGaps(thisGroup) ;
				float minGroupGap = pair.getA().floatValue() - 1.0f ;
				float maxGroupGap = pair.getB().floatValue() + 1.0f ;

				if ( thisGap >= minGroupGap && thisGap <= maxGroupGap )
				{
					thisGroup.add(thisGap) ;
					foundGroup = true ;
					break ;
				}
			}

			if ( !foundGroup )
			{
				List<Float> newGroup = new ArrayList<Float>() ;
				newGroup.add(thisGap) ;
				gapGroups.add(newGroup) ;
			}
		}

		if ( DEBUG )
			System.out.println("Gap Groups: " + gapGroups) ;

		float tabularGapValues = computeTabularGapValues(lines) ;
		System.out.println("Tabular-Gap-Values: " + tabularGapValues) ; 

		List<Float> biggestGroup = new ArrayList<Float>() ;
		int maxSize = Integer.MIN_VALUE ;
		for ( int i=0 ; i<gapGroups.size() ; i++ )
		{
			List<Float> group = gapGroups.get(i) ;

			if ( group.size() == 1 )
				continue ;

			if ( DEBUG )
				System.out.println("\tThis Group = " + group) ;

			Pair<Float, Float> minMax = findMinMaxGaps(group) ;

			if ( minMax.getA().floatValue() < 2.0f )
				continue ;

			if ( tabularGapValues >= minMax.getA().floatValue() && tabularGapValues <= minMax.getB().floatValue() )
				continue ;

			if ( DEBUG )
				System.out.println("\t\tMin, Max = " + minMax) ;

			int size = group.size() ;

			if(tabularGapValues>0.0)
			{
				if(minMax.getA().floatValue()>tabularGapValues && minMax.getB().floatValue() > tabularGapValues)
					continue;
			}

			if ( maxSize < size )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
			else if ( maxSize == size )
			{
				if ( biggestGroup.get(0).floatValue() < group.get(0).floatValue() )
				{
					maxSize = size ;
					biggestGroup = group ;
				}
			}
		}

		if ( DEBUG )
			System.out.println("Biggest Group: " + biggestGroup) ;

		Pair<Float, Float> minMax = findMinMaxGaps(biggestGroup) ;

		float padding = 0.0f ;
		Pair<Float, Float> pair = new Pair<Float, Float>(minMax.getA().floatValue()-padding, minMax.getB().floatValue()+padding) ;

		return pair ;
	}

	
	private float computeTabularGapValues ( List<PDFLine> lines )
	{
		if ( lines.size() <= 2 )
			return -1.0f ;

		List<Float> gaps = new ArrayList<Float>() ;

		for ( int i=0 ; i<lines.size()-1 ; i++ )
		{
			PDFLine thisLine = lines.get(i) ;
			PDFLine nextLine = lines.get(i+1) ;

			if ( thisLine.getChunks().size() == 1 || nextLine.getChunks().size() == 1 )
				continue ;

			for ( PDFChunk thisChunk : thisLine.getChunks() )
			{
				if ( thisChunk.getChunk().trim().equalsIgnoreCase("") )
					continue ;

				if ( !thisChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
					continue ;

				boolean found = false ;
				for ( PDFChunk nextChunk : nextLine.getChunks() )
				{
					if ( nextChunk.getChunk().trim().equalsIgnoreCase("") 
							|| !nextChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
						continue ;

					if ( thisChunk.getX2() < nextChunk.getX1() || thisChunk.getX1() > nextChunk.getX2() )
						continue ;

					System.out.println("Selecting Chunks: " + thisChunk + "\t" + nextChunk) ;

					found = true ;
					break ;
				}

				if ( !found )
					continue ;

				float gap = nextLine.getY1() - thisLine.getY2() ;
				gaps.add(gap) ;
				System.out.println("\t" + gap) ;
			}
		}

		System.out.println("Tabular-All-Gaps: " + gaps) ;

		// Create Gap Groups.
		List<List<Float>> gapGroups = new ArrayList<List<Float>>() ;
		for ( int i=0 ; i<gaps.size() ; i++ )
		{
			float thisGap = gaps.get(i) ;

			boolean foundGroup = false ;
			for ( int j=0 ; j<gapGroups.size() ; j++ )
			{
				List<Float> thisGroup = gapGroups.get(j) ;
				Pair<Float, Float> pair = findMinMaxGaps(thisGroup) ;
				float minGroupGap = pair.getA().floatValue() - 1.0f ;
				float maxGroupGap = pair.getB().floatValue() + 1.0f ;

				if ( thisGap >= minGroupGap && thisGap <= maxGroupGap )
				{
					thisGroup.add(thisGap) ;
					foundGroup = true ;
					break ;
				}
			}

			if ( !foundGroup )
			{
				List<Float> newGroup = new ArrayList<Float>() ;
				newGroup.add(thisGap) ;
				gapGroups.add(newGroup) ;
			}
		}

		System.out.println("Tabular-Gap-Groups: " + gapGroups) ;

		List<Float> biggestGroup = new ArrayList<Float>() ;
		int maxSize = Integer.MIN_VALUE ;
		for ( int i=0 ; i<gapGroups.size() ; i++ )
		{
			List<Float> group = gapGroups.get(i) ;

			if ( group.size() == 1 )
				continue ;

			if ( DEBUG )
				System.out.println("\tThis Group = " + group) ;

			Pair<Float, Float> minMax = findMinMaxGaps(group) ;

			if ( DEBUG )
				System.out.println("\t\tMin, Max = " + minMax) ;

			int size = group.size() ;

			if ( maxSize <= size )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
			else if ( maxSize == size )
			{
				if ( biggestGroup.get(0).floatValue() < group.get(0).floatValue() )
				{
					maxSize = size ;
					biggestGroup = group ;
				}
			}
		}

		System.out.println("Tabular-Biggest-Gap-Group: " + biggestGroup) ;

		float ret = 0.0f ;
		for ( Float gap : biggestGroup )
			ret = ret + gap ;

		ret = biggestGroup.size() == 0 ? 0.0f : (ret / (biggestGroup.size()+0.0f)) ;

		return ret ;
	}

	public void createBlocksForNonLatin (String fileName )
	{
		//List<List<PDFLine>> groups = createVerticalBlocks() ;

		List<List<PDFLine>> groups  = createVerticalBlocksChinese(fileName) ;////****

		setLineBlocks(groups) ;

		List<PDFBlock> blocks = createBlocks(groups) ;

		List<PDFBlock> newBlocks = new ArrayList<PDFBlock>();

		for(PDFBlock eachBlock : blocks)
		{
			List<PDFBlock> splittedBlocks = splitBlocksBasedOnBold(eachBlock);
			newBlocks.addAll(splittedBlocks);
		}

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER CREATING BLOCKS\n\n") ;
			for ( int i=0 ; i<newBlocks.size() ; i++ )
			{
				PDFBlock block = newBlocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}

		newBlocks = cleanupBlocks(newBlocks) ;

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER CLEANUP\n\n") ;
			for ( int i=0 ; i<newBlocks.size() ; i++ )
			{
				PDFBlock block = newBlocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}

		// blocks = clearCapsBlocks(blocks);

		setBlocks(newBlocks) ;

	}




	void run()
	{
		List<List<PDFLine>> groups = createVerticalBlocks() ;
		setLineBlocks(groups) ;

		List<PDFBlock> blocks = createBlocks(groups) ;

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER CREATING BLOCKS\n\n") ;
			for ( int i=0 ; i<blocks.size() ; i++ )
			{
				PDFBlock block = blocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}

		/*blocks = validateVerticalBlocks(blocks) ;

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER VALIDATING VERTICAL BLOCKS\n\n") ;
			for ( int i=0 ; i<blocks.size() ; i++ )
			{
				PDFBlock block = blocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}*/

		/*blocks = pruneBlocks(blocks) ;

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER PRUNING \n\n") ;
			for ( int i=0 ; i<blocks.size() ; i++ )
			{
				PDFBlock block = blocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}*/

		blocks = cleanupBlocks(blocks) ;

		if ( DEBUG )
		{
			System.out.println("\n\n\nAFTER CLEANUP\n\n") ;
			for ( int i=0 ; i<blocks.size() ; i++ )
			{
				PDFBlock block = blocks.get(i) ;
				List<PDFLine> lines = block.getLines() ;
				System.out.println("BLOCK " + i) ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}
		}

		// blocks = clearCapsBlocks(blocks);

		setBlocks(blocks) ;
	}

	// TODO Remove unused code found by UCDetector
	// 	public List<PDFBlock> clearCapsBlocks(List<PDFBlock> blocks) 
	// 	{
	// 		List<PDFBlock> ret=new ArrayList<PDFBlock>() ;
	// 		
	// 		for(int i=0 ; i<blocks.size() ; i++)
	// 		{
	// 			PDFBlock block=blocks.get(i) ;
	// 			List<PDFLine> pdfLines=block.getLines();
	// 
	// 			if(pdfLines.size()==1)
	// 			{
	// 				ret.add(block);
	// 				continue;
	// 			}
	// 			
	// 			boolean isFirstLine=false;
	// 			boolean isLastLine=false;
	// 			
	// 			if(isParagraphFirstTokenCapitalized(pdfLines.get(0).getLine().trim()) 
	// 					&& pdfLines.get(0).getLine().trim().endsWith(":"))
	// 			{
	// 				List<PDFLine> tempLineList=new ArrayList<PDFLine>();
	// 				tempLineList.add(pdfLines.get(0));
	// 				PDFBlock blk1=new PDFBlock(getPageNo(), tempLineList);
	// 				ret.add(blk1);
	// 				isFirstLine=true;
	// 			}
	// 			
	// 			PDFBlock blk1=null;
	// 			
	// 			if(isParagraphFirstTokenCapitalized(pdfLines.get(pdfLines.size()-1).getLine().trim()) 
	// 					&& pdfLines.get(pdfLines.size()-1).getLine().trim().endsWith(":"))
	// 			{
	// 				List<PDFLine> tempLineList=new ArrayList<PDFLine>();
	// 				tempLineList.add(pdfLines.get(pdfLines.size()-1));
	// 				blk1=new PDFBlock(getPageNo(), tempLineList);
	// 				isLastLine=true;
	// 			}
	// 			
	// 			List<PDFLine> tempLineList=new ArrayList<PDFLine>();
	// 			for(int j=0;j<pdfLines.size();j++)
	// 			{
	// 				if(j==0 && isFirstLine)
	// 					continue;
	// 				if(j==pdfLines.size()-1 && isLastLine)
	// 					continue;
	// 				tempLineList.add(pdfLines.get(j));
	// 			}
	// 			
	// 			if(tempLineList.size()>0)
	// 			{
	// 				PDFBlock tempBlk1=new PDFBlock(getPageNo(), tempLineList);
	// 				ret.add(tempBlk1);
	// 			}
	// 			
	// 			if(blk1!=null && blk1.getLines().size()>0)
	// 			{
	// 				ret.add(blk1);
	// 			}
	// 		}
	// 		
	// 		return ret;
	// 	}

	/*private static boolean isParagraphFirstTokenCapitalized(String blockString) 
	{
		String cleanString = "" ;
		for ( int i=0 ; i<blockString.length() ; i++ )
		{
			String thisCharacter = blockString.substring(i, i+1) ;
			int code = (int) thisCharacter.charAt(0) ;

			if ( code < 65 || (code >= 91 && code <= 96) || code >= 123 )
				cleanString = cleanString + " " ;
			else
				cleanString = cleanString + thisCharacter ;
		}

		String[] tokens = cleanString.trim().split("\\s+") ;

		int count = 0 ;
		for ( int i=0 ; i<tokens.length ; i++ )
		{
			String token =  tokens[i] ;

			if ( token.trim().equalsIgnoreCase("") )
				continue ;

			if ( StopWords.isStopWord(token.toLowerCase()) )
				continue ;

			if ( isParagraphAlphaNumeric(token) )
				continue ;

			String firstCharacter = token.substring(0, 1) ;
			if ( !firstCharacter.equals(firstCharacter.toUpperCase()) )
				return false ;

			count++ ;
		}

		if ( count >= 2 )
			return true ;

		return false ;
	}
	 */
	/*private static boolean isParagraphAlphaNumeric(String paragraphString) 
	{
		String[] tokens = paragraphString.split(" ") ;

		int count = 0 ;
		for ( int i=0 ; i<tokens.length ; i++ )
		{
			String token = tokens[i] ;
			// System.out.println("TOKEN : " + token) ;
			if ( isTokenAlphaNumeric(token) )
			{
				// System.out.println("\tALPHA-NUMERIC") ;
				count++ ;
			}
		}

		int size = tokens.length ;
		float percentAlphaNumeric = (float) count / (float) size ;
		// System.out.println("percent = " + percentAlphaNumeric + "\tcount = " + count + "\tsize = " + size) ;

		if ( percentAlphaNumeric > 0.21 )
			return true ;

		return false ;
	}
	 */
	/*	private static boolean isTokenAlphaNumeric(String token)
	{
		boolean containsNumber = false ;
		boolean containsCharacter = false ;

		for ( int i=0 ; i<token.length() ; i++ )
		{
			if ( containsNumber && containsCharacter )
				return true ;

			String character = token.substring(i, i+1) ;
			int code = (int) character.charAt(0) ;
			// System.out.println("\tCHARACTER : " + character + "\t" + code) ;

			boolean isThisNumber = (code >= 48 && code <= 57) ? true : false ;
			boolean isUpperCaseAlphabet = (code >= 65 && code <= 90) ? true : false ;
			boolean isLowerCaseAlphabet = (code >= 97 && code <= 122) ? true : false ;

			if ( isThisNumber )
			{
				containsNumber = true ;
				continue ;
			}

			if ( isUpperCaseAlphabet || isLowerCaseAlphabet )
			{
				containsCharacter = true ;
				continue ;
			}
		}

		if ( containsNumber && containsCharacter )
			return true ;

		return false ;
	}*/

	private List<PDFBlock> cleanupBlocks(List<PDFBlock> blocks) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<blocks.size() ; i++ )
		{
			PDFBlock block = blocks.get(i) ;
			List<PDFLine> lines = block.getLines() ;

			List<PDFLine> newLines = new ArrayList<PDFLine>() ;
			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				if ( line == null || line.getLine().trim().equalsIgnoreCase("") )
					continue ;

				newLines.add(line) ;
			}

			if ( newLines.size() == 0 )
				continue ;

			PDFBlock newBlock = new PDFBlock(getPageNo(), newLines) ;
			ret.add(newBlock) ;
		}

		return ret ;
	}

	/*private List<PDFBlock> validateVerticalBlocks(List<PDFBlock> blocks)
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<blocks.size() ; i++ )
		{
			PDFBlock block = blocks.get(i) ;
			List<PDFLine> lines = block.getLines() ;

			if ( lines.size() == 1 )
			{
				ret.add(block) ;
				continue ;
			}

			float averageGap = computeAverageGap(lines) ;

			List<List<PDFLine>> newLineGroups = new ArrayList<List<PDFLine>>() ;
			List<PDFLine> thisLineGroup = new ArrayList<PDFLine>() ;

			for ( int j=0 ; j<lines.size()-1 ; j++ )
			{
				PDFLine thisLine = lines.get(j) ;
				PDFLine nextLine = lines.get(j+1) ;

				float gap = nextLine.getY1() - thisLine.getY2() ;
				gap = gap < 0.0f ? 0.0f : gap ;

				boolean nextLineEnumeration = ParagraphsCreater.isLineEnumerated(nextLine.getLine().trim()) ;
				if ( VALIDATE_BLOCKS_DEBUG )
				{
					System.out.println("CHECK .... \n\t" + thisLine.getLine() + "\n\t" + nextLine.getLine()) ;
					System.out.println("\t\tAVG GAP : " + averageGap) ;
					System.out.println("\t\tTHIS GAP : " + gap) ;
				}

				boolean indent=false;
				if(nextLine.getX1()-thisLine.getX1()>25 || nextLine.getX1()-thisLine.getX1()<-25)
				{
					indent=true;
					//System.out.println(thisLine.getLine());
					//System.out.println(nextLine.getLine());
				}

				if ( (gap >= averageGap || indent) && nextLineEnumeration 
						&& (TypeIdentifier.findClauseNo(nextLine.getLine().trim()).trim().endsWith(".") || TypeIdentifier.findClauseNo(nextLine.getLine().trim()).trim().endsWith(")"))
						&& !InlineClauseIdentifier.checkKeyWords(thisLine.getLine().trim()) )
				{
					if ( VALIDATE_BLOCKS_DEBUG )
					{
						System.out.println("BREAKING .... \n\t" + thisLine.getLine() + "\n\t" + nextLine.getLine()) ;
					}

					if ( !thisLineGroup.contains(thisLine) )
						thisLineGroup.add(thisLine) ;

					newLineGroups.add(new ArrayList<PDFLine>(thisLineGroup)) ;

					thisLineGroup = new ArrayList<PDFLine>() ;
					thisLineGroup.add(nextLine) ;

					continue ;
				}

				if ( !thisLineGroup.contains(thisLine) )
					thisLineGroup.add(thisLine) ;
				if ( !thisLineGroup.contains(nextLine) )
					thisLineGroup.add(nextLine) ;
			}



			if ( thisLineGroup.size() != 0 )
			{
				newLineGroups.add(new ArrayList<PDFLine>(thisLineGroup)) ;
				thisLineGroup = new ArrayList<PDFLine>() ;
			}

			for ( int j=0 ; j<newLineGroups.size() ; j++ )
			{
				List<PDFLine> newLines = newLineGroups.get(j) ;
				PDFBlock newBlock = new PDFBlock(getPageNo(), newLines) ;
				ret.add(newBlock) ;
			}
		}


		return ret ;
	}*/

	/*private float computeAverageGap(List<PDFLine> lines)
	{
		float gapSum = 0.0f ;
		int count = 0 ;

		for ( int j=0 ; j<lines.size()-1 ; j++ )
		{
			PDFLine thisLine = lines.get(j) ;
			PDFLine nextLine = lines.get(j+1) ;

			float gap = nextLine.getY1() - thisLine.getY2() ;
			// System.out.println("THIS GAP : " + nextLine.getX1() +) ;
			gap = gap < 0.0f ? 0.0f : gap ;

			gapSum = gapSum + gap ;
			count++ ;
		}

		float averageGap = count == 0 ? 0.0f : gapSum / (float) count ;

		if ( PRUNE_BLOCKS_DEBUG )
			System.out.println("AVERAGE GAP : " + gapSum + " / " + count + " = " + averageGap) ;

		return averageGap ;
	}*/

	/*private List<PDFBlock> pruneBlocks(List<PDFBlock> blocks)
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<blocks.size() ; i++ )
		{
			PDFBlock block = blocks.get(i) ;
			List<PDFLine> lines = block.getLines() ;

			if ( PRUNE_BLOCKS_DEBUG )
			{
				System.out.println("\n\n\n\n") ;
				System.out.println("PROCESSING BLOCK : ") ;
				for ( int j=0 ; j<lines.size() ; j++ )
				{
					PDFLine line = lines.get(j) ;
					System.out.println("\tLINE " + j + " : " + line.getLine()) ;
				}
			}

			if ( lines.size() == 1 )
			{
				ret.add(block) ;
				continue ;
			}

			Pair<PDFLine, PDFLine> pair = computeFirstAndSecondLines(lines) ;
			PDFLine firstLine = pair.getA() ;
			PDFLine secondLine = pair.getB() ;

			List<PDFLine> restLines = computeRestOfTheLines(lines, firstLine) ;

			if ( PRUNE_BLOCKS_DEBUG )
			{
				System.out.println() ;
				System.out.println("\tFIRST LINE : " + firstLine.getLine()) ;
				System.out.println("\tSECOND LINE : " + secondLine.getLine()) ;
				System.out.println("\tREST LINES : ") ;
				for ( int j=0 ; j<restLines.size() ; j++ )
				{
					PDFLine line = restLines.get(j) ;
					System.out.println("\t\tLINE " + j + " : " + line.getLine()) ;
				}
			}

			if ( restLines.size() == 0 )
			{
				ret.add(block) ;
				continue ;
			}

			// If first line is bolded and second line is not bolded
			if ( HeadingIdentifier.isFontSizeCharactersMapBolded(firstLine.getLine().trim(), false, firstLine.getFontSizeCharactersMap())
					&& !HeadingIdentifier.isFontSizeCharactersMapBolded(secondLine.getLine().trim(), false, secondLine.getFontSizeCharactersMap()) )
			{
				if ( PRUNE_BLOCKS_DEBUG )
				{
					System.out.println("\n\n") ;
					System.out.println("CONDITION 1 .... ") ;
				}

				List<PDFLine> newLines = new ArrayList<PDFLine>() ;
				newLines.add(firstLine) ;
				PDFBlock newBlock = new PDFBlock(getPageNo(), newLines) ;
				ret.add(newBlock) ;

				PDFBlock newBlock2 = new PDFBlock(getPageNo(), restLines) ;
				ret.add(newBlock2) ;

				continue ;
			}

			// if first line's all tokens start in caps and second line tokens dont start in caps
			if ( HeadingIdentifier.isParagraphFirstTokenCapitalized(firstLine.getLine().trim()) 
					&& !HeadingIdentifier.isParagraphFirstTokenCapitalized(secondLine.getLine().trim()) )
			{
				if ( PRUNE_BLOCKS_DEBUG )
				{
					System.out.println("\n\n") ;
					System.out.println("CONDITION 2 .... ") ;
				}


				List<PDFLine> newLines = new ArrayList<PDFLine>() ;
				newLines.add(firstLine) ;
				PDFBlock newBlock = new PDFBlock(newLines) ;
				ret.add(newBlock) ;

				PDFBlock newBlock2 = new PDFBlock(restLines) ;
				ret.add(newBlock2) ;

				continue ;
			}

			// If first line is way smaller than second line(s)		
			if ( isLineSmall(firstLine, getLines()) && areLinesFull(restLines, getLines()) && !areRestLineFormatted(restLines) )
			{
				if ( PRUNE_BLOCKS_DEBUG )
				{
					System.out.println("\n\n") ;
					System.out.println("CONDITION 3 .... ") ;
				}

				List<PDFLine> newLines = new ArrayList<PDFLine>() ;
				newLines.add(firstLine) ;
				PDFBlock newBlock = new PDFBlock(getPageNo(), newLines) ;
				ret.add(newBlock) ;

				PDFBlock newBlock2 = new PDFBlock(getPageNo(), restLines) ;
				ret.add(newBlock2) ;

				continue ;
			}

			ret.add(block) ;
		}

		return ret ;
	}*/

	/*private boolean areRestLineFormatted(List<PDFLine> lines)
	{
		PDFLine firstLine = null ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;
			if ( !line.getLine().trim().equalsIgnoreCase("") )
			{
				firstLine = line ;
				break ;
			}
		}

		if ( firstLine == null )
			return false ;

		if ( firstLine.getChunks().size() >= 3 )
			return true ;

		return false ;
	}*/

	/*private List<PDFLine> computeRestOfTheLines(List<PDFLine> lines, PDFLine firstLine)
	{
		List<PDFLine> restLines = new ArrayList<PDFLine>() ;

		boolean foundFirst = false ;
		for ( int j=0 ; j<lines.size() ; j++ )
		{
			PDFLine line = lines.get(j) ;
			if ( line.equals(firstLine) )
			{
				foundFirst = true ;
				continue ;
			}

			if ( !foundFirst )
				continue ;

			restLines.add(line) ;
		}

		return restLines ;
	}*/

	/*private Pair<PDFLine, PDFLine> computeFirstAndSecondLines(List<PDFLine> lines)
	{
		PDFLine firstLine = null ;
		PDFLine secondLine = null ;

		for ( int j=0 ; j<lines.size() ; j++ )
		{
			if ( firstLine != null && secondLine != null )
				break ;

			PDFLine line = lines.get(j) ;
			if ( line.getLine().trim().equalsIgnoreCase("") )
				continue ;

			if ( firstLine == null )
			{
				firstLine = line ;
				continue ;
			}

			if ( firstLine != null && secondLine == null )
			{
				secondLine = line ;
				break ;
			}

			break ;
		}

		return new Pair<PDFLine, PDFLine>(firstLine, secondLine) ;
	}*/

	/*private boolean isLineSmall(PDFLine firstLine, List<PDFLine> lines)
	{
		float minX1 = Float.MAX_VALUE ;
		float maxX2 = Float.MIN_VALUE ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;

			float x1 = line.getX1() ;
			float x2 = line.getX2() ;

			if ( x1 < minX1 )
				minX1 = x1 ;

			if ( x2 > maxX2 )
				maxX2 = x2 ;
		}

		float width = maxX2 - minX1 ;

		float firstLineWidth = firstLine.getWidth() ;

		if ( (0.60*width) >= firstLineWidth )
			return true ;

		return false ;
	}*/

	/*private boolean areLinesFull(List<PDFLine> restLines, List<PDFLine> lines) 
	{
		float minX1 = Float.MAX_VALUE ;
		float maxX2 = Float.MIN_VALUE ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;

			float x1 = line.getX1() ;
			float x2 = line.getX2() ;

			if ( x1 < minX1 )
				minX1 = x1 ;

			if ( x2 > maxX2 )
				maxX2 = x2 ;
		}

		float width = maxX2 - minX1 ;

		int count = 0 ;
		for ( int i=0 ; i<restLines.size() ; i++ )
		{
			PDFLine line = restLines.get(i) ;
			float lineWidth = line.getWidth() ;

			if ( (0.75 * width) <= lineWidth )
				count++ ;
		}

		float percentage = (float) count / (float) restLines.size() ;

		if ( restLines.size() > 2 && percentage >= 0.5 )
			return true ;
		else if ( restLines.size() <= 2 && percentage == 1.0 )
			return true ;

		return false ;
	}*/

	private List<PDFBlock> createBlocks(List<List<PDFLine>> groups) 
	{
		List<PDFBlock> blocks = new ArrayList<PDFBlock>() ;

		for ( int i=0 ; i<groups.size() ; i++ )
		{
			List<PDFLine> group = groups.get(i) ;

			PDFBlock block = new PDFBlock(getPageNo(), group) ;
			blocks.add(block) ;
		}

		return blocks;
	}

	private List<List<PDFLine>> createVerticalBlocks() 
	{
		List<List<PDFLine>> groups = createDefaultBlocks(getLines()) ;

		if ( groups.size() == 1 )
			return groups ;

		List<List<PDFLine>> newGroups = new ArrayList<List<PDFLine>>() ;
		List<PDFLine> thisGroup = new ArrayList<PDFLine>() ;
		float minX1=0.0f;

		for ( int i=0 ; i<groups.size()-1 ; i++ )
		{
			List<PDFLine> thisBlock = groups.get(i) ;

			PDFLine thisLine = thisBlock.get(0) ;
			if(minX1==0.0f)
				minX1=thisLine.getX1();

			if(minX1>thisLine.getX1())
				minX1=thisLine.getX1();

		}

		// float distance = getMostRepeatedGapDistance(groups);
		Pair<Float, Float> distanceRange = getMostRepeatedGapDistance1(groups) ;

		for ( int i=0 ; i<groups.size()-1 ; i++ )
		{
			List<PDFLine> thisBlock = groups.get(i) ;
			List<PDFLine> nextBlock = groups.get(i+1) ;

			PDFLine thisLine = thisBlock.get(0) ;
			PDFLine nextLine = nextBlock.get(0) ;
			PDFLine prevLine = null;
			PDFLine secondNextLine=null;
			if(i>0)
			{
				prevLine=groups.get(i-1).get(0);
			}
			if(i<groups.size()-2)
			{
				secondNextLine=groups.get(i+2).get(0);
			}
			if ( DEBUG )
			{
				System.out.println("\n\n") ;
				System.out.println("THIS LINE : " + thisLine.getLine()) ;
				System.out.println("NEXT LINE : " + nextLine.getLine()) ;
			}

			boolean isGapOK = isGapOK(thisLine, nextLine, prevLine , minX1, secondNextLine,distanceRange) ;

			if ( DEBUG )
			{
				System.out.println("\tGAP : " + isGapOK) ;
			}

			boolean isFontOK = isFontValid(thisLine, nextLine) ;

			if ( DEBUG )
			{
				System.out.println("\tFONT : " + isFontOK) ;
			}

			boolean isLineOK = isLineNotCompletelySameCharacter(thisLine) || isLineNotCompletelySameCharacter(nextLine) ? true : false ;

			if ( DEBUG )
			{
				System.out.println("\tLINE : " + isLineOK) ;
			}
			boolean isIndentOK = true ; // isIndentSimilar(thisLine, nextLine, getLines()) ;
			if ( DEBUG )
			{
				System.out.println("\tINDENT : " + isIndentOK) ;
			}


			if ( !isLineOK )
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( DEBUG )
				{
					System.out.println("CREATING NEW GROUP .... ") ;
				}

				newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

				thisGroup = new ArrayList<PDFLine>(nextBlock) ;
			}
			else if ( (isGapOK && isFontOK && isIndentOK))
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( !thisGroup.contains(nextLine) )
					thisGroup.add(nextLine) ;

				if ( DEBUG )
				{
					System.out.println("ADDING IN THE CURRENT GROUP .... ") ;
				}

				continue ;
			}
			else
			{
				if ( !thisGroup.contains(thisLine) )
					thisGroup.add(thisLine) ;

				if ( DEBUG )
				{
					System.out.println("CREATING NEW GROUP .... ") ;
				}

				newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

				thisGroup = new ArrayList<PDFLine>(nextBlock) ;

				continue ;
			}
		}

		if ( thisGroup.size() != 0 )
			newGroups.add(new ArrayList<PDFLine>(thisGroup)) ;

		groups = new ArrayList<List<PDFLine>>(newGroups) ;

		return groups;
	}

	private Pair<Float, Float> getMostRepeatedGapDistance1(List<List<PDFLine>> groups)
	{
		List<PDFLine> lines = new ArrayList<PDFLine>() ;
		for ( int i=0 ; i<groups.size() ; i++ )
			lines.addAll(groups.get(i)) ;

		List<Float> distances = new ArrayList<Float>() ;
		for ( int i=0 ; i<lines.size()-1 ; i++ )
		{
			PDFLine thisLine = lines.get(i) ;
			PDFLine nextLine = lines.get(i+1) ;

			boolean thisLineMostlyAlphabets = isLineMostlyAlphabets(thisLine) ;
			boolean nextLineMostlyAlphabets = isLineMostlyAlphabets(nextLine) ;

			if ( !thisLineMostlyAlphabets || !nextLineMostlyAlphabets )
			{
				if ( DEBUG )
					System.out.println("Leaving Line : " + (!thisLineMostlyAlphabets ? thisLine.getLine() : nextLine.getLine())) ;

				continue ;
			}

			float gap = nextLine.getY1() - thisLine.getY2() ;

			if ( gap < 0.0f )
				continue ;

			distances.add(gap) ;
		}

		if ( DEBUG )
			System.out.println("GAPS : " + distances) ;

		List<List<Float>> gapGroups = new ArrayList<List<Float>>() ;
		for ( int i=0 ; i<distances.size() ; i++ )
		{
			float thisGap = distances.get(i) ;

			boolean foundGroup = false ;
			for ( int j=0 ; j<gapGroups.size() ; j++ )
			{
				List<Float> thisGroup = gapGroups.get(j) ;
				Pair<Float, Float> pair = findMinMaxGaps(thisGroup) ;
				float minGroupGap = pair.getA().floatValue() - 1.0f ;
				float maxGroupGap = pair.getB().floatValue() + 1.0f ;

				if ( thisGap >= minGroupGap && thisGap <= maxGroupGap )
				{
					thisGroup.add(thisGap) ;
					foundGroup = true ;
					break ;
				}
			}

			if ( !foundGroup )
			{
				List<Float> newGroup = new ArrayList<Float>() ;
				newGroup.add(thisGap) ;
				gapGroups.add(newGroup) ;
			}
		}

		if ( DEBUG )
			System.out.println("Gap Groups: " + gapGroups) ;

		float averageFontSize = computeAverageFontSize(groups) ;

		if ( DEBUG )
			System.out.println("Average Font Size = " + averageFontSize) ;

		if ( DEBUG )
			System.out.println("Finding Biggest Group ...") ;

		List<Float> biggestGroup = new ArrayList<Float>() ;
		int maxSize = Integer.MIN_VALUE ;
		for ( int i=0 ; i<gapGroups.size() ; i++ )
		{
			List<Float> group = gapGroups.get(i) ;

			if ( DEBUG )
				System.out.println("\tThis Group = " + group) ;

			Pair<Float, Float> minMax = findMinMaxGaps(group) ;

			if ( DEBUG )
				System.out.println("\t\tMin, Max = " + minMax) ;

			if ( minMax.getB().floatValue() > (1.5*averageFontSize) )
				continue ;

			int size = group.size() ;

			if ( maxSize < size )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
		}

		if ( DEBUG )
			System.out.println("Biggest Group: " + biggestGroup) ;

		Pair<Float, Float> minMax = findMinMaxGaps(biggestGroup) ;

		/*float sum = 0.0f ;
		float count = biggestGroup.size() + 0.0f ;

		for ( int i=0 ; i<biggestGroup.size() ; i++ )
			sum = sum + biggestGroup.get(i) ;

		float average = sum / count ;*/

		float padding = 1.0f ;
		Pair<Float, Float> pair = new Pair<Float, Float>(minMax.getB().floatValue()-padding, minMax.getB().floatValue()+padding) ;

		// Pair<Float, Float> pair = findMinMaxGaps(biggestGroup) ;
		// pair.setB(pair.getB()+1.0f) ;

		return pair ;
	}

	/**
	 * @param groups
	 * @return
	 */
	private float computeAverageFontSize(List<List<PDFLine>> groups)
	{
		float sum = 0.0f ;
		float count = 0.0f ;

		for ( int i=0 ; i<groups.size() ; i++ )
		{
			List<PDFLine> group = groups.get(i) ;
			for ( int j=0 ; j<group.size() ; j++ )
			{
				PDFLine line = group.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;
				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;
					List<PDFWord> words = chunk.getWords() ;
					for ( int l=0 ; l<words.size() ; l++ )
					{
						PDFWord word = words.get(l) ;
						List<PDFCharacter> characters = word.getCharacters() ;
						for ( int m=0 ; m<characters.size() ; m++ )
						{
							PDFCharacter character = characters.get(m) ;

							String strCharacter = character.getCharacter() ;

							if ( strCharacter.trim().equalsIgnoreCase("") )
								continue ;

							if ( strCharacter.replaceAll("[0-9\\.\\-]", "").trim().equalsIgnoreCase("") )
								continue ;

							float height = character.getHeight() ;
							sum = sum + height ;
							count = count + 1.0f ;
						}
					}
				}
			}
		}

		float average = sum / count ;

		return average ;
	}

	private boolean isLineMostlyAlphabets(PDFLine thisLine)
	{
		List<String> alphabets = new ArrayList<String>() ;
		List<String> numbers = new ArrayList<String>() ;

		for ( int i=0 ; i<thisLine.getChunks().size() ; i++ )
		{
			PDFChunk chunk = thisLine.getChunks().get(i) ;
			for ( int j=0 ; j<chunk.getWords().size() ; j++ )
			{
				PDFWord word = chunk.getWords().get(j) ;
				for ( int k=0 ; k<word.getCharacters().size() ; k++ )
				{
					PDFCharacter character = word.getCharacters().get(k) ;

					String strCharacter = character.getCharacter() ;

					if ( strCharacter.trim().equalsIgnoreCase("") )
					{
						alphabets.add(strCharacter) ;
						continue ;
					}

					if ( strCharacter.replaceAll("[0-9,\\-\\.]", "").trim().equalsIgnoreCase("") ) 
					{
						numbers.add(strCharacter) ;
						continue ;
					}

					alphabets.add(strCharacter) ;
				}
			}
		}

		float alphaCount = alphabets.size() + 0.0f ;
		float totalCount = alphabets.size() + numbers.size() + 0.0f ;

		float percent = alphaCount/totalCount ;
		// System.out.println("Percent : " + percent + " : " + thisLine.getLine()) ;
		if ( percent >= 0.3 )
			return true ;

		return false ;
	}

	private Pair<Float, Float> findMinMaxGaps(List<Float> group) 
	{
		float min = Float.MAX_VALUE ;
		float max = Float.MIN_VALUE ;

		for ( int i=0 ; i<group.size() ; i++ )
		{
			float gap = group.get(i) ;

			if ( min > gap )
				min = gap ;

			if ( max < gap )
				max = gap ;
		}

		Pair<Float, Float> pair = new Pair<Float, Float>(min, max) ;
		return pair ;
	}

	// TODO Remove unused code found by UCDetector
	// 	public float getMostRepeatedGapDistance(List<List<PDFLine>> groups) 
	// 	{
	// 		Map<Float,Integer> distanceRepeatMap = new HashMap<Float,Integer>() ;
	// 		
	// 		for ( int i=0 ; i<groups.size()-1 ; i++ )
	// 		{
	// 			List<PDFLine> thisBlock = groups.get(i) ;
	// 			List<PDFLine> nextBlock = groups.get(i+1) ;
	// 			PDFLine thisLine = thisBlock.get(0) ;
	// 			PDFLine nextLine = nextBlock.get(0) ;
	// 
	// 			float distance = Math.round(Math.abs(thisLine.getY2()-nextLine.getY1())*10.0)/10.0f;
	// 
	// 			if( !distanceRepeatMap.keySet().contains(distance) )
	// 			{
	// 				distanceRepeatMap.put(distance, 1) ;
	// 			}
	// 			else
	// 			{
	// 				int occurence = distanceRepeatMap.get(distance) ;
	// 				distanceRepeatMap.put(distance, occurence+1) ;
	// 			}	
	// 		}
	// 		
	// 		float maxDistanceRepeated = 1000.0f ;
	// 		Set<Float> keySet = distanceRepeatMap.keySet() ;
	// 		/*for(Float key:keySet)
	// 		{
	// 			if(distanceRepeatMap.get(key)>occurence)
	// 			{
	// 				maxDistanceRepeated=key;
	// 				occurence=distanceRepeatMap.get(key);
	// 			}
	// 		}*/
	// 		boolean isDistanceRepeatFound=false;
	// 		for(Float key:keySet)
	// 		{
	// 			if(distanceRepeatMap.get(key)>1 && key<maxDistanceRepeated)
	// 			{
	// 				maxDistanceRepeated=key;
	// 				isDistanceRepeatFound=true;
	// 			}
	// 		}
	// 		
	// 		if( !isDistanceRepeatFound )
	// 		{
	// 			for(Float key:keySet)
	// 			{
	// 				if(key<maxDistanceRepeated)
	// 				{
	// 					maxDistanceRepeated=key;
	// 					isDistanceRepeatFound=true;
	// 				}
	// 			}
	// 		}
	// 
	// 		return maxDistanceRepeated ;
	// 	}

	/*public boolean isIndentSimilar(PDFLine thisOldLine, PDFLine nextOldLine, List<PDFLine> lines) 
	{
		boolean thisLineCentered = isLineCentered(thisOldLine, lines) ;
		boolean nextLineCentered = isLineCentered(nextOldLine, lines) ;

		if ( (!thisLineCentered && !nextLineCentered) || (thisLineCentered && nextLineCentered) )
			return true ;

		return false ;
	}*/

	// TODO Remove unused code found by UCDetector
	// 	public boolean isLineCentered(PDFLine line, List<PDFLine> lines) 
	// 	{
	// 		float pageMinStart = Float.MAX_VALUE ;
	// 		float pageMaxEnd = Float.MIN_VALUE ;
	// 
	// 		for ( int j=0 ; j<lines.size() ; j++ )
	// 		{
	// 			PDFLine thisLine = lines.get(j) ;
	// 
	// 			if ( thisLine.getX1() < pageMinStart )
	// 				pageMinStart = thisLine.getX1() ;
	// 
	// 			if ( thisLine.getX2() > pageMaxEnd )
	// 				pageMaxEnd = thisLine.getX2() ;
	// 		}
	// 
	// 		float pageMean = (pageMinStart + pageMaxEnd) / 2 ;
	// 
	// 		float lineMinStart = line.getX1() ;
	// 		float lineMaxEnd = line.getX2() ;
	// 		float lineMean = (lineMinStart + lineMaxEnd) / 2 ;
	// 
	// 		boolean meanCentered = lineMean >= pageMean*0.8 && lineMean <= pageMaxEnd*1.2 ;
	// 		boolean startGreaterThanThreshold = (lineMinStart - pageMinStart) >= ((pageMaxEnd-pageMinStart)*0.2) ;
	// 		boolean endLessThanThreshold = (pageMaxEnd-lineMaxEnd) >= ((pageMaxEnd-pageMinStart)*0.2) ;
	// 
	// 		if ( meanCentered && startGreaterThanThreshold && endLessThanThreshold )
	// 			return true ;
	// 
	// 		return false ;
	// 	}

	private boolean isLineNotCompletelySameCharacter(PDFLine thisOldLine)
	{
		HashSet<String> set = new HashSet<String>() ;

		for ( int i=0 ; i<thisOldLine.getChunks().size() ; i++ )
		{
			PDFChunk chunk = thisOldLine.getChunks().get(i) ;
			if ( chunk == null )
				continue ;

			List<PDFWord> words = chunk.getWords() ;

			for ( int j=0 ; j<words.size() ; j++ )
			{
				PDFWord word = words.get(j) ;
				if ( word == null )
					continue ;

				List<PDFCharacter> characters = word.getCharacters() ;

				for ( int k=0 ; k<characters.size() ; k++ )
				{
					PDFCharacter character = characters.get(k) ;
					if ( character == null )
						continue ;

					String str = character.getCharacter() ;
					if ( str.trim().equalsIgnoreCase("") )
						continue ;

					set.add(str.trim()) ;
				}
			}
		}

		if ( set.size() == 1 )
			return false ;

		return true ;
	}

	/*public boolean isFontValid(PDFLine thisLine, PDFLine nextLine) 
	{
		boolean thisLineUpperCase = thisLine.getLine().equals(thisLine.getLine().toUpperCase()) ;
		boolean nextLineUpperCase = nextLine.getLine().equals(nextLine.getLine().toUpperCase()) ;

		if ( !thisLineUpperCase && nextLineUpperCase )
		{
			if ( doesLineEndCleanly(thisLine) )
				return false ;
		}

		if ( (thisLineUpperCase && !nextLineUpperCase) || (!thisLineUpperCase && nextLineUpperCase) )
			return false ;

		HashSet<String> thisFonts = getFonts(thisLine) ;
		HashSet<String> nextFonts = getFonts(nextLine) ;

		boolean fontNameOK = ! ( !isOneContainedInAnother(thisFonts, nextFonts) && !isOneContainedInAnother(nextFonts, thisFonts) ) ;

		HashSet<Float> thisFontSize = getFontSizes(thisLine) ;
		HashSet<Float> nextFontSize = getFontSizes(nextLine) ;

		float thisFS = new ArrayList<Float>(thisFontSize).get(0).floatValue() ;
		float nextFS = new ArrayList<Float>(nextFontSize).get(0).floatValue() ;

		float diff = Math.abs(thisFS - nextFS) ;

		boolean fontSizeOK =  diff <= 1.0f ;

		if ( fontNameOK || fontSizeOK )
			return true ;

		return false ;
	}*/

	private boolean isFontValid(PDFLine thisLine, PDFLine nextLine) 
	{
		boolean isThisLineGarbage = isLineGarbage(thisLine) ;
		boolean isNextLineGarbage = isLineGarbage(nextLine) ;

		if ( isThisLineGarbage || isNextLineGarbage )
			return true ;

		if ( !isThisLineGarbage && !isNextLineGarbage )
		{
			boolean thisLineUpperCase = thisLine.getLine().equals(thisLine.getLine().toUpperCase()) ;
			boolean nextLineUpperCase = nextLine.getLine().equals(nextLine.getLine().toUpperCase()) ;

			if ( !thisLineUpperCase && nextLineUpperCase )
			{
				if ( doesLineEndCleanly(thisLine) )
					return false ;
			}

			if ( (thisLineUpperCase && !nextLineUpperCase) || (!thisLineUpperCase && nextLineUpperCase) )
				return false ;
		}

		HashSet<String> thisFonts = getFonts(thisLine) ;
		HashSet<String> nextFonts = getFonts(nextLine) ;

		if ( DEBUG )
		{
			System.out.println("THIS FONTS : " + thisFonts) ;
			System.out.println("NEXT FONTS : " + nextFonts) ;
		}

		boolean fontNameOK = ! ( !isOneContainedInAnother(thisFonts, nextFonts) && !isOneContainedInAnother(nextFonts, thisFonts) ) ;

		HashSet<Float> thisFontSize = getFontSizes(thisLine) ;
		HashSet<Float> nextFontSize = getFontSizes(nextLine) ;

		float thisFS = new ArrayList<Float>(thisFontSize).get(0).floatValue() ;
		float nextFS = new ArrayList<Float>(nextFontSize).get(0).floatValue() ;

		float diff = Math.abs(thisFS - nextFS) ;

		boolean fontSizeOK =  diff <= 1.0f ;

		if ( fontNameOK || fontSizeOK )
			return true ;

		return false ;
	}

	private boolean isLineGarbage(PDFLine thisLine)
	{
		HashSet<String> set = new HashSet<String>() ;

		StringTokenizer st = new StringTokenizer(thisLine.getLine(), "~`!@#$%^&*()_+-={}[]|\\:;\"'<>?,./ ") ;
		while ( st.hasMoreTokens() )
		{
			String token = st.nextToken() ;

			for ( int i=0 ; i<token.length() ; i++ )
			{
				String subString = token.substring(i, i+1) ;

				boolean isNumber = false ;
				try
				{
					Integer.parseInt(subString) ;
					isNumber = true ;
				}
				catch (Exception e) 
				{

				}

				if ( isNumber == true )
					continue ;

				set.add(subString.toLowerCase()) ;
			}
		}

		if ( set.size() > 2 )
			return true ;

		return false ;
	}

	private boolean doesLineEndCleanly(PDFLine thisLine) 
	{
		String strLine = new String(thisLine.getLine()) ;
		strLine = strLine.trim() ;

		if ( strLine.endsWith(".") || strLine.endsWith("!") || strLine.endsWith("?") || strLine.endsWith(".\"") )
			return true ;

		return false ;
	}

	private boolean isOneContainedInAnother(HashSet<String> thisFonts, HashSet<String> nextFonts) 
	{
		HashSet<String> set1 = new HashSet<String>(thisFonts) ;
		HashSet<String> set2 = new HashSet<String>(nextFonts) ;

		set1.removeAll(set2) ;

		if ( set1.size() == 0 )
			return true ;

		return false;
	}

	private HashSet<Float> getFontSizes(PDFLine thisLine) 
	{
		HashSet<Float> fonts = new HashSet<Float>() ;

		HashMap<Float, Integer> fontCountsMap = new HashMap<Float, Integer>() ;

		for ( int i=0 ; i<thisLine.getChunks().size() ; i++ )
		{
			PDFChunk chunk = thisLine.getChunks().get(i) ;
			List<PDFWord> words = chunk.getWords() ;

			for ( int j=0 ; j<words.size() ; j++ )
			{
				PDFWord word = words.get(j) ;
				List<PDFCharacter> characters = word.getCharacters() ;

				for ( int k=0 ; k<characters.size() ; k++ )
				{
					PDFCharacter character = characters.get(k) ;

					// String font = character.getFont().getName() /*+ "#" + character.getFont().getSize()*/ ;
					// fonts.add(font) ;

					Float size = character.getHeight() ;
					Integer count = fontCountsMap.containsKey(size) ? fontCountsMap.get(size) : new Integer(0) ;
					count = count.intValue() +1 ;

					fontCountsMap.put(size, count) ;
				}
			}
		}

		if ( DEBUG )
			System.out.println("FONT COUNTS MAP : " + fontCountsMap) ;

		List<Integer> counts = new ArrayList<Integer>(new TreeSet<Integer>(fontCountsMap.values())) ;
		Integer maxCount = counts.get(counts.size()-1) ;

		for ( Float size : fontCountsMap.keySet() )
		{
			Integer count = fontCountsMap.get(size) ;

			if ( count.intValue() != maxCount.intValue() )
				continue ;

			/*if ( font.contains("-Bold") )
				font = font.replaceAll("-Bold", "").trim() ;*/

			fonts.add(size) ;
		}

		if ( DEBUG )
			System.out.println("\tFONT SIZES : " + fonts) ;

		return fonts ;
	}

	private HashSet<String> getFonts(PDFLine thisLine) 
	{
		HashSet<String> fonts = new HashSet<String>() ;

		HashMap<String, Integer> fontCountsMap = new HashMap<String, Integer>() ;

		for ( int i=0 ; i<thisLine.getChunks().size() ; i++ )
		{
			PDFChunk chunk = thisLine.getChunks().get(i) ;
			List<PDFWord> words = chunk.getWords() ;

			for ( int j=0 ; j<words.size() ; j++ )
			{
				PDFWord word = words.get(j) ;
				List<PDFCharacter> characters = word.getCharacters() ;

				for ( int k=0 ; k<characters.size() ; k++ )
				{
					PDFCharacter character = characters.get(k) ;

					String font = character.getFont().getName() /*+ "#" + character.getFont().getSize()*/ ;
					// fonts.add(font) ;

					Integer count = fontCountsMap.containsKey(font) ? fontCountsMap.get(font) : new Integer(0) ;
					count = count.intValue() +1 ;

					fontCountsMap.put(font, count) ;
				}
			}
		}

		if ( DEBUG )
			System.out.println("FONT COUNTS MAP : " + fontCountsMap) ;

		List<Integer> counts = new ArrayList<Integer>(new TreeSet<Integer>(fontCountsMap.values())) ;
		Integer maxCount = counts.get(counts.size()-1) ;

		for ( String font : fontCountsMap.keySet() )
		{
			Integer count = fontCountsMap.get(font) ;

			if ( count.intValue() != maxCount.intValue() )
				continue ;

			if ( font != null && font.contains("-Bold") )
				font = font.replaceAll("-Bold", "").trim() ;

			fonts.add(font) ;
		}

		if ( DEBUG )
			System.out.println("\tFONTS : " + fonts) ;

		return fonts ;
	}

	private boolean isGapOK(PDFLine thisLine, PDFLine nextLine, PDFLine prevLine, float minX1, PDFLine secondNextLine, Pair<Float, Float> distanceRange) 
	{
		float gap = nextLine.getY1() - thisLine.getY2() ;

		if ( DEBUG )
		{
			System.out.println("This Gap : " + gap  + " : Distance-Range : " + distanceRange) ;
		}

		if ( gap < 0.0f )
		{
			if ( DEBUG )
				System.out.println("\tNEGATIVE GAP ... ") ;

			return true ;
		}

		/*float nextAvgHeight = computeAverageHeight(nextLine) ;

		if ( DEBUG )
		{
			System.out.println("AVG HEIGHTS : " + thisAvgHeight + " : " + nextAvgHeight) ;
		}

		float diff = Math.abs(thisAvgHeight - nextAvgHeight) ;

		if ( DEBUG )
		{
			System.out.println("DIFF : " + diff) ;
		}

		if ( diff >= 2.0f )
		{
			if ( DEBUG )
			{
				System.out.println("\tDIFF FAILED ... ") ;
			}

			return false ;
		}*/

		if ( tableCondition(thisLine,nextLine,prevLine,minX1,secondNextLine) )
		{
			if ( DEBUG )
				System.out.println("\t\tTABLE CONDITION FAILED ...") ;

			return false ;
		}

		///Commented as this condition fails in some cases and merges the paragraphs
		/*
		if ( gap <= (1.5*thisAvgHeight) )
		{
			if ( DEBUG )
			{
				System.out.println("\tPASSED ... ") ;
			}

			return true ;
		}*/

		if(distanceCondition(thisLine,nextLine,distanceRange))
		{
			if ( DEBUG )
				System.out.println("\t\tDISTANCE CONDITION PASSED ...") ;

			return true;
		}

		/*if( gapCondition(thisLine,nextLine,prevLine,minX1,secondNextLine) )
		{
			return true;
		}*/
		if ( DEBUG )
		{
			System.out.println("\tDEFAULT FAILED ... ") ;
		}

		return false ;
	}

	private boolean distanceCondition(PDFLine thisLine, PDFLine nextLine,Pair<Float,Float> distanceRange) 
	{
		// float thisDiff=Math.round(Math.abs(thisLine.getY2()-nextLine.getY1())*10.0)/10.0f;
		float thisDiff = nextLine.getY1()-thisLine.getY2() ;
		if ( thisDiff <= 0.0f )
			return true ;

		//float diff=Math.abs(thisDiff-(distance+0.2f));
		/*if(thisDiff<=(distanceRange+2.0f))
			return true;*/

		if ( thisDiff <= distanceRange.getB() )
			return true ;

		return false;
	}

	// TODO Remove unused code found by UCDetector
	// 	public boolean gapCondition(PDFLine thisLine, PDFLine nextLine,PDFLine prevLine, float minX1, PDFLine secondNextLine) 
	// 	{
	// 		if(thisLine!=null && nextLine!=null && (secondNextLine!=null || prevLine!=null))
	// 		{
	// 			if(secondNextLine!=null && prevLine!=null)
	// 			{
	// 				float prevDiff=Math.abs(prevLine.getY2()-thisLine.getY1());
	// 				float thisDiff=Math.abs(thisLine.getY2()-nextLine.getY1());
	// 				float nxtDiff=Math.abs(nextLine.getY2()-secondNextLine.getY1());
	// 				float prevMinusThis=Math.abs(prevDiff-thisDiff);
	// 				float thisMinusNext=Math.abs(thisDiff-nxtDiff);
	// 				if( prevMinusThis<2.0 && thisMinusNext<2.0 )
	// 				{
	// 					return true;
	// 				}
	// 				else if( prevMinusThis<2.1 )
	// 				{
	// 					return true;
	// 				}
	// 			}
	// 			else if(prevLine!=null)
	// 			{
	// 				float prevDiff=Math.abs(prevLine.getY2()-thisLine.getY1());
	// 				float thisDiff=Math.abs(thisLine.getY2()-nextLine.getY1());
	// 				float prevMinusThis=Math.abs(prevDiff-thisDiff);
	// 				if( prevMinusThis<2.1 )
	// 				{
	// 					return true;
	// 				}
	// 			}
	// 			else
	// 			{
	// 				float thisDiff=Math.abs(thisLine.getY2()-nextLine.getY1());
	// 				float nxtDiff=Math.abs(nextLine.getY2()-secondNextLine.getY1());
	// 				float thisMinusNext=Math.abs(thisDiff-nxtDiff);
	// 				if( thisMinusNext<2.1  )
	// 				{
	// 					return true;
	// 				}
	// 
	// 			}
	// 		}
	// 		return false;
	// 	}

	private boolean isIndentGreater(PDFLine thisLine, PDFLine nextLine, int threshold)
	{
		float indent=thisLine.getX1()-nextLine.getX1();
		if(indent<-threshold || indent>threshold)
		{
			return true;
		}
		return false;
	}

	private boolean isIndentLess(PDFLine thisLine, PDFLine nextLine, int threshold)
	{
		float indent=thisLine.getX1()-nextLine.getX1();
		if(indent>-threshold && indent<threshold)
		{
			return true;
		}
		return false;
	}

	private boolean tableCondition(PDFLine thisLine, PDFLine nextLine, PDFLine prevLine, float minX1, PDFLine secondNextLine) 
	{
		boolean isIndent=isIndentGreater(thisLine,nextLine,25);
		float diffX1=thisLine.getX1()-minX1;
		boolean isChunksValid = areChunkValid(nextLine,secondNextLine);
		if(prevLine!=null && prevLine.getChunks().size()==1 && thisLine.getChunks().size()==1 
				&& isChunksValid && isIndent && isIndentLess(thisLine,prevLine,5) && diffX1>-5 && diffX1<5)
		{
			if ( DEBUG )
			{
				System.out.println("Breaking-----------");
				System.out.println("Prev Line-"+prevLine.getLine());
				System.out.println("This Line-"+thisLine.getLine());
				System.out.println("Next Line-"+nextLine.getLine());
			}

			return true ;
		}
		return false;
	}

	private boolean areChunkValid(PDFLine nextLine, PDFLine secondNextLine) 
	{
		if(nextLine.getChunks().size()>2)
		{
			return true;
		}
		if(secondNextLine!=null && nextLine.getChunks().size()>1 && secondNextLine.getChunks().size()>2)
		{
			return true;
		}
		return false;
	}

	// TODO Remove unused code found by UCDetector
	// 	public float computeAverageHeight(PDFLine line) 
	// 	{
	// 		float sum = 0.0f ;
	// 		int count = 0 ;
	// 
	// 		List<PDFChunk> chunks = line.getChunks() ;
	// 		for ( int i=0 ; i<chunks.size() ; i++ )
	// 		{
	// 			PDFChunk chunk = chunks.get(i) ;
	// 
	// 			if ( chunk.getChunk().trim().equalsIgnoreCase("") )
	// 				continue ;
	// 
	// 			List<PDFWord> words = chunk.getWords() ;
	// 
	// 			for ( int j=0 ; j<words.size() ; j++ )
	// 			{
	// 				PDFWord word = words.get(j) ;
	// 
	// 				if ( word == null || word.getWord().trim().equalsIgnoreCase("") )
	// 					continue ;
	// 
	// 				List<PDFCharacter> characters = word.getCharacters() ;
	// 
	// 				for ( int k=0 ; k<characters.size() ; k++ )
	// 				{
	// 					PDFCharacter character = characters.get(k) ;
	// 
	// 					if ( character == null || character.getCharacter().trim().equalsIgnoreCase("") )
	// 						continue ;
	// 
	// 					sum = sum + character.getHeight() ;
	// 					count ++ ;
	// 				}
	// 			}
	// 		}
	// 
	// 		float avg = count == 0 ? 0.0f : (sum / count) ;
	// 
	// 		return avg ;
	// 	}

	private List<List<PDFLine>> createDefaultBlocks(List<PDFLine> lines) 
	{
		List<List<PDFLine>> ret = new ArrayList<List<PDFLine>>() ;

		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;

			List<PDFLine> lineBlock = new ArrayList<PDFLine>() ;
			lineBlock.add(line) ;

			ret.add(lineBlock) ;
		}

		return ret ;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public List<List<PDFLine>> getLineBlocks() {
		return lineBlocks;
	}

	public void setLineBlocks(List<List<PDFLine>> lineBlocks) {
		this.lineBlocks = lineBlocks;
	}

	public List<PDFBlock> getBlocks() {
		return blocks;
	}

	public void setBlocks(List<PDFBlock> blocks) {
		this.blocks = blocks;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}


	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception 
	{
		String fileName = "D:/Samples/MultiLanguage/English/" +"Financials.pdf";// "Audited - Bla LLC 2015_SaveAs.pdf" ;

		Integer pageNo = 1 ;

		PDDocument document = PDDocument.load(new File(fileName)) ;
		if ( document.isEncrypted() )
			document.openProtection(new StandardDecryptionMaterial("")) ;

		List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;

		PDPage page = pages.get(pageNo) ;

		PDFPageParser parser = new PDFPageParser(pageNo, page) ;
		parser.run() ;
		PageParse parse = parser.getParse() ;

		List<PDFLine> pageLines = parser.getParse().getPageLines() ;
		System.out.println("\n\n\nPrinting Lines .... \n") ;
		for ( int i=0 ; i<pageLines.size() ; i++ )
		{
			PDFLine line = pageLines.get(i) ;
			System.out.println("\tLine " + i + " : " + line.getLine() + " : " + line.getHeight()) ;
		}

		List<PDFBlock> blocks = parse.getPageBlocks() ;

		System.out.println("\n\n\nPrinting Blocks .... \n") ;
		for ( int i=0 ; i<blocks.size() ; i++ )
		{
			System.out.println("\n\n\n") ;
			PDFBlock block = blocks.get(i) ;
			System.out.println(block.getBlockString()) ;

			List<PDFLine> lines = block.getLines() ;
			for ( int j=0 ; j<lines.size() ; j++ )
			{
				PDFLine line = lines.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;

				for ( int k=0 ; k<chunks.size() ; k++ )
				{
					PDFChunk chunk = chunks.get(k) ;
					System.out.print("'" + chunk.getChunk()+"' [" + chunk.getX1() + ", " + 
							chunk.getY1() + ", " + chunk.getX2() + ", " + chunk.getY2() + "]") ;
				}

				System.out.println() ;
			}
		}
	}

	private boolean checkLineInCurrentCell ( PDFLine thisLine, PDFLine nextLine, Pair<Float, Float> tableDistanceRange, Map<Integer, Pair<Float, Float>> lineDistanceMap )
	{
		if(tableDistanceRange.getA()>0.0f && tableDistanceRange.getB()>0.0f)
		{
			if(nextLine.getY1()>tableDistanceRange.getA() && nextLine.getY2()<tableDistanceRange.getB())
			{
				System.out.println("Next line is present in current cell");

				return true;
			}

			System.out.println("Checking is next line present in table cells");
			Pair<Float,Float> pair2 = isLineInCell(nextLine,lineDistanceMap);

			if(pair2.getA()>0.0f && pair2.getB()>0.0f)
			{
				tableDistanceRange.setA(pair2.getA());
				tableDistanceRange.setB(pair2.getB());
			}
			//
			return false;
		}

		System.out.println("Checking is first line appears in table cells");
		Pair<Float,Float> pair1 = isLineInCell(thisLine,lineDistanceMap);

		if(pair1.getA()>0.0f && pair1.getB()>0.0f)
		{
			System.out.println("this line is present in cell"+thisLine.getLineString());

			if(nextLine.getY1()>pair1.getA() && nextLine.getY2()<pair1.getB())
			{
				System.out.println("Next line is present in current cell");

				tableDistanceRange.setA(pair1.getA());
				tableDistanceRange.setB(pair1.getB());
				return true;
			}
		}

		System.out.println("Checking is next line present in table cells");
		Pair<Float,Float> pair2 = isLineInCell(nextLine,lineDistanceMap);

		if(pair2.getA()>0.0f && pair2.getB()>0.0f)
		{
			tableDistanceRange.setA(pair2.getA());
			tableDistanceRange.setB(pair2.getB());
		}

		return false;
	}

	private boolean isTabularNumberOK ( PDFLine thisLine, List<PDFLine> thisGroup )
	{
		List<PDFLine> group = new ArrayList<PDFLine>(thisGroup) ;
		group.remove(thisLine) ;

		if ( group.size() == 0 )
			return true ;

		for ( PDFChunk thisChunk : thisLine.getChunks() )
		{
			if ( thisChunk.getChunk().trim().equalsIgnoreCase("") )
				continue ;

			if ( !thisChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
				continue ;

			for ( PDFLine groupLine : group )
			{
				for ( PDFChunk nextChunk : groupLine.getChunks() )
				{
					if ( nextChunk.getChunk().trim().equalsIgnoreCase("") 
							|| !nextChunk.getChunk().replaceAll("[0-9\\.,\\(\\)\\-]", "").trim().equalsIgnoreCase("") )
						continue ;

					if ( thisChunk.getX2() < nextChunk.getX1() || thisChunk.getX1() > nextChunk.getX2() )
						continue ;

					System.out.println("Selecting Chunks: " + thisChunk + "\t" + nextChunk) ;

					return false ;
				}
			}
		}

		return true ;
	}

	private boolean isGapCloseCompareToSecondNextLine ( PDFLine thisLine, PDFLine nextLine, PDFLine secondNextLine, List<PDFLine> thisGroup, Pair<Float, Float> distanceRange )
	{
		float gap = nextLine.getY1() - thisLine.getY2();

		if(gap>distanceRange.getB())
			return true;

		if(gap<=distanceRange.getB() && ((distanceRange.getB()-gap)<0.5))
		{
			if(secondNextLine != null)
			{
				float gap2 = secondNextLine.getY1() - nextLine.getY2();

				if(gap2<gap && (gap-gap2)>0.5)//>0.5
				{
					return false;
				}
			}
		}
		return true;
	}

	private static List<PDFBlock> splitBlocksBasedOnBold(PDFBlock block) 
	{
		List<PDFBlock> ret = new ArrayList<PDFBlock>();

		List<List<PDFLine>> newLineBlocks = new ArrayList<List<PDFLine>>();

		List<PDFLine> thisBlock = new ArrayList<PDFLine>();
		PDFLine thisBlockFirstLine = null;
		boolean isFirstLineBold = false;
		for (int i = 0; i < block.getLines().size(); i++) 
		{
			PDFLine line = block.getLines().get(i);

			if (thisBlockFirstLine == null) 
			{
				thisBlockFirstLine = line;
				thisBlock.add(line);
				isFirstLineBold = lineContainsBold(line);

				continue;
			}

			boolean thisLineBold = lineContainsBold(line);
			if ((thisLineBold && !isFirstLineBold)
					|| (!thisLineBold && isFirstLineBold)) 
			{
				newLineBlocks.add(new ArrayList<PDFLine>(thisBlock));

				thisBlock = new ArrayList<PDFLine>();

				thisBlock.add(line);
				thisBlockFirstLine = line;
				isFirstLineBold = new Boolean(thisLineBold);

				continue;
			}

			thisBlock.add(line);
		}

		if (thisBlock.size() != 0) 
		{
			newLineBlocks.add(new ArrayList<PDFLine>(thisBlock));
			thisBlock = new ArrayList<PDFLine>();
		}

		for (int i = 0; i < newLineBlocks.size(); i++) 
		{
			List<PDFLine> thisLines = newLineBlocks.get(i);
			if (thisLines.size() == 0)
				continue;

			PDFBlock newBlock = new PDFBlock(thisLines.get(0).getPageNo(), thisLines);
			ret.add(newBlock);
		}

		return ret;
	}

	private static boolean lineContainsBold(PDFLine line) {
		List<PDFCharacter> allCharacters = new ArrayList<PDFCharacter>();

		for (int i = 0; i < line.getChunks().size(); i++) {
			PDFChunk chunk = line.getChunks().get(i);

			for (int j = 0; j < chunk.getWords().size(); j++) {
				PDFWord word = chunk.getWords().get(j);

				if (word.getWord().trim().equalsIgnoreCase("")
						/*|| word.getWord().trim().replaceAll("[^a-zA-Z0-9]", "")
                                .trim().equalsIgnoreCase("")*/)
					continue;

				allCharacters.addAll(word.getCharacters());
			}
		}

		int boldCount = 0;
		for (int i = 0; i < allCharacters.size(); i++) {
			PDFCharacter character = allCharacters.get(i);
			PDFFont font = character.getFont();
			String fontName = font.getName();

			if (fontName != null && fontName.toLowerCase().contains("bold"))
				boldCount++;
		}

		float percent = ((float) boldCount / (float) allCharacters.size());

		if (percent >= 0.5)
			return true;

		return false;
	}

	private boolean isLineEndsWithColon ( PDFLine thisLine, PDFLine nextLine )
	{
		if(thisLine!=null && !thisLine.getLine().trim().equalsIgnoreCase(""))
		{
			if(thisLine.getLine().trim().endsWith(":") || thisLine.getLine().trim().endsWith("："))
			{
				return true;
			}
		}

		/*if(nextLine!=null && !nextLine.getLine().trim().equalsIgnoreCase(""))
		{
			if(nextLine.getLine().trim().endsWith(":") || nextLine.getLine().trim().endsWith("："))
			{
				return true;
			}
		}*/

		return false;
	}
}
