package com.rage.extraction.pdf;

import java.io.Serializable;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.TreeSet;

import org.apache.pdfbox.util.TextPosition;

import com.rage.extraction.statements.attributes.StatementAttributes;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.ontology.TimePeriodOntology;
import com.rage.extraction.statements.uitls.AccentsRemover;


public class PDFCharacter extends PDFBoundedObject implements Serializable
{
	private static final long serialVersionUID = -4225194350320128858L;

	private Integer pageNo ;
	private String character ;
	private PDFFont font ;
	private int[] codePoints ;
	private float direction ;
	private boolean isDiacritic ;
	private float pageWidth ;
	private float pageHeight ;
	private boolean invertX ;
	private boolean invertY ;
	String fontName, fontFamily;
	float fontSize, fontSizeInPt, widthOfSpace;
	boolean isBold, isItalic;
	int multiColumnIndex;

	private static LinkedHashSet<String> latinLanguageList;

	// TODO Remove unused code found by UCDetector
	// 	public static PDFCharacter createPDFCharacter(PDFCharacter sampleCharacter, float x1, float y1, float x2, float y2, String text)
	// 	{
	// 		PDFCharacter spaceCharacter = new PDFCharacter(sampleCharacter.getPageNo(), null, -1.0f, -1.0f, false, false) ;
	// 		spaceCharacter.setPageNo(sampleCharacter.getPageNo()) ;
	// 		spaceCharacter.setBounds("", x1, y1, x2, y2) ;
	// 		spaceCharacter.setCharacter(text) ;
	// 		spaceCharacter.setDiacritic(false) ;
	// 		spaceCharacter.setDirection(sampleCharacter.getDirection()) ;
	// 		spaceCharacter.setFont(sampleCharacter.getFont()) ;
	// 		
	// 		return spaceCharacter ;
	// 	}


	private void getLanguages()
	{
		if(getLatinLanguageList()==null)
		{
			String fileName = "resource/section-identification/languageSpecificRules.txt" ;
			if(TimePeriodOntology.getLanguageSpecificMap()==null)
			{
				TimePeriodOntology.loadRules(fileName) ;
			}

			if(TimePeriodOntology.getLanguageSpecificMap().containsKey("[Latin-Languages]"))
				setLatinLanguageList(TimePeriodOntology.getLanguageSpecificMap().get("[Latin-Languages]"));

		}
	}

	public PDFCharacter(Integer pageNo, TextPosition textPosition, float pageWidth, float pageHeight, boolean invertX, boolean invertY)
	{	
		setPageNo(pageNo) ;
		setPageWidth(pageWidth) ;
		setPageHeight(pageHeight) ;
		setInvertX(invertX) ;
		setInvertY(invertY) ;
		
		if ( textPosition == null )
			return ;
		
		setCodePoints(textPosition.getCodePoints()) ;
		setDirection(textPosition.getDir()) ;
		setDiacritic(textPosition.isDiacritic()) ;
		
		float x3 = textPosition.getXDirAdj() ;
		float y3 = textPosition.getYDirAdj() ;
		float width = textPosition.getWidthDirAdj() ;
		float height = textPosition.getHeightDir() ;

		// System.out.println("CHARACTER X AND Y SCALES : " + textPosition.getXScale() + ", " + textPosition.getYScale()) ;

		float x1 = x3 ;
		float y1 = y3 - height ;
		float x2 = x3 + width ;
		float y2 = y3 ;

		if ( invertX )
		{
			x1 = getPageWidth() > x1 ? (getPageWidth() - x1) : (x1 - getPageWidth()) ;
			x2 = getPageWidth() > x2 ? (getPageWidth() - x2) : (x2 - getPageWidth()) ;
		}

		if ( invertY )
		{			
			y1 = getPageHeight() > y1 ? (getPageHeight() - y1) : (y1 - getPageHeight()) ;
			y2 = getPageHeight() > y2 ? (getPageHeight() - y2) : (y2 - getPageHeight()) ;	
		}
		
		// TODO: Invert Y-axis if direction is 180 degree.
		if ( getDirection() == 180.0f )
		{
			// System.out.print("Old-Y1=" + y1 + ", Old-Y2=" + y2 + "\t\t\t") ;
			float oldY1 = y1 ;
			float oldY2 = y2 ;
			y1 = pageHeight - oldY2 ;
			y2 = pageHeight - oldY1 ;
			// System.out.println("New-Y1=" + y1 + ", New-Y2=" + y2) ;
		}
		
		/*if ( x1 > x2 )
		{
			float temp = x1 ;
			x1 = x2 ;
			x2 = temp ;
		}

		if ( y1 > y2 )
		{
			float temp = y1 ;
			y1 = y2 ;
			y2 = temp ;
		}*/

		setBounds("PDF-CHARACTER", x1, y1, x2, y2) ;

		String character = textPosition.getCharacter() ;
		character = character.equalsIgnoreCase("�") ? "'" : character ;
		character = character.replaceAll("�", "-");

		character = AccentsRemover.removeAccents(character);
		getLanguages();
		if(getLatinLanguageList()!=null && getLatinLanguageList().contains(FinancialStatementExtractor.getLanguage().trim().toLowerCase()))
			character = character.replaceAll("[^\\xA2-\\xA5\\x20-\\x7E�]+", " ") ;
		//character = character.replaceAll("[^\\x20-\\x7E]+", " ") ;
		//[^\\xA2-\\xA5\\x20-\\x7E�]
		if(StatementAttributes.getAttributeMap()==null)
		{
			try {
				StatementAttributes st = new StatementAttributes();
			} catch (Exception e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
			}
		}

		try {

			if(StatementAttributes.getAttributeMap().get("[Number-Names]")!=null) 
			{

				for(String keyValue : StatementAttributes.getAttributeMap().get("[Number-Names]"))
				{
					String[] keyValues =  keyValue.split("##########");
					if(keyValues.length==2)
					{
						if(character.contains(keyValues[1].trim()))
						{
							character = keyValues[0].trim();
							break;
						}

					}
				}

			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}



		setCharacter(character) ;

		setFont(new PDFFont(textPosition.getFont().getBaseFont(), textPosition.getFont().getSubType(), textPosition.getFontSizeInPt())) ;
	}

	
	public PDFCharacter(Integer pageNo,float x1,float x2,float y1,float y2,String charStr,String fontName,String fontFamily
			,float fontSize,float fontSizeInPt,float widthOfSpace,boolean isBold,boolean isItalic,int multiColIndex,float width,float height)
	{	
		this.pageNo=pageNo;
		this.setX1(x1);
		this.setX2(x2);
		this.setY1(y1);
		this.setY2(y2);
		this.character=charStr;
		this.fontName=fontName;
		this.fontFamily=fontFamily;
		this.fontSize=fontSize;
		this.fontSizeInPt=fontSizeInPt;
		this.widthOfSpace=widthOfSpace;
		this.isBold=isBold;
		this.isItalic=isItalic;
		this.multiColumnIndex=multiColIndex;
		this.setWidth(width);
		this.setHeight(height);
		setFont(new PDFFont(fontName, fontFamily, fontSizeInPt)) ;
		
	}
	
	public String toCompleteString()
	{
		return getCharacter() + " : COORDINATES : " + super.toString() + " : DIRECTION : " + getDirection() + 
				" : DIMENSION : [" + getWidth() + ", " + getHeight() + "] : FONTS : " + getFont().toString() ;
	}

	@Override
	public String toString() 
	{
		return getCharacter() ;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result
				+ ((character == null) ? 0 : character.hashCode());
		result = prime * result + Arrays.hashCode(codePoints);
		result = prime * result + Float.floatToIntBits(direction);
		result = prime * result + ((font == null) ? 0 : font.hashCode());
		result = prime * result + (isDiacritic ? 1231 : 1237);
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFCharacter other = (PDFCharacter) obj;
		if (character == null) {
			if (other.character != null)
				return false;
		} else if (!character.equals(other.character))
			return false;
		if (!Arrays.equals(codePoints, other.codePoints))
			return false;
		if (Float.floatToIntBits(direction) != Float
				.floatToIntBits(other.direction))
			return false;
		if (font == null) {
			if (other.font != null)
				return false;
		} else if (!font.equals(other.font))
			return false;
		if (isDiacritic != other.isDiacritic)
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		return true;
	}

	public String getCharacter() 
	{
		return character;
	}

	public void setCharacter(String character) {
		this.character = character;
	}

	public int[] getCodePoints() {
		return codePoints;
	}

	public void setCodePoints(int[] codePoints) {
		this.codePoints = codePoints;
	}

	public float getDirection() {
		return direction;
	}

	public void setDirection(float direction) {
		this.direction = direction;
	}

	public boolean isDiacritic() {
		return isDiacritic;
	}

	public void setDiacritic(boolean isDiacritic) {
		this.isDiacritic = isDiacritic;
	}

	public PDFFont getFont() {
		return font;
	}

	public void setFont(PDFFont font) {
		this.font = font;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public float getPageWidth() {
		return pageWidth;
	}

	public void setPageWidth(float pageWidth) {
		this.pageWidth = pageWidth;
	}

	public float getPageHeight() {
		return pageHeight;
	}

	public void setPageHeight(float pageHeight) {
		this.pageHeight = pageHeight;
	}

	public boolean isInvertX() {
		return invertX;
	}

	public void setInvertX(boolean invertX) {
		this.invertX = invertX;
	}

	public boolean isInvertY() {
		return invertY;
	}

	public void setInvertY(boolean invertY) {
		this.invertY = invertY;
	}


	public static LinkedHashSet<String> getLatinLanguageList() {
		return latinLanguageList;
	}


	public void setLatinLanguageList(LinkedHashSet<String> latinLanguageList) {
		this.latinLanguageList = latinLanguageList;
	}
	
	public int getMultiColumnIndex ( )
	{
		return multiColumnIndex;
	}


	public void setMultiColumnIndex ( int multiColumnIndex )
	{
		this.multiColumnIndex = multiColumnIndex;
	}
	
	public float getWidthOfSpace() {
		return widthOfSpace;
	}

	public void setWidthOfSpace(float widthOfSpace) {
		this.widthOfSpace = widthOfSpace;
	}
}
