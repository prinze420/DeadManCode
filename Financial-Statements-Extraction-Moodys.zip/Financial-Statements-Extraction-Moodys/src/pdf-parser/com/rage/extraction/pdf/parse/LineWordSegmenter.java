package com.rage.extraction.pdf.parse;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class LineWordSegmenter 
{
	private static Boolean GAPS_DIFFS_DEBUG = Boolean.FALSE ;
	private static Boolean CHUNKS_OUTPUT_DEBUG = Boolean.FALSE ;
	private static Boolean SINGLE_CHARACTERS_CHUNK_DEBUG = Boolean.FALSE ;
	private static Boolean BREAK_TO_RANGE_DEBUG = Boolean.FALSE ;
	private static Boolean INTERNAL_DEBUG = Boolean.FALSE ;

	private static Float WORD_SEGMENT_X_GAP_THRESHOLD = 2.0f ;
	private static Float CHUNK_SEGMENT_X_GAP_THRESHOLD = 10.0f ;
	
	private Integer pageNo ;
	private List<List<PDFCharacter>> characterLines ;
	private List<List<List<PDFWord>>> wordChunkLines ;
	private List<List<PDFWord>> wordLines ;
	private List<List<PDFChunk>> chunkLines ;
	private List<PDFLine> lines ;
	
	LineWordSegmenter(Integer pageNo, List<List<PDFCharacter>> characterLines)
	{
		setPageNo(pageNo) ;
		setCharacterLines(characterLines) ;
		setWordChunkLines(new ArrayList<List<List<PDFWord>>>()) ;
		setWordLines(new ArrayList<List<PDFWord>>()) ;
		setChunkLines(new ArrayList<List<PDFChunk>>()) ;
		setLines(new ArrayList<PDFLine>()) ;
	}

	void run()
	{
		for ( int i=0 ; i<getCharacterLines().size() ; i++ )
		{
			List<PDFCharacter> charactersLine = getCharacterLines().get(i) ;

			if ( INTERNAL_DEBUG )
				System.out.println("\n\nLINE " + i + " : " + charactersLine) ;

			List<List<PDFCharacter>> characterChunksLine = createCharacterChunksLine(charactersLine, CHUNK_SEGMENT_X_GAP_THRESHOLD) ;
			
			if ( INTERNAL_DEBUG )
				System.out.println("\tCHUNKS LINE " + i + " : AFTER CRESTING CHUNKS : " + characterChunksLine) ;

			List<List<List<PDFCharacter>>> characterWordsChunksLine = createCharacterWordsChunksLine(characterChunksLine) ;
			
			if ( INTERNAL_DEBUG )
				System.out.println("\tWORDS CHUNKS LINE " + i + " : AFTER CREATING WORDS AS LIST OF CHARACTERS : " + characterWordsChunksLine) ;

			List<List<PDFWord>> wordsChunkLine = createWordsChunkLine(characterWordsChunksLine) ;
			getWordChunkLines().add(wordsChunkLine) ;

			if ( INTERNAL_DEBUG )
				System.out.println("\tWORDS CHUNK LINE " + i + " : AFTER CREATING WORDS : " + wordsChunkLine) ;

			List<PDFWord> wordsLine = createWordsLine(wordsChunkLine) ;
			getWordLines().add(wordsLine) ;

			if ( INTERNAL_DEBUG )
				System.out.println("\tWORDS LINES " + i + " : AFTER CREATING LINES : " + wordsLine) ;

			List<PDFChunk> chunksLine = createChunksLine(wordsChunkLine) ;
			getChunkLines().add(chunksLine) ;

			if ( INTERNAL_DEBUG )
				System.out.println("\tWORDS LINES " + i + " : " + chunksLine) ;

			PDFLine line = new PDFLine(i,getPageNo(), chunksLine) ;
			getLines().add(line) ;

			if ( INTERNAL_DEBUG )
				System.out.println("\tWORDS LINES " + i + " : " + line) ;
		}
	}

	private List<PDFChunk> createChunksLine(List<List<PDFWord>> wordsChunkLine) 
	{
		List<PDFChunk> ret = new ArrayList<PDFChunk>() ;

		for ( int i=0 ; i<wordsChunkLine.size() ; i++ )
		{
			List<PDFWord> words = wordsChunkLine.get(i) ;
			PDFChunk chunk = new PDFChunk(getPageNo(), words) ;
			ret.add(chunk) ;
		}

		return ret ;
	}

	private List<PDFWord> createWordsLine(List<List<PDFWord>> wordsChunkLine) 
	{
		List<PDFWord> ret = new ArrayList<PDFWord>() ;

		for ( int i=0 ; i<wordsChunkLine.size() ; i++ )
		{
			List<PDFWord> thisChunk = wordsChunkLine.get(i) ;
			ret.addAll(thisChunk) ;
		}

		return ret ;
	}

	private List<List<PDFWord>> createWordsChunkLine(List<List<List<PDFCharacter>>> characterWordsChunksLine) 
	{
		List<List<PDFWord>> ret = new ArrayList<List<PDFWord>>() ;

		for ( int i=0 ; i<characterWordsChunksLine.size() ; i++ )
		{
			List<List<PDFCharacter>> thisCharactersChunk = characterWordsChunksLine.get(i) ;

			List<PDFWord> thisWordsChunk = new ArrayList<PDFWord>() ;
			for ( int j=0 ; j<thisCharactersChunk.size() ; j++ )
			{
				List<PDFCharacter> characters = thisCharactersChunk.get(j) ;
				PDFWord word = new PDFWord(getPageNo(), characters) ;
				thisWordsChunk.add(word) ;
				
				/*PDFCharacter firstCharacter = characters.get(0) ;
				PDFCharacter lastCharacter = characters.get(characters.size()-1) ;
				System.out.println("CREATED Word: " + word.getWord() + " [" + word.getX1() + ", " + word.getX2() + "]" + " :: " + firstCharacter.toCompleteString() + " : " + lastCharacter.toCompleteString()) ;*/
			}

			ret.add(thisWordsChunk) ;
		}

		return ret ;
	}

	private List<List<List<PDFCharacter>>> createCharacterWordsChunksLine(List<List<PDFCharacter>> chunks) 
	{
		List<List<List<PDFCharacter>>> ret = new ArrayList<List<List<PDFCharacter>>>() ;
		
		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			List<PDFCharacter> chunk = chunks.get(i) ;
			List<List<PDFCharacter>> gapWordsChunk = createCharacterChunksLine(chunk, WORD_SEGMENT_X_GAP_THRESHOLD) ;
			
			List<List<PDFCharacter>> wordsChunk = new ArrayList<List<PDFCharacter>>() ;

			for ( int j=0 ; j<gapWordsChunk.size() ; j++ )
			{
				List<PDFCharacter> thisChunk = gapWordsChunk.get(j) ;
				List<List<PDFCharacter>> thisWordsChunk = createWordsChunk(thisChunk) ;
				wordsChunk.addAll(thisWordsChunk) ;
			}

			ret.add(wordsChunk) ;
		}

		return ret ;
	}

	private List<List<PDFCharacter>> createWordsChunk(List<PDFCharacter> chunk) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		List<PDFCharacter> thisWord = new ArrayList<PDFCharacter>() ;
		for ( int j=0 ; j<chunk.size() ; j++ )
		{
			PDFCharacter character = chunk.get(j) ;

			if ( character.getCharacter().trim().equalsIgnoreCase("") )
			{
				if ( thisWord.size() != 0 )
				{
					ret.add(new ArrayList<PDFCharacter>(thisWord)) ;

					thisWord = new ArrayList<PDFCharacter>() ;
					thisWord.add(character) ;
					ret.add(new ArrayList<PDFCharacter>(thisWord)) ;

					thisWord = new ArrayList<PDFCharacter>() ;

					continue ;
				}

				ret.add(new ArrayList<PDFCharacter>(thisWord)) ;

				thisWord = new ArrayList<PDFCharacter>() ;
				thisWord.add(character) ;
				ret.add(new ArrayList<PDFCharacter>(thisWord)) ;

				thisWord = new ArrayList<PDFCharacter>() ;
				continue ;
			}

			thisWord.add(character) ;
		}

		if ( thisWord.size() != 0 )
			ret.add(new ArrayList<PDFCharacter>(thisWord)) ;


		///Changes. Tables having dots. Dots are removed and is replaced with empty character " ".
		for(int i=0;i<ret.size();i++)
		{
			List<PDFCharacter> characters=ret.get(i);
			String charString="";
			for(int j=0;j<characters.size();j++)
			{
				charString=charString+characters.get(j).getCharacter();
			}
			Pattern p=Pattern.compile("(\\.){3,}");
			Matcher m=p.matcher(charString);
			TreeMap<Integer,Integer> indexMap=new TreeMap<Integer, Integer>();
			while(m.find())
			{
				indexMap.put(m.start(),m.end());
			}
			for(Integer key:indexMap.keySet())
			{
				int end=indexMap.get(key);
				for(int j=0;j<characters.size();j++)
				{
					if(j>=key && j<end)
					{
						characters.get(j).setCharacter(" ");
					}
				}
			}
		}

		return ret ;
	}

	private List<List<PDFCharacter>> createCharacterChunksLine(List<PDFCharacter> line, float threshold) 
	{
		if ( GAPS_DIFFS_DEBUG )
			System.out.println("\n\nPROCESSING LINE : " + line) ;

		List<List<PDFCharacter>> chunksLine = createDefaultChunks(line) ;
		
		List<Float> gaps = computeGaps(chunksLine) ;
		List<Float> diffs = computeDiffs(gaps) ;

		if ( GAPS_DIFFS_DEBUG )
		{
			System.out.print("\tGAPS : ") ;
			for ( int i=0 ; i<gaps.size() ; i++ )
			{
				PDFCharacter thisCharacter = line.get(i) ;
				PDFCharacter nextCharacter = line.get(i+1) ;
				System.out.print("[" + thisCharacter.getCharacter() + "-" + nextCharacter.getCharacter() + " = " + gaps.get(i) + "]") ;
			}
			System.out.println() ;

			System.out.print("\tDIFFS : ") ;
			for ( int i=0 ; i<diffs.size() ; i++ )
			{
				PDFCharacter thisCharacter = line.get(i) ;
				PDFCharacter nextCharacter = line.get(i+1) ;
				PDFCharacter nextNextCharacter = line.get(i+2) ;
				System.out.print("[" + thisCharacter.getCharacter() + "-" + nextCharacter.getCharacter() + "-" + nextNextCharacter.getCharacter() + " = " + diffs.get(i) + "]") ;
			}
			
			System.out.println() ;
		}
		
		chunksLine = createChunksOnDiffs(chunksLine, gaps, diffs, threshold) ;

		if ( CHUNKS_OUTPUT_DEBUG )
		{
			System.out.println("\t\tTHESE CHUNKS BEFORE HANDLING SINGLE CHARACTERS : ") ;
			for ( int i=0 ; i<chunksLine.size() ; i++ )
			{
				List<PDFCharacter> thisWord = chunksLine.get(i) ;
				System.out.println("\t\t\tTHIS CHUNK : " + thisWord) ;
			}
		}

		chunksLine = handleSingleCharacters(chunksLine) ;
		chunksLine = handleDots(chunksLine);

		if ( CHUNKS_OUTPUT_DEBUG )
		{
			System.out.println("\t\tTHESE CHUNKS AFTER  HANDLING SINGLE CHARACTERS : ") ;
			for ( int i=0 ; i<chunksLine.size() ; i++ )
			{
				List<PDFCharacter> thisWord = chunksLine.get(i) ;
				System.out.println("\t\t\tTHIS CHUNK : " + thisWord) ;
			}
		}

		return chunksLine ;
	}

	private List<List<PDFCharacter>> handleDots(List<List<PDFCharacter>> chunksLine) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;
		for ( int i=0 ; i<chunksLine.size() ; i++ )
		{
			List<PDFCharacter> characters=chunksLine.get(i);
			String charString="";
			for(int j=0;j<characters.size();j++)
			{
				charString=charString+characters.get(j).getCharacter();
			}
			Pattern p=Pattern.compile("(\\.){3,}");
			Matcher m=p.matcher(charString);
			TreeMap<Integer,Integer> indexMap=new TreeMap<Integer, Integer>();
			boolean isFound=false;
			while(m.find())
			{
				indexMap.put(m.start(),m.end());
				isFound=true;
			}
			List<PDFCharacter> newChunk = new ArrayList<PDFCharacter>() ;
			if(isFound)
			{
				TreeMap<Integer,List<PDFCharacter>> keyCharList=new TreeMap<Integer, List<PDFCharacter>>();
				for(Integer key:indexMap.keySet())
				{
					int end=indexMap.get(key);
					List<PDFCharacter> tempChunk = new ArrayList<PDFCharacter>() ;
					for(int j=0;j<characters.size();j++)
					{
						if(j>=key && j<end)
						{
							tempChunk.add(characters.get(j));
						}
					}
					keyCharList.put(key, tempChunk);
				}

				for(int j=0;j<characters.size();j++)
				{
					if(indexMap.keySet().contains(j))
					{
						if(newChunk.size()>0)
						{
							List<PDFCharacter> tempChunk = new ArrayList<PDFCharacter>() ;
							tempChunk.addAll(newChunk);
							ret.add(tempChunk);
							newChunk.clear();
						}
						ret.add(keyCharList.get(j));
						j=indexMap.get(j);
						continue;
					}
					newChunk.add(characters.get(j));
				}
				if(newChunk.size()>0)
				{
					ret.add(newChunk);
				}
			}
			else
			{
				ret.add(characters);
				continue;
			}
		}

		return ret;
	}

	private List<List<PDFCharacter>> handleSingleCharacters(List<List<PDFCharacter>> chunksLine) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		float avgGap = findAverageGap(chunksLine) ;

		boolean nextChunkAdded = false ;
		List<PDFCharacter> newChunk = new ArrayList<PDFCharacter>() ;
		for ( int i=0 ; i<chunksLine.size()-1 ; i++ )
		{
			List<PDFCharacter> thisChunk = chunksLine.get(i) ;
			List<PDFCharacter> nextChunk = chunksLine.get(i+1) ;

			if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
			{
				System.out.println("\n\n") ;
				System.out.println("THIS CHUNK : " + thisChunk) ;
				System.out.println("NEXT CHUNK : " + nextChunk) ;
			}

			if(nextChunkAdded)
			{
				nextChunkAdded=false;
				continue;
			}

			if ( ! (thisChunk.size() == 1 && nextChunk.size() == 1) )
			{
				if ( newChunk.size() != 0 )
				{
					if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
						System.out.println("\tADDING OLD CHUNK INTO RET ... " + newChunk) ;

					ret.add(new ArrayList<PDFCharacter>(newChunk)) ;
					newChunk = new ArrayList<PDFCharacter>() ;
				}

				if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
					System.out.println("\tADDING THIS CHUNK INTO RET ... " + thisChunk) ;

				ret.add(thisChunk) ;

				nextChunkAdded = false ;

				continue ;
			}

			float gap = nextChunk.get(0).getX1() - thisChunk.get(thisChunk.size()-1).getX2() ;

			if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
				System.out.println("\tAVG GAP ... " + avgGap + " : THIS GAP ... " + gap) ;

			if ( gap <= avgGap )
			{
				if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
					System.out.println("\t\tADDING BOTH CHUNKS INTO THIS NEW CHUNK : " + thisChunk + " ::: " + nextChunk) ;

				if ( !newChunk.contains(thisChunk) )
					newChunk.addAll(thisChunk) ;

				if ( !newChunk.contains(nextChunk) )
					newChunk.addAll(nextChunk) ;

				nextChunkAdded = true ;

				continue ;
			}

			if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
				System.out.println("\tADDING NEW CHUNK INTO RET : " + newChunk) ;

			if ( newChunk.size() != 0 )
			{
				ret.add(new ArrayList<PDFCharacter>(newChunk)) ;
				newChunk = new ArrayList<PDFCharacter>() ;

				if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
					System.out.println("\tADDING THIS CHUNK INTO RET : " + thisChunk) ;

			}

			newChunk.addAll(thisChunk) ;
			ret.add(new ArrayList<PDFCharacter>(newChunk)) ;
			newChunk = new ArrayList<PDFCharacter>() ;

			nextChunkAdded = false ;
		}

		if ( newChunk.size() != 0 )
		{
			if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
				System.out.println("\tADDING LEFT-OVER CHUNKS INTO RET : " + newChunk) ;

			ret.add(newChunk) ;
		}

		if ( !nextChunkAdded )
		{
			List<PDFCharacter> lastChunk = chunksLine.get(chunksLine.size()-1) ;
			ret.add(lastChunk) ;

			if ( SINGLE_CHARACTERS_CHUNK_DEBUG )
				System.out.println("\tADDING LEFT-OVER LAST CHUNK INTO RET : " + lastChunk) ;
		}

		return ret ;
	}

	private float findAverageGap(List<List<PDFCharacter>> chunksLine) 
	{
		float sum = 0.0f ;
		int count = 0 ;

		for ( int i=0 ; i<chunksLine.size() ; i++ )
		{
			List<PDFCharacter> chunk = chunksLine.get(i) ;
			if ( chunk.size() == 1 )
				continue ;

			for ( int j=0 ; j<chunk.size()-1 ; j++ )
			{
				PDFCharacter thisCharacter = chunk.get(j) ;
				PDFCharacter nextCharacter = chunk.get(j+1) ;

				float gap = nextCharacter.getX1() - thisCharacter.getX2() ;
				gap = gap < 0.0f ? 0.0f : gap ;
				sum += gap ;
				count ++ ;
			}
		}

		float avg = sum / count ;
		return avg ;
	}

	private List<List<PDFCharacter>> createChunksOnDiffs(List<List<PDFCharacter>> chunks, List<Float> gaps, List<Float> diffs, float threshold) 
	{
		List<Pair<Integer, Integer>> possibleMergesPairs = findPossibleMergesPairs(chunks, gaps, diffs, threshold) ;

		List<List<PDFCharacter>> newChunks = new ArrayList<List<PDFCharacter>>() ;

		List<Pair<Integer, Integer>> donePairs = new ArrayList<Pair<Integer,Integer>>() ;
		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			Integer index = i ;
			// System.out.println("THIS INDEX : " + index + " : " + chunks.get(i)) ;

			Pair<Integer, Integer> pair = findConnectedPair(possibleMergesPairs, index) ;

			if ( pair == null )
			{
				newChunks.add(chunks.get(i)) ;
				continue ;
			}

			Pair<Integer, Integer> nxtPair = findConnectedPair(possibleMergesPairs, pair.getB().intValue()+3) ;

			if ( donePairs.contains(pair) )
				continue ;

			donePairs.add(pair) ;

			Integer startIndex = pair.getA() ;
			Integer endIndex;
			if(nxtPair==null)
			{
				endIndex = pair.getB()+2 ;
			}
			else
			{
				if(pair.getB()+2>=nxtPair.getA())
					endIndex = pair.getB()+1 ;
				else
					endIndex = pair.getB()+2 ;
			}

			List<PDFCharacter> newChunk = new ArrayList<PDFCharacter>() ;

			// System.out.println("MERGING : ") ;

			for ( int j=startIndex.intValue() ; j<=endIndex.intValue() && j<chunks.size() ; j++ )
			{
				List<PDFCharacter> prevChunk = chunks.get(j) ;
				// System.out.println("\t" + prevChunk) ;
				newChunk.addAll(new ArrayList<PDFCharacter>(prevChunk)) ;
			}

			newChunks.add(newChunk) ;

			i = pair.getB().intValue()+2 ;
			// System.out.println("SETTING i TO : " + i) ;
		}

		return newChunks ;
	}

	private Pair<Integer, Integer> findConnectedPair(List<Pair<Integer, Integer>> pairs, int index) 
	{
		for ( int i=0 ; i<pairs.size() ; i++ )
		{
			Pair<Integer, Integer> pair = pairs.get(i) ;
			if ( index >= pair.getA().intValue() && index <= pair.getB().intValue()+2 )
				return pair ;
		}

		return null ;
	}

	private List<Pair<Integer, Integer>> findPossibleMergesPairs(List<List<PDFCharacter>> wordsLine, List<Float> gaps, List<Float> diffs, float threshold) 
	{
		List<Pair<Integer, Integer>> ret = new ArrayList<Pair<Integer,Integer>>() ;
		
		if ( gaps.size() == 0 || diffs.size() == 0 )
		{
			Pair<Integer, Integer> pair = new Pair<Integer, Integer>(0, wordsLine.size()-1) ;
			ret.add(pair) ;
			
			return ret ;
		}
		
		List<Integer> possibleDiffs = new ArrayList<Integer>() ;
		for ( int i=0 ; i<diffs.size() ; i++ )
		{
			float diff = diffs.get(i) ;

			if ( diff >= (-1 * threshold) && diff <= threshold )
				possibleDiffs.add(new Integer(i)) ;
		}
		
		if ( GAPS_DIFFS_DEBUG )
			System.out.println("BREAKS : " + possibleDiffs) ;

		
		for ( int i=0 ; i<possibleDiffs.size() ; i++ )
		{
			Integer thisIndex = possibleDiffs.get(i) ;
			
			if ( BREAK_TO_RANGE_DEBUG )
				System.out.println("THIS INDEX : " + thisIndex) ;

			Integer startIndex = new Integer(thisIndex) ;
			Integer endIndex = new Integer(thisIndex) ;

			for ( int j=i+1 ; j<possibleDiffs.size() ; j++ )
			{
				Integer subsequentIndex = possibleDiffs.get(j) ;

				if ( BREAK_TO_RANGE_DEBUG )
					System.out.println("\tSUB-SEQUENT INDEX : " + subsequentIndex) ;

				if ( subsequentIndex.intValue()-endIndex.intValue() == 1 )
				{
					endIndex = new Integer(subsequentIndex) ;
					i = j ;

					if ( BREAK_TO_RANGE_DEBUG )
						System.out.println("\t\tCONTINUING ... ") ;

					continue ;
				}

				if ( BREAK_TO_RANGE_DEBUG )
					System.out.println("\t\tBREAKING ... ") ;

				break ;
			}

			Pair<Integer, Integer> pair = new Pair<Integer, Integer>(startIndex, endIndex) ;
			ret.add(pair) ;
		}

		return ret ;
	}

	private List<Float> computeDiffs(List<Float> gaps) 
	{
		List<Float> ret = new ArrayList<Float>() ;

		for ( int i=0 ; i<gaps.size()-1 ; i++ )
		{
			Float thisGap = gaps.get(i) ;
			Float nextGap = gaps.get(i+1) ;

			float diff = nextGap - thisGap ;

			ret.add(new Float(diff)) ;
		}

		return ret ;
	}

	private List<Float> computeGaps(List<List<PDFCharacter>> wordsLine) 
	{
		List<Float> ret = new ArrayList<Float>() ;

		for ( int i=0 ; i<wordsLine.size()-1 ; i++ )
		{
			List<PDFCharacter> thisWord = wordsLine.get(i) ;
			List<PDFCharacter> nextWord = wordsLine.get(i+1) ;

			PDFCharacter nextWordFirstCharacter = nextWord.get(0) ;
			PDFCharacter thisWordLastCharacter = thisWord.get(thisWord.size()-1) ;

			float gap = nextWordFirstCharacter.getX1() - thisWordLastCharacter.getX2() ;
			ret.add(new Float(gap)) ;
		}

		return ret ;
	}

	private List<List<PDFCharacter>> createDefaultChunks(List<PDFCharacter> line) 
	{
		List<List<PDFCharacter>> ret = new ArrayList<List<PDFCharacter>>() ;

		for ( int i=0 ; i<line.size() ; i++ )
		{
			PDFCharacter character = line.get(i) ;

			List<PDFCharacter> word = new ArrayList<PDFCharacter>() ;
			word.add(character) ;
			
			ret.add(word) ;
		}

		return ret ;
	}

	public List<List<PDFCharacter>> getCharacterLines() {
		return characterLines;
	}

	public void setCharacterLines(List<List<PDFCharacter>> characterLines) {
		this.characterLines = characterLines;
	}

	public List<List<List<PDFWord>>> getWordChunkLines() {
		return wordChunkLines;
	}

	public void setWordChunkLines(List<List<List<PDFWord>>> wordChunkLines) {
		this.wordChunkLines = wordChunkLines;
	}

	public List<List<PDFWord>> getWordLines() {
		return wordLines;
	}

	public void setWordLines(List<List<PDFWord>> wordLines) {
		this.wordLines = wordLines;
	}

	public List<List<PDFChunk>> getChunkLines() {
		return chunkLines;
	}

	public void setChunkLines(List<List<PDFChunk>> chunkLines) {
		this.chunkLines = chunkLines;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
