package com.rage.extraction.pdf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.pdf.utils.PDFBoundedObjectUtils;

public class PDFLine extends PDFBoundedObject implements Serializable
{
	private static final long serialVersionUID = -7911633266760903207L;
	private Integer pageNo ;
	private List<PDFChunk> chunks ;
	private String line ;
	private Integer lineNo ;
	private Integer blockNo ;
	private boolean isLineFooter;
	private boolean isLineHeader;

	private Boolean isTableID = Boolean.FALSE;
	private Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap ;
	
	public PDFLine(Integer lineNo,Integer pageNo, List<PDFChunk> chunks)
	{
		setPageNo(pageNo) ;
		setLineNo(lineNo);
		setChunks(chunks) ;
		setBounds("PDF-Line", PDFBoundedObjectUtils.findBoundingRectangle(getChunks())) ;
		setLine(createStringFromChunks(getChunks())) ;
		setFontSizeCharactersMap(createFontSizeCharactersMap(getChunks())) ;
	}
	
	public Integer getLineNo() {
		return lineNo;
	}

	public void setLineNo(Integer lineNo) {
		this.lineNo = lineNo;
	}

	public String getLineString()
	{
		String ret = "" ;
		
		for ( int i=0 ; i<getChunks().size() ; i++ )
		{
			PDFChunk chunk = getChunks().get(i) ;
			ret = ret.trim() + " " + chunk.toString() ;
		}
		
		return ret.trim() ;
	}
	
	private static Map<String, Map<Float, List<PDFCharacter>>> createFontSizeCharactersMap(List<PDFChunk> chunks) 
	{
		Map<String, Map<Float, List<PDFCharacter>>> map = new HashMap<String, Map<Float,List<PDFCharacter>>>() ;
		
		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			PDFChunk chunk = chunks.get(i) ;
			Map<String, Map<Float, List<PDFCharacter>>> chunkMap = chunk.getFontSizeCharactersMap() ;
			
			for ( String font : chunkMap.keySet() )
			{
				Map<Float, List<PDFCharacter>> chunkSubList = chunkMap.get(font) ;
				Map<Float, List<PDFCharacter>> subList = map.containsKey(font) ? map.get(font) : new HashMap<Float, List<PDFCharacter>>() ;
				
				for ( Float size : chunkSubList.keySet() )
				{
					List<PDFCharacter> chunkList = chunkSubList.get(size) ;
					
					List<PDFCharacter> list = subList.containsKey(size) ? subList.get(size) : new ArrayList<PDFCharacter>() ;
					list.addAll(chunkList) ;
					
					subList.put(size, list) ;
				}
				
				map.put(font, subList) ;
			}
		}
		
		return map ;
	}

	private static String createStringFromChunks(List<PDFChunk> chunks) 
	{
		String ret = "" ;
		
		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			PDFChunk chunk = chunks.get(i) ;
			if ( chunk == null )
				continue ;
			
			ret =  ret + (ret.trim().equalsIgnoreCase("") || ret.trim().endsWith("+++") ? "" : " ") + chunk.getChunk() ;
		}
		
		return ret ;
	}
	
	@Override
	public String toString() 
	{
		return getLine() ;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((chunks == null) ? 0 : chunks.hashCode());
		result = prime
				* result
				+ ((fontSizeCharactersMap == null) ? 0 : fontSizeCharactersMap
						.hashCode());
		result = prime * result + ((line == null) ? 0 : line.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFLine other = (PDFLine) obj;
		if (chunks == null) {
			if (other.chunks != null)
				return false;
		} else if (!chunks.equals(other.chunks))
			return false;
		if (fontSizeCharactersMap == null) {
			if (other.fontSizeCharactersMap != null)
				return false;
		} else if (!fontSizeCharactersMap.equals(other.fontSizeCharactersMap))
			return false;
		if (line == null) {
			if (other.line != null)
				return false;
		} else if (!line.equals(other.line))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		return true;
	}

	public List<PDFChunk> getChunks() {
		return chunks;
	}

	public void setChunks(List<PDFChunk> chunks) {
		this.chunks = chunks;
	}

	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}

	public Map<String, Map<Float, List<PDFCharacter>>> getFontSizeCharactersMap() {
		return fontSizeCharactersMap;
	}

	public void setFontSizeCharactersMap(
			Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap) {
		this.fontSizeCharactersMap = fontSizeCharactersMap;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public boolean isTableID() {
		return isTableID;
	}

	public void setTableID(boolean isTableID) {
		this.isTableID = isTableID;
	}

	public Integer getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(Integer blockNo) {
		this.blockNo = blockNo;
	}

	public boolean isLineFooter() {
		return isLineFooter;
	}

	public void setLineFooter(boolean isLineFooter) {
		this.isLineFooter = isLineFooter;
	}

	public boolean isLineHeader() {
		return isLineHeader;
	}

	public void setLineHeader(boolean isLineHeader) {
		this.isLineHeader = isLineHeader;
	}
}
