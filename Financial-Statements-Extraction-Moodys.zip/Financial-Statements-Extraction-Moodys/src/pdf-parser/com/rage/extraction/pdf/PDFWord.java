package com.rage.extraction.pdf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.pdf.utils.PDFBoundedObjectUtils;

public class PDFWord extends PDFBoundedObject implements Serializable
{
	private static final long serialVersionUID = -6004742005938492594L;
	private Integer pageNo ;
	private String word ;
	private List<PDFCharacter> characters ;
	private Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap ;
	
	public PDFWord(Integer pageNo, List<PDFCharacter> characters)
	{
		setPageNo(pageNo) ;
		setCharacters(characters) ;
		setBounds("PDF-WORD", PDFBoundedObjectUtils.findBoundingRectangle(getCharacters())) ;
		setWord(createStringFromCharacters(getCharacters())) ;
		setFontSizeCharactersMap(createFontSizeCharactersMap(characters)) ;
	}
	
	private static Map<String, Map<Float, List<PDFCharacter>>> createFontSizeCharactersMap(List<PDFCharacter> characters)
	{
		Map<String, Map<Float, List<PDFCharacter>>> map = new HashMap<String, Map<Float,List<PDFCharacter>>>() ;
		
		for ( int i=0 ; i<characters.size() ; i++ )
		{
			PDFCharacter character = characters.get(i) ;
			String fontName = character.getFont().getName() ;
			Float fontSize = character.getFont().getSize() ;
			
			Map<Float, List<PDFCharacter>> subMap = map.containsKey(fontName) ? map.get(fontName) : new HashMap<Float, List<PDFCharacter>>() ;
			List<PDFCharacter> list = subMap.containsKey(fontSize) ? subMap.get(fontSize) : new ArrayList<PDFCharacter>() ;
			list.add(character) ;
			subMap.put(fontSize, list) ;
			map.put(fontName, subMap) ;
		}
		
		return map;
	}

	private static String createStringFromCharacters(List<PDFCharacter> characters) 
	{
		String word = "" ;
		
		for ( int i=0 ; i<characters.size() ; i++ )
		{
			PDFCharacter character = characters.get(i) ;
			if ( character == null )
				continue ;
			
			word = word + character.getCharacter() ;
		}
		
		return word ;
	}
	
	@Override
	public String toString() 
	{
		return getWord() ;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = super.hashCode();
		
		result = prime * result + ((characters == null) ? 0 : characters.hashCode());
		result = prime * result + ((fontSizeCharactersMap == null) ? 0 : fontSizeCharactersMap.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		result = prime * result + ((word == null) ? 0 : word.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFWord other = (PDFWord) obj;
		if (characters == null) {
			if (other.characters != null)
				return false;
		} else if (!characters.equals(other.characters))
			return false;
		if (fontSizeCharactersMap == null) {
			if (other.fontSizeCharactersMap != null)
				return false;
		} else if (!fontSizeCharactersMap.equals(other.fontSizeCharactersMap))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		if (word == null) {
			if (other.word != null)
				return false;
		} else if (!word.equals(other.word))
			return false;
		return true;
	}

	public String getWord() 
	{
		return word;
	}

	public void setWord(String word) {
		this.word = word;
	}

	public List<PDFCharacter> getCharacters() {
		return characters;
	}

	public void setCharacters(List<PDFCharacter> characters) {
		this.characters = characters;
	}

	public Map<String, Map<Float, List<PDFCharacter>>> getFontSizeCharactersMap() {
		return fontSizeCharactersMap;
	}

	public void setFontSizeCharactersMap(
			Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap) {
		this.fontSizeCharactersMap = fontSizeCharactersMap;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
