package com.rage.extraction.pdf.parse;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import javax.xml.bind.ValidationException;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.statements.security.PathTravesal;
import com.rage.extraction.statements.security.SafeFile;

class TextPositionsFinder extends PDFTextStripper
{
	private PDPage page ;
	private Integer pageNo ;
	private Vector<TextPosition> textPositions ;
	private List<PDFCharacter> characters ;
	private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(PDFTextStripper.class);
	public static Vector<TextPosition> findTextPositions(Integer pageNo, PDPage page) // NO_UCD (unused code)
	{
		try
		{
			TextPositionsFinder ptlf = new TextPositionsFinder(pageNo, page) ;
			ptlf.run() ;
			return ptlf.getTextPositions() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN FINDING TEXT-POSITIONS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		
		return new Vector<TextPosition>() ;
	}
	
	TextPositionsFinder(Integer pageNo, PDPage page) throws IOException 
	{
		super();
		super.setSortByPosition(true) ;
		
		setPageNo(pageNo) ;
		setPage(page) ;
		setTextPositions(new Vector<TextPosition>()) ;
	}
	
	void run()
	{
		try
		{
			processStream(getPage(), getPage().findResources(), getPage().getContents().getStream()) ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PROCESSING STREAM : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		
		List<TextPosition> textPositions = discardSuccessiveWhiteSpaces(getTextPositions()) ;
		
		if ( textPositions.size() < 1 )
			return ;
		
		List<PDFCharacter> characters = new ArrayList<PDFCharacter>() ;
		List<Float> validDirections = findMainDirections(textPositions) ;
		
		float pageWidth = getPage().getMediaBox().getWidth() ;
		float pageHeight = getPage().getMediaBox().getHeight() ;
		
		/*System.out.println("Page Width = " + pageWidth) ;
		System.out.println("Page Height = " + pageHeight) ;*/
		
		float totalInvertedX = 0.0f ;
		float totalInvertedY = 0.0f ;
		float totalCount = 0.0f ;
		
		for ( int i=0 ; i<textPositions.size() ; i++ )
		{
			TextPosition textPosition = textPositions.get(i) ;
			
			totalCount = totalCount + 1.0f ;
			
			float x3 = textPosition.getXDirAdj() ;
			float y3 = textPosition.getYDirAdj() ;
			float width = textPosition.getWidthDirAdj() ;
			float height = textPosition.getHeightDir() ;
			
			// System.out.println("CHARACTER X AND Y SCALES : " + textPosition.getXScale() + ", " + textPosition.getYScale()) ;
			
			float x1 = x3 ;
			float y1 = y3 - height ;
			float x2 = x3 + width ;
			float y2 = y3 ;
			
			if ( x1 > x2 )
				totalInvertedX = totalInvertedX + 1.0f ;
			
			if ( y1 > y2 )
				totalInvertedY = totalInvertedY + 1.0f ;
			
			pageWidth = pageWidth > x1 ? pageWidth : x1 ;
			pageWidth = pageWidth > x2 ? pageWidth : x2 ;
			pageHeight = pageHeight > y1 ? pageHeight : y1 ;
			pageHeight = pageHeight > y2 ? pageHeight : y2 ;
		}
		
		boolean invertX = (totalInvertedX / totalCount) > 0.5f ? true : false ;
		boolean invertY = (totalInvertedY / totalCount) > 0.5f ? true : false ;
		
		// System.out.println("Invert X,Y = [" + invertX + ", " + invertY + "]") ;
		
	//	System.out.println("Page Width: " + pageWidth) ;	
		//System.out.println("Page Height: " + pageHeight) ;	
		
		for ( int i=0 ; i<textPositions.size() ; i++ )
		{
			TextPosition textPosition = textPositions.get(i) ;
			float direction = textPosition.getDir() ;
			if ( !validDirections.contains(direction) )
				continue ;
			
			PDFCharacter character = new PDFCharacter(getPageNo(), textPosition, pageWidth, pageHeight, invertX, invertY) ;
			character.setWidthOfSpace(textPosition.getWidthOfSpace());
			characters.add(character) ;
			
			// System.out.println("Adding Character : " + character.toCompleteString()) ;
		}
		
		setCharacters(characters) ;
	}
	
	private static List<Float> findMainDirections(List<TextPosition> textPositions) 
	{
		TreeMap<Float, Integer> directionCountsMap = new TreeMap<Float, Integer>() ;

		for ( int i=0 ; i<textPositions.size() ; i++ )
		{
			TextPosition tp = textPositions.get(i) ;
			float direction = tp.getDir() ;

			Integer count = directionCountsMap.containsKey(direction) ? directionCountsMap.get(direction) : new Integer(0) ;
			count = count.intValue() + 1 ;
			directionCountsMap.put(direction, count) ;
		}

		List<Integer> counts = new ArrayList<Integer>(new TreeSet<Integer>(directionCountsMap.values())) ;
		Integer maxCount = counts.get(counts.size()-1) ;

		List<Float> directions = new ArrayList<Float>() ;
		for ( Float direction : directionCountsMap.keySet() )
		{
			Integer count = directionCountsMap.get(direction) ;
			if ( count.intValue() == maxCount.intValue() )
				directions.add(direction) ;
		}

		return directions ;
	}
	
	private static List<TextPosition> discardSuccessiveWhiteSpaces(List<TextPosition> textPositions) 
	{
		List<TextPosition> refinedTextPositions = new ArrayList<TextPosition>();
		TextPosition tpPrev=null, tpCurr=null, tpNext=null;
		
		for (int index = 0; index < textPositions.size(); index++) 
		{
			int charCount = 0;
			if ((index - 1) >= 0) 
			{
				tpPrev = textPositions.get(index - 1);
				if (tpPrev.getCharacter() != null && !tpPrev.getCharacter().equals(" "))
					charCount ++;
			}

			tpCurr = textPositions.get(index);
			if (tpCurr.getCharacter() != null && !tpCurr.getCharacter().equals(" "))
				charCount ++;

			if ((index + 1) < textPositions.size()) 
			{
				tpNext = textPositions.get(index + 1);
				if (tpNext.getCharacter() != null && !tpNext.getCharacter().equals(" "))
					charCount ++;
			}

			if (charCount > 0 && tpPrev != null)
				refinedTextPositions.add(tpPrev);

		}
		if (textPositions!=null && textPositions.size()>0)
			refinedTextPositions.add(textPositions.get(textPositions.size()-1));
		
		return refinedTextPositions;
	}
	
	@Override
    protected void processTextPosition(TextPosition text) 
	{
		getTextPositions().addElement(text) ;
    }
	
	public PDPage getPage() {
		return page;
	}

	public void setPage(PDPage page) {
		this.page = page;
	}

	public Vector<TextPosition> getTextPositions() {
		return textPositions;
	}

	public void setTextPositions(Vector<TextPosition> textPositions) {
		this.textPositions = textPositions;
	}
	
	public List<PDFCharacter> getCharacters() {
		return characters;
	}

	public void setCharacters(List<PDFCharacter> characters) {
		this.characters = characters;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception
	{
		String fileName = "D:/Samples/MultiLanguage/English/" +"Financials.pdf"; //"Audited - Bla LLC 2015_SaveAs.pdf" ;
		
		Integer pageNo = 1 ;
		
		PDDocument document = PDDocument.load(new File(fileName)) ;
		if ( document.isEncrypted() )
			document.openProtection(new StandardDecryptionMaterial("")) ;
		
		List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;

		PDPage page = pages.get(pageNo) ;
		
		TextPositionsFinder tpf = new TextPositionsFinder(pageNo, page) ;
		tpf.run() ;
		List<PDFCharacter> characters = tpf.getCharacters() ;
		
		for ( int i=0 ; i<characters.size() ; i++ )
		{
			PDFCharacter character = characters.get(i) ;
			System.out.println(character.toCompleteString()) ;
		}
		
		document.close() ;
	}
}
