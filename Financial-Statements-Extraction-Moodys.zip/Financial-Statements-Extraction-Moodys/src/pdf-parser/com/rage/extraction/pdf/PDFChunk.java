package com.rage.extraction.pdf;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.extraction.pdf.utils.PDFBoundedObjectUtils;

public class PDFChunk extends PDFBoundedObject implements Serializable
{
	private static final long serialVersionUID = 1182319145198443520L;
	private Integer pageNo ;
	private List<PDFWord> words ;
	private String chunk ;
	private Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap ;
	
	public PDFChunk(Integer pageNo, List<PDFWord> words)
	{
		setPageNo(pageNo) ;
		setWords(words) ;
		setBounds("PDF-WORD", PDFBoundedObjectUtils.findBoundingRectangle(getWords())) ;
		setChunk(createStringFromWords(getWords())) ;
		setFontSizeCharactersMap(createFontSizeCharactersMap(getWords())) ;
	}
	
	private static Map<String, Map<Float, List<PDFCharacter>>> createFontSizeCharactersMap(List<PDFWord> words) 
	{
		Map<String, Map<Float, List<PDFCharacter>>> map = new HashMap<String, Map<Float,List<PDFCharacter>>>() ;
		
		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			Map<String, Map<Float, List<PDFCharacter>>> wordMap = word.getFontSizeCharactersMap() ;
			
			for ( String font : wordMap.keySet() )
			{
				Map<Float, List<PDFCharacter>> wordSubMap = wordMap.get(font) ;
				Map<Float, List<PDFCharacter>> subMap = map.containsKey(font) ? map.get(font) : new HashMap<Float, List<PDFCharacter>>() ;
				
				for ( Float size : wordSubMap.keySet() )
				{
					List<PDFCharacter> wordList = wordSubMap.get(size) ;
					
					List<PDFCharacter> list = subMap.containsKey(size) ? subMap.get(size) : new ArrayList<PDFCharacter>() ;
					list.addAll(wordList) ;
					
					subMap.put(size, list) ;
				}
				
				map.put(font, subMap) ;
			}
		}
		
		return map ;
	}

	private static String createStringFromWords(List<PDFWord> words) 
	{
		String ret = "" ;
		
		for ( int i=0 ; i<words.size() ; i++ )
		{
			PDFWord word = words.get(i) ;
			if ( word == null )
				continue ;
			
			String wordStr = word.getWord() ;
			ret = ret.trim() + " " + wordStr.trim() ;
		}
		
		return ret.trim() ;
	}
	
	public String getWordSeparatedString()
	{
		String ret = "" ;
		
		for ( int i=0 ; i<getWords().size() ; i++ )
		{
			PDFWord word = getWords().get(i) ;
			if ( word.getWord().trim().equalsIgnoreCase("") )
				continue ;
			
			ret = ret.trim() + " " + "'" + word.getWord().trim() + "'" ;
		}
		
		return ret.trim() ;
	}
	
	@Override
	public String toString() 
	{
		return getChunk() ;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((chunk == null) ? 0 : chunk.hashCode());
		result = prime
				* result
				+ ((fontSizeCharactersMap == null) ? 0 : fontSizeCharactersMap
						.hashCode());
		result = prime * result + ((pageNo == null) ? 0 : pageNo.hashCode());
		result = prime * result + ((words == null) ? 0 : words.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFChunk other = (PDFChunk) obj;
		if (chunk == null) {
			if (other.chunk != null)
				return false;
		} else if (!chunk.equals(other.chunk))
			return false;
		if (fontSizeCharactersMap == null) {
			if (other.fontSizeCharactersMap != null)
				return false;
		} else if (!fontSizeCharactersMap.equals(other.fontSizeCharactersMap))
			return false;
		if (pageNo == null) {
			if (other.pageNo != null)
				return false;
		} else if (!pageNo.equals(other.pageNo))
			return false;
		if (words == null) {
			if (other.words != null)
				return false;
		} else if (!words.equals(other.words))
			return false;
		return true;
	}

	public List<PDFWord> getWords() {
		return words;
	}

	public void setWords(List<PDFWord> words) {
		this.words = words;
	}

	public String getChunk() {
		return chunk;
	}

	public void setChunk(String chunk) {
		this.chunk = chunk;
	}

	public Map<String, Map<Float, List<PDFCharacter>>> getFontSizeCharactersMap() {
		return fontSizeCharactersMap;
	}

	public void setFontSizeCharactersMap(
			Map<String, Map<Float, List<PDFCharacter>>> fontSizeCharactersMap) {
		this.fontSizeCharactersMap = fontSizeCharactersMap;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}
}
