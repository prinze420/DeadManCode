package com.rage.extraction.pdf.parse;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;


import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.encryption.StandardDecryptionMaterial;

import com.rage.extraction.pdf.PDFBlock;
import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;

public class PDFPageParser 
{
	private static Boolean DEBUG_VERTICAL_LINE_MERGE = Boolean.FALSE ;
	//private final static  org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(PDFPageParser.class);

	private Integer pageNo ;
	private PDPage page ;

	private PageParse parse ;

	public PDFPageParser(Integer pageNo, PDPage page)
	{
		setPageNo(pageNo) ;
		setPage(page) ;

		PageParse parse = new PageParse(getPageNo(),page) ;
		setParse(parse) ;
	}

	public PDFPageParser(Integer pageNo)
	{
		setPageNo(pageNo) ;
		setPage(page) ;

		PageParse parse = new PageParse(getPageNo(),page) ;
		setParse(parse) ;
	}
	
	public void run()
	{
		List<PDFCharacter> characters = createCharacters() ;
		

		if ( characters == null || characters.size() == 0 )
		{
			System.err.println("No characters found for Page No. " + getPageNo()) ;
			return ;
		}

		List<List<PDFCharacter>> characterLines = createCharacterLines(characters) ;
		if ( characterLines == null || characterLines.size() == 0 )
		{
			System.err.println("No lines found for Page No. " + getPageNo()) ;
			return ;
		}

		createLineChunkWords(characterLines) ;
		if ( getParse().getPageLines() == null || getParse().getPageLines().size() == 0 )
		{
			System.err.println("No chunks and words found in lines for Page No. " + getPageNo()) ;
			return ;
		}

		// Merge vertically-overlapping lines, which are not horizontally overlapping
		List<PDFLine> lines = new ArrayList<PDFLine>(getParse().getPageLines()) ;
		lines = mergeVerticallyOverlappingLines(lines) ;
		getParse().setPageLines(lines) ;

		// Adjust x-axis

		List<PDFBlock> blocks = createBlocks(getParse().getPageLines()) ;
		if ( blocks == null || blocks.size() == 0 )
		{
			System.err.println("No blocks found for Page No. " + getPageNo()) ;
			return ;
		}

		getParse().setPageBlocks(blocks) ;
	}
	
	public void run(List<PDFCharacter> characters,boolean isSpaceCheck)
	{
		//List<PDFCharacter> characters = createCharacters() ;

		if ( characters == null || characters.size() == 0 )
		{
			System.err.println("No characters found for Page No. " + getPageNo()) ;
			return ;
		}

		List<List<PDFCharacter>> characterLines = createCharacterLines(characters) ;
		if ( characterLines == null || characterLines.size() == 0 )
		{
			System.err.println("No lines found for Page No. " + getPageNo()) ;
			return ;
		}

		createLineChunkWords(characterLines) ;
		if ( getParse().getPageLines() == null || getParse().getPageLines().size() == 0 )
		{
			System.err.println("No chunks and words found in lines for Page No. " + getPageNo()) ;
			return ;
		}

		// Merge vertically-overlapping lines, which are not horizontally overlapping
		List<PDFLine> lines = new ArrayList<PDFLine>(getParse().getPageLines()) ;
		lines = mergeVerticallyOverlappingLines(lines) ;
		getParse().setPageLines(lines) ;

		// Adjust x-axis

		List<PDFBlock> blocks = createBlocks(getParse().getPageLines()) ;
		if ( blocks == null || blocks.size() == 0 )
		{
			System.err.println("No blocks found for Page No. " + getPageNo()) ;
			return ;
		}

		getParse().setPageBlocks(blocks) ;
	}
	
	private List<PDFLine> mergeVerticallyOverlappingLines(List<PDFLine> lines) 
	{
		List<List<PDFLine>> lineGroups = new ArrayList<List<PDFLine>>() ;
		for ( int i=0 ; i<lines.size() ; i++ )
		{
			PDFLine line = lines.get(i) ;

			boolean foundMerging = false ;
			for ( int j=0 ; j<lineGroups.size() ; j++ )
			{
				List<PDFLine> thisGroup = lineGroups.get(j) ;

				for ( int k=0 ; k<thisGroup.size() ; k++ )
				{
					PDFLine groupLine = thisGroup.get(k) ;

					boolean verticallyMerging = true ;
					if ( line.getY2() < groupLine.getY1() || line.getY1() > groupLine.getY2() )
						verticallyMerging = false ;

					boolean horizontallyMerging = areLinesHorizontallyMerging(line, groupLine) ;

					if ( verticallyMerging && !horizontallyMerging )
					{
						foundMerging = true ;
						break ;
					}
				}

				if ( !foundMerging )
					continue ;

				thisGroup.add(line) ;
				break ;
			}

			if ( !foundMerging )
			{
				List<PDFLine> newGroup = new ArrayList<PDFLine>() ;
				newGroup.add(line) ;

				lineGroups.add(newGroup) ;
			}
		}

		if ( DEBUG_VERTICAL_LINE_MERGE )
		{
			System.out.println("Printing Groups ....") ;
			for ( int i=0 ; i<lineGroups.size() ; i++ )
			{
				List<PDFLine> thisGroup = lineGroups.get(i) ;

				System.out.println("\tGroup " + i + " : ") ;
				for ( int j=0 ; j<thisGroup.size() ; j++ )
				{
					PDFLine line = thisGroup.get(j) ;

					System.out.println("\t\tLine " + j + " : " + line.getLine()) ;
				}
			}
		}

		List<PDFLine> newLines = new ArrayList<PDFLine>() ;

		for ( int i=0 ; i<lineGroups.size() ; i++ )
		{
			List<PDFLine> group = lineGroups.get(i) ;
			group = sortLinesByX(group) ;

			List<PDFChunk> newChunks = new ArrayList<PDFChunk>() ;
			for ( int j=0 ; j<group.size() ; j++ )
			{
				PDFLine line = group.get(j) ;
				List<PDFChunk> chunks = line.getChunks() ;
				newChunks.addAll(chunks) ;
			}

			PDFLine newLine = new PDFLine(i,getPageNo(), newChunks) ;
			newLines.add(newLine) ;
		}

		if ( DEBUG_VERTICAL_LINE_MERGE )
		{
			System.out.println("\n\nPrinting lines after merging vertically ...") ;
			for ( int i=0 ; i<newLines.size() ; i++ )
			{
				PDFLine line = newLines.get(i) ;
				System.out.println("\tLine " + i + " : " + line.getLine()) ;
			}
		}

		return newLines ;
	}

	private boolean areLinesHorizontallyMerging(PDFLine line1, PDFLine line2)
    {
        for ( int i=0 ; i<line1.getChunks().size() ; i++ )
        {
                PDFChunk chunk1 = line1.getChunks().get(i) ;
                
                for ( int j=0 ; j<line2.getChunks().size() ; j++ )
                {
                        PDFChunk chunk2 = line2.getChunks().get(j) ;
                        
                        if ( chunk1.getX2() >= chunk2.getX1() && chunk1.getX2() <= chunk2.getX2() )
                                return true ;
                        
                        if ( chunk2.getX2() >= chunk1.getX1() && chunk2.getX2() <= chunk1.getX2() )
                                return true ;
                }
        }
        
        return false;
}

	
	private List<PDFLine> sortLinesByX(List<PDFLine> group)
	{
		Comparator<PDFLine> xComparator = new Comparator<PDFLine>() {
			public int compare(PDFLine line1, PDFLine line2) 
			{
				return new Float(line1.getX1()).compareTo(new Float(line2.getX1())) ;
			}
		} ;

		PDFLine[] arr = group.toArray(new PDFLine[group.size()]) ;
		Arrays.sort(arr, xComparator) ;

		return new ArrayList<PDFLine>(Arrays.asList(arr)) ;
	}

	private List<PDFBlock> createBlocks(List<PDFLine> pageLines) 
	{
		List<PDFBlock> blocks = new ArrayList<PDFBlock>() ;

		try
		{
			AdaptiveVerticalBlocksCreater avbc = new AdaptiveVerticalBlocksCreater(getPageNo(), pageLines) ;
			avbc.run() ;
			blocks = avbc.getBlocks() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN CREATING BLOCKS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return blocks ;
	}

// TODO Remove unused code found by UCDetector
// 	public void createLines(List<List<List<PDFWord>>> lineChunkWords)
// 	{
// 		List<PDFLine> lines = new ArrayList<PDFLine>() ;
// 		List<List<PDFChunk>> lineChunks = new ArrayList<List<PDFChunk>>() ;
// 		List<List<PDFWord>> lineWords = new ArrayList<List<PDFWord>>() ;
// 
// 		for ( int lineNo=0 ; lineNo < lineChunkWords.size() ; lineNo++ )
// 		{
// 			List<List<PDFWord>> chunkWords = lineChunkWords.get(lineNo) ;
// 
// 			List<PDFChunk> chunks = new ArrayList<PDFChunk>() ;
// 			List<PDFWord> thisLineWords = new ArrayList<PDFWord>() ;
// 
// 			for ( int chunkNo=0 ; chunkNo < chunkWords.size() ; chunkNo++ )
// 			{
// 				List<PDFWord> words = chunkWords.get(chunkNo) ;
// 				thisLineWords.addAll(words) ;
// 
// 				PDFChunk chunk = new PDFChunk(getPageNo(), words) ;
// 				chunks.add(chunk) ;
// 			}
// 
// 			lineWords.addAll(lineWords) ;
// 			lineChunks.add(chunks) ;
// 
// 			PDFLine line = new PDFLine(lineNo,getPageNo(), chunks) ;
// 			lines.add(line) ;
// 		}
// 
// 		getParse().setPageLines(lines) ;
// 	}

	private void createLineChunkWords(List<List<PDFCharacter>> characterLines) 
	{
		List<PDFLine> lines = new ArrayList<PDFLine>() ;

		try
		{
			LineWordSegmentorv2 lws2 = new LineWordSegmentorv2(getPageNo(), characterLines) ;
			lws2.run() ;
			lines = lws2.getLines() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN CREATING WORD-CHUNK-LINES : " + e.getMessage()) ;
			e.printStackTrace() ; 
		}

		getParse().setPageLines(lines) ;
	}

	private List<List<PDFCharacter>> createCharacterLines(List<PDFCharacter> characters) 
	{
		List<List<PDFCharacter>> characterLines = new ArrayList<List<PDFCharacter>>() ;

		try
		{
			CharacterLinesCreater clc = new CharacterLinesCreater(characters) ;
			clc.run() ;
			characterLines = clc.getCharacterLines() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN COMPUTING CHARACTER LINES : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return characterLines ;
	}

	private List<PDFCharacter> createCharacters()
	{
		List<PDFCharacter> characters = new ArrayList<PDFCharacter>() ;

		try
		{
			TextPositionsFinder tpf = new TextPositionsFinder(getPageNo(), getPage()) ;
			tpf.run() ;
			characters = tpf.getCharacters() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN GETTING TEXT-POSITIONS FROM PAGE : " + getPageNo() + " : " + e.getMessage()) ;
			e.printStackTrace() ; 
		}

		return characters ;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public PDPage getPage() {
		return page;
	}

	public void setPage(PDPage page) {
		this.page = page;
	}

	public PageParse getParse() {
		return parse;
	}

	public void setParse(PageParse parse) {
		this.parse = parse;
	}
	@SuppressWarnings("unchecked")
	public static void main(String[] args) throws Exception
	{
		String fileName="D:/"
				+"Allied-240-241.pdf" ;

		List<Integer> pageNos = new ArrayList<Integer>(Arrays.asList(new Integer[] {
				1
		})) ;
		/*try
		{
			new SafeFile(fileName);
			PathTravesal  pt = new  PathTravesal();
			pt.failIfDirectoryTraversal(fileName);
		} catch (ValidationException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava(e.getMessage())));
			logger.info(StringEscapeUtils.escapeJava(StringEscapeUtils.escapeJava("Exiting System")));
			System.exit(1);
		}*/
		PDDocument document = PDDocument.load(new File(fileName)) ;

		if ( document.isEncrypted() )
			document.openProtection(new StandardDecryptionMaterial("")) ;

		List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;

		for ( int i=0 ; i<pages.size() ; i++ )
		{
			if ( !(pageNos.size() != 0 && pageNos.contains(i)) )
				continue ;

			PDPage page = pages.get(i) ;

			PDFPageParser parser = new PDFPageParser(i, page) ;
			parser.run() ;
			PageParse parse = parser.getParse() ;

			List<PDFBlock> blocks = parse.getPageBlocks() ;

			System.out.println("\n\n\nPAGE " + i) ;
			for ( int j=0 ; j<blocks.size() ; j++ )
			{
				PDFBlock block = blocks.get(j) ;
				List<PDFLine> lines = block.getLines() ;

				System.out.println("\n\tBlock " + j + " : ") ;

				for ( int k=0 ; k<lines.size() ; k++ )
				{
					PDFLine line = lines.get(k) ;

					if ( line.getLine().trim().equalsIgnoreCase("") )
						continue ;

					List<PDFChunk> chunks = line.getChunks() ;
					String strLine = "" ;
					for ( int l=0 ; l<chunks.size() ; l++ )
						strLine = strLine + " ##### " + chunks.get(l).getChunk() ;

					System.out.println("\t\tLine " + k + " : " + strLine) ;
				}
			}
		}
	}
}
