package com.rage.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import com.rage.extraction.pdf.PDFCharacter;
import com.rage.extraction.pdf.PDFChunk;
import com.rage.extraction.pdf.PDFLine;
import com.rage.extraction.pdf.PDFWord;
import com.rage.extraction.pdf.utils.Pair;

class LineWordSegmentorv2 
{
	private static Boolean DEBUG = Boolean.FALSE ;
	private static Boolean NEW_WORD_CREATER_DEBUG = Boolean.FALSE ;
	private static Boolean CHARACTER_CHUNKS_DEBUG = Boolean.FALSE ;
	private static Boolean FINAL_DEBUG = Boolean.FALSE ;

	private Integer pageNo ;
	private List<List<PDFCharacter>> characterLines ;

	private List<PDFLine> lines ;

	LineWordSegmentorv2(Integer pageNo, List<List<PDFCharacter>> characterLines)
	{
		setPageNo(pageNo) ;
		setCharacterLines(characterLines) ;

		setLines(new ArrayList<PDFLine>()) ;
	}

	private float computeAverageCharacterWidth(List<PDFCharacter> characterLine) 
	{
		float sum = 0.0f ;
		float count = 0.0f ;


		for ( int j=0 ; j<characterLine.size() ; j++ )
		{
			PDFCharacter character = characterLine.get(j) ;

			if ( character.getCharacter().trim().equalsIgnoreCase("") )
				continue ;

			float width = character.getX2() - character.getX1() ;

			sum = sum + width ;
			count = count + 1.0f ;
		}

		float average = count == 0.0f ? 0.0f : (sum/count) ;

		return average ;
	}


	void run()
	{
		float averageSpaceWidth = computeAverageSpaceWidth(getCharacterLines()) ;

		List<PDFLine> lines = new ArrayList<PDFLine>() ;

		for ( int i=0 ; i<getCharacterLines().size() ; i++ )
		{
			List<PDFCharacter> line = getCharacterLines().get(i) ;
			//System.out.println("Before::"+line);
			Comparator<PDFCharacter> charCmp= new Comparator<PDFCharacter>() {
				@Override
				public int compare(PDFCharacter ch1, PDFCharacter ch2) 
				{
					return new Float(ch1.getX1()).compareTo(new Float(ch2.getX1())) ;
				}
			};

			Collections.sort(line,charCmp);
			//System.out.println("After ::"+line);
			
			if ( DEBUG )
				System.out.println("\nProcessing Line: " + line) ;

			float averageCharacterWidth = computeAverageCharacterWidth(line) ;

			List<List<PDFCharacter>> chunks = createChunks(averageSpaceWidth, line,averageCharacterWidth) ;

			if ( DEBUG )
				System.out.println("\tFirst-level Chunks = " + chunks) ;


			if ( DEBUG )
				System.out.println("\tProcessing second-level Recursively ...") ;

			chunks = createSubChunks(averageSpaceWidth, chunks,averageCharacterWidth) ;

			if ( DEBUG )
				System.out.println("\tSecond-level Chunks = " + chunks) ;

			List<List<List<PDFCharacter>>> words = createWordsFromChunks(chunks,averageCharacterWidth, averageSpaceWidth) ;

			if ( DEBUG )
				System.out.println("\tPrinting Chunk Words ...") ;

			for ( int a=0 ; a<words.size() ; a++ )
			{
				List<List<PDFCharacter>> thisChunk = words.get(a) ;

				if ( DEBUG )
					System.out.println("\t\tChunk: " + thisChunk) ;

				for ( int b=0 ; b<thisChunk.size() ; b++ )
				{
					List<PDFCharacter> thisWord = thisChunk.get(b) ;
					String strWord = computeString(thisWord) ;

					if ( DEBUG )
						System.out.println("\t\t\tWord: " + strWord) ;
				}
			}

			List<PDFChunk> finalChunks = new ArrayList<PDFChunk>() ;
			for ( int j=0 ; j<words.size() ; j++ )
			{
				List<List<PDFCharacter>> dummy1 = words.get(j) ;
				List<PDFWord> chunkWords = new ArrayList<PDFWord>() ;
				for ( int k=0 ; k<dummy1.size() ; k++ )
				{
					List<PDFCharacter> dummy2 = dummy1.get(k) ;
					PDFWord word = new PDFWord(getPageNo(), dummy2) ;
					chunkWords.add(word) ;
				}

				PDFChunk chunk = new PDFChunk(getPageNo(), chunkWords) ;
				finalChunks.add(chunk) ;
			}

			PDFLine finalLine = new PDFLine(i,getPageNo(), finalChunks) ;
			lines.add(finalLine) ;
		}

		setLines(lines) ;

		if ( FINAL_DEBUG )
		{
			for ( int i=0 ; i<getLines().size() ; i++ )
			{
				PDFLine line = getLines().get(i) ;
				System.out.println("\nLine: " + line.getLine()) ;

				List<PDFChunk> chunks = line.getChunks() ;
				for ( int j=0 ; j<chunks.size() ; j++ )
				{
					PDFChunk chunk = chunks.get(j) ;
					System.out.println("\tChunk: " + chunk.getChunk()) ;

					List<PDFWord> words = chunk.getWords() ;
					for ( int k=0 ; k<words.size() ; k++ )
					{
						PDFWord word = words.get(k) ;

						if ( word.getWord().trim().equalsIgnoreCase("") )
							continue ;

						System.out.println("\t\tWord: " + word.getWord()) ;
					}
				}
			}
		}
	}

	private String computeString(List<PDFCharacter> thisWord) 
	{
		String ret = "" ;

		for ( int i=0 ; i<thisWord.size() ; i++ )
		{
			PDFCharacter character = thisWord.get(i) ;
			ret = ret.trim() + " " + character.getCharacter() ;
		}

		return ret.trim() ;
	}

	private List<List<List<PDFCharacter>>> createWordsFromChunks(List<List<PDFCharacter>> chunks, float averageCharacterWidth, float averageSpaceWidth)
	{
		List<List<List<PDFCharacter>>> ret = new ArrayList<List<List<PDFCharacter>>>() ;

		for ( int i=0 ; i<chunks.size() ; i++ )
		{
			List<PDFCharacter> chunk = chunks.get(i) ;
			List<List<PDFCharacter>> thisChunkWords = createWordsFromOneChunk(chunk,averageCharacterWidth, averageSpaceWidth) ;
			ret.add(thisChunkWords) ;
		}

		return ret ;
	}

	private boolean isSpaceCharacterPresent(List<PDFCharacter> chunk) 
	{
		boolean ret=false;
		for ( int k=0 ; k<chunk.size() ; k++ )
		{
			PDFCharacter character = chunk.get(k) ;
			if ( character.getCharacter().trim().equalsIgnoreCase("") )
			{
				return true;
			}
		}
		return ret;
	}

	private List<List<PDFCharacter>> createWordsFromOneChunk(List<PDFCharacter> chunk, float averageCharacterWidth, float averageSpaceWidth) 
	{
		if ( NEW_WORD_CREATER_DEBUG )
			System.out.println("\n\nNEW-PROCESSING-LINE: " + chunk) ;

		List<List<PDFCharacter>> words = new ArrayList<List<PDFCharacter>>() ;

		List<PDFCharacter> thisWord = new ArrayList<>() ;
		
		for ( int i=0 ; i<chunk.size() ; i++ )
		{
			PDFCharacter thisChar = chunk.get(i) ;
			
			if ( NEW_WORD_CREATER_DEBUG )
				System.out.println("\tThis Char: " + thisChar) ;
			
			if ( thisWord.size() == 0 )
			{
				if ( NEW_WORD_CREATER_DEBUG )
					System.out.println("\t\tNew-Word ... Empty Condition ...") ;
				
				thisWord.add(thisChar) ;
				continue ;
			}
			
			if ( thisChar.getCharacter().trim().equalsIgnoreCase("") )
			{
				if ( NEW_WORD_CREATER_DEBUG )
					System.out.println("\t\tFound Space ... ") ;
				
				words.add(new ArrayList<PDFCharacter>(thisWord)) ;
				thisWord.clear() ;
				
				thisWord.add(thisChar) ;
				words.add(new ArrayList<PDFCharacter>(thisWord)) ;
				thisWord.clear() ;
				
				continue ;
			}
			
			PDFCharacter prevChar = thisWord.get(thisWord.size()-1) ;
			if ( NEW_WORD_CREATER_DEBUG )
				System.out.println("\tPrev Char: " + prevChar) ;
			
			if ( Math.max(prevChar.getFont().getSize(), thisChar.getFont().getSize()) - Math.min(prevChar.getFont().getSize(), thisChar.getFont().getSize()) > 1.0f )
			{
				if ( NEW_WORD_CREATER_DEBUG )
					System.out.println("\t\tVariable height ... ") ;

				words.add(new ArrayList<PDFCharacter>(thisWord)) ;
				thisWord.clear() ;

				thisWord.add(thisChar) ;
				continue ;
			}
			
			if ( NEW_WORD_CREATER_DEBUG )
				System.out.println("\t\tSimilar height ... ") ;

			float gap = thisChar.getX1() - prevChar.getX2() ;
			if ( NEW_WORD_CREATER_DEBUG )
				System.out.println("\t\tGap: " + gap + " : " + averageCharacterWidth) ;

			if ( gap >= averageCharacterWidth )
			{
				if ( NEW_WORD_CREATER_DEBUG )
					System.out.println("\t\tFound Implicit Space ... ") ;
				// Found space ...
				if ( thisWord.size() != 0 )
				{
					words.add(new ArrayList<PDFCharacter>(thisWord)) ;
					thisWord.clear() ;

					thisWord.add(thisChar) ;
					words.add(new ArrayList<PDFCharacter>(thisWord)) ;
					thisWord.clear() ;
				}

				continue ;
			}
			
			if ( NEW_WORD_CREATER_DEBUG )
				System.out.println("\t\tDefault ...") ;

			thisWord.add(thisChar) ;
			continue ;
		}
		
		
		if ( thisWord.size() != 0 )
			words.add(thisWord) ;
		
		// return words ;
		
		List<List<PDFCharacter>> newWords = new ArrayList<List<PDFCharacter>>() ;
		for ( int i=0 ; i<words.size() ; i++ )
		{
			List<PDFCharacter> oldWord = words.get(i) ;
			List<List<PDFCharacter>> newSubWords = createChunks(averageCharacterWidth, oldWord, averageSpaceWidth) ;
			newWords.addAll(newSubWords) ;
		}
		
		return newWords ;
	}
	
	public List<List<PDFCharacter>> createWordsFromOneChunkOld(List<PDFCharacter> chunk, float averageCharacterWidth) 
	{
		List<List<PDFCharacter>> words = new ArrayList<List<PDFCharacter>>() ;

		List<PDFCharacter> thisWord = new ArrayList<PDFCharacter>() ;
		PDFCharacter lastCharacter = null ;
		boolean isSpacesPresent=isSpaceCharacterPresent(chunk);
		//	boolean isSpacesPresent=!isSpaceCheck;

		for ( int k=0 ; k<chunk.size() ; k++ )
		{
			PDFCharacter character = chunk.get(k) ;

			if ( lastCharacter == null || thisWord.size() == 0 )
			{
				thisWord.add(character) ;
				lastCharacter = character ;

				continue ;
			}

			if(isSpacesPresent)
			{
				if ( character.getCharacter().trim().equalsIgnoreCase("") )
				{
					if ( thisWord.size() != 0 )
					{
						words.add(new ArrayList<PDFCharacter>(thisWord)) ;
						thisWord = new ArrayList<PDFCharacter>() ;
					}

					thisWord.add(character) ;

					words.add(new ArrayList<PDFCharacter>(thisWord)) ;
					thisWord = new ArrayList<PDFCharacter>() ;

					lastCharacter = null ;

					continue ;
				}
				else
				{
					thisWord.add(character) ;
					lastCharacter = character ;
				}
			}
			else
			{	

				float diff=Math.abs(character.getX1()-lastCharacter.getX2());
				float widthOfSpace=character.getWidthOfSpace();

				if ( diff<=(widthOfSpace/2) )
				{
					thisWord.add(character) ;
					lastCharacter = character ;
				}
				else
				{
					if ( thisWord.size() != 0 )
					{
						words.add(new ArrayList<PDFCharacter>(thisWord)) ;
						thisWord = new ArrayList<PDFCharacter>() ;
					}

					thisWord.add(character) ;

					//words.add(new ArrayList<PDFCharacter>(thisWord)) ;
					//thisWord = new ArrayList<PDFCharacter>() ;

					lastCharacter = character ;

					continue ;
				}
			}
		}

		if ( thisWord.size() != 0 )
			words.add(new ArrayList<PDFCharacter>(thisWord)) ;

		return words;
	}

	private List<List<PDFCharacter>> createWordsFromOneChunkBackUP(List<PDFCharacter> chunk) 
	{
		List<List<PDFCharacter>> words = new ArrayList<List<PDFCharacter>>() ;

		List<PDFCharacter> thisWord = new ArrayList<PDFCharacter>() ;
		PDFCharacter lastCharacter = null ;
		//boolean isSpacesPresent=isSpaceCharacterPresent(chunk);

		for ( int k=0 ; k<chunk.size() ; k++ )
		{
			PDFCharacter character = chunk.get(k) ;

			if ( lastCharacter == null || thisWord.size() == 0 )
			{
				thisWord.add(character) ;
				lastCharacter = character ;

				continue ;
			}

			if ( character.getCharacter().trim().equalsIgnoreCase("") )
			{
				if ( thisWord.size() != 0 )
				{
					words.add(new ArrayList<PDFCharacter>(thisWord)) ;
					thisWord = new ArrayList<PDFCharacter>() ;
				}

				thisWord.add(character) ;

				words.add(new ArrayList<PDFCharacter>(thisWord)) ;
				thisWord = new ArrayList<PDFCharacter>() ;

				lastCharacter = null ;

				continue ;
			}

			thisWord.add(character) ;
			lastCharacter = character ;
		}

		if ( thisWord.size() != 0 )
			words.add(new ArrayList<PDFCharacter>(thisWord)) ;

		return words;
	}

	private List<List<PDFCharacter>> createSubChunks(float averageSpaceWidth, List<List<PDFCharacter>> chunks,float averageCharacterWidth) 
	{
		List<List<PDFCharacter>> newChunks = new ArrayList<List<PDFCharacter>>() ;

		for ( int chunkID=0 ; chunkID<chunks.size() ; chunkID++ )
		{
			List<PDFCharacter> chunk = chunks.get(chunkID) ;
			List<List<PDFCharacter>> subChunks = createChunks(averageSpaceWidth, chunk,averageCharacterWidth) ;
			newChunks.addAll(subChunks) ;
		}

		return newChunks ;
	}

	private List<List<PDFCharacter>> createChunks(float averageSpaceWidth, List<PDFCharacter> line, float averageCharacterWidth) 
	{
		if ( line.size() == 1 )
		{
			List<List<PDFCharacter>> chunks = new ArrayList<List<PDFCharacter>>() ;
			chunks.add(line) ;
			return chunks ;
		}

		List<List<PDFCharacter>> chunks = new ArrayList<List<PDFCharacter>>() ;

		if ( CHARACTER_CHUNKS_DEBUG )
			System.out.println("\nProcessing Line: " + line) ;

		List<Float> gaps = computeGaps(line) ;

		if ( CHARACTER_CHUNKS_DEBUG )
		{
			System.out.println("\tPrinting Gaps: ") ;
			System.out.print("\t\t") ;
			for ( int j=0 ; j<line.size()-1 ; j++ )
			{
				PDFCharacter char1 = line.get(j) ;
				PDFCharacter char2 = line.get(j+1) ;
				System.out.print("[" + char1.getCharacter() + "-" + char2.getCharacter() + "=" + gaps.get(j) + "], ") ;
			}
			System.out.println() ;
		}

		List<List<Float>> gapGroups = createGapGroups(gaps) ;

		if ( CHARACTER_CHUNKS_DEBUG )
			System.out.println("\tGap Groups: " + gapGroups) ;

		if ( CHARACTER_CHUNKS_DEBUG )
			System.out.println("\tFinding Biggest Group ...") ;

		List<Float> biggestGroup = new ArrayList<Float>() ;
		int maxSize = Integer.MIN_VALUE ;
		for ( int j=0 ; j<gapGroups.size() ; j++ )
		{
			List<Float> group = gapGroups.get(j) ;

			if ( CHARACTER_CHUNKS_DEBUG )
				System.out.println("\t\tThis Group = " + group) ;

			Pair<Float, Float> minMax = findMinMaxGaps(group) ;

			if ( CHARACTER_CHUNKS_DEBUG )
				System.out.println("\t\t\tMin, Max = " + minMax) ;

			int size = group.size() ;

			if ( maxSize < size && minMax.getA().floatValue() <= averageSpaceWidth && averageSpaceWidth != 0.0f )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
			else if ( maxSize < size && minMax.getA().floatValue() <= averageSpaceWidth && averageSpaceWidth != 0.0f )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
			else if ( minMax.getA().floatValue() <= averageCharacterWidth && averageCharacterWidth != 0.0f )
			{
				maxSize = size ;
				biggestGroup = group ;
			}
		}

		if ( CHARACTER_CHUNKS_DEBUG )
			System.out.println("\tBiggest Group: " + biggestGroup) ;

		Pair<Float, Float> minMax = findMinMaxGaps(biggestGroup) ;
		float padding = 1.0f ;

		float maxGap = minMax.getB().floatValue() + padding ;
		/*float maxGap = minMax.getA().floatValue() - padding ;
		maxGap = maxGap < 0.0f ? 0.0f : maxGap ;*/

		if ( CHARACTER_CHUNKS_DEBUG )
			System.out.println("\tMax Gap = " + maxGap) ;

		List<PDFCharacter> thisChunk = new ArrayList<PDFCharacter>() ;
		PDFCharacter lastCharacter = null ;
		for ( int j=0 ; j<line.size() ; j++ )
		{
			PDFCharacter character = line.get(j) ;

			if ( lastCharacter == null || thisChunk.size() == 0 )
			{
				thisChunk.add(character) ;
				lastCharacter = character ;

				continue ;
			}

			float gap = character.getX1() - lastCharacter.getX2() ;

			if ( gap < maxGap )
			{
				thisChunk.add(character) ;
				lastCharacter = character ;

				continue ;
			}

			chunks.add(new ArrayList<PDFCharacter>(thisChunk)) ;

			thisChunk = new ArrayList<PDFCharacter>() ;
			lastCharacter = null ;

			thisChunk.add(character) ;
			lastCharacter = character ;
		}
		if ( thisChunk.size() != 0 )
		{
			chunks.add(new ArrayList<PDFCharacter>(thisChunk)) ;
			thisChunk = new ArrayList<PDFCharacter>() ;
		}

		if ( CHARACTER_CHUNKS_DEBUG )
		{
			System.out.println("\tPrinting Chunks:") ;
			System.out.print("\t\t");
			for ( int j=0 ; j<chunks.size() ; j++ )
			{
				List<PDFCharacter> chunk = chunks.get(j) ;
				System.out.print("  " + chunk + ", ") ;
			}
			System.out.println() ;
		}

		return chunks ;
	}

	private float computeAverageSpaceWidth(List<List<PDFCharacter>> characterLines) 
	{
		float sum = 0.0f ;
		float count = 0.0f ;

		for ( int i=0 ; i<characterLines.size() ; i++ )
		{
			List<PDFCharacter> line = characterLines.get(i) ;
			for ( int j=0 ; j<line.size() ; j++ )
			{
				PDFCharacter character = line.get(j) ;

				if ( !character.getCharacter().trim().equalsIgnoreCase("") )
					continue ;

				float width = character.getX2() - character.getX1() ;

				sum = sum + width ;
				count = count + 1.0f ;
			}
		}

		float average = count == 0.0f ? 0.0f : (sum/count) ;

		return average ;
	}

	private List<List<Float>> createGapGroups(List<Float> gaps)
	{
		List<List<Float>> gapGroups = new ArrayList<List<Float>>() ;
		for ( int i=0 ; i<gaps.size() ; i++ )
		{
			float thisGap = gaps.get(i) ;

			boolean foundGroup = false ;
			for ( int j=0 ; j<gapGroups.size() ; j++ )
			{
				List<Float> thisGroup = gapGroups.get(j) ;
				Pair<Float, Float> pair = findMinMaxGaps(thisGroup) ;
				float minGroupGap = pair.getA().floatValue() - 1.0f ;
				float maxGroupGap = pair.getB().floatValue() + 1.0f ;

				if ( thisGap >= minGroupGap && thisGap <= maxGroupGap )
				{
					thisGroup.add(thisGap) ;
					foundGroup = true ;
					break ;
				}
			}

			if ( !foundGroup )
			{
				List<Float> newGroup = new ArrayList<Float>() ;
				newGroup.add(thisGap) ;
				gapGroups.add(newGroup) ;
			}
		}

		return gapGroups ;
	}

	private Pair<Float, Float> findMinMaxGaps(List<Float> group) 
	{
		float min = Float.MAX_VALUE ;
		float max = Float.MIN_VALUE ;

		for ( int i=0 ; i<group.size() ; i++ )
		{
			float gap = group.get(i) ;

			if ( min > gap )
				min = gap ;

			if ( max < gap )
				max = gap ;
		}

		Pair<Float, Float> pair = new Pair<Float, Float>(min, max) ;
		return pair ;
	}

	private List<Float> computeGaps(List<PDFCharacter> line) 
	{
		List<Float> ret = new ArrayList<Float>() ;

		for ( int i=0 ; i<line.size()-1 ; i++ )
		{
			PDFCharacter char1 = line.get(i) ;
			PDFCharacter char2 = line.get(i+1) ;

			float gap = char2.getX1() - char1.getX2() ;
			gap = gap < 0.0f ? 0.0f : gap ;

			ret.add(gap) ;
		}

		return ret ;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public List<List<PDFCharacter>> getCharacterLines() {
		return characterLines;
	}

	public void setCharacterLines(List<List<PDFCharacter>> characterLines) {
		this.characterLines = characterLines;
	}

	public List<PDFLine> getLines() {
		return lines;
	}

	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}
}
