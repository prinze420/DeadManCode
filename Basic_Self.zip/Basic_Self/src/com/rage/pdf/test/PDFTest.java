package com.rage.pdf.test;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.parse.CharacterCreator;
import com.rage.siapp.extraction.pdf.parse.LineExtraction;

public class PDFTest {
	
	
	static List<PDFCharacter> characters;
	
	public static void main(String[] args) 
	{
		System.out.println("Start");
		try
		{
			
			//String fileName = "./testCase/881304_AYI.pdf" ;	
			//String fileName = "./testCase/048130a_2014-09.pdf";
			String fileName = "./testCase/contract.pdf" ;
			
			PDDocument document = PDDocument.load(new File(fileName)) ;
			List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;
			Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= getPageCharacterMap(pages);
			for (Integer pgNO:pageWiseCharacterMap.keySet())
			{
				characters=pageWiseCharacterMap.get(pgNO);
			}
		
			
			/*for(int i=0;i<characters.size();i++)
			{
				System.out.print(characters.get(i));
			}*/
			
			LineExtraction lineExt = new LineExtraction(pageWiseCharacterMap);
			lineExt.createLines();
			
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("End");
	}

	private static Map<Integer, List<PDFCharacter>> getPageCharacterMap(List<PDPage> pages) 
	{
		Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= new TreeMap<Integer,List<PDFCharacter>>();
		for(int i=0;i<pages.size();i++)
		{
			PDPage page=pages.get(i);
			CharacterCreator cc= new CharacterCreator();
			List<PDFCharacter> characters=cc.createCharacters(page);
			pageWiseCharacterMap.put(i, characters);
		}
		
		return pageWiseCharacterMap;
	}

}
