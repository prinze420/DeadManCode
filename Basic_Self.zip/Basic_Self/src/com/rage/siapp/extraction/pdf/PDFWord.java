package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

public class PDFWord extends PDFBoundedObject {

	String word;
	List<PDFCharacter> charInWords;
	
	
	public PDFWord(String word, List<PDFCharacter> charInWords, float x1, float y1, float x2, float y2) {
		this.word=word;
		this.charInWords = new ArrayList<PDFCharacter>(charInWords);
		setBounds("PDFWord", x1, y1, x2, y2);
		
		
	}


	public String getWord() {
		return word;
	}


	public void setWord(String word) {
		this.word = word;
	}


	public List<PDFCharacter> getCharInWords() {
		return charInWords;
	}


	public void setCharInWords(List<PDFCharacter> charInWords) {
		this.charInWords = charInWords;
	}


	@Override
	public String toString() {
		return "PDFWord [word=" + word + ", charInWords=" + charInWords + "]";
	}

}
