package com.rage.siapp.extraction.pdf;

import java.io.Serializable;

public class PDFFont implements Comparable<PDFFont>, Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4957314986215316836L;
	private String name ;
	private String type ;
	private float size ;
	
	PDFFont(String name, String type, float size)
	{
		setName(name) ;
		setType(type) ;
		setSize(size) ;
	}
	
	@Override
	public int compareTo(PDFFont other) 
	{
		if ( getSize() != other.getSize() )
			return new Float(getSize()).compareTo(new Float(other.getSize())) ;
		
		if ( !getName().equalsIgnoreCase(other.getName()) )
			return getName().toLowerCase().compareTo(other.getName().toLowerCase()) ;
		
		if ( !getType().equalsIgnoreCase(other.getType()) )
			return getType().toLowerCase().compareTo(other.getType().toLowerCase()) ;
		
		return 0 ;
	}
	
	@Override
	public String toString() 
	{
		return "[" + getSize() + ", " + getName() + ", " + getType() + "]" ;
	}
	
	@Override
	public int hashCode() 
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		result = prime * result + Float.floatToIntBits(size);
		result = prime * result + ((type == null) ? 0 : type.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		PDFFont other = (PDFFont) obj;
		
		if (name == null) 
		{
			if (other.name != null)
				return false;
		}
		else if (!name.equals(other.name))
			return false;
		
		if (Float.floatToIntBits(size) != Float.floatToIntBits(other.size))
			return false;
		
		if (type == null) 
		{
			if (other.type != null)
				return false;
		}
		else if (!type.equals(other.type))
			return false;
		
		return true;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public float getSize() {
		return size;
	}

	public void setSize(float size) {
		this.size = size;
	}
}
