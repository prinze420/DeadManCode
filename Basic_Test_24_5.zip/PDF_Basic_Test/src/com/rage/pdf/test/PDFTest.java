package com.rage.pdf.test;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFParagraph;
import com.rage.siapp.extraction.pdf.PDFWord;
import com.rage.siapp.extraction.pdf.parse.CharacterCreator;
import com.rage.siapp.extraction.pdf.parse.ChunkCreator;
import com.rage.siapp.extraction.pdf.parse.LineCreator;
import com.rage.siapp.extraction.pdf.parse.ParaChunkCreator;
import com.rage.siapp.extraction.pdf.parse.ParaCreator;
import com.rage.siapp.extraction.pdf.parse.TableDetection;
import com.rage.siapp.extraction.pdf.parse.WordCreator;


public class PDFTest {
	
	static List<PDFCharacter> characters;
	static List<PDFLine> lines;
	static List<PDFWord> words;
	static List<PDFParagraph> paras;
	
	public static void main(String[] args) 
	{
		System.out.println("Start");
		try
		{
			characters = new ArrayList<PDFCharacter>();
			lines = new ArrayList<PDFLine>();
			words = new ArrayList<PDFWord>();
			paras = new ArrayList<PDFParagraph>();
			
			//String fileName = "./testCase/Hello Moto.pdf";
			//String fileName = "./testCase/contract.pdf" ;
			String fileName = "./testCase/048130a_2014-09.pdf";
			//String fileName = "./testCase/test_data.pdf";
			//String fileName = "./testCase/881304_AYI_cut.pdf";
			//String fileName = "./testCase/881304_AYI.pdf";
			//String fileName = "./testCase/China_Merchants_Bank_Co.pdf";
			
			PDDocument document = PDDocument.load(new File(fileName)) ;
			
			@SuppressWarnings("unchecked")
			List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;
			
			Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= getPageCharacterMap(pages);
			
			
			for (Integer pgNO:pageWiseCharacterMap.keySet())
			{
				characters=pageWiseCharacterMap.get(pgNO);
				
			}
			
	
	
			
			WordCreator wordCreator = new WordCreator(pageWiseCharacterMap);
			words=wordCreator.extractWords();
			
			/*try
			{
			    
				PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\word.txt", "UTF-8");
				for(int i =0 ;i<words.size();i++)
				{
					    writer.println(" "+words.get(i).getWord()+
					    		" \n["
					    		+words.get(i).getCharacters().get(0).getX1()+
					    		" ,"+words.get(i).getCharacters().get(0).getY1()+
					    		"] ["
					    		+words.get(i).getCharacters().get(words.get(i).getCharacters().size()-1).getX2()+
					    		" ,"+words.get(i).getCharacters().get(words.get(i).getCharacters().size()-1).getY2()+"]\n"
					    		
					    		);
					
					
				}
			    writer.close();
			} 
			catch (IOException e) 
			{
				System.out.println(e);
			}
	*/
			
			
			
			
			
			
			LineCreator lineCreator = new LineCreator(words);
			lines=lineCreator.extractLines();
			
			TableDetection tableDetector = new TableDetection(lines);
			tableDetector.markTables();
			
			
			//ChunkCreator chunkCreator = new ChunkCreator(words);
			//chunkCreator.extractChunks();
			

			/*try
			{
			    
				PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\line.txt", "UTF-8");
				for(int i =0 ;i<lines.size();i++)
				{
					    writer.println(lines.get(i).getline());
					    //writer.println();
					
					
				}
			    writer.close();
			} 
			catch (IOException e) 
			{
				System.out.println(e);
			}
		*/
			
			
			
			
			
			//ParaCreator paraCreator = new ParaCreator(lines);
			//paras=paraCreator.extractParas();
			
			//ParaChunkCreator paraChunkCreator =  new ParaChunkCreator(paras);
			//paraChunkCreator.extractParaChunks();
			
			
			/*try
			{
			    
				PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\para.txt", "UTF-8");
				for(int i =0 ;i<paras.size();i++)
				{
					    writer.println("paras# "+i +" "+paras.get(i));
					    writer.println();
					
					
				}
			    writer.close();
			} 
			catch (IOException e) 
			{
				System.out.println(e);
			}
				*/		
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("End");
	}

	

	
	




	private static Map<Integer, List<PDFCharacter>> getPageCharacterMap(List<PDPage> pages) 
	{
		Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= new TreeMap<Integer,List<PDFCharacter>>();
		for(int i=0;i<pages.size();i++)
		{
			PDPage page=pages.get(i);
			CharacterCreator cc= new CharacterCreator();
			List<PDFCharacter> characters=cc.createCharacters(page);
			
			pageWiseCharacterMap.put(i, characters);
		}
		
		return pageWiseCharacterMap;
	}

}
