package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

public class PDFLine {

	String line;
	List<PDFWord> words;
	
	
	public PDFLine(String line, List<PDFWord> wordsInLine) {
		this.line=line;
		this.words= new ArrayList<PDFWord>(wordsInLine);
	}

	
	public PDFLine(String line)
	{
		this.line=line;
	}
	
	
	public String getline() {
		return line;
	}
	
	public void setline(String line) {
		this.line = line;
	}
	
	public List<PDFWord> getwords() {
		return words;
	}
	
	public void setwords(List<PDFWord> words) {
		this.words = words;
	}

	
	@Override
	public String toString() {
		//return "PDFLine [line=" + line + ", words=" + words + "]";
		return "PDFLine [line=" + line + "]";
	}
	
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((line == null) ? 0 : line.hashCode());
		result = prime * result + ((words == null) ? 0 : words.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFLine other = (PDFLine) obj;
		if (line == null) {
			if (other.line != null)
				return false;
		} else if (!line.equals(other.line))
			return false;
		if (words == null) {
			if (other.words != null)
				return false;
		} else if (!words.equals(other.words))
			return false;
		return true;
	}

	
	
	
	
}
