package com.rage.siapp.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFWord;

/***
 * 
 * @author Prince Gupta
 * This page is to create words from characters
 *
 */
public class WordCreator {

	
	Map<Integer, List<PDFCharacter>> pageWiseCharacterMap;
	
	List<PDFWord> finalWords;
	List<PDFCharacter> charInWord;
	
	public WordCreator(Map<Integer, List<PDFCharacter>> pageWiseCharacterMap) 
	{
		this.pageWiseCharacterMap=pageWiseCharacterMap;
		finalWords = new ArrayList<PDFWord>();
	}

	public List<PDFWord> extractWords() 
	{
		List<PDFCharacter> listChars = new ArrayList<PDFCharacter>();
		
		charInWord = new ArrayList<PDFCharacter>();
		
		for (Map.Entry<Integer, List<PDFCharacter>> entry : pageWiseCharacterMap.entrySet()) {
			for(PDFCharacter c : entry.getValue())
			{	
				listChars.add(c);
			}
		}
		
		String word=listChars.get(0).getCharacter();
		PDFCharacter ch =listChars.get(0);
		charInWord.add(ch);
		
		for(int i=1;i<listChars.size();i++)
		//for(int i=1;i<10000;i++)
		{
			Float yDiff = listChars.get(i-1).getY1()-listChars.get(i).getY1();
			Float xDiff = listChars.get(i-1).getX1()-listChars.get(i).getX1();
			
			if((yDiff >= 0 || yDiff  <=0) && xDiff < (listChars.get(i).getWidthOfSpace()/2) && !(listChars.get(i).toString().trim().length()==0) )
			{
				if(Math.abs(xDiff)<20)
				{
					word+=listChars.get(i).getCharacter().trim();
					charInWord.add(listChars.get(i));
				}
				else
				{
					if(charInWord.size()>0)
					{
						finalWords.add(new PDFWord(word, charInWord));
						charInWord.clear();
						word="";
						
					}
					
					if(!(listChars.get(i).toString().trim().length()==0))
					{
						word+=listChars.get(i).getCharacter().trim();
						charInWord.add(listChars.get(i));
						
					}
				}		
			}
			else
			{
					if(charInWord.size()>0)
					{
						finalWords.add(new PDFWord(word, charInWord));
						charInWord.clear();
						word="";			
					}
					
					if(!(listChars.get(i).toString().trim().length()==0))
					{
						word+=listChars.get(i).getCharacter().trim();
						charInWord.add(listChars.get(i));
						
					}
			}
		}
		
		return finalWords;
			
	}
	
}
