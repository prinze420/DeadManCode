package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFWord;

public class LineCreator {
	
	
	List<PDFLine> finalLines = new ArrayList<PDFLine>();
	List<PDFWord> words;
	
	List<String> temp = new ArrayList<String>();

	String line="";
	float prevYDiff=0f;
	List<PDFWord> wordsInLine = new ArrayList<PDFWord>();
	float width=0.0f;
	
	
	public LineCreator(List<PDFWord> words) 
	{
		this.words=words;
		//System.out.println("data "+this.words);	
	}
	
	
	
	public List<PDFLine> extractLines() {
	
		
		width=words.get(0).getCharacters().get(0).getWidthOfSpace();
		
		wordsInLine.add(words.get(0));
		line+= words.get(0).getWord()+" ";
		
		
		for(int i=1;i<words.size();i++)
		//for(int i=0;i<100;i++)
		{
			//System.out.println("data "+words.get(i));
			
			
			if((words.get(i).getCharacters().size()==0) )
			{
				words.remove(i);
				
			}
			else if( ((i+1)<words.size()) && (words.get(i+1).getCharacters().size()==0))
			{
				words.remove(i+1);
				add(i);
				
			}
			else
			{
				if((i+1) <  words.size())
				{
					
					add(i);
				}
				else
				{
					line+= words.get(i).getWord()+" ";
					wordsInLine.add(words.get(i));
					finalLines.add(new PDFLine(line,wordsInLine));
					wordsInLine.clear();
				}

			}

		}
		
		/*for (int i = 0; i < finalLines.size(); i++) {
			System.out.println("Line#  "+i +" "+finalLines.get(i));	
		}*/
		
		
		/*try
		{
		    
			PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\line.doc", "UTF-8");
			for(int i =0 ;i<finalLines.size();i++)
			{
				    writer.println("Line# "+i +" "+finalLines.get(i).getline());
				    writer.println();
				
				
			}
		    writer.close();
		} 
		catch (IOException e) 
		{
			System.out.println(e);
		}
		
		*/
		
		
		return finalLines;
		
	}


	private void add(int i) 
	{
		
		List<PDFCharacter> curPdfChar= words.get(i).getCharacters();
		List<PDFCharacter> nextPdfChar= words.get(i+1).getCharacters();
		
		
		
		
		
		if(nextPdfChar.isEmpty())
		{
			nextPdfChar= words.get(i+2).getCharacters();
			System.out.println("next "+nextPdfChar);
		}
		
		float curY = curPdfChar.get((curPdfChar.size()-1)).getY1();
		
		float nextY= nextPdfChar.get(0).getY1();
	
		
		float curX = curPdfChar.get((curPdfChar.size()-1)).getX1();
		float nextX = (nextPdfChar.get(0).getX1());
		
		
		
		
		float yDiff = (curY-nextY) ;
		float xDiff = (curX-nextX) ;
		
		
		/*System.out.println(curPdfChar.get((curPdfChar.size()-1))+" "+curY);
		System.out.println(nextPdfChar.get((0))+" "+nextY);
		System.out.println("X Dif "+xDiff);
		System.out.println("Y Dif "+yDiff);
		System.out.println();
		System.out.println("width "+width);
		*/
		
		//System.exit(0);
		
		
		
		//if( ( (yDiff >=0) || ( Math.abs(yDiff) < Math.abs(prevYDiff)))  || ((( Math.abs(yDiff) - Math.abs(prevYDiff)) <=5)  && xDiff <= width ))
		if( (yDiff >=0 || yDiff <=0)  && xDiff <= width)
		{
			if(( Math.abs(yDiff) < Math.abs(prevYDiff)) || ( ( (int)(Math.abs(yDiff) - Math.abs(prevYDiff)) -2) <=5))
			{
				prevYDiff=yDiff;
				line+= words.get(i).getWord()+" ";
				wordsInLine.add(words.get(i));
			}
			else
			{
				prevYDiff=yDiff;
				line+= words.get(i).getWord()+" ";
				wordsInLine.add(words.get(i));
				
				//temp.add(line);
				
				finalLines.add(new PDFLine(line,wordsInLine));
				wordsInLine.clear();
				line="";
			}

		}
		else
		{
			prevYDiff=yDiff;
			line+= words.get(i).getWord()+" ";
			wordsInLine.add(words.get(i));
			
			//temp.add(line);
			
			finalLines.add(new PDFLine(line,wordsInLine));
			wordsInLine.clear();
			line="";
			
			
		}
		
	}
			


}