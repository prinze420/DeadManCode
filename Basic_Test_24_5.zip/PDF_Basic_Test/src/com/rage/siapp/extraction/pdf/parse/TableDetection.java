package com.rage.siapp.extraction.pdf.parse;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFWord;

public class TableDetection {

	
	
	
	List<PDFLine> listLines;
	public TableDetection(List<PDFLine> lines) {
		this.listLines=lines;
	}

	
	
	
	
	public void markTables() throws Exception
	{
		
		PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\table.txt", "UTF-8");
		String table="";
		
		ArrayList<String> tableData = new ArrayList<String>();
		
		
		PDFLine nextLine;
		PDFLine curLine;
		
		List<PDFLine> data2;
		List<PDFLine> data1;
		
		for(int i=10;i<listLines.size()-1;i++)
		{
			
			curLine= listLines.get(i);
			data1=	processCurLine(curLine);
			 
				 
			nextLine= listLines.get(i+1);
			data2=	processNextLine(nextLine);
				
			int t1=0;
			if( ( (data1.size()==data2.size()) || ((data1.size()-3)<data2.size()) || ((data1.size()+3)<data2.size()) || ((data2.size()+3)<data1.size()) || ((data2.size()-3)<data1.size()) ) && (data1.size()>1) && (data2.size()>1) )
			{
			
				//writer.println("data1 "+data1);
				//writer.println("data2 "+data2);
				//writer.println();
			
				
				for(;t1<data1.size();t1++)
				{
					//writer.print(data1.get(t1).getline());
					table+=data1.get(t1).getline();
					
				}
				
				table+="\n";
				
			}
			else
			{
				if(data1.size()>1)
				{
					for(;t1<data1.size();t1++)
					{
						//writer.print(data1.get(t1).getline());
						table+=data1.get(t1).getline();
						
					}
					tableData.add(table);
					table="";
				}
			}
			//writer.println();
				
		}
		
		for(int a=0;a<tableData.size();a++)
		{
			if( (tableData.get(a).length()>0) )
			{
				writer.println(tableData.get(a));
				writer.println();
			}
			
		}
		 writer.close();
		//System.out.println("Table "+tableData);
		
	}
	
	





	public List<PDFLine> processCurLine(PDFLine curLine)
	{
		List<PDFWord> words1 =curLine.getwords();
		
		
		List<PDFLine> finalLine = new ArrayList<PDFLine>();
		String line="";
		
		
		float X2CurWord=0f;
		float X1nextWord=0f;
		PDFWord curWord;
		PDFWord nextWord;
		List<PDFWord> wordsInLine = new ArrayList<PDFWord>();
		
		for(int w1=0;w1<words1.size();w1++)
		{	
			curWord = words1.get(w1);
			
			
			if(w1+1 < words1.size())
			{
				nextWord = words1.get(w1+1);
				
				
				X2CurWord =curWord.getCharacters().get(words1.get(w1).getCharacters().size()-1).getX2();
				X1nextWord =nextWord.getCharacters().get(0).getX1();
				
				
				if(X1nextWord <= (X2CurWord+5))
				{
					line+=curWord.getWord()+" ";
					wordsInLine.add(curWord);
				}
				else
				{
					
					line+=curWord.getWord()+" ";
					wordsInLine.add(curWord);
					finalLine.add(new PDFLine(line,wordsInLine));
					wordsInLine.clear();
					
					line="";
					
				}
			
			}
			else
			{
				line+=curWord.getWord()+" ";
				wordsInLine.add(curWord);
				finalLine.add(new PDFLine(line,wordsInLine));
				wordsInLine.clear();
				line="";
				
			}
		}
		return finalLine;

	}
	
	
	public List<PDFLine> processNextLine(PDFLine nextLine)
	{
		List<PDFWord> words1 =nextLine.getwords();
		
		
		List<PDFLine> finalLine = new ArrayList<PDFLine>();
		String line="";
		
		float X2CurWord=0f;
		float X1nextWord=0f;
		PDFWord curWord;
		PDFWord nextWord;
		List<PDFWord> wordsInLine = new ArrayList<PDFWord>();
		
		for(int w1=0;w1<words1.size();w1++)
		{	
			curWord = words1.get(w1);
			
			if(w1+1 < words1.size())
			{
				nextWord = words1.get(w1+1);
				
				X2CurWord =curWord.getCharacters().get(words1.get(w1).getCharacters().size()-1).getX2();
				X1nextWord =nextWord.getCharacters().get(0).getX1();
				
				
				if(X1nextWord <= (X2CurWord+5))
				{
					line+=curWord.getWord()+" ";
					wordsInLine.add(curWord);
				}
				else
				{
					
					line+=curWord.getWord()+" ";
					wordsInLine.add(curWord);
					finalLine.add(new PDFLine(line,wordsInLine));
					wordsInLine.clear();
					line="";
					
				}
			
			}
			else
			{
				
				line+=curWord.getWord()+" ";
				wordsInLine.add(curWord);
				finalLine.add(new PDFLine(line,wordsInLine));
				wordsInLine.clear();
				line="";
				
			}
		}

		return finalLine;
	}

}