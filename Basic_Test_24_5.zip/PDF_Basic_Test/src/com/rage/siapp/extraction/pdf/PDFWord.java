package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;

@SuppressWarnings("serial")
public class PDFWord extends PDFBoundedObject{

	@Override
	public String toString() {
		return "PDFWord [word=" + word + ", characters=" + characters + "]";
	}



	String word;
	List<PDFCharacter> characters;
	
	
	public PDFWord(String word, List<PDFCharacter> characters) {
		this.word = word;
		this.characters = new ArrayList<PDFCharacter>(characters);
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((characters == null) ? 0 : characters.hashCode());
		result = prime * result + ((word == null) ? 0 : word.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFWord other = (PDFWord) obj;
		if (characters == null) {
			if (other.characters != null)
				return false;
		} else if (!characters.equals(other.characters))
			return false;
		if (word == null) {
			if (other.word != null)
				return false;
		} else if (!word.equals(other.word))
			return false;
		return true;
	}



	public String getWord() {
		return word;
	}



	public void setWord(String word) {
		this.word = word;
	}



	public List<PDFCharacter> getCharacters() {
		return characters;
	}



	public void setCharacters(List<PDFCharacter> characters) {
		this.characters = characters;
	}

		
}
