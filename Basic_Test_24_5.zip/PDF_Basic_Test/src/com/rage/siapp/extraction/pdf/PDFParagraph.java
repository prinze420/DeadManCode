package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

public class PDFParagraph {

	String enumeration;
	List<PDFLine> lines;
	
	public PDFParagraph(String enumeration, List<PDFLine> lines) {
		this.enumeration=enumeration;
		this.lines= new ArrayList<PDFLine>(lines);
		
	}
	public String getEnumeration() {
		return enumeration;
	}
	public void setEnumeration(String enumeration) {
		this.enumeration = enumeration;
	}
	public List<PDFLine> getLines() {
		return lines;
	}
	public void setLines(List<PDFLine> lines) {
		this.lines = lines;
	}
	@Override
	public String toString() {
		return "PDFParagraph [enumeration=" + enumeration + ", lines=" + lines + "]";
	}
	
	
	
	
	
	
	
}
