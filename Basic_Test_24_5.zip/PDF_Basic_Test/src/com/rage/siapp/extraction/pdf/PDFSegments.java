package com.rage.siapp.extraction.pdf;

public class PDFSegments {

}
