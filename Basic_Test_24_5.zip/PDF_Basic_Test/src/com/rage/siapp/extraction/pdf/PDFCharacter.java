package com.rage.siapp.extraction.pdf;

import java.io.Serializable;
import java.util.Arrays;

import org.apache.pdfbox.util.TextPosition;

public class PDFCharacter extends PDFBoundedObject implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4225194350320128858L;
	private String character ;
	private PDFFont font ;
	private int[] codePoints ;
	private float direction ,widthOfSpace;
	private boolean isDiacritic ;
	private boolean isSuperScript ;
	private boolean isSubScript ;
	
	
	
	
	public PDFCharacter(TextPosition textPosition)
	{	
		
		
		float x3 = textPosition.getXDirAdj() ;
		float y3 = textPosition.getYDirAdj() ;
		float width = textPosition.getWidthDirAdj() ;
		float height = textPosition.getHeightDir() ;
		this.widthOfSpace = textPosition.getWidthOfSpace();
		
		// System.out.println("CHARACTER X AND Y SCALES : " + textPosition.getXScale() + ", " + textPosition.getYScale()) ;
		
		float x1 = x3 ;
		float y1 = y3 - height ;
		float x2 = x3 + width ;
		float y2 = y3 ;
		
		setBounds("PDF-CHARACTER", x1, y1, x2, y2) ;
		
		String character = textPosition.getCharacter() ;
		character = character.equalsIgnoreCase("�") ? "'" : character ;
		character = character.replaceAll("�", "-");
		character = character.replaceAll("[^\\xA2-\\xA5\\x20-\\x7E�]+", " ") ;
		//character = character.replaceAll("[^\\x20-\\x7E]+", " ") ;
		//[^\\xA2-\\xA5\\x20-\\x7E�]

		setCharacter(character) ;
		setCodePoints(textPosition.getCodePoints()) ;
		setDirection(textPosition.getDir()) ;
		setDiacritic(textPosition.isDiacritic()) ;
		setSuperScript(false);
		setSubScript(false);
		setFont(new PDFFont(textPosition.getFont().getBaseFont(), textPosition.getFont().getSubType(), textPosition.getFontSizeInPt())) ;
	}


	public String toCompleteString()
	{
		return getCharacter() + " : COORDINATES : " + super.toString() + " : DIMENSION : [" + getWidth() + ", " + getHeight() + "] : FONTS : " + getFont().toString() +" : SPACE "+ getWidthOfSpace() ;
	}

	@Override
	public String toString() 
	{
		return getCharacter() ;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((character == null) ? 0 : character.hashCode());
		result = prime * result + Arrays.hashCode(codePoints);
		result = prime * result + Float.floatToIntBits(direction);
		result = prime * result + ((font == null) ? 0 : font.hashCode());
		result = prime * result + (isDiacritic ? 1231 : 1237);
		result = prime * result + (isSubScript ? 1231 : 1237);
		result = prime * result + (isSuperScript ? 1231 : 1237);
		result = prime * result + Float.floatToIntBits(widthOfSpace);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFCharacter other = (PDFCharacter) obj;
		if (character == null) {
			if (other.character != null)
				return false;
		} else if (!character.equals(other.character))
			return false;
		if (!Arrays.equals(codePoints, other.codePoints))
			return false;
		if (Float.floatToIntBits(direction) != Float.floatToIntBits(other.direction))
			return false;
		if (font == null) {
			if (other.font != null)
				return false;
		} else if (!font.equals(other.font))
			return false;
		if (isDiacritic != other.isDiacritic)
			return false;
		if (isSubScript != other.isSubScript)
			return false;
		if (isSuperScript != other.isSuperScript)
			return false;
		if (Float.floatToIntBits(widthOfSpace) != Float.floatToIntBits(other.widthOfSpace))
			return false;
		return true;
	}

	public String getCharacter() 
	{
		return character;
	}

	public float getWidthOfSpace() {
		return widthOfSpace;
	}

	public void setWidthOfSpace(float widthOfSpace) {
		this.widthOfSpace = widthOfSpace;
	}
	
	
	
	public void setCharacter(String character) {
		this.character = character;
	}

	public int[] getCodePoints() {
		return codePoints;
	}

	public void setCodePoints(int[] codePoints) {
		this.codePoints = codePoints;
	}

	public float getDirection() {
		return direction;
	}

	public void setDirection(float direction) {
		this.direction = direction;
	}

	public boolean isDiacritic() {
		return isDiacritic;
	}

	
	
	public void setDiacritic(boolean isDiacritic) {
		this.isDiacritic = isDiacritic;
	}

	public PDFFont getFont() {
		return font;
	}

	public void setFont(PDFFont font) {
		this.font = font;
	}
	public boolean isSuperScript() {
		return isSuperScript;
	}

	public void setSuperScript(boolean isSuperScript) {
		this.isSuperScript = isSuperScript;
	}

	public boolean isSubScript() {
		return isSubScript;
	}

	public void setSubScript(boolean isSubScript) {
		this.isSubScript = isSubScript;
	}
	
	
}
