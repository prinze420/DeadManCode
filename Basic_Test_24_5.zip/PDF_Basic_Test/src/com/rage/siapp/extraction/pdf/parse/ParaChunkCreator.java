package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFParagraph;
import com.rage.siapp.extraction.pdf.PDFWord;

public class ParaChunkCreator {
	
	
	
	List<PDFParagraph> paras;
	PrintWriter writer;
	List<String> chunkList = new  ArrayList<String>();
	
	public ParaChunkCreator(List<PDFParagraph> paras) 
	{
		this.paras=paras;		
	}
	
	
	
	public void extractParaChunks() throws Exception {
	
		String chunk="";
		String finalChunk="";
		
		
		
		writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\paraline.txt", "UTF-8");
		for(int i=0;i<paras.size();i++)
		{
			//System.out.println(paras.get(i));
			
			
			
			System.out.println("parasize "+paras.size());
			List<PDFLine> curLine = paras.get(i).getLines();
			System.out.println("Line Size "+curLine.size());
			for(int n=0;n<curLine.size();n++)
			{
				
				List<PDFWord> words = curLine.get(n).getwords();
				System.out.println("Words Size "+words.size());
				for(int w=0;w<=words.size()-1;w++)
				{
					
					PDFWord curWord = words.get(w);
					
					PDFWord nextWord;
					if((w+1)<words.size())
					{
					
						nextWord=words.get(w+1);
						
						float X2curWord = curWord.getCharacters().get(curWord.getCharacters().size()-1).getX2();
						float X1nextWord = nextWord.getCharacters().get(0).getX1();
						
						
						if( ( Math.abs(X2curWord - X1nextWord) <= 6) )
						{
							chunk+=curWord.getWord()+" ";
							
						}
						else
						{
							chunk+=curWord.getWord()+" ";
							finalChunk+=chunk+"\n";
							
							chunk="";
							
						}
					}
					else
					{
						//final else
						chunk+=curWord.getWord()+" ";
						finalChunk+=chunk+"\n";
						
						chunk="";
					}
					
					
					
				}
				
			}
			
			//writer.println("ParaChunks# "+i+"\n"+finalChunk+"----\n");
			chunkList.add(finalChunk);
			
			finalChunk="";
			
		}
		for(int z=0;z<chunkList.size();z++)
		{
			writer.println("ParaChunks# "+z+"\n"+chunkList.get(z)+"----\n");
		}
		writer.close();
		
		
	}
	

}