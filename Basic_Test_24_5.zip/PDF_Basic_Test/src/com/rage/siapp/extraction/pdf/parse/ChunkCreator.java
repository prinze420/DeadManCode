package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFWord;

public class ChunkCreator {
	
	
	
	List<PDFWord> words;
	
	
	public ChunkCreator(List<PDFWord> words) 
	{
		this.words=words;		
	}
	
	
	
	public void extractChunks() {
	
		String chunk="";
		String finalChunk="";
		
		
		for(int i=0;i<words.size()-1;i++)
		{
		
			//String curWord1 = words.get(i).getWord();
			//String nextWord1 = words.get(i+1).getWord();
			//System.out.println("CUR : "+curWord1+" \nNEXT :"+nextWord1);
			//System.out.println();
			
			PDFWord curWord = words.get(i);
			PDFWord nextWord = words.get(i+1);
			
			//chunk=curWord.getWord()+" ";
			
			float X2curWord = curWord.getCharacters().get(curWord.getCharacters().size()-1).getX2();
			float X1nextWord = nextWord.getCharacters().get(0).getX1();
			
			
			//System.out.println("CUR: "+words.get(i).getWord()+" : X2: "+X2curWord+"  NEXT: "+words.get(i+1).getWord()+" : X1:"+X1nextWord);
			//System.out.println();
			
			if( ( Math.abs(X2curWord - X1nextWord) <= 6) )
			{
				chunk+=curWord.getWord()+" ";
				//System.out.println("in if "+chunk);
			}
			else
			{
				chunk+=curWord.getWord()+" ";
				finalChunk+=chunk+"\n";
				
				chunk="";
				//System.out.println("in else "+chunk);
				
			}
			
			
			if(( i+1)==words.size()-1)
			{
				finalChunk+=chunk+"\n";
				
			}
			
			
		}
		//System.out.println(chunk);
		
		try
		{
		    
			PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\chunk.txt", "UTF-8");
			
			{
				    writer.println(finalChunk);
				    writer.println();
				
				
			}
		    writer.close();
		} 
		catch (IOException e) 
		{
			System.out.println(e);
		}
		
		//System.out.println(finalChunk);
		
		
	}


	}