package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.util.List;
import java.util.Vector;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

public class TextPositionsFinder extends PDFTextStripper
{
	private PDPage page ;
	private Vector<TextPosition> textPositions ;
	
	public TextPositionsFinder(PDPage page) throws IOException 
	{
		super();
		super.setSortByPosition(false);
		super.setSuppressDuplicateOverlappingText(true);
		
		setPage(page) ;
		setTextPositions(new Vector<TextPosition>()) ;
	}
	

	public void run()
	{
		try
		{
			if ( getPage().getContents() == null )
				return ;

			processStream(getPage(), getPage().findResources(), getPage().getContents().getStream()) ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PROCESSING STREAM : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
	}
	
	@Override
    protected void processTextPosition(TextPosition text) 
	{
		
		
		getTextPositions().add(text) ;
		
		 //System.out.println(text.getCharacter() + "[" + text.getX() + ", " + text.getY() + "]") ;
    }
	
	public PDPage getPage() {
		return page;
	}

	public void setPage(PDPage page) {
		this.page = page;
	}

	public Vector<TextPosition> getTextPositions() {
		return textPositions;
	}

	public void setTextPositions(Vector<TextPosition> textPositions) {
		this.textPositions = textPositions;
	}
}
