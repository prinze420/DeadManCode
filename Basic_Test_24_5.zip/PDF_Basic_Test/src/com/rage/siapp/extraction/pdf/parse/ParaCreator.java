package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFParagraph;
import com.rage.siapp.extraction.pdf.PDFWord;

public class ParaCreator {

	
	List<PDFLine> listLines;
	
	List<PDFLine> linesInPara = new ArrayList<PDFLine>();
	List<PDFParagraph> finalParas = new ArrayList<PDFParagraph>();
	
	
	
	public ParaCreator(List<PDFLine> lines) {
		this.listLines=lines;
		
	}

	
	public List<PDFParagraph> extractParas()
	{
	
		PDFLine line1 = listLines.get(0);
		PDFLine line2 = null;
		String para="";
		String finalPara="";
		int prevYDiff = 0;
		float maxDiff = 0f;
		String enumeration="";	
		String enumValue="";
		
		for (int i = 1; i < listLines.size(); i++) 
		{
			//System.out.println(listLines.get(i));
			
			line1 = listLines.get(i-1);
			line2 = listLines.get(i);
			
			
			List<PDFWord> wordsLine1 = line1.getwords();
			List<PDFWord> wordsLine2 = line2.getwords();
			
			
				List<PDFCharacter> firstWord1= wordsLine1.get(0).getCharacters();
				List<PDFCharacter> lastWord1= wordsLine1.get(wordsLine1.size()-1).getCharacters();
				
				
				List<PDFCharacter> firstWord2= wordsLine2.get(0).getCharacters();
				List<PDFCharacter> lastWord2= wordsLine2.get(wordsLine2.size()-1).getCharacters();
				
				
				
				//System.out.println("line1 "+wordsLine1);
				//System.out.println("line2 "+wordsLine2);
				
				
				//System.out.println(firstWord.get(0)+" "+firstWord.get(0).getX1()+" "+lastWord.get(lastWord.size()-1)+" "+lastWord.get(lastWord.size()-1).getX1());
				
				//first line first word first char x,y
				float x1Cord1FW = firstWord1.get(0).getX1();
				float y1Cord1FW = firstWord1.get(0).getY1();
				
				//System.out.println("Size "+firstWord1.get(0)+" "+firstWord1.get(0).getFont());
				
				//first line last word last char x,y
				float x2Cord1LW = lastWord1.get(lastWord1.size()-1).getX2();
				float y2Cord1LW = lastWord1.get(lastWord1.size()-1).getY2();
				
				////second line first word first char x,y
				float x1Cord2FW = firstWord2.get(0).getX1();
				float y1Cord2FW = firstWord2.get(0).getY1();
				
				//second line last word last char x,y
				float x2Cord2LW = lastWord2.get(lastWord2.size()-1).getX2();
				float y2Cord2LW = lastWord2.get(lastWord2.size()-1).getY2();
				
				int yDiff= (int)(y2Cord1LW-y1Cord2FW);


				//System.out.println( (x1Cord1FW - x1Cord2FW) );
				//System.out.println( (x2Cord1LW - x2Cord2LW) );
				
				/*System.out.println(lastWord1.get(lastWord1.size()-1));
				System.out.println(firstWord2.get(0));
				System.out.println();
				System.out.println("yDiff "+yDiff);
				System.out.println("prev "+prevYDiff);
				System.out.println();
				*/
				//System.out.println(listLines.size());
				
				//enumeration=addEnum(line1);
				//System.out.println("enum "+enumeration);
				
				
				
				
				if( ((Math.abs( (x1Cord1FW - x1Cord2FW) )<2 ) || ( Math.abs( (x2Cord1LW - x2Cord2LW) ) <2 )) &&  ( (Math.abs(yDiff) < Math.abs(prevYDiff)) || ((Math.abs(yDiff) - Math.abs(prevYDiff) <=5) ) ))
				{
					para+=line1.getline()+"\n";
					
					enumeration=addEnum(line1);
					//System.out.println("enum "+enumeration);
					if(enumeration.trim().length()!=0)
					{
						enumValue = enumeration;
					}
					
					//System.out.println("EV "+enumValue);
					linesInPara.add(line1);
					prevYDiff = yDiff;

					
				}
				else 
				{
											
						para+=line1.getline()+"\n";
						finalPara+=para+"\n";
						linesInPara.add(line1);
						//System.out.println("**"+linesInPara);
					
						
						enumeration=addEnum(line1);
						//System.out.println("enum "+enumeration);
						if(enumeration.trim().length()!=0)
						{
							enumValue = enumeration;
						}
						
						
						finalParas.add(new PDFParagraph(enumValue,linesInPara));
						enumValue="";
						
						para="";
						linesInPara.clear();
						
						
						prevYDiff = yDiff;


						if((i+1)==(listLines.size()))
						{
							System.out.println("in condition if ");
							para+=line2.getline()+"\n";
							finalPara+=para+"\n";
							linesInPara.add(line2);
							
							enumeration=addEnum(line2);
							if(enumeration.trim().length()!=0)
							{
								enumValue = enumeration;
							}
							
							finalParas.add(new PDFParagraph(enumValue,linesInPara));
							enumValue="";
						
							para="";
							linesInPara.clear();
							
						}
						
					
				}
			
		}
		
		//System.out.println(finalPara);
		
		/*try
		{
		    
			PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\para.txt", "UTF-8");
			
				    writer.println(finalPara);
				    writer.println();
				
				
			
		    writer.close();
		} 
		catch (IOException e) 
		{
			System.out.println(e);
		}
		*/
		
		return finalParas;
	}


	


	private String addEnum(PDFLine line) 
	{
		
		//System.out.println("line "+line);
		
		
		String pattern1="^M{0,4}(CM|CD|D?C{0,3})(XC|XL|L?X{0,3})(\\(IX\\)|\\(IV\\)|\\(V?I{0,3}\\))$";
		String pattern2="^m{0,4}(cm|cd|d?c{0,3})(xc|xl|l?x{0,3})(\\(ix\\)|\\(iv\\)|\\(v?i{0,3}\\))$";
		String pattern3="\\([a-zA-Z]+\\.?\\)";
		
			//System.out.println("First "+p+" "+paras.get(p).getLines().get(0).getwords().get(0));
			//PDFWord firstWord = paras.get(p).getLines().get(0).getwords().get(0);
			
			PDFWord firstWord = line.getwords().get(0);
			//System.out.println(firstWord);
			//System.exit(0);
			
			if(firstWord.getWord().matches(pattern1))
			{
		        //System.out.println("if "+firstWord.getWord());
		        return firstWord.getWord();
		    }
			else if(firstWord.getWord().matches(pattern2))
		    {
				//System.out.println("else if"+firstWord.getWord());
				return firstWord.getWord();
		    }
			else if(firstWord.getWord().matches(pattern3))
		    {
				//System.out.println("else if if"+firstWord.getWord());
				return firstWord.getWord();
		    }
			else
			{
				return "";
			}
		
		
		
	}
	

}
