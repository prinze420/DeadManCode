package com.pdf.parser.extraction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.utils.CommonOperations;

import edu.stanford.nlp.util.Comparators;

public class FormProcesses {


	public static  List<PDFSegment> getmatchedSeg(String keySubStr,Map<Integer, List<PDFSegment>> segGroups) {

		List<PDFSegment> temp=new ArrayList<PDFSegment>();
		for ( Integer pg : segGroups.keySet()) {
			List<PDFSegment> ss = segGroups.get(pg);
			for (PDFSegment basicStructure : ss) {

				String ckeyText=basicStructure.getStringRepresentation();
				/*if(basicStructure.isEnumerated()){ //remove enum from text 
					String enTxt = basicStructure.getEnumeration();
					ckeyText=basicStructure.getStringRepresentation().substring(basicStructure.getStringRepresentation().indexOf(enTxt)+enTxt.length()).trim();
				}*/
				if(ckeyText.contains("Gender")){
					System.out.println();
				}
				if(ckeyText.trim().equalsIgnoreCase(keySubStr) 
						||ckeyText.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(keySubStr.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim())
						){
					//return ((PDFSegment)basicStructure);
					temp.add(basicStructure);
				}
			}
		}
		return temp;
	}


	public static List<PDFSegment>getBelowSegs(PDFSegment mainKeyWord_Seg, List<PDFSegment> pageSegments, int i){
		List<PDFSegment> temp=new ArrayList<PDFSegment>();

		//	float belowLineLimit = 3*mainKeyWord_Seg.getRectangle().getHeight();
		int cnt=0;
		for(int segNo=i;segNo<pageSegments.size();segNo++){
			PDFSegment currentSeg = pageSegments.get(segNo);
			if(currentSeg.getRectangle().getY2()>mainKeyWord_Seg.getRectangle().getY()){

				if(CommonOperations.isOverlapOnX(mainKeyWord_Seg, currentSeg) ){//&& cnt <= overlapLineLimit ){
					temp.add(currentSeg);
					cnt++;
				}
			}

		}

		return temp;
	}

	public static List<PDFSegment>getFrontSegment(PDFSegment mainKeyWord_Seg, List<PDFSegment> pageSegments){
		List<PDFSegment> temp=new ArrayList<PDFSegment>();

		for(int segNo=0;segNo<pageSegments.size();segNo++){
			PDFSegment currentSeg = pageSegments.get(segNo);
			if(mainKeyWord_Seg.equals(currentSeg)|| mainKeyWord_Seg.getRectangle().getX2() > currentSeg.getRectangle().getX()){
				continue;
			}
			float ydiff = Math.abs(currentSeg.getRectangle().getY()-mainKeyWord_Seg.getRectangle().getY());
			boolean slightYdiff=false;

			if(currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY2() <= mainKeyWord_Seg.getRectangle().getY() ){
				slightYdiff=true;
			}
			if(currentSeg.getRectangle().getY() <= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY2() ){
				slightYdiff=true;
			}


			if(ydiff<1.0 || slightYdiff){
				temp.add(pageSegments.get(segNo));
			}

		}

		return temp;
	}


	public static List<PDFWord> getcheckBoxWords(PDFSegment matchedSeg,	List<PDFSegment> pageSegs, String checkBoxSecondWords) {
		List<PDFWord> temp=new ArrayList<PDFWord>();
		if(checkBoxSecondWords==null){
			return temp;
		}
		String endWordString="";
		String checkBoxWordsString="";

		if(checkBoxSecondWords.contains("##")){
			endWordString=checkBoxSecondWords.substring(checkBoxSecondWords.lastIndexOf("##"),checkBoxSecondWords.length()).replaceAll("##", "");
			checkBoxWordsString=checkBoxSecondWords.substring(0,checkBoxSecondWords.lastIndexOf("##"));
		}

		List<String>checkBoxWord=new ArrayList<String>();
		checkBoxWord=Arrays.asList(checkBoxWordsString.split("##"));
		outer:	
			for (PDFSegment seg : pageSegs) {
				if(seg.getStringRepresentation().contains("Male")){
					System.out.println("");
				}
				if(seg!=matchedSeg && (seg.getRectangle().getY()>=matchedSeg.getRectangle().getY()|| CommonOperations.isOverlapOnY(matchedSeg, seg))){

					for (PDFWord wrd : seg.getWords()) {
						if(checkBoxWord.contains(wrd.getStringRepresentation())){
							temp.add(wrd);
							continue outer;
						}
					}
					if(!endWordString.isEmpty()){
						if(seg.getStringRepresentation().contains(endWordString)){
							break;
						}
					}
				}
			}
		return temp;
	}

	public static List<PDFWord>getFrontWords(PDFWord mainKeyWord_Seg, List<PDFWord> wordList){
		List<PDFWord> temp=new ArrayList<PDFWord>();

		for(int segNo=0;segNo<wordList.size();segNo++){
			PDFWord currentSeg = wordList.get(segNo);
			if(mainKeyWord_Seg.equals(currentSeg)|| mainKeyWord_Seg.getRectangle().getX2() > currentSeg.getRectangle().getX()){
				continue;
			}
			float ydiff = Math.abs(currentSeg.getRectangle().getY()-mainKeyWord_Seg.getRectangle().getY());
			boolean slightYdiff=false;

			if(currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY2() <= mainKeyWord_Seg.getRectangle().getY() ){
				slightYdiff=true;
			}
			if(currentSeg.getRectangle().getY() <= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY2() ){
				slightYdiff=true;
			}
			if(ydiff<1.0 || slightYdiff){
				temp.add(wordList.get(segNo));
			}

		}
		
		Collections.sort(temp, new Comparator<PDFWord>(){
			@Override
			public int compare(PDFWord o1, PDFWord o2) {
				// TODO Auto-generated method stub
				return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
			}
		});
		
		return temp;
	}

	public static List<PDFWord> getBackWords(PDFWord mainKeyWord_Seg, List<PDFSegment> pageSegs){
		List<PDFWord> temp=new ArrayList<PDFWord>();

		for(int segNo=0; segNo< pageSegs.size();segNo++){
			
			PDFSegment seg = pageSegs.get(segNo);

			if(seg.getStringRepresentation().contains("Gender")){
				System.out.print("");
			}
			for (PDFWord currentWord : seg.getWords()) {
			
				if(mainKeyWord_Seg.equals(currentWord)|| mainKeyWord_Seg.getRectangle().getX2() < currentWord.getRectangle().getX()){
					continue;
				}
				float ydiff = Math.abs(currentWord.getRectangle().getY()-mainKeyWord_Seg.getRectangle().getY());
				boolean slightYdiff=false;

				if(currentWord.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY()&& currentWord.getRectangle().getY2() <= mainKeyWord_Seg.getRectangle().getY() ){
					slightYdiff=true;
				}
				if(currentWord.getRectangle().getY() <= mainKeyWord_Seg.getRectangle().getY()&& currentWord.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY2() ){
					slightYdiff=true;
				}

				if(ydiff<1.0 || slightYdiff){
					temp.add(currentWord);
				}
			}

		}

		Collections.sort(temp, new Comparator<PDFWord>(){
			@Override
			public int compare(PDFWord o1, PDFWord o2) {
				// TODO Auto-generated method stub
				return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
			}
		});
		
		return temp;
	}

}
