
package com.pdf.parser.extraction;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Locale;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;


public class CheckBoxProcessor {
	
	static ResourceBundle imageProcessingConfig;
	static{
		try {
			imageProcessingConfig = ResourceBundle.getBundle("imageProcessingParameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config_extraction").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	private int type2Threshold = Integer.parseInt(imageProcessingConfig.getString("type2Threshold"));
	private int grayThreshold = Integer.parseInt(imageProcessingConfig.getString("grayScaleThreshold")) ;
	
	
	private BufferedImage image;
	private int width;
	private int height;
	
	public int gray (int xImg, int yImg)
	{
		Color c = new Color(image.getRGB(xImg,yImg));
		int red = (int) (c.getRed() * 0.299);
		int green = (int) (c.getGreen() * 0.587);
		int blue = (int) (c.getBlue() * 0.114);

		int k = truncate( red + green + blue);
		return k ;
	}

	private  int truncate(int a) {
		if      (a <   0) return 0;
		else if (a > 255) return 255;
		else              return a;
	}


	public  boolean check_box_LeftDirection(float x_co_ordi, float y_co_ordi, float w, float h, BufferedImage imag) 
	{
		image=imag;
		try {

			width = image.getWidth();
			height = image.getHeight();

			int y = (int)((y_co_ordi * (height / h)));
			int x = (int)(x_co_ordi *(width/w));

			int xStart = x-1;
			int xEnd = x-60;
			final int YSTART = y+40;
			final int YEND = y-30;
			boolean flag=false;
			for (int i = xStart; i >= xEnd && i>0; i--) 
			{
				for(int j= YSTART; j>=YEND;j--)
				{
					int k = gray(i, j);
					int box_Width = 0;
					int box_Height = 0;
					if(k<grayThreshold && !flag)
					{

						for (int a1 = i; a1 >=i-100 ; a1--) { // int a1 = i; a1 >=i-35 ; a1--
							int l = gray(a1, j);
							if (l > grayThreshold)
							{
								box_Width = i-a1;
								break;
							}

						}
						for (int b1 = j; b1 >=j-100 ; b1--) { //int b1 = j; b1 >=j-35 ; b1--
							int l = gray(i, b1);
							if (l > grayThreshold)
							{
								box_Height = j-b1;
								break;
							}
						}

						if(box_Height>25 && box_Width>25)
						{
							flag=true;
//							System.out.println("corner found at- "+ (i - (box_Width-15)) +","+ (j -(box_Height-15)));
							BufferedImage boxImage = new BufferedImage(box_Width-20, box_Height-20, BufferedImage.TYPE_INT_ARGB);
							boxImage = image.getSubimage(i - (box_Width-10),j -(box_Height-10),
									box_Width-20, box_Height-20);
							
							ConnectComponent c = new ConnectComponent();
							if ( c.getConnectedComponent(boxImage)> type2Threshold) {
								return true;
//								System.out.println("By new approach- true");
							}
							
							else return false;
							
						}

						else continue;
						
					}
					else if(i == xEnd && !flag)
					{
						xStart = xEnd - 1; 
						xEnd = xEnd -21;
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return false;

	}

	
	public  boolean check_box_RightDirection(float x2_co_ordi, float y_co_ordi, float w, float h, BufferedImage imag) 
	{
		image=imag;
		try {

			width = image.getWidth();
			height = image.getHeight();

			int y = (int)((y_co_ordi) * (height / h));
			int x = (int)(x2_co_ordi *(width/w));
			int xStart = x+1;
			int xEnd = x+80;
			final int YSTART = y+40;
			final int YEND = y-30;

			boolean flag=false;
			for (int i = xStart; i <= xEnd && i<width; i++) 
			{
				for(int j= YSTART; j>=YEND;j--)
				{
					
					int k = gray(i, j);
					int box_Width = 0;
					int box_Height = 0;
					if(k<230 && !flag)
					{

						for (int a1 = i; a1 <=i+100 ; a1++) { // int a1 = i; a1 >=i-35 ; a1--
							int l = gray(a1, j);
							if (l > 230)
							{
								box_Width = a1-i;
								break;
							}

						}
						for (int b1 = j; b1 >=j-100 ; b1--) { //int b1 = j; b1 >=j-35 ; b1--
							int l = gray(i, b1);
							if (l > 230)
							{
								box_Height = j-b1;
								break;
							}
						}

						if(box_Height>25 && box_Width>25)
						{
//							System.out.println("corner found at-"+i+","+j+"\n"+box_Width+","+box_Height);
							flag=true;
							BufferedImage boxImage = new BufferedImage(box_Width-20, box_Height-20, BufferedImage.TYPE_INT_ARGB);
							boxImage = image.getSubimage(i + 15 ,j -(box_Height-15),
									box_Width-30, box_Height-30);
							ConnectComponent c = new ConnectComponent();
							if ( c.getConnectedComponent(boxImage)> type2Threshold) {
								return true;
							}
							
							else return false;
							
						}

						else continue;
					}
					else if(i == xEnd && !flag)
					{
						xStart = xEnd + 1; 
						xEnd = xEnd + 21;
					}
				}

			}

		} catch (Exception e) {
			e.printStackTrace();

		}

		return false;

	}

	public static void main(String args[]) throws IOException{

		String filepath = "D:/Extraction_Platform/NewMoodys/samples/2009269840.pdf";
		int pg=0;
		File file =new File(filepath);
		PDDocument pdf = PDDocument.load(filepath);
		FileInputStream input = new FileInputStream(file);
		PDPage page = (PDPage) pdf.getDocumentCatalog().getAllPages().get(pg);
//		PDFParser parser = new PDFParser(input);
//		parser.parse();
		
		BufferedImage img = page.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
		ImageIO.write(img, "PNG", new File("D:/Extraction_Platform/NewMoodys/samples/Images/2009269840.png"));
		
		float hRatio = page.getMediaBox().getHeight();
		float wRatio = page.getMediaBox().getWidth(); 
		
		CheckBoxProcessor chk = new CheckBoxProcessor();
//		boolean mark = chk.check_box_RightDirection(179, 292 , wRatio, hRatio, img);
//		boolean mark = chk.check_box_LeftDirection((float)272.15982,(float) 502.5599 , wRatio, hRatio, img); // unknown above yes
//		boolean mark = chk.check_box_LeftDirection((float)272.15982,(float) 514.73987 , wRatio, hRatio, img); // unknown 
//		boolean mark = chk.check_box_LeftDirection((float)134.51923,(float) 265.98022 , wRatio, hRatio, img); // Female
//		boolean mark = chk.check_box_LeftDirection((float)458.71,(float) 219.02002 , wRatio, hRatio, img); // Male
//		boolean mark = chk.check_box_LeftDirection((float)272.3118,(float) 517.85 , wRatio, hRatio, img); // Male
		boolean mark = chk.check_box_LeftDirection((float)84.718,(float) 193.568 , wRatio, hRatio, img); // Male

		System.out.println(mark);

	}

}
