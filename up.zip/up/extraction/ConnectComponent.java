package com.pdf.parser.extraction;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.awt.image.WritableRaster;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

/**
 * Use row-by-row labeling algorithm to label connected components
 * The algorithm makes two passes over the image: one pass to record
 * equivalences and assign temporary labels and the second to replace each
 * temporary label by the label of its equivalence class.
 * [Reference]
 * Linda G. Shapiro, Computer Vision: Theory and Applications.  (3.4 Connected
 * Components Labeling)
 * Rosenfeld and Pfaltz (1966)
 */
public class ConnectComponent
{
    final int MAX_LABELS= 80000;
    int next_label = 1;

    /**
     * label and re-arrange the labels to make the numbers of label continuous
     * @param zeroAsBg Leaving label 0 untouched
     */
    public int[] compactLabeling(int[] image, Dimension d, boolean zeroAsBg)
    {
        //label first
        int[] label= labeling(image,d,zeroAsBg);
        int[] stat= new int[next_label+1];
        for (int i=0;i<image.length;i++) {
            if (label[i]>next_label)
                System.err.println("bigger label than next_label found!");
            stat[label[i]]++;
        }

        stat[0]=0;              // label 0 will be mapped to 0
                                // whether 0 is background or not
        int j = 1;
        for (int i=1; i<stat.length; i++) {
            if (stat[i]!=0) stat[i]=j++;
        }

        System.out.println("From "+next_label+" to "+(j-1)+" regions");
        next_label= j-1;
        for (int i=0;i<image.length;i++) label[i]= stat[label[i]];
        return label;
    }

    /**
     * return the max label in the labeling process.
     * the range of labels is [0..max_label]
     */
    public int getMaxLabel() {return next_label;}


    /**
     * Label the connect components
     * If label 0 is background, then label 0 is untouched;
     * If not, label 0 may be reassigned
     * [Requires]
     *   0 is treated as background
     * @param image data
     * @param d dimension of the data
     * @param zeroAsBg label 0 is treated as background, so be ignored
     */
    public int[] labeling(int[] image, Dimension d, boolean zeroAsBg)    
    {
        int w= d.width, h= d.height;
        int[] rst= new int[w*h];
        int[] parent= new int[MAX_LABELS];
        int[] labels= new int[MAX_LABELS];
        // region label starts from 1;
        // this is required as union-find data structure
        int next_region = 1;
        for (int y = 0; y < h; ++y ){
            for (int x = 0; x < w; ++x ){
                if (image[y*w+x] == 0 && zeroAsBg) continue;
                int k = 0;
                boolean connected = false;
                // if connected to the left
                if (x > 0 && image[y*w+x-1] == image[y*w+x]) {
                   k = rst[y*w+x-1];
                   connected = true;
                }
                // if connected to the up
                if (y > 0 && image[(y-1)*w+x]== image[y*w+x] &&
                    (connected = false || image[(y-1)*w+x] < k )) {
                    k = rst[(y-1)*w+x];
                    connected = true;
                 }
                if ( !connected ) {
                    k = next_region;
                    next_region++;
                }

                if ( k >= MAX_LABELS ){
                    System.err.println("maximum number of labels reached. " +
                        "increase MAX_LABELS and recompile." );
                    System.exit(1);
                }
                rst[y*w+x]= k;
                // if connected, but with different label, then do union
                if ( x> 0 && image[y*w+x-1]== image[y*w+x] && rst[y*w+x-1]!= k )
                        uf_union( k, rst[y*w+x-1], parent );
                if ( y> 0 && image[(y-1)*w+x]== image[y*w+x] && rst[(y-1)*w+x]!= k )
                        uf_union( k, rst[(y-1)*w+x], parent );
            }
        }

        // Begin the second pass.  Assign the new labels
        // if 0 is reserved for background, then the first available label is 1
        next_label = 1;
        for (int i = 0; i < w*h; i++ ) {
            if (image[i]!=0 || !zeroAsBg) {           
                rst[i] = uf_find( rst[i], parent, labels );                
                // The labels are from 1, if label 0 should be considered, then
                // all the label should minus 1
                if (!zeroAsBg) rst[i]--;
            }
        }
        next_label--;   // next_label records the max label
        if (!zeroAsBg) next_label--;

        System.out.println(next_label+" regions");

        return rst;
    }
    void uf_union( int x, int y, int[] parent)
    {
        while ( parent[x]>0 )
            x = parent[x];
        while ( parent[y]>0 )
            y = parent[y];
        if ( x != y ) {
            if (x<y)
                parent[x] = y;
            else parent[y] = x;
        }
    }

    /**
     * This function is called to return the root label
     * Returned label starts from 1 because label array is inited to 0 as first
     * [Effects]
     *   label array records the new label for every root
     */
    int uf_find( int x, int[] parent, int[] label)

     {
        while ( parent[x]>0 )
            x = parent[x];
        if ( label[x] == 0 )
            label[x] = next_label++;
        return label[x];
    }
    
    public int getConnectedComponent (BufferedImage image) {
    	if (image.getType() != BufferedImage.TYPE_INT_ARGB) {
	        BufferedImage tmp = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
	        tmp.getGraphics().drawImage(image, 0, 0, null);
	        image = tmp;
	    }
    	int count=0;
	    int[] srcPixels = ((DataBufferInt)image.getRaster().getDataBuffer()).getData();
	    Dimension d = new Dimension(image.getWidth(), image.getHeight());
	    
	    ConnectComponent c = new ConnectComponent();
    	int [] all_region = c.compactLabeling(srcPixels , d ,false);
    	int [] regionsCount = new int[c.next_label+1];
    	for (int i : all_region) {
//    		System.out.println(i);
			regionsCount[i]++;
		}
    	for (int i=1; i<regionsCount.length; i++) {
			if (count<regionsCount[i]) {
				count = regionsCount[i];
			}
		}
    	System.out.println(count);
		return count;
	}
    public List<Integer> getNeighbourhood(int x, int y) {
		List<Integer> neighbours = new ArrayList<Integer>();
		CheckBoxProcessor c = new CheckBoxProcessor();
		neighbours.add(c.gray(x+1, y));
		neighbours.add(c.gray(x+1, y-1));
		neighbours.add(c.gray(x, y-1));
		neighbours.add(c.gray(x-1,y-1));
		neighbours.add(c.gray(x-1,y));
		neighbours.add(c.gray(x-1,y+1));
		neighbours.add(c.gray(x,y+1));
		neighbours.add(c.gray(x+1,y+1));
		
		return neighbours;
	}
	
	public   Point getNextPixel(int x, int y , int val) {
		Map<Integer, Point> connectivityVal = new HashMap<Integer, Point>();
		connectivityVal.put(0, new Point(x+1, y));
		connectivityVal.put(1, new Point(x+1, y-1));
		connectivityVal.put(2, new Point(x, y-1));
		connectivityVal.put(3, new Point(x-1,y-1));
		connectivityVal.put(4, new Point(x-1,y));
		connectivityVal.put(5, new Point(x-1,y+1));
		connectivityVal.put(6, new Point(x,y+1));
		connectivityVal.put(7, new Point(x+1,y+1));
		
		return connectivityVal.get(val);
		
	}
	
	public boolean findConnectedPixel(int x, int y ,int width, int hieght, int threshold ) {
		
		int connectedCount = 0;
		CheckBoxProcessor c = new CheckBoxProcessor();
		boolean counting = true;
		for (int i = x; i <x+width ; i++) {
			for (int j = y; j < y+hieght; j++) {
				connectedCount = 0;
				if (c.gray(i, j)<150) {
					Point p = new Point(i, j);
					List<Point> existing = new ArrayList<Point>();
					while (counting) {
						
						List<Integer> neighbours =getNeighbourhood(p.x,p.y);
						for (int i1 = 7; i1 >= 0; i1--) {
							if (neighbours.get(i1)<150) {
								
								p = getNextPixel(p.x, p.y, i1);
								connectedCount ++;
								counting = true;
								if (existing.isEmpty() || !existing.contains(p)) {
									existing.add(p);
								}
								else //if(!existing.isEmpty() && existing.contains(p)) {
								{	
//									counting = false;
									continue;
								}
								neighbours.clear();
								break;
							}
							counting = false;
						}
						/*if (connectedCount > threshold) {
							return true;
						}*/
						
					}
					System.out.println(connectedCount);
					if (connectedCount > threshold) {
						return true;
					}
					
				}
				
			}
			
		}
		System.out.println(connectedCount);
		if (connectedCount > threshold) {
			
			return true;
		}
		
		return false;
	}
	
    
    public static void main(String[] args){  
    	BufferedImage image = null;
	    File f = null;
	    try{
	    f = new File("check2.png");
	    image = ImageIO.read(f);
	    
	    if (image.getType() != BufferedImage.TYPE_INT_ARGB) {
	        BufferedImage tmp = new BufferedImage(image.getWidth(), image.getHeight(), BufferedImage.TYPE_INT_ARGB);
	        tmp.getGraphics().drawImage(image, 0, 0, null);
	        image = tmp;
	    }
	    ConnectComponent c = new ConnectComponent();
	     int count = c.getConnectedComponent(image);
	     System.out.println("Connected Component count-"+ count);
	   
    	
      }catch(IOException e){
	      System.out.println("Error: "+e);
	    }
}
}