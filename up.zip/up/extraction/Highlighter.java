package com.pdf.parser.extraction;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.graphics.color.PDGamma;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotation;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.rules.Extraction_Result;
import com.pdf.parser.utils.CommonOperations;




public class Highlighter {

	public static List<PDFSegment> gettLabelSegs(int page,  DefaultParser parser, String label) {

		List<PDFSegment> labelSeg = new ArrayList<PDFSegment>();

		String txt = "";
		for (int i = 0; i < parser.getSegments().get(page).size(); i++) {
			PDFSegment segment = parser.getSegments().get(page).get(i);
			// seg must start with label 
			if (label.trim().startsWith(segment.getStringRepresentation().trim())) {
				// if single seg and label are totally matched  
				if (label.trim().equalsIgnoreCase(segment.getStringRepresentation().trim())) {
					//System.out.println("\nmatched:" + segment.getStringRepresentation());
					labelSeg.add(segment);
					return labelSeg;

				} else if (label.trim().contains(segment.getStringRepresentation().trim())) {
					// if single seg and label are partially matched  
					//System.out.println("\npartial matched :" + segment.getStringRepresentation());
					for (int j = 0; j < parser.getSegments().get(page).size(); j++) {
						PDFSegment nextSeg = parser.getSegments().get(page).get(j);
						if (segment.getRectangle().getY() == nextSeg.getRectangle().getY()) {
							txt = txt + nextSeg.getStringRepresentation().trim() + " ";
							labelSeg.add(nextSeg);
						}
					}

					//if all label got in single x line i.e. above txt
					if (label.replaceAll("\\s+"," ").trim().equalsIgnoreCase((txt.replaceAll("\\s+"," ").trim()))) {
						return labelSeg;
					}

					//if txt(y line) not contains in label then consider only current seg not next segments of same y
					if (!label.replaceAll("\\s+", " ").trim().contains(txt.replaceAll("\\s+", " ").trim())) {
						labelSeg.clear();
						txt = "";
						txt = segment.getStringRepresentation();
						labelSeg.add(segment);
					}

					// go ahead cos total label still dosen't cached; checked with next line (can say overlapped) segments
					do {
						PDFSegment overlapedSeg = getOverlapedSeg(segment, parser.getSegments().get(page));
						if (overlapedSeg != null) {
							txt = txt + " " + overlapedSeg.getStringRepresentation();

						} else {
							break;
						}
						labelSeg.add(overlapedSeg);
					} while (!label.trim().equalsIgnoreCase(txt.trim()) && label.contains(txt));

					//finally check with cached string "txt" and "label" string
					if (label.replaceAll("\\s+", " ").trim().equalsIgnoreCase(txt.replaceAll("\\s+", " ").trim())) {
						//	System.out.println("##txt: " + txt);
						return labelSeg;
					} else {
						labelSeg.clear();
					}
				}

			}
		}
		return labelSeg;
	}

	public static PDFSegment getOverlapedSeg(PDFSegment s1, List<PDFSegment> allSeg) {

		for (PDFSegment pdfSegment : allSeg) {

			float diff = pdfSegment.getRectangle().getY() - s1.getRectangle().getY();

			if (s1.getRectangle().getY() < pdfSegment.getRectangle().getY() && diff > 2 && diff <= 15) {

				if (CommonOperations.isOverlapOnX(s1, pdfSegment)) {
					return pdfSegment;
				}
			}
		}
		return null;
	}

	@SuppressWarnings("unchecked")
	public static void highLightResult(String pdfFileName, List<Extraction_Result> searchResult,String highlight_outputFilePath) {

		System.out.println("highlight_outputFilePath "+highlight_outputFilePath);
		PDDocument pdf = null;
		List<PDPage> pages = null;
		try{
			pdf = PDDocument.load(new File(pdfFileName));
			pages = (List<PDPage>) pdf.getDocumentCatalog().getAllPages();
		} catch (IOException e) {
			e.printStackTrace();
		}

		for (Extraction_Result rslt : searchResult) {

			// highlight Extracted result segments

			List<BasicStructure> allResultSegs = rslt.getResultSegments();
			if (!rslt.getOutputList().isEmpty() && allResultSegs!=null && !allResultSegs.isEmpty()) {
				if(rslt.getRule().getRuleId()==1){
					System.out.println();
				}
				List<BasicStructure>resultMatchedSegment =	getMatchedSegments(allResultSegs,rslt.getOutputList());
				//				System.out.println("");
				if(resultMatchedSegment!=null && !resultMatchedSegment.isEmpty()){
					for (BasicStructure pdfSegment : resultMatchedSegment) {
						try {
							PDPage page = pages.get(pdfSegment.getRectangle().getPage());
							highlight(pdf, page, pdfSegment.getRectangle().getX2(), pdfSegment.getRectangle().getY(),
									pdfSegment.getRectangle().getX(), pdfSegment.getRectangle().getY2(), "yellow");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}

			}else{
				System.out.println("segment detection failed for "+rslt.getRule()); 
			}
		}

		try {
			//System.out.println("highlighting Data");
			pdf.save(highlight_outputFilePath);
			System.out.println("\nhighlighting process end***");
			pdf.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static List<BasicStructure> getMatchedSegments(List<BasicStructure> allSegs, List<String> outputList) {

		List<BasicStructure> temp=new ArrayList<BasicStructure>();

		for (String string : outputList) {
			for (BasicStructure seg : allSegs) {
				String pureSeg=seg.getStringRepresentation().replaceAll("[^0-9A-Za-z ]", "").replaceAll("\\s+", " ").trim();
				String pureString=string.replaceAll("[^0-9A-Za-z ]", "").replaceAll("\\s+", " ").trim();
				if(string.contains(seg.getStringRepresentation())||seg.getStringRepresentation().contains(string)){
					temp.add(seg);
				}else if(pureString.contains(pureSeg)||pureSeg.contains(pureString)){
					temp.add(seg);
				}
				
				/*else if((string.replaceAll("[^0-9A-Za-z ]", "").contains(seg.getStringRepresentation().replaceAll("[^0-9A-Za-z ]", "")))||seg.getStringRepresentation().replaceAll("[^0-9A-Za-z ]", "").contains(string.replaceAll("[^0-9A-Za-z ]", ""))){
					temp.add(seg);
				}*/
			}
		}
		return temp;
	}

	public static void highlight(PDDocument document, PDPage page, float x1, float y1, float x3, float y3,
			String blockcolor) throws Exception {

		if (y1 == y3) {
			y1 = y3 - 7;
		}
		List<PDAnnotation> annotations = new Vector<PDAnnotation>(page.getAnnotations());
		PDRectangle mediaBox = page.getBleedBox();
		float pageHeight = mediaBox.getHeight();
		PDGamma color = new PDGamma();

		if (blockcolor.toLowerCase().equals("yellow")) {
			color.setR(255);
			color.setG(255);
			color.setB(0);
		}
		if (blockcolor.toLowerCase().equals("green"))
			color.setG(1);
		if (blockcolor.toLowerCase().equals("blue"))
			color.setB(1);
		if (blockcolor.toLowerCase().equals("red"))
			color.setR(1);

		PDAnnotationTextMarkup txtMark = new PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT);

		txtMark.setColour(color);

		txtMark.setConstantOpacity((float) 0.5);
		PDRectangle rect1 = new PDRectangle();
		rect1.setLowerLeftX(x1);
		rect1.setLowerLeftY(pageHeight - y1);
		rect1.setUpperRightX(x3);
		rect1.setUpperRightY(pageHeight - y3);

		PDRectangle rect = rect1;
		float[] quads = new float[8];

		quads[0] = rect.getLowerLeftX();
		quads[1] = rect.getUpperRightY() + 2;
		quads[2] = rect.getUpperRightX();
		quads[3] = quads[1];
		quads[4] = quads[0];
		quads[5] = rect.getLowerLeftY() - 2;
		quads[6] = quads[2];
		quads[7] = quads[5];

		txtMark.setQuadPoints(quads);
		txtMark.setRectangle(rect);
		txtMark.setLocked(true);

		annotations.add(txtMark);
		page.setAnnotations(annotations);
	}

}
