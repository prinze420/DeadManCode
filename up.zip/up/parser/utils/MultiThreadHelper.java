package com.pdf.parser.utils;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class MultiThreadHelper {
	public static void processThreads(List<Runnable> runs, int parallelCount){
		ExecutorService es = Executors.newFixedThreadPool(parallelCount);
		
		for( Runnable run : runs )
			es.submit(run);
		
		es.shutdown();
		try {
			while(!es.awaitTermination(100, TimeUnit.MILLISECONDS)){}
		} catch (InterruptedException e1) {
			e1.printStackTrace();
		};
	}
}
