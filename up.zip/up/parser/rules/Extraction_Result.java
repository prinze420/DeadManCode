package com.pdf.parser.rules;  

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.base.BasicStructure;

public class Extraction_Result {
	private int sentenceIndex;//, row, column;
	private long nodeId;
	private ExtractionRule rule;
	//private boolean isTable;
	private List<String> outputList;
	private String fileDirName; 
	private List<BasicStructure> resultSegments;
	private float yCoordinate;
	int page;
	
	public Extraction_Result(long nodeId, int sentenceIndex, ExtractionRule rule, float yCoordinate, int page) {
		this.nodeId = nodeId;
		this.sentenceIndex = sentenceIndex;
		this.rule = rule;
		this.yCoordinate = yCoordinate;
		this.page = page;
		//isTable = false;
		outputList=new ArrayList<String>();
		resultSegments=new ArrayList<BasicStructure>();
		
	}

	/*public SearchResult(long nodeId, int row, int column, RuleGroup rule, float yCoordinate, int page) {
		this.nodeId = nodeId;
		this.row = row;
		this.column = column;
		this.rule = rule;
		isTable = true;
		outputList=new ArrayList<String>();
	//	this.resultSegments=resultSegments;
		this.yCoordinate = yCoordinate;
		this.page = page;
	}*/

	public List<BasicStructure> getResultSegments() {
		return resultSegments;
	}

	/*public void setResultSegments(List<BasicStructure> resultSegments) {
		this.resultSegments = resultSegments;
	}*/

	@Override
	public String toString() {
		return "outputList=" + outputList + ", rule=" + rule + ", nodeId=" + nodeId;
	}

	public long getNodeId() {
		return nodeId;
	}

	public int getSentenceIndex() {
		return sentenceIndex;
	}

/*	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}

	public boolean isTable() {
		return isTable;
	}*/
	
	public ExtractionRule getRule() {
		return rule;
	}
	public void setOutputList(List<String> outputList) {
		
		this.outputList=outputList;
	}
	public List<String> getOutputList(){
		return outputList;
	}

	public void setFileDirName(String fileDirName) {
		// TODO Auto-generated method stub
		this.fileDirName=fileDirName;
	}

	public String getFileDirName() {
		return fileDirName;
	}

	public void setNodeId(long nodeId) {
		this.nodeId = nodeId;
	}

	public float getyCoordinate() {
		return yCoordinate;
	}

	public int getPage() {
		return page;
	}
	
}
