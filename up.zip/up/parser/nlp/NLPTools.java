package com.pdf.parser.nlp;

import java.io.File;
import java.io.FileInputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import opennlp.tools.chunker.ChunkerME;
import opennlp.tools.chunker.ChunkerModel;
import opennlp.tools.postag.POSModel;
import opennlp.tools.postag.POSTaggerME;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;
import opennlp.tools.util.Span;

public class NLPTools {
	
	//private static final ResourceBundle config = ResourceBundle.getBundle("config_extraction/emailconfig");
	
	static ResourceBundle config;// = ResourceBundle.getBundle("nlp-config");
	static{
		try {
			config = ResourceBundle.getBundle("nlp-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
//			config = ResourceBundle.getBundle("emailconfig",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config_extraction").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	private static final String LOCALE = config.getString("nlp.locale")+"."; //en. or de.
	
	int instanceCounter;
	private SentenceDetectorME sentenceDetector;
	private TokenizerME tokenizer;
	private POSTaggerME posTagger;
	private ChunkerME chunker;
//	private PorterStemmer stemmer;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + instanceCounter;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NLPTools other = (NLPTools) obj;
		if (instanceCounter != other.instanceCounter)
			return false;
		return true;
	}
	
	private static NLPTools[] instances = new NLPTools[new Integer(config.getString("nlp.threads"))];
//	private static final int maxSentenceLength = new Integer(config.getString("nlptools.max.sentence.length"));
	private static HashMap<Integer, Boolean> instanceTracker = new HashMap<Integer,Boolean>(new Integer(config.getString("nlp.threads")));
	
	public static void init(){
		if(instanceTracker.size()==0){
			for(int i=0; i<new Integer(config.getString("nlp.threads")); i++){
				instances[i] = new NLPTools();
				instances[i].setInstanceCounter(i);
				
				instanceTracker.put(i, false); //default initialization where false for not being in use
			}
		}
	}
	
	public NLPTools(){
		
		try{
			
			//********Initialize Sentence Detector from OpenNLP
			FileInputStream sentenceDetectorModel = new FileInputStream(config.getString(LOCALE+"sentence.detector.model"));
			sentenceDetector = new SentenceDetectorME(new SentenceModel(sentenceDetectorModel));
			//*************************************************
			
			//********Initialize Tokenizer from OpenNLP
			FileInputStream tokenizerModel = new FileInputStream(config.getString(LOCALE+"tokenizer.model"));
			tokenizer = new TokenizerME(new TokenizerModel(tokenizerModel));
			//*************************************************
			
			//********Initialize POS Tagger from OpenNLP
			FileInputStream posTaggerModel = new FileInputStream(config.getString(LOCALE+"pos.tagger.model"));
			posTagger = new POSTaggerME(new POSModel(posTaggerModel));
			//*************************************************
			
			//********Initialize Chunker from OpenNLP
			FileInputStream chunkerModel = new FileInputStream(config.getString(LOCALE+"chunker.model"));
			chunker = new ChunkerME(new ChunkerModel(chunkerModel));
			//*************************************************
			
			//*********************Stemmer
			//stemmer = new PorterStemmer();
			//**************************
		
		}catch(Exception e){			
			System.err.println("************Failed to initialize NLP Tools\n");
			e.printStackTrace();
			System.err.println("\n*****************************************");
		}
	}
	
	//Singleton inner class
	public static class ThreadSafe{
		
		public final static ThreadSafe instance = new ThreadSafe();
		
		private ThreadSafe(){}
		
		public synchronized NLPTools getNLPToolsInstance(){
			NLPTools nt = null;
			
			for(int i=0; i<instances.length; i++){
				if(!instanceTracker.get(i)){//false means not in use
					instanceTracker.put(i, true);
					nt = instances[i];
					break;
				}
			}
			return nt;
		}
		
		public synchronized void releaseNLPToolsInstance(NLPTools nt){
			for(int i=0; i<instances.length; i++){
				if(instances[i].equals(nt)){
					instanceTracker.put(i, false);
					break;
				}
			}
		}
	}
	
	public static NLPTools getThreadSafeInstance(){
		
		if(instanceTracker.size()==0)
			NLPTools.init();
		
		NLPTools instance = NLPTools.ThreadSafe.instance.getNLPToolsInstance();
		while(instance==null){
			instance = NLPTools.ThreadSafe.instance.getNLPToolsInstance();
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {}
		}
		
		return instance;
	}
	
	public static void releaseThreadSafeInstance(NLPTools instance){
		NLPTools.ThreadSafe.instance.releaseNLPToolsInstance(instance);
	}
	
	static final List<String> allowedPhraseTypes = Arrays.asList("VP");
	static final int maxFeatureLength = 50;//no. of chars
	
/*public List<Token> getTokens(String text, boolean extractPhrases, boolean extractPhrasePairs, boolean extractNounVerb, boolean useOntologyKeywords, 
			String reason, int restrictSentencesCount){
		
		List<Token> allTokens = new ArrayList<Token>();
		
		//For now we are ignoring repeated sentences. We are getting repeated content in notes and description
		//Also in some cases the content of the attachment is pasted in the notes.
		Set<String> uniqueSentences = new HashSet<String>(getSentences(text));
		
		int sentenceCount=0;
		for(String sentence : uniqueSentences){
			
			//Only select limited sentences
			if(restrictSentencesCount!=-1 && sentenceCount>restrictSentencesCount)
				break;
			sentenceCount++;
			
			//Filter sentence from numbers and special characters
			sentence = sentence.replaceAll("[^A-Za-z\\s]", "").replaceAll("\\s+", " ");
			
			if(sentence.toLowerCase().contains("your request ha been complet"))
				System.out.println("Debug");
			
			String[] tokens = tokenizer.tokenize(sentence);
			Span[] spans = chunker.chunkAsSpans(tokens, posTagger.tag(tokenizer.tokenize(sentence)));
			
			List<String> phraseSeq = new ArrayList<String>();
			List<String> originalPhraseSeq = new ArrayList<String>();
			List<String> phraseTypeSeq = new ArrayList<String>();
			
			for(int i=0; i<spans.length; i++){
				
				String phrase = "", originalPhrase = "";
				Span s = spans[i];
				
				for(int j=s.getStart(); j<s.getEnd(); j++){
					phrase += stemmer.stem(tokens[j]) + " ";
					originalPhrase += tokens[j] + " ";
				}
				phrase = phrase.trim();
				originalPhrase = originalPhrase.trim();
				
				if(StopWords.contains(phrase, this))
					continue;
				
				phraseSeq.add(phrase);
				originalPhraseSeq.add(originalPhrase);
				phraseTypeSeq.add(s.getType());
				
				if(extractPhrases && phrase.length()<maxFeatureLength && allowedPhraseTypes.contains(s.getType().toUpperCase())){
					
					Token token = new Token(phrase, originalPhrase, 1, Token.TYPE.PHRASE);
					int index = allTokens.indexOf(token);
					
					if(index == -1){
						if(token.getOriginal().length()<maxFeatureLength)
							allTokens.add(token);
					}else
						allTokens.get(index).inc();
				}
			}
			
			//Add combination of NP VP and VP NP
			if(extractPhrasePairs && phraseTypeSeq.size()>1){
				for(int i=0; i<phraseTypeSeq.size()-1; i++){
					
					//Check the sequence for NP-VP or VP-NP
					if((phraseTypeSeq.get(i).equals("NP") && phraseTypeSeq.get(i+1).equals("VP")) ||
							(phraseTypeSeq.get(i).equals("VP") && phraseTypeSeq.get(i+1).equals("NP"))){
						
						//******Consider only the head words of both the phrases
						String[] phraseSplit = phraseSeq.get(i).split("\\s");
						String phraseHead1 = stemmer.stem(phraseSplit[phraseSplit.length-1]);
						
						String[] phraseSplit2 = phraseSeq.get(i+1).split("\\s");
						String phraseHead2 = stemmer.stem(phraseSplit2[phraseSplit2.length-1]);
						
						if(StopWords.contains(phraseHead1.toLowerCase(), this) && StopWords.contains(phraseHead2.toLowerCase(), this))
							continue;
						//***********************************
						
//						String combinedPhrase = phraseSeq.get(i) + " " + phraseSeq.get(i+1);
						String combinedPhrase = phraseHead1 + " " + phraseHead2;
						if(combinedPhrase.length() < maxFeatureLength){
							Token token = new Token(combinedPhrase.toLowerCase(),originalPhraseSeq.get(i)+" "+originalPhraseSeq.get(i+1), 1, Token.TYPE.PHRASE_PAIR);
							int index = allTokens.indexOf(token);
							
							if(index == -1){
								if(token.getOriginal().length()<maxFeatureLength)
									allTokens.add(token);
							}else
								allTokens.get(index).inc();
						}
					}
				}
			}
			
			//Record Nouns from pos tags
			if(extractNounVerb){
				String[] tags = posTagger.tag(tokens);
				for(int i=0; i<tokens.length; i++){
					if(tags[i].startsWith("NN") || tags[i].startsWith("VB")){
						if(StopWords.contains(tokens[i].trim().toLowerCase(), this))
							continue;
						
						Token token = new Token(stemmer.stem(tokens[i].trim().toLowerCase()), tokens[i].trim(), 1, Token.TYPE.WORD);
						int index = allTokens.indexOf(token);
						
						if(index == -1){
							if(token.getOriginal().length()<maxFeatureLength)
								allTokens.add(token);
						}else
							allTokens.get(index).inc();
					}
				}
			}
		}
		
		return allTokens;
	}
		*/	
	public List<String> getSentences(String para){
		List<String> sentences = new ArrayList<String>();
		
		for(String sentence : sentenceDetector.sentDetect(para.replaceAll("[\r\n]", ". "))){
			//if(sentence.length()<=maxSentenceLength)
				sentences.add(sentence);
		}
		
		return sentences;
	}
	
	public String[] tokenize(String sentence){
		return tokenizer.tokenize(sentence);
	}

	public int getInstanceCounter() {
		return instanceCounter;
	}

	public void setInstanceCounter(int instanceCounter) {
		this.instanceCounter = instanceCounter;
	}
	
	/*public String stem(String word){
		return stemmer.stem(word);
	}*/
	
	public String[] tag(String[] tokens){
		//return tag(tokens);
		return posTagger.tag(tokens);
	}
	
	public Span[] chunkAsSpans(String sentence){
		String[] tokens = tokenizer.tokenize(sentence);
		return chunker.chunkAsSpans(tokens, posTagger.tag(tokenizer.tokenize(sentence)));
	}
	
	
}
