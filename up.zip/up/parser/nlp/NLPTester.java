package com.pdf.parser.nlp;

import java.util.List;


public class NLPTester {

	public static void main(String[] args) {
		String str="My 1st sentence. �Does it work for questions?� My third sentence.";
		
		NLPTools.init();
		NLPTools nlpTools = NLPTools.getThreadSafeInstance();
		List<String> sentences = nlpTools.getSentences(str);
		NLPTools.releaseThreadSafeInstance(nlpTools);
		
		for (String string : sentences) {
			System.out.println(string);
		}
		
	}
}
