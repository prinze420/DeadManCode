package com.pdf.parser.complex.strategy;

import java.awt.Color;
import java.awt.image.BufferedImage;

public class GeneralUtility {
	public static final int THRESHOLD = 140;
	/**
	 * Calculates the count of pixels in specified rectangle having color values
	 * greater than threshold after applying Gray filter.
	 * 
	 * @param x
	 *            : X coordinate of upper left corner of rectangle.
	 * @param y
	 *            : Y coordinate of upper left corner of rectangle.
	 * @param width
	 *            : Width of rectangle
	 * @param height
	 *            : Height of rectangle
	 * @return : Count of pixels.
	 */
	public static int compare(int x, int y, int width, int height, BufferedImage img) {
		int count = 0;
		for (int i = x; i < (x + width) && i<img.getWidth(); i++) {
			for (int j = y; j < (y + height) && j<img.getHeight(); j++) {
				if (j < (img.getHeight() - 5) && i < img.getWidth()) {
					int k = new Color(img.getRGB(i, j)).getRed();// ImagePreprocessing.gray(i, j, img);
					if (k > THRESHOLD) {
						count++;
					}
				} else
					break;
			}
		}
		return count;
	}
}
