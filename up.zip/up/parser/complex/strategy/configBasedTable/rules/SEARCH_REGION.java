package com.pdf.parser.complex.strategy.configBasedTable.rules;

public enum SEARCH_REGION {
	SEGMENT, LINE, PARA;
	
	public static SEARCH_REGION getRegion(String region){
		if(region.equalsIgnoreCase("segment"))
			return SEARCH_REGION.SEGMENT;
		
		else if(region.equalsIgnoreCase("line"))
			return SEARCH_REGION.LINE;
		
		return SEARCH_REGION.PARA;
	}
}
