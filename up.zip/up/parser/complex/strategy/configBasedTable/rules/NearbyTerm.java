package com.pdf.parser.complex.strategy.configBasedTable.rules;

public class NearbyTerm {
	
	int id;
	String searchTerm, subTitle, pattern;
	SEARCH_REGION region;
	
	public NearbyTerm(int id, String searchTerm, String subTitle, String pattern, SEARCH_REGION region) {
		super();
		this.id = id;
		this.searchTerm = searchTerm;
		this.subTitle = subTitle;
		this.pattern = pattern;
		this.region = region;
	}

	public int getId() {
		return id;
	}

	public String getSearchTerm() {
		return searchTerm;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public String getPattern() {
		return pattern;
	}

	public SEARCH_REGION getRegion() {
		return region;
	}
}
