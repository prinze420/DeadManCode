package com.pdf.parser.complex.strategy.configBasedTable.rules;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TableRule {
	int tableId;
	String tableTitle;
	List<NearbyTerm> nearbyTerms;
	List<ColumnRule> columnRules;
	List<HeaderRule> headerRules;
	
	Set<String> columnHeadWords = new HashSet<String>();
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + tableId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TableRule other = (TableRule) obj;
		if (tableId != other.tableId)
			return false;
		return true;
	}

	public int getTableId() {
		return tableId;
	}

	public void setTableId(int tableId) {
		this.tableId = tableId;
	}

	public String getSearchTerm() {
		return tableTitle;
	}

	public void setSearchTerm(String searchTerm) {
		this.tableTitle = searchTerm;
	}

	public String getTableTitle() {
		return tableTitle;
	}

	public void setTableTitle(String tableTitle) {
		this.tableTitle = tableTitle;
	}

	public List<ColumnRule> getColumnRules() {
		return columnRules;
	}

	public void setColumnRules(List<ColumnRule> columnRules) {
		this.columnRules = columnRules;
	}

	public List<HeaderRule> getHeaderRules() {
		return headerRules;
	}

	public void setHeaderRules(List<HeaderRule> headerRules) {
		this.headerRules = headerRules;
	}

	public Set<String> getColumnHeadWords() {
		return columnHeadWords;
	}

	public void setColumnHeadWords(Set<String> columnHeadWords) {
		this.columnHeadWords = columnHeadWords;
	}

	public List<NearbyTerm> getNearbyTerms() {
		return nearbyTerms;
	}

	public void setNearbyTerms(List<NearbyTerm> nearbyTerms) {
		this.nearbyTerms = nearbyTerms;
	}
}
