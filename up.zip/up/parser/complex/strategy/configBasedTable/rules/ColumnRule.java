package com.pdf.parser.complex.strategy.configBasedTable.rules;

public class ColumnRule {
	int id, subId;
	String head, subHead, businessName;
	String[] stackedHeads;
	String dataType;
	Alignment alignment, rowVAlignment;
	boolean isMultiValue, isEmbedded, isCompulsory, isRowIndicator;
	
	public ColumnRule(){
		subId = -1;
	}
	
	@Override
	public String toString() {
		return "id=" + id + ", subId=" + subId + ", head=" + head + ", subHead=" + subHead + ", businessName="
				+ businessName + ", dataType=" + dataType + ", alignment=" + alignment + ", rowVAlignment="
				+ rowVAlignment + ", isMultiValue=" + isMultiValue + ", isEmbedded=" + isEmbedded + ", isCompulsory="
				+ isCompulsory + ", isRowIndicator=" + isRowIndicator;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + subId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ColumnRule other = (ColumnRule) obj;
		if (id != other.id)
			return false;
		if (subId != other.subId)
			return false;
		return true;
	}
	
	public String getHead() {
		return head;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getSubId() {
		return subId;
	}

	public void setSubId(int subId) {
		this.subId = subId;
	}

	public void setHead(String head) {
		this.head = head;
	}

	public String[] getStackedHeads() {
		return stackedHeads;
	}

	public void setStackedHeads(String[] stackedHeads) {
		this.stackedHeads = stackedHeads;
	}

	public String getSubHead() {
		return subHead;
	}

	public void setSubHead(String subHead) {
		this.subHead = subHead;
	}

	public String getBusinessName() {
		return businessName;
	}

	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	public boolean isMultiValue() {
		return isMultiValue;
	}

	public void setMultiValue(boolean isMultiValue) {
		this.isMultiValue = isMultiValue;
	}

	public boolean isEmbedded() {
		return isEmbedded;
	}

	public void setEmbedded(boolean isEmbedded) {
		this.isEmbedded = isEmbedded;
	}

	public boolean isCompulsory() {
		return isCompulsory;
	}

	public void setCompulsory(boolean isCompulsory) {
		this.isCompulsory = isCompulsory;
	}

	public boolean isRowIndicator() {
		return isRowIndicator;
	}

	public void setRowIndicator(boolean isRowIndicator) {
		this.isRowIndicator = isRowIndicator;
	}

	public Alignment getAlignment() {
		return alignment;
	}

	public void setAlignment(Alignment alignment) {
		this.alignment = alignment;
	}

	public Alignment getRowVAlignment() {
		return rowVAlignment;
	}

	public void setRowVAlignment(Alignment rowVAlignment) {
		this.rowVAlignment = rowVAlignment;
	}
}
