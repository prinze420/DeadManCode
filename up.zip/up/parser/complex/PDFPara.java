package com.pdf.parser.complex;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.nlp.NLPTools;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.CommonOperations.DIRECTION;
import com.pdf.parser.utils.CommonOperations.SORT_CRITERIA;
import com.pdf.parser.utils.Structure_Id;

public class PDFPara implements ComplexStructure{
	
	long id;
	List<DPRectangle> rectangles;
	String stringRepresentation;
	StructureType type;
	
	Map<Integer,List<BasicStructure>> segments;
	
	//Created after concatenating segments
	List<String> sentences;
	
	boolean hasTitleSegment;
	
	String enumeration;
	boolean isEnumerated;
	
	public PDFPara(List<DPRectangle> rectangles, Map<Integer, List<BasicStructure>> segments, StructureType type) {
		id = Structure_Id.getInstance().getNext();
		this.rectangles = rectangles;
		this.segments = segments;
		this.type = type;
		
		stringRepresentation = "";
		for(List<BasicStructure> segs : segments.values())
			for(BasicStructure seg : segs)
				stringRepresentation += seg.getStringRepresentation()+" ";
		
		NLPTools nlp = NLPTools.getThreadSafeInstance();
		sentences = nlp.getSentences(stringRepresentation.trim());
		NLPTools.releaseThreadSafeInstance(nlp);
	}
	
	public long getId() {
		return id;
	}

	public void merge(PDFPara para, int page){
		rectangles.addAll(para.getRectangles());
		
		for(int sPage : para.getSegments().keySet()){
			if(segments.containsKey(sPage))
				segments.get(sPage).addAll(para.getSegments().get(sPage));
			else
				segments.put(sPage, para.getSegments().get(sPage));
		}
		
		stringRepresentation = "";
		for(List<BasicStructure> segs : segments.values())
			for(BasicStructure seg : segs)
				stringRepresentation += seg.getStringRepresentation()+" ";
	}
	
	public static PDFPara create(List<PDFSegment> segments){
		
		List<BasicStructure> xSorted = CommonOperations.sort(segments, SORT_CRITERIA.X, DIRECTION.MIN);
		float x = xSorted.get(0).getRectangle().getX();
		
		List<BasicStructure> x2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.X2, DIRECTION.MAX);
		float x2 = x2Sorted.get(0).getRectangle().getX2();
		
		List<BasicStructure> ySorted = CommonOperations.sort(segments, SORT_CRITERIA.Y, DIRECTION.MAX); //Y increases as origin is top-left
		float y = ySorted.get(0).getRectangle().getY();
		
		List<BasicStructure> y2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.Y2, DIRECTION.MIN); //Y2 decreases as origin is top-left
		float y2 = y2Sorted.get(0).getRectangle().getY2();
		
		float w = x2 - x;
		float h = y - y2;
		
		int page = segments.get(0).getRectangle().getPage();
		
		List<DPRectangle> rects = new ArrayList<DPRectangle>();
		rects.add(new DPRectangle(x, y, w, h, page));
		
		Map<Integer, List<BasicStructure>> pageWiseSegments = new TreeMap<Integer, List<BasicStructure>>();
		pageWiseSegments.put(page, new ArrayList<BasicStructure>(segments));
		
		PDFPara para = new PDFPara(rects, pageWiseSegments, StructureType.PARA); 
		
		return para;
	}

	@Override
	public String toString() {
		return stringRepresentation;
	}
	
	@Override
	public int hashCode() {//Implemented using the first rectangle only
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangles.get(0) == null) ? 0 : rectangles.get(0).hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {//Implemented using the first rectangle only
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFPara other = (PDFPara) obj;
		if (rectangles.get(0) == null) {
			if (other.rectangles.get(0) != null)
				return false;
		} else if (!rectangles.get(0).equals(other.rectangles.get(0)))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public StructureType getType() {
		return type;
	}

	public float getWidthOfSpace() {
		return segments.values().iterator().next().get(0).getWidthOfSpace();
	}

	public List<DPRectangle> getRectangles() {
		return rectangles;
	}

	public Map<Integer, List<BasicStructure>> getSegments() {
		return segments;
	}

	public List<String> getSentences() {
		return sentences;
	}

	public boolean isHasTitleSegment() {
		return hasTitleSegment;
	}

	public void setHasTitleSegment(boolean hasTitleSegment) {
		this.hasTitleSegment = hasTitleSegment;
	}

	public String getEnumeration() {
		return enumeration;
	}

	public void setEnumeration(String enumeration) {
		this.enumeration = enumeration;
	}

	public boolean isEnumerated() {
		return isEnumerated;
	}

	public void setEnumerated(boolean isEnumerated) {
		this.isEnumerated = isEnumerated;
	}
}
