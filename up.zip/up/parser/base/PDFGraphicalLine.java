package com.pdf.parser.base;

import com.pdf.parser.utils.Structure_Id;



public class PDFGraphicalLine {

	private long id;
	private	float x,y,x2,y2; 
	private	int index;
	private	boolean isHorizontal,isAcrossPage;
	private Pixel color;

	public PDFGraphicalLine(float x1,float y1,float x2,float y2,boolean isHorizontal,Pixel color){

		this.id=Structure_Id.getInstance().getNext();

		this.x = x1;
		this.x2 = x2;
		this.y = y1;
		this.y2 = y2;
		this.index=-1;
		this.isHorizontal = isHorizontal;
		this.color = color;

	}

	public long getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public float  getindex() {
		return index;
	}

	public void setindex(int index) {
		this.index = index;
	}
	public String toString(){
		return "("+x+","+y+") ("+x2+","+y2+")";
	}

	public float getX() {
		return x;
	}

	public void setX(float x1) {
		this.x = x1;
	}

	public float getY() {
		return y;
	}

	public void setY(float y1) {
		this.y = y1;
	}

	public float getX2() {
		return x2;
	}

	public void setX2(float x2) {
		this.x2 = x2;
	}

	public float getY2() {
		return y2;
	}

	public void setY2(float y2) {
		this.y2 = y2;
	}

	public boolean isHorizontal() {
		return isHorizontal;
	}

	public void setHorizontal(boolean isHorizontal) {
		this.isHorizontal = isHorizontal;
	}

	public Pixel getColor() {
		return color;
	}

	public void setColor(Pixel color) {
		this.color = color;
	}

	public float getWidth() {
		return this.x2 - this.x;
	}

	public float getHeight() {
		return this.y2-this.y;
	}


	public void setAcrossPage(boolean isAcrossPage) {
		this.isAcrossPage = isAcrossPage;
	}

	// Currently we are keeping 0.2 as tolerance
	public  boolean isFullLine(double pageWidthOrHeight){

		if(this.isHorizontal && ((pageWidthOrHeight - this.getWidth())<=pageWidthOrHeight*0.1) ){
			return true;
		}
		else if( !this.isHorizontal && ((pageWidthOrHeight - this.getWidth())<=pageWidthOrHeight*0.1))
			return false;
		else
			return false;
	}
}
