package com.pdf.parser.base;

import java.io.Serializable;
import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;

public class KeyValuePair implements Serializable, BasicStructure {
	
	private static final long serialVersionUID = 1L;
	private long id;
	private String text="",keyText="",valueText="";
	private DPRectangle rectangle;
	private BasicStructure key;
	private List<BasicStructure>valueList;
	private float widthOfSpace;
	private StructureType type;

	public KeyValuePair(BasicStructure key, String keyText, List<BasicStructure> valueList, String valueText,
			String text, DPRectangle rectangle, float widthOfSpace) {
		
		id = Structure_Id.getInstance().getNext();
		this.key = key;
		
		if(keyText.isEmpty()){
			this.keyText = key.getStringRepresentation();
		}else{
			this.keyText = keyText;
		}
		
		this.valueList = valueList;
		this.valueText = valueText;
		this.text = text;
		this.rectangle = rectangle;
		this.widthOfSpace = widthOfSpace;
		this.type = StructureType.KEY_VALUE;
		
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getKeyText() {
		return keyText;
	}

	public List<BasicStructure> getValueList() {
		return valueList;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		KeyValuePair other = (KeyValuePair) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return text;
	}

	@Override
	public StructureType getType() {
		return type;
	}

	@Override
	public String getStringRepresentation() {
		return text;
	}

	@Override
	public float getWidthOfSpace() {
		return widthOfSpace;
	}

	@Override
	public long getId() {
		return id;
	}

	@Override
	public DPRectangle getRectangle() {
		return rectangle;
	}

	public BasicStructure getKey() {
		return key;
	}

	public String getValueText() {
		return valueText;
	}
}
