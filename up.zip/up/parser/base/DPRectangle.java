package com.pdf.parser.base;

/**
 * Rectangular region on a particular page. 
 * It's usually the dimension of a structure.
 * @author Shishir.Mane
 *
 */
public class DPRectangle {
	float x, y, width, height;
	int page;
	
	public DPRectangle(float x, float y, float width, float height, int page) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
		this.page = page;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(height);
		result = prime * result + page;
		result = prime * result + Float.floatToIntBits(width);
		result = prime * result + Float.floatToIntBits(x);
		result = prime * result + Float.floatToIntBits(y);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		DPRectangle other = (DPRectangle) obj;
		if (Float.floatToIntBits(height) != Float
				.floatToIntBits(other.height))
			return false;
		if (page != other.page)
			return false;
		if (Float.floatToIntBits(width) != Float
				.floatToIntBits(other.width))
			return false;
		if (Float.floatToIntBits(x) != Float.floatToIntBits(other.x))
			return false;
		if (Float.floatToIntBits(y) != Float.floatToIntBits(other.y))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "DPRectangle [x=" + x + ", y=" + y + ", width=" + width + ", height=" + height + ", page=" + page + "]";
	}

	public float getX() {
		return x;
	}

	public float getY() {
		return y;
	}

	public float getWidth() {
		return width;
	}

	public float getHeight() {
		return height;
	}

	public int getPage() {
		return page;
	}
	
	public float getX2() {
		return x + width;
	}

	public float getY2() {
		return y - height;
	}

	public void setX(float x) {
		this.x = x;
	}

	public void setY(float y) {
		this.y = y;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public void setHeight(float height) {
		this.height = height;
	}
}
