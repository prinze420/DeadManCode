package com.pdf.parser.base.strategy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;

public class PDFTitleDetectionStrategy implements Strategy<Map<Integer,List<PDFSegment>>> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	Map<Integer,List<PDFSegment>> segments, titles;
	
	public PDFTitleDetectionStrategy(Map<Integer,List<PDFSegment>> segments) {
		this.segments = segments;
		titles = new HashMap<Integer, List<PDFSegment>>();
	}
	
	@Override
	public void apply() {
		
		for(int page : segments.keySet()){
			
			List<PDFSegment> pageWiseSegments = segments.get(page);
			
			//We are assuming that there can be only one title per Y
			List<StructureGroup> ygroups = CommonOperations.groupStructuresOnY(pageWiseSegments);
			
			titles.put(page, new ArrayList<PDFSegment>());
			
			if(Boolean.valueOf(config.getString("titlesBasedOnFont")))
				detectTitlesOnFonts(page, ygroups);
			
			if(Boolean.valueOf(config.getString("titlesBasedOnList")))
				detectTitlesFromList(page, ygroups);
			
			if(Boolean.valueOf(config.getString("partialTitlesDetect")))
				detectPartialTitles(page, ygroups);
		}
	}
	
	private void detectTitlesOnFonts(int page, List<StructureGroup> ygroups){
		boolean titlesAreBold = Boolean.valueOf(config.getString("titlesAreBold"));
		
		if(titlesAreBold){
			
			for(StructureGroup group : ygroups){
				if(group.getSegmentsSize()==1){
					
					List<PDFSegment> segs = group.getCastedPDFSegments();
					
					PDFSegment seg = segs.get(0);
					
					int i = seg.isEnumerated() ? 1 : 0;
					boolean isBoldSegment = true;
					for(;i<seg.getWords().size(); i++){
						if(!seg.getWords().get(i).isCompletelyBold()){
							isBoldSegment = false;
							break;
						}
					}
					
					if(isBoldSegment){
						seg.setEntirelyTitle(true);
						seg.setTitle(true);
						seg.setTitle(seg.getStringRepresentation());
						
						titles.get(page).add(seg);
					}
				}
			}
		}
	}
	
	/**
	 * Here the segments grouped are converted to a single line and then matched with the list, but without the enumeration
	 * @param ygroups group of segments based on y match
	 */
	private void detectTitlesFromList(int page, List<StructureGroup> ygroups){
		
		Set<String> titlesList = new HashSet<String>();
		File list = new File("config/titles.list");
		if(list.exists()){
			
			try{
				BufferedReader reader = new BufferedReader(new FileReader(list));
				String l = "";
				while((l=reader.readLine()) != null){
					titlesList.add(l.trim());
				}
				reader.close();
				
				for(StructureGroup group : ygroups){
					String line = "";
					for(int i=0; i<group.getSegmentsSize(); i++){
						
						PDFSegment seg = group.getCastedPDFSegments().get(i);
						if(i==0 && seg.isEnumerated()){
							line += seg.getStringRepresentation().substring(seg.getStringRepresentation().indexOf(" ")+1) + " ";
							continue;
						}
						
						line += seg.getStringRepresentation()+" ";
					}
					
					if(titlesList.contains(line.trim())){
						for(PDFSegment seg : group.getCastedPDFSegments()){
							
							//If not previously marked as title
							if(!seg.isTitle()){
								seg.setEntirelyTitle(true);
								seg.setTitle(true);
								seg.setTitle(line.trim());
								
								titles.get(page).add(seg);
							}
						}
					}
				}
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
	}
	
	private void detectPartialTitles(int page, List<StructureGroup> ygroups){
		for(StructureGroup group : ygroups){
			PDFSegment seg = group.getCastedPDFSegments().get(0);
			
			int i = seg.isEnumerated() ? 1 : 0;
			String bold="";
			for(;i<seg.getWords().size(); i++){
				if(seg.getWords().get(i).isCompletelyBold()){
					bold += seg.getWords().get(i).getStringRepresentation() + " ";
					continue;
				}
				break;
			}
			
			if(bold.length()>0 && !seg.isTitle()){
				seg.setEntirelyTitle(false);
				seg.setTitle(true);
				seg.setTitle(bold);
				
				titles.get(page).add(seg);
			}
		}
	}

	@Override
	public Map<Integer, List<PDFSegment>> getOutcome() {
		return titles;
	}
	
	public static void main(String[] args) throws Exception{
		DefaultParser dp = new DefaultParser(PDDocument.load(new File("D:\\MPhasis\\03152016\\OCR\\Lisa ISDA_1.pdf")));
		dp.parse();
		
		PDFTitleDetectionStrategy t = new PDFTitleDetectionStrategy(dp.getSegments());
		t.apply();
		
		Map<Integer, List<PDFSegment>> titles = t.getOutcome();
		
		for(int page : titles.keySet()){
			System.out.println("Page "+page);
			for(PDFSegment seg : titles.get(page)){
				System.out.println(seg.getTitle());
			}
			System.out.println();
		}
	}
}
