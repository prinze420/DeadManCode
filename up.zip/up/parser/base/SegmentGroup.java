package com.pdf.parser.base;

import java.util.ArrayList;
import java.util.List;



/**
 * Group segments based on Y
 * @author Shishir.Mane
 *
 */
public class SegmentGroup {
	float y;
	List<? extends BasicStructure> segments;
	
	public SegmentGroup(float y){
		this.y = y;
		segments = new ArrayList<BasicStructure>();
	}
	
	public boolean contains(PDFSegment seg){
		return segments.contains(seg);
	}
	
	public int indexOf(PDFSegment seg){
		return segments.indexOf(seg);
	}

	@Override
	public String toString() {
		return "y=" + y + ", segments=" + segments+"\n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(y);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SegmentGroup other = (SegmentGroup) obj;
		if (Float.floatToIntBits(y) != Float.floatToIntBits(other.y))
			return false;
		return true;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public List<BasicStructure> getBasicStructures() {
		List<BasicStructure> bs = new ArrayList<BasicStructure>(segments);
		segments = bs;
		
		return bs;
	}
	
	public void setSegments(List<? extends BasicStructure> segments){
		this.segments = segments;
	}
	
	public int getSegmentsSize(){
		return segments.size();
	}
	
	public List<PDFSegment> getCastedPDFSegments(){
		List<PDFSegment> segs = new ArrayList<PDFSegment>();
		
		for(BasicStructure s : new ArrayList<BasicStructure>(segments)){
			segs.add((PDFSegment)s);
		}
		
		segments = segs;
		return segs;
	}
}	
