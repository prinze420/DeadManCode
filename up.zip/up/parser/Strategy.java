package com.pdf.parser;

/**
 * Strategy is the manner in which we extract the outcome. The outcome can be a single or list of structures.
 * @author Shishir.Mane
 * @see 2.2
 * @param <Outcome> The outcome returned by an implemented strategy
 */
public interface Strategy<Outcome> {
	
	public void apply();
	
	public Outcome getOutcome();
}
