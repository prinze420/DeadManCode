package com.pdf.parser.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.MultiThreadHelper;

public class BasicStructureHtmlGenerator {

	/**
	 * @param args
	 */
	
	public static void main(String[] args) throws Exception{
		//String file = "Statement-517530140105453-May-2016.pdf";
		//
		//D:\Platform\Phizer\TestSample\MerckOcred\Memo2.pdf
		String file="D:\\Platform\\Phizer\\TestSample\\temp\\marketedEDC.pdf";//
		final float fontScale = 1f;
		
		PDDocument pdf = PDDocument.load(file);
		
		final DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();
		
		String finalHtml = "<html><body>\n";
		List<Runnable> runs = new ArrayList<Runnable>();
		final Map<Integer,String> pageOutputs = new HashMap<Integer, String>();
		
		for(final int page : parser.getSegments().keySet()){
			
			runs.add(new Runnable() {
				public void run() {
					String html = "";
					int pageWidth = (int)parser.getPageWidthHeight().get(page).getX();
					int pageHeight = (int)parser.getPageWidthHeight().get(page).getY();
					
					html += "<div>Page: "+(page+1)+"</div>\n";
					html += "\t<div style='width:"+pageWidth+"px; height:"+pageHeight+"px;border:1px solid red; margin-bottom: 10px;position:relative;'>\n";
					
					List<PDFSegment> segments = parser.getSegments().get(page);
					
					for(PDFSegment element : segments){
						
						String fontName = element.getWords().get(0).getCharacters().get(0).getFontName();
						if(fontName == null || fontName.length()==0)
							fontName = "";
						if(fontName.contains("+"))
							fontName = fontName.substring(fontName.lastIndexOf("+")+1);
						
						
						int fontSize = (int)(element.getWords().get(0).getCharacters().get(0).getFontSizeInPt()*fontScale);
						if(fontSize>20)
							fontSize = 20;
						
						String tooltip = "x="+(int)element.getRectangle().getX()+" x2="+(int)element.getRectangle().getX2();
						tooltip += "\ny="+(int)element.getRectangle().getY()+" y2="+(int)element.getRectangle().getY2();
						tooltip += "\nwidth="+(int)element.getRectangle().getWidth();
						tooltip += "\nHeight="+(int)element.getRectangle().getHeight();
						tooltip += "\nFont="+element.getWords().get(element.getWords().size()-1).getCharacters().get(0).getFontName();
						tooltip += "\nBold="+element.getWords().get(0).getCharacters().get(0).isBold();
						tooltip += "\nFont-Size="+element.getWords().get(0).getCharacters().get(0).getFontSizeInPt()+"pt";
						tooltip += "\nWords="+element.getWords().size();
						tooltip += "\n"+element.getStringRepresentation();
						
						boolean isBold = element.getWords().get(0).getCharacters().get(0).isBold() ||
								element.getWords().get(element.getWords().size()-1).getCharacters().get(0).getFontName().toLowerCase().endsWith("bold");
						String boldProp = isBold ? "font-weight: bold;" : "font-weight: normal;";
						
						html += "\t\t<div" +
								" style='font-family:"+fontName+";left:"+(int)element.getRectangle().getX()+"px;font-size:"+fontSize+"px;top:"+(int)element.getRectangle().getY()+"px; position:absolute; "
								+ "text-decoration: underline;"+boldProp+"'" +
								" title='"+tooltip+"' onmouseover=\"this.style.color='red'\" onmouseout=\"this.style.color='black'\"" +
								">\n";
						html += "\t\t\t"+element.getStringRepresentation()+"\n";
						html += "\t\t</div>\n";
					}
					
					html += "\t</div>\n";
					
					synchronized(pageOutputs){
						pageOutputs.put(page, html);
					}
				}
			});
		}
		
		MultiThreadHelper.processThreads(runs, 4);
		
		for(int i=0; i<pdf.getDocumentCatalog().getAllPages().size(); i++){
			if(pageOutputs.containsKey(i)){
				finalHtml += pageOutputs.get(i);
			}
		}
		finalHtml += "</body></html>";
		
		String fname = new File(file).getName();
		fname = fname.substring(0, fname.lastIndexOf("."));
		BufferedWriter writer = new BufferedWriter(new FileWriter("basic-structure-"+fname+".html"));
		writer.write(finalHtml.toString());
		writer.flush();
		writer.close();
	
		pdf.close();
	}
	
//	private static boolean nearlyEqual(float n1, float n2, float comp){
//		if(Math.abs(n1-n2)>comp)
//			return false;
//		return true;
//	}
}
