package com.pdf.parser;

/**
 * This is an abstract construct of a PDF File. Every structure will have a definite position and size. 
 * Some basic structures include Characters and Words; while complex structures include Paragraphs and Tables.
 * @author Shishir.Mane
 * @see Point 2, 2.1
 */
public interface Structure {
	
	/**
	 * The unique name that should be provided to each complex structure.
	 * @return The unique name of the complex structure.
	 */
	public StructureType getType();
	
	/**
	 * The String representation of the structure
	 * @return Usually contains the string content of the structure. E.g. character, word, segment, etc.
	 */
	public String getStringRepresentation();
	
	public float getWidthOfSpace();

	long getId();
}
