package com.pdf.parser.rules;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.HashSet;
import java.util.Set;

public class CreateRules {
	
	
	
	public static Set<ExtractionRule> getRulesFromText(String ruleFile){
		Set<ExtractionRule> rules = new HashSet<ExtractionRule>();
		
		if(rules.size()==0){
			String line = "";
			try{
				BufferedReader reader = new BufferedReader(new FileReader(ruleFile));
				
				boolean skipFirstLine = true;
				while((line = reader.readLine())!=null){
					
					if(skipFirstLine){
						skipFirstLine = false;
						continue;
					}
					
					line = line.trim() ;
					//TemplateID	ID	Field Name	Keyword	Extraction Area	DataType	NLP_Proces	CheckBoxSecondWord

					String[] split = line.split("\\t") ;
					ExtractionRule newGroup = new ExtractionRule() ;
					newGroup.setTemplateID(new Integer(split[0]));
					
					newGroup.setRuleId(new Integer(split[1]));
					newGroup.setFieldName(split[2]) ;
					newGroup.setNormalized_Field_Name(split[3]);
					String keywordToSet = split[4] ;
					newGroup.setKeywords(keywordToSet.trim()) ;
					newGroup.setExtractionArea(split[5]) ;
					newGroup.setDataType(split[6]) ;							
					newGroup.setNLP_Process(split[7]);
					if(split.length>=9){
						newGroup.setCheckBoxSecondWord(split[8]);
					}
					rules.add(newGroup);
				}
				
				reader.close();
				
			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Issue - "+line);
			}
		}
		System.out.println("Total Rules :"+rules.size());
		return rules;
	}
	
	/*public static Set<ExtractionRule> getRulesFromDB(){
		if(rules.size()==0){
			try{
				Connection conn = DatabaseConnection.getConnection();
				Statement st = conn.createStatement();
				ResultSet rs = st.executeQuery("select * from ONTOLOGY");
				
				while(rs.next()){
					
					int c = 1;
					ExtractionRule r = new ExtractionRule() ;
					r.setRuleId(rs.getInt(c++));
					r.setOntoTopic(rs.getString(c++));
					r.setKeywords(rs.getString(c++));
					r.setSearchArea(rs.getString(c++));
					r.setExtractionArea(rs.getString(c++));
					r.setExtractionType(rs.getString(c++));
					r.setExtractionValMandatory(rs.getString(c++).equalsIgnoreCase("y")?true:false);
					r.setRanking(rs.getInt(c++));		
					rules.add(r);
				}
				
				rs.close();
				st.close();
				conn.close();
				
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return rules;
	}*/
}
