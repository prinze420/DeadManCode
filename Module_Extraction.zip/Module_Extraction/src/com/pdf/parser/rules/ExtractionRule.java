package com.pdf.parser.rules;

//public class ExtractionRule 



public class ExtractionRule 
{
	//	ID	Field Name	Keyword	Search_Area	Extraction Area	DataType	Ranking	Pattern
	//TemplateID	ID	Field Name	Keyword	Extraction Area	DataType	NLP_Proces	CheckBoxSecondWord
	private int templateID;
	private int ruleId;
	private String fieldName;
	private String keywords;
	private String extractionArea;
	private String dataType;
	//private boolean extractionValMandatory ;
	private String NLP_Process;
	private String checkBoxSecondWord;
	private String normalized_Field_Name;
	//private Integer listRanking;
	//private Long nodeId;
	//private String isTable;
	//private Long keywordId;
	//	SignAddress SignCompanyName SignEmail_Id SignPersonName SignPhoneNumber

	public static enum EXTRACTION_AREA{SENTENCE,PARA}

	public ExtractionRule(){

	}

	public ExtractionRule(ExtractionRule r){
		templateID=r.getTemplateID();
		ruleId = r.getRuleId();
		fieldName = r.getFieldName();
		keywords = r.getKeywords();
		extractionArea = r.getExtractionArea();
		dataType = r.getDataType();
		NLP_Process=r.getNLP_Process();
		checkBoxSecondWord=r.getCheckBoxSecondWord();
		normalized_Field_Name=r.getNormalized_Field_Name();
	}

	public int getTemplateID() {
		return templateID;
	}

	public String getNormalized_Field_Name() {
		return normalized_Field_Name;
	}

	public void setNormalized_Field_Name(String normalized_Field_Name) {
		this.normalized_Field_Name = normalized_Field_Name;
	}

	public void setTemplateID(int templateID) {
		this.templateID = templateID;
	}

	public String getCheckBoxSecondWord() {
		return checkBoxSecondWord;
	}
	public void setCheckBoxSecondWord(String checkBoxSecondWord) {
		this.checkBoxSecondWord=checkBoxSecondWord;
	}
	public String getNLP_Process() {
		return NLP_Process;
	}

	public void setNLP_Process(String nLP_Process) {
		NLP_Process = nLP_Process;
	}

	public int getRuleId() {
		return ruleId;
	}

	public String getFieldName() {
		return fieldName;
	}

	public String getKeywords() {
		return keywords;
	}

	/*public String getSearchArea() {
		return searchArea;
	}*/

	public String getExtractionArea() {
		return extractionArea;
	}

	public String getDataType() {
		return dataType;
	}


	public void setRuleId(int ruleId) {
		this.ruleId = ruleId;
	}


	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}


	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}


	/*public void setSearchArea(String searchArea) {
		this.searchArea = searchArea;
	}*/


	public void setExtractionArea(String extractionArea) {
		this.extractionArea = extractionArea;
	}


	public void setDataType(String dataType) {
		this.dataType = dataType;
	}





	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((fieldName == null) ? 0 : fieldName.hashCode());
		result = prime * result
				+ ((extractionArea == null) ? 0 : extractionArea.hashCode());
		result = prime * result
				+ ((dataType == null) ? 0 : dataType.hashCode());
		//result = prime * result + (extractionValMandatory ? 1231 : 1237);
		result = prime * result
				+ ((keywords == null) ? 0 : keywords.hashCode());
		//		result = prime * result
		//				+ ((searchArea == null) ? 0 : searchArea.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ExtractionRule other = (ExtractionRule) obj;
		if (fieldName == null) {
			if (other.fieldName != null)
				return false;
		} else if (!fieldName.equals(other.fieldName))
			return false;
		if (extractionArea == null) {
			if (other.extractionArea != null)
				return false;
		} else if (!extractionArea.equals(other.extractionArea))
			return false;
		if (dataType == null) {
			if (other.dataType != null)
				return false;
		} else if (!dataType.equals(other.dataType))
			return false;
		/*if (extractionValMandatory != other.extractionValMandatory)
			return false;*/
		if (keywords == null) {
			if (other.keywords != null)
				return false;
		} else if (!keywords.equals(other.keywords))
			return false;
		//		if (searchArea == null) {
		//			if (other.searchArea != null)
		//				return false;
		//		} else if (!searchArea.equals(other.searchArea))
		//			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Rules [ruleId="+ruleId+", FieldName=" + fieldName + ", keywords=" + keywords
				+ /*", searchArea=" + searchArea +*/ ", extractionArea="
				+ extractionArea + ", dataType="+dataType+"]";
	}
}
