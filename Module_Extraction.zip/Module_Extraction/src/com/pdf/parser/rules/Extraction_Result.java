package com.pdf.parser.rules;  

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.base.BasicStructure;

public class Extraction_Result {
	private int sentenceIndex;//, row, column;
	private long nodeId;
	private ExtractionRule rule;
	//private boolean isTable;
	private List<String> outputList;
	private String fileDirName; 
	private List<BasicStructure> resultSegments;
	private float yCoordinate;
	
	private String coordinatesBox="-1";
	private List<String> coordinatesBoxList;
	int page;
	
	public Extraction_Result(long nodeId, int sentenceIndex, ExtractionRule rule, float yCoordinate, int page/*,String coordinatesBox*/) {
		this.nodeId = nodeId;
		this.sentenceIndex = sentenceIndex;
		this.rule = rule;
		this.yCoordinate = yCoordinate;
		this.page = page;
		//isTable = false;
		//this.coordinatesBox=coordinatesBox;
		coordinatesBoxList= new ArrayList<String>();
		outputList=new ArrayList<String>();
		resultSegments=new ArrayList<BasicStructure>();
		
	}

	/*public SearchResult(long nodeId, int row, int column, RuleGroup rule, float yCoordinate, int page) {
		this.nodeId = nodeId;
		this.row = row;
		this.column = column;
		this.rule = rule;
		isTable = true;
		outputList=new ArrayList<String>();
	//	this.resultSegments=resultSegments;
		this.yCoordinate = yCoordinate;
		this.page = page;
	}*/
	
	public List<String> getCoordinatesBoxList() {
		return coordinatesBoxList;
	}

	public void setCoordinatesBoxList(List<String> coordinatesBoxList) {
		this.coordinatesBoxList = coordinatesBoxList;
	}
	
	public String getCoordinatesBox() {
		return coordinatesBox;
	}

	public void setCoordinatesBox(List<BasicStructure>basicStr) {
		
		float x1=100000,y2=100000;
		
		float x2=-1,y1=-1;
		int pageNum=-1;
		if(basicStr!=null && !basicStr.isEmpty()){
			for (BasicStructure basicStructure : basicStr) {
				if(pageNum==-1){
					pageNum=basicStructure.getRectangle().getPage()+1;
				}
				
				if(basicStructure.getRectangle().getX()<x1){
					x1=basicStructure.getRectangle().getX();
					
				}
				if(basicStructure.getRectangle().getX2()>x2){
					x2=basicStructure.getRectangle().getX2();
				}
				
				if(basicStructure.getRectangle().getY2()<y2){
					y2=basicStructure.getRectangle().getY2();
				}
				if(basicStructure.getRectangle().getY()>y1){
					y1=basicStructure.getRectangle().getY();
				}
			}
			if(x1!=100000 && y2!=100000 && x2!=-1 && y1!=-1){
				this.coordinatesBox= x1+","+y2+","+x2+","+y1+","+pageNum;
			}else{
				System.err.println("Coordinates Not Found");
			}
			
		}else{
			System.err.println("Null | Empty Structure List");
		}
	}

	public List<BasicStructure> getResultSegments() {
		return resultSegments;
	}

	/*public void setResultSegments(List<BasicStructure> resultSegments) {
		this.resultSegments = resultSegments;
	}*/

	@Override
	public String toString() {
		return "outputList=" + outputList + ", rule=" + rule + ", nodeId=" + nodeId;
	}

	public long getNodeId() {
		return nodeId;
	}

	public int getSentenceIndex() {
		return sentenceIndex;
	}

/*	public int getRow() {
		return row;
	}

	public int getColumn() {
		return column;
	}

	public boolean isTable() {
		return isTable;
	}*/
	
	public ExtractionRule getRule() {
		return rule;
	}
	public void setOutputList(List<String> outputList) {
		
		this.outputList=outputList;
	}
	public List<String> getOutputList(){
		return outputList;
	}

	public void setFileDirName(String fileDirName) {
		// TODO Auto-generated method stub
		this.fileDirName=fileDirName;
	}

	public String getFileDirName() {
		return fileDirName;
	}

	public void setNodeId(long nodeId) {
		this.nodeId = nodeId;
	}

	public float getyCoordinate() {
		return yCoordinate;
	}

	public int getPage() {
		return page;
	}
	
}
