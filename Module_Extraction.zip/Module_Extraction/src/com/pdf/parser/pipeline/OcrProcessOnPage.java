package com.pdf.parser.pipeline;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;

public class OcrProcessOnPage {

	public static void main(String[] args) {
		String inputdir = "C:\\Users\\bb0e1165\\Desktop\\PageWiseOCR";
		String middleOutputpath="D:\\Platform\\Phizer\\middleOutputpath";
		String Outputpath = "D:\\Platform\\Phizer\\OcrResult";
		// String Outputpath = args[2];

		List<File>inputOriginalPDFFiles=new ArrayList<File>();
		File folder = new File(inputdir);
		File[] listFiles = null;
		boolean flag = false;
		if (folder.isDirectory()) {
			listFiles = folder.listFiles();
			for (File file : listFiles) {

				if (file.getAbsolutePath().endsWith(".pdf")) {
					inputOriginalPDFFiles.add(file);
					try {
						PDDocument finalOCRedFile=null;
						createImagePagePDFs(file,middleOutputpath);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}

		processOCR(middleOutputpath);

		mergePDF(middleOutputpath,Outputpath,inputOriginalPDFFiles);
		//process on this pdf and merge in final file
		/*if(imagePage_Pdf!=null && !imagePage_Pdf.keySet().isEmpty()){
							for (Integer pg : imagePage_Pdf.keySet()) {
								PDDocument pdfFile = imagePage_Pdf.get(pg);
								finalOCRedFile.save(middleOutputpath + File.separator + file.getName());

								pdfFile=processOCR(pdfFile);
								imagePage_Pdf_OcredOutput.put(pg, pdfFile);
							}
							 finalOCRedFile=mergePDF(file,imagePage_Pdf_OcredOutput);

						}
						if(finalOCRedFile!=null){
							finalOCRedFile.save(Outputpath + File.separator + file.getName());
							finalOCRedFile.close();
						}*/



	}

	private static void mergePDF(String middleOutputpath,String ocredOutputPath, List<File> inputOriginalPDFFiles) {

		File folder = new File(middleOutputpath);
		Map<String, List<File>>fileOCredPages=new HashMap<String, List<File>>();
		//List<File>pdfFiles=new ArrayList<File>();

		if (folder.isDirectory()) {
			File[]  listFiles = folder.listFiles();
			for (File file : listFiles) {
				if(file.getName().toLowerCase().endsWith(".pdf")){
					String mainFile=file.getName().split("-")[0];

					if(fileOCredPages.containsKey(mainFile)){
						List<File> files = fileOCredPages.get(mainFile);
						files.add(file);
						fileOCredPages.put(mainFile, files);
					}else{
						List<File> files = new ArrayList<File>();
						files.add(file);
						fileOCredPages.put(mainFile, files);
					}
				}
			}
		}

		for (File inFile : inputOriginalPDFFiles) {
			String name=inFile.getName().substring(0,inFile.getName().lastIndexOf("."));
			
			if(!fileOCredPages.containsKey(name)){
				continue;
			}
			
			List<File> imagePagefiles = fileOCredPages.get(name);
			
			PDDocument pdf = null;
			try {
				pdf = PDDocument.load(inFile);

				pdf.setAllSecurityToBeRemoved(true);

				if (pdf.isEncrypted())
					pdf.decrypt("");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CryptographyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			PDDocument ocredFile = new PDDocument();
			List inputOriginalPages = (List<PDPage>)pdf.getDocumentCatalog().getAllPages();

			for (int i = 0; i < inputOriginalPages.size(); i++) {
				
				File pageFile=null;
				for (File f : imagePagefiles) {
					String subName=f.getName().substring(0,f.getName().lastIndexOf("."));
					
					String pageNum=subName.split("-")[1];
					{
						if(i==Integer.valueOf(pageNum)){
							pageFile=f;
							break;
						}
						
					}
				}
				if(pageFile!=null){
					
					PDDocument pageFilePDF = null;
					try {
						pageFilePDF = PDDocument.load(pageFile);

						pageFilePDF.setAllSecurityToBeRemoved(true);

						if (pageFilePDF.isEncrypted())
							pageFilePDF.decrypt("");
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (CryptographyException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
					ocredFile.addPage((PDPage) ((List<PDPage>)pageFilePDF.getDocumentCatalog().getAllPages()).get(0));
				}else{
					ocredFile.addPage((PDPage) inputOriginalPages.get(i));
				}
			}
			//save file
			try {
				ocredFile.save(ocredOutputPath + File.separator +name+".pdf");
				
			} catch (COSVisitorException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}

/*	private static PDDocument mergePDF(File file,Map<Integer, PDDocument> imagePage_Pdf_OcredOutput) {
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(file);

			pdf.setAllSecurityToBeRemoved(true);

			if (pdf.isEncrypted())
				pdf.decrypt("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CryptographyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PDDocument ocredFile = new PDDocument();
		List inputOriginalPages = (List<PDPage>)pdf.getDocumentCatalog().getAllPages();

		for (int i = 0; i < inputOriginalPages.size(); i++) {

			if(imagePage_Pdf_OcredOutput.containsKey(i)){
				ocredFile.addPage((PDPage) ((List<PDPage>)imagePage_Pdf_OcredOutput.get(i).getDocumentCatalog().getAllPages()).get(0));
			}else{
				ocredFile.addPage((PDPage) inputOriginalPages.get(i));
			}
		}
		return ocredFile;
	}*/
	/*	private static PDDocument mergePDF(File file,Map<Integer, PDDocument> imagePage_Pdf_OcredOutput) {
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(file);

			pdf.setAllSecurityToBeRemoved(true);

			if (pdf.isEncrypted())
				pdf.decrypt("");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (CryptographyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PDDocument ocredFile = new PDDocument();
		List inputOriginalPages = (List<PDPage>)pdf.getDocumentCatalog().getAllPages();

		for (int i = 0; i < inputOriginalPages.size(); i++) {

			if(imagePage_Pdf_OcredOutput.containsKey(i)){
				ocredFile.addPage((PDPage) ((List<PDPage>)imagePage_Pdf_OcredOutput.get(i).getDocumentCatalog().getAllPages()).get(0));
			}else{
				ocredFile.addPage((PDPage) inputOriginalPages.get(i));
			}
		}
		return ocredFile;
	}*/

	private static void processOCR(String middleOutputpath) {
		// TODO Auto-generated method stub

	}


	static float percentageAreaTolerance = 0.5f; // Eligibility of an image if
	// it's area is greater than
	// a percentage of area of
	// the page

	private static boolean createImagePagePDFs(File file, String middleOutputpath) throws Exception {

		PDDocument pdf = PDDocument.load(file);
		pdf.setAllSecurityToBeRemoved(true);
		//Map<Integer, PDDocument>imagePage_Pdf=new HashMap<Integer, PDDocument>();
		//	List<PDDocument>ImagePagesPdfs=new ArrayList<PDDocument>();
		if (pdf.isEncrypted())
			pdf.decrypt("");
		boolean imgFlag=false;
		int a = -1;
		for (PDPage page : (List<PDPage>) pdf.getDocumentCatalog().getAllPages()) {
			a++;
			float pageArea = page.getBleedBox().getWidth() * page.getBleedBox().getHeight();
			float imageArea = 0f;

			for (PDXObject x : page.getResources().getXObjects().values()) {

				if (x instanceof PDXObjectImage) {
					PDXObjectImage img = (PDXObjectImage) x;
					imageArea += (img.getWidth() * img.getHeight());

				}
			}

			if (imageArea > pageArea * percentageAreaTolerance) {


				imgFlag=true;

				PDDocument pdf1 = new PDDocument();
				pdf1.addPage(page);
				String filName=file.getName().substring(0,file.getName().lastIndexOf("."));
				pdf1.save(middleOutputpath + File.separator +filName+"-"+ a + ".pdf");
				//ImagePagesPdfs.add(pdf1);
				//imagePage_Pdf.put(a, pdf1);
			}
		}
		return imgFlag;
	}
}
