package com.pdf.parser.pipeline;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.poi.hslf.blip.Metafile.Header;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.strategy.LeftNumbersDetectionStrategy;
import com.pdf.parser.base.strategy.PDFFooterDetectorStrategy;
import com.pdf.parser.base.strategy.PDFHeaderDetectionStrategy;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.complex.strategy.PDFParaDetectionStrategy;

public class Pdf_Text_Writer {



	private String inputFile = "",outputFilePath="";
	//private String outputParagraphFileDirPath = "";
//	private Set<ExtractionRule> rules;
	private static Set<String>processedFiles=new HashSet<String>();
	static ResourceBundle basicConfig;
	private Map<Integer,List<String>> startPageKeywords = new TreeMap<Integer, List<String>>();
	private static boolean printFlag=false;

	//private Map<String,Set<String>> validPagKeywordsForCellDetection=new TreeMap<String, Set<String>>();
//	private int forPageCellDetection_matching_Limit;
	//private;//=new TreeMap<Integer, BufferedImage>();

	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

			BufferedReader reader = new BufferedReader(new FileReader("config/processedFiles.list"));
			String line ="";
			while((line = reader.readLine()) != null)
				processedFiles.add(line.trim());
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	static final Integer forStartPageDetection_matching_Limit = Integer.valueOf(basicConfig.getString("forStartPageDetection_matching_Limit"));

	public Pdf_Text_Writer(String inputFile, String outputFilePath) {

		this.inputFile=inputFile;
		this.outputFilePath=outputFilePath;
		//this.outputParagraphFileDirPath=outputParagraphFileDirPath;

		try{
//			forPageCellDetection_matching_Limit=Integer.valueOf(basicConfig.getString("forPageCellDetection_matching_Limit"));

			BufferedReader reader = new BufferedReader(new FileReader("config/startPageKeywords.list"));
			if(basicConfig.getString("printFlag").equalsIgnoreCase("true")){
				printFlag=true;
			}
			String line ="";
			while((line = reader.readLine()) != null){
				String[] split = line.split("##");
				int templateID=Integer.valueOf(split[1]);
				if(startPageKeywords.containsKey(templateID)){
					List<String> kw = startPageKeywords.get(templateID);
					kw.add(split[0]);
					startPageKeywords.put(templateID, kw);
				}else{
					List<String> kw = new ArrayList<String>();
					kw.add(split[0]);
					startPageKeywords.put(templateID, kw);
				}
			}
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private void apply() throws IOException {
		//defaultEmailLastPage=;

		File f=new File(inputFile);
		PDDocument pdf = PDDocument.load(f);

		pdf.setAllSecurityToBeRemoved(true);
		if(pdf.isEncrypted()){
			try {
				pdf.decrypt("");
			} catch (CryptographyException e) {
				e.printStackTrace();
			}
		}
		pdf.setAllSecurityToBeRemoved(true);

		//Create image cet of pdf Pages for CheckBoxProcessing

		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, DPRectangle> pageWiseRectangle = parser.getPageSizes();
		Map<Integer, List<PDFSegment>> pageSegments = parser.getSegments();
		List<PDPage> pdPages = parser.getPdfPages();

		//remove header and footer
		Map<Integer,List<BasicStructure>> SegsInBasicStru1=new TreeMap<Integer, List<BasicStructure>>();
		for (Integer pdPage : pageSegments.keySet()) {
			List<PDFSegment> lst = pageSegments.get(pdPage);
			List<BasicStructure>temp=new ArrayList<BasicStructure>(lst);
			SegsInBasicStru1.put(pdPage, temp);
		}

		System.out.println("\n------------------- Headers ------------------------------");
		PDFHeaderDetectionStrategy hds= new PDFHeaderDetectionStrategy(SegsInBasicStru1,pageWiseRectangle); //need to also remove from pageAndMColWiseSegments 
		hds.apply();
		Map<Integer, List<Header>> pageWiseHeaders = hds.getOutcome();
		System.out.println(pageWiseHeaders);
		Map<Integer, List<BasicStructure>> segmentsAftrHeaderRemoval = hds.getRemainingPageWiseParas();

		//		remove footers
		System.out.println("\n------------------- Footers ------------------------------");
		System.out.println("PDFFooterDetectorStrategy");
		PDFFooterDetectorStrategy fds= new PDFFooterDetectorStrategy(segmentsAftrHeaderRemoval,pageWiseRectangle,parser.getPages());
		fds.apply();

		Map<Integer, List<BasicStructure>> pageWiseFooters = fds.getOutcome();
		System.out.println(pageWiseFooters);
		Map<Integer, List<PDFSegment>> segmentsAftrFooterRemoval=fds.getRemainingPageWiseSegs();

		//LeftNumbersDetectionStrategy
		LeftNumbersDetectionStrategy lNum=new LeftNumbersDetectionStrategy(segmentsAftrFooterRemoval, pageWiseRectangle);
		lNum.apply();
		Map<Integer, List<PDFSegment>> afterLeftMargineDataRemoval = lNum.getOutcome();

		pageSegments=afterLeftMargineDataRemoval;

		//----------------------------------startPage-----------------------------
		int startPage=detectStartPage(pageSegments); 

		System.out.println("****************\n StartPage :\t "+startPage+"\n********************");

		System.out.println("--------------------- PDFParaDetectionStrategy --------------------");
		PDFParaDetectionStrategy pdp=new PDFParaDetectionStrategy(pageSegments,pdPages,startPage);
		pdp.apply();
		Map<Integer, List<PDFPara>> pageWiseParas = pdp.getOutcome();

		if(printFlag){
			System.out.println("\n ***** Paras: *******");
			for ( Integer k : pageWiseParas.keySet()) { 
				System.out.println("page \t"+k);
				for ( PDFPara p : pageWiseParas.get(k)) {
					System.out.println("Enum:  "+ p.getEnumeration() +"\t "+p.getStringRepresentation());
				}
			}
		}

			String parafile=outputFilePath+File.separator+f.getName().substring(0, f.getName().lastIndexOf("."))+".txt";
			writeStructure(pageWiseParas,parafile,startPage);

	}



	public void writeStructure(	Map<Integer, List<PDFPara>> pageWiseParas,String filePath, int startPage){

		StringBuffer strb=new StringBuffer();

		BufferedWriter writer;
		try {
			writer = new BufferedWriter(new FileWriter(filePath));
			for (Integer em : pageWiseParas.keySet()) {
				if(!pageWiseParas.get(em).isEmpty() && em>=startPage){
					for (PDFPara structure : pageWiseParas.get(em)) {
						strb.append(structure.getStringRepresentation()+" ");
					}
				}
			}
			writer.write(strb.toString().replaceAll("\\s+", " ").trim());
			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}
		
	}

	private Integer detectStartPage(Map<Integer, List<PDFSegment>> map)
	{
		int sartPage=0;

		if(startPageKeywords==null ||startPageKeywords.isEmpty()){
			return sartPage;
		}
		for (Integer pg : map.keySet()) {

			List<PDFSegment>list=map.get(pg);
			if(list!=null && !list.isEmpty()){
				sartPage=list.get(0).getRectangle().getPage();
			}
			// TODO: Get character lines/segments, read keywords, match minimum N keywords

			for (Integer key : startPageKeywords.keySet()) { // template keyword matching on same page
				int matchCount=0;
				List<String> pageStartIndicatorList = startPageKeywords.get(key);
				List<String> matchedKeyWords=new ArrayList<String>();
				for ( PDFSegment seg :list ) 
				{
					for (String string : pageStartIndicatorList) {
						if(seg.getStringRepresentation().contains(string) && !matchedKeyWords.contains(seg.getStringRepresentation()))
						{
							matchedKeyWords.add(seg.getStringRepresentation());
							matchCount++;
							break;
						}
					}
				}
				if(forStartPageDetection_matching_Limit > 0){
					if(matchCount>=forStartPageDetection_matching_Limit){
						System.out.println("It is Starting page\t"+sartPage);
						return list.get(0).getRectangle().getPage();
					}
				}else{
					if(matchCount>=pageStartIndicatorList.size()){
						return list.get(0).getRectangle().getPage();
					}
				}

			}


		}
		return 0;
	}

	public static void main(String[] a) throws Exception {

		
		String inputDirPath =a[0];
		String outputFilePath =a[1];
//		String inputDirPath ="D:\\Platform\\Phizer\\TestSample\\temp";
//		String outputFilePath ="D:\\Platform\\Phizer\\TestSample\\output";
		
		Queue<File> inputQ = new LinkedList<File>();
		inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));

		while(!inputQ.isEmpty())
		{
			final File in = inputQ.poll();
			long start=System.currentTimeMillis();
			//	System.out.println("\n##------##--------## Start of "+in.getName()+"\t "+start);
			if(in.isDirectory())//f.getName().startsWith("AWD")){
				inputQ.addAll(Arrays.asList(in.listFiles()));

			else if(in.getName().toLowerCase().endsWith(".pdf")){

				try{

					Pdf_Text_Writer ph=new Pdf_Text_Writer(in.getAbsolutePath(),outputFilePath);
					ph.apply();
					System.out.println("\n***********##------##--------## End of\t"+in.getAbsolutePath()+"\t "+(System.currentTimeMillis()-start)/1000);
				}catch(Exception e)
				{
					e.printStackTrace();
				}
			}

		}


	}


}
