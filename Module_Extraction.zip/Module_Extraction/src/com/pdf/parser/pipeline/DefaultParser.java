package com.pdf.parser.pipeline;

import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDResources;

import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFVerticalGap;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.base.strategy.PDFCharacterFormationStrategy;
import com.pdf.parser.base.strategy.PDFSegmentFormationStrategy;
import com.pdf.parser.base.strategy.PDFWordFormationStrategy;

/**
 * This is the default parser of PDF file.
 * It shows how the basic structures are prepared and some of the complex ones.
 * @author Shishir.Mane
 *
 */
public class DefaultParser implements PDFParser {

	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("ignore-structure-patterns",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private PDDocument pdf;
	private Map<Integer, List<PDFCharacter>> characters;
	private Map<Integer, List<PDFCharacter>> overrideCharacters;
	private Map<Integer, List<PDFWord>> words;
	private Map<Integer, List<PDFVerticalGap>> vgaps;
	private Map<Integer, List<PDFSegment>> segments;
	private Map<Integer, Point2D> pageWidthHeight = new HashMap<Integer, Point2D>();
	private List<Integer> pages;
	private List<PDPage> pdfPages;
	private Map<Integer, DPRectangle> pageSizes;
	private boolean docConainImage;

	public DefaultParser(PDDocument pdf){
		this.pdf = pdf;
		characters = new TreeMap<Integer, List<PDFCharacter>>();
		overrideCharacters= new TreeMap<Integer, List<PDFCharacter>>();
		words = new TreeMap<Integer,List<PDFWord>>();
		vgaps = new TreeMap<Integer,List<PDFVerticalGap>>();
		segments = new TreeMap<Integer, List<PDFSegment>>();
		pageSizes = new TreeMap<Integer, DPRectangle>();
		pages=new ArrayList<Integer>();
		docConainImage=false;
	}

	public DefaultParser(PDDocument pdf, List<Integer> pages){
		this.pdf = pdf;
		characters = new TreeMap<Integer, List<PDFCharacter>>();
		overrideCharacters= new TreeMap<Integer, List<PDFCharacter>>();
		words = new TreeMap<Integer,List<PDFWord>>();
		vgaps = new TreeMap<Integer,List<PDFVerticalGap>>();
		segments = new TreeMap<Integer, List<PDFSegment>>();
		this.pages = pages;
	}

	public void parse() {
		formulateStructures();
	}

	@SuppressWarnings("unchecked")
	public void formulateStructures() {
		if(pages==null || pages.isEmpty()){

			for(int pg=0; pg<pdf.getDocumentCatalog().getAllPages().size(); pg++){
				pages.add(pg);
			}
		}

		for(int pg=0; pg<pdf.getDocumentCatalog().getAllPages().size(); pg++){

			if(pages!=null && !pages.contains(pg))
				continue;

			PDPage page = (PDPage) pdf.getDocumentCatalog().getAllPages().get(pg);
			//	pageSizes.put(pg, new Rectangle((int)page.getBleedBox().getWidth(), (int)page.getBleedBox().getHeight()));

			if(page.getBleedBox()!=null){
				//System.out.println(page.getBleedBox() +"\t"+ (int)page.getBleedBox().getWidth());
				//	pageSizes = new HashMap<Integer, Rectangle>();
				Rectangle temp = new Rectangle((int)page.getBleedBox().getWidth(), (int)page.getBleedBox().getHeight());
				pageSizes.put(pg, new DPRectangle((float)temp.getX(),(float)temp.getY(),(float)temp.getWidth(),(float)temp.getHeight(),pg));
			}
			else if(page.getMediaBox()!=null){
				Rectangle temp = new Rectangle((int)page.getMediaBox().getWidth(), (int)page.getMediaBox().getHeight());
				pageSizes.put(pg, new DPRectangle((float)temp.getX(),(float)temp.getY(),(float)temp.getWidth(),(float)temp.getHeight(),pg));
			}
			else if(page.getTrimBox()!=null){
				Rectangle temp = new Rectangle((int)page.getTrimBox().getWidth(), (int)page.getTrimBox().getHeight());

				pageSizes.put(pg, new DPRectangle((float)temp.getX(),(float)temp.getY(),(float)temp.getWidth(),(float)temp.getHeight(),pg));
			}




			pdfPages = (List<PDPage>) pdf.getDocumentCatalog().getAllPages();

			float width = page.getBleedBox().getWidth();
			float height = page.getBleedBox().getHeight();
			pageWidthHeight.put(pg, new Point2D.Float(width, height));

			PDFCharacterFormationStrategy pcf = new PDFCharacterFormationStrategy(page, pg);
			pcf.apply();

			if(!docConainImage){
				try{
					if(isImagePresent(page))
						docConainImage=true;
				}catch (Exception e) {
					// TODO: handle exception
				}
			}

			if(pcf.getOutcome().size() == 0)//No characters on page
				continue;

			characters.put(pg, pcf.getOutcome());
			overrideCharacters.put(pg, pcf.getOverrideCharacters());

			PDFWordFormationStrategy pwf = new PDFWordFormationStrategy(pcf.getOutcome(), pg);
			pwf.apply();

			//Remove irrelevant words
			Iterator<PDFWord> wordIterator = pwf.getOutcome().iterator();
			while(wordIterator.hasNext()){
				if(wordIterator.next().getStringRepresentation().replaceAll(config.getString("word"), "").trim().length()==0)
					wordIterator.remove();
			}
			List<PDFWord> pageWords = pwf.getOutcome();
			updatePageWordsForKeyValueProcess(pageWords);
			System.out.println();

			words.put(pg, pageWords);

			PDFSegmentFormationStrategy psf = new PDFSegmentFormationStrategy(pageWords, pg);
			psf.apply();

			//Remove irrelevant segments
			Iterator<PDFSegment> segmentIterator = psf.getOutcome().iterator();
			while(segmentIterator.hasNext()){
				if(segmentIterator.next().getStringRepresentation().replaceAll(config.getString("segment"), "").trim().length()==0)
					segmentIterator.remove();
			}
			segments.put(pg, psf.getOutcome());

		}
	}

	private static List<List<String>>kvWordSetList=new ArrayList<List<String>>();

	private void updatePageWordsForKeyValueProcess(List<PDFWord> pageWords) 
	{
		if(kvWordSetList.isEmpty()){
			try {
				BufferedReader reader = new BufferedReader(new FileReader("config/KeyValueExternalKeywords.list"));
				String line="";
				while((line = reader.readLine()) != null){
					List<String> split = Arrays.asList(line.split("#"));
					kvWordSetList.add(split);
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		for (List<String> string : kvWordSetList) {
			//check all are present and in same x2
			List<PDFWord> matchedwordList=new ArrayList<PDFWord>();
			PDFWord lastWord=null;
			for (PDFWord wrd : pageWords) {
				if(wrd.getStringRepresentation().contains("&")){
					//PG code 
					
					//if(!pageWords.get(pageWords.indexOf(wrd)-1).getStringRepresentation().equalsIgnoreCase("Name")){
					if(pageWords.indexOf(wrd)==0)
					{
						if(!pageWords.get(pageWords.indexOf(wrd)).getStringRepresentation().equalsIgnoreCase("Name")){
							continue;
						}
					}
					else if(!pageWords.get(pageWords.indexOf(wrd)-1).getStringRepresentation().equalsIgnoreCase("Name")){
						continue;
					}
						
					//System.out.println();
				}
				if(wrd.getStringRepresentation().contains("Class")){
					//System.out.println();
				}
					
				if(string.contains(wrd.getStringRepresentation().trim()) && lastWord==null){
					matchedwordList.add(wrd);
					lastWord=wrd;
				}else if(string.contains(wrd.getStringRepresentation().trim()) && Math.abs(wrd.getRectangle().getX2()-lastWord.getRectangle().getX2())<12){
					matchedwordList.add(wrd);
					lastWord=wrd;
				}
			}
			if(matchedwordList.size()>=(string.size()-1)){
				for (PDFWord pdfWord : matchedwordList) {
					pdfWord.setStringRepresentation(pdfWord.getStringRepresentation()+":");
				}
			}
		}

	}

	@SuppressWarnings("deprecation")
	public static boolean isImagePresent(PDPage page){ //for checking signature as image 

		PDResources pdResources =page.getResources();
		if(pdResources!=null){
			try {
				Map	pageImages = pdResources.getImages();
				if (pageImages != null) {
					while (pageImages.keySet().iterator().hasNext()) {
						return true;
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	public Map<Integer, List<PDFCharacter>> getCharacters() {
		return characters;
	}
	public Map<Integer, List<PDFCharacter>> getOverrideCharacters() {
		return overrideCharacters;
	}

	public Map<Integer, List<PDFWord>> getWords() {
		return words;
	}

	public Map<Integer, List<PDFSegment>> getSegments() {
		return segments;
	}

	public Map<Integer, Point2D> getPageWidthHeight() {
		return pageWidthHeight;
	}

	public Map<Integer, List<PDFVerticalGap>> getVgaps() {
		return vgaps;
	}

	public List<PDPage> getPdfPages() {
		return pdfPages;
	}

	public List<Integer> getPages() {
		return pages;
	}

	public Map<Integer, DPRectangle> getPageSizes() {
		return pageSizes;
	}

	public boolean isDocConainImage() {
		return docConainImage;
	}

}
