package com.pdf.parser.base;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

import com.pdf.parser.utils.CommonOperations;


public class Enumerations {
	
	public static Map<Integer,List<String>> optionMap;
	public static Set<String> options;
	
	static{
		
		optionMap = new HashMap<Integer, List<String>>();
		options = new TreeSet<String>();
		
		List<String> enumerationPatterns = new ArrayList<String>();
		List<String> enclosurePatterns = new ArrayList<String>();
		
		try{
			BufferedReader reader = new BufferedReader(new FileReader("config/enumerations.list"));
			
			String line ="";
			while((line = reader.readLine()) != null)
				enumerationPatterns.add(line.trim());
			
			reader.close();
			
			
			reader = new BufferedReader(new FileReader("config/enumeration-enclosures.list"));
			
			while((line = reader.readLine()) != null)
				enclosurePatterns.add(line.trim());
			
			reader.close();
					
		}catch(Exception e){
			e.printStackTrace();
		}
		
		int count = 0;
		for(String pattern : enumerationPatterns){
			for(String enclosure : enclosurePatterns){
				
				List<String> combinations = new ArrayList<String>();
				optionMap.put(count++, combinations);
				
				//Check if the pattern is single or double pattern
				int patternCount = 0;
				for(String p : Arrays.asList("%d","%a","%A","%r","%R")){
					
					int index=0;
					while(index<pattern.length() && pattern.indexOf(p, index)!=-1){
						patternCount++;
						index = pattern.indexOf(p, index)+1;
					}
					
					if(patternCount!=0)
						break;
				}
				
				if(patternCount == 1){
					for(int i=1; i<=100; i++){
						
						if(pattern.contains("%d")){
							combinations.add(enclosure.replace("%e", i+""));
						
						}else if(pattern.contains("%a")){
							if(i<27){
								char a = (char)(96+i);
								combinations.add(enclosure.replace("%e", a+""));
								
							}else
								break;
						
						}else if(pattern.contains("%A")){
							if(i<27){
								char a = (char)(64+i);
								combinations.add(enclosure.replace("%e", a+""));
								
							}else
								break;
						
						}else if(pattern.contains("%r")){
							combinations.add(enclosure.replace("%e", CommonOperations.getRomanNumerals(i).toLowerCase()));
						
						}else if(pattern.contains("%R")){
							combinations.add(enclosure.replace("%e", CommonOperations.getRomanNumerals(i)));
						
						}
					}
				
				}else if(patternCount == 2){
					if(pattern.equals("%d.%d")){
						
						for(int i=1; i<=100; i++){
							for(int j=1; j<=100; j++){
								combinations.add(enclosure.replace("%e", i+"."+j));
							}
						}
					}
				}
				
				options.addAll(combinations);
			}
		}
		
		//Without enclosure only for 1.1 pattern
		if(enumerationPatterns.contains("%d.%d")){
			
			List<String> combinations = new ArrayList<String>();
			optionMap.put(count++, combinations);
			
			for(int i=1; i<=100; i++){
				for(int j=1; j<=100; j++){
					combinations.add(i+"."+j);
				}
			}
			
			options.addAll(combinations);
		}
	}
	
	public static void main(String[] args) {
		char a = 'A';
		System.out.println((int)a);
	}
}
