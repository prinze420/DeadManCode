package com.pdf.parser.base;

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;

public class PDFSegment implements BasicStructure {
	
	long id;
	DPRectangle rectangle;
	String stringRepresentation;
	StructureType type;
	List<PDFWord> words;
	
	boolean isEnumerated;
	String enumeration;
	
	boolean isTitle, isEntirelyTitle,isCellPart,isInKVPair;
	String title;
	
	public PDFSegment(String segment, DPRectangle rectangle, 
			StructureType type, List<PDFWord> words) {
		
		id = Structure_Id.getInstance().getNext();
		this.stringRepresentation = segment;
		this.rectangle = rectangle;
		this.type = type;
		this.words = new ArrayList<PDFWord>(words);
		isEnumerated = false;
		isTitle = false;
		isEntirelyTitle = false;
	}
	
	public long getId() {
		return id;
	}

	//Should either be starts with or ends with
	public List<PDFSegment> breakSegment(String phrase){
		List<PDFSegment> broken = new ArrayList<PDFSegment>();
		
		String word1 = "", word2 = "";
		List<PDFWord> words1 = new ArrayList<PDFWord>();
		List<PDFWord> words2 = new ArrayList<PDFWord>();
		
		if(stringRepresentation.toLowerCase().trim().startsWith(phrase.toLowerCase().trim())){
			int i=0;
			
			for(i=0; i<words.size(); i++){
				word1 += words.get(i).getStringRepresentation()+" ";
				if(word1.toLowerCase().trim().equals(phrase.toLowerCase().trim()))
					break;
			}
			
			for(int j=i+1; j<words.size(); j++)
				word2 += words.get(j).getStringRepresentation()+" ";
			
			for(int j=0; j<words.size(); j++){
				if(j<=i)
					words1.add(words.get(j));
				else
					words2.add(words.get(j));
			}
		
		}else if(stringRepresentation.toLowerCase().trim().endsWith(phrase.toLowerCase().trim())){
			int i=0;
			
			for(i=words.size()-1; i>=0; i--){
				word2 = words.get(i).getStringRepresentation()+" "+word2;
				if(word2.toLowerCase().trim().equals(phrase.toLowerCase().trim()))
					break;
			}
			
			for(int j=0; j<i; j++)
				word1 += words.get(j).getStringRepresentation()+" ";
			
			for(int j=0; j<words.size(); j++){
				if(j<i)
					words1.add(words.get(j));
				else
					words2.add(words.get(j));
			}
		}
		
		if(words1.size()>0 && words2.size()>0){
			float x = words1.get(0).getRectangle().getX();
			float y = words1.get(0).getRectangle().getY();
			float width = words1.get(words1.size()-1).getRectangle().getX2() - words1.get(0).getRectangle().getX();
			float height = words1.get(0).getRectangle().getHeight();
			broken.add(new PDFSegment(word1, new DPRectangle(x, y, width, height, rectangle.getPage()), StructureType.SEGMENT, words1));
			
			x = words2.get(0).getRectangle().getX();
			y = words2.get(0).getRectangle().getY();
			width = words2.get(words2.size()-1).getRectangle().getX2() - words2.get(0).getRectangle().getX();
			height = words2.get(0).getRectangle().getHeight();
			broken.add(new PDFSegment(word2, new DPRectangle(x, y, width, height, rectangle.getPage()), StructureType.SEGMENT, words2));
		}
		
		return broken;
	}
	
	@Override
	public String toString() {
		return stringRepresentation;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangle == null) ? 0 : rectangle.hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFSegment other = (PDFSegment) obj;
		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public String getStringRepresentation() {
		return stringRepresentation.trim();
	}

	public DPRectangle getRectangle() {
		return rectangle;
	}

	public StructureType getType() {
		return type;
	}

	public List<PDFWord> getWords() {
		return words;
	}

	public float getWidthOfSpace() {
		return getWords().get(0).getWidthOfSpace();
	}

	public boolean isEnumerated() {
		return isEnumerated;
	}

	public void setEnumerated(boolean isEnumerated) {
		this.isEnumerated = isEnumerated;
	}

	public String getEnumeration() {
		return enumeration;
	}

	public void setEnumeration(String enumeration) {
		this.enumeration = enumeration;
	}

	public void setStringRepresentation(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}

	public boolean isTitle() {
		return isTitle;
	}

	public void setTitle(boolean isTitle) {
		this.isTitle = isTitle;
	}

	public boolean isEntirelyTitle() {
		return isEntirelyTitle;
	}

	public void setEntirelyTitle(boolean isEntirelyTitle) {
		this.isEntirelyTitle = isEntirelyTitle;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	
	
	public void setIsInKVPair(boolean b) {
		// TODO Auto-generated method stub
		this.isInKVPair = b;
	}
	public boolean isInKVPair() {
		return isInKVPair;
	}
	
	public void setIsCellPart(boolean b) {
		// TODO Auto-generated method stub
		this.isCellPart = b;
	}
	
	public boolean isCellPart() {
		return isCellPart;
	}
	DPCell lineDPCell;
	public void setLineDPCell(DPCell c) {
		this.lineDPCell=c;
	}
	
	public DPCell getLineDPCell(){
		return lineDPCell;
	}
}
