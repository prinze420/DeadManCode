package com.pdf.parser.base;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;

/**
 * A vertical gap represents the gap of vertical space that has no segment, word or character within its boundary
 * @author Shishir.Mane
 *
 */
public class PDFVerticalGap implements BasicStructure {
	
	long id;
	DPRectangle rectangle;
	float widthOfSpace;
	String bottomWord="";
	StructureType type;
	BasicStructure word1, word2;
	
	public PDFVerticalGap(BasicStructure word1, DPRectangle rectangle, StructureType type, float widthOfSpace) {
		id = Structure_Id.getInstance().getNext();
		this.word1 = word1;
		this.rectangle = rectangle;
		this.type = type;
		this.widthOfSpace = widthOfSpace;
	}

	public long getId() {
		return id;
	}

	@Override
	public String toString() {
		return "x=" + rectangle.getX() + ", y=" + rectangle.getY() + ", word1=" + word1 + ", bottomWord=" + bottomWord+", page="+rectangle.getPage()+"\n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bottomWord == null) ? 0 : bottomWord.hashCode());
		result = prime * result + ((rectangle == null) ? 0 : rectangle.hashCode());
		result = prime * result + ((word1 == null) ? 0 : word1.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFVerticalGap other = (PDFVerticalGap) obj;
		if (bottomWord == null) {
			if (other.bottomWord != null)
				return false;
		} else if (!bottomWord.equals(other.bottomWord))
			return false;
		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		if (word1 == null) {
			if (other.word1 != null)
				return false;
		} else if (!word1.equals(other.word1))
			return false;
		return true;
	}

	public DPRectangle getRectangle() {
		return rectangle;
	}

	public StructureType getType() {
		return type;
	}

	public String getBottomWord() {
		return bottomWord;
	}

	public void setBottomWord(String bottomWord) {
		this.bottomWord = bottomWord;
	}

	/**
	 * A vertical block will always have blank content.
	 */
	public String getStringRepresentation() {
		return word1+"--"+bottomWord;
	}
	
	@Override
	public float getWidthOfSpace() {
		return widthOfSpace;
	}

	public BasicStructure getWord1() {
		return word1;
	}

	public BasicStructure getWord2() {
		return word2;
	}

	public void setWord2(BasicStructure word2) {
		this.word2 = word2;
	}
}
