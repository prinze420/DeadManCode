package com.pdf.parser.base;

import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;

public class PDFTitle implements BasicStructure {
	
	long id;
	DPRectangle rectangle;
	String stringRepresentation;
	StructureType type;
	
	List<PDFSegment> segments;
	
	public PDFTitle(List<PDFSegment> segments, StructureType type) {
		super();
		id = Structure_Id.getInstance().getNext();
		this.segments = segments;
		this.type = type;
	}
	
	public long getId() {
		return id;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangle == null) ? 0 : rectangle.hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFTitle other = (PDFTitle) obj;
		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public DPRectangle getRectangle() {
		return rectangle;
	}

	public float getWidthOfSpace() {
		return segments.get(0).getWords().get(0).getWidthOfSpace();
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public StructureType getType() {
		return type;
	}

	public List<PDFSegment> getSegments() {
		return segments;
	}
}
