package com.pdf.parser.base.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.pdf.parser.Strategy;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.utils.CommonOperations;


public class PDFWordFormationStrategy implements Strategy<List<PDFWord>> {

	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	Boolean fontBasedWordFormation = new Boolean(config.getString("fontBasedWordFormation"));

	List<PDFCharacter> characters;
	List<PDFCharacter> spaceCharacters;
	List<PDFWord> words;
	int page;

	public PDFWordFormationStrategy(List<PDFCharacter> characters, int page){
		this.characters = characters;
		words = new ArrayList<PDFWord>();
		this.page = page;
	}
	public PDFWordFormationStrategy(List<PDFCharacter> characters, int page, List<PDFCharacter> spaceList){
		this.characters = characters;
		if(spaceList!=null)
			this.spaceCharacters = spaceList;
		else
			this.spaceCharacters = new ArrayList<PDFCharacter>();
		words = new ArrayList<PDFWord>();
		this.page = page;
	}

	@SuppressWarnings("unchecked")
	public void apply() {

		//Characters within a word
		List<PDFCharacter> wordCharSet = new ArrayList<PDFCharacter>();

		//Initialize the first character
		wordCharSet.add(characters.get(0));

		//String representation of the word
		String word = characters.get(0).getStringRepresentation();

		//Start the loop with the second character
		for(int i=1; i<characters.size(); i++){

			PDFCharacter character = characters.get(i);
			PDFCharacter lastChar = wordCharSet.get(wordCharSet.size()-1);
			PDFCharacter nextChar = null;
			if(i<characters.size()-1){
				nextChar = characters.get(i+1);
			}
			boolean spaceCharFlag =false;
			/*if(i<characters.size()-1){
				nextChar = characters.get(i+1);
			}*/
			if(character.getStringRepresentation().trim().length()==0 || character.isSpaceChar() ||PDFCharacterFormationStrategy.isUTFSpaceChar(character.getStringRepresentation())){
				spaceCharFlag =true;
				//	System.out.println(character.getWidthOfSpace());
			}


			float predictedX = lastChar.getRectangle().getX2();
			float diffX = Math.abs(predictedX - character.getRectangle().getX());
			if(spaceCharFlag && nextChar!=null ){
				diffX = Math.abs(lastChar.getRectangle().getX2() - nextChar.getRectangle().getX());
			}

			//In some cases pdf box does not return a font name
			boolean doesFontMatch = lastChar.getFontName().equals(character.getFontName()) 
					|| lastChar.getFontName().length()==0 
					|| character.getFontName().length()==0;

			doesFontMatch = doesFontMatch && lastChar.getFontSize() == character.getFontSize()
					&& lastChar.isBold()==character.isBold() && lastChar.isItalic()==character.isItalic();

			if(!fontBasedWordFormation)
				doesFontMatch = true;

			//A word should consist of characters with same font and size
			//The difference in x2 of last character and the x of current char should be less than half the width of space, to be part of the same word
			//Also the tolerance for Y2 is kept half of character height
			//Also check that characters have the same isBold and isItalic flags
			//We can understand that these conditions are adaptive and hence will adapt to different fonts and sizes

			//			if(diffX < 2
			/*if(diffX <= character.getWidthOfSpace()/2 && spaceCharFlag){
				System.out.println("cvdbcjk");
			}*/
			if((diffX <= character.getWidthOfSpace()/2 && !spaceCharFlag ) 
					&& CommonOperations.isOverlapOnY(lastChar, character) 
					&& doesFontMatch
					&&((lastChar.getLineCell()==null && character.getLineCell()==null) ||
							(lastChar.getLineCell()!=null && character.getLineCell()!=null && lastChar.getLineCell().equals(character.getLineCell())))
					){

				wordCharSet.add(character);
				word += character.getStringRepresentation();

				//If this is the last character
				if(i==characters.size()-1){
					//Find the max height of word
					float maxHeight = -1;
					for(PDFCharacter c1 : wordCharSet){
						float height = c1.getRectangle().getHeight();
						if(height > maxHeight)
							maxHeight = height;
					}

					Iterator<PDFCharacter> it =wordCharSet.iterator();
					while(it.hasNext()) {
						PDFCharacter pdfCharacter =it.next();
						if(pdfCharacter.getStringRepresentation().trim().length()==0 || pdfCharacter.isSpaceChar() 
								||PDFCharacterFormationStrategy.isUTFSpaceChar(pdfCharacter.getStringRepresentation())){
							it.remove();
						}
					}
					//Formulate the word
					if(!wordCharSet.isEmpty()){
						PDFCharacter firstChar = wordCharSet.get(0);
						lastChar =wordCharSet.get(wordCharSet.size()-1);
						words.add(new PDFWord(word, 
								new DPRectangle(firstChar.getRectangle().getX(), firstChar.getRectangle().getY(), lastChar.getRectangle().getX2()-firstChar.getRectangle().getX(), maxHeight, page), 
								StructureType.WORD, wordCharSet));
					}	
				}

			}else{

				if(word.trim().length()>0){

					//Find the max height of word
					float maxHeight = -1;
					for(PDFCharacter c1 : wordCharSet){
						float height = c1.getRectangle().getHeight();
						if(height > maxHeight)
							maxHeight = height;
					}

					Iterator<PDFCharacter> it =wordCharSet.iterator();
					while(it.hasNext()) {
						PDFCharacter pdfCharacter =it.next();
						if(pdfCharacter.getStringRepresentation().trim().length()==0 || pdfCharacter.isSpaceChar() 
								||PDFCharacterFormationStrategy.isUTFSpaceChar(pdfCharacter.getStringRepresentation())){
							it.remove();
						}
					}
					//Formulate the word
					if(!wordCharSet.isEmpty()){
						PDFCharacter firstChar = wordCharSet.get(0);
						lastChar =wordCharSet.get(wordCharSet.size()-1);
						words.add(new PDFWord(word, 
								new DPRectangle(firstChar.getRectangle().getX(), firstChar.getRectangle().getY(), lastChar.getRectangle().getX2()-firstChar.getRectangle().getX(), maxHeight, page), 
								StructureType.WORD, wordCharSet));
					}
				}

				wordCharSet.clear();
				if(character.getStringRepresentation().trim().length()==0 || character.isSpaceChar() ||PDFCharacterFormationStrategy.isUTFSpaceChar(character.getStringRepresentation())){
					i++;
					while(i<characters.size()){
						PDFCharacter next=characters.get(i);
						if(next.getStringRepresentation().trim().length()==0 || next.isSpaceChar() ||PDFCharacterFormationStrategy.isUTFSpaceChar(next.getStringRepresentation())){
							//do nothing
						}else{
							wordCharSet.add(next);
							word = next.getStringRepresentation();
							break;
						}
						i++;
					}
				}
				else{
					wordCharSet.add(character);
					word = character.getStringRepresentation();
				}

				//Handling last dangling character
				if(i==characters.size()-1){
					words.add(new PDFWord(character.getStringRepresentation(), 
							new DPRectangle(character.getRectangle().getX(), character.getRectangle().getY(), character.getRectangle().getWidth(), character.getRectangle().getHeight(), page), 
							StructureType.WORD, Arrays.asList(character)));
				}
			}
		}

		words = (List<PDFWord>)CommonOperations.yxSort(new HashSet<PDFWord>(words), false, Float.valueOf(config.getString("allowedYDiffInSort")));

		//Is completely bold
		for(PDFWord w : words){

			/*if(w.getStringRepresentation().trim().equalsIgnoreCase("$�000")){
				System.out.println("czsdkcbjkznj");
			}*/

			boolean isBold = true;
			//			sameCell;
			for(PDFCharacter c : w.getCharacters()){
				if(!c.isBold()){
					isBold = false;
					break;
				}

			}

			if(isBold)
				w.setCompletelyBold(true);


		}
		
		//split word based on isWordContainValidColon
		List<PDFWord>newWords=new ArrayList<PDFWord>();
		Iterator<PDFWord> itr = words.iterator();
		while(itr.hasNext()){
			PDFWord wrd = itr.next();
			String wrdText = wrd.getStringRepresentation().trim();
			if(wrdText.contains(":") && !isWordContainValidColon(wrdText)){
				List<PDFWord> splitWords = wrd.breakWord(":");
				if(splitWords!=null && !splitWords.isEmpty()){
					newWords.addAll(splitWords);
					itr.remove();
				}
			}
		}
		if(!newWords.isEmpty()){
			words.addAll(newWords);
			words = (List<PDFWord>)CommonOperations.yxSort(new HashSet<PDFWord>(words), false, Float.valueOf(config.getString("allowedYDiffInSort")));
		}
		

	}

	private static  boolean isWordContainValidColon(String text) {
		//String text=w1.getStringRepresentation().trim();

		if(text.trim().isEmpty()||text.trim().endsWith(":")){
			return true;
		}

		if(text.contains(":")){
			if(text.trim().length()>2){
				if(text.matches("(.*)([0-9]{1,}:[0-9]{1,})(.*)")){
					return true; //its valid colon
				}
			}
		}else{
			return true;
		}
		return false;

	}

	private boolean isSpaceCharPresent(PDFCharacter lastChar,PDFCharacter character) {

		for (PDFCharacter space : spaceCharacters) {
			if(space.getRectangle().getPage()==lastChar.getRectangle().getPage() && space.getRectangle().getPage()==character.getRectangle().getPage()
					&&(space.getRectangle().getY()==lastChar.getRectangle().getY() && space.getRectangle().getY()==character.getRectangle().getY())
					&& space.getRectangle().getX()>=lastChar.getRectangle().getX2() && space.getRectangle().getX2()<=character.getRectangle().getX()){

				return true;
			}
		}

		return false;
	}
	public List<PDFWord> getOutcome() {
		return words;
	}

	public static void main(String[] args) {

		System.out.println(isWordContainValidColon("qwe6:7"));


	}

}
