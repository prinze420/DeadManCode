package com.pdf.parser.base.strategy;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.utils.CommonOperations;

public class SimpleFooterStrategy implements Strategy<Float> {
	
	float footerY = -1;
	List<StructureGroup> group;
	
	static List<String> starters = new ArrayList<String>();
	static List<String> patterns = new ArrayList<String>();
	static{
		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/footer-start.list"));
			String line = "";
			while((line = reader.readLine()) != null){
				starters.add(line.trim());
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/footer-pattern.list"));
			
			String line = "";
			while((line = reader.readLine()) != null)
				patterns.add(CommonOperations.processDataType(line.trim().toLowerCase()));
			
			reader.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public SimpleFooterStrategy(List<StructureGroup> group) {
		this.group = group;
	}
	
	@Override
	public void apply() {
		for(StructureGroup g: group){
			for(BasicStructure s:g.getBasicStructures()){
				
				//Check for starters
				for(String start : starters){
					
					if(s.getStringRepresentation().trim().startsWith("file"))
						System.out.println("debug");
					
					if(s.getStringRepresentation().trim().startsWith(start)){
						footerY = s.getRectangle().getY2();//Mark top of the seg as footer start
						return;
					}
				}
				
				//Check for footer patterns
				for(String p : patterns){
					if(s.getStringRepresentation().trim().matches(p)){
						footerY = s.getRectangle().getY2();//Mark top of the seg as footer start
						return;
					}
				}
			}
		}
	}

	@Override
	public Float getOutcome() {
		return footerY;
	}
	
	public static void removeFooters(Map<Integer, List<StructureGroup>> groups){
		for(List<StructureGroup> sg : groups.values()){
			
			SimpleFooterStrategy sf = new SimpleFooterStrategy(sg);
			sf.apply();
			float finalY = sf.getOutcome();
			
			if(finalY==-1)
				continue;
			
			Iterator<StructureGroup> it = sg.iterator();
			while(it.hasNext()){
				StructureGroup s = it.next();
				if(s.getY() > finalY){
					it.remove();
					System.out.println("Removed Footer: "+s.toString());
				}
			}
		}
	}
}
