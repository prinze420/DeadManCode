package com.pdf.parser.base.strategy;


import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.utils.CommonOperations;

public class PDFFooterDetectorStrategy  implements Strategy<Map<Integer,List<BasicStructure>>>  {

	/**
	 * We are planning to detect Footer based on the following strategies:<br>
	 * 	@Logic:- 1.Repetition of text at a similar location i.e. generic Similarity Based Footer Detection.	<br>
	 * 			 2.Predefined pattern Based Footer Detection <br>
	 * 	 		 3.Boundary Based Footer Detection <br>	
	 * @author BB0e1165									
	 * */
	private static ResourceBundle HF_Parameters_config;//,config;
	//boolean statis intermediateWrite=false;
	static{
		try {
			//	config = ResourceBundle.getBundle("ignore_structure_patterns",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

			HF_Parameters_config=ResourceBundle.getBundle("HF_Parameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private  Map<Integer, List<BasicStructure>> pageWiseSegs;
	private  Map<Integer, List<BasicStructure>> pageWiseFootersList;
	private  Map<Integer, List<BasicStructure>> pageWiseFooters;
	private  Map<Integer, DPRectangle> pageSizes=new TreeMap<Integer, DPRectangle>();


	private float heightThreshold = Float.valueOf(HF_Parameters_config.getString("footerHeightThreshold"));
	private int editDistance = Integer.valueOf(HF_Parameters_config.getString("allowedEditDistance"));
	private float footerPagesFactor = Float.valueOf(HF_Parameters_config.getString("footerPagesFactor"));
	private List<String>patterns=new ArrayList<String>();

	private List<String>f_InclusionList= Arrays.asList(HF_Parameters_config.getString("f_Inclusion").split(","));
	private List<String>f_ExclusionList= Arrays.asList(HF_Parameters_config.getString("f_Exclusion").split(","));
	private int f_number_of_lines=Integer.valueOf(HF_Parameters_config.getString("f_number_of_lines"));
	private List<String>f_StartKeywordList= Arrays.asList(HF_Parameters_config.getString("f_StartKeywordList").split(","));



	static boolean intermediateWrite=false;
	private  List<Integer> pages;
	
	public PDFFooterDetectorStrategy(Map<Integer, List<BasicStructure>> segmentsAftrHeaderRemoval,Map<Integer, DPRectangle> pageSizes, List<Integer> pages){
		pageWiseSegs = segmentsAftrHeaderRemoval;
		pageWiseFootersList = new HashMap<Integer,List<BasicStructure>>();
		pageWiseFooters=new TreeMap<Integer, List<BasicStructure>>();
		this.pages=pages;
		for (Integer k : pageWiseSegs.keySet()) {
			pageWiseFootersList.put(k, new ArrayList<BasicStructure>());
		}
		
		this.pageSizes=pageSizes;

		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/footer-pattern.list"));
			String line = "";

			while((line = reader.readLine()) != null){
				//String pt=patternConvertor(Commons.processDataType(line.trim().toLowerCase()));
				patterns.add(CommonOperations.processDataType(line.trim().toLowerCase()));
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-FooterDetectorStrategy apply 		<br>
	 * 	@Purpose:-	Create Footers	 	<br>
	 * 	@Logic:-apply generic Similarity Based Footer Detection :decide header area of page and check frequency of paragraphs on multiple pages which are repeated. consider it as header.			<br>
	 * 			apply pattern Based Footer Detection <br>
	 * 	 		apply Boundary Based Footer Detection <br>										
	 * */
	@Override
	public void apply() {

		//**Find similar segments on pages that can be termed footer and be removed
		if(HF_Parameters_config.getString("similarityBased_HFDetection").equalsIgnoreCase("true")){
			genericSimilarityBasedFooterDetection(heightThreshold,editDistance,footerPagesFactor);
		}

		if(HF_Parameters_config.getString("patternBased_HFDetection").equalsIgnoreCase("true")){
			patternBasedFooterDetection(patterns , heightThreshold, editDistance, footerPagesFactor);
		}

		if(HF_Parameters_config.getString("boundaryBased_HFDetection").equalsIgnoreCase("true")){
			genericBoundaryBasedFooterDetection();
		}

		if(HF_Parameters_config.getString("numOfLineBased_HFDetection").equalsIgnoreCase("true")){
			numOfLineBased_HFDetection(f_number_of_lines);
		}

		if(HF_Parameters_config.getString("includeKeywordsBased_HFDetection").equalsIgnoreCase("true")){
			InclusionKeywordsBased_HFDetection(f_InclusionList);
		}

		if(HF_Parameters_config.getString("startEndKeywordBased_HFDetection").equalsIgnoreCase("true")){
			startEndKeywordBased_HFDetection(f_StartKeywordList);
		}
		//must be do at end: remove detected footer according to f_ExclusionList
		if(HF_Parameters_config.getString("excludeKeywordbased_HFDetection").equalsIgnoreCase("true")){
			ExclusionKeywordbased_HFDetection(f_ExclusionList);
		}

		createFootersAndRemoveParas(pageWiseFootersList);

	}

	private void createFootersAndRemoveParas(Map<Integer, List<BasicStructure>> pageWiseFootersList) {

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure> tempPageFooters=new ArrayList<BasicStructure>();

			List<BasicStructure> footerParas = pageWiseFootersList.get(keyPage);
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next(); 
				String text = para.getStringRepresentation();
				/*if(text.contains("MDL Fact Sheet - Bianchini")){
					System.out.println("");
				}*/
				if(isPresentInFooterParas(para,footerParas)){
					//Footer f=new Footer( para.getRectangle(), para.getStringRepresentation(),-1, StructureType.FOOTER);
				//	tempPageFooters.add(f);
					paraIterator.remove();
				}
			}
			pageWiseFooters.put(keyPage, tempPageFooters);
		}
		
		/*for (Integer p : pageWiseSegs.keySet()) {
			System.out.println("--------------------");
			for (BasicStructure string : pageWiseSegs.get(p)) {
				System.out.println(string.getStringRepresentation());
			}
		}*/
	}

	private boolean isPresentInFooterParas(BasicStructure para,List<BasicStructure> footerParas) {

		for (BasicStructure paragraph : footerParas) {
			if(para.equals(paragraph)){
				return true;
			}
		}
		return false;
	}

	private void startEndKeywordBased_HFDetection(List<String> f_StartKeywordList) {


		for(Integer keyPage:pageWiseSegs.keySet()){
			//float pageHeight=(float) pageSizes.get(keyPage).getHeight();
			//float pageFHeight=pageHeight*heightThreshold;
			//float pageFooterHeight=(pageHeight-(pageFHeight));

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>();//pageWiseFooters.get(keyPage);
			float startY=getY_StartKeywordOfFooter(f_StartKeywordList,paraElements);

			if(startY==0)
				continue;
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() >=startY)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempFooter.add(para);
					//paraIterator.remove();
					//pageWiseFooters.put(keyPage, tempFooter);

				}
			}
			//add in footer HM
			if(pageWiseFootersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseFootersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseFootersList.put(keyPage, lst);
			}else{
				pageWiseFootersList.put(keyPage, tempFooter);
			}
		}

	}

	private float getY_StartKeywordOfFooter(List<String> f_StartKeywordList2,List<BasicStructure> paraElements) {

		float startY =0;// paraElements.get(paraElements.size()-1).getRectangle().getY()+2;//initially footr y= last element y+2

		for (int i= paraElements.size()-1; i >=0; i--) {
			String segStr = paraElements.get(i).getStringRepresentation();
			for ( String start : f_StartKeywordList2) {
				if(segStr.equalsIgnoreCase(start)){
					startY=paraElements.get(i).getRectangle().getY2();
				}
			}
		}
		return startY;

	}


	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-numOfLine based footer detection 		<br>
	 * 	@param 	:- int f_number_of_lines; 		<br>
	 * 	@return :-	Map(Page,List(footer)) pageWisefooters;		<br>
	 * 	@Purpose:-	detect and Create for  Headers	 	<br>
	 * 	@Logic:-detect segments  who's position is inside of the given number of lines from bottom <br>
	 * 											
	 * */
	//It removes detected footers if it match with anyone in exclude list and again add in original page Para map
	private void ExclusionKeywordbased_HFDetection(List<String> excludeAsfooter) {



		for(Integer keyPage:pageWiseFootersList.keySet()){
			//			float pageHeight=(float) pageSizes.get(keyPage).getHeight();
			//			float pageFHeight=pageHeight*heightThreshold;
			//			float pageFooterHeight=(pageHeight-(pageFHeight));

			List<BasicStructure> paraElements=pageWiseFootersList.get(keyPage);
			Iterator<BasicStructure> ftrIterator = paraElements.iterator();
			List<BasicStructure>pageParas=pageWiseSegs.get(keyPage); 

			while(ftrIterator.hasNext()){
				BasicStructure para=ftrIterator.next();
				for (String exclude : excludeAsfooter) {
					if(para.getStringRepresentation().trim().equalsIgnoreCase(exclude) )
					{
						if(!pageParas.contains(para))
							pageParas.add(para);
						//	ftrIterator.remove();
					}
				}
			}
			pageWiseSegs.put(keyPage, pageParas);

		}	



	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-Inclusion Keywords based footers detection 		<br>
	 * 	@param 	:- List<String> includeAsfooter; 		<br>
	 * 	@return :-	Map(Page,List(footers)) pageWisefooters;		<br>
	 * 	@Purpose:-	detect and Create  Headers	 	<br>
	 * 	@Logic:-detect segments  who's perfectly matched with paragraph text consider it as footers <br>
	 * 											
	 * */
	private void InclusionKeywordsBased_HFDetection(List<String> includeAsfooter) {


		for(Integer keyPage:pageWiseSegs.keySet()){

			//			float pageHeight=(float) pageSizes.get(keyPage).getHeight();
			//			float pageFHeight=pageHeight*heightThreshold;
			//			float pageFooterHeight=(pageHeight-(pageFHeight));

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>();//pageWiseFooters.get(keyPage);

			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();
				for (String include : includeAsfooter) {
					if(para.getStringRepresentation().trim().equalsIgnoreCase(include) )
					{
						tempFooter.add(para);
						//paraIterator.remove();
					}
				}
			}
			//add in footer HM
			if(pageWiseFootersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseFootersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseFootersList.put(keyPage, lst);
			}else{
				pageWiseFootersList.put(keyPage, tempFooter);
			}
		}	

	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-numOfLine based footer detection 		<br>
	 * 	@param 	:- int f_number_of_lines; 		<br>
	 * 	@return :-	Map(Page,List(footer)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	detect and Create Footers	 	<br>
	 * 	@Logic:-detect segments  who's position is below or equal the given number of lines from bottom of page <br>
	 * 											
	 * */
	private void numOfLineBased_HFDetection(int f_number_of_lines) {


		for(Integer keyPage:pageWiseSegs.keySet()){

			//			float pageHeight=(float) pageSizes.get(keyPage).getHeight();
			//			float pageFHeight=pageHeight*heightThreshold;
			//			float pageFooterHeight=(pageHeight-(pageFHeight));

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>();//pageWiseFooters.get(keyPage);
			float noOfLinesY=getY_No_of_lines(f_number_of_lines,paraElements);

			if(noOfLinesY==0)
				continue;
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() >=noOfLinesY)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempFooter.add(para);
					//paraIterator.remove();
					//pageWiseFooters.put(keyPage, tempFooter);

				}
			}
			//add in footer HM
			if(pageWiseFootersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseFootersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseFootersList.put(keyPage, lst);
			}else{
				pageWiseFootersList.put(keyPage, tempFooter);
			}
		}

	}


	private float getY_No_of_lines(int f_number_of_lines2,List<BasicStructure> paraElements) {

		int cnt=0;
		float linesTopY =0;// paraElements.get(paraElements.size()-1).getRectangle().getY()+2;//initially footr y= last element y+2

		if(f_number_of_lines2==0){
			return linesTopY;
		}
		if(paraElements.size()==1){
			linesTopY=paraElements.get(0).getRectangle().getY2();
			return linesTopY;
		}
		//fing highest Y Seg 
		int highestySegNo=1;;
		for (int i= paraElements.size()-1; i >=0; i--) {
			if(paraElements.get(i).getRectangle().getY() > paraElements.get(highestySegNo).getRectangle().getY()){
				highestySegNo=i;
			}
		}
		System.out.println("highestySegNo :"+paraElements.get(highestySegNo));


		for (int i= highestySegNo; i >=1; i--) {
			BasicStructure seg1 = paraElements.get(i);
			BasicStructure segPrev = paraElements.get(i-1);
			float diff=Math.abs(seg1.getRectangle().getY()-segPrev.getRectangle().getY());
			if(diff>100)continue;
			if(diff>2){//(seg1.getRectangle().getHeight())){
				cnt++;
				if(cnt==f_number_of_lines2){
					linesTopY=seg1.getRectangle().getY2();
					System.out.println("no lins top element:"+seg1);
					break;
				}
			}
		}

		return linesTopY;
	}


	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-GenericSimilarity based footer detection 		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)), float, int, float; 		<br>
	 * 	@return :-	Map(Page,List(footer)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	Create Footers	 	<br>
	 * 	@Logic:-decide footer area of page and detect paragraphs  who's repeated in same region of every page. <br>
	 * 			if its occurrence is > threshold page size then consider it as Footer.			<br>
	 * 											
	 * */

	public   Map<Integer, List<BasicStructure>> genericSimilarityBasedFooterDetection( float heightThreshold, int editDistance, float footerPagesFactor){
		Map<BasicStructure,Integer> paraFreq = new HashMap<BasicStructure,Integer>();
		Map<String,Integer> stringBasedParaFreq = new HashMap<String,Integer>();

		if(pageWiseSegs.keySet().size()<=3){
			return pageWiseFootersList;
		}

		//if(intermediateWrite)IntermediateResultWriter.writeContent("\n\n ## now we calculate here Frequency based footer on every page (e.g. page 1 of 10)");
		//Detect paragraphs  who's repeated in Footer region of every page

		//		for(Integer pg1:pageWiseParas.keySet())
		//		{


		for(int pg1=pages.get(0); pg1 < pages.get(pages.size()-1);pg1++ ){

			if(!pageSizes.containsKey(pg1)){
				continue;
			}

			float pageHeight=(float) pageSizes.get(pg1).getHeight();

			if(!pageWiseSegs.containsKey(pg1))continue;

			List<BasicStructure> elList=pageWiseSegs.get(pg1);
			if(elList==null||elList.isEmpty())
				continue;
			float pageFHeight=pageHeight*heightThreshold;
			float pageFooterHeight=(pageHeight-(pageFHeight/*/2*/));
			for(BasicStructure el:elList)
			{
				if(el instanceof BasicStructure && el.getRectangle().getY() > pageFooterHeight)
				{
					if(paraFreq.containsKey(el))
					{
						paraFreq.put(el, paraFreq.get(el)+1);
					}
					else
					{
						if(paraFreq.size()<1)
						{
							paraFreq.put(el, 1);
							continue;
						}
						boolean addFlag=false;
						for(BasicStructure tempEl:paraFreq.keySet())
						{
							BasicStructure p1=(BasicStructure)tempEl;
							BasicStructure p2=(BasicStructure)el;
							String s1 =p1.getStringRepresentation().trim().toLowerCase(); 
							String s2 =p2.getStringRepresentation().trim().toLowerCase();
							if(s1.length()>editDistance && s2.length()> editDistance && 
									StringUtils.getLevenshteinDistance(s1, s2) <= editDistance)
							{
								paraFreq.put(tempEl, (paraFreq.get(tempEl)+1));
								addFlag=true;
								break;
							}
						}
						if(!addFlag)
						{
							paraFreq.put(el, 1);
						}
					}

					//-------------------------
				}
			}
		}
		/*System.out.println("--------------------repeated Strucrure-------------------");
		for (BasicStructure pk : paraFreq.keySet()) {
			System.out.println(pk.getStringRepresentation()+" \t::count:"+paraFreq.get(pk));
		}
		System.out.println("-----------------------------------------------------------");
*/
		List<BasicStructure>repeatedStr_OddEven=new ArrayList<BasicStructure>();
		repeatedStr_OddEven=getOddEvenList(paraFreq,heightThreshold);
	
		//			create pagewise footer
		for(Integer pg1:pageWiseSegs.keySet())
		{
			List<BasicStructure> elList=pageWiseSegs.get(pg1);
			Iterator<BasicStructure> paraIterator = elList.iterator();

			float pageHeight=(float) pageSizes.get(pg1).getHeight();
			float pageFHeight=pageHeight*heightThreshold;
			float pageFooterHeight=(pageHeight-(pageFHeight));
			int pageAllowedFooterNumber=(int) (pageWiseSegs.keySet().size()*footerPagesFactor);
			if(pageAllowedFooterNumber<=1){
				continue;
			}
			List<BasicStructure> tempFooter=new ArrayList<BasicStructure>();
			while(paraIterator.hasNext()){
				BasicStructure el=paraIterator.next();
				//				if(el instanceof PDFSegment){ //page number segment
				//					if(((PDFSegment)el).getWords().get(0).isPageNum())
				//						tempFooter.add(el);	
				//				}
				
				if(el.getRectangle().getY() > pageFooterHeight && el instanceof BasicStructure)
				{
					boolean addedFooter=false;
					for(BasicStructure tempEl : paraFreq.keySet())
					{
						BasicStructure p1=(BasicStructure)tempEl;
						BasicStructure p2=(BasicStructure)el;
						String s1 =p1.getStringRepresentation().trim().toLowerCase(); 
						String s2 =p2.getStringRepresentation().trim().toLowerCase();
//						System.out.println("edt Dist: "+StringUtils.getLevenshteinDistance(s1, s2));
//						System.out.println("edt Dist: "+StringUtils.getLevenshteinDistance(s2, s1));
						if(s1.length()>editDistance && s2.length()> editDistance && 
								StringUtils.getLevenshteinDistance(s1, s2) <= editDistance)
						{
							int freq=paraFreq.get(tempEl);
							//Similarity according to oddEven count
							boolean oddEvenFlag=false;
							for (BasicStructure tmp : repeatedStr_OddEven) {
								if(tmp.getStringRepresentation().equals(tempEl.getStringRepresentation())){
									oddEvenFlag=true;
									break;
								}
							}

							if(freq>=pageAllowedFooterNumber||oddEvenFlag)
							{
								//	BasicStructure  hdr = new BasicStructure(p2.getId(),p2.getX(), p2.getY(), p2.getWidth(), p2.getHeight(),p2.getText());
								tempFooter.add(p2);
								//paraIterator.remove();
								addedFooter=true;
							}
						}
						if(addedFooter)
							break;
					}
				}
			}
			pageWiseFootersList.put(pg1, tempFooter);
		}		
		return pageWiseFootersList;
	}

	private  List<BasicStructure> getOddEvenList(Map<BasicStructure, Integer> paraFreq,float heightThreshold) {

		List<BasicStructure>temp=new ArrayList<BasicStructure>();
		if(pageWiseSegs.size()<=4)
			return temp;
		for (BasicStructure st : paraFreq.keySet()) {
			if(pageWiseSegs.size()>12){
				if(paraFreq.get(st)>=(pageWiseSegs.size()-3)/2){ //occurences of that structure is atleast nearest of half					temp.add(st);
				}
			}
			else{
				if(paraFreq.get(st)>=(pageWiseSegs.size()-1)/2){
					temp.add(st);
				}	
			}
		}
			//validate is it on odd and even pages??
		List<BasicStructure>repeatedStr_OddEven=new ArrayList<BasicStructure>();
		
		if(temp.size()<2){ //odd even criteria: ateast two 
			return repeatedStr_OddEven;
		}
	
		for (BasicStructure str : temp) 
		{
			int oddCounter=0;
			int evenCounter=0;
			int sequenceCounter=0;
			int prevePageNo=-1;
			
			for(Integer pg1:pageWiseSegs.keySet())
			{ 
				List<BasicStructure> elList=pageWiseSegs.get(pg1);

				float pageHeight=(float) pageSizes.get(pg1).getHeight();
				float pageFHeight=pageHeight*heightThreshold;
				float pageFooterHeight=(pageHeight-(pageFHeight));


				for(BasicStructure el:elList)
				{
					if(el instanceof BasicStructure && el.getRectangle().getY()>pageFooterHeight && el.getStringRepresentation().equals(str.getStringRepresentation()))
					{
						if((el.getRectangle().getPage()%2)==0){
							evenCounter++;break;
						}else{
							oddCounter++;break;
						}
					}
				}
				//for sequenceCounter
				for(BasicStructure el:elList)
				{
					if(el instanceof BasicStructure 
							&& el.getRectangle().getY()>pageFooterHeight 
							&& el.getStringRepresentation().equals(str.getStringRepresentation())
							&& CommonOperations.isOverlapOnY(el,str)//el.getRectangle().getY()==str.getRectangle().getY()
							)
					{
						if(prevePageNo==-1){
							prevePageNo=el.getRectangle().getPage();
							sequenceCounter++;
							break;
						}else
							if(el.getRectangle().getPage()-prevePageNo==1){
								prevePageNo=el.getRectangle().getPage();
								sequenceCounter++;
								break;
							}
					}
				}

			}
			if(pageWiseSegs.size()>12
				&&(evenCounter>=(pageWiseSegs.size()-3)/2)||(oddCounter>=(pageWiseSegs.size()-3)/2)){
					repeatedStr_OddEven.add(str);
				
			}else if((evenCounter>=(pageWiseSegs.size()-1)/2)||(oddCounter>=(pageWiseSegs.size()-1)/2)){
					repeatedStr_OddEven.add(str);
				
			}else if(sequenceCounter > 5){ // seg is continues and at same y on atleast 5 sequential pages // consider it as footer
				repeatedStr_OddEven.add(str);
			}
			
		}
		// seg is continues and at same y on atleast 5 pages // consider it as footer


		return repeatedStr_OddEven;
	}
	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-Pattern based Footer detection  		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)),List(String), float, int, float; 		<br>
	 * 	@return :-	Map(Page,List(Footer)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	Create Footers	 	<br>
	 * 	@Logic:-decide Footer area of page and check is paragraphs on this areas  match any pattern from patterns list ? <br>
	 * 			if match create Footer.	<br>
	 * 											
	 * */
	public  Map<Integer, List<BasicStructure>> patternBasedFooterDetection( List<String> patterns, float heightThreshold, int editDistance, float footerPagesFactor){


		//	int pageAllowedFooterNumber=(int) (pageWiseParas.keySet().size()*footerPagesFactor);
		if(pageWiseSegs.keySet().size()<=2){
			return pageWiseFootersList;
		}
		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> pageElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = pageElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>();

			float pageHeight=(float) pageSizes.get(keyPage).getHeight();
			float pageFooterHeight=pageHeight-(pageHeight*heightThreshold);
			int startEndCount=0;
			seg:
				while(paraIterator.hasNext()){
					BasicStructure para=paraIterator.next();
					startEndCount++;
					if(para.getRectangle().getY() > pageFooterHeight){
						boolean	pageNumFlag=false;
						/*if(para instanceof PDFWord){
							pageNumFlag= ((PDFWord)para).isPageNum();
						}else if(para instanceof PDFSegment){
							pageNumFlag = ((PDFSegment)para).isPageNum();
						}*/
						if(pageNumFlag){
							tempFooter.add(para);
							continue ;
						}

						for(String pattern : patterns){
							if(para.getStringRepresentation().toLowerCase().trim().matches(pattern)){
								tempFooter.add(para);
								//paraIterator.remove();
								continue seg;
							}
						}

						if(para.getStringRepresentation().trim().matches("[0-9]{1,3}")){//&& !tempFooter.contains(para)){
							//can also check  nearest  segment on same y if > threshold distance

							//int count=onNextPagesDetection(para,keyPage);
							//boolean textPresentFlag=isAnyTextOnSameY(para,paraElements);

							//if(!textPresentFlag){			
							tempFooter.add(para);
						}
					}else if((pageElements.size()>2)&&(startEndCount>(pageElements.size()-5))){

						if(para.getStringRepresentation().trim().matches("[0-9]{1,3}")){//&& !tempFooter.contains(para)){
							//							boolean isAnyOtherText = isAnyOtherText(para,pageElements);
							//							if(!isAnyOtherText)
							tempFooter.add(para);
						}
					}
				}

			//add in footer HM
			if(pageWiseFootersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseFootersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseFootersList.put(keyPage, lst);
			}else{
				pageWiseFootersList.put(keyPage, tempFooter);
			}
		}
		return pageWiseFootersList;
	}

	private  boolean isAnyOtherText(BasicStructure seg,List<BasicStructure> pageElements) {

		if(pageElements==null || pageElements.isEmpty()){
			return false;
		}
		for (BasicStructure s : pageElements) {
			if(!s.equals(seg) && CommonOperations.isOverlapOnY(s, seg)){
				return true;
			}
		}
		return false;
	}



	private  int onNextPagesDetection(BasicStructure seg,int pageNo) {

		int cnt=0;
		//		List<Integer> pageNumSeqList=new ArrayList<Integer>();
		//		pageNumSeqList.add(Integer.parseInt(para.getStringRepresentation().trim()));
		for(Integer i:pageWiseSegs.keySet()){
			List<BasicStructure> pageParas = pageWiseSegs.containsKey(i) ? pageWiseSegs.get(i) : new ArrayList<BasicStructure>();
			if(pageParas==null || pageParas.isEmpty()){
				continue;
			}

			for (BasicStructure s : pageParas) {
				float diff=Math.abs(seg.getRectangle().getY()-s.getRectangle().getY());
				if(diff<2){//same y

					if(seg.getStringRepresentation().matches("[0-9]{1,3}")){
						//						int nm = Integer.parseInt(para.getStringRepresentation().trim());
						//						if(pageNumSeqList.get(pageNumSeqList.size()-1)==(nm-1)){
						//							pageNumSeqList.add(nm);
						cnt++;
						break;
						//						}
					}
				}

			}
		}
		return cnt;
	}


	/**
		/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-boundary based Footer detection  		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)) ,Map(Page,List(Footer)) ; 		<br>
	 * 	@return :-	Map(Page,List(Footer)) ;		<br>
	 * 	@Purpose:-	 Paragraphs which are below side of boundary footer	Create as Footer. 	<br>
	 * 	@Logic:-detect boundary Footer/s through pattern based or generic similarity based then catch lowest y from this Footer/s  <br>
	 * 			paragraphs which are below this Footer_paragraph are also Footer so need to converts it in Footer. 			<br>
	 * 											
	 * */
	public  Map<Integer, List<BasicStructure>> genericBoundaryBasedFooterDetection(){


		if(pageWiseSegs.keySet().size()<=2){
			return pageWiseFootersList;
		}

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>(); //=pageWiseFooters.get(keyPage);
			float lowest=getLowestYofFooter(pageWiseFootersList.get(keyPage));
			if(lowest==0)
				continue;
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() >=lowest)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempFooter.add(para);
					//paraIterator.remove();
					//pageWiseFooters.put(keyPage, tempFooter);

				}
			}
			if(pageWiseFootersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseFootersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseFootersList.put(keyPage, lst);
			}else{
				pageWiseFootersList.put(keyPage, tempFooter);
			}
		}
		return pageWiseFootersList;
	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-getLowestYofFooter  		<br>
	 * 	@param 	:-	List(Footer); 		<br>
	 * 	@return :-	float;		<br>
	 * 	@Purpose:-	Catch minimum lowest y of created Footer to detect below of its as also Footer<br>
	 *											
	 * */
	public  float getLowestYofFooter(List<BasicStructure> tempFooter){
		if(tempFooter==null || tempFooter.size()<=0){
			return 0 ;
		}
		float lowest=tempFooter.get(0).getRectangle().getY();
		BasicStructure lowHeader = null ;
		for (BasicStructure header : tempFooter) {
			if(header.getRectangle().getY2()<lowest){
				lowHeader=header;
				lowest=header.getRectangle().getY2();
			}
		}
		//if(lowHeader!=null)
		
		return lowest;

	}


	public Map<Integer,List<BasicStructure>> getOutcome() {
		return pageWiseFootersList;
	}
	
	public Map<Integer, List<PDFSegment>> getRemainingPageWiseSegs(){

		//		return pageWiseParas;

		Map<Integer, List<PDFSegment>>temp=new  HashMap<Integer, List<PDFSegment>>();
		for (Integer i : pageWiseSegs.keySet()) {
			List<BasicStructure> st = pageWiseSegs.get(i);
			List<PDFSegment>lst=new ArrayList<PDFSegment>();
			for (BasicStructure b : st) {
				lst.add((PDFSegment)b);
			}
			temp.put(i,lst);
		}
		return temp;
	}


	public static String patternConvertor(String pattern){


		String regex=pattern.toLowerCase();

		String numPattern ="\\\\d";//"[0-9,.]";//"(\\d{1,3}[,.]?)(\\d{1,3})*(.\\d*)";// "[0-9,.]";//"\\\\d";
		String spacePat="\\\\s";
		String charPattern="[A-Za-z]";
		String allPattern=".*";

		if(regex.toLowerCase().contains("num")){	
			regex=regex.replaceAll("num", numPattern);
		}

		if(regex.toLowerCase().contains("char")){
			regex=regex.replaceAll("char", charPattern);
		}
		if(regex.toLowerCase().contains("space")){
			regex=regex.replaceAll("space", spacePat);
		}
		if(regex.toLowerCase().contains("all")){
			regex=regex.replaceAll("all", allPattern);
		}

		regex=regex.replaceAll("\\$", "")	;	

		return regex;
	}

	public static void main(String[] args) {/*

		//		D:\IntermediateResult\HeaderFooterDetection\Sample
		NLPTools.init();
		String filePath ="D:/IntermediateResult/HeaderFooterDetection/Sample/2015_annual_report1.pdf"; 
		File f=new File(filePath);
		String fName = f.getName().substring(0, f.getName().indexOf("."));

		String resultFileName ="D:/IntermediateResult/HeaderFooterDetection/"+fName+"_Result.txt"; 
		IntermediateResultWriter.init(resultFileName);
		IntermediateResultWriter.writeContent("Hierarchy Formation on:"+f.getName()+"\n");

		Map<Integer, Map<Integer, List<PDFSegment>>> pageAndMColWiseSegments=new TreeMap<Integer, Map<Integer, List<PDFSegment>>>();

		List<PDPage> pdfPages=new ArrayList<PDPage>();

		PDDocument pdf;
		try {
			IntermediateResultWriter.writeContent("\n Initial Pdf parsing process Start:");

			pdf = PDDocument.load(filePath);
			DefaultPDFParser parser = new DefaultPDFParser(filePath);
			parser.parse();

			pageSizes = parser.getPageSizes();
			pdfPages=parser.getPdfPages();
			pageNoPageMap=parser.getPageNoPageMap();
			pageWidthHeight=parser.getPageWidthHeight();

			//if pages is not given  must to add all pages in "pages" list.
			List<Integer> pages = null;
			if(pages==null||pages.isEmpty()){
				pages=new ArrayList<Integer>();
				for(int pg=0; pg<pdf.getDocumentCatalog().getAllPages().size(); pg++){
					pages.add(pg);
				}
			}
			IntermediateResultWriter.writeContent("\nInitial Pdf parsing process Done");
			IntermediateResultWriter.writeContent("\n TotalPages:"+pages.size());


			IntermediateResultWriter.writeContent("\n Pdf parser updating process Start:");

			DefaultPDFParserUpdate updateData = new DefaultPDFParserUpdate(pdf);
			Map<Integer,Map<Integer, List<BasicStructure>>>pageWise_WordMultiColumnMap=new HashMap<Integer, Map<Integer,List<BasicStructure>>>();

			for(int pg=0; pg < pdf.getDocumentCatalog().getAllPages().size(); pg++){

				if(pages!=null && !pages.contains(pg))
					continue;

				if(parser.getWords().get(pg)==null||parser.getWords().get(pg).isEmpty()){
					continue;
				}
				Map<Integer, List<PDFWord>> pwords = parser.getWords();

				PDPage page1 = pdfPages.get(pg);
				float pHeight = (float)pageSizes.get(pg).getHeight();
				updateData.apply(pg,parser,filePath);

				//create Table of each page.................

				if(updateData.getCharOutcome()!=null && updateData.getCharOutcome().size()>0){
					List<BasicStructure> words = updateData.getWordOutcome();

					Map<Integer, List<BasicStructure>>pageWiseWordMapttteemmpp=new HashMap<Integer, List<BasicStructure>>();

					RawPDFTableDecomposition tableFormation =new RawPDFTableDecomposition(updateData.getWordOutcome(),updateData.getVgapsUpdated(),updateData.getTableVgaps(),updateData.getPageVgaps(),pg,pHeight,(int)page1.getBleedBox().getLowerLeftX(),(int)page1.getBleedBox().getLowerLeftX()+(int)page1.getBleedBox().getWidth());
					tableFormation.apply();
					List<DPTable> pageTables = tableFormation.getOutcome();

					if(pageTables!=null)
						pageWiseTableMap.put(pg, new ArrayList<Structure>(pageTables));

					pageWiseCharMap.put(pg, updateData.getCharOutcome());
					pageWiseWordMap.put(pg, updateData.getWordOutcome());
				}
				else{
					pageWiseCharMap.put(pg, new ArrayList<BasicStructure>());
					pageWiseWordMap.put(pg, new ArrayList<BasicStructure>());
				}
				if(updateData.getVgapsUpdated()!=null){
					vgaps.put(pg,updateData.getVgapsUpdated());
				}else{
					vgaps.put(pg,new ArrayList<PDFVerticalGap>());
				}

				Map<Integer, List<BasicStructure>> wordMultiColumnMap = updateData.getWordMultiColumnMap();
				//List<BasicStructure>tableWors=getPageWiseTableWords(wordMultiColumnMap);
				//pageWiseTableWords.put(pg, tableWors);

				pageWise_WordMultiColumnMap.put(pg, wordMultiColumnMap);
			}
			IntermediateResultWriter.writeContent("\n Pdf parser updating process End");

			IntermediateResultWriter.writeContent("\n\n Pdf Page Number Identification process Start: ");

			PageNumberIdentification pni=new PageNumberIdentification(pageWiseWordMap,pages,pageSizes);
			pni.detectPageNo();
			//check word pageNumDeection are worke or not 
			boolean sysOutFlag=true;
			if(sysOutFlag)
				for(Integer pgNum :pages){
					List<BasicStructure> lst2 = pageWiseWordMap.get(pgNum);
					if(lst2==null)continue;
					for (BasicStructure basicStructure : lst2) {
						if(((PDFWord)basicStructure).isPageNum()){
							System.out.println("PageNum : "+basicStructure.getStringRepresentation());
						}
					}
				}
			IntermediateResultWriter.writeContent("\n"+pageWiseWordMap.toString());
			IntermediateResultWriter.writeContent("\n Pdf Page Number Identification process End ");


			//create Segments of 
			IntermediateResultWriter.writeContent("\n\n Pdf Page word grouping process (i.e. Segment Formation) Start:");

			if(sysOutFlag)System.out.println("**************************NewPDFSegmentFormationStrategy*********************************");

			for(Integer pgNum :pages){

				Map<Integer, List<BasicStructure>> wordMultiColumnMap = pageWise_WordMultiColumnMap.get(pgNum);

				if(wordMultiColumnMap==null){
					continue;
				}

				//				ArrayList<DPRectangle> columnRects = detectColumnsRectangle(wordMultiColumnMap);//column rectangle detection 
				//				pageWiseColumnRectangle.put(pgNum, columnRects);

				NewPDFSegmentFormationStrategy npsf = new NewPDFSegmentFormationStrategy(wordMultiColumnMap, pgNum,pageSizes.get(pgNum));
				npsf.apply();

				//Remove irrelevant segments

				Map<Integer, List<PDFSegment>> mColumnSegs = npsf.getOutcome();
				List<PDFSegment>temp=new ArrayList<PDFSegment>();

				for (Integer mColIndx : mColumnSegs.keySet()) {
					List<PDFSegment> colSegs = mColumnSegs.get(mColIndx);
					//					sort colSegs
					Collections.sort(colSegs, new Comparator<PDFSegment>() {
						public int compare(PDFSegment o1, PDFSegment o2) {
							return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
						}
					});

					Iterator<PDFSegment> segmentIterator = colSegs.iterator();
					while(segmentIterator.hasNext()){
						if(segmentIterator.next().getStringRepresentation().replaceAll(config.getString("segment"), "").trim().length()==0)
							segmentIterator.remove();
					}
					mColumnSegs.put(mColIndx, colSegs);//update with sequence
					temp.addAll(colSegs);
				}

				pageAndMColWiseSegments.put(pgNum, mColumnSegs);
				pageWiseSegments.put(pgNum, temp);
			}
			IntermediateResultWriter.writeContent("\n Pdf Page word grouping process End");

			pdf.close();
			//		remove headers
			IntermediateResultWriter.writeContent("\n\n Pdf Header detection process Start:");
			if(sysOutFlag)System.out.println("PDFHeaderDetectionStrategy");
			//		List<PDPage> PdfPages = getPdfPages();
			if(sysOutFlag)System.out.println("\n------------------- Headers ------------------------------");
			Map<Integer, List<BasicStructure>> SegsInBasicStru1 = ExtractionParser.castInBasicStructure(pageWiseSegments);

			PDFHeaderDetectionStrategy hds= new PDFHeaderDetectionStrategy(SegsInBasicStru1,pageSizes); //need to also remove from pageAndMColWiseSegments 
			hds.apply();
			Map<Integer, List<Header>> pageWiseHeaders = hds.getOutcome();
			if(sysOutFlag)System.out.println(pageWiseHeaders);
			IntermediateResultWriter.writeContent("\n "+pageWiseHeaders.toString());
			IntermediateResultWriter.writeContent("\n Pdf Header detection process End");

			Map<Integer, List<BasicStructure>> segmentsAftrHeaderRemoval = hds.getRemainingPageWiseParas();

			//		remove footers
			System.out.println("\n------------------- Footers ------------------------------");
			IntermediateResultWriter.writeContent("\n\n Pdf Footer detection process Start:");

			//Map<Integer, List<BasicStructure>> SegsInBasicStru = castInBasicStructure(segmentsAftrHeaderRemoval);
			if(sysOutFlag)System.out.println("PDFFooterDetectorStrategy");
			PDFFooterDetectorStrategy fds= new PDFFooterDetectorStrategy(segmentsAftrHeaderRemoval,pageSizes,pages);
			fds.apply();

			Map<Integer, List<BasicStructure>> pageWiseFooters = fds.getOutcome();
			if(sysOutFlag)System.out.println(pageWiseFooters);
			IntermediateResultWriter.writeContent("\n"+pageWiseFooters.toString());

		}catch (Exception e){
			e.printStackTrace();
		}

	 */}

}
