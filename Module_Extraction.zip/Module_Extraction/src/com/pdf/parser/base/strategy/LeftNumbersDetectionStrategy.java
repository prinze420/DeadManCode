package com.pdf.parser.base.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.utils.CommonOperations;

public class LeftNumbersDetectionStrategy implements Strategy<Map<Integer,List<PDFSegment>>>  {

	private static ResourceBundle HF_Parameters_config;//,config;
	static{
		try {
			HF_Parameters_config=ResourceBundle.getBundle("HF_Parameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private  Map<Integer, List<PDFSegment>> pageWiseSegs;
	private  Map<Integer, DPRectangle> pageSizes=new TreeMap<Integer, DPRectangle>();

	private float leftDistanceThreshold = Float.valueOf(HF_Parameters_config.getString("leftDistanceThreshold"));

	public LeftNumbersDetectionStrategy(Map<Integer, List<PDFSegment>> segmentsAftrFooterRemoval,Map<Integer, DPRectangle> pageSizes){
		this.pageWiseSegs = segmentsAftrFooterRemoval;
		this.pageSizes=pageSizes;
	}

	@Override
	public void apply() {
		Map<Integer, List<PDFSegment>> pageWiseLeftMargineData=new HashMap<Integer, List<PDFSegment>>();
		float laftMargin=0.5f;
		for (Integer pg : pageWiseSegs.keySet()) {
			DPRectangle pageRect = pageSizes.get(pg);
			laftMargin=pageRect.getWidth()*leftDistanceThreshold;
			List<PDFSegment> pageLeftMargineData=leftMargineNumbersDetection(pageWiseSegs.get(pg),laftMargin);
			if(pageLeftMargineData.size()>8){
				// TODO
				//do if vertical line is present on this page 
				//Additional rules: check max occurred x or x2 segs and keep only those:
				boolean overlapCount=false;
				boolean yGapMissmach=true;
				int cnt=1;
				for (PDFSegment s1 : pageLeftMargineData) {
					for (PDFSegment s2 : pageLeftMargineData) {
						if(s1!=s2 && CommonOperations.isOverlapOnX(s1, s2)){
							//System.out.println("");
							cnt++;
						}
					}
					break;
				}

				System.out.println("count "+cnt);
				if(cnt>=pageLeftMargineData.size()-1){
					//System.out.println("all in overlap");
					overlapCount=true;
				}

				// check y diff
				//then chek is y difference between all this are smae??
				float firstDiff = Math.abs(pageLeftMargineData.get(0).getRectangle().getY()-pageLeftMargineData.get(1).getRectangle().getY2());
				//System.out.println("firstDiff \t"+firstDiff);
				for (int i = 0; i < pageLeftMargineData.size()-1; i++) {
					float df = Math.abs(pageLeftMargineData.get(i).getRectangle().getY()-pageLeftMargineData.get(i+1).getRectangle().getY2());
					if(Math.abs(firstDiff-df) > 1){
						//	System.out.println("Not same diff\t"+df);
						yGapMissmach=false;
						break;
					}
				}
				if( overlapCount &&  yGapMissmach){
					pageWiseLeftMargineData.put(pg, pageLeftMargineData);
					System.out.println("pageLeftMargine Words: "+pg+"\t"+pageLeftMargineData);
				}
			}
		}
		
		if(pageWiseLeftMargineData.size()>0)
			removePageWiseLeftMargineData(pageWiseLeftMargineData);
	}

	public List<PDFSegment> leftMargineNumbersDetection(List<PDFSegment> list, float laftMargin){
		
		List<PDFSegment> pageLeftMargineData=new ArrayList<PDFSegment>();
		
		for (PDFSegment seg : list) {
			if(seg.getRectangle().getX2()<laftMargin && seg.getStringRepresentation().trim().matches("[0-9]{1,3}")){
				pageLeftMargineData.add(seg);
				
				if( pageLeftMargineData.size()>= 2 ){
					PDFSegment s2 = pageLeftMargineData.get(pageLeftMargineData.size()-1);
					PDFSegment s1 = pageLeftMargineData.get(pageLeftMargineData.size()-2);
							if(CommonOperations.isOverlapOnX(s2,s1)){
								if(laftMargin> s2.getRectangle().getX2()+10)
								{
									laftMargin=s2.getRectangle().getX2()+10;
								}
								if(laftMargin> s1.getRectangle().getX2()+10)
								{
									laftMargin=s1.getRectangle().getX2()+10;
								}
							}
				}
			}
		}

		return pageLeftMargineData;
	}
	private void removePageWiseLeftMargineData(Map<Integer, List<PDFSegment>> pageWiseLeftMargineData) {

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<PDFSegment> paraElements=pageWiseSegs.get(keyPage);
			Iterator<PDFSegment> paraIterator = paraElements.iterator();
			//List<BasicStructure> tempPageFooters=new ArrayList<BasicStructure>();
			if(!pageWiseLeftMargineData.containsKey(keyPage) || pageWiseLeftMargineData.get(keyPage)==null || pageWiseLeftMargineData.get(keyPage).isEmpty() ){
				continue;
			}
			List<PDFSegment> pageLeftMargineData = pageWiseLeftMargineData.get(keyPage);
			while(paraIterator.hasNext()){
				PDFSegment para=paraIterator.next(); 
				//String text = para.getStringRepresentation();
				if(isPresentInLeftMargineData(para,pageLeftMargineData)){
					//	tempPageFooters.add(f);

					paraIterator.remove();
				}
			}
			System.out.println(">>> Removed Page LeftMargineData \t"+pageLeftMargineData);
			//pageWiseFooters.put(keyPage, tempPageFooters);
		}
	}

	private boolean isPresentInLeftMargineData(BasicStructure para,List<PDFSegment> footerParas) {

		for (PDFSegment paragraph : footerParas) {
			if(para.equals(paragraph)){
				return true;
			}
		}
		return false;
	}

	@Override
	public Map<Integer, List<PDFSegment>> getOutcome() {
		// TODO Auto-generated method stub
		return pageWiseSegs;
	}
}
