package com.pdf.parser.base.strategy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.hslf.blip.Metafile.Header;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.utils.CommonOperations;

/**
 * We are planning to detect Header based on the following strategies:<br>
 * 	@Logic:- 1.Repetition of text at a similar location i.e. generic Similarity Based Header Detection.	<br>
 * 			 2.Predefined pattern Based Header Detection <br>
 * 	 		 3.Boundary Based Header Detection <br>	
 * @author BB0e1165									
 * */
public class PDFHeaderDetectionStrategy implements Strategy<Map<Integer,List<Header>>> {
	private static ResourceBundle HF_Parameters_config,config;
	static{
		try {
			config = ResourceBundle.getBundle("ignore-structure-patterns",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
			HF_Parameters_config=ResourceBundle.getBundle("HF_Parameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private float heightThreshold = Float.valueOf(HF_Parameters_config.getString("headerHeightThreshold"));
	private int editDistance = Integer.valueOf(HF_Parameters_config.getString("allowedEditDistance"));
	private float headerPagesFactor = Float.valueOf(HF_Parameters_config.getString("footerPagesFactor"));

	private  Map<Integer, List<BasicStructure>> pageWiseSegs;
	private  Map<Integer, List<BasicStructure>> pageWiseHeadersList;
	private  Map<Integer, List<Header>> pageWiseHeadersFinal;
	private  Map<Integer, DPRectangle> pageSizes=new TreeMap<Integer, DPRectangle>();
	private List<String>patterns=new ArrayList<String>();

	private List<String>h_InclusionList= Arrays.asList(HF_Parameters_config.getString("h_Inclusion").split(","));
	private List<String>h_ExclusionList= Arrays.asList(HF_Parameters_config.getString("h_Exclusion").split(","));
	private int h_number_of_lines=Integer.valueOf(HF_Parameters_config.getString("h_number_of_lines"));
	private List<String>h_EndKeywordList= Arrays.asList(HF_Parameters_config.getString("h_EndKeywordList").split(","));

	//static boolean intermediateWrite=false;

	public PDFHeaderDetectionStrategy(Map<Integer,List<BasicStructure>> SegsInBasicStru1,Map<Integer, DPRectangle>pageSizes){
		this.pageWiseSegs = SegsInBasicStru1; 
		pageWiseHeadersList = new HashMap<Integer,List<BasicStructure>>();
		pageWiseHeadersFinal=new TreeMap<Integer, List<Header>>();

		for (Integer k : pageWiseSegs.keySet()) {
			pageWiseHeadersList.put(k, new ArrayList<BasicStructure>());//create empty  Hashmap initially
		}

		this.pageSizes=pageSizes;
		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/footer-pattern.list"));
			String line = "";

			while((line = reader.readLine()) != null){
				//String pt=patternConvertor(Commons.processDataType(line.trim().toLowerCase()));
				patterns.add(CommonOperations.processDataType(line.trim().toLowerCase()));
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}


	}


	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-HeaderDetectionStrategy apply 		<br>
	 * 	@Purpose:-	Create Headers	 	<br>
	 * 	@Logic:-apply generic Similarity Based Header Detection :decide header area of page and detect paragraphs  who's repeated in header region of every page consider it as header.			<br>
	 * 			apply pattern Based Header Detection <br>
	 * 	 		apply Boundary Based Header Detection <br>										
	 * */
	@Override
	public void apply() {
		//**Find similar segments on pages that can be termed footer and be removed
		if(HF_Parameters_config.getString("similarityBased_HFDetection").equalsIgnoreCase("true")){
			genericSimilarityBasedHFDetection(heightThreshold,editDistance,headerPagesFactor);
		}

		if(HF_Parameters_config.getString("patternBased_HFDetection").equalsIgnoreCase("true")){
			patternBasedHFDetection(patterns, heightThreshold, editDistance, headerPagesFactor);
		}

		if(HF_Parameters_config.getString("boundaryBased_HFDetection").equalsIgnoreCase("true")){
			genericBoundaryBasedHFDetection();
		}

		if(HF_Parameters_config.getString("numOfLineBased_HFDetection").equalsIgnoreCase("true")){
			numOfLineBased_HFDetection(h_number_of_lines);
		}

		if(HF_Parameters_config.getString("includeKeywordsBased_HFDetection").equalsIgnoreCase("true")){
			inclusionKeywordsBased_HFDetection(h_InclusionList);
		}


		if(HF_Parameters_config.getString("startEndKeywordBased_HFDetection").equalsIgnoreCase("true")){
			startEndKeywordBased_HFDetection(h_EndKeywordList);
		}

		//must be do at end: remove detected headers according to h_ExclusionList

		if(HF_Parameters_config.getString("excludeKeywordbased_HFDetection").equalsIgnoreCase("true")){
			exclusionKeywordbased_HFDetection(h_ExclusionList);	
		}
		createHeaderAndRemoveParas(pageWiseHeadersList);
	}


	private void createHeaderAndRemoveParas(Map<Integer, List<BasicStructure>> pageWiseHeadersList) {

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<Header> tempPageHeader=new ArrayList<Header>();

			List<BasicStructure> headerParas = pageWiseHeadersList.get(keyPage);
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next(); 
				String text = para.getStringRepresentation();
				if(isPresentInHeaderParas(para,headerParas)){
					//Header h= new Header(para.getRectangle(), para.getStringRepresentation(),-1, StructureType.HEADER);
					//tempPageHeader.add(h);
					paraIterator.remove();
				}
			}
			pageWiseHeadersFinal.put(keyPage, tempPageHeader);

		}
	}
	private boolean isPresentInHeaderParas(BasicStructure para,List<BasicStructure> pageSegs) {

		for (BasicStructure paragraph : pageSegs) {
			if(para.equals(paragraph)){
				return true;
			}
		}
		return false;
	}
	private void startEndKeywordBased_HFDetection(List<String> h_EndKeywordList) {

		for(Integer keyPage:pageWiseSegs.keySet()){
			float pageHeight=(float) pageSizes.get(keyPage).getHeight(); 
			float pageHeaderHeight=pageHeight*heightThreshold;

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempHdr=new ArrayList<BasicStructure>();//pageWiseHeaders.get(keyPage);
			float endY=getY_EndKeywordOfHeader(h_EndKeywordList,paraElements);

			if(endY==0)
				continue;
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() <=endY)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempHdr.add(para);
					//paraIterator.remove();
					//pageWiseHeaders.put(keyPage, tempFooter);

				}
			}
			//add in footer HM
			if(pageWiseHeadersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseHeadersList.get(keyPage);
				for (BasicStructure pdfSegment : tempHdr) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseHeadersList.put(keyPage, lst);
			}else{
				pageWiseHeadersList.put(keyPage, tempHdr);
			}
		}

	}

	private float getY_EndKeywordOfHeader(List<String> f_StartKeywordList2,List<BasicStructure> paraElements) {

		float endY =0;// paraElements.get(paraElements.size()-1).getRectangle().getY()+2;//initially footr y= last element y+2

		for (int i = 0; i <  paraElements.size()-1; i++) {

			String segStr = paraElements.get(i).getStringRepresentation();
			for ( String start : f_StartKeywordList2) {
				if(segStr.equalsIgnoreCase(start)){
					endY=paraElements.get(i).getRectangle().getY();
				}
			}
		}
		return endY;

	}


	//It removes detected footers if it match with anyone in exclude list and again add in original page Para map
	private void exclusionKeywordbased_HFDetection(List<String> excludeAsHeader) {

		for(Integer keyPage:pageWiseHeadersList.keySet()){
			float pageHeight=(float) pageSizes.get(keyPage).getHeight(); 
			float pageHeaderHeight=pageHeight*heightThreshold;

			List<BasicStructure> paraElements=pageWiseHeadersList.get(keyPage);
			Iterator<BasicStructure> hdrIterator = paraElements.iterator();
			List<BasicStructure>pageParas=pageWiseSegs.get(keyPage); 

			while(hdrIterator.hasNext()){
				BasicStructure para=hdrIterator.next();
				for (String exclude : excludeAsHeader) {
					if(para.getStringRepresentation().trim().equalsIgnoreCase(exclude) )
					{
						if(!pageParas.contains(para))
							pageParas.add(para);
						hdrIterator.remove();
					}
				}
			}
			pageWiseSegs.put(keyPage, pageParas);

		}	

	}
	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-Inclusion Keywords based Headers detection 		<br>
	 * 	@param 	:- List<String> includeAsfooter; 		<br>
	 * 	@return :-	Map(Page,List(Headers)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	detect and Create  Headers	 	<br>
	 * 	@Logic:-detect segments  who's perfectly matched with paragraph text consider it as headers <br>
	 * 											
	 * */
	private void inclusionKeywordsBased_HFDetection(List<String> includeAsHeader) {


		for(Integer keyPage:pageWiseSegs.keySet()){
			float pageHeight=(float) pageSizes.get(keyPage).getHeight(); 
			float pageHeaderHeight=pageHeight*heightThreshold;

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempHeader=new ArrayList<BasicStructure>();//pageWiseHeaders.get(keyPage);

			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();
				for (String include : includeAsHeader) {
					if(para.getStringRepresentation().trim().equalsIgnoreCase(include) )
					{
						tempHeader.add(para);
						//paraIterator.remove();
					}
				}
			}
			//add in footer HM
			if(pageWiseHeadersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseHeadersList.get(keyPage);
				for (BasicStructure pdfSegment : tempHeader) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseHeadersList.put(keyPage, lst);
			}else{
				pageWiseHeadersList.put(keyPage, tempHeader);
			}
		}	

	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-numOfLine based Headers detection 		<br>
	 * 	@param 	:- int f_number_of_lines; 		<br>
	 * 	@return :-	Map(Page,List(Headers)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	detect and Create  Headers	 	<br>
	 * 	@Logic:-detect segments  who's position is inside of the given number of lines from top <br>
	 * 											
	 * */
	private void numOfLineBased_HFDetection(int h_number_of_lines) {
		//		Integer pg = pageSizes.keySet().iterator().next();

		if(pageWiseSegs.keySet().size()<=2){
			return ;
		}


		for(Integer keyPage:pageWiseSegs.keySet()){

			float pageHeight=(float) pageSizes.get(keyPage).getHeight(); 
			float pageHeaderHeight=pageHeight*heightThreshold;

			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempFooter=new ArrayList<BasicStructure>();//pageWiseHeaders.get(keyPage);
			float linesBottomY=getBottomY_lines(h_number_of_lines,paraElements);

			if(linesBottomY==0)
				continue;
			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() <=linesBottomY)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempFooter.add(para);
					//paraIterator.remove();
					//pageWiseHeaders.put(keyPage, tempFooter);

				}
			}
			//add in footer HM
			if(pageWiseHeadersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseHeadersList.get(keyPage);
				for (BasicStructure pdfSegment : tempFooter) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseHeadersList.put(keyPage, lst);
			}else{
				pageWiseHeadersList.put(keyPage, tempFooter);
			}
		}

	}


	private float getBottomY_lines(int f_number_of_lines2,List<BasicStructure> paraElements) {

		int cnt=0;
		float linesBottomY =0;// paraElements.get(paraElements.size()-1).getRectangle().getY()+2;//initially footr y= last element y+2

		for (int i=0; i <paraElements.size()-1; i++) {

			BasicStructure p1 = paraElements.get(i);
			BasicStructure p2 = paraElements.get(i+1);

			float yDiff=Math.abs(paraElements.get(i+1).getRectangle().getY2()-paraElements.get(i).getRectangle().getY());
			if(yDiff>2){
				cnt++;
				if(cnt==f_number_of_lines2){
					linesBottomY=paraElements.get(i).getRectangle().getY();
					System.out.println("no lins top element:"+paraElements.get(i));
					break;
				}
			}
		}

		return linesBottomY;
	}



	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-GenericSimilarity based Header detection 		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)), float, int, float; 		<br>
	 * 	@return :-	Map(Page,List(Header)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	Create Headers	 	<br>
	 * 	@Logic:-decide header area of page and Detect paragraphs  who's repeated in header region of every page. <br>
	 * 			if its occurrence is > threshold page size then consider it as header.			<br>
	 * 											
	 * */
	public   Map<Integer, List<BasicStructure>> genericSimilarityBasedHFDetection( float heightThreshold, int editDistance, float headerPagesFactor){
		//Map<Integer, List<BasicStructure>> pageWiseHeaders=new TreeMap<Integer, List<BasicStructure>>();
		Map<BasicStructure,Integer> paraFreq = new HashMap<BasicStructure,Integer>();
		Map<String,Integer> stringBasedParaFreq = new HashMap<String,Integer>();

		//Detect paragraphs  who's repeated in header region of every page || first 5 seg by default
		if(pageWiseSegs.keySet().size()<=3){
			return pageWiseHeadersList;
		}

		boolean intermediateWrite=false;
		int firstFewCounter=0;
		for(Integer pg1:pageWiseSegs.keySet())
		{
			if(!pageSizes.containsKey(pg1)){
				continue;
			}
			float pageHeight=(float) pageSizes.get(pg1).getHeight();
			List<BasicStructure> elList=pageWiseSegs.get(pg1);
			if(elList==null){
				continue;
			}

			float pageHeaderHeight=(pageHeight*heightThreshold);///1.3f;
			firstFewCounter=0;
			for(BasicStructure el:elList)
			{
				firstFewCounter++;
				if(el instanceof BasicStructure && (el.getRectangle().getY()< pageHeaderHeight || firstFewCounter<=5) )
				{
					if(paraFreq.containsKey(el))
					{
						paraFreq.put(el, paraFreq.get(el)+1);
					}
					else
					{
						if(paraFreq.size()<1)
						{
							paraFreq.put(el, 1);
							continue;
						}
						boolean addFlag=false;
						for(BasicStructure tempEl:paraFreq.keySet()) 
						{
							BasicStructure p1=(BasicStructure)tempEl;
							BasicStructure p2=(BasicStructure)el;
							String s1 =p1.getStringRepresentation().trim().toLowerCase(); 
							String s2 =p2.getStringRepresentation().trim().toLowerCase();
							if(s1.length()>editDistance && s2.length()> editDistance && 
									StringUtils.getLevenshteinDistance(s1, s2) <= editDistance)
							{
								paraFreq.put(tempEl, (paraFreq.get(tempEl)+1));
								addFlag=true;
								break;
							}
						}
						if(!addFlag)
						{
							paraFreq.put(el, 1);
						}
					}
				}
			}
		}
		/*System.out.println("--------------------repeated Strucrure-------------------");
		for (BasicStructure pk : paraFreq.keySet()) {
			System.out.println(pk.getStringRepresentation()+" "+paraFreq.get(pk));
		}
		System.out.println("-----------------------------------------------------------");
		 */
		List<BasicStructure>repeatedStr_OddEven=new ArrayList<BasicStructure>();
		repeatedStr_OddEven=getOddEvenList(paraFreq,heightThreshold);


		if(intermediateWrite)
			for (BasicStructure basicStructure : paraFreq.keySet()) {
				if(paraFreq.get(basicStructure)>1){
				}
			}

		for(Integer pg1:pageWiseSegs.keySet())
		{
			List<BasicStructure> elList=pageWiseSegs.get(pg1);
			Iterator<BasicStructure> paraIterator = elList.iterator();

			float pageHeight=(float) pageSizes.get(pg1).getHeight();
			float pageHeaderHeight=((pageHeight*heightThreshold));
			int pageAllowedHeaderNumber=(int) (pageWiseSegs.keySet().size()*headerPagesFactor);
			if(pageAllowedHeaderNumber<=1){
				continue;
			}
			List<BasicStructure> tempHeader=new ArrayList<BasicStructure>();
			firstFewCounter=0;
			while(paraIterator.hasNext()){
				firstFewCounter++;
				BasicStructure el=paraIterator.next();
				if(el instanceof BasicStructure &&(el.getRectangle().getY()<pageHeaderHeight ||firstFewCounter<5) )
				{
					boolean addedHeader=false;
					for(BasicStructure tempEl : paraFreq.keySet())
					{
						BasicStructure p1=(BasicStructure)tempEl;
						BasicStructure p2=(BasicStructure)el;
						String s1 =p1.getStringRepresentation().trim().toLowerCase(); 
						String s2 =p2.getStringRepresentation().trim().toLowerCase();
						if(s1.length()>editDistance && s2.length()> editDistance && 
								StringUtils.getLevenshteinDistance(s1, s2) <= editDistance)
						{
							int freq=paraFreq.get(tempEl);
							//Similarity according to oddEven count
							boolean oddEvenFlag=false;
							for (BasicStructure tmp : repeatedStr_OddEven) {
								if(Math.abs(tmp.getRectangle().getY()-tmp.getRectangle().getY()) < 1 && tmp.getStringRepresentation().equals(tempEl.getStringRepresentation())){
									oddEvenFlag=true;
									break;
								}
							}
							if(freq>=pageAllowedHeaderNumber||oddEvenFlag)
							{
								//BasicStructure  hdr = new BasicStructure(p2.getId(),p2.getX(), p2.getY(), p2.getWidth(), p2.getHeight(),p2.getText());
								tempHeader.add(tempEl);
								//	paraIterator.remove();
								addedHeader=true;
							}
						}
						if(addedHeader)
							break;
					}
				}
			}
			pageWiseHeadersList.put(pg1, tempHeader);
		}		
		return pageWiseHeadersList;
	}

	private  List<BasicStructure> getOddEvenList(Map<BasicStructure, Integer> paraFreq,float heightThreshold) {

		List<BasicStructure>temp=new ArrayList<BasicStructure>();
		if(pageWiseSegs.size()<=4)
			return temp;

		for (BasicStructure st : paraFreq.keySet()) {
			if(pageWiseSegs.size()>12){
				if(paraFreq.get(st)>=(pageWiseSegs.size()-3)/2){
					temp.add(st);
				}
			}
			else{
				if(paraFreq.get(st)>=(pageWiseSegs.size()-1)/2){
					temp.add(st);
				}	
			}
		}


		//validate is it on odd and even pages??
		List<BasicStructure>repeatedStr_OddEven=new ArrayList<BasicStructure>();
		for (BasicStructure str : temp) 
		{
			int oddCounter=0;
			int evenCounter=0;

			for(Integer pg1:pageWiseSegs.keySet())
			{ 
				float pageHeight=(float) pageSizes.get(pg1).getHeight();
				List<BasicStructure> elList=pageWiseSegs.get(pg1);

				float pageHeaderHeight=pageHeight*heightThreshold;
				for(BasicStructure el:elList)
				{
					if(el instanceof BasicStructure && el.getRectangle().getY()<pageHeaderHeight && el.getStringRepresentation().equals(str.getStringRepresentation()))
					{
						if((el.getRectangle().getPage()%2)==0){
							evenCounter++;break;
						}else{
							oddCounter++;break;
						}
					}
				}

			}

			if(pageWiseSegs.size()>12){
				if((evenCounter>=(pageWiseSegs.size()-3)/2)||(oddCounter>=(pageWiseSegs.size()-3)/2)){
					repeatedStr_OddEven.add(str);
				}
			}else{
				if((evenCounter>=(pageWiseSegs.size()-1)/2)||(oddCounter>=(pageWiseSegs.size()-1)/2)){
					repeatedStr_OddEven.add(str);
				}
			}


		}
		return repeatedStr_OddEven;
	}


	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-Pattern based Header detection  		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)),List(String), float, int, float; 		<br>
	 * 	@return :-	Map(Page,List(Header)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	Create Headers	 	<br>
	 * 	@Logic:-decide header area of page and check paragraphs on this areas is match any patter from patterns list ? <br>
	 * 			if match create this paragraph as Header.	<br>
	 * 											
	 * */
	public  Map<Integer, List<BasicStructure>> patternBasedHFDetection(List<String> patterns, float heightThreshold, int editDistance, float headerPagesFactor){
		//		Map<Page, List<Header>> pageWiseHeaders=new TreeMap<Page, List<Header>>();

		//create paragraph Frequency HashMap for header region

		if(pageWiseSegs.keySet().size()<=2){
			return pageWiseHeadersList;
		}

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> pageElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = pageElements.iterator();
			List<BasicStructure>tempHeader=new ArrayList<BasicStructure>();

			float pageHeight=(float) pageSizes.get(keyPage).getHeight(); 
			float pageHeaderHeight=pageHeight*heightThreshold;
			int startEndCount=0;

			seg:
				while(paraIterator.hasNext()){
					BasicStructure para=paraIterator.next();
					startEndCount++;
					if(para.getRectangle().getY() < pageHeaderHeight){
						boolean	pageNumFlag=false;
						/*if(para instanceof PDFWord){
							pageNumFlag= ((PDFWord)para).isPageNum();
						}else if(para instanceof PDFSegment){
							pageNumFlag= ((PDFSegment)para).isPageNum();
						}*/
						if(pageNumFlag){// && para.getStringRepresentation().trim().split(" ").length==1){
							//boolean isAnyOtherText = isAnyOtherText(para,pageElements);
							tempHeader.add(para);
							continue ;
						}
						for(String pattern : patterns){
							if(para.getStringRepresentation().toLowerCase().trim().matches(pattern)){
								//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
								tempHeader.add(para);
								//paraIterator.remove();
								continue seg;
							}
						}
						//System.out.println("Pattern - "+para.getText());
						if(para.getStringRepresentation().matches("[0-9]{1,3}")&& para.getRectangle().getY() < pageHeaderHeight/1.5){//&& !tempFooter.contains(para)){
							//can also check  nearest  segment on same y if > threshold distance

							int count=onNextPagesDetection(para,keyPage);
							//	boolean textPresentFlag=isAnyTextOnSameY(para,paraElements);

							boolean isAnyOtherText = isAnyOtherText(para,pageElements);
							if(!isAnyOtherText){
								tempHeader.add(para);
							}
							//}
							//paraIterator.remove();
						}	
					}
					else if((pageElements.size()>10)&&(startEndCount<5)){

						if(para.getStringRepresentation().matches("[0-9]{1,3}")){//&& !tempFooter.contains(para)){
							boolean isAnyOtherText = isAnyOtherText(para,pageElements);
							if(!isAnyOtherText){
								tempHeader.add(para);
							}
						}
					}
				}
			if(pageWiseHeadersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseHeadersList.get(keyPage);
				for (BasicStructure pdfSegment : tempHeader) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseHeadersList.put(keyPage, lst);
			}else{
				pageWiseHeadersList.put(keyPage, tempHeader);
			}
			//pageWiseHeaders.put(keyPage, tempHeader);
		}
		return pageWiseHeadersList;
	}
	private  int onNextPagesDetection(BasicStructure seg,int pageNo) {

		int cnt=0;
		//		List<Integer> pageNumSeqList=new ArrayList<Integer>();
		//		pageNumSeqList.add(Integer.parseInt(para.getStringRepresentation().trim()));
		for(Integer i:pageWiseSegs.keySet()){
			List<BasicStructure> pageParas = pageWiseSegs.containsKey(i) ? pageWiseSegs.get(i) : new ArrayList<BasicStructure>();
			if(pageParas==null || pageParas.isEmpty()){
				continue;
			}

			for (BasicStructure s : pageParas) {
				float diff=Math.abs(seg.getRectangle().getY()-s.getRectangle().getY());
				if(diff<2){//same y

					if(seg.getStringRepresentation().matches("[0-9]{1,3}")){
						//						int nm = Integer.parseInt(para.getStringRepresentation().trim());
						//						if(pageNumSeqList.get(pageNumSeqList.size()-1)==(nm-1)){
						//							pageNumSeqList.add(nm);
						cnt++;
						break;
						//						}
					}
				}

			}
		}
		return cnt;
	}

	private static boolean isAnyOtherText(BasicStructure seg,List<BasicStructure> pageElements) {

		if(pageElements==null || pageElements.isEmpty()){
			return false;
		}
		for (BasicStructure s : pageElements) {
			if(!s.equals(seg) && CommonOperations.isOverlapOnY(s, seg)){
				return true;
			}
		}
		return false;
	}

	/*	private static boolean isAnyOtherText(BasicStructure seg,List<BasicStructure> pageElements) {
		float segY = seg.getRectangle().getY();
		if(pageElements==null || pageElements.isEmpty()){
			return false;
		}
		for (BasicStructure s : pageElements) {
			//			if(s.equals(seg){
			//				continue;
			//			}
			float diff=Math.abs(seg.getRectangle().getY()-s.getRectangle().getY());
			if(diff<2){//same y
				if(!s.equals(seg) && s.getRectangle().getY()==segY){
					return true;
				}

			}
		}
		return false;
	}*/
	/**
	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-boundary based Header detection  		<br>
	 * 	@param 	:-	Map(Page,List(Paragraph)) pageWiseParas,Map(Page,List(Header)) pageWiseHeaders; 		<br>
	 * 	@return :-	Map(Page,List(Header)) pageWiseHeaders;		<br>
	 * 	@Purpose:-	 Paragraphs which are above side of boundary header	Create as Headers 	<br>
	 * 	@Logic:-detect boundary header/s through pattern based or generic similarity based catch max y from this header/s  <br>
	 * 			paragraphs which are above's this header are also converts to header. 			<br>
	 * 											
	 * */
	public  Map<Integer, List<BasicStructure>> genericBoundaryBasedHFDetection(){

		if(pageWiseSegs.keySet().size()<=2){
			return pageWiseHeadersList;
		}

		for(Integer keyPage:pageWiseSegs.keySet()){
			List<BasicStructure> paraElements=pageWiseSegs.get(keyPage);
			Iterator<BasicStructure> paraIterator = paraElements.iterator();
			List<BasicStructure>tempHeader= new ArrayList<BasicStructure>();
			float max=getMaxYofHeader(pageWiseHeadersList.get(keyPage));
			if( max==0 )continue;

			while(paraIterator.hasNext()){
				BasicStructure para=paraIterator.next();

				if(para.getRectangle().getY() <= max)
				{
					//BasicStructure h=new BasicStructure(para.getId(), para.getX(), para.getY(), para.getWidth(), para.getHeight(), para.getText());
					tempHeader.add(para);
					//paraIterator.remove();
					//pageWiseHeaders.put(keyPage, tempHeader);
				}
			}
			if(pageWiseHeadersList.containsKey(keyPage)){
				List<BasicStructure> lst = pageWiseHeadersList.get(keyPage);
				for (BasicStructure pdfSegment : tempHeader) {
					if(!lst.contains(pdfSegment)){
						lst.add(pdfSegment);
					}
				}
				pageWiseHeadersList.put(keyPage, lst);
			}else{
				pageWiseHeadersList.put(keyPage, tempHeader);
			}
		}

		return pageWiseHeadersList;
	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-getMaxYofHeader  		<br>
	 * 	@param 	:-	List(Header); 		<br>
	 * 	@return :-	float;		<br>
	 * 	@Purpose:-	Catch maximum y of created header to detect above of its as also header<br>
	 *											
	 * */
	public static float getMaxYofHeader(List<BasicStructure> tempHeader){

		if(tempHeader==null || tempHeader.size()<=0){
			return 0 ;
		}

		float max=0;
		BasicStructure maxHeader = null ;
		for (BasicStructure header : tempHeader) {
			if(header.getRectangle().getY()>max){
				maxHeader=header;
				max=header.getRectangle().getY();
			}
		}
		return max;
	}

	/**
	 * @author BB0e1165		<br>
	 * 	Method Name:-getOutcome	<br>
	 * 	@return :-	Map(Page,List(Header)) pageWiseFHeaders;		<br>
	 * 	@Purpose:-	return created Headers	 	<br>
	 *
	 * */
	@Override
	public Map<Integer, List<Header>> getOutcome() {
		return pageWiseHeadersFinal;
	}

	public Map<Integer, List<BasicStructure>> getRemainingPageWiseParas(){
		return pageWiseSegs;
	}
	public Map<Integer, List<BasicStructure>> getRemainingParaElementsHM(){
		return pageWiseSegs;
	}
}
