package com.pdf.parser.base.strategy;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

import com.pdf.parser.Strategy;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.utils.CommonOperations;


/**
 * A strategy to form PDFCharacters for a page.
 * The default text position objects retrieved from PDFTextStripper do not strictly follow the order of x and y. Custom sorts are applied to make it right.
 * @author Shishir.Mane
 *
 */
public class PDFCharacterFormationStrategy implements Strategy<List<PDFCharacter>> {

	private List<PDFCharacter> characters;
	private List<PDFCharacter> overrideCharacters;
	private PDPage page;
	private int pageNumber;
	private List<TextPosition> chars;
	private List<TextPosition> spaceCharTextPos;
	private List<PDFCharacter> spaceCharList;
	private List<DPCell>pageLineCells;


	private static  ResourceBundle config;
	static{
		try {
			//config = ResourceBundle.getBundle("Utf_Characters");
			config = ResourceBundle.getBundle("Utf_Characters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public PDFCharacterFormationStrategy(PDPage page, int pageNumber){
		/*this.page = page;
		this.pageNumber = pageNumber;
		//Track the characters in the PDF and their order
		chars = new ArrayList<TextPosition>();
		spaceCharTextPos =new ArrayList<TextPosition>();
		//Final outcome of this strategy
		characters = new ArrayList<PDFCharacter>();*/
		this.page = page;
		this.pageNumber = pageNumber;
		//this.pageLineCells=pageLineCells;
		//Track the characters in the PDF and their order
		chars = new ArrayList<TextPosition>();
		spaceCharTextPos =new ArrayList<TextPosition>();
		spaceCharList=new ArrayList<PDFCharacter>();
		//Final outcome of this strategy
		characters = new ArrayList<PDFCharacter>();
		overrideCharacters=new ArrayList<PDFCharacter>();
	}

	/*public PDFCharacterFormationStrategy(PDPage page, int pageNumber,
			List<DPCell> pageLineCells) {
		this.page = page;
		this.pageNumber = pageNumber;
		this.pageLineCells=pageLineCells;
		//Track the characters in the PDF and their order
		chars = new ArrayList<TextPosition>();
		spaceCharTextPos =new ArrayList<TextPosition>();
		spaceCharList=new ArrayList<PDFCharacter>();
		//Final outcome of this strategy
		characters = new ArrayList<PDFCharacter>();

	}*/

	@SuppressWarnings("unchecked")
	public void apply() {
		try{
			PDFTextStripper pts = new PDFTextStripper(){
				protected void processTextPosition(TextPosition t) {

					if(t.getCharacter().trim().length()==0 || isUTFSpaceChar(t.getCharacter())){
						spaceCharTextPos.add(t);
						/*PDFCharacter c = new PDFCharacter(new DPRectangle(t.getXDirAdj(), t.getYDirAdj(), t.getWidthDirAdj(), t.getHeightDir(), pageNumber), 
								t.getCharacter(), StructureType.CHARACTER,
								"", "",
								t.getFontSize(), t.getFontSizeInPt(), t.getWidthOfSpace(),
								false, false);
						if(!isOverride(c))
							spaceCharList.add(c);
						c.setRoatation(t.getDir());*/
						//return;
					}

					chars.add(t);
				};
			};

			pts.setSuppressDuplicateOverlappingText(true);

			//This helps in tracking the order of characters
			pts.setSortByPosition(true);

			//This invokes the processTextPosition function in pts
			pts.processStream(page, page.findResources(), page.getContents().getStream());
			//Fill the PDFCharacter list.
			for (TextPosition t : spaceCharTextPos) {
				PDFCharacter c = new PDFCharacter(new DPRectangle(t.getXDirAdj(), t.getYDirAdj(), t.getWidthDirAdj(), t.getHeightDir(), pageNumber), 
						t.getCharacter(), StructureType.CHARACTER,
						"", "",
						t.getFontSize(), t.getFontSizeInPt(), t.getWidthOfSpace(),
						false, false);
				if(!isOverride(c))
					spaceCharList.add(c);
				c.setRoatation(t.getDir());
			}
			for(TextPosition ch : chars){

				if(ch.getCharacter().equalsIgnoreCase(")")){
					System.out.print("");

				}
				if(ch.getX()<0) //remove space Char here also
					continue;

				boolean isBold=false, isItalic=false;
				String fontName = "";
				String fontFamily = "";

				if(ch.getFont()!=null && ch.getFont().getFontDescriptor()!=null && ch.getFont().getBaseFont()!=null){
					isBold = ch.getFont().getFontDescriptor().isForceBold() 
							|| ch.getFont().getBaseFont().toLowerCase().endsWith("bold")
							|| ch.getFont().getBaseFont().toLowerCase().endsWith("boldmt")
							|| ch.getFont().getBaseFont().toLowerCase().endsWith("bolditalic");

					isItalic = (ch.getFont().getFontDescriptor()!=null && ch.getFont().getFontDescriptor().isItalic()) 
							|| ch.getFont().getBaseFont().toLowerCase().endsWith("italic");

					if(ch.getFont().getFontDescriptor()!=null){
						fontName = ch.getFont().getFontDescriptor().getFontName();
						fontFamily = ch.getFont().getFontDescriptor().getFontFamily();
					}

				}

				PDFCharacter c = new PDFCharacter(new DPRectangle(ch.getXDirAdj(), ch.getYDirAdj(), ch.getWidthDirAdj(), ch.getHeightDir(), pageNumber), 
						ch.getCharacter(), StructureType.CHARACTER,
						fontName, fontFamily,
						ch.getFontSize(), ch.getFontSizeInPt(), ch.getWidthOfSpace(),
						isBold, isItalic);

				if(isOverride(c)){
					overrideCharacters.add(c);
					continue;
				}

				if(isUTFSpaceChar(c)) {//remove space Char here also
					c.setSpaceChar(true);
				}

				characters.add(c);
				c.setRoatation(ch.getDir());
				//				if(c.getRectangle().getY()>151){
				//System.out.print("cell Part"+c);	
				//				}

				if(pageLineCells!=null && !pageLineCells.isEmpty()){
					DPCell dpCell=isInCellArea(c,pageLineCells);
					if(dpCell!=null){
						c.setLineCell(dpCell);
						//		System.out.print(c.getStringRepresentation());
					}
				}

			}

			/*for (PDFCharacter pdfWord : characters) {
				System.out.println(pdfWord.getStringRepresentation()+"\t"+pdfWord.getRectangle().getX()+"\t"+pdfWord.getRectangle().getY());
			}*/
			//Y-Overlaps are not considered. Exact y matches are sorted
			characters = (List<PDFCharacter>)CommonOperations.yxSort(new HashSet<PDFCharacter>(characters), false, 0);//Hashset helps in removing duplicates

		}catch(IOException e){
			e.printStackTrace();
			Logger.getLogger(PDFCharacterFormationStrategy.class.getName()).log(Level.SEVERE, e.getMessage());
		}
	}

	private DPCell isInCellArea(PDFCharacter c, List<DPCell> cell_list) {


		for (DPCell dpLineCell : cell_list) {
			float y2 = (float)dpLineCell.getRectangle().getY();
			float y = (float) (y2+ dpLineCell.getRectangle().getHeight());
			double x=dpLineCell.getRectangle().getX();
			double x2=x+dpLineCell.getRectangle().getWidth();

			if(c.getRectangle().getY()<=y
					&& c.getRectangle().getY2()>=y2
					&& c.getRectangle().getX()>=x
					&& c.getRectangle().getX2()<=x2
					){

				return dpLineCell;

			}

		}
		return null;
	}


	public static boolean isUTFSpaceChar(String ch) {

		/*List<String> utfSpaceChars = Arrays.asList(config.getString("spaceUTF").split(","));
		for (String string : utfSpaceChars) {
			if(((char)+"\'"+string.trim()).equals(ch.getStringRepresentation().charAt(0)))){
				return true;
			}
		}*/
		if(ch.trim().length()==0){
			return true;
		}
		List<String> utfSpaceChars = Arrays.asList(config.getString("spaceUTFInt").split(","));
		for (String string : utfSpaceChars) {
			if(Integer.valueOf(string.trim())==((int)ch.charAt(0))){
				return true;
			} 
		}
		return false;
	}

	private boolean isUTFSpaceChar(PDFCharacter ch) {

		/*List<String> utfSpaceChars = Arrays.asList(config.getString("spaceUTF").split(","));
		for (String string : utfSpaceChars) {
			if(((char)+"\'"+string.trim()).equals(ch.getStringRepresentation().charAt(0)))){
				return true;
			}
		}*/
		if(ch.getStringRepresentation().trim().length()==0){
			return true;
		}
		List<String> utfSpaceChars = Arrays.asList(config.getString("spaceUTFInt").split(","));
		for (String string : utfSpaceChars) {
			if(Integer.valueOf(string.trim())==((int)ch.getStringRepresentation().trim().charAt(0))){
				return true;
			} 
		}
		return false;
	}

	public static boolean isOverlapOnX(BasicStructure s1, BasicStructure s2){
		boolean overlap = false;

		if(s2.getRectangle().getX() > s1.getRectangle().getX()+1 && s2.getRectangle().getX() < s1.getRectangle().getX2()-1)
			overlap = true;

		else if(s2.getRectangle().getX2() < s1.getRectangle().getX2()-1 && s2.getRectangle().getX2() > s1.getRectangle().getX()+1)
			overlap = true;

		else if(s2.getRectangle().getX() < s1.getRectangle().getX()-1 && s2.getRectangle().getX2() > s1.getRectangle().getX2()+1)
			overlap = true;

		return overlap;
	}
	
	public static boolean isOverlapOnY(BasicStructure s1, BasicStructure s2){
		boolean overlap = false;

		if(s2.getRectangle().getY() < s1.getRectangle().getY()-1 && s2.getRectangle().getY() > s1.getRectangle().getY2()+1)
			overlap = true;

		else if(s2.getRectangle().getY2() > s1.getRectangle().getY2()+1 && s2.getRectangle().getY2() < s1.getRectangle().getY()-1)
			overlap = true;

		else if(s2.getRectangle().getY() > s1.getRectangle().getY()+1 && s2.getRectangle().getY2() < s1.getRectangle().getY2()-1)
			overlap = true;

		//Special handling for periods and commas which may have their y2 just below the word's y
//		else if(Math.abs(s2.getRectangle().getY() - s1.getRectangle().getY()) <= Float.valueOf(basicConfig.getString("allowedYDiffInSort")))
//			overlap = true;

		return overlap;
	}
	public boolean isOverride(PDFCharacter c){

		for (PDFCharacter pdfCharacter : characters) {
			/*if(pdfCharacter.getRectangle().getPageNo()!=c.getRectangle().getPageNo() || pdfCharacter.getStringRepresentation().trim().length()==0 || isUTFSpaceChar(pdfCharacter)){
				continue;
			}*/
			/*if(isOverlapOnX( c, pdfCharacter ) && isOverlapOnY( c, pdfCharacter )){
				return true;
			}*/
			float xDiff = Math.abs(c.getRectangle().getX()-pdfCharacter.getRectangle().getX());
			float yDiff = Math.abs(c.getRectangle().getY()-pdfCharacter.getRectangle().getY());

			if(xDiff < 1.0 && yDiff < 1.0 ){
				if(!isUTFSpaceChar(pdfCharacter) &&  isUTFSpaceChar(c)){ //if spsce override with character remove it
					return true;

				}else 
				if((isUTFSpaceChar(pdfCharacter) &&  isUTFSpaceChar(c))
						||(!isUTFSpaceChar(pdfCharacter) &&  !isUTFSpaceChar(c))
						){
					//System.out.println("Override with:"+pdfCharacter);
					return true;
				}
			}
		}
		return false;
	}


	public List<PDFCharacter> getOutcome() {
		return characters;
	}

	public List<PDFCharacter> getSpaceOutcome() {
		return spaceCharList;
	}
	public List<PDFCharacter> getOverrideCharacters() {
		return overrideCharacters;
	}

}
