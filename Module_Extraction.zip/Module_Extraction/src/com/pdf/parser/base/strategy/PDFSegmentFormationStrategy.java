package com.pdf.parser.base.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import com.pdf.parser.Strategy;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.Enumerations;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.utils.CommonOperations;

/**
 * A strategy to form segments out of PDF Words of a page.
 * Just that each word in a segment should have the same font, size and style.
 * @author Shishir.Mane
 *
 */
public class PDFSegmentFormationStrategy implements Strategy<List<PDFSegment>> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	Boolean fontBasedSegmentFormation = new Boolean(config.getString("fontBasedSegmentFormation"));
	
	List<PDFSegment> segments;
	List<PDFWord> words;
	int page;
	
	public PDFSegmentFormationStrategy(List<PDFWord> words, int page){
		segments = new ArrayList<PDFSegment>();
		
		this.words = words;
		this.page = page;
	}

	/**
	 * Broadly the approach is to first find the words with groups of similar Y.
	 * For each of these groups, form segments based on two strategies:
	 * 1. The gap is more than the config
	 * 2. The consecutive gaps is crossing the threshold defined in the config
	 */
	
	@SuppressWarnings("unchecked")
	@Override
	public void apply() {
		List<PDFWord> wordsOnMatchingY = new ArrayList<PDFWord>();
		Set<String> individualSegWords = new HashSet<String>();
		individualSegWords.add("DOB:");
		individualSegWords.add("Gender:");
		individualSegWords.add("Gender;");
		individualSegWords.add("MRN:");
		individualSegWords.add("AGE:");
		individualSegWords.add("Greeting:");
		
		//DOB
		if(words.isEmpty()){
			return ;
		}
		
		//System.out.println("WORDS "+words);
		//System.out.println();
		
		wordsOnMatchingY.add(words.get(0));
		
		for(int i=1; i<words.size(); i++){//Last but one
			float diffY = Math.abs(words.get(i-1).getRectangle().getY() - words.get(i).getRectangle().getY());
			
			if(words.get(i).getStringRepresentation().contains("DOB:"))
				System.out.print("");
			
			if((diffY <= Float.valueOf(config.getString("allowedYForGroup"))&& !individualSegWords.contains(words.get(i).getStringRepresentation().trim()))
					//&& isWordEndsWithValidColon(words.get(i-1))
					)

				wordsOnMatchingY.add(words.get(i));
		
//			if(diffY <= Float.valueOf(config.getString("allowedYForGroup")))
//				wordsOnMatchingY.add(words.get(i));
//			
//			//The line has changed
			else{
				
				processListOnY(wordsOnMatchingY);
				
				wordsOnMatchingY.clear();
				wordsOnMatchingY.add(words.get(i));
			}
		}
		
		if(wordsOnMatchingY.size()>0)
			processListOnY(wordsOnMatchingY);//If there are any remaining
		
		segments = (List<PDFSegment>)CommonOperations.yxSort(new HashSet<PDFSegment>(segments), true, 0);
		
		//***Connect enumerated segments
		//create groupOfSegment based on y and take first seg for enum check
		List<PDFSegment> lastParaSegs = new ArrayList<PDFSegment>(segments);
		Collections.sort(lastParaSegs, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o2.getRectangle().getX2()).compareTo(o1.getRectangle().getX2());
			}
		});
		
		// PG code condition for checking lastParaSegs doc#2016484302 
		if( !lastParaSegs.isEmpty()  && lastParaSegs!=null)
		{

		PDFSegment maxX2Seg = lastParaSegs.get(0);
	
		float maxX2 = maxX2Seg.getRectangle().getX2();

		Collections.sort(lastParaSegs, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
			}
		});
		PDFSegment minXSeg = lastParaSegs.get(0);
		float minX = minXSeg.getRectangle().getX();
		
		
		float y=-1;
		List<PDFSegment> segToBeRemoved = new ArrayList<PDFSegment>();
		for(int i=0; i<segments.size(); i++){
			PDFSegment seg = segments.get(i);
			
			if(seg.getStringRepresentation().contains("TIV of $"))
				System.out.println("debug");
			if(seg.getStringRepresentation().contains("5:01:40")){
				System.out.print("");
			}
			if(seg.getRectangle().getY() != y && seg.getRectangle().getY() > y){
				y = seg.getRectangle().getY();
				//check its x coordinate of enum seg is must less than half of max x2 of current column
				double percentArea = ((maxX2-minX)*0.20); //first 20% area of that column
				if(seg.getRectangle().getX()>(minX+percentArea)){//if greater don't find its enum
					continue;		
				}
				
				if(Enumerations.options.contains(seg.getStringRepresentation().trim())){
					if(i!=segments.size()-1){
						PDFSegment next = segments.get(i+1);
						
						if(CommonOperations.isOverlapOnY(seg, next)){//Next segment should be at the same level
							seg.getRectangle().setWidth(next.getRectangle().getX2() - seg.getRectangle().getX());
							seg.getRectangle().setHeight(
									seg.getRectangle().getHeight() > next.getRectangle().getHeight() ?
											seg.getRectangle().getHeight() :
											next.getRectangle().getHeight()
									);
							seg.getWords().addAll(next.getWords());
							
							seg.setEnumerated(true);
							seg.setEnumeration(seg.getStringRepresentation());
							seg.setStringRepresentation(seg.getStringRepresentation() + " " + next.getStringRepresentation());
							
							segToBeRemoved.add(next);
							i++;
						}
					}
				}
				/*}else if(CommonOperations.isStartwithBulletPoint(seg.getStringRepresentation())){
					seg.setEnumerated(true);
					seg.setEnumeration(".");
				*/
				}else if(seg.getStringRepresentation().contains(" ")){
					String firstWord = seg.getStringRepresentation().split("\\s")[0].trim();
					if(Enumerations.options.contains(firstWord)){
						seg.setEnumerated(true);
						seg.setEnumeration(firstWord);
					
					}
				}
			}
		
		//************************
		
			segments.removeAll(segToBeRemoved);
		} // end if for PG code
	}
	
	private boolean isWordEndsWithValidColon(PDFWord w1) {
		String text=w1.getStringRepresentation();

		if(text.trim().equalsIgnoreCase("|")){
			return false;
		}
		if(text.endsWith(":")){
			if(text.trim().length()>2){
				String subStr=text.substring(0, text.length()-1).trim();
				if(subStr.matches("[^:]*[0-9]{2,}$")){
					return true; //its's not valid colon
				}
			}
		}else{
			return true;
		}
		return false;
		//		if(!w1.getStringRepresentation().trim().endsWith(":") && w1.subStr.matches("[^:]*[0-9]{2,}$")){

	}
	/**
	 * We wish to make a further sub-list based on font properties and forward it to processListOnX. 
	 * The idea being that, that function purely has to focus on actual segmentation, rest of the aspects are taken care of.
	 * @param wordsOnMatchingY List of words with similar Y
	 */
	private void processListOnY(List<PDFWord> wordsOnMatchingY){
		
//		for(PDFWord word : wordsOnMatchingY){
//			if(word.getStringRepresentation().equalsIgnoreCase("(d)")){
//				System.out.println("debug");
//				break;
//			}
//		}
		
		//If there is only one word in the list, that becomes the segment
		if(wordsOnMatchingY.size()==1){
			PDFWord w = wordsOnMatchingY.get(0);
			segments.add(new PDFSegment(w.getStringRepresentation(), 
								new DPRectangle(w.getRectangle().getX(), w.getRectangle().getY(), w.getRectangle().getWidth(), w.getRectangle().getHeight(), page), 
								StructureType.SEGMENT, Arrays.asList(w)));
		
		}else if(wordsOnMatchingY.size()>1 && fontBasedSegmentFormation){
			
			//Find words with matching font attributes in the sub-list
			List<PDFWord> wordsWithMatchingFont = new ArrayList<PDFWord>();
			wordsWithMatchingFont.add(wordsOnMatchingY.get(0));
			
			for(int j=1; j<wordsOnMatchingY.size(); j++){
				PDFWord lastWord = wordsWithMatchingFont.get(wordsWithMatchingFont.size()-1);
				PDFWord word = wordsOnMatchingY.get(j);
				
				//Sometimes pdf box does not return any font name
				boolean doesFontNameMatch = word.getCharacters().get(0).getFontName().equals(lastWord.getCharacters().get(0).getFontName()) 
						|| word.getCharacters().get(0).getFontName().length()==0 
						|| lastWord.getCharacters().get(0).getFontName().length()==0;
				
				float fontSizeOfWord = word.getCharacters().get(0).getFontSize();
				float fontSizeOfLastWord = lastWord.getCharacters().get(0).getFontSize();
				boolean isWordBold = word.getCharacters().get(0).isBold();
				boolean isLastWordBold = lastWord.getCharacters().get(0).isBold();
				boolean isWordItalic = word.getCharacters().get(0).isItalic();
				boolean isLastWordItalic = lastWord.getCharacters().get(0).isItalic();
			
				//Last word and current one should have same font, size, bold, italic, allCaps
				//We can understand that these conditions are adaptive and hence will adapt to different fonts and sizes
				if(doesFontNameMatch && fontSizeOfWord == fontSizeOfLastWord
						&& isWordBold==isLastWordBold && isWordItalic==isLastWordItalic){
					
					wordsWithMatchingFont.add(word);
				
				}else{
					processListOnX(wordsWithMatchingFont);
					
					wordsWithMatchingFont.clear();
					wordsWithMatchingFont.add(word);
				}
			}
			
			processListOnX(wordsWithMatchingFont);
		
		}else
			processListOnX(wordsOnMatchingY);
	}
	
	float maxGapLimit = new Float(config.getString("maxGapLimit"));
	float subsequentGapTolerance = new Float(config.getString("subsequentGapTolerance"));
	
	/**
	 * Please refer to the in-function comments for greater understanding. Broadly the steps are:
	 * 1. Handle one word and two word cases
	 * 2. For more than two words:
	 * 		a. Handle all words except last three
	 * 			i)  Handle cases where the gaps breach the permitted gap
	 * 			ii) Else handle based on diff of subsequent gaps
	 * 		
	 * 		b. Handle last three words
	 * 			i)   Handle if the first gap is more than permitted gap
	 * 			ii)  Handle if the second gap is more than permitted gap
	 * 			iii) Handle if both gaps are within permitted gap
	 * 
	 * @param wordsWithMatchingFont List of words that occur on similar Y and which have matching font properties.
	 */
	private void processListOnX(List<PDFWord> wordsWithMatchingFont){
		
//		if(page == 1)
//			System.out.println("Debug");
		
		//Strictly one word scenario
		if(wordsWithMatchingFont.size()==1){
			PDFWord w = wordsWithMatchingFont.get(0);
			segments.add(new PDFSegment(w.getStringRepresentation(), 
					new DPRectangle(w.getRectangle().getX(), w.getRectangle().getY(), w.getRectangle().getWidth(), w.getRectangle().getHeight(), page), 
					StructureType.SEGMENT, Arrays.asList(w)));
		
		//Strictly for two words scenario
		}else if(wordsWithMatchingFont.size()==2){
			
			float gap = wordsWithMatchingFont.get(1).getRectangle().getX() - wordsWithMatchingFont.get(0).getRectangle().getX2();
			float widthOfSpace = wordsWithMatchingFont.get(0).getCharacters().get(0).getWidthOfSpace();
			
			//If gap is less than product of widthOfSpace and maxGapLimit then combine them in one segment or else create two separate segments
			if(gap < widthOfSpace*maxGapLimit){
				
				PDFWord w1 = wordsWithMatchingFont.get(0);
				PDFWord w2 = wordsWithMatchingFont.get(1);
				makeSegment(Arrays.asList(w1,w2), w1.getStringRepresentation()+" "+w2.getStringRepresentation(), segments, page);
			
			}else{
				PDFWord w = wordsWithMatchingFont.get(0);
				segments.add(new PDFSegment(w.getStringRepresentation(), 
								new DPRectangle(w.getRectangle().getX(), w.getRectangle().getY(), w.getRectangle().getWidth(), w.getRectangle().getHeight(), page), 
								StructureType.SEGMENT, Arrays.asList(w)));
				
				w = wordsWithMatchingFont.get(1);
				segments.add(new PDFSegment(w.getStringRepresentation(), 
						new DPRectangle(w.getRectangle().getX(), w.getRectangle().getY(), w.getRectangle().getWidth(), w.getRectangle().getHeight(), page), 
						StructureType.SEGMENT, Arrays.asList(w)));
			}
		
		//Strictly more than two words scenario
		}else{
			
			List<PDFWord> segmentWords = new ArrayList<PDFWord>();
			String segmentString = "";
			float widthOfSpace = wordsWithMatchingFont.get(0).getCharacters().get(0).getWidthOfSpace();
			
			for(int i=0; i<wordsWithMatchingFont.size()-2; i++){
				
				PDFWord word1 = wordsWithMatchingFont.get(i);
				PDFWord word2 = wordsWithMatchingFont.get(i+1);
				PDFWord word3 = wordsWithMatchingFont.get(i+2);
				
//				if(word1.getStringRepresentation().equalsIgnoreCase("company") && word2.getStringRepresentation().equalsIgnoreCase("vehicles"))
//					System.out.println("debug");
				
				float diff1 = word2.getRectangle().getX() - word1.getRectangle().getX2();
				float diff2 = word3.getRectangle().getX() - word2.getRectangle().getX2();
				
				//if this is not the third last word
				if(i != wordsWithMatchingFont.size()-3){
					
					//If diff1 is more than the condition, we create the segment
					//We do not need to check the diff2 the same way because after continuing diff2 will become diff1
					if(diff1 > widthOfSpace*maxGapLimit || word1.getStringRepresentation().endsWith(":")){
						segmentWords.add(word1);
						segmentString += word1.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
						//Reset
						segmentWords.clear();
						segmentString = "";
					
					//Else we need to check for subsequent gap tolerance
					}else{
					
						float percentageDiff = Math.abs(diff2 - diff1)/diff1;
						boolean areBothLess = (diff1 < widthOfSpace*maxGapLimit) && (diff2 < widthOfSpace*maxGapLimit);
						//Just add the first word to the list
						if(percentageDiff < subsequentGapTolerance || diff2<diff1 || areBothLess){
							segmentWords.add(word1);
							segmentString += word1.getStringRepresentation()+" ";
						
						//Add first and second word to the list and create segment and reset the list
						}else{
							segmentWords.add(word1);
							segmentString += word1.getStringRepresentation()+" ";
							
							segmentWords.add(word2);
							segmentString += word2.getStringRepresentation()+" ";
							
							makeSegment(segmentWords, segmentString, segments, page);
							
							//Reset
							segmentWords.clear();
							segmentString = "";
							
							i++;//Increment as i+1 got utilized in the segment creation
							
							//If we are on the third last word that is already part of the above segment
							//We have to just decide regarding the last two words
							//Anyways this is the last iteration of the loop
							if(i == wordsWithMatchingFont.size()-3){
								PDFWord w1 = wordsWithMatchingFont.get(i+1);
								PDFWord w2 = wordsWithMatchingFont.get(i+2);
								
								float gap = w2.getRectangle().getX() - w1.getRectangle().getX2();
								
								//If gap is less than product of widthOfSpace and maxGapLimit then combine them in one segment or else create two separate segments
								if(gap < w1.getWidthOfSpace()*maxGapLimit){
									
									makeSegment(Arrays.asList(w1,w2), w1.getStringRepresentation()+" "+w2.getStringRepresentation(), segments, page);
								
								}else{
									segments.add(new PDFSegment(w1.getStringRepresentation(), 
											new DPRectangle(w1.getRectangle().getX(), w1.getRectangle().getY(), w1.getRectangle().getWidth(), w1.getRectangle().getHeight(), page), 
											StructureType.SEGMENT, Arrays.asList(w1)));
									
									segments.add(new PDFSegment(w2.getStringRepresentation(), 
											new DPRectangle(w2.getRectangle().getX(), w2.getRectangle().getY(), w2.getRectangle().getWidth(), w2.getRectangle().getHeight(), page), 
											StructureType.SEGMENT, Arrays.asList(w2)));
								}
							}
						}
					}
				}				
				
				//If we are on the third last word
				else{
					
					if(diff1 < widthOfSpace*maxGapLimit && diff2 < widthOfSpace*maxGapLimit){
						
						segmentWords.add(word1);
						segmentString += word1.getStringRepresentation()+" ";
						
						segmentWords.add(word2);
						segmentString += word2.getStringRepresentation()+" ";
						
						segmentWords.add(word3);
						segmentString += word3.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
					}else if(diff1 < widthOfSpace*maxGapLimit && diff2 > widthOfSpace*maxGapLimit){
						
						segmentWords.add(word1);
						segmentString += word1.getStringRepresentation()+" ";
						
						segmentWords.add(word2);
						segmentString += word2.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
						segmentWords.clear();
						segmentString = "";
						
						segmentWords.add(word3);
						segmentString += word3.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
					}else if(diff1 > widthOfSpace*maxGapLimit && diff2 < widthOfSpace*maxGapLimit){
						
						segmentWords.add(word1);
						segmentString += word1.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
						segmentWords.clear();
						segmentString = "";
						
						segmentWords.add(word2);
						segmentString += word2.getStringRepresentation()+" ";
						
						segmentWords.add(word3);
						segmentString += word3.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
					}else if(diff1 > widthOfSpace*maxGapLimit && diff2 > widthOfSpace*maxGapLimit){
						segmentWords.add(word1);
						segmentString += word1.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
						segmentWords.clear();
						segmentString = "";
						
						segmentWords.add(word2);
						segmentString += word2.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
						
						segmentWords.clear();
						segmentString = "";
						
						segmentWords.add(word3);
						segmentString += word3.getStringRepresentation()+" ";
						
						makeSegment(segmentWords, segmentString, segments, page);
					}
				}
			}
		}
	}
	
	public static void makeSegment(List<PDFWord> segmentWords, String segmentString, List<PDFSegment> segments, int page){
//		System.out.println(segmentString);
		PDFWord firstWord = segmentWords.get(0);
		PDFWord lastWord = segmentWords.get(segmentWords.size()-1);
		float width = lastWord.getRectangle().getX2() - firstWord.getRectangle().getX();
		float height = lastWord.getRectangle().getHeight() > firstWord.getRectangle().getHeight() ? lastWord.getRectangle().getHeight() : firstWord.getRectangle().getHeight();
		
		segments.add(new PDFSegment(segmentString.trim(), 
						new DPRectangle(firstWord.getRectangle().getX(), firstWord.getRectangle().getY(), width, height, page), 
						StructureType.SEGMENT, new ArrayList<PDFWord>(segmentWords)));
	}

	@Override
	public List<PDFSegment> getOutcome() {
		return segments;
	}

}

/* OLD Logic for last triplet handling
 * 
//					//If the gap between the first and the second word is more than the permitted gap, make a segment with just the first word.
//					//Also check if the gap between the second and the third word is within permitted gap. If it is then create a segment with the second and third
//					if(diff1 > widthOfSpace*maxGapLimit){
//						segmentWords.add(word1);
//						segmentString += word1.getStringRepresentation()+" ";
//						
//						makeSegment(segmentWords, segmentString);
//						
//						//Reset
//						segmentWords.clear();
//						segmentString = "";
//						
//						if(diff2 <= widthOfSpace*maxGapLimit){
//							segmentWords.add(word2);
//							segmentString += word2.getStringRepresentation()+" ";
//							
//							segmentWords.add(word3);
//							segmentString += word3.getStringRepresentation()+" ";
//							
//							makeSegment(segmentWords, segmentString);
//						}
//					}
//					
//					//This block is exactly the opposite of the above condition. If the gap between the second and the third word is more than permitted
//					//and if the gap between the first and second is acceptable, we combine the first and second and their is a dangling third
//					if(diff2 > widthOfSpace*maxGapLimit){
//						
//						if(diff1 <= widthOfSpace*maxGapLimit){
//							segmentWords.add(word1);
//							segmentString += word1.getStringRepresentation()+" ";
//							
//							segmentWords.add(word2);
//							segmentString += word2.getStringRepresentation()+" ";
//							
//							makeSegment(segmentWords, segmentString);
//						
//						}else
//							segments.add(new PDFSegment(word2.getStringRepresentation(), word2.getX(), word2.getY(), word2.getWidth(), 
//									word2.getHeight(), StructureType.SEGMENT, Arrays.asList(word2), page));
//						
//						segments.add(new PDFSegment(word3.getStringRepresentation(), word3.getX(), word3.getY(), word3.getWidth(), 
//													word3.getHeight(), StructureType.SEGMENT, Arrays.asList(word3), page));
//					
//					}
//					
//					//This is the last case, where both gaps are acceptable, hence we have just one segment of all three words
//					if(diff1 <= widthOfSpace*maxGapLimit && diff2 <= widthOfSpace*maxGapLimit){
//						segmentWords.add(word1);
//						segmentWords.add(word2);
//						segmentWords.add(word3);
//						
//						segmentString += word1.getStringRepresentation()
//											+" "+word2.getStringRepresentation()+" "
//											+word3.getStringRepresentation();
//						
//						makeSegment(segmentWords, segmentString);
//					}
 */


/* ***********OLD LOGIC

List<PDFWord> segmentWordSet = new ArrayList<PDFWord>();//Set of words in a segment
		String segment = "";//String representation of a segment
		
		for(int i=0; i<words.size(); i++){
			PDFWord word = words.get(i);
			
			if(segmentWordSet.isEmpty()){
				segmentWordSet.add(word);
				segment += word.getStringRepresentation()+" ";
				continue;
			}
			
			PDFWord lastWord = segmentWordSet.get(segmentWordSet.size()-1);
			
			float predictedX = lastWord.getX2();
			float diffX = Math.abs(predictedX - word.getX());
			float diffY = Math.abs(lastWord.getY2() - word.getY2());
			
			String fontOfWord = word.getCharacters().get(0).getFontName();
			String fontOfLastWord = lastWord.getCharacters().get(0).getFontName();
			float fontSizeOfWord = word.getCharacters().get(0).getFontSize();
			float fontSizeOfLastWord = lastWord.getCharacters().get(0).getFontSize();
			boolean isWordBold = word.getCharacters().get(0).isBold();
			boolean isLastWordBold = lastWord.getCharacters().get(0).isBold();
			boolean isWordItalic = word.getCharacters().get(0).isItalic();
			boolean isLastWordItalic = lastWord.getCharacters().get(0).isItalic();
			
			//The difference in x2 of last word and the x of current word should be less than or equal to the 1.5 times width of space, to be part of the same segment
			//Also the tolerance for Y2 is kept half of word's height
			//Last word and current one should have same font, size, bold, italic, allCaps
			//We can understand that these conditions are adaptive and hence will adapt to different fonts and sizes
			if(fontOfWord.equals(fontOfLastWord) && fontSizeOfWord == fontSizeOfLastWord
					&& isWordBold==isLastWordBold && isWordItalic==isLastWordItalic
					&& diffX <= (lastWord.getWidth()/lastWord.getStringRepresentation().length())
					&& diffY < lastWord.getHeight()/2 && i!=words.size()-1){
				
				segmentWordSet.add(word);
				segment += word.getStringRepresentation()+" ";
			
			}else{
				
				//Handling last word, and aiding in the last segment formation
				if(i==words.size()-1){
					segmentWordSet.add(word);
					segment += word.getStringRepresentation()+" ";
					lastWord = word;
				}
				
				//Find the max height of word
				float maxHeight = -1;
				for(PDFWord w1 : segmentWordSet){
					float height = w1.getHeight();
					if(height > maxHeight)
						maxHeight = height;
				}
				
				//Formulate the word
				PDFWord firstWord = segmentWordSet.get(0);
				segments.add(new PDFSegment(segment.trim(), firstWord.getX(), firstWord.getY(), lastWord.getX2()-firstWord.getX(), 
						maxHeight, BasicType.SEGMENT, segmentWordSet, page));
				
				segmentWordSet.clear();
				segmentWordSet.add(word);
				segment = word.getStringRepresentation()+" ";
			}
		}
*/