package com.pdf.parser.complex;

import java.util.List;

import com.pdf.parser.Structure;
import com.pdf.parser.base.DPRectangle;

/**
 * This represents the complex constructs of the PDF. E.g. paragraphs, tables, parallel sentences etc.
 * @author Shishir.Mane
 * @see 2.1.2
 */
public interface ComplexStructure extends Structure {
	
	public List<DPRectangle> getRectangles();
	
	public int hashCode();
	
	public boolean equals(Object o);
}
