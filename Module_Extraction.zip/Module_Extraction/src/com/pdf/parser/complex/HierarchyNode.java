package com.pdf.parser.complex;

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.Structure;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.utils.Structure_Id;

public class HierarchyNode implements ComplexStructure {
	
	long id;
	HierarchyNode parent;
	List<HierarchyNode> children;
	
	List<DPRectangle> rectangles;
	String stringRepresentation;
	StructureType type;
		
	//Can be group of paragraphs, tables, vgaps, segments, etc. arranged in book reading style
	Structure structure;
	
	//Constructor for root node
	public HierarchyNode(StructureType type){
		id = Structure_Id.getInstance().getNext();
		parent = null;
		this.type = type;
		this.children = new ArrayList<HierarchyNode>();
	}
	
	public long getId() {
		return id;
	}

	//Constructor for child hierarchy of root
	public HierarchyNode(HierarchyNode parent, Structure structure, StructureType type) {
		id = Structure_Id.getInstance().getNext();
		this.parent = parent;
		this.structure = structure;
		this.type = type;
		this.children = new ArrayList<HierarchyNode>();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (id ^ (id >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HierarchyNode other = (HierarchyNode) obj;
		if (id != other.id)
			return false;
		return true;
	}
	
	public static String toDeepString(HierarchyNode node, String indent){
		String ret = "" ;
		if(node==null){
			return ret;
		}
		/*if(node.getNode() instanceof DPEmail)
		{
			ret = "\n"+indent+"Email: ";
		}else{
			ret = ret + indent + node.toString();
		}*/
		
		indent = indent + "     " ;

		for ( int i=0 ; i<node.getChildren().size() ; i++ )
		{
			HierarchyNode child = node.getChildren().get(i) ;
			String childStr = toDeepString(child, indent) ;
			ret = ret + "\n" + childStr ;
		}

		return ret ;
	}

	public HierarchyNode getParent() {
		return parent;
	}

	public List<HierarchyNode> getChildren() {
		return children;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public StructureType getType() {
		return type;
	}

	public List<DPRectangle> getRectangles() {
		return rectangles;
	}

	public Structure getStructure() {
		return structure;
	}
	
	public Structure getNode() {
		return structure;
	}

	//May never be used
	public float getWidthOfSpace() {
		return structure.getWidthOfSpace();
	}
}
