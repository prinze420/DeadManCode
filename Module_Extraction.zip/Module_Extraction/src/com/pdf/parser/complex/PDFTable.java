package com.pdf.parser.complex;

import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.utils.Structure_Id;

public class PDFTable implements ComplexStructure {
	
	long id;
	List<DPRectangle> rectangles;
	String stringRepresentation;
	StructureType type;
	List<TableCell> cells;
	
	public PDFTable(List<TableCell> cells, StructureType type) {
		id = Structure_Id.getInstance().getNext();
		this.cells = cells;
		this.type = type;
	}
	
	public long getId() {
		return id;
	}

	@Override
	public int hashCode() {//Implemented using the first rectangle only
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangles.get(0) == null) ? 0 : rectangles.get(0).hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {//Implemented using the first rectangle only
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		HierarchyNode other = (HierarchyNode) obj;
		if (rectangles.get(0) == null) {
			if (other.rectangles.get(0) != null)
				return false;
		} else if (!rectangles.get(0).equals(other.rectangles.get(0)))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public List<DPRectangle> getRectangles() {
		return rectangles;
	}

	public List<TableCell> getCells() {
		return cells;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public StructureType getType() {
		return type;
	}

	public float getWidthOfSpace() {
		return cells.get(0).getWidthOfSpace();
	}
}
