package com.pdf.parser.complex.strategy.configBasedTable.rules;

public class HeaderRule {
	String level;
	String subHeader, subHeaderTitle, pattern, footer;
	SEARCH_REGION region;
	
	public HeaderRule(String subHeader, String level, String subHeaderTitle, SEARCH_REGION region, String pattern,
			String footer) {
		super();
		this.subHeader = subHeader;
		this.level = level;
		this.subHeaderTitle = subHeaderTitle;
		this.region = region;
		this.pattern = pattern;
		this.footer = footer;
	}
	
	public String toString() {
		return "level=" + level + ", subHeader=" + subHeader + ", footer=" + footer;
	}

	public String getLevel() {
		return level;
	}

	public String getSubHeader() {
		return subHeader;
	}

	public String getFooter() {
		return footer;
	}
}
