package com.pdf.parser.complex.strategy.configBasedTable.rules;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.pdf.parser.utils.CommonOperations;


public class TableRuleReader {
	
	public static final int TOTAL_COLUMNS = 13;
	
	public static List<TableRule> getTableRules(String configPath){
		List<TableRule> rules = new ArrayList<TableRule>();
		
		try {
			//***The entire excel cells need to be marked Text. No Numeric cells are allowed
			XSSFWorkbook excel = new XSSFWorkbook(new FileInputStream(configPath));
			
			XSSFSheet columnSheet = excel.getSheetAt(0);
			int rowCount = 1;
			while(true){
				XSSFRow row = columnSheet.getRow(rowCount);
				
				if(row==null)
					break;
				
				for(int i=0;i<8;i++){
					if(row.getCell(i)!=null)
						row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
				}
				
				//Row with valid table id. Start of a table config
				if(row!=null && row.getCell(0)!=null && row.getCell(0).getStringCellValue().trim().matches("\\d+")){//TID column
					
					TableRule tableRule = new TableRule();
					tableRule.setTableId(new Integer(row.getCell(0).getStringCellValue().trim()));
					tableRule.setSearchTerm(row.getCell(1).getStringCellValue());
					
					if(row.getCell(2)!=null && row.getCell(2).getStringCellValue().trim().matches("\\d+")){//Search ID column
						tableRule.setNearbyTerms(new ArrayList<NearbyTerm>());
						tableRule.getNearbyTerms().add(getNearByTerm(row));
						rowCount++;
						
						XSSFRow nextRow = columnSheet.getRow(rowCount++); 
						while(nextRow!=null && nextRow.getCell(0)==null){//Repeat until we find next table ID
							tableRule.getNearbyTerms().add(getNearByTerm(nextRow));
							nextRow = columnSheet.getRow(rowCount++);
						}
						rowCount--;
					
					}else
						rowCount++;
					
					rules.add(tableRule);
					
				}else
					break;
			}
			
			columnSheet = excel.getSheetAt(1);
			rowCount = 1;
			while(true){
				XSSFRow row = columnSheet.getRow(rowCount);
				
				if(row==null)
					break;
				
				for(int i=0;i<15;i++){
					if(row.getCell(i)!=null)
						row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
				}
				
				//Row with valid table id. Start of a table config
				if(row!=null && row.getCell(0)!=null && row.getCell(0).getStringCellValue().trim().matches("\\d+")){
					
					TableRule tableRule = new TableRule();
					tableRule.setTableId(new Integer(row.getCell(0).getStringCellValue().trim()));
					
					tableRule = rules.get(rules.indexOf(tableRule));
					
					List<ColumnRule> columnRules = getColumnRules(tableRule, columnSheet, rowCount);
					tableRule.setColumnRules(columnRules);
					rowCount += columnRules.size();

				}else
					break;
			}
			
			XSSFSheet headerSheet = excel.getSheetAt(2);
			rowCount = 1;
			while(true){
				XSSFRow row = headerSheet.getRow(rowCount);
				
				if(row==null)
					break;
				
				for(int i=0;i<5;i++){
					if(row.getCell(i)!=null)
						row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
				}
				
				//Row with valid table id. Start of a table config
				if(row.getCell(0)!=null && row.getCell(0).getStringCellValue().trim().matches("\\d+")){
					
					TableRule tableRule = new TableRule();
					tableRule.setTableId(new Integer(row.getCell(0).getStringCellValue().trim()));
					
					tableRule = rules.get(rules.indexOf(tableRule));
					tableRule.setHeaderRules(getHeaderRules(headerSheet, rowCount));
					
					rowCount += tableRule.getHeaderRules().size();
					
				}else
					break;
			}
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return rules;
	}
	
	/**
	 * This fills the list of column rules. Most importantly the data type string is processed into reg-ex based string.
	 * @param sheet Representing column rules
	 * @param rowCount Start row for the column rule set in the sheet
	 * @return
	 */
	public static List<ColumnRule> getColumnRules(TableRule tableRule, XSSFSheet sheet, int rowCount){
		List<ColumnRule> cols = new ArrayList<ColumnRule>();
		
		while(true){
			XSSFRow row = sheet.getRow(rowCount);
			
			//Column Count for the Column ID column
			int colCount=1;
			
			if(row==null)//reached last
				return cols;
			
			for(int i=0;i<15;i++){
				if(row.getCell(i)!=null)
					row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
			}
			
			ColumnRule rule = new ColumnRule();
			cols.add(rule);
			
			String id = row.getCell(colCount).getStringCellValue();
			colCount++;
			
			if(id.contains(".")){
				rule.setId(new Integer(id.split("\\.")[0]));
				rule.setSubId(new Integer(id.split("\\.")[1]));
			
			}else
				rule.setId(new Integer(id));
			
			rule.setHead(row.getCell(colCount)==null || row.getCell(colCount).getStringCellValue()==null ? "" : row.getCell(colCount).getStringCellValue());
			colCount++;
			
			rule.setSubHead(row.getCell(colCount)==null || row.getCell(colCount).getStringCellValue()==null ? "" : row.getCell(colCount).getStringCellValue());
			colCount++;
			
			rule.setBusinessName(row.getCell(colCount)==null || row.getCell(colCount).getStringCellValue()==null ? "" : row.getCell(colCount).getStringCellValue());
			colCount++;
			
			//Convert to appropriate regex
			rule.setDataType(CommonOperations.processDataType(row.getCell(colCount++).getStringCellValue()));
			
			rule.setMultiValue(row.getCell(colCount++).getStringCellValue().equalsIgnoreCase("y"));
			rule.setAlignment(Alignment.getAlignment(row.getCell(colCount++).getStringCellValue()));
			rule.setEmbedded(row.getCell(colCount++).getStringCellValue().equalsIgnoreCase("y"));
			rule.setCompulsory(row.getCell(colCount++).getStringCellValue().equalsIgnoreCase("y"));
			rule.setRowIndicator(row.getCell(colCount++).getStringCellValue().equalsIgnoreCase("y"));
			
			String valign = row.getCell(colCount)==null || row.getCell(colCount).getStringCellValue()==null ? "" : row.getCell(colCount).getStringCellValue();
			colCount++;
			
			if(valign.length()>0)
				rule.setRowVAlignment(Alignment.getAlignment(valign));
			
			String header = rule.getHead().toLowerCase()+" "+rule.getSubHead().toLowerCase();
			header = header.replaceAll("\\s+", " ");
			
			//This is used in the header detection module
			tableRule.getColumnHeadWords().addAll(Arrays.asList(header.split("\\s")));
			tableRule.getColumnHeadWords().add(rule.getHead().toLowerCase());
			tableRule.getColumnHeadWords().add(rule.getSubHead().toLowerCase());
			
			//Break whenever a fresh table id is found
			if(sheet.getRow(rowCount+1)!=null && sheet.getRow(rowCount+1).getCell(0)!=null && 
					sheet.getRow(rowCount+1).getCell(0).getStringCellValue()!=null &&
					sheet.getRow(rowCount+1).getCell(0).getStringCellValue().trim().matches("\\d+")){
				
				break;
			}
			
			rowCount++;
		}
		
		return cols;
	}
	
	/**
	 * 
	 * @param sheet
	 * @param rowCount
	 * @return
	 */
	public static List<HeaderRule> getHeaderRules(XSSFSheet sheet, int rowCount){
		List<HeaderRule> headers = new ArrayList<HeaderRule>();
		
		while(true){
			XSSFRow row = sheet.getRow(rowCount);
			
			if(row==null)
				break;
			
			for(int i=0;i<8;i++){
				if(row.getCell(i)!=null)
					row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
			}
			
			String level = row.getCell(1)==null ? null : row.getCell(1).getStringCellValue().trim();
			
			String header = null;
			if(row.getCell(2)!=null && 
					row.getCell(2).getStringCellValue()!=null && 
					row.getCell(2).getStringCellValue().trim().length()>0){
				
				header = CommonOperations.processDataType(row.getCell(2).getStringCellValue());
			}
			
			String title=null;
			if(row.getCell(3)!=null && 
					row.getCell(3).getStringCellValue()!=null && 
					row.getCell(3).getStringCellValue().trim().length()>0){
				
				title = row.getCell(3).getStringCellValue();
			}
			
			SEARCH_REGION region = null;
			if(row.getCell(4)!=null && 
					row.getCell(4).getStringCellValue()!=null && 
					row.getCell(4).getStringCellValue().trim().length()>0){
				
				region = SEARCH_REGION.getRegion(row.getCell(4).getStringCellValue());
			}
			
			String pattern = null;
			if(row.getCell(5)!=null && 
					row.getCell(5).getStringCellValue()!=null && 
					row.getCell(5).getStringCellValue().trim().length()>0){
				
				pattern = row.getCell(5).getStringCellValue();
			}
			
			String footer = null;
			if(row.getCell(6)!=null && row.getCell(6).getStringCellValue()!=null && row.getCell(6).getStringCellValue().trim().length()>0)
				footer = CommonOperations.processDataType(row.getCell(6).getStringCellValue());
			
			headers.add(new HeaderRule(header, level, title, region, pattern, footer));
			
			//Break whenever a fresh table id is found
			if(sheet.getRow(rowCount+1)!=null && sheet.getRow(rowCount+1).getCell(0)!=null){
				sheet.getRow(rowCount+1).getCell(0).setCellType(Cell.CELL_TYPE_STRING);
				if(sheet.getRow(rowCount+1).getCell(0).getStringCellValue().trim().matches("\\d+"))
					break;
			
			}
			
			rowCount++;
		}
		
		return headers;
	}
	
	private static NearbyTerm getNearByTerm(XSSFRow row){
		for(int i=0;i<8;i++){
			if(row.getCell(i)!=null)
				row.getCell(i).setCellType(Cell.CELL_TYPE_STRING);
		}
		
		int searchId = new Integer(row.getCell(2).getStringCellValue().trim());
		String searchTerm = row.getCell(3).getStringCellValue().trim();
		String searchRegion = row.getCell(4).getStringCellValue().trim();
		String subTitle = row.getCell(5).getStringCellValue().trim();
		String pattern = CommonOperations.processDataType(row.getCell(6).getStringCellValue().trim());
		
		return new NearbyTerm(searchId, searchTerm, subTitle, pattern, SEARCH_REGION.getRegion(searchRegion));
	}
	
	public static void main(String[] args) throws Exception{
		List<TableRule> rules = getTableRules("config/table-config.xlsx");
		System.out.println("done "+rules.size());
	}
}
