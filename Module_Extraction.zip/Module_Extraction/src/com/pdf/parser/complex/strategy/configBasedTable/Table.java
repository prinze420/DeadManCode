package com.pdf.parser.complex.strategy.configBasedTable;

import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.complex.ComplexStructure;
import com.pdf.parser.complex.TableCell;
import com.pdf.parser.utils.Structure_Id;

public class Table implements ComplexStructure {
	
	long id;
	List<DPRectangle> rectangles;
	String stringRepresentation;
	StructureType type;
	int page;
	
	PDFSegment title;
	List<TableCell> cells;
	
	public Table(PDFSegment title, List<TableCell> cells, List<DPRectangle> rectangles,
			String stringRepresentation, StructureType type) {
		
		id = Structure_Id.getInstance().getNext();
		this.title = title;
		this.cells = cells;
		this.rectangles = rectangles;
		this.stringRepresentation = stringRepresentation;
		this.type = type;
	}

	public long getId() {
		return id;
	}

	public List<DPRectangle> getRectangles() {
		return rectangles;
	}

	public PDFSegment getTitle() {
		return title;
	}

	public List<TableCell> getCells() {
		return cells;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public StructureType getType() {
		return type;
	}

	public int getPage() {
		return page;
	}
	
	public float getWidthOfSpace() {
		return cells.get(0).getWidthOfSpace();
	}
}
