package com.pdf.parser.complex.strategy;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFGraphicalLine;

public class GraphicalLinesDetectionStrategy {

	static int threshold=GetCells.grayScaleThreshold;
	static BufferedImage img, oimg;
	static int VerticalGap = 10;
	static List<PDFGraphicalLine> HLine= null;
	static float hRatio=0;
	static float wRatio =0;

	public static List<PDFGraphicalLine> combineNearestLines(List<PDFGraphicalLine> allLines,boolean horizontal) {
		List<PDFGraphicalLine> updatedLines = new ArrayList<PDFGraphicalLine>() ;
		if (horizontal) {
			updatedLines =new ArrayList<PDFGraphicalLine>(allLines);
			for (PDFGraphicalLine line : allLines) {
				if(updatedLines.contains(line))
					for (PDFGraphicalLine innnerLine : updatedLines) {
						if(line!=innnerLine 
								&&(Math.abs(line.getY()-innnerLine.getY())<=10) 
								&& (Math.abs(line.getX()-innnerLine.getX())<=5)
								&& (Math.abs(line.getX2()-innnerLine.getX2())<=5)){
							if(line.getWidth()<innnerLine.getWidth())
								updatedLines.remove(line);
							else
								updatedLines.remove(innnerLine);
							break;
						}
						else if(line!=innnerLine &&(Math.abs(line.getY()-innnerLine.getY())<=5) && (Math.abs(line.getX2()-innnerLine.getX2())<=2)){
							if(line.getWidth()<innnerLine.getWidth())
								updatedLines.remove(line);
							else
								updatedLines.remove(innnerLine);
							break;
						}
					}
			}
		}
		else{
			updatedLines =new ArrayList<PDFGraphicalLine>(allLines);
			for (PDFGraphicalLine line : allLines) {
				if(updatedLines.contains(line))
					for (PDFGraphicalLine innnerLine : allLines) {
						if(line!=innnerLine 
								&&(Math.abs(line.getX()-innnerLine.getX())<=10) 
								&& (Math.abs(line.getY()-innnerLine.getY())<=10)
								&& (Math.abs(line.getY2()-innnerLine.getY2())<=10) ){
							updatedLines.remove(innnerLine);
						}
						/*else if(line!=innnerLine &&(Math.abs(line.getX()-innnerLine.getX())<=5) && (Math.abs(line.getY2()-innnerLine.getY2())<=5)){
						if(line.getWidth()<innnerLine.getWidth())
							updatedHLines.remove(line);
						else
							updatedHLines.remove(innnerLine);
						break;
					}*/
					}
			}
			/*if(updatedVLines!=null && updatedVLines.size()>0){
				if(updatedHLines==null || updatedHLines.size()==0){
					updatedHLines =new ArrayList<PDFGraphicalLine>();
					updatedHLines.addAll(updatedVLines);
				}
				else
					updatedHLines.addAll(updatedVLines);
			}*/
		}

		return updatedLines;
	}

	public  List<DPCell> extractPageCell(int pg, PDPage pdPage, String fileName) throws IOException
	{
		/*-------Get image of pdf page stored in buffer--------*/
		GetCells gc =new GetCells();
		try {
			oimg = pdPage.convertToImage(BufferedImage.TYPE_INT_BGR, 500);//BufferedImage.TYPE_INT_RGB, 500);
			img = oimg;//Thresholding(oimg);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		/*---------Converting image into gray scale then into binary for better line detection ----------*/
		Graphics2D graphics = oimg.createGraphics();
		graphics.drawImage(oimg, 0, 0, null);
		graphics.setColor(Color.RED);
		graphics.setFont(new Font("TimesRoman", Font.BOLD, 28));
		if(pdPage.getBleedBox()!=null){
			hRatio = img.getHeight()/(pdPage.getBleedBox().getHeight());
			wRatio = img.getWidth()/(pdPage.getBleedBox().getWidth()); 
		}
		else if(pdPage.getMediaBox()!=null){
			hRatio = img.getHeight()/(pdPage.getMediaBox().getHeight());
			wRatio = img.getWidth()/(pdPage.getMediaBox().getWidth()); 
		}
		else if(pdPage.getTrimBox()!=null){
			hRatio = img.getHeight()/(pdPage.getTrimBox().getHeight());
			wRatio = img.getWidth()/(pdPage.getTrimBox().getWidth()); 
		}

		List<PDFGraphicalLine> horizontalLines = gc.detectLinesImageBased(img, true);		
		List<PDFGraphicalLine> combinedHorizontalLines = combineNearestHorizontalLines(horizontalLines, VerticalGap);
		
		/*List<PDFGraphicalLine> combinedHLines =combineNearestLines(horizontalLines, true);
		List<PDFGraphicalLine> combinedHorizontalLines = new ArrayList<PDFGraphicalLine>();
		Boolean overLap = false;
		for (int i = 0; i < combinedHLines.size(); i++) {
			if (i>0 ){
				PDFGraphicalLine p1 = combinedHLines.get(i-1);
				PDFGraphicalLine p2 = combinedHLines.get(i);
				if (p2.getY()-p1.getY()<=5) {
					if (overLap) {
						p1 = combinedHorizontalLines.get(combinedHorizontalLines.size()-1);
						PDFGraphicalLine temp = isOverlap(p1, p2);
						if (temp.getX() == p1.getX() && temp.getX2() == p1.getX2()) {
							continue;
						}
						else{
							combinedHorizontalLines.remove(combinedHorizontalLines.size()-1);
							combinedHorizontalLines.add(temp);
							continue;
						}
					}
					combinedHorizontalLines.add(isOverlap(p1, p2));
					overLap = true;
				}
				else if (overLap) {
					overLap = false;
		// *** for Last line*************
					if (i== combinedHLines.size()-1) {
						combinedHorizontalLines.add(combinedHLines.get(i));
					}
					continue;
				}
				else {
					combinedHorizontalLines.add(combinedHLines.get(i-1));
					if (i== combinedHLines.size()-1) {
						combinedHorizontalLines.add(combinedHLines.get(i));
						continue;
					}
				}
			}
		}*/
		List<PDFGraphicalLine> verticalLines =gc.detectLinesImageBased(img, false);
 
		//******** Print horizontal and vertical lines******
//		for (PDFGraphicalLine pdfGraphicalLine : combinedHorizontalLines) {
//			graphics.drawLine((int)pdfGraphicalLine.getX(),(int) pdfGraphicalLine.getY(),(int) pdfGraphicalLine.getX2(),(int) pdfGraphicalLine.getY2());
//		}
//		graphics.setColor(Color.BLUE);
//		for (PDFGraphicalLine pdfGraphicalLine : verticalLines) {
//			graphics.drawLine((int)pdfGraphicalLine.getX(),(int) pdfGraphicalLine.getY(),(int) pdfGraphicalLine.getX2(),(int) pdfGraphicalLine.getY2());
//		}
////		graphics.dispose();
//		ImageIO.write(oimg, "PNG", new File("lines.png"));
//		
		
		// ******Add initial Verticle line***********
		if(GetCells.isAddFirstVerticleLine.equalsIgnoreCase("true")){
			gc.addVirtualLine(combinedHorizontalLines, verticalLines,false);//addRightLine :false
			
			Collections.sort(verticalLines, new Comparator<Object>() {
				public int compare(Object o1, Object o2) {
					PDFGraphicalLine r1 = (PDFGraphicalLine) o1;
					PDFGraphicalLine r2 = (PDFGraphicalLine) o2;
					return Integer.valueOf((int)r1.getX()).compareTo((int)r2.getX());
				}
			});
			
		}
		
		
		
		List<DPCell> pageCells=new ArrayList<DPCell>();
		int  rowCount=0;
		for (int index = 0; index < combinedHorizontalLines.size()-1; index++) {
			/*---------Getting cells for rows i.e. between line 1 and 2 and so on...---------*/
			List<DPRectangle> rectangles = gc.getCellsInHorizontalLines(combinedHorizontalLines,index, verticalLines, img, pg);
			if (!rectangles.isEmpty()) {
				rowCount++;
			}
			/*---------Iterating cells loop with pdf words for given page and getting words lies within boundary formed cells------------*/
			for (int rectIndex = 0; rectIndex < rectangles.size(); rectIndex++) {

				DPRectangle rectangle = rectangles.get(rectIndex);
				//Ignore too largeCells and too small cells
				if (rectangle.getHeight()>img.getHeight()/2 
						||rectangle.getHeight()<img.getHeight()*GetCells.minVerticleLineLengthThreshold 
						|| rectangle.getWidth()<img.getWidth()*GetCells.minLineLengthThreshold
						) {
					continue;
				}
				//*********Draw Cells on Image*************
				if (GetCells.writeImage.equalsIgnoreCase("true")) {
					graphics.drawRect((int) rectangle.getX(), (int) rectangle.getY(), (int) rectangle.getWidth(),(int) rectangle.getHeight());
					graphics.drawChars((rowCount - 1 + "," + rectIndex).toCharArray(), 0,
							(rowCount - 1 + "," + rectIndex).length(),(int) rectangle.getX() + 20,
							(int) rectangle.getY() + 20);
				}
				List<BasicStructure> paraList=new ArrayList<BasicStructure>();
	
				if(rectangle.getHeight()>img.getHeight()/3 ){
					System.out.println("Big size Cell ::Ignore\t"+rectangle.getHeight());
					continue;
				}
				DPCell dc=new DPCell(0, rowCount-1, rectIndex, rectangle, "", "", paraList, 0);
				if(!pageCells.contains(dc))
					pageCells.add(dc);
			}
		}
		graphics.dispose();
		if(GetCells.writeImage.equalsIgnoreCase("true"))
		{
			String imagePath=GetCells.imageProcessingConfig.getString("imagePath");
			File f=new File(fileName);
			String fName=f.getName().substring(0,f.getName().lastIndexOf("."));
			ImageIO.write(oimg, "PNG", new File(imagePath+File.separator+fName+"-"+pg+".png"));
			System.out.println();
		}
		

		for (DPCell dpCell : pageCells) {
			if(dpCell.getRow()==57 && dpCell.getColumn()==3){
				System.out.print("");
			}
			dpCell.getRectangle().setX(dpCell.getRectangle().getX()/wRatio);
			dpCell.getRectangle().setWidth(dpCell.getRectangle().getWidth()/wRatio);
			dpCell.getRectangle().setY((dpCell.getRectangle().getY()+dpCell.getRectangle().getHeight())/hRatio);
			dpCell.getRectangle().setHeight(dpCell.getRectangle().getHeight()/hRatio);
			System.out.print("");
		}
		return pageCells;

	}

	/**
	 * Combines horizontal lines which are close to each other. Closeness is
	 * decided based on vertical gap between lines.
	 * 
	 * @param horizontalLines
	 *            : List of all horizontal lines.
	 * @param yGap
	 *            : Expected vertical gap between two horizontal lines.
	 * @return : List of new horizontal lines.
	 */
	

	public static List<PDFGraphicalLine> combineNearestHorizontalLinesOld(List<PDFGraphicalLine> horizontalLines, int yGap) {
	final int Y1_INITIAL_VALUE = -1;
	final int X1_INITIAL_VALUE = -1;
	final int MINIMUM_HORIZONTAL_LINE_WIDTH = 100;
	final int MINIMUM_HORIZONTAL_LINE_GAP = 70;

	int newX2 = 0;
	int lineIndex = 0;
	int prevX2 = 0;
	int prevY1 = Y1_INITIAL_VALUE;
	int prevX1 = X1_INITIAL_VALUE;
	boolean lineGap = false;
	List<PDFGraphicalLine> newHorizontalLines = new ArrayList<PDFGraphicalLine>();

	for (PDFGraphicalLine line : horizontalLines) {
		if (newHorizontalLines != null 
				&& newHorizontalLines.contains(line)) {
			continue;
		}
		lineIndex++;
		if (prevY1 == Y1_INITIAL_VALUE) {
			prevX1 = (int) line.getX();
			prevY1 = (int) line.getY();
			prevX2 = (int) line.getX2();
		} else {
			if (Math.abs(line.getY() - prevY1) < yGap) {
				if((prevX2 < line.getX()
						&& line.getX()-prevX2 > MINIMUM_HORIZONTAL_LINE_GAP)
						||(line.getX2() < prevX1
								&& prevX1-line.getX2() > MINIMUM_HORIZONTAL_LINE_GAP)
						){
					if (!checkGap(horizontalLines, lineIndex-1, prevX2, (int)line.getX(), prevY1)) {
						System.out.print("");
						int x1 = (int) line.getX();
						int y1 = (int) line.getY();
						int x2 = (int) line.getX2();
						prevX2 = (int) line.getX2();
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
						prevY1 = y1;
						prevX1 = x1;
						newX2 = x2;//0;
						lineGap = true;
						continue;
					}
				}
				
				if (line.getX() < prevX1
						&& !lineGap) {
					prevX1 = (int) line.getX();
					prevY1 = (int) line.getY();
				}
				if (newX2 < line.getX2() 
						&& !lineGap) {
					newX2 = (int) line.getX2();
				}
				if (lineIndex == horizontalLines.size()) // for last line
				{
					line.setX(prevX1);
					line.setX2(newX2);
					line.setY(prevY1);
					line.setY2(prevY1);
					newHorizontalLines.add(line);
				}
			} else if ((line.getY() - prevY1) > yGap) {
				// added NewX2 comparison to
				// avoid continuous lines
				if ((newX2 - prevX1) > MINIMUM_HORIZONTAL_LINE_WIDTH) {
					int x1 = (int) line.getX();
					int y1 = (int) line.getY();
					int x2 = (int) line.getX2();
					prevX2 = (int) line.getX2();
					line.setX(prevX1);
					line.setX2(newX2);
					line.setY(prevY1);
					line.setY2(prevY1);
					newHorizontalLines.add(line);
					prevY1 = y1;
					prevX1 = x1;
					newX2 = x2;//0;
					lineGap = false;
				} else {
					prevY1 = (int) line.getY(); // prevY2 = y2 ;
					prevX1 = (int) line.getX();
					newX2 = (int) line.getX2();//0;// H.getX2();
				}
			}
		}
	}
	return newHorizontalLines;
}
	/**
	 * Combines horizontal lines which are close to each other. Closeness is
	 * decided based on vertical gap between lines.
	 * 
	 * @param horizontalLines
	 *            : List of all horizontal lines.
	 * @param yGap
	 *            : Expected vertical gap between two horizontal lines.
	 * @return : List of new horizontal lines.
	 */
	public static boolean checkGap(List<PDFGraphicalLine> horizontalLines , int index, int start, int end, int prevY) {
		for (int i = index; i < horizontalLines.size(); i++) {
			PDFGraphicalLine l = horizontalLines.get(i);
			if (Math.abs(l.getY() - prevY) < VerticalGap) {
				if (l.getX()> start 
						&& l.getX()<end) {
					return true;		
				}	
				else if (l.getX() < start 
						&& l.getX2() > start) {
					return true;		
				}
			}
		}
		return false;
	}
	
//	public static List<PDFGraphicalLine> combineNearestHorizontalLines(List<PDFGraphicalLine> horizontalLines, int yGap) {
//
//		final int Y1_INITIAL_VALUE = -1;
//		final int X1_INITIAL_VALUE = -1;
//		final int MINIMUM_HORIZONTAL_LINE_WIDTH = 100;
//
//		int newX2 = 0;
//		int lineIndex = 0;
//		int prevY1 = Y1_INITIAL_VALUE;
//		int prevX1 = X1_INITIAL_VALUE;
//		List<PDFGraphicalLine> newHorizontalLines = new ArrayList<PDFGraphicalLine>();
//
//		for (PDFGraphicalLine line : horizontalLines) {
//			lineIndex++;
//			if (prevY1 == Y1_INITIAL_VALUE) {
//				prevX1 = (int) line.getX();
//				prevY1 = (int) line.getY();
//			} else {
//				if (Math.abs(line.getY() - prevY1) < yGap) {
//					if (line.getX() < prevX1) {
//						prevX1 = (int) line.getX();
//						prevY1 = (int) line.getY();
//					}
//					if (newX2 < line.getX2()) {
//						newX2 = (int) line.getX2();
//					}
//					if (lineIndex == horizontalLines.size()) // for last line
//					{
//						line.setX(prevX1);
//						line.setX2(newX2);
//						line.setY(prevY1);
//						line.setY2(prevY1);
//						newHorizontalLines.add(line);
//					}
//				} else if ((line.getY() - prevY1) > yGap) {
//					// added NewX2 comparison to
//					// avoid continuous lines
//					if ((newX2 - prevX1) > MINIMUM_HORIZONTAL_LINE_WIDTH) {
//						int x1 = (int) line.getX();
//						int y1 = (int) line.getY();
//						line.setX(prevX1);
//						line.setX2(newX2);
//						line.setY(prevY1);
//						line.setY2(prevY1);
//						newHorizontalLines.add(line);
//						prevY1 = y1;
//						prevX1 = x1;
//						newX2 = (int) line.getX2();//0;
//					} else {
//						prevY1 = (int) line.getY(); // prevY2 = y2 ;
//						prevX1 = (int) line.getX();
//						newX2 = (int) line.getX2();//0;// H.getX2();
//					}
//				}
//			}
//		}
//		// HLine.subList(i+1, HLine.size()).clear();
//
//		return newHorizontalLines;
//	}

	

	public static BufferedImage Thresholding(BufferedImage img) {
		int newPixel = 0;
		BufferedImage binarize = new BufferedImage(img.getWidth(), img.getHeight(),BufferedImage.TYPE_INT_BGR);
		for(int i=0; i<img.getWidth(); i++)
		{
			for(int j=0; j<img.getHeight(); j++)
			{
				int alpha = new Color(img.getRGB(i, j)).getRed();
				//int gray = gray(i, j);
				if(alpha< threshold)
				{
					newPixel =0;
				}
				else{
					newPixel =255;
				}
				int rgb=new Color(newPixel, newPixel, newPixel).getRGB();
				binarize.setRGB(i, j, rgb);
			}
		}
		return binarize;
	}

	
	public  boolean isTopOverlap(PDFGraphicalLine p1, PDFGraphicalLine p2){
		if (p1.getX()>= p2.getX() && p1.getX2()<=p2.getX2()) {
			return true;
		}
		return false;
	}
	public  boolean isBottomOverlap(PDFGraphicalLine p1, PDFGraphicalLine p2){
		if (p1.getX()<= p2.getX() && p1.getX2()>=p2.getX2()) {
			return true;
		}
		return false;
	}
	public PDFGraphicalLine isOverlap(PDFGraphicalLine p1, PDFGraphicalLine p2) {
		int x1 = 0,y1 = 0,x2 = 0,y2 = 0;
		if (((p1.getX()>= p2.getX() && p1.getX()<p2.getX2())
				||(p1.getX2()> p2.getX() && p1.getX2()<=p2.getX2()))
				|| ((p2.getX()>= p1.getX() && p2.getX()<p1.getX2())
						||(p2.getX2()> p1.getX() && p2.getX2()<=p1.getX2()) )) {
			int overlapWidth = (int) (Math.min(p1.getX2(), p2.getX2()) - Math.max(p1.getX(), p2.getX()));
			if (overlapWidth >= (img.getWidth()*GetCells.minLineLengthThreshold)) {
				x1 = (int) Math.min(p1.getX(), p2.getX());
				x2 = (int) Math.max(p1.getX2(), p2.getX2());
				y1 = y2 = (int) (p1.getY()+((p2.getY()-p1.getY())/2));
			}
		}
		else{
			if (p1.getWidth()> p2.getWidth()) {
				return p1;
			}
			else
				return p2;
		}
		
		return new PDFGraphicalLine(x1, y1, x2, y2, true, null);
	}
	
	public  List<PDFGraphicalLine> combineNearestHorizontalLines(List<PDFGraphicalLine> horizontalLines, int yGap) {

		final int Y1_INITIAL_VALUE = -1;
		final int X1_INITIAL_VALUE = -1;
		final int MINIMUM_HORIZONTAL_LINE_WIDTH = 100;
		final int MINIMUM_HORIZONTAL_LINE_GAP = 70;

		int newX2 = 0;
		int lineIndex = 0;
		int prevX2 = 0;
		int prevY1 = Y1_INITIAL_VALUE;
		int prevX1 = X1_INITIAL_VALUE;
		boolean lineGap = false;
		List<PDFGraphicalLine> newHorizontalLines = new ArrayList<PDFGraphicalLine>();

		for (PDFGraphicalLine line : horizontalLines) {
			if (newHorizontalLines != null 
					&& newHorizontalLines.contains(line)) {
				continue;
			}
			lineIndex++;
			if (prevY1 == Y1_INITIAL_VALUE) {
				prevX1 = (int) line.getX();
				prevY1 = (int) line.getY();
				prevX2 = (int) line.getX2();
			} else {
				if (Math.abs(line.getY() - prevY1) < yGap) {
					if((prevX2 < line.getX()
							&& line.getX()-prevX2 > MINIMUM_HORIZONTAL_LINE_GAP)
							||(line.getX2() < prevX1
									&& prevX1-line.getX2() > MINIMUM_HORIZONTAL_LINE_GAP)
							){
						if (!checkGap(horizontalLines, lineIndex-1, prevX2, (int)line.getX(), prevY1)
								 && newHorizontalLines.size()>0) {
							if (isBottomOverlap(newHorizontalLines.get(newHorizontalLines.size()-1),line)) {
								continue;
							}
							else if (isTopOverlap(newHorizontalLines.get(newHorizontalLines.size()-1),line)) {
								newHorizontalLines.remove(newHorizontalLines.size()-1);
							}
							
							System.out.print("");
							int x1 = (int) line.getX();
							int y1 = (int) line.getY();
							int x2 = (int) line.getX2();
							prevX2 = (int) line.getX2();
							line.setX(prevX1);
							line.setX2(newX2);
							line.setY(prevY1);
							line.setY2(prevY1);
							newHorizontalLines.add(line);
							prevY1 = y1;
							prevX1 = x1;
							newX2 = x2;//0;
							lineGap = true;
							continue;
						}
					}
					
					if (line.getX() < prevX1
							&& !lineGap) {
						prevX1 = (int) line.getX();
						prevY1 = (int) line.getY();
					}
					if (newX2 < line.getX2() 
							&& !lineGap) {
						newX2 = (int) line.getX2();
					}
					if (lineIndex == horizontalLines.size()) // for last line
					{
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
					}
				} else if ((line.getY() - prevY1) > yGap) {
					// added NewX2 comparison to
					// avoid continuous lines
					if ((newX2 - prevX1) > MINIMUM_HORIZONTAL_LINE_WIDTH) {
						
						int x1 = (int) line.getX();
						int y1 = (int) line.getY();
						int x2 = (int) line.getX2();
						prevX2 = (int) line.getX2();
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
						prevY1 = y1;
						prevX1 = x1;
						newX2 = x2;//0;
						lineGap = false;
					} else {
						prevY1 = (int) line.getY(); // prevY2 = y2 ;
						prevX1 = (int) line.getX();
						newX2 = (int) line.getX2();//0;// H.getX2();
					}
				}
			}
		}
		return newHorizontalLines;
	}
	
	public static void main(String[] args) throws Exception{


		try{
			System.out.println("Start");
			String filepath = "C:\\Users\\pg0e1373\\Desktop\\Projects\\pPfizer\\updated\\temp\\input\\2016603482.pdf";
			int pg=1;
//			File file =new File(filepath);
			GraphicalLinesDetectionStrategy obj = new GraphicalLinesDetectionStrategy();
			PDDocument pdf = PDDocument.load(filepath);
//			for (int pg = 0; pg < pdf.getDocumentCatalog().getAllPages().size(); pg++) {
				PDPage page = (PDPage) pdf.getDocumentCatalog().getAllPages().get(pg);
				long start = System.currentTimeMillis();
				List<DPCell> pageResult = obj.extractPageCell(pg,page,filepath);
				System.out.println((System.currentTimeMillis()-start)/1000.0);
				System.out.println(pageResult.size()+ " -by GetCell method");
//			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

	}

}
