package com.pdf.parser.complex.strategy;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFVerticalGap;
import com.pdf.parser.complex.PDFTable;
import com.pdf.parser.pipeline.DefaultParser;

public class PDFTableFromNumberColumnStrategy implements Strategy<List<PDFTable>>{
	
	List<PDFSegment> segments;
	List<PDFVerticalGap> vgaps;
	List<PDFTable> tables;
	
	public static void main(String[] args) throws Exception {
		
		int page = 9;
		
		DefaultParser p = new DefaultParser(PDDocument.load(new File("19952290.pdf")));
		p.parse();
		
		PDFTableFromNumberColumnStrategy s = new PDFTableFromNumberColumnStrategy(p.getSegments().get(page-1), p.getVgaps().get(page-1));
		s.apply();
	}
	
	public PDFTableFromNumberColumnStrategy(List<PDFSegment> segments, List<PDFVerticalGap> vgaps) {
		this.segments = segments;
		this.vgaps = vgaps;
		tables = new ArrayList<PDFTable>();
		
//		for(PDFSegment seg : segments)
//			System.out.println(seg.getStringRepresentation());
		
//		for(PDFVerticalGap vgap : vgaps)
//			System.out.println(vgap);
//		
//		System.out.println("***************");
	}
	
	@Override
	public void apply() {
		Map<PDFVerticalGap, List<PDFVerticalGap>> numericalColumns = getNumericalColumns();
		
		//Let's find the longest column
		PDFVerticalGap longest = null;
		for(PDFVerticalGap head : numericalColumns.keySet()){
			if(numericalColumns.get(head).size()>0){
				if(longest == null || numericalColumns.get(head).size() > numericalColumns.get(longest).size())
					longest = head;
			}
		}
		
		//Find vgaps that overlap with the longest along y-axis
		
		//Accordingly compose the table cells
	}
	
	/**
	 * Find out the vgap that has a number on its right
	 * Find the next vgap that also has a number on its right and has the same width as the first vgap such that it coincides
	 * Make sure there is no segment intersecting between the top of both vgaps
	 */
	public Map<PDFVerticalGap, List<PDFVerticalGap>> getNumericalColumns(){
		String numberPattern = "\\(?(�|$|-)?\\d+((\\,\\s*\\d+){0,})?(\\.\\s*\\d+)?(%)?\\)?";
		Map<PDFVerticalGap, List<PDFVerticalGap>> vgapColumnTracker = new HashMap<PDFVerticalGap, List<PDFVerticalGap>>();
		Set<PDFVerticalGap> vgapTrack = new HashSet<PDFVerticalGap>();
		
//		for(PDFVerticalGap vgap : vgaps)
//			System.out.println(vgap.getWord2().getStringRepresentation());
//		
//		System.out.println("**********");
		
		for(int i=0; i<vgaps.size(); i++){
			PDFVerticalGap vgap1 = vgaps.get(i);
			boolean isColumn = vgapColumnTracker.containsKey(vgap1);
			
//			if(vgap1.getWord2().getStringRepresentation().contains("873"))
//				System.out.println("debug");
			
			if(vgap1.getWord2().getStringRepresentation().matches(numberPattern)){
				
				for(int j=i+1; j<vgaps.size(); j++){
					PDFVerticalGap vgap2 = vgaps.get(j);
					
//					if(vgap2.getWord2().getStringRepresentation().contains("2,858"))
//						System.out.println("debug");
					
					if(!vgapTrack.contains(vgap2)
							&& vgap2.getWord2().getStringRepresentation().matches(numberPattern) 
							&&	vgap1.getBottomWord().equals(vgap2.getBottomWord())
							&& vgap1.getRectangle().getX()>=vgap2.getRectangle().getX()-5 && vgap1.getRectangle().getX2()<=vgap2.getRectangle().getX2()+5){
						
						List<PDFVerticalGap> vgaps = null;
						if(!isColumn){
							vgaps = new ArrayList<PDFVerticalGap>();
							vgapColumnTracker.put(vgap1, vgaps);
							isColumn = true;
						
						}else
							vgaps = vgapColumnTracker.get(vgap1);
						
						//Check if atleast one word2 in vgaps has an overlap with the new vgap2-word2
						boolean overlap = vgaps.size() == 0 ? true : false;
						for(PDFVerticalGap existingVgap : vgaps){
							float ex = existingVgap.getWord2().getRectangle().getX(), ex2 = existingVgap.getWord2().getRectangle().getX2();
							float nx = vgap2.getWord2().getRectangle().getX(), nx2 = vgap2.getWord2().getRectangle().getX2();
							
							if(nx>=ex && nx<ex2)
								overlap = true;
							
							else if(nx2>ex && nx2<=ex2)
								overlap = true;
							
							else if(nx<=ex && nx2>=ex2)
								overlap = true;
							
							if(overlap)
								break;
						}
						
						if(overlap){
							vgaps.add(vgap2);
							vgapTrack.add(vgap2);
						}
					}
				}
			}
		}
		
//		for(PDFVerticalGap key : vgapColumnTracker.keySet()){
//			System.out.println(key.getWord2().getStringRepresentation()+": ("+vgapColumnTracker.get(key).size()+")");
//			for(PDFVerticalGap child : vgapColumnTracker.get(key)){
//				System.out.println(child.getWord2().getStringRepresentation());
//			}
//			System.out.println("\n");
//		}
		
//		System.out.println("Done");
		return vgapColumnTracker;
	}
	
	@Override
	public List<PDFTable> getOutcome() {
		return tables;
	}
}
