package com.pdf.parser.complex.strategy.configBasedTable;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.Structure;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.complex.TableCell;
import com.pdf.parser.complex.strategy.configBasedTable.rules.Alignment;
import com.pdf.parser.complex.strategy.configBasedTable.rules.TableRule;
import com.pdf.parser.complex.strategy.configBasedTable.rules.TableRuleReader;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;

public class TableProcessor {
	
	List<PDFSegment> segments;
	List<TableRule> rules;
	
	public TableProcessor(List<PDFSegment> segments, List<TableRule> rules){
		this.segments = segments;
		this.rules = rules;
	}
	
	public List<Table> processTables(){
		List<Table> tables = new ArrayList<Table>();
		
		//****Grouping of segments based on y
		List<StructureGroup> segmentPerY = CommonOperations.groupStructuresOnY(segments);
		//***********************
		
		//*****Find the correct headers by splitting segments if necessary
		HeaderDetection hd = new HeaderDetection(0, segments, rules.get(7), segmentPerY);
		hd.detect();
		
		List<Structure> headerStructures = new ArrayList<Structure>(CommonOperations.yxSort(hd.getHeaders(), true, 0));
		List<TableCell> headers = new ArrayList<TableCell>();
		for(Structure s : headerStructures)
			headers.add((TableCell)s);
		//*******************************************
		
		//Atleast one header is present
		if(headers.size()>0){
			//The start of value rows
			int nextStart = hd.getSearchStart();
			
			//Get headers removed
			segmentPerY = hd.getSegmentPerY();
			
			//Split segments for each known column-header
			Map<PDFSegment, List<PDFSegment>> splitTracker = splitSegmentsOnRules(segmentPerY, headers, nextStart);
			
			List<TableCell> rowIndicators = new ArrayList<TableCell>();
			for(TableCell head : headers){
				if(head.getRule().isRowIndicator())
					rowIndicators.add(head);
			}
			
			//Find y-delimiters for each row
			Set<Float> rowBoundaries = getRowBoundaries(nextStart, segmentPerY, rowIndicators, headers);
			
			//Add some tolerance to rowBoundaries
			Set<Float> temp = new HashSet<Float>(rowBoundaries);
			rowBoundaries.clear();
			for(Float f : temp)
				rowBoundaries.add(f+2);
			
			//Form table cells based on respective data-types for known headers and create a map of cells contained per row
			Map<Float, List<TableCell>> rows = getRowsBasedOnHeads(segmentPerY, headers, rowBoundaries);
			
			//Sort the rows
			for(List<TableCell> row : rows.values()){
				Collections.sort(row, new Comparator<TableCell>() {
					@Override
					public int compare(TableCell o1, TableCell o2) {
						return Float.valueOf(o1.getRectangles().get(0).getX()).compareTo(o2.getRectangles().get(0).getX());
					}
				});
			}
			
			System.out.println("debug");
		}
		
		return tables;
	}
	
	/**
	 * Splits the segments based on data type and adjust the segment groups
	 * @param segmentsPerY
	 * @param headers
	 * @return Map to track which segments were broken. This will help us modify the original list of segments eventually
	 */
	private Map<PDFSegment, List<PDFSegment>> splitSegmentsOnRules(List<StructureGroup> segmentsPerY, List<TableCell> headers, int start){
		
		Map<PDFSegment, List<PDFSegment>> splitTracker = new HashMap<PDFSegment, List<PDFSegment>>();
		
		head:
		for(int i=0; i<headers.size(); i++){
			TableCell head = headers.get(i);
			
			for(int j=start; j<segmentsPerY.size(); j++){
				for(PDFSegment seg : segmentsPerY.get(j).getCastedPDFSegments()){
					
					if(CommonOperations.isAligned(headers, head, seg)){
						
						if(!seg.getStringRepresentation().trim().matches(head.getRule().getDataType())){
							//Now that segment does not match, let's see if it starts with the appropriate pattern
							Pattern p = Pattern.compile(head.getRule().getDataType());
							Matcher m = p.matcher(seg.getStringRepresentation().trim());
							while(m.find()){
								
								if(m.group().trim().length()==0)
									continue;
								
								//Segment breaking happens on start or end match
								if(seg.getStringRepresentation().startsWith(m.group()) || 
										seg.getStringRepresentation().endsWith(m.group())){
									
									List<PDFSegment> broken = seg.breakSegment(m.group());
									if(broken.size()==2)
										splitTracker.put(seg, broken);
									
									continue head; //Only one segment may be broken per head, hence move to next column head
								}
							}
						}
					}
				}
			}
		}
		
		//Adjust segmentsPerY accordingly
		for(PDFSegment seg : splitTracker.keySet()){
			for(StructureGroup sg : segmentsPerY){
				if(sg.contains(seg)){
					List<PDFSegment> split = splitTracker.get(seg);
					int index = sg.indexOf(seg);
					
					List<PDFSegment> segs = sg.getCastedPDFSegments();
					segs.set(index, split.get(0));
					segs.add(index+1, split.get(1));
					sg.setSegments(segs);
				}
			}
		}
		
		return splitTracker;
	}
	
	//Row boundary are the y-delimiters for each row
	public Set<Float> getRowBoundaries(int nextStart, List<StructureGroup> segmentPerY, 
				List<TableCell> rowIndicators, List<TableCell> headers){
		
		Set<Float> rowBoundaries = new TreeSet<Float>();
		
		//Keep track of last segmentPerY for Align Mid calculation
		int k=-1;
		
		nextY:
		for(int i=nextStart; i<segmentPerY.size(); i++){
			List<PDFSegment> commonYSegments = segmentPerY.get(i).getCastedPDFSegments();
			
			for(PDFSegment seg : commonYSegments){
				for(TableCell head : rowIndicators){
					
					//Segment should be properly aligned and should match the data type reg-ex
					if(CommonOperations.isAligned(headers, head, seg) &&
							seg.getStringRepresentation().trim().matches(head.getRule().getDataType())){
						
						if(head.getRule().getRowVAlignment() == Alignment.Top)
							rowBoundaries.add(findLeastY2(commonYSegments));
						
						else if(head.getRule().getRowVAlignment() == Alignment.Bottom)
							rowBoundaries.add(findMaxY(commonYSegments));
						
						else{ //Middle aligned
							float mid = seg.getRectangle().getY2() + (seg.getRectangle().getHeight()/2f);
							
							//If this is the first iteration, take the top group of segments after headers
							//Or else take the next segment based on last iteration
							int start = k==-1 ? nextStart : k;
							StructureGroup first = segmentPerY.get(start);
							
							//Find the least y2 among the first group of segments
							float top = findLeastY2(first.getCastedPDFSegments());
							float topHalf = mid - top;
							float bottom = mid + topHalf;
							
							//Find the segment that is just above the bottom half 
							int j=-1;
							for(j=i+1; j<segmentPerY.size(); j++){
								List<PDFSegment> nextSegs = segmentPerY.get(j).getCastedPDFSegments(); 
								if(findLeastY2(nextSegs)>bottom){
									j--;
									break;
								}
							}
							
							rowBoundaries.add(findMaxY(segmentPerY.get(j).getCastedPDFSegments()));
							
							k=j+1;
						}
						
						continue nextY;
					}
				}
			}
		}
		
		return rowBoundaries;
	}
	
	private Map<Float, List<TableCell>> getRowsBasedOnHeads(List<StructureGroup> segmentPerY, List<TableCell> headers, Set<Float> rowBoundaries){
		Map<Float, List<TableCell>> rows = new TreeMap<Float, List<TableCell>>();
		
		for(StructureGroup sg : segmentPerY){
			
			nextSeg:
			for(PDFSegment seg : sg.getCastedPDFSegments()){
				
//				if(seg.getStringRepresentation().equals("CTS CLG:00121"))
//					System.out.println("debug");
				
				for(TableCell head : headers){
					if(seg.getRectangle().getY2()>head.getRectangles().get(0).getY() && CommonOperations.isAligned(headers, head, seg)){
						
						for(float boundary : rowBoundaries){
							if(seg.getRectangle().getY() <= boundary){
								
								List<TableCell> row = rows.get(boundary);
								if(row == null){
									row = new ArrayList<TableCell>();
									rows.put(boundary, row);
								}
								
								List<PDFSegment> existingSegments = new ArrayList<PDFSegment>();
								int index = -1;
								for(int i=0; i<row.size(); i++){
									TableCell c = row.get(i);
									if(c.getRule().equals(head.getRule())){
										existingSegments.addAll(c.getSegments().get(0));
										index = i;
										break;
									}
								}
								
								if(index == -1){
									row.add(TableCell.create(Arrays.asList(seg), head.getRule(), true));
								
								}else{
									existingSegments.add(seg);//Add one more segment to the cell
									row.set(index, TableCell.create(existingSegments, head.getRule(), true));//recreate the cell
								}
								
								continue nextSeg;
							}
						}
					}
				}
			}
		}
		
		return rows;
	}
	
	public static void main(String[] args) throws Exception{
		int page = 1;
		
		List<TableRule> rules = TableRuleReader.getTableRules("config/table-config.xlsx");
		
		DefaultParser parser = new DefaultParser(PDDocument.load(new File("D:\\SI-Extraction Framework Test\\Bank Statements\\Bank\\CITY_UNION.PDF")), Arrays.asList(page));
		parser.parse();
		
		TableProcessor processor = new TableProcessor(parser.getSegments().get(page), rules);
		processor.processTables();
	}
	
	/**
	 * Find the titles on the current page
	 * @param title
	 * @return the indexes of titles found.
	 */
	public List<Integer> findTitleSegments(String title){
		List<Integer> indexes = new ArrayList<Integer>();
		
		for(int i=0; i<segments.size(); i++){
			if(segments.get(i).getStringRepresentation().equalsIgnoreCase(title))
				indexes.add(i);
		}
		
		return indexes;
	}
	
	private float findLeastY2(List<PDFSegment> segments){
		float min = Float.MAX_VALUE;
		
		for(PDFSegment s : segments){
			if(s.getRectangle().getY2() < min)
				min = s.getRectangle().getY2();
		}
		
		return min;
	}
	
	private float findMaxY(List<PDFSegment> segments){
		float max = 0;
		
		for(PDFSegment s : segments){
			if(s.getRectangle().getY() > max)
				max = s.getRectangle().getY();
		}
		
		return max;
	}
}
