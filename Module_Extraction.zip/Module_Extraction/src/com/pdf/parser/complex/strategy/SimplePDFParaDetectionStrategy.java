package com.pdf.parser.complex.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.Strategy;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.CommonOperations.DIRECTION;
import com.pdf.parser.utils.CommonOperations.SORT_CRITERIA;

public class SimplePDFParaDetectionStrategy implements Strategy<List<PDFPara>> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("complex-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	List<PDFPara> paras;
	List<StructureGroup> groups;
	
	//Merge factor for successive segments
	//Factor as a product with the height of the initial segment 
	public static final float yDiffFactor = new Float(config.getString("verticalSegmentMerge"));
	
	/*
	 * Create paras simple from left to right and top to bottom. Merge lines if they are vertically under the threshold.
	 * No merging of paras across pages
	 */
	
	public SimplePDFParaDetectionStrategy(List<StructureGroup> groups){
		this.groups = groups;
		paras = new ArrayList<PDFPara>();
	}
	
	public void apply() {
		
		List<BasicStructure> temp = new ArrayList<BasicStructure>();
		for(StructureGroup grp : groups){
			for(BasicStructure s:grp.getBasicStructures()){
				
				//First segment for a para
				if(temp.size()==0){
					temp.add(s);
					continue;
				}
				
				BasicStructure last = temp.get(temp.size()-1);
				if(isEligible(last, s))
					temp.add(s);
				
				else{//Make a para with whatever we got
					paras.add(create(temp));
					temp.clear();
					temp.add(s);
				}
			}
		}
		
		//Whatever is remaining
		if(temp.size()>0)
			paras.add(create(temp));
	}
	
	private static boolean isEligible(BasicStructure s1, BasicStructure s2){
		float y1 = s1.getRectangle().getY();
		float y2 = s2.getRectangle().getY2();
		float h = s1.getRectangle().getHeight();
		float diff = y2-y1;
		
		return diff < h*yDiffFactor;
	}
	
	public static PDFPara create(List<BasicStructure> segments){
		
		List<BasicStructure> xSorted = CommonOperations.sort(segments, SORT_CRITERIA.X, DIRECTION.MIN);
		float x = xSorted.get(0).getRectangle().getX();
		
		List<BasicStructure> x2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.X2, DIRECTION.MAX);
		float x2 = x2Sorted.get(0).getRectangle().getX2();
		
		List<BasicStructure> ySorted = CommonOperations.sort(segments, SORT_CRITERIA.Y, DIRECTION.MAX); //Y increases as origin is top-left
		float y = ySorted.get(0).getRectangle().getY();
		
		List<BasicStructure> y2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.Y2, DIRECTION.MIN); //Y2 decreases as origin is top-left
		float y2 = y2Sorted.get(0).getRectangle().getY2();
		
		float w = x2 - x;
		float h = y - y2;
		
		int page = segments.get(0).getRectangle().getPage();
		
		List<DPRectangle> rects = new ArrayList<DPRectangle>();
		rects.add(new DPRectangle(x, y, w, h, page));
		
		Map<Integer, List<BasicStructure>> pageWiseSegments = new TreeMap<Integer, List<BasicStructure>>();
		pageWiseSegments.put(page, new ArrayList<BasicStructure>(segments));
		
		PDFPara para = new PDFPara(rects, pageWiseSegments, StructureType.PARA); 
		
		return para;
	}

	@Override
	public List<PDFPara> getOutcome() {
		return paras;
	}
	
	public static void main(String[] args) throws Exception{
		DefaultParser p = new DefaultParser(PDDocument.load(new File("SwissRe-Sample/AWD100184/email.pdf")));
		p.parse();
		
		SimplePDFParaDetectionStrategy s = new SimplePDFParaDetectionStrategy(CommonOperations.groupStructuresOnY(p.getSegments().get(0)));
		s.apply();
		
		System.out.println(s.getOutcome());
	}
}
