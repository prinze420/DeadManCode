package com.pdf.parser.complex.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.pdf.parser.Strategy;
import com.pdf.parser.Structure;
import com.pdf.parser.StructureType;
import com.pdf.parser.complex.HierarchyNode;

public class PDFHierarchyCreationStrategy implements Strategy<HierarchyNode> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("complex-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	List<Structure> structures;
	HierarchyNode root;
	
	public PDFHierarchyCreationStrategy(List<Structure> structures) {
		this.structures = structures;
		root = new HierarchyNode(StructureType.HIERARCHY);
	}

	@Override
	public void apply() {
		
	}

	@Override
	public HierarchyNode getOutcome() {
		return root;
	}
	
}
