package com.pdf.parser.complex.strategy;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFGraphicalLine;
import com.pdf.parser.complex.strategy.GeneralUtility;


/**
 * Updated code changes required to handle merged black cells
 * 21-Feb-2017
 * @author sk0e1284
 *
 */
public class CellDetector {
	
	public static List<DPRectangle> getCellsInHorizontalLines(List<PDFGraphicalLine> horizontalLines, 
			 int index,List<PDFGraphicalLine> verticalLines, BufferedImage bufferedImage, int pgNum) {
		float prevX1 = 0, prevY1 = 0;
		int i = 0;

		List<DPRectangle> RowId = new ArrayList<DPRectangle>();

		for (int a = 0; a<horizontalLines.size(); a++ ) {
			PDFGraphicalLine hline = horizontalLines.get(a);
			
			if (index - 1 == a) {
				prevY1 = hline.getY();

			} else if (index == a) {

				for (PDFGraphicalLine vline : verticalLines) {
					DPRectangle rectangle = new DPRectangle(0, 0, 0, 0, pgNum);
					if (prevX1 == 0) {
						prevX1 = vline.getX();
					}

					if (Math.abs(bufferedImage.getWidth() - vline.getX()) < 15
							&& (hline.getY() > vline.getY() || Math.abs(vline.getY() - hline.getY()) < 20)
							&& vline.getY() - prevY1 < 20
							&& (hline.getY() < vline.getY2() || Math.abs(vline.getY2() - hline.getY()) < 30)
							&& (prevX1 < vline.getX() || Math.abs(hline.getX() - vline.getX()) < 10)
							&& (vline.getX() < hline.getX2() || Math.abs(vline.getX() - hline.getX2()) < 20)
							&& vline.getX2() - prevX1 > 20) {

						int x1 = (int) prevX1;
						int x2 = (int) vline.getX();
						int y1 = (int) prevY1;
						int y2 = (int) hline.getY();
						prevX1 = vline.getX();
						
						rectangle.setX(x1);
						rectangle.setY(y1);
						rectangle.setWidth(x2 - x1);
						rectangle.setHeight(y2 - y1);
						RowId.add(rectangle);
						i = 0;
						break;
					}

					if (prevX1 != 0 && (hline.getY() > vline.getY() || Math.abs(vline.getY() - hline.getY()) < 20)
							&& vline.getY() - prevY1 < 20
							&& (hline.getY() < vline.getY2() || Math.abs(vline.getY2() - hline.getY()) < 30)
							&& (prevX1 < vline.getX() || Math.abs(hline.getX() - vline.getX()) < 10)
							&& (vline.getX() < hline.getX2() || Math.abs(vline.getX() - hline.getX2()) < 20)
							&& vline.getX2() - prevX1 > 20) {
						i++;
						/*if (RowId.size()>0) {
							int count1 = GeneralUtility.compare((int)vline.getX() - 12, (int)hline.getY() - 26, 6, 20, bufferedImage);
							int count2 = GeneralUtility.compare((int)vline.getX() + 3, (int)hline.getY() - 26, 6, 20, bufferedImage);

							if (count2 > 80 || count1 > 80) {*/
								int x1 = (int)prevX1;
								int x2 = (int)vline.getX();
								int y1 = (int)prevY1;
								int y2 = (int)hline.getY();
								prevX1 = vline.getX();
								
								rectangle.setX(x1);
								rectangle.setY(y1);
								rectangle.setWidth(x2 - x1);
								rectangle.setHeight(y2 - y1);
								
								RowId.add(rectangle);
								i = 0;
							/*}
							else{
								int x1 = (int)prevX1;
								int x2 = (int)vline.getX();
								int y1 = (int)prevY1;
								int y2 = (int)hline.getY();
								prevX1 = vline.getX();
							
								rectangle.setX(x1);
								rectangle.setY(y1);
								rectangle.setWidth(x2 - x1);
								rectangle.setHeight(y2 - y1);
								
								RowId.add(rectangle);
								i = 0;
							}
						}*/
						
					}
				}
				prevY1 = hline.getY();
				break;
			}
		}
		return RowId;
	}

}