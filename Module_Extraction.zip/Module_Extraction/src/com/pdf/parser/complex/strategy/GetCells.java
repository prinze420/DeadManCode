package com.pdf.parser.complex.strategy;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;
import java.util.Set;

import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFGraphicalLine;
import com.pdf.parser.base.Pixel;


public class GetCells {//GraphicalCellGenerationStrategy
	//imageProcessingParameters.properties
	static ResourceBundle imageProcessingConfig;
	static{
		try {
			imageProcessingConfig = ResourceBundle.getBundle("imageProcessingParameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	public static float minLineLengthThreshold=Float.valueOf(imageProcessingConfig.getString("minLineLengthThreshold"));
	public static float minVerticleLineLengthThreshold=Float.valueOf(imageProcessingConfig.getString("minVerticleLineLengthThreshold"));
	public static int grayScaleThreshold=Integer.valueOf(imageProcessingConfig.getString("grayScaleThreshold"));
	public static String isAddFirstVerticleLine=imageProcessingConfig.getString("isAddFirstVerticleLine");
	public static String writeImage=imageProcessingConfig.getString("writeImage");
	public static List<PDFGraphicalLine> detectLinesImageBased(BufferedImage img,boolean horizontal){
		List<PDFGraphicalLine> lines = new ArrayList<PDFGraphicalLine>();

		//		Raster raster = img.getData();

		//**********Decide how to parse the pixel matrix based on whether to extract horizontal/vertical line
		int outer = horizontal ? img.getHeight() : img.getWidth();
		int inner = horizontal ? img.getWidth() : img.getHeight();
		int minLineLength = (int)(horizontal ? img.getWidth()*(minLineLengthThreshold) : img.getHeight()*(minVerticleLineLengthThreshold));
		minLineLength = (int)(horizontal ? minLineLength : minLineLength);
		//***************************************

		//************Detect lines
		for(int i=0;i<outer;i++){

			PDFGraphicalLine line = null;
			for(int j=0;j<inner;j++){


				int x = horizontal ? j : i;
				int y = horizontal ? i : j;
//				Color color = new Color(img.getRGB(x, y));
//				int[] pixel = {color.getRed() ,color.getGreen(),color.getBlue(),color.getAlpha()} ;
//
//				Pixel pix = new Pixel(pixel , x, y);
				//				Pixel pix = new Pixel(raster.getPixel(x, y, new int[4]),x,y);

				if(new Color(img.getRGB(x, y)).getRed()>grayScaleThreshold){//pix.isWhite()){//Ignore white pixels and treat them as breaking points between lines

					if(line!=null){
						float start = horizontal ? line.getX() : line.getY();
						float end = horizontal ? line.getX2() : line.getY2();

						if((int)(end-start)>=minLineLength){//The line is actually created in the else part below

							//##########Find the max color for line
//							HashMap<Pixel, Integer> pxCounts = new HashMap<Pixel,Integer>();
//							for(float a=line.getX();a<=line.getX2();a++){
//								for(float b=line.getY();b<=line.getY2();b++){
//
//									Color c = new Color(img.getRGB((int)a, (int)b));
//									int[] pi = {c.getRed() ,c.getGreen(),c.getBlue(),c.getAlpha()} ;
//
//									Pixel p = new Pixel(pi,a,b);
//
//									//									Pixel p = new Pixel(raster.getPixel((int)a, (int)b, new int[4]),a,b);
//									if(pxCounts.containsKey(p)){
//										pxCounts.put(p, pxCounts.get(p)+1);
//									}else{
//										pxCounts.put(p, 1);
//									}
//								}
//							}
//
//							Pixel max = null;
//							int count = 0;
//							for(Pixel key : pxCounts.keySet()){
//								if(max==null){
//									max = key;
//									count = pxCounts.get(max);
//									continue;
//								}
//
//								if(pxCounts.get(key) > count){
//									max = key;
//									count = pxCounts.get(max);
//								}
//							}
//
//							line.setColor(max);
							line.setHorizontal(horizontal);
							//#####################################
							lines.add(line);
						}
					}

					line = null;
					continue;

				}else{//For any non-white pixel append it to the line, thereby extending its length
					if(line==null){
						line = new PDFGraphicalLine(x,y,0,0,true,null);//pix.getX(),pix.getY(),0,0,true,pix);
						continue;
					}
//					line.setX2(pix.getX());
//					line.setY2(pix.getY());
					line.setX2(x);
					line.setY2(y);
				}
				if(horizontal== true && line.getX2()-line.getX()> minLineLength && x==img.getWidth()-1)
				{
					lines.add(line);
				}

			}

		}

		return lines;
	}

	public static List<DPRectangle> getCellsInHorizontalLines(List<PDFGraphicalLine>horizontalLine, int index, //Line currentHorizontalLine, Line previousHorizontalLine,
			List<PDFGraphicalLine> verticalLines, BufferedImage img, int pgNum) 
	{
		int i = 0;
		PDFGraphicalLine currentHorizontalLine = null;
		PDFGraphicalLine nextHorizontalLine1 = horizontalLine.get(index+1);
		PDFGraphicalLine previousHorizontalLine = horizontalLine.get(index);
		PDFGraphicalLine nextHorizontalLine2 = null;
		List<DPRectangle> rectangles = new ArrayList<DPRectangle>();
		PDFGraphicalLine previousVerticalLine = null;
		Boolean isSpan = false;
		Boolean flag2 = true;
		Boolean checkCell = false;
		int newIndex;

		for (PDFGraphicalLine currentVerticalLine : verticalLines) {
			DPRectangle rectangle = new DPRectangle(0, 0, 0, 0, pgNum);
			if (previousVerticalLine == null) {
				if((currentVerticalLine.getY() <= previousHorizontalLine.getY() 
						|| Math.abs(currentVerticalLine.getY() -previousHorizontalLine .getY()) <10)
						){
					previousVerticalLine = currentVerticalLine;
				}
				else{
					previousVerticalLine = null;
					continue;
				}
				//				previousVerticalLine = currentVerticalLine;
			}


			if(flag2 && !isSpan)
			{
				if( //currentHorizontalLine != nextHorizontalLine1
						//						&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
						//						&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
						Math.abs(previousHorizontalLine.getX() - nextHorizontalLine1.getX()) <10 
						&& nextHorizontalLine1.getY()>previousHorizontalLine.getY()
						|| (nextHorizontalLine1.getX()<previousHorizontalLine.getX()
								&& nextHorizontalLine1.getX2()>previousHorizontalLine.getX() ))
				{
					isSpan = false;
					currentHorizontalLine = nextHorizontalLine1;
				}
				else 
				{
					for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								//								&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
								//								&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
						{
							isSpan = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}
			else if (!isSpan && rectangles.size()!=0)
			{	
				for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
				{
					nextHorizontalLine2 = horizontalLine.get(newIndex);
					//					if(Math.abs(previousHorizontalLine.getX2() - nextHorizontalLine2.getX2()) <10 )
					if(rectangles.get(rectangles.size()-1).getX()!=0
							&&(rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) >= nextHorizontalLine2.getX()
							//							&& Math.abs(rectangles.get(rectangles.size()-1).getX2() - nextHorizontalLine2.getX2()) >15 )
							//							&& nextHorizontalLine2.getX2()-currentVerticalLine.getX()>=1)
							&& nextHorizontalLine2.getX2() - (rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) > 10 )

					{
						isSpan = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else if (rectangles.get(rectangles.size()-1).getX()==0
							&& nextHorizontalLine2.getX()==nextHorizontalLine2.getX()) {
						isSpan = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else continue;
				}
			}

			if (	previousVerticalLine != null && currentHorizontalLine!=null
					&& previousVerticalLine != currentVerticalLine 
					//					&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20
					) {
				checkCell = true;
				if (currentHorizontalLine.getX2() < currentVerticalLine.getX() 
						&& currentHorizontalLine == nextHorizontalLine1) {
					for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
								&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
						{
							isSpan = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}


			if (currentHorizontalLine!=null 
					&& currentVerticalLine!=null 
					&& previousVerticalLine!=null 
					&& previousHorizontalLine !=null //added by Bharat
					&& Math.abs(img.getWidth() - currentVerticalLine.getX()) < 15
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20) {

				int x1 = (int)previousVerticalLine.getX();
				int x2 = (int)currentVerticalLine.getX();
				int y1 = (int)previousHorizontalLine.getY();
				int y2 = (int)currentHorizontalLine.getY();
				previousVerticalLine = currentVerticalLine;
				//rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);

				rectangle.setX(x1);
				rectangle.setY(y1);
				rectangle.setWidth(x2 - x1);
				rectangle.setHeight(y2 - y1);

				rectangles.add(rectangle);
				i = 0;
				//newly added logic
				if(Math.abs(x2- nextHorizontalLine1.getX2())<10){
					currentHorizontalLine= null;
					flag2 = false;
					continue;
				}
				else
					break;

			}
			
			/*else if (!checkCell) {
				continue;
			}*/

			else if (checkCell && previousVerticalLine != null && currentHorizontalLine!=null
					//						&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20)// &&
			{

				i++;
//				if (i >= 1) {
//					int count1 = 0;
//					int count2 = 0;
//					count1 = GeneralUtility.compare((int)currentVerticalLine.getX() - 12, 
//							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
//					count2 = GeneralUtility.compare((int)currentVerticalLine.getX() + 5, 
//							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
//
//					if (count2 > 80 || count1 > 80) {
						int x1 = (int) previousVerticalLine.getX();
						int x2 = (int)currentVerticalLine.getX();
						int y1 = (int)previousHorizontalLine.getY();
						int y2 = (int)currentHorizontalLine.getY();

						if(x1<previousHorizontalLine.getX()&& previousHorizontalLine.getX()-x1 >20)// Math.abs(x1- previousHorizontalLine.getX())>10  )
						{
							previousVerticalLine = currentVerticalLine;
							rectangles.add(rectangle);
							continue;
						}
						else{
							previousVerticalLine = currentVerticalLine;
							//								rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);
							rectangle.setX(x1);
							rectangle.setY(y1);
							rectangle.setWidth(x2 - x1);
							rectangle.setHeight(y2 - y1);
							rectangles.add(rectangle);
						}
						i = 0;
						if(isSpan && Math.abs(x2- nextHorizontalLine1.getX())<10)
						{
							currentHorizontalLine = nextHorizontalLine1;
						}
						else if(rectangles.size()>0
								&& Math.abs(x2- currentHorizontalLine.getX2())<10
								||(Math.abs(x2- nextHorizontalLine1.getX())<5)
								){
							flag2 = false;
						}

						if ( Math.abs(x2 - currentHorizontalLine.getX2())> 15) {
							continue;
						}
						else if(rectangles.size()>0){
							flag2 = false;
						}
//					}
//				}
			}

			else if (previousVerticalLine != null
					&& currentHorizontalLine!= null
					&& currentVerticalLine == verticalLines.get(verticalLines.size()-1)) {
				if (rectangles.size()==0 //|| ()
						|| (previousHorizontalLine.getX2() == currentVerticalLine.getX()
						|| Math.abs(previousHorizontalLine.getX2() -currentVerticalLine.getX())<30) )
				{
					continue;
				}
				rectangle.setX(previousVerticalLine.getX());
				rectangle.setY(previousHorizontalLine.getY());
				rectangle.setWidth(Math.min(previousHorizontalLine.getX2(), currentHorizontalLine.getX2()) -previousVerticalLine.getX() );
				rectangle.setHeight(currentHorizontalLine.getY()-previousHorizontalLine.getY());
				rectangles.add(rectangle);
				return rectangles;
			}

		}
		// prevY = hLine.getY();
		return rectangles;
	}

	public static List<DPRectangle> getCellsInHorizontalLinesNew(List<PDFGraphicalLine>horizontalLine, int index, //Line currentHorizontalLine, Line previousHorizontalLine,
			List<PDFGraphicalLine> verticalLines, BufferedImage img, int pgNum, boolean goodDoc) 
	{
		int i = 0;
		int yGapThreshold=0;
		int xGapThreshold=0;
		if (goodDoc) {
			yGapThreshold = 20;
			xGapThreshold = 20;
		}
		PDFGraphicalLine currentHorizontalLine = null;
		PDFGraphicalLine nextHorizontalLine1 = horizontalLine.get(index+1);
		PDFGraphicalLine previousHorizontalLine = horizontalLine.get(index);
		PDFGraphicalLine nextHorizontalLine2 = null;
		List<DPRectangle> rectangles = new ArrayList<DPRectangle>();
		PDFGraphicalLine previousVerticalLine = null;
		Boolean isSpan = false;
		Boolean flag2 = true;
		Boolean checkCell = false;
		int newIndex;

		for (PDFGraphicalLine currentVerticalLine : verticalLines) {
			DPRectangle rectangle = new DPRectangle(0, 0, 0, 0, pgNum);
			if (previousVerticalLine == null) {
				if((currentVerticalLine.getY() <= previousHorizontalLine.getY() 
						|| Math.abs(currentVerticalLine.getY() -previousHorizontalLine .getY()) <10)
						){
					previousVerticalLine = currentVerticalLine;
				}
				else{
					previousVerticalLine = null;
					continue;
				}
				//				previousVerticalLine = currentVerticalLine;
			}


			if(flag2 && !isSpan)
			{
				if( //currentHorizontalLine != nextHorizontalLine1
						//						&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
						//						&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
						Math.abs(previousHorizontalLine.getX() - nextHorizontalLine1.getX()) <10 
						&& nextHorizontalLine1.getY()>previousHorizontalLine.getY()
						|| (nextHorizontalLine1.getX()<previousHorizontalLine.getX()
								&& nextHorizontalLine1.getX2()>previousHorizontalLine.getX() ))
				{
					isSpan = false;
					currentHorizontalLine = nextHorizontalLine1;
				}
				else 
				{
					for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								//								&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
								//								&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
						{
							isSpan = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}
			else if (!isSpan && rectangles.size()!=0)
			{	
				for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
				{
					nextHorizontalLine2 = horizontalLine.get(newIndex);
					//					if(Math.abs(previousHorizontalLine.getX2() - nextHorizontalLine2.getX2()) <10 )
					if(rectangles.get(rectangles.size()-1).getX()!=0
							&&(rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) >= nextHorizontalLine2.getX()
							//							&& Math.abs(rectangles.get(rectangles.size()-1).getX2() - nextHorizontalLine2.getX2()) >15 )
							//							&& nextHorizontalLine2.getX2()-currentVerticalLine.getX()>=1)
							&& nextHorizontalLine2.getX2() - (rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) > 10 )

					{
						isSpan = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else if (rectangles.get(rectangles.size()-1).getX()==0
							&& nextHorizontalLine2.getX()==nextHorizontalLine2.getX()) {
						isSpan = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else continue;
				}
			}

			if (	previousVerticalLine != null && currentHorizontalLine!=null
					&& previousVerticalLine != currentVerticalLine 
					//					&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) <= 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() <= 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) <= 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) <= 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <= 13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() >= 20
					) {
				checkCell = true;
				if (currentHorizontalLine.getX2() < currentVerticalLine.getX() 
						&& currentHorizontalLine == nextHorizontalLine1) {
					for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
								&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
						{
							isSpan = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}


			if (currentHorizontalLine!=null 
					&& currentVerticalLine!=null 
					&& previousVerticalLine!=null 
					&& previousHorizontalLine !=null //added by Bharat
					&& Math.abs(img.getWidth() - currentVerticalLine.getX()) <= 15
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) <= 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() <= 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) <= 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) <= 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <= 13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() >= 20) {

				int x1 = (int)previousVerticalLine.getX();
				int x2 = (int)currentVerticalLine.getX();
				int y1 = (int)previousHorizontalLine.getY();
				int y2 = (int)currentHorizontalLine.getY();
				previousVerticalLine = currentVerticalLine;
				//rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);

				rectangle.setX(x1);
				rectangle.setY(y1);
				rectangle.setWidth(x2 - x1);
				rectangle.setHeight(y2 - y1);

				rectangles.add(rectangle);
				i = 0;
				//newly added logic
				if(Math.abs(x2- nextHorizontalLine1.getX2())<10){
					currentHorizontalLine= null;
					flag2 = false;
					continue;
				}
				else
					break;

			}
			
			/*else if (!checkCell) {
				continue;
			}*/

			else if (checkCell && previousVerticalLine != null && currentHorizontalLine!=null
					//						&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) <= 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() <= 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) <= 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) <= 10)
					&& (currentVerticalLine.getX() < previousHorizontalLine.getX2() 
							|| currentVerticalLine.getX() - previousHorizontalLine.getX2() <= 13 )
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20)// &&
			{

				i++;
//				if (i >= 1) {
//					int count1 = 0;
//					int count2 = 0;
//					count1 = GeneralUtility.compare((int)currentVerticalLine.getX() - 12, 
//							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
//					count2 = GeneralUtility.compare((int)currentVerticalLine.getX() + 5, 
//							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
//
//					if (count2 > 80 || count1 > 80) {
						int x1 = (int) previousVerticalLine.getX();
						int x2 = (int)currentVerticalLine.getX();
						int y1 = (int)previousHorizontalLine.getY();
						int y2 = (int)currentHorizontalLine.getY();

						if(x1<previousHorizontalLine.getX()&& previousHorizontalLine.getX()-x1 >20)// Math.abs(x1- previousHorizontalLine.getX())>10  )
						{
							previousVerticalLine = currentVerticalLine;
							rectangles.add(rectangle);
							continue;
						}
						else{
							previousVerticalLine = currentVerticalLine;
							//								rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);
							rectangle.setX(x1);
							rectangle.setY(y1);
							rectangle.setWidth(x2 - x1);
							rectangle.setHeight(y2 - y1);
							rectangles.add(rectangle);
						}
						i = 0;
						if(isSpan && Math.abs(x2- nextHorizontalLine1.getX())<10)
						{
							currentHorizontalLine = nextHorizontalLine1;
						}
						else if(rectangles.size()>0
								&& Math.abs(x2- currentHorizontalLine.getX2())<10
								||(Math.abs(x2- nextHorizontalLine1.getX())<5)
								){
							flag2 = false;
						}

						if ( Math.abs(x2 - currentHorizontalLine.getX2())> 15) {
							continue;
						}
						else if(rectangles.size()>0){
							flag2 = false;
						}
//					}
//				}
			}

			else if (previousVerticalLine != null
					&& currentHorizontalLine!= null
					&& currentVerticalLine == verticalLines.get(verticalLines.size()-1)) {
				if (rectangles.size()==0 //|| ()
						|| (previousHorizontalLine.getX2() == currentVerticalLine.getX()
						|| Math.abs(previousHorizontalLine.getX2() -currentVerticalLine.getX())<30) )
				{
					continue;
				}
				rectangle.setX(previousVerticalLine.getX());
				rectangle.setY(previousHorizontalLine.getY());
				rectangle.setWidth(Math.min(previousHorizontalLine.getX2(), currentHorizontalLine.getX2()) -previousVerticalLine.getX() );
				rectangle.setHeight(currentHorizontalLine.getY()-previousHorizontalLine.getY());
				rectangles.add(rectangle);
				return rectangles;
			}

		}
		// prevY = hLine.getY();
		return rectangles;
	}



	public static  void addVirtualLine(List<PDFGraphicalLine> horizontalLines, List<PDFGraphicalLine> verticalLines, boolean addRightLine ) {

		/*List<Float> tempY2 = new ArrayList<Float>();
        for (PDFGraphicalLine l : horizontalLines) {
                        tempY2.add(l.getX2());
        }
        Collections.sort(tempY2);
		 */
		Set<Float> tempX = new HashSet<Float>();
		for (PDFGraphicalLine l : horizontalLines) {
			tempX.add(l.getX());
		}
		List<Float> sortedX = new ArrayList<>(tempX);
		Collections.sort(sortedX);
		//System.out.println(sortedX);
		Set<Float> tempX2 = new HashSet<Float>();
		for (PDFGraphicalLine l : horizontalLines) {
			tempX2.add(l.getX2());
		}
		List<Float> sortedX2 = new ArrayList<>(tempX2);
		Collections.sort(sortedX2);
		//System.out.println(sortedX2);
		List<Float> tempY = new ArrayList<Float>();

		for (PDFGraphicalLine l : horizontalLines) {
			if (l.getWidth()>= Math.abs(sortedX2.get(sortedX2.size()-1)-sortedX.get(0))
					||Math.abs(l.getWidth()-Math.abs(sortedX2.get(sortedX2.size()-1)-sortedX.get(0)))<20 ) {
				tempY.add(l.getY());
			}
			/*else if(Math.abs(l.getWidth()-Math.abs(sortedX2.get(sortedX2.size()-1)-sortedX.get(0)))<20){
				tempY.add(l.getY());
			}*/
		}

		Collections.sort(tempY);
		if (sortedX.size()>0 && tempY.size()>0) {
			PDFGraphicalLine l = new PDFGraphicalLine(sortedX.get(0), tempY.get(0), 
					sortedX.get(0), tempY.get(tempY.size()-1), false, null);
			verticalLines.add(l);
		}

		if (sortedX2.size()>0 && tempY.size()>0 && addRightLine) {
			PDFGraphicalLine l2 = new PDFGraphicalLine(sortedX2.get(sortedX2.size()-1), tempY.get(0), 
					sortedX2.get(sortedX2.size()-1), tempY.get(tempY.size()-1), false, null);
			verticalLines.add(l2);
		}
	}


}
