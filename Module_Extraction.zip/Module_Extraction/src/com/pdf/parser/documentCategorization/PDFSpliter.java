package com.pdf.parser.documentCategorization;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;

public class PDFSpliter {

	private PDFParser parser;
	private PDFTextStripper pdfStripper;
	private PDDocument pdDoc ;
	private COSDocument cosDoc ;

	public void splitPDF(String filePath,String saveAs,int pageSize) throws IOException
	{
		this.pdfStripper = null;
		this.pdDoc = null;
		this.cosDoc = null;

		File file = new File(filePath);
		parser = new PDFParser(new FileInputStream(file));
		PDDocument pdf = PDDocument.load(file);
		parser.parse();
		cosDoc = parser.getDocument();
		pdfStripper = new PDFTextStripper();
		pdDoc = new PDDocument(cosDoc);
		pdDoc.getNumberOfPages();
		pdfStripper.setStartPage(0);
		pdfStripper.setEndPage(1);
		// reading text from page 1 to 10
		// if you want to get text from full pdf file use this code

		//  pdfStripper.setEndPage(pdDoc.getNumberOfPages());
		try {
			List<PDPage> pages=new ArrayList<PDPage>();
			int splitCounter=0;
			for (int i = 0; i < pdf.getDocumentCatalog().getAllPages().size(); i++) {
				PDPage p = (PDPage) pdf.getDocumentCatalog().getAllPages().get(i);

				if(i!=0 && i%pageSize==0){

					PDDocument pdf1 =new PDDocument();
					for (PDPage page : pages) {
						pdf1.addPage(page);
					}
					pdf1.save(saveAs+File.separator+file.getName()+"_"+splitCounter+".pdf"); 
					pdf1.close();
					splitCounter++;
					//clear pageList
					pages=new ArrayList<PDPage>();
					pages.add(p);

				}else{
					pages.add(p);
				}
			}
			if(!pages.isEmpty()){
				PDDocument pdf1 =new PDDocument();
				for (PDPage page : pages) {
					pdf1.addPage(page);
				}
				pdf1.save(saveAs+File.separator+file.getName()+"_"+splitCounter+".pdf"); 
				pdf1.close();
			}

		} catch (COSVisitorException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	public static void main(String[] a) {

		//"D:\\Platform\\\Phizer\\LargeFile" "D:\\Platform\\Phizer\\LargeFile" 25
		String inputDir = a[0];
		String output = a[1];

		int pageSize=Integer.valueOf(a[2]);
		PDFSpliter pfs=new PDFSpliter();

		System.out.println("inputDir::"+inputDir+"\t output::"+output);
		System.out.println();
		try {
			Queue<File> inputQ = new LinkedList<File>();
			inputQ.addAll(Arrays.asList(new File(inputDir).listFiles()));

			while(!inputQ.isEmpty()){
				final File f = inputQ.poll();
				if(f.isDirectory())//f.getName().startsWith("AWD")){
					inputQ.addAll(Arrays.asList(f.listFiles()));
				else{
					if(f.getName().toLowerCase().endsWith("pdf")){
						System.out.println(f.getAbsolutePath()+" ......Start");
						pfs.splitPDF(f.getAbsolutePath(), output, pageSize);
					}
				}
			}
			System.out.println("\n -----------------END------------------");
		}catch (Exception e){
			e.printStackTrace();				}


	}
}
