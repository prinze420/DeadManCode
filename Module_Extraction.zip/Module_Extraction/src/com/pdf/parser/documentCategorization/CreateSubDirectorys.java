package com.pdf.parser.documentCategorization;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.poi.openxml4j.opc.internal.FileHelper;

import com.pdf.parser.utils.MultiThreadHelper;

public class CreateSubDirectorys {


	public static void main(String[] args) {
		//"D:\\Platform\\Phizer\\subDirInput" "D:\\Platform\\Phizer\\subdir" 3

		//"D:\\Platform\\Phizer\\BatchProcess\\Input" "D:\\Platform\\Phizer\\BatchProcess\\InputSubDir" 3
		String inputDir=args[0];
		String outputDir=args[1];
		int subDirSize=Integer.valueOf(args[2]);

		CreateSubDirectorys crn=new CreateSubDirectorys();
		crn.divideInSubDir(inputDir, outputDir, subDirSize);
		System.out.println("Done"); 
	}

	public void divideInSubDir(String inputDir,String outputDir, int subDirSize){

		Queue<File> innputFiles = new LinkedList<File>();
		Queue<File> tempInputQ = new LinkedList<File>();
		tempInputQ.addAll(Arrays.asList(new File(inputDir).listFiles()));

		while(!tempInputQ.isEmpty()){
			final File in = tempInputQ.poll();
			if(in.isDirectory()){//f.getName().startsWith("AWD")){
				tempInputQ.addAll(Arrays.asList(in.listFiles()));
			}else{
				if(in.getName().toLowerCase().endsWith(".pdf")){
					innputFiles.add(in);
				}
			}
		}
		int perfolderFiles=innputFiles.size()/subDirSize;
		if(perfolderFiles<=1){
			perfolderFiles=innputFiles.size(); 
		}
		int folderCnt=1;

		File output_Dir = new File(outputDir);
		if(output_Dir.isDirectory() && output_Dir.listFiles().length>0){
			for (File file: output_Dir.listFiles()) {
				file.delete();
			}
		}
		/*if (output_Dir.exists()) 
		{
			output_Dir.delete();
		}
		if (output_Dir.mkdir()) {
			System.out.println("Directory is created!"+output_Dir);
		}*/


		String saveAt=outputDir+File.separator+""+folderCnt;

		if(!saveAt.trim().isEmpty()){
			File res_O_Dir = new File(saveAt);
			if (!res_O_Dir.exists()) {
				if (res_O_Dir.mkdir()) {
					System.out.println("Directory is created!"+res_O_Dir);
				} else {
					System.out.println("Failed to create directory!");

				}
			}
		}

		int cnt=1;
		List<Runnable> runs = new ArrayList<Runnable>();
		for (final File file : innputFiles) {
			
			final String sa = saveAt;
			runs.add(new Runnable() {
				public void run() {

					try {
						FileHelper.copyFile(file, new File(sa+File.separator+file.getName()));
					} catch (IOException e) {
						e.printStackTrace();
					} 
				}
			});

			if(cnt%perfolderFiles==0){
				folderCnt++;

				if(cnt < innputFiles.size() && folderCnt<=subDirSize){
					saveAt=outputDir+File.separator+""+folderCnt;
					if(!saveAt.trim().isEmpty()){
						File res_O_Dir = new File(saveAt);
						if (!res_O_Dir.exists()) {
							if (res_O_Dir.mkdir()) {
								System.out.println("Directory is created!"+res_O_Dir);
							} else {
								System.out.println("Failed to create directory!");

							}
						}
					}
				}
			}
			cnt++;
		}
		
		MultiThreadHelper.processThreads(runs, 20);
	}



}
