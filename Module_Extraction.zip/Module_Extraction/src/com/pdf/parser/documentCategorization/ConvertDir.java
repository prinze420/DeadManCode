package com.pdf.parser.documentCategorization;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.print.attribute.standard.JobPriority;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObject;
import org.apache.pdfbox.pdmodel.graphics.xobject.PDXObjectImage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.strategy.PDFCharacterFormationStrategy;

import edu.stanford.nlp.util.Comparators;

public class ConvertDir {

	static final int PARALLEL_JOBS = 12;

	private static String inputDir ;
	private static String url ;
	private static String username;
	private static String passwd;
	private static String domain ;
	private static String outputDirPath;
	private static String middlePageOutput;
	private static String middlePageOutputOcr;


	static float percentageAreaTolerance = 0.5f; // Eligibility of an image if
	// it's area is greater than
	// a percentage of area of
	// the page

	public static void main(String[] args) {
		//OLD 5 args//"E:\\ExtractionDir\\OriginalInputSet2\\LiveWorld"  http://localhost/Nuance.OmniPage.Server.Service 850029740 G@28032017t INDCORP "E:\ExtractionDir\\OriginalInputSet2\\Result"
		inputDir = args[0];
		url = args[1];
		username = args[2];
		passwd = args[3];
		domain = args[4];
		outputDirPath = args[5];
		middlePageOutput=args[6];
		middlePageOutputOcr=args[7];

		int jobtype = 23;

		//"E:\\ExtractionDir\\PageWiseOCRTesting\\Input"  http://localhost/Nuance.OmniPage.Server.Service 850029740 G@28032017t INDCORP "E:\\ExtractionDir\\PageWiseOCRTesting\\Output" "E:\\ExtractionDir\\PageWiseOCRTesting\\middlePageOutput" "E:\\ExtractionDir\\PageWiseOCRTesting\\MiddlePageOcred"
		//2//"E:\\TrainingDS1\\Legal" http://localhost/Nuance.OmniPage.Server.Service 850029740 G@28032017t INDCORP "E:\\TrainingDS1\\OCRedLegal" "E:\\TrainingDS1\\MiddleImagePages" "E:\\TrainingDS1\\MiddlePageOcred"


		/*String input="E:\\TrainingDS1\\OCRedLegal";
		String Output="E:\\ExtractionDir\\PageWiseOCRTesting\\Output";
		String MiddlePageOcred="E:\\ExtractionDir\\PageWiseOCRTesting\\MiddlePageOcred";
		String middlePageOutput="E:\\ExtractionDir\\PageWiseOCRTesting\\middlePageOutput";
		 */

		//"E:\\ExtractionDir\\PageWiseOCRTesting\\Output" "E:\\ExtractionDir\\PageWiseOCRTesting\\MiddlePageOcred" "E:\\ExtractionDir\\PageWiseOCRTesting\\middlePageOutput"

		List<File>inputOriginalPDFFiles =createImagePagePDFs(inputDir, middlePageOutput);
		//ocrOnDir(jobtype, middlePageOutput,middlePageOutputOcr);
		mergePDF(middlePageOutputOcr,outputDirPath,inputOriginalPDFFiles);

		System.out.println("Done");

	}

	/*public static void ocrOnDir(int jobtype, String dir, String outputDir){

		//Arguments - http://localhost/Nuance.OmniPage.Server.Service shishir.mane Rage$456 creditpointe 18 Job1 temp.pdf output1122.pdf
		//http://localhost/Nuance.OmniPage.Server.Service shishir.mane Rage$456 creditpointe 18 Job1 temp.pdf output1122.pdf
		//E:\\ExtractionDir\\Script5Temp\\input
		//E:\\ExtractionDir\\Script5Temp\\Result
		String dir = args[0];
		String url = args[1];
		String username = args[2];
		String passwd = args[3];
		String domain = args[4];
		String outputDir = args[5];

		 Job Type ID
		16 Normal PDF
		17 Image Only PDF
		18 Searchable Image PDF


		String jobName = "Dir";
		int count=1;

		//create subPageFilsForImagePage
		//save it in someDirectory----
		//pass this dir for next process------

		List<File> allFiles = Arrays.asList(new File(dir).listFiles());
		List<File> files = new ArrayList<File>();


		for(int j=0; j<allFiles.size(); j++){
			files.add(allFiles.get(j));
			if((j+1)%PARALLEL_JOBS!=0 && j<allFiles.size()-1)
				continue;

			if((j+1)<PARALLEL_JOBS && j<allFiles.size()-1)
				continue;

			OPSService service = new OPSServiceImpl(url, username, passwd, domain);
			List<String> jobs = new ArrayList<String>();
			for(File input : files){

				//Create job
				String job = service.createJob(jobtype, jobName+(count++), "CONVERSION", "Job Metadata");

				//Get URLs for upload file
				List<String> urls = service.getUploadUrls(job, 1); 

				//Upload the input file to the server
				service.postInputFile(urls.get(0), input.getAbsolutePath());

				jobs.add(job);
			}

			for(int i=0; i<jobs.size(); i++){
				String job = jobs.get(i);

				//Specify parameters for conversion
				ConversionParameters params = new ConversionParameters();
				params.setImageQuality("Good");
				params.setLayoutTradeOff("Accuracy");
				params.setTradeOff("Accuracy");

				//Start the job
				service.startJob(job, 1800, JobPriority.HIGH, params);
				System.out.println("Job started for "+files.get(i).getName());
			}

			for(int i=0; i<jobs.size(); i++){
				String job = jobs.get(i);

				//Poll the server to check for when the job finishes.
				while(true)
				{
					if(job==null)
						break;

					// Get JobInfo
					JobInfo response = service.getJobInfo(job);
					//			        JobStateEnum state = response.getState();
					//			        String jobState = state.name();
					//			        System.out.println(jobState);

					if(response.getState() == JobStateEnum.FAILED ||
							response.getState() == JobStateEnum.ABANDONED ||
							response.getState() == JobStateEnum.CANCELLED)
					{
						//trace error    
						System.out.println("Job failed");
						System.out.println(response.getResultMessage());
						break;
					}
					if(response.getState() == JobStateEnum.COMPLETED)
					{
						// Get Download Urls
						List<String> retUrls = service.getDownloadUrls(job);            
						//Download the file
						File file = new File(outputDir+"/"+files.get(i).getName());
						if(file.exists())
							file.delete();

						service.downloadFile(retUrls.get(0), file);
						break;
					}
					else
					{
						//Job still in progress...wait a bit
						try {
							Thread.sleep(500);
						} catch (InterruptedException e) {
							e.printStackTrace();
						}
					}
				}
				// Delete files
				service.deleteJobData(job, 1);
			}

			files.clear();
		}

		//mergeFiles-----------------------

	}

	 */
	private static List<File> createImagePagePDFs(String inputdir, String middleOutputpath) {
		List<File>inputOriginalPDFFiles=new ArrayList<File>();
		File folder = new File(inputdir);
		File[] listFiles = null;

		if (folder.isDirectory()) {
			listFiles = folder.listFiles();
			for (File file : listFiles) {

				if (file.getAbsolutePath().endsWith(".pdf")) {
					inputOriginalPDFFiles.add(file);
				}
			}
		}

		for (File file : listFiles) {

			PDDocument pdf;
			try {
				pdf = PDDocument.load(file);

				pdf.setAllSecurityToBeRemoved(true);
				//Map<Integer, PDDocument>imagePage_Pdf=new HashMap<Integer, PDDocument>();
				//	List<PDDocument>ImagePagesPdfs=new ArrayList<PDDocument>();
				if (pdf.isEncrypted())
					pdf.decrypt("");


				//boolean imgFlag=false;
				int a = -1;
				for (PDPage page : (List<PDPage>) pdf.getDocumentCatalog().getAllPages()) {
					a++;


					boolean isTextPresent=checkIsTextPresent(page,a);

					if(!isTextPresent){
						float pageArea = page.getBleedBox().getWidth() * page.getBleedBox().getHeight();
						float imageArea = 0f;

						for (PDXObject x : page.getResources().getXObjects().values()) {

							if (x instanceof PDXObjectImage) 
							{
								PDXObjectImage img = (PDXObjectImage) x;
								imageArea += (img.getWidth() * img.getHeight());

							}
						}

						if (imageArea > pageArea * percentageAreaTolerance) {
							//imgFlag=true;
							PDDocument pdf1 = new PDDocument();
							pdf1.addPage(page);
							String filName=file.getName().substring(0,file.getName().lastIndexOf("."));
							pdf1.save(middleOutputpath + File.separator +filName+"-"+ a + ".pdf");
							pdf1.close();
							//ImagePagesPdfs.add(pdf1);
							//imagePage_Pdf.put(a, pdf1);
						}
					}
				}
				pdf.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CryptographyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (COSVisitorException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return inputOriginalPDFFiles;
	}

	private static boolean checkIsTextPresent(PDPage page, int a) {

		float pageHeight=0.0f;

		if(page.getBleedBox()!=null){
			pageHeight = page.getBleedBox().getHeight();
		}else if(page.getMediaBox()!=null){
			pageHeight = (page.getMediaBox().getHeight());
		}else if(page.getTrimBox()!=null){
			pageHeight = (page.getTrimBox().getHeight());
		}


		final List<TextPosition> chars=new ArrayList<TextPosition>();
		PDFTextStripper pts = null;
		try {
			pts = new PDFTextStripper(){
				protected void processTextPosition(TextPosition t) {
					chars.add(t);
				};
			};
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		pts.setSuppressDuplicateOverlappingText(true);
		//This helps in tracking the order of characters
		pts.setSortByPosition(true);
		//This invokes the processTextPosition function in pts
		try {
			pts.processStream(page, page.findResources(), page.getContents().getStream());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Collections.sort(chars, new Comparator<TextPosition>() {
			@Override
			public int compare(TextPosition o1, TextPosition o2) {
				return Float.valueOf(o1.getY()).compareTo(o2.getY());
			}
		});

		//Fill the PDFCharacter list.
		List<TextPosition> charsOnPage =chars;
		float firstAndLastCharDiff=-1;
		if(pageHeight > 1 && charsOnPage!=null && !charsOnPage.isEmpty()){ 
			firstAndLastCharDiff= charsOnPage.get(charsOnPage.size()-1).getY()-charsOnPage.get(0).getY();
		}else{
			return false;
		}
		if(firstAndLastCharDiff>0 && firstAndLastCharDiff > pageHeight/2){
			return true;
		}
		return false;
	}

	private static void mergePDF(String middleOutputpath,String ocredOutputPath, List<File> inputOriginalPDFFiles) {

		File folder = new File(middleOutputpath);
		Map<String, List<File>>fileOCredPages=new HashMap<String, List<File>>();
		//List<File>pdfFiles=new ArrayList<File>();

		if (folder.isDirectory()) {
			File[]  listFiles = folder.listFiles();
			for (File file : listFiles) {
				if(file.getName().toLowerCase().endsWith(".pdf")){
					String mainFile=file.getName().split("-")[0];

					if(fileOCredPages.containsKey(mainFile)){
						List<File> files = fileOCredPages.get(mainFile);
						files.add(file);
						fileOCredPages.put(mainFile, files);
					}else{
						List<File> files = new ArrayList<File>();
						files.add(file);
						fileOCredPages.put(mainFile, files);
					}
				}
			}
		}

		for (File inFile : inputOriginalPDFFiles) {
			String name=inFile.getName().substring(0,inFile.getName().lastIndexOf("."));

			if(!fileOCredPages.containsKey(name)){
				continue;
			}

			List<File> imagePagefiles = fileOCredPages.get(name);

			PDDocument pdf = null;
			try {
				pdf = PDDocument.load(inFile);

				pdf.setAllSecurityToBeRemoved(true);

				if (pdf.isEncrypted())
					pdf.decrypt("");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (CryptographyException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			PDDocument ocredFile = new PDDocument();
			List inputOriginalPages = (List<PDPage>)pdf.getDocumentCatalog().getAllPages();

			for (int i = 0; i < inputOriginalPages.size(); i++) {

				File pageFile=null;
				for (File f : imagePagefiles) {
					String subName=f.getName().substring(0,f.getName().lastIndexOf("."));

					String pageNum=subName.split("-")[1];
					{
						if(i==Integer.valueOf(pageNum)){
							pageFile=f;
							break;
						}

					}
				}
				if(pageFile!=null){

					PDDocument pageFilePDF = null;
					try {
						pageFilePDF = PDDocument.load(pageFile);

						pageFilePDF.setAllSecurityToBeRemoved(true);

						if (pageFilePDF.isEncrypted())
							pageFilePDF.decrypt("");

						ocredFile.addPage((PDPage) ((List<PDPage>)pageFilePDF.getDocumentCatalog().getAllPages()).get(0));
						//pageFilePDF.close();

					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (CryptographyException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}else{
					ocredFile.addPage((PDPage) inputOriginalPages.get(i));
				}

			}
			//save file
			try {
				ocredFile.save(ocredOutputPath + File.separator +name+".pdf");
				pdf.close();
				ocredFile.close();

			} catch (COSVisitorException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

	}

}
