package com.pdf.parser.documentCategorization;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.ResourceBundle;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.MultiThreadHelper;

public class DocCategorizer {

	private static ResourceBundle  docCategoriser;
	static{
		try{
			docCategoriser = ResourceBundle.getBundle("docCategoriserParameters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

		}catch (Exception e)
		{
			e.printStackTrace();
		}
	}

	private	String type1path;
	private List<String>type1Keywords;

	private	String type2path;
	private List<String>type2Keywords;

	private	String type3path;
	private List<String>type3Keywords;

	private	String otherPath;

	public DocCategorizer() {
		// TODO Auto-generated constructor stub

		type1path=docCategoriser.getString("type1path");
		type1Keywords=Arrays.asList(docCategoriser.getString("type1Keywords").split(","));

		type2path=docCategoriser.getString("type2path");
		type2Keywords=Arrays.asList(docCategoriser.getString("type2Keywords").split(","));

		type3path=docCategoriser.getString("type3path");
		type3Keywords=Arrays.asList(docCategoriser.getString("type3Keywords").split(","));

		otherPath=docCategoriser.getString("otherPath");
	}
	public void apply(String inputDirPath,int parallel){

		System.out.println("Dir process ");

		//final String dirPath = a[1];

		System.out.println();
		Queue<File> inputQ = new LinkedList<File>();
		inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));
		List<Runnable> threads = new ArrayList<Runnable>();

		while(!inputQ.isEmpty()){
			final File in = inputQ.poll();
			if(in.isDirectory())//f.getName().startsWith("AWD")){
				inputQ.addAll(Arrays.asList(in.listFiles()));
			else if(in.getName().toLowerCase().endsWith(".pdf")){
				threads.add(new Runnable() {
					public void run() {
						//Trying to avoid the entire loop to break on exception
						try{
							if(in.getName().contains("complaint1")){
								System.out.println();
							}
							categorize(in);
							System.out.println("Done with "+in.getAbsolutePath());

						}catch(Exception e){e.printStackTrace();}
					}
				});
			}
			if(threads.size()>5){
				MultiThreadHelper.processThreads(threads, parallel);
				threads.clear();
			}
		}

		//Remaining threads
		if(threads.size()>0){
			MultiThreadHelper.processThreads(threads, 2);
			threads.clear();
		}
	}

	public void categorize(File f){

		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(f);

			if(pdf.isEncrypted()){
				try {
					pdf.decrypt("");
				} catch (CryptographyException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, List<PDFSegment>> pageWiseSegs = parser.getSegments();

		try{
			if( keywordPresent(pageWiseSegs,type1Keywords)){
				pdf.save( type1path+File.separator+f.getName() );

			}else if( keywordPresent(pageWiseSegs,type2Keywords)){
				pdf.save( type2path+File.separator+f.getName() );

			}else if(keywordPresent(pageWiseSegs,type3Keywords)){
				pdf.save( type3path +File.separator+ f.getName() );

			}else
			{
				pdf.save( otherPath+File.separator+f.getName() );
			}
		} catch (COSVisitorException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	private boolean keywordPresent(Map<Integer, List<PDFSegment>> pageWiseSegs,	List<String> typeKeywords) {


		for (Integer pgNo : pageWiseSegs.keySet()) {

			int cnt=0;
			for (PDFSegment seg : pageWiseSegs.get(pgNo)) {
				String inWordStr = seg.getStringRepresentation().trim().replaceAll("[^0-9A-Za-z ]", "").trim();
				if(inWordStr.contains("Case")){
					System.out.println();
				}
				for (String string : typeKeywords) {
					if(inWordStr.trim().contains(string.trim())){
						cnt++;
						break;
					}
				}
				if(cnt==typeKeywords.size())
				{
					return true;
				}
			}
			
		}
		return false;
	}

	public static void main(String[] args) {

//		String str="D:\\Platform\\Phizer\\TestSample\\";
//		int parrallel_process=4;
	
		String str=args[0];
		int parrallel_process=Integer.valueOf(args[1]);
	
		DocCategorizer dc=new DocCategorizer();
		dc.apply(str,parrallel_process);

	}
}
