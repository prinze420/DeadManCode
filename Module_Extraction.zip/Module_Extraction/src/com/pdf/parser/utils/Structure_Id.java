package com.pdf.parser.utils;

import java.io.Serializable;

public class Structure_Id implements Serializable{


	/**
	 * 
	 */
	private static final long serialVersionUID = -9120069317589360161L;
	
	private static long counter=0;
	private static Structure_Id singletonObject =null;

	private Structure_Id() {}

	public static Structure_Id getInstance()
	{
		if(singletonObject ==null)
		{
			singletonObject = new Structure_Id();
		}
		return singletonObject;
	}

	public synchronized long getNext()
	{
		return ++counter;
	}



}
