package com.pdf.parser.ocrQuality;

import java.util.List;

import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFWord;

public class PageAccuracyRecord {

	private int pageNum;
	private float wordAccuracyRatio;
	private List<PDFWord>invalidWords;

	private float validCharacterRatio;
	private float inValidCharacterRatio;
	private float overlappedRatio;
	private List<PDFCharacter>validCharacters;
	private List<PDFCharacter>inValidCharacters;
	private List<PDFCharacter>overlappedCharacters;
	int total_PageWords;
		
	public int getPageNum() {
		return pageNum;
	}
	public void setPageNum(int pageNum) {
		this.pageNum = pageNum;
	}
	public float getWordAccuracyRatio() {
		return wordAccuracyRatio;
	}
	public List<PDFWord> getInvalidWords() {
		return invalidWords;
	}
	public float getValidCharacterRatio() {
		return validCharacterRatio;
	}
	public float getInValidCharacterRatio() {
		return inValidCharacterRatio;
	}
	public float getOverlappedRatio() {
		return overlappedRatio;
	}
	public List<PDFCharacter> getValidCharacters() {
		return validCharacters;
	}
	public List<PDFCharacter> getInValidCharacters() {
		return inValidCharacters;
	}
	public List<PDFCharacter> getOverlappedCharacters() {
		return overlappedCharacters;
	}
	public void setWordAccuracyRatio(float wordAccuracyRatio) {
		this.wordAccuracyRatio = wordAccuracyRatio;
	}
	public void setInvalidWords(List<PDFWord> invalidWords) {
		this.invalidWords = invalidWords;
	}
	public void setValidCharacterRatio(float validCharacterRatio) {
		this.validCharacterRatio = validCharacterRatio;
	}
	public void setInValidCharacterRatio(float inValidCharacterRatio) {
		this.inValidCharacterRatio = inValidCharacterRatio;
	}
	public void setOverlappedRatio(float overrideRatio) {
		this.overlappedRatio = overrideRatio;
	}
	public void setValidCharacters(List<PDFCharacter> validCharacters) {
		this.validCharacters = validCharacters;
	}
	public void setInValidCharacters(List<PDFCharacter> inValidCharacters) {
		this.inValidCharacters = inValidCharacters;
	}
	public void setOverlappedCharacters(List<PDFCharacter> overrideCharacters) {
		this.overlappedCharacters = overrideCharacters;
	}
	public int getTotal_PageWords() {
		return total_PageWords;
	}
	public void setTotal_PageWords(int total_PageWords) {
		this.total_PageWords = total_PageWords;
	}
	
	

}
