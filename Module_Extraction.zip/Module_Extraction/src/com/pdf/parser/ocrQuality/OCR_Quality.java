package com.pdf.parser.ocrQuality;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.MultiThreadHelper;

public class OCR_Quality {

	static ResourceBundle basicConfig;
	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public Map<Integer, PageAccuracyRecord> Apply(String inputFile){

		File f=new File(inputFile);
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(f);

			if(pdf.isEncrypted()){
				try {
					pdf.decrypt("");
				} catch (CryptographyException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, List<PDFCharacter>> pageWiseCharacters=parser.getCharacters();
		Map<Integer, List<PDFWord>> pageWiseWords = parser.getWords();
		Map<Integer, List<PDFCharacter>> pageWiseOverlappedCharacters=parser.getOverrideCharacters();

		//create pagewise page records 
		Map<Integer, PageAccuracyRecord> PageAccuracyRecordMap= new TreeMap<Integer, PageAccuracyRecord>();

		for (Integer pgNo : pageWiseCharacters.keySet()) {
			PageAccuracyRecord pgacc=new PageAccuracyRecord();
			pgacc.setPageNum(pgNo);
			PageAccuracyRecordMap.put(pgNo, pgacc);
		}
		//		PageAccuracyRecord
		characterQualityProcess(pageWiseCharacters,pageWiseOverlappedCharacters,PageAccuracyRecordMap);

		//int threshold=1;
		int threshold=Integer.valueOf(basicConfig.getString("validWordCount"));
		wordQualityProcess(pageWiseWords,PageAccuracyRecordMap,threshold);


		return PageAccuracyRecordMap;
	}

	private void wordQualityProcess(Map<Integer, List<PDFWord>> pageWiseWords, Map<Integer, PageAccuracyRecord> pageAccuracyRecordMap,int threshold) {
		//System.out.println("\n ------- wordQualityProcess");
		// TODO Auto-generated method stub

		Map<String,Integer>uniqueWords=new TreeMap<String,Integer>();

		for (Integer pgNo : pageWiseWords.keySet()) {
			for (PDFWord wrd : pageWiseWords.get(pgNo)) {
				String inWordStr = wrd.getStringRepresentation().trim().replaceAll("[^0-9A-Za-z]", "").trim();
				if(uniqueWords.containsKey(inWordStr)){
					int cnt=uniqueWords.get(inWordStr);
					uniqueWords.put(inWordStr, cnt+1);
				}else{
					uniqueWords.put(inWordStr, 1);
				}
			}
		}

		uniqueWords=sortByComparator(uniqueWords,true);//true :Asc

		Set<String>validWords=new HashSet<String>();

		//System.out.println("SortedWordlist");

		for (String k : uniqueWords.keySet()) {
			if(uniqueWords.get(k)>threshold){
				validWords.add(k);
			}
			//	System.out.println(k+"\t"+uniqueWords.get(k));
		}

		Map<Integer,List<PDFWord>>invalidWordsRecords=new TreeMap<Integer, List<PDFWord>>();

		for (Integer pgNo : pageWiseWords.keySet()) {
			List<PDFWord> temp=new ArrayList<PDFWord>();
			for (PDFWord wrd : pageWiseWords.get(pgNo)) {
				String inWordStr = wrd.getStringRepresentation().trim().replaceAll("[^0-9A-Za-z]", "").trim();

				if(validWords.contains(inWordStr)){ 
					temp.add(wrd);
				}

			}
			invalidWordsRecords.put(pgNo, temp);

			float pageWordAccuracy=((float)temp.size()/(float)pageWiseWords.get(pgNo).size())*100;
			PageAccuracyRecord record = pageAccuracyRecordMap.get(pgNo);
			record.setWordAccuracyRatio(pageWordAccuracy);
			record.setInvalidWords(temp);
			record.setTotal_PageWords(pageWiseWords.get(pgNo).size());
		}
		
	}

	private static Map<String, Integer> sortByComparator(Map<String, Integer> unsortMap, final boolean order)
	{
		List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(unsortMap.entrySet());
		// Sorting the list based on values
		Collections.sort(list, new Comparator<Entry<String, Integer>>()
				{
			public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)
			{
				if (order)
				{
					return o1.getValue().compareTo(o2.getValue());
				}
				else
				{
					return o2.getValue().compareTo(o1.getValue());

				}
			}
				});

		// Maintaining insertion order with the help of LinkedList
		Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
		for (Entry<String, Integer> entry : list)
		{
			sortedMap.put(entry.getKey(), entry.getValue());
		}

		return sortedMap;
	}


	private void characterQualityProcess(Map<Integer, List<PDFCharacter>> pageWiseCharacters, Map<Integer, List<PDFCharacter>> pageWiseOverrideCharacters, Map<Integer, PageAccuracyRecord> pageAccuracyRecordMap) {
		//System.out.println(" ------- characterQualityProcess ");
		// TODO Auto-generated method stub
		Map<Integer,List<PDFCharacter>>validCharacterCounts=new TreeMap<Integer, List<PDFCharacter>>();
		Map<Integer,List<PDFCharacter>>inValidCharacterCounts=new TreeMap<Integer, List<PDFCharacter>>();
		for (Integer pgNo : pageWiseCharacters.keySet()) {
			List<PDFCharacter> validCharCount=new ArrayList<PDFCharacter>();
			List<PDFCharacter> inValidCharCount=new ArrayList<PDFCharacter>();
			for (PDFCharacter character : pageWiseCharacters.get(pgNo)) {
				if(CommonOperations.isValidCharacter(character.getStringRepresentation())){
					//validCharCount++;	
					validCharCount.add(character);
				}else{
					//inValidCharCount++;
					inValidCharCount.add(character);
				}
			}
			validCharacterCounts.put(pgNo, validCharCount);
			inValidCharacterCounts.put(pgNo, inValidCharCount);
		}

		//detect ratio
		for (Integer pgNo : pageWiseCharacters.keySet()) {


			//		System.out.println("########Page: "+pgNo);
			int totalPageChars=pageWiseCharacters.get(pgNo).size()+pageWiseOverrideCharacters.get(pgNo).size();
			/*if(totalPageChars<=0){
					System.out.println("No Characters found");
				}*/
			float validChar = (((float)validCharacterCounts.get(pgNo).size()/(float)totalPageChars)*100);
			//System.out.println("ValidCharacter Ratio:\t"+validChar+"%");

			float invalidChar = ((float)inValidCharacterCounts.get(pgNo).size()/(float)totalPageChars)*100;
			//System.out.println("InValid Character Ratio:\t"+invalidChar+"%");

			float ovverride = ((float)pageWiseOverrideCharacters.get(pgNo).size()/(float)totalPageChars)*100;
			//System.out.println("Override Ratio:\t"+ovverride+"%");

			PageAccuracyRecord record = pageAccuracyRecordMap.get(pgNo);
			record.setValidCharacterRatio(validChar);
			record.setInValidCharacterRatio(invalidChar);
			record.setOverlappedRatio(ovverride);

			record.setValidCharacters(validCharacterCounts.get(pgNo));
			record.setInValidCharacters(inValidCharacterCounts.get(pgNo));
			record.setOverlappedCharacters(pageWiseOverrideCharacters.get(pgNo));
		}

	}


		private static void saveDirResult(Map<Integer, PageAccuracyRecord> PageAccuracyRecordMap, File file, BufferedWriter writer) {
		try {
			String fileName=file.getName().substring(0, file.getName().lastIndexOf("."));
			
			for (Integer pgNo : PageAccuracyRecordMap.keySet()) 
			{
				PageAccuracyRecord record = PageAccuracyRecordMap.get(pgNo);

				synchronized (writer) {
					writer.write(fileName+"\t"+record.getPageNum()+"\t"+record.getValidCharacterRatio()+"\t"+
							record.getInValidCharacterRatio()+"\t"+record.getOverlappedRatio()+"\t"+record.getWordAccuracyRatio()+"\t"+record.getTotal_PageWords());
					writer.newLine();
				}
			}
			System.out.println("******---------End of "+file.getName());
		}catch (Exception e){
			e.printStackTrace();
		}
	}
	
//	private static void sveResult(Map<Integer, PageAccuracyRecord> PageAccuracyRecordMap, String outputFilePath) {
//		// TODO Auto-generated method stub
//
//		BufferedWriter writer;
//		try {
//
//			writer = new BufferedWriter(new FileWriter(outputFilePath));
//			System.out.println("\n\n************************************ Extraction ----Resut -----");
//			System.out.println("\n******************* page Quality Result ******************");
//
//			writer.write("\nPageNo \t ValidCharacterRatio \t InValidCharacterRatio \t OverrideRatio \t WordAccuracyRatio");
//
//			for (Integer pgNo : PageAccuracyRecordMap.keySet()) 
//			{
//				PageAccuracyRecord record = PageAccuracyRecordMap.get(pgNo);
//				System.out.println("\n**************");
//				System.out.println("Page No:\t"+record.getPageNum());
//				System.out.println("Valid Character Ratio:\t"+record.getValidCharacterRatio());
//				System.out.println("InValid Character Ratio:\t"+record.getInValidCharacterRatio());
//				System.out.println("Ovelapped Ratio:\t"+record.getOverrideRatio());
//				System.out.println("##Word Accuracy Ratio:\t"+record.getWordAccuracyRatio());
//
//				writer.write("\n"+record.getPageNum()+"\t"+record.getValidCharacterRatio()+"\t"+
//						record.getInValidCharacterRatio()+"\t"+record.getOverrideRatio()+"\t"+record.getWordAccuracyRatio());
//
//			}
//			writer.close();
//			//DBOperations.save(res, new Integer(fileID));
//		}catch (Exception e){
//			e.printStackTrace();
//		}
//	}
		
		public static void main(String[] a) throws IOException {
			//String inputFile="D:\\Platform\\Phizer\\TestSample\\12131MQMQ525527.pdf"; //


			//Aberdeen Leaders Limited Annual Report 30 June 2016## AWD100200##  Response## Template_3## complaint1
			if(a.length<1){

				System.out.println("Missing input Arguments");
				return;
			}

			if(a[0].equalsIgnoreCase("file")){ // file "D:/Platform/Phizer/TestSample/Response.pdf" "D:/Platform/Phizer/TestSample/"
				OCR_Quality ocrAcc=new OCR_Quality();
				String inputFile =a[1];
				final String outpuDir=a[2];
				Map<Integer, PageAccuracyRecord> result = ocrAcc.Apply(inputFile);
				File f=new File(inputFile);
//				String outpuResult=outpuDir+File.separator+f.getName().substring(0, f.getName().lastIndexOf("."))+"_OcrQ_Result.txt";
//				sveResult(result, outpuResult);
				String outpuResult=outpuDir+File.separator+"OCR_Quality_Result.txt";
				
				BufferedWriter writer = new BufferedWriter(new FileWriter(outpuResult));
				writer.write("\n FileName\t PageNo \t Valid_Character_Ratio \t Invalid_Character_Ratio \t Overlapped_Ratio \t Word_Accuracy_Ratio");
				
				saveDirResult(result, f, writer);
				writer.close();

			}else if(a[0].equalsIgnoreCase("dir")){  // dir "D:/Platform/SampleFiles" 3 "D:/Platform/"

				String inputDirPath =a[1];
				int parallel=Integer.valueOf(a[2]);
				final String outputFileDirPath=a[3];

				Queue<File> inputQ = new LinkedList<File>();
				inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));
				List<Runnable> threads = new ArrayList<Runnable>();
				
				String outpuResult=outputFileDirPath+File.separator+"OCR_Quality_Result.txt";
				
				final BufferedWriter writer = new BufferedWriter(new FileWriter(outpuResult));
				writer.write("FileName\t PageNo \t Valid_Character_Ratio \t Invalid_Character_Ratio \t Overlapped_Ratio \t Word_Accuracy_Ratio \t Total_PageWords");
				writer.newLine();
				while(!inputQ.isEmpty()){
					final File in = inputQ.poll();
					if(in.isDirectory())//f.getName().startsWith("AWD")){
						inputQ.addAll(Arrays.asList(in.listFiles()));

					else if(in.getName().toLowerCase().endsWith(".pdf")){
						threads.add(new Runnable() {
							public void run() {
								//Trying to avoid the entire loop to break on exception
								try{
									OCR_Quality ocrAcc=new OCR_Quality();
									Map<Integer, PageAccuracyRecord> res = ocrAcc.Apply(in.getAbsolutePath());
									saveDirResult(res, in, writer);
									//sveResult(res, outpuResult);
								}catch(Exception e){e.printStackTrace();}
							}
						});
					}
					if(threads.size()>=parallel){
						MultiThreadHelper.processThreads(threads, parallel);
						threads.clear();
					}
				}
				//Remaining threads
				if(threads.size()>0){
					MultiThreadHelper.processThreads(threads, threads.size());
					threads.clear();
				}
				writer.close();
			}

		}


}
