package com.pdf.parser.ocrQuality;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;

public class OCR_Accuracy {


	public void Apply(String inputFile){

		File f=new File(inputFile);
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(f);

			if(pdf.isEncrypted()){
				try {
					pdf.decrypt("");
				} catch (CryptographyException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, List<PDFCharacter>> pageWiseCharacters=parser.getCharacters();
		Map<Integer, List<PDFWord>> pageWiseWords = parser.getWords();
		Map<Integer, List<PDFCharacter>> pageWiseOverrideCharacters=parser.getOverrideCharacters();



		//create pagewise page records 
		Map<Integer, PageAccuracyRecord> PageAccuracyRecordMap= new TreeMap<Integer, PageAccuracyRecord>();

		for (Integer pgNo : pageWiseCharacters.keySet()) {
			PageAccuracyRecord pgacc=new PageAccuracyRecord();
			pgacc.setPageNum(pgNo);
			PageAccuracyRecordMap.put(pgNo, pgacc);
		}
		//		PageAccuracyRecord
		characterQualityProcess(pageWiseCharacters,pageWiseOverrideCharacters,PageAccuracyRecordMap);
		
		int threshold=1;
		wordQualityProcess(pageWiseWords,PageAccuracyRecordMap,threshold);

		System.out.println("\n******************* page Quality Result ******************");

		for (Integer pgNo : PageAccuracyRecordMap.keySet()) 
		{
			PageAccuracyRecord record = PageAccuracyRecordMap.get(pgNo);
			System.out.println("\n**************");
			System.out.println("PageNo:\t"+record.getPageNum());
			System.out.println("ValidCharacterRatio:\t"+record.getValidCharacterRatio());
			System.out.println("InValidCharacterRatio:\t"+record.getInValidCharacterRatio());
//			System.out.println("OverrideRatio:\t"+record.getOverrideRatio());
			System.out.println("##WordAccuracyRatio:\t"+record.getWordAccuracyRatio());
		}

	}
	
		private void wordQualityProcess(Map<Integer, List<PDFWord>> pageWiseWords, Map<Integer, PageAccuracyRecord> pageAccuracyRecordMap,int threshold) {
			System.out.println("\n ------- wordQualityProcess");
			// TODO Auto-generated method stub
			
			Map<String,Integer>uniqueWords=new TreeMap<String,Integer>();

			for (Integer pgNo : pageWiseWords.keySet()) {
				for (PDFWord wrd : pageWiseWords.get(pgNo)) {
					String inWordStr = wrd.getStringRepresentation().trim().replaceAll("[^0-9A-Za-z]", "").trim();
					if(uniqueWords.containsKey(inWordStr)){
						int cnt=uniqueWords.get(inWordStr);
						uniqueWords.put(inWordStr, cnt+1);
					}else{
						uniqueWords.put(inWordStr, 1);
					}
				}
			}

			uniqueWords=sortByComparator(uniqueWords,true);//true :Asc

			List<String>invalidWords=new ArrayList<String>();

			//System.out.println("SortedWordlist");

			for (String k : uniqueWords.keySet()) {
				if(uniqueWords.get(k)>threshold){
					invalidWords.add(k);
				}
			//	System.out.println(k+"\t"+uniqueWords.get(k));
			}

			Map<Integer,List<PDFWord>>invalidWordsRecords=new TreeMap<Integer, List<PDFWord>>();

			for (Integer pgNo : pageWiseWords.keySet()) {
				List<PDFWord> temp=new ArrayList<PDFWord>();
				for (PDFWord wrd : pageWiseWords.get(pgNo)) {
					String inWordStr = wrd.getStringRepresentation().trim().replaceAll("[^0-9A-Za-z]", "").trim();

					if(invalidWords.contains(inWordStr)){
						temp.add(wrd);
					}

				}
				invalidWordsRecords.put(pgNo, temp);

				float pageWordAccuracy=((float)temp.size()/(float)pageWiseWords.get(pgNo).size())*100;
				PageAccuracyRecord record = pageAccuracyRecordMap.get(pgNo);
				record.setWordAccuracyRatio(pageWordAccuracy);
				record.setInvalidWords(temp);

			}
		}

		private static Map<String, Integer> sortByComparator(Map<String, Integer> unsortMap, final boolean order)
		{
			List<Entry<String, Integer>> list = new LinkedList<Entry<String, Integer>>(unsortMap.entrySet());
			// Sorting the list based on values
			Collections.sort(list, new Comparator<Entry<String, Integer>>()
					{
				public int compare(Entry<String, Integer> o1, Entry<String, Integer> o2)
				{
					if (order)
					{
						return o1.getValue().compareTo(o2.getValue());
					}
					else
					{
						return o2.getValue().compareTo(o1.getValue());

					}
				}
					});

			// Maintaining insertion order with the help of LinkedList
			Map<String, Integer> sortedMap = new LinkedHashMap<String, Integer>();
			for (Entry<String, Integer> entry : list)
			{
				sortedMap.put(entry.getKey(), entry.getValue());
			}

			return sortedMap;
		}


		private void characterQualityProcess(Map<Integer, List<PDFCharacter>> pageWiseCharacters, Map<Integer, List<PDFCharacter>> pageWiseOverrideCharacters, Map<Integer, PageAccuracyRecord> pageAccuracyRecordMap) {
			System.out.println(" ------- characterQualityProcess ");
			// TODO Auto-generated method stub
			Map<Integer,List<PDFCharacter>>validCharacterCounts=new TreeMap<Integer, List<PDFCharacter>>();
			Map<Integer,List<PDFCharacter>>inValidCharacterCounts=new TreeMap<Integer, List<PDFCharacter>>();
			for (Integer pgNo : pageWiseCharacters.keySet()) {
				List<PDFCharacter> validCharCount=new ArrayList<PDFCharacter>();
				List<PDFCharacter> inValidCharCount=new ArrayList<PDFCharacter>();
				for (PDFCharacter character : pageWiseCharacters.get(pgNo)) {
					if(CommonOperations.isValidCharacter(character.getStringRepresentation())){
						//validCharCount++;	
						validCharCount.add(character);
					}else{
						//inValidCharCount++;
						inValidCharCount.add(character);
					}
				}
				validCharacterCounts.put(pgNo, validCharCount);
				inValidCharacterCounts.put(pgNo, inValidCharCount);
			}

			//detect ratio
			for (Integer pgNo : pageWiseCharacters.keySet()) {


		//		System.out.println("########Page: "+pgNo);
				int totalPageChars=pageWiseCharacters.get(pgNo).size()+pageWiseOverrideCharacters.get(pgNo).size();
				/*if(totalPageChars<=0){
					System.out.println("No Characters found");
				}*/
				float validChar = (((float)validCharacterCounts.get(pgNo).size()/(float)totalPageChars)*100);
				//System.out.println("ValidCharacter Ratio:\t"+validChar+"%");

				float invalidChar = ((float)inValidCharacterCounts.get(pgNo).size()/(float)totalPageChars)*100;
				//System.out.println("InValid Character Ratio:\t"+invalidChar+"%");

				float ovverride = ((float)pageWiseOverrideCharacters.get(pgNo).size()/(float)totalPageChars)*100;
				//System.out.println("Override Ratio:\t"+ovverride+"%");

				PageAccuracyRecord record = pageAccuracyRecordMap.get(pgNo);
				record.setValidCharacterRatio(validChar);
				record.setInValidCharacterRatio(invalidChar);
//				record.setOverrideRatio(ovverride);

				record.setValidCharacters(validCharacterCounts.get(pgNo));
				record.setInValidCharacters(inValidCharacterCounts.get(pgNo));
//				record.setOverrideCharacters(pageWiseOverrideCharacters.get(pgNo));
			}

		}


		public static void main(String[] args) {

			String inputFile="D:\\Platform\\Phizer\\TestSample\\12131MQMQ525527.pdf"; //

			OCR_Accuracy ocrAcc=new OCR_Accuracy();

			ocrAcc.Apply(inputFile);
		}
	}
