package com.pdf.parser.test;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

public class WordFormation {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		PDDocument doc = PDDocument.load("D:\\SI-Extraction Framework Test\\Bank Statements\\Bank\\CITY_UNION.PDF");
		PDPage page = (PDPage)doc.getDocumentCatalog().getAllPages().get(1);
		
		PDFTextStripper pts = new PDFTextStripper(){
			TextPosition lastChar = null;
			@Override
			protected void processTextPosition(TextPosition tp) {
				if(tp.getCharacter().trim().length()==0)
					return;
//				System.out.print("x="+tp.getX()+" xDir="+tp.getXDirAdj()+" xScale="+tp.getXScale());
				System.out.print("x="+tp.getX()+" xDir="+tp.getTextPos().getXScale());
				System.out.print(" y="+tp.getY()+" yDir="+tp.getTextPos().getYPosition());
				System.out.print(" fontSize="+tp.getFontSize()+"/"+tp.getFontSizeInPt()+" font="+tp.getFont().getBaseFont());
				System.out.print(" width="+tp.getWidth()+" height="+tp.getHeight());
				System.out.print(" nextX="+(tp.getX()+tp.getWidth())+" space="+tp.getWidthOfSpace());
				
				if(lastChar!=null){
					float diff = tp.getX()-(lastChar.getX()+lastChar.getWidth());
					System.out.print(" nextDiff="+diff);
				}
				
				System.out.print(" -- "+tp);
				System.out.println();
				
				lastChar = tp;
			}
		};
		pts.setSortByPosition(true);
		
		pts.processStream(page, page.findResources(), page.getContents().getStream());
	}

}
