package com.pdf.parser.test;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;

import com.pdf.parser.base.PDFVerticalGap;
import com.pdf.parser.pipeline.DefaultParser;

public class SingleVerticalGapsGenerator {

	static int count = 1;
	public static void main(String[] args) throws Exception{
		final String file = "ANNUALS.pdf";
		
		//Clean vgap-output directory
		for(File f : new File("vgap-output").listFiles()){
			while(!f.delete())
				Thread.sleep(10);
		}

		final PDDocument pdf = PDDocument.load(file);

		DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();
		
		final Random random = new Random();
		List<Thread> threads = new ArrayList<Thread>();
		
		for(int pg=0; pg<pdf.getNumberOfPages(); pg++){
			
			if(pg!=1)
				continue;
			
			List<PDFVerticalGap> vgaps = parser.getVgaps().get(pg);
			
			if(vgaps!=null && vgaps.size()>0){
				
				for(final PDFVerticalGap vgap : vgaps){
					
					final PDDocument tempPdf = PDDocument.load(file);
					final PDPage page = (PDPage)tempPdf.getDocumentCatalog().getAllPages().get(pg);
					final float pheight = page.getMediaBox().getHeight();
					
					final int pageNo = pg;
					final int cnt = count++;
					
					threads.add(new Thread(){
						public void run() {
							try {
								PDPageContentStream stream = new PDPageContentStream(tempPdf, page, true, false);
								
								Color color = new Color(random.nextInt(254), random.nextInt(254), random.nextInt(254), 200);				
								stream.setNonStrokingColor(color);
								stream.setStrokingColor(color);
								
								float x = vgap.getRectangle().getX();
								float y = pheight - vgap.getRectangle().getY();
								float width = vgap.getRectangle().getWidth();
								float height = vgap.getRectangle().getHeight();
//								stream.fillRect(vgap.getX(), page.getBleedBox().getHeight()-10-vgap.getY(), vgap.getWidth(), vgap.getHeight());
								stream.addRect(x, y, width, height);
//								System.out.println(vgap.getStringRepresentation()+","+vgap.getX()+","+(page.getBleedBox().getHeight()-10-vgap.getY())+","+vgap.getWidth()+","+vgap.getHeight());
								System.out.println(vgap.getStringRepresentation()+" -> "+x+","+y+","+width+","+height);

								stream.fillRect(10, page.getBleedBox().getHeight(), 10, 10);
								stream.close();
								
								String prefix = cnt%10==cnt ? "0"+cnt : ""+cnt;
								PDDocument temp = new PDDocument();
								temp.importPage(page);
								temp.save("vgap-output/"+prefix+"- "+vgap.getStringRepresentation().replaceAll("[^A-Za-z0-9\\s-]", "")+" -"+pageNo+".pdf");
								temp.close();
								
								tempPdf.close();
								
							} catch (Exception e) {
								e.printStackTrace();
							}
						}
					});
					
					if(threads.size()%1 == 0){
						for(Thread th:threads)
							th.start();
						
						for(Thread th:threads)
							th.join();
						
						threads.clear();
					}
				}
			}
		}
		
		for(Thread th:threads)
			th.start();
		
		for(Thread th:threads)
			th.join();
		
		pdf.save("vgap-output/~1.pdf");
		pdf.close();
	}
}
