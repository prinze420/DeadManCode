package com.pdf.parser.test;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;

public class WordPrinter {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		String file = "D:\\SI-Extraction Framework Test\\UBS\\43302174_2015-09.pdf";
		
		DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();
		
		for(int page=0; page<parser.getWords().size(); page++){
			
			if(page!=4)
				continue;
			
			System.out.println("PAGE "+(page+1));
			PDFWord lastWord = null;
			for(PDFWord word : parser.getWords().get(page)){
				
				if(lastWord!=null){
					float yDiff = Math.abs(lastWord.getRectangle().getY() - word.getRectangle().getY());
					if(yDiff>word.getRectangle().getHeight()/2)
						System.out.println();
				}
				System.out.print("{"+word.toString()+"} ");
				lastWord = word;
			}
			System.out.println("\n");
		}
	}

}
