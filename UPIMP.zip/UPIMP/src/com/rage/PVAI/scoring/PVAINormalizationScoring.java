package com.rage.PVAI.scoring;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.rage.nlp.PVAI.AENormalization;
import com.rage.nlp.PVAI.FileReader;
import com.rage.nlp.PVAI.MatchTypeCategorization;
import com.rage.nlp.PVAI.Triplet;

public class PVAINormalizationScoring
{

	public static void main(String[] args)
	{
		String type="case-ae";
		String input="CEP";
		String inputCasesFileName ="data/input/"+input+".txt";
		String resultsFileName = "data/results/"+type+input+".txt";
		String resultsIndexes = "0,1";
		String answerFileName = "data/answer/"+type+".txt";
		String answereIndexes = "0,1,2,3";
		String outputFileName ="data/output/PVAINormScoring_"+type+input+".csv";
		String answerFileDelimiter="\\t";
		String resultsFileDelimiter="\\t";
		Set<String> cases= FileReader.readFile(inputCasesFileName);
		HashMap<String,HashSet<String>> results = populateResultsData(resultsFileName, resultsFileDelimiter, resultsIndexes);
		System.out.println("Results size ::"+results.size());
		Map<String, Set<Triplet<String, String, String>>> answers= populateAnswerData(answerFileName, answerFileDelimiter, answereIndexes);
		System.out.println("Answer size ::"+answers.size());
		updateScores(outputFileName,",",results, answers, cases, type);


	}

	private static void updateScores(String outputFileName,String delimiter, 
			HashMap<String, HashSet<String>> results, Map<String, Set<Triplet<String, String, String>>> goldResults,
			Set<String> cases, String type)
	{
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(outputFileName);
			fileWriter.append("Case No"+delimiter+"Total Entities"+delimiter+"Total Entities Found"+delimiter+"Answer Values"+delimiter+"Result Values"+delimiter+"TP Count"+delimiter+"FP Count"+delimiter+"FN Count"+delimiter+"Additional TP Count\n");
			calculateScores(type, fileWriter, results, cases, goldResults, delimiter);
			System.out.println("Excel written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}


	private static void calculateScores(String sheetName, FileWriter fileWriter, HashMap<String, HashSet<String>> allResults,Set<String> cases, Map<String, Set<Triplet<String, String, String>>> allAnswers, String delimiter) throws IOException
	{
		int casesNotPresentinAnswerkey=0;
		int totalTP=0;
		int totalFP=0;
		int totalFN=0;
		int i=0;
		for(String caseNum : cases)
		{
			Set<Triplet<String, String, String>> answers= allAnswers.containsKey(caseNum) ? allAnswers.get(caseNum) : new HashSet<Triplet<String,String,String>>();
			HashSet<String> results=allResults.containsKey(caseNum) ? allResults.get(caseNum) : new HashSet<String>();
			int totalEntities = answers.size();
			int totalEntitiesFound=results.size();
			int TP=0;
			int FP=0;
			int FN=0;
			int addTP=0;
			String answereValues= answers.toString().replaceAll("\\[|\\]", "").replaceAll(", ", " AND ");
			String resultsValues= createResultsString(results);
			Set<String> tpValues= new HashSet<String>();
			if(totalEntities>0)
			{
				for(Triplet<String, String, String> answer : answers)
				{
					List<String> values=new ArrayList<String>();
					if(!answer.getValue1().isEmpty())
						values.add(answer.getValue1());
					if(!answer.getValue2().isEmpty())
						values.add(answer.getValue2());
					if(!answer.getValue3().isEmpty())
						values.add(answer.getValue3());

					boolean isPresent=true;
					if(answer.getValue1().toLowerCase().startsWith("no ") 
							|| answer.getValue2().toLowerCase().startsWith("no ")
							|| answer.getValue3().toLowerCase().startsWith("no "))
						isPresent=false;

					if(isPresent)
					{
						Set<String> thisTpValues= new HashSet<String>();
						String matchType="";
						for(String concept : results)
						{
							for(int l=0 ; l<values.size() ; l++)
							{
								String goldValue=values.get(l);
								matchType= MatchTypeCategorization.checkMatchType(goldValue.trim(), concept.trim(), true);
								if(matchType.equalsIgnoreCase("Exact Match") || matchType.equalsIgnoreCase("Partial Match"))
								{
									thisTpValues.add(concept);
									break;
								}
							}
						}
						if(thisTpValues.size()>0)
						{
							TP++;
							tpValues.addAll(thisTpValues);
						}
					}
					else
					{
						TP++;
					}
				}
				if(TP>0)
				{
					addTP=tpValues.size()-TP;
					if(addTP<=0)
						addTP=0;
				}
				FP=results.size()-tpValues.size();
				FN=answers.size()-(TP+FP);
				if(FN<=0)
					FN=0;
				totalTP= totalTP+ TP;
				totalFP=totalFP +FP;
				totalFN= totalFN+FN;
			}
			else
			{
				casesNotPresentinAnswerkey++;
			}
i++;
			fileWriter.append(caseNum+delimiter+totalEntities+delimiter+totalEntitiesFound+delimiter+answereValues+delimiter+resultsValues+delimiter+TP+delimiter+FP+delimiter+FN+delimiter+addTP+"\n");
			fileWriter.flush();
			if(i==10)
				break;
		}

		Double Precision=(new Double(totalTP)/new Double(totalTP+totalFP));
		Double Recall=(new Double(totalTP)/new Double(totalTP+totalFN));
		Double FScore=2*((Precision*Recall)/(Precision+Recall));

		System.out.println("Total Cases not present in Answer key ::"+casesNotPresentinAnswerkey);
		System.out.println("Precison ::"+Precision);
		System.out.println("Recall ::"+Recall);
		System.out.println("FScore ::"+FScore);

	}

	private static String createResultsString(HashSet<String> results)
	{
		String ret="";
		for(String concept : results)
		{
			String normalizedConcept=AENormalization.findNormalizedAE(concept).getValue2();
			String result = concept + "==[" +normalizedConcept+"]";
			ret= ret.isEmpty() ? result : (ret + " AND "+ result);
		}
		return ret;
	}

	private static Map<String, Set<Triplet<String, String, String>>> populateAnswerData(String fileName, String delimiter, String indexStr)
	{
		HashMap<String, Set<Triplet<String, String, String>>> ret= new HashMap<String, Set<Triplet<String, String, String>>>();
		List<List<String>> lines= FileReader.readFile(fileName, delimiter);
		List<String> indexes=Arrays.asList(indexStr.split(","));
		for(int i=0; i<lines.size() ; i++)
		{
			List<String> values=lines.get(i);
			//System.out.println(values);
			String caseID="";
			Triplet<String, String, String> ae_triplet=null;
			if(indexes.size()==4)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				String v1 = values.get(Integer.parseInt(indexes.get(1))).trim().replaceAll(",", " # ");;
				String v2 =values.get(Integer.parseInt(indexes.get(2))).trim().replaceAll(",", " # ");;
				String v3 = values.get(Integer.parseInt(indexes.get(3))).trim().replaceAll(",", " # ");;
				ae_triplet= new Triplet<String, String, String>(v1, v2, v3);

			}
			else if(indexes.size()==3)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				String v1 = values.get(Integer.parseInt(indexes.get(1))).trim().replaceAll(",", " # ");;
				String v2 = values.get(Integer.parseInt(indexes.get(2))).trim().replaceAll(",", " # ");;
				String v3 = "";
				ae_triplet= new Triplet<String, String, String>(v1, v2, v3);
			}
			else if(indexes.size()==2)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				String v1 = values.get(Integer.parseInt(indexes.get(1))).trim().replaceAll(",", " # ");;
				String v2 = "";
				String v3 = "";
				ae_triplet= new Triplet<String, String, String>(v1, v2, v3);
			}
			Set<Triplet<String, String, String>> triplets =ret.containsKey(caseID) ? ret.get(caseID) : new HashSet<Triplet<String,String,String>>();
			triplets.add(ae_triplet);
			ret.put(caseID, triplets);
		}		
		return ret;
	}
	private static HashMap<String,HashSet<String>> populateResultsData(String fileName, String delimiter, String indexStr) 
	{
		HashMap<String,HashSet<String>> ret = new HashMap<String, HashSet<String>>();
		List<List<String>> lines= FileReader.readFile(fileName, delimiter);
		List<String> indexes=Arrays.asList(indexStr.split(","));
		for(int i=1; i<lines.size() ; i++)
		{
			List<String> values=lines.get(i);
			String caseNum=values.get(Integer.parseInt(indexes.get(0))).trim() ;
			String concept=values.get(Integer.parseInt(indexes.get(1))).trim();
			HashSet<String> concepts = ret.containsKey(caseNum) ? ret.get(caseNum) : new HashSet<String>();
			concepts.add(concept.replaceAll(",", " # ").replaceAll("\\s+", " "));
			ret.put(caseNum, concepts);
		}
		return ret;
	}

	

}