package com.rage.PVAI.scoring;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test
{

	public static void main(String[] args)
	{
		String conceptStr="33";
		Matcher m = Pattern.compile("[a-zA-Z]+").matcher(conceptStr);
		if(!m.find())
			conceptStr =conceptStr + " Years";
		System.out.println(conceptStr);
	}
}
