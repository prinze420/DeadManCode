package com.rage.PVAI.scoring;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import com.rage.nlp.PVAI.AENormalization;
import com.rage.nlp.PVAI.AnswerKeyLoader;
import com.rage.nlp.PVAI.CSVoutputgenerator;
import com.rage.nlp.PVAI.ConceptCleanup;
import com.rage.nlp.PVAI.Feature;
import com.rage.nlp.PVAI.FeatureExtractor;
import com.rage.nlp.PVAI.FieldName;
import com.rage.nlp.PVAI.FileReader;
import com.rage.nlp.PVAI.MatchTypeCategorization;
import com.rage.nlp.PVAI.MetadataLoader;
import com.rage.nlp.PVAI.Pair;
import com.rage.nlp.PVAI.Triplet;
import com.rage.nlp.core.SentenceBoundaryDetector;

public class ConsolidationAndScoring
{
	public static boolean populateInitails =false;
	public static boolean test =false;
	public static Map<Set<String>,Set<String>> meddraMap;
	public static Map<String,Set<String>> normalizedAEMap=new HashMap<String, Set<String>>();

	public static void main(String[] args)
	{
		String nlpResultsFile = args[0];
		String extractionResultsFile = args[1];
		String outputFileName = args[2];
		String inputFilePath=args[3];
		populateInitails=Boolean.parseBoolean(args[4]);
		test=Boolean.parseBoolean(args[5]);
		String scoringFolderName=args[6];
		String fields=args[7];
		String csvFolderName=args[8];
		Set<FieldName> specificFields= new HashSet<FieldName>();
		if(!fields.isEmpty())
		{
			List<String> inputFields= Arrays.asList(fields.split(","));
			for(String field:inputFields)
			{
				FieldName fieldName = FieldName.valueOf(field.trim());
				specificFields.add(fieldName);
			}
		}
		File f = new File(scoringFolderName);
		f.mkdir();

		f = new File(csvFolderName);
		f.mkdir();

		Set<String> cases= extractAllCases(inputFilePath);
		List<List<String>> nlpResults = MetadataLoader.readFile(new File(nlpResultsFile), "\t");
		List<List<String>> extractionResults = MetadataLoader.readFile(new File(extractionResultsFile), "\t");

		Map<FieldName,Map<String, Map<String, Map<String,Map<String,String>>>>> consolidatedResults= new HashMap<FieldName, Map<String,Map<String,Map<String,Map<String,String>>>>>();
		appendNLPResults(nlpResults, consolidatedResults, cases);
		appendExtractionResults(extractionResults,consolidatedResults,cases,specificFields);
		cases=new TreeSet<String>(cases);

		Map<FieldName,Map<String, Set<String>>> allCsvResults= new HashMap<FieldName, Map<String,Set<String>>>();
		writeResultsToExcel(scoringFolderName, outputFileName, cases, consolidatedResults , test, specificFields, allCsvResults);

		CSVoutputgenerator.updateCSVOutput(csvFolderName, allCsvResults, false);
	}

	private static void appendExtractionResults(List<List<String>> extractionResults,
			Map<FieldName,Map<String, Map<String, Map<String,Map<String,String>>>>> consolidatedResults, 
			Set<String> cases, Set<FieldName> specificFields)
	{

		Map<String,Map<FieldName,Set<String>>> caseFieldAreaMap = new HashMap<String, Map<FieldName,Set<String>>>();
		System.out.println("Extraction Results Size ::"+extractionResults.size());
		for(int i=1 ; i<extractionResults.size() ; i++)
		{

			String paragraph="";
			String type="Extraction";
			List<String> values = extractionResults.get(i);
			String fileName= values.get(0).trim();
			String pageNo= values.get(1).trim();
			String extractionType=values.get(2).toLowerCase().trim();
			String marker= values.get(3).trim();
			String value= values.size()>=5 ? values.get(4) :"";
			String nlp_process= values.size()>=6 ? values.get(5) :"";
			value = value.replaceAll("\\[|\\]", "").replaceAll("\\s+", " ").trim();
			value=FileReader.applyAsciiFilter(value);
			cases.add(fileName);
			pageNo=pageNo.replaceAll("#", "").trim();
			Vector<String> sentences = new Vector<String>();
			if(extractionType.equalsIgnoreCase("paragraph") || nlp_process.equalsIgnoreCase("Y"))
			{
				sentences=SentenceBoundaryDetector.detectSentenceBoundary(value);
				if(sentences.size()<=1)
				{
					extractionType="no";
					nlp_process="N";
				}
			}

			FieldName fieldName=MetadataLoader.getFieldMapping(marker.toLowerCase());
			if(fieldName.equals(FieldName.NONE))
			{
				System.out.println("Ignoring Values:::"+values);
				continue;
			}
			if(!fieldName.equals(FieldName.AE_VERBATIM) && specificFields.size()>0 && !specificFields.contains(fieldName))
				continue;
			Map<String, Map<String, Map<String,Map<String,String>>>> patientNames=consolidatedResults.containsKey(FieldName.PAT_INITIALS) ? consolidatedResults.get(FieldName.PAT_INITIALS) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();
			Map<String, Map<String, Map<String,Map<String,String>>>> ages=consolidatedResults.containsKey(FieldName.PAT_AGE_UNIT) ? consolidatedResults.get(FieldName.PAT_AGE_UNIT) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();
			Map<String, Map<String, Map<String,Map<String,String>>>> genders=consolidatedResults.containsKey(FieldName.GENDER) ? consolidatedResults.get(FieldName.GENDER) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();

			Map<String, Map<String, Map<String,Map<String,String>>>> fieldResults=consolidatedResults.containsKey(fieldName) ? consolidatedResults.get(fieldName) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();
			Map<String, Map<String,Map<String,String>>> pns = fieldResults.containsKey(fileName) ? fieldResults.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
			if(fieldName.equals(FieldName.GENDER) || fieldName.equals(FieldName.OCCUPATION) || fieldName.equals(FieldName.PAT_AGE_UNIT) || fieldName.equals(FieldName.REPORTER_TYPE))
			{
				if(extractionType.equalsIgnoreCase("checkbox"))
				{
					pns= new HashMap<String, Map<String,Map<String,String>>>();
				}
			}
			Set<String> results=new HashSet<String>();
			if(fieldName.equals(FieldName.TRADE_NAME))
			{
				Set<String> splits=new HashSet<String>();
				if(extractionType.equalsIgnoreCase("paragraph") || nlp_process.equalsIgnoreCase("Y"))
				{
					Set<String> patients=new HashSet<String>();
					StringBuffer newValue= new StringBuffer();
					for(String sentence : sentences)
					{
						Map<Feature,Set<String>> featureMap=FeatureExtractor.extractFeatures(sentence, "Extraction");
						Set<String> thisEvents=featureMap.containsKey(Feature.DrugName) ? featureMap.get(Feature.DrugName) : new HashSet<String>();
						Set<String> thisPatients=featureMap.containsKey(Feature.PatientName) ? featureMap.get(Feature.PatientName) : new HashSet<String>();
						patients.addAll(thisPatients);
						if(thisEvents.size()>0)
							splits.addAll(thisEvents);
						else
							newValue.append(sentence+" ");
					}
					if(!newValue.toString().trim().isEmpty())
						splits.add(newValue.toString().trim());

					if(patients.size()>0)
						appendExtraPatients(patientNames, fileName, pageNo, patients, value);
					if(splits.size()>0)
						paragraph=value;
				}
				else
				{
					splits.add(value);
				}
				for(String split:splits)
				{
					if(!extractionType.equalsIgnoreCase("paragraph"))
					{
						split=ConceptCleanup.refineConcept(split);
					}
					else
						split=split.replaceAll("\\s+", " ").trim();
					if(split.isEmpty() || (split.contains("See ") && split.contains(" Answer ")))
						continue;
					results.add(split);
				}
			}
			else if(fieldName.equals(FieldName.PAT_INITIALS))
			{
				if(value.contains("http"))
					value=value.substring(0,value.indexOf("http"));
				if(value.contains("profile"))
					value=value.substring(0,value.indexOf("profile"));
				value=ConceptCleanup.refinePatientConcept(value);
				if(value.isEmpty())
					continue;
				results.add(value);
			}
			else if(fieldName.equals(FieldName.AE_VERBATIM))
			{
				Set<String> splits=new HashSet<String>();
				Set<String> age=new HashSet<String>();
				Set<String> genderValues=new HashSet<String>();
				if(extractionType.equalsIgnoreCase("paragraph") || nlp_process.equalsIgnoreCase("Y"))
				{
					Set<String> patients=new HashSet<String>();
					StringBuffer newValue= new StringBuffer();
					for(String sentence : sentences)
					{
						Map<Feature,Set<String>> featureMap=FeatureExtractor.extractFeatures(sentence, "Extraction");
						Set<String> thisEvents=featureMap.containsKey(Feature.AdverseEvent) ? featureMap.get(Feature.AdverseEvent) : new HashSet<String>();
						Set<String> thisPatients=featureMap.containsKey(Feature.PatientName) ? featureMap.get(Feature.PatientName) : new HashSet<String>();
						patients.addAll(thisPatients);
						if(thisEvents.size()>0)
							splits.addAll(thisEvents);
						else
							newValue.append(sentence+" ");
					}
					if(!newValue.toString().trim().isEmpty())
						splits.add(newValue.toString().trim());

					if(patients.size()>0)
						appendExtraPatients(patientNames, fileName, pageNo, patients, value);

					if(splits.size()>0)
						paragraph=value;
				}
				else
				{
					sentences=SentenceBoundaryDetector.detectSentenceBoundary(value);
					splits.add(value);
				}
				for(String sentence : sentences)
				{
					String gender=ConceptCleanup.extractGender(sentence);
					if(!gender.isEmpty())
						genderValues.add(gender);
					String ageUnit=ConceptCleanup.extractAge(sentence);
					if(!ageUnit.isEmpty())
						age.add(ageUnit);
				}
				if(age.size()>0)
				{
					System.out.println("ADDED AGE ::"+fileName+"\t"+age+"\t"+value);
					appendExtraPatients(ages, fileName, pageNo, age, value);
				}
				if(genderValues.size()>0)
				{
					System.out.println("ADDED Gender ::"+fileName+"\t"+genderValues+"\t"+value);
					appendExtraPatients(genders, fileName, pageNo, genderValues, value);
				}
				for(String split:splits)
				{
					String split1=ConceptCleanup.refineConcept(split);
					if(split.isEmpty() || split.length()<=2 || split1.isEmpty() || (split.contains("See ") && split.contains(" Answer ")))
						continue;
					results.add(split);
				}
			}
			else if(fieldName.equals(FieldName.PAT_DOB_PARTIAL))
			{
				results.add(MatchTypeCategorization.getLongDate(value));
			}
			else if(fieldName.equals(FieldName.PAT_AGE_UNIT))
			{
				value=ConceptCleanup.getAge(value);
				results.add(value);
			}
			else if(fieldName.equals(FieldName.GENDER))
			{
				value=ConceptCleanup.getGender(value);
				if(!value.isEmpty())
					results.add(value);
			}
			else
				results.add(value);
			for(String split:results)
			{
				Map<String,Map<String,String>> typesMap=pns.containsKey(split)? pns.get(split): new HashMap<String, Map<String,String>>();
				Map<String,String> pageParaInfo =typesMap.containsKey(type) ? typesMap.get(type) : new HashMap<String, String>();
				String para=pageParaInfo.containsKey(pageNo) ? pageParaInfo.get(pageNo)+" "+ paragraph: paragraph;
				pageParaInfo.put(pageNo, para.trim());
				typesMap.put(type, pageParaInfo);
				pns.put(split, typesMap);
			}
			if(fieldName.equals(FieldName.GENDER) || fieldName.equals(FieldName.OCCUPATION) || fieldName.equals(FieldName.PAT_AGE_UNIT) || fieldName.equals(FieldName.REPORTER_TYPE))
			{
				Map<FieldName,Set<String>> fieldAreaMap = caseFieldAreaMap.containsKey(fileName) ? caseFieldAreaMap.get(fileName) : new HashMap<FieldName, Set<String>>();
				Set<String> areas=fieldAreaMap.containsKey(fieldName) ? fieldAreaMap.get(fieldName) : new HashSet<String>();
				if(areas.contains("checkbox"))
				{
					System.out.println("Ignoring CHECKBOX is present ::\t"+values);
				}
				else 
				{
					areas.add(extractionType);
					caseFieldAreaMap.put(fileName, fieldAreaMap);	
					fieldResults.put(fileName, pns);
					consolidatedResults.put(fieldName, fieldResults);
				}
			}
			else
			{
				fieldResults.put(fileName, pns);
				consolidatedResults.put(fieldName, fieldResults);
			}
			consolidatedResults.put(FieldName.GENDER, genders);
			consolidatedResults.put(FieldName.PAT_AGE_UNIT, ages);
			consolidatedResults.put(FieldName.PAT_INITIALS, patientNames);
		}
	}


	private static void appendExtraPatients(Map<String, Map<String, Map<String, Map<String, String>>>> patientNames, 
			String fileName, String pageNo,Set<String> values, String paragraph)
	{
		String type ="NLP";
		Map<String, Map<String,Map<String,String>>> pns = patientNames.containsKey(fileName) ? patientNames.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
		for(String split:values)
		{
			if(split.isEmpty())
				continue;
			Map<String,Map<String,String>> typesMap=pns.containsKey(split)? pns.get(split): new HashMap<String, Map<String,String>>();
			Map<String,String> pageParaInfo =typesMap.containsKey(type) ? typesMap.get(type) : new HashMap<String, String>();
			String para=pageParaInfo.containsKey(pageNo) ? pageParaInfo.get(pageNo)+" "+paragraph : paragraph;
			pageParaInfo.put(pageNo, para.trim());
			typesMap.put(type, pageParaInfo);
			pns.put(split, typesMap);
		}
		patientNames.put(fileName, pns);
	}

	private static void appendNLPResults(List<List<String>> nlpResults, 
			Map<FieldName,Map<String, Map<String, Map<String,Map<String,String>>>>> consolidatedResults,
			Set<String> cases)
	{
		System.out.println("NLP Results Size ::"+nlpResults.size());
		for(int i=1 ; i<nlpResults.size() ; i++)
		{
			String type="NLP";
			List<String> values = nlpResults.get(i);
			String fileName= values.get(0).trim();
			String pageNo=values.get(1).trim();
			String paragraph=values.get(2).trim();
			String pn= values.get(3).trim();
			String ae= values.get(4).trim(); 
			String dn= values.get(5).trim();
			pageNo=pageNo.replaceAll("#", "").trim();
			cases.add(fileName);
			if(!pn.isEmpty())
			{
				Map<String, Map<String, Map<String,Map<String,String>>>> patientNames=consolidatedResults.containsKey(FieldName.PAT_INITIALS) ? consolidatedResults.get(FieldName.PAT_INITIALS) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();
				Map<String, Map<String,Map<String,String>>> pns = patientNames.containsKey(fileName) ? patientNames.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
				Set<String> splits = new HashSet<String>(Arrays.asList(pn.split(", ")));
				for(String split:splits)
				{
					split=ConceptCleanup.refineConcept(split);
					if(split.isEmpty())
						continue;
					Map<String,Map<String,String>> typesMap=pns.containsKey(split)? pns.get(split): new HashMap<String, Map<String,String>>();
					Map<String,String> pageParaInfo =typesMap.containsKey(type) ? typesMap.get(type) : new HashMap<String, String>();
					String para=pageParaInfo.containsKey(pageNo) ? pageParaInfo.get(pageNo) : "";
					para=para+" "+paragraph;
					pageParaInfo.put(pageNo, para.trim());
					typesMap.put(type, pageParaInfo);
					pns.put(split, typesMap);
				}
				patientNames.put(fileName, pns);
				consolidatedResults.put(FieldName.PAT_INITIALS, patientNames);
			}

			if(!ae.isEmpty())
			{
				Map<String, Map<String, Map<String,Map<String,String>>>> adverseEvents=consolidatedResults.containsKey(FieldName.AE_VERBATIM) ? consolidatedResults.get(FieldName.AE_VERBATIM) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();	
				Map<String, Map<String,Map<String,String>>> pns = adverseEvents.containsKey(fileName) ? adverseEvents.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
				Set<String> splits = new HashSet<String>(Arrays.asList(ae.split(", ")));
				for(String split:splits)
				{
					String split1=ConceptCleanup.refineConcept(split);
					if(split.isEmpty() || split1.isEmpty())
						continue;
					Map<String,Map<String,String>> typesMap=pns.containsKey(split)? pns.get(split): new HashMap<String, Map<String,String>>();
					Map<String,String> pageParaInfo =typesMap.containsKey(type) ? typesMap.get(type) : new HashMap<String, String>();
					String para=pageParaInfo.containsKey(pageNo) ? pageParaInfo.get(pageNo) : "";
					para=para+" "+paragraph;
					pageParaInfo.put(pageNo, para.trim());
					typesMap.put(type, pageParaInfo);
					pns.put(split, typesMap);
				}
				adverseEvents.put(fileName, pns);
				consolidatedResults.put(FieldName.AE_VERBATIM, adverseEvents);
			}

			if(!dn.isEmpty())
			{
				Map<String, Map<String, Map<String,Map<String,String>>>> drugNames=consolidatedResults.containsKey(FieldName.TRADE_NAME) ? 	consolidatedResults.get(FieldName.TRADE_NAME) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();	
				Map<String, Map<String,Map<String,String>>> pns = drugNames.containsKey(fileName) ? drugNames.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
				Set<String> splits = new HashSet<String>(Arrays.asList(dn.split(", ")));
				for(String split:splits)
				{
					split=ConceptCleanup.refineConcept(split);
					if(split.isEmpty())
						continue;
					if(split.split(" ").length==1)
						split=split+"_Suspect";
					Map<String,Map<String,String>> typesMap=pns.containsKey(split)? pns.get(split): new HashMap<String, Map<String,String>>();
					Map<String,String> pageParaInfo =typesMap.containsKey(type) ? typesMap.get(type) : new HashMap<String, String>();
					String para=pageParaInfo.containsKey(pageNo) ? pageParaInfo.get(pageNo) : "";
					para=para+" "+paragraph;
					pageParaInfo.put(pageNo, para.trim());
					typesMap.put(type, pageParaInfo);
					pns.put(split, typesMap);
				}
				drugNames.put(fileName, pns);
				consolidatedResults.put(FieldName.TRADE_NAME, drugNames);
			}
		}
	}

	public static Set<String> extractAllCases(String inputFilePath)
	{
		Set<String> cases = new TreeSet<String>();
		File f = new File(inputFilePath);
		try 
		{ 
			if (f.isDirectory()) 
			{
				for (File inputFileName : f.listFiles())
				{
					if(!inputFileName.isDirectory())
					{
						if(inputFileName.getName().endsWith(".txt"))
						{
							String caseName=inputFileName.getName().replaceAll(".txt", "").trim();
							cases.add(caseName);
						}
					}
				}
			}
			else
			{
				File inputFileName=f;
				if(inputFileName.getName().endsWith(".txt"))
				{
					String caseName=inputFileName.getName().replaceAll(".txt", "").trim();
					cases.add(caseName);
				}
			}
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return cases;
	}

	public static void writeResultsToExcel(String scoringFolderName, String fileName, Set<String> cases, 
			Map<FieldName,Map<String, Map<String, Map<String,Map<String,String>>>>> consolidatedResults, 
			boolean test, Set<FieldName> specificFields , Map<FieldName,Map<String, Set<String>>> allCsvResults) 
	{

		try
		{
			FileOutputStream fileOut = new FileOutputStream(new File(fileName));
			HSSFWorkbook workbook = new HSSFWorkbook();
			for(FieldName fieldName : consolidatedResults.keySet())
			{
				if(specificFields.size()>0 && !specificFields.contains(fieldName))
					continue;
				Map<String, Map<String, Map<String,Map<String,String>>>> fieldResults=consolidatedResults.containsKey(fieldName) ? consolidatedResults.get(fieldName) : new HashMap<String, Map<String,Map<String,Map<String,String>>>>();
				System.out.println("Writing to Excel ::"+fieldName+"\t"+fieldResults.size());
				if(fieldName.equals(FieldName.AE_VERBATIM))
				{
					writeToExcel(scoringFolderName, fieldName, cases, fieldResults, workbook, test, allCsvResults);
				}
				else
				{
					writeToExcel(scoringFolderName, fieldName, cases, fieldResults, workbook, test, allCsvResults);
				}
			}
			workbook.write(fileOut);
			fileOut.close();
			System.out.println("Excel written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	private static void writeToExcel(String scoringFolderName, FieldName fieldName, Set<String> cases, 
			Map<String, Map<String, Map<String, Map<String, String>>>> resultMap , HSSFWorkbook workbook, boolean test, 
			Map<FieldName,Map<String, Set<String>>> allCsvResults)
	{
		String sheetName=fieldName.toString();
		HSSFSheet sheet = workbook.createSheet(sheetName);
		HSSFSheet sheet1=null;
		HSSFSheet sheet2=null;
		Row header = sheet.createRow(0);
		header.createCell(0).setCellValue("Case No");
		header.createCell(1).setCellValue(sheetName);
		header.createCell(2).setCellValue("Answer");
		header.createCell(3).setCellValue("Extraction Type");
		header.createCell(4).setCellValue("Page No");
		header.createCell(5).setCellValue("Paragraph");
		header.createCell(6).setCellValue("Match Type");
		int j=1;
		int i=1;

		Map<String, Set<String>> allResults = new HashMap<String, Set<String>>();
		Map<String, Set<String>> allResults1 = new HashMap<String, Set<String>>();
		Map<String, Set<String>> allResults2 = new HashMap<String, Set<String>>();
		for(String fileName : cases)
		{
			String caseID=fileName;
			Set<String> thisResults= new HashSet<String>();
			Set<String> thisResults1= new HashSet<String>();
			Set<String> thisResults2= new HashSet<String>();
			Map<String, Map<String,Map<String,String>>> results= resultMap.containsKey(fileName)? resultMap.get(fileName) : new HashMap<String, Map<String,Map<String,String>>>();
			Set<String> answers = new HashSet<String>(AnswerKeyLoader.getAnswer(fieldName, caseID));
			String answer=answers.toString().replaceAll("\\[|\\]", "").trim();
			if(results.size()==0)
			{
				if(j<60000)
				{
					Row dataRow = sheet.createRow(i);
					dataRow.createCell(0).setCellValue(caseID);
					dataRow.createCell(1).setCellValue("");
					dataRow.createCell(2).setCellValue(answer);
					dataRow.createCell(3).setCellValue("");
					dataRow.createCell(4).setCellValue("");
					dataRow.createCell(5).setCellValue("");
					dataRow.createCell(6).setCellValue("Not Matched");
				}
				if(j==60000 && sheet1==null)
				{
					sheet1 = workbook.createSheet(sheetName+"_1");
					Row header1 = sheet1.createRow(0);
					header1.createCell(0).setCellValue("Case No");
					header1.createCell(1).setCellValue(sheetName);
					header1.createCell(2).setCellValue("Answer");
					header1.createCell(3).setCellValue("Extraction Type");
					header1.createCell(4).setCellValue("Page No");
					header1.createCell(5).setCellValue("Paragraph");
					header1.createCell(6).setCellValue("Match Type");
					i=1;
				}
				if(j==120000 && sheet2==null)
				{
					sheet2 = workbook.createSheet(sheetName+"_2");
					Row header1 = sheet2.createRow(0);
					header1.createCell(0).setCellValue("Case No");
					header1.createCell(1).setCellValue(sheetName);
					header1.createCell(2).setCellValue("Answer");
					header1.createCell(3).setCellValue("Extraction Type");
					header1.createCell(4).setCellValue("Page No");
					header1.createCell(5).setCellValue("Paragraph");
					header1.createCell(6).setCellValue("Match Type");
					i=1;
				}
				if(j>=60000 && j<120000)
				{
					Row dataRow = sheet1.createRow(i);
					dataRow.createCell(0).setCellValue(caseID);
					dataRow.createCell(1).setCellValue("");
					dataRow.createCell(2).setCellValue(answer);
					dataRow.createCell(3).setCellValue("");
					dataRow.createCell(4).setCellValue("");
					dataRow.createCell(5).setCellValue("");
					dataRow.createCell(6).setCellValue("Not Matched");
				}
				if(j>=1200000)
				{
					Row dataRow = sheet2.createRow(i);
					dataRow.createCell(0).setCellValue(caseID);
					dataRow.createCell(1).setCellValue("");
					dataRow.createCell(2).setCellValue(answer);
					dataRow.createCell(3).setCellValue("");
					dataRow.createCell(4).setCellValue("");
					dataRow.createCell(5).setCellValue("");
					dataRow.createCell(6).setCellValue("Not Matched");
				}
				i++;
				j++;
			}
			for(String conceptStr: results.keySet())
			{
				Map<String,Map<String,String>> typeMap= results.get(conceptStr);
				conceptStr=conceptStr.replaceAll("\\s+", " ").trim();
				if(fieldName.equals(FieldName.AE_VERBATIM))
				{
					Pair<String> pair =AENormalization.findNormalizedAE(conceptStr);
					String normalizedAE=pair.getValue1();
					String llt=pair.getValue2();
					thisResults1.add(normalizedAE);
					if(!llt.isEmpty())
						thisResults2.add(llt);
					System.out.println("Normalized Concept ::\t"+caseID+"\t"+conceptStr+"\t"+normalizedAE+"\t"+llt);
				}
				String matchType= test ? "": MatchTypeCategorization.checkMatchType(answers,conceptStr.toLowerCase().trim());
				if(populateInitails && fieldName.equals(FieldName.PAT_INITIALS))
					conceptStr=ConceptCleanup.findPatientInitials(conceptStr);

				thisResults.add(conceptStr);

				Map<String,String> pageParaNLP = typeMap.containsKey("NLP") ? typeMap.get("NLP") : new HashMap<String, String>();
				Map<String,String> pageParaExtraction = typeMap.containsKey("Extraction") ? typeMap.get("Extraction") : new HashMap<String, String>();
				String type ="";
				Map<String,String> pagePara = new HashMap<String, String>();
				if(pageParaNLP.size()!=0 && pageParaExtraction.size()!=0)
				{
					System.out.println("Combining ::"+fileName+"\t"+sheetName+"\t"+conceptStr);
					type="NLP and Extraction";
					pagePara.putAll(pageParaExtraction);
					pagePara.putAll(pageParaNLP);
				}
				else if(pageParaNLP.size()==0)
				{
					type="Extraction";
					pagePara=pageParaExtraction;
				}
				else
				{
					type="NLP";
					pagePara=pageParaNLP;
				}	
				if(j<60000)
				{
					for(String pageNo: pagePara.keySet())
					{
						Row dataRow = sheet.createRow(i);
						dataRow.createCell(0).setCellValue(caseID);
						dataRow.createCell(1).setCellValue(conceptStr);
						dataRow.createCell(2).setCellValue(answer);
						dataRow.createCell(3).setCellValue(type);
						dataRow.createCell(4).setCellValue(pageNo);
						dataRow.createCell(5).setCellValue(pagePara.get(pageNo));
						dataRow.createCell(6).setCellValue(matchType);
					}
				}
				if(j==60000 && sheet1==null)
				{
					sheet1 = workbook.createSheet(sheetName+"_1");
					Row header1 = sheet1.createRow(0);
					header1.createCell(0).setCellValue("Case No");
					header1.createCell(1).setCellValue(sheetName);
					header1.createCell(2).setCellValue("Answer");
					header1.createCell(3).setCellValue("Extraction Type");
					header1.createCell(4).setCellValue("Page No");
					header1.createCell(5).setCellValue("Paragraph");
					header1.createCell(6).setCellValue("Match Type");
					i=1;
				}
				if(j==1200000 && sheet2==null)
				{
					sheet2 = workbook.createSheet(sheetName+"_2");
					Row header1 = sheet2.createRow(0);
					header1.createCell(0).setCellValue("Case No");
					header1.createCell(1).setCellValue(sheetName);
					header1.createCell(2).setCellValue("Answer");
					header1.createCell(3).setCellValue("Extraction Type");
					header1.createCell(4).setCellValue("Page No");
					header1.createCell(5).setCellValue("Paragraph");
					header1.createCell(6).setCellValue("Match Type");
					i=1;
				}
				if(j>=60000 && j<120000)
				{
					for(String pageNo: pagePara.keySet())
					{
						Row dataRow = sheet1.createRow(i);
						dataRow.createCell(0).setCellValue(caseID);
						dataRow.createCell(1).setCellValue(conceptStr);
						dataRow.createCell(2).setCellValue(answer);
						dataRow.createCell(3).setCellValue(type);
						dataRow.createCell(4).setCellValue(pageNo);
						dataRow.createCell(5).setCellValue(pagePara.get(pageNo));
						dataRow.createCell(6).setCellValue(matchType);
					}
				}
				if(j>=1200000)
				{
					for(String pageNo: pagePara.keySet())
					{
						Row dataRow = sheet2.createRow(i);
						dataRow.createCell(0).setCellValue(caseID);
						dataRow.createCell(1).setCellValue(conceptStr);
						dataRow.createCell(2).setCellValue(answer);
						dataRow.createCell(3).setCellValue(type);
						dataRow.createCell(4).setCellValue(pageNo);
						dataRow.createCell(5).setCellValue(pagePara.get(pageNo));
						dataRow.createCell(6).setCellValue(matchType);
					}
				}
				i++;
				j++;
			}
			if(thisResults.size()>0)
			{
				allResults.put(caseID, new HashSet<String>(thisResults));
				allResults1.put(caseID,  new HashSet<String>(thisResults1));
				allResults2.put(caseID,  new HashSet<String>(thisResults2));
			}
		}
		if(test)
		{
			if(fieldName.equals(FieldName.AE_VERBATIM))
			{
				updateScores(scoringFolderName, FieldName.AE_VERBATIM_Normalized, allResults1, cases);
				updateScores(scoringFolderName, FieldName.AE_LLT, allResults2, cases);
			}
			updateScores(scoringFolderName, fieldName, allResults, cases);
		}
		if(fieldName.equals(FieldName.AE_VERBATIM))
		{
			allCsvResults.put(FieldName.AE_VERBATIM_Normalized, allResults1);
			allCsvResults.put(FieldName.AE_LLT, allResults2);
		}
		allCsvResults.put(fieldName, allResults);
	}

	private static void updateScores(String scoresFileName, FieldName fieldName, Map<String, Set<String>> results,Set<String> cases)
	{
		String delimiter= ",";
		String sheetName=fieldName.toString();
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(scoresFileName+File.separator+sheetName+".csv");
			fileWriter.append("Case No"+delimiter+"Total Entities"+delimiter+"Total Entities Found"+delimiter+"Answer Values"+delimiter+"Result Values"+delimiter+"TP Count"+delimiter+"FP Count"+delimiter+"FN Count"+delimiter+"Additional TP Count\n");
			calculateScores(fieldName, fileWriter, results, cases, delimiter);
			System.out.println("Scores Excel written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	private static void calculateScores(FieldName fieldName, FileWriter fileWriter, 
			Map<String, Set<String>> allResults,Set<String> cases,String delimiter) throws IOException
	{
		int casesNotPresentinAnswerkey=0;
		int totalAdd=0;
		int totalTP=0;
		int totalFP=0;
		int totalFN=0;
		int complteEntities=0;
		int complteEntitiesFound=0;
		for(String caseNum : cases)
		{
			Set<Triplet<String, String, String>> answers= fieldName.equals(FieldName.AE_VERBATIM_Normalized) ? AnswerKeyLoader.getAnswerTriplet(FieldName.AE_VERBATIM, caseNum)
					: AnswerKeyLoader.getAnswerTriplet(fieldName, caseNum);
			Set<String> results=allResults.containsKey(caseNum) ? allResults.get(caseNum) : new HashSet<String>();
			int totalEntities = 0;
			int totalEntitiesFound=results.size();
			int TP=0;
			int FP=0;
			int FN=0;
			int addTP=0;
			String answereValues= answers.toString().replaceAll("\\[|\\]", "").replaceAll(", ", " AND ");
			String resultsValues= createValueString(results);
			Set<String> tpValues= new HashSet<String>();
			if(answers.size()>0)
			{
				for(Triplet<String, String, String> answer : answers)
				{
					List<String> values=new ArrayList<String>();
					if(!answer.getValue1().isEmpty())
					{
						String v1=answer.getValue1();
						if(fieldName.equals(FieldName.PAT_DOB_PARTIAL))
						{
							v1=MatchTypeCategorization.getLongDate1(v1);
						}
						else if(fieldName.equals(FieldName.GENDER))
						{
							if(v1.equalsIgnoreCase("M"))
								v1="Male";
							else if (v1.equalsIgnoreCase("F"))
								v1="Female";
						}
						values.add(v1);
					}
					if(!answer.getValue2().isEmpty())
						values.add(answer.getValue2());
					if(!answer.getValue3().isEmpty())
						values.add(answer.getValue3());

					boolean isPresent=true;
					if(answer.getValue1().toLowerCase().startsWith("no ") 
							|| answer.getValue2().toLowerCase().startsWith("no ")
							|| answer.getValue3().toLowerCase().startsWith("no ") || answer.getValue1().equalsIgnoreCase("-1"))
						isPresent=false;

					if(isPresent)
					{
						Set<String> thisTpValues= new HashSet<String>();
						String matchType="";
						for(String concept : results)
						{
							if(fieldName.equals(FieldName.GENDER))
							{
								if(concept.equalsIgnoreCase("M"))
									concept="Male";
								else if (concept.equalsIgnoreCase("F"))
									concept="Female";
							}
							for(int l=0 ; l<values.size() ; l++)
							{
								String goldValue=values.get(l);
								boolean checkPartial=fieldName.equals(FieldName.GENDER) || fieldName.equals(FieldName.PAT_DOB_PARTIAL) ? false : true;
								matchType= MatchTypeCategorization.checkMatchType(goldValue.trim(), concept.trim(), checkPartial);
								if(fieldName.equals(FieldName.PAT_AGE_UNIT))
								{
									if(matchType.equalsIgnoreCase("Exact Match") || matchType.equalsIgnoreCase("Partial Match"))
									{
										thisTpValues.add(concept);
										break;
									}
									if(concept.contains("-") && !goldValue.contains("-"))
									{
										List<Integer> pairs =ConceptCleanup.getAgePair(concept);
										int minValue =pairs.get(0);
										int maxValue =pairs.get(1);
										int average = ((minValue+maxValue)/2);
										concept=average+"";	
										matchType= MatchTypeCategorization.checkMatchType(goldValue.trim(), concept.trim(),false);
									}
									else
									{
										goldValue=ConceptCleanup.getAge(goldValue);
										matchType= MatchTypeCategorization.checkMatchType(goldValue.trim(), concept.trim(),false);
									}
								}
								if(matchType.equalsIgnoreCase("Exact Match") || matchType.equalsIgnoreCase("Partial Match"))
								{
									thisTpValues.add(concept);
									break;
								}
							}
						}
						if(thisTpValues.size()>0)
						{
							TP++;
							tpValues.addAll(thisTpValues);
						}
						totalEntities++;
					}
					else
					{
						/*totalEntitiesFound++;
						tpValues.addAll(results);
						TP++;*/
					}
				}
				if(totalEntities>0)
				{
					if(TP>0)
					{
						addTP=tpValues.size()-TP;
						if(addTP<=0)
							addTP=0;

					}
					FP=totalEntitiesFound-tpValues.size();
					FN=totalEntities-(TP+FP);
					if(FN<=0)
						FN=0;
					totalTP= totalTP+ TP;
					totalFP=totalFP +FP;
					totalFN= totalFN+FN;
					totalAdd=totalAdd+addTP;
				}
			}
			else
			{
				casesNotPresentinAnswerkey++;

			}
			complteEntities=complteEntities+totalEntities;
			complteEntitiesFound=complteEntitiesFound+totalEntitiesFound;
			fileWriter.append(caseNum+delimiter+totalEntities+delimiter+totalEntitiesFound+delimiter+answereValues+delimiter+resultsValues+delimiter+TP+delimiter+FP+delimiter+FN+delimiter+addTP+"\n");
			fileWriter.flush();
		}
		/*Double Precision=(new Double(totalTP)/new Double(totalTP+totalFP));
		Double Recall=(new Double(totalTP)/new Double(totalTP+totalFN));*/
		Double Precision=(new Double(totalTP+totalAdd)/new Double(complteEntitiesFound));
		Double Recall=(new Double(totalTP)/new Double(complteEntities));
		Double FScore=2*((Precision*Recall)/(Precision+Recall));
		System.out.println("Total Cases ::"+cases.size());
		System.out.println("Total Cases not present in Answer key ::"+casesNotPresentinAnswerkey);
		System.out.println("Precison ::"+Precision);
		System.out.println("Recall ::"+Recall);
		System.out.println("FScore ::"+FScore);
		fileWriter.append("Total Cases ::"+cases.size()+delimiter+complteEntities+delimiter+complteEntitiesFound+delimiter+"Precison ::"+Precision+delimiter+"Recall ::"+Recall+delimiter+totalTP+delimiter+totalFP+delimiter+totalFN+delimiter+totalAdd+"\n");
		fileWriter.append("FScore ::"+FScore+"\n");
		fileWriter.flush();
	}


	private static String createValueString(Set<String> values)
	{
		StringBuffer ret = new StringBuffer();
		for(String value : values)
		{
			value = value.replaceAll(",", "#").replaceAll("\\s+", " ");
			if(ret.toString().length()>0)
				ret.append(" AND ");
			ret.append(value);
		}
		return ret.toString().trim();
	}

}
