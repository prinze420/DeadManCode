package com.rage.nlp.core;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.rage.nlp.core.RuleLoader.Rule;
import edu.stanford.nlp.ling.HasWord;
import edu.stanford.nlp.ling.TaggedWord;
import edu.stanford.nlp.tagger.maxent.MaxentTagger;

/**
 * This MyTagger class used for customizing Maxent tagger output,by modifying
 * some pos tag based on rules ,given by rule loader .
 * 
 * 
 * @author rajendrasingh.rao
 * @version 1.2
 * @since 03-08-2016 1.2 added forcing pos tag for certain word
 * 
 */

public class MyTagger
{

	MaxentTagger			tagger;
	String					path					= "";
	RuleLoader				objRuleLoader			= new RuleLoader();
	PosTaggedTokenLoader	objPosTagTokenLoader	= new PosTaggedTokenLoader();
	public static boolean	shouldRuleApplied		= false;

	public MyTagger(String taggerPath) throws IOException
	{
		path = taggerPath;
		initTagger();
	}

	public void initTagger() throws IOException
	{
		//System.out.println("initalizing tagger, time start:"+ new Date().toString() + "\n\n");
		tagger = new MaxentTagger(path);
		//System.out.println("end initalizing tagger at :"+ new Date().toString() + "\n\n");

	}

	public List<Rule> getRuleLists()
	{
		//System.out.println("loading rules at :" + new Date().toString());
		List<Rule> ruleList = objRuleLoader.getRules();
		return ruleList;
	}

	public Map<String, String> getPosTaggedWords()
	{

		//System.out.println("loading already Tagged word from list");
		return objPosTagTokenLoader.getListPosTagToken();

	}

	public List<TaggedWord> doPostagging(String inputSentence,
			List<Rule> ruleList, Map<String, String> posTaggedWordMap)
	{
		if (tagger == null)
		{
			return null;
		}

		List<TaggedWord> tSentence = null;
		// Call MaxentTagger on text file
		try
		{

			boolean flag = false;
			String fileWriterStr = "";
			boolean isPreFixPosTag = false;
			String tempSentence = inputSentence.trim().replaceAll("( )+", " ");
			;
			for (Map.Entry<String, String> entry : posTaggedWordMap.entrySet())
			{
				tempSentence = tempSentence.replace(entry.getKey().trim(),
						entry.getKey().trim().replace(" ", "_"));
			}

			List<List<HasWord>> tokens = MaxentTagger
					.tokenizeText(new StringReader(tempSentence));

			// ====added code for forcing some pre
			List<String> tokensList = new ArrayList<String>();

			List<String> postTagList = new ArrayList<String>();

			// key=> token
			// val=>posTag
			// System.out.println(entry.getKey() + "/" + entry.getValue());
			// if
			// (tempSentence.toUpperCase().contains(entry.getKey().replace(" ",
			// "_").toUpperCase()))
			// {

			for (Iterator iterator = tokens.iterator(); iterator.hasNext();)
			{
				List<HasWord> list = (List<HasWord>) iterator.next();

				for (HasWord hasWord : list)
				{
					boolean isPosTagExistes = false;
					for (Map.Entry<String, String> entry : posTaggedWordMap
							.entrySet())
					{

						if (hasWord
								.word()
								.toUpperCase()
								.equals(entry.getKey().replace(" ", "_")
										.toUpperCase()))
						{
							isPreFixPosTag = true;
							isPosTagExistes = true;
							tokensList.add(entry.getKey());

							postTagList.add(entry.getValue());
							break;
						}

					}

					if (!isPosTagExistes)
					{
						tokensList.add(hasWord.word());
						postTagList.add(null);
					}

				}
				// System.out.println(list);

			}

			// }

			if (isPreFixPosTag)
			{
				tSentence = forceMaxentForSpecificTag(tokensList, postTagList);
			}
			else
			{

				String tagged = tagger.tagString(inputSentence);

				tSentence = PosTagger.getTaggedWords(tagged);
			}

			String wordSeq = "-";
			String posTagSeq = "-";

			for (TaggedWord tWord : tSentence)
			{
				wordSeq += tWord.word().replace("-", "*") + "-";
				posTagSeq += tWord.tag().replace("-", "*") + "-";
			}

			// now check all rule one by one if that applies,if applies
			// change pos tag sequence accordingly

			String prePosTagSeq = posTagSeq;
			int loopCount = 0;

			fileWriterStr += "Plain Sentence:\n\n";

			String taggedSentence = (tSentence.toString().replace(",,", "@@@"))
					.replace(", ", "-").replace("@@@", ",")
					.replaceAll("[|]", "");

			fileWriterStr += "pos Tagged Sentence:\n" + tSentence.toString()
					+ "\n\n";

			while (true)
			{
				loopCount++;
				boolean localflag = false;
				for (Rule rule : ruleList)
				{

					if ((rule.getWrongPosSeq().equals("JJ-NN")
							|| rule.getWrongPosSeq().equals("JJ-NNS")
							|| rule.getWrongPosSeq().equals("JJ-NNP") || rule
							.getWrongPosSeq().equals("JJ-NNPS"))
							&& (!shouldRuleApplied))
					{
						continue;
					}

					if (posTagSeq.contains("-" + rule.getWrongPosSeq() + "-"))
					{ // if
						// rule
						// exists
						// in
						// String[] splited=posTagSeq.split(rule[0].trim());
						// // pos
						// tag sequence

						// @ check if exception exists in following wrong
						// rule,if yes not replace it with write rule
						// else let it run as it is

						// now fetch out exception word from Rule data
						// structure

						Map<String, List<String>> exceptionList = rule
								.getExceptionList();

						Map<String, Boolean> shouldOccursList = rule
								.getShouldOccursList();

						boolean isExceptionExist = false;

						if (exceptionList != null && exceptionList.size() > 0)
						{

							List<String[]> pos_wordList = fetchRuleAttachedWords(
									rule.getWrongPosSeq(), taggedSentence);

							boolean ifAllExceptionWordNull = true;
							boolean ifAllShouldOccursFalse = true;

							if (shouldOccursList.toString().contains("true"))
								ifAllShouldOccursFalse = false;

							for (int pos_word_counter = 0; pos_word_counter < pos_wordList
									.size(); pos_word_counter++)
							{

								List<String> exceptionWords = exceptionList
										.get(pos_wordList.get(pos_word_counter)[0]);

								if (exceptionWords != null)
								{

									ifAllExceptionWordNull = false;

									boolean shouldOccur = shouldOccursList
											.get(pos_wordList
													.get(pos_word_counter)[0]);

									if (!shouldOccur)
									{// this is exception case
										// exception word
										// occurs we will not
										// apply rule
										if ((", "
												+ exceptionWords.toString()
														.replace("]", "")
														.replace("[", "") + ",")
												.contains(", "
														+ pos_wordList
																.get(pos_word_counter)[1]
														+ ","))
										{

											isExceptionExist = true;
											break;
										}
									}
									else
									{ // this is acceptence case we
										// should only go for change if
										// that word exists
										if (!(", "
												+ exceptionWords.toString()
														.replace("]", "")
														.replace("[", "") + ",")
												.contains(", "
														+ pos_wordList
																.get(pos_word_counter)[1]
														+ ","))
										{// if
											// acceptence
											// criteria
											// does not
											// match
											// then
											// don't
											// apply
											// rule

											isExceptionExist = true;
											break;
										}
									}

								}

							}

							if (!ifAllShouldOccursFalse)
							{

								if (ifAllExceptionWordNull)
								{
									isExceptionExist = true;
								}
							}
						}

						if (isExceptionExist)
						{
							break;
						}

						fileWriterStr += "\n\n" + "wrong pos tag seq:"
								+ rule.getWrongPosSeq()
								+ " ,          replaced pos tag seq: "
								+ rule.getApplicablePosSeq() + "\n";

						posTagSeq = posTagSeq.replaceAll(
								"-" + rule.getWrongPosSeq() + "-",
								"-" + rule.getApplicablePosSeq() + "-");

						flag = true;
						localflag = true;
					}

				}

				// add terminating condition
				if (!localflag)
				{
					break;
				}
				else
				{
					if (loopCount == 2)
					{
						fileWriterStr += "\n --looping for second time--";
					}

					if (loopCount >= 3)
					{
						fileWriterStr += " loop exists three time in pos tag sequence  ";
						break;
					}
				}
			}
			// now split both word list and postaglist and now pass it to
			// Forceified_MaxentTagger

			if (flag)
			{
				// remove extra "-" from biggening and last position
				wordSeq = wordSeq.substring(1, wordSeq.length() - 1);
				posTagSeq = posTagSeq.substring(1, posTagSeq.length() - 1);
				prePosTagSeq = prePosTagSeq.substring(1,
						prePosTagSeq.length() - 1);
				// System.out.println("word seq:" + wordSeq);
				// System.out.println("pre pos tag seq:" + prePosTagSeq);
				// System.out.println("postpos tag seq:" + posTagSeq);
				tSentence = forceMaxentForSpecificTag(wordSeq.split("-"),
						prePosTagSeq.split("-"), posTagSeq.split("-"));
				if (tSentence == null)
				{
					//System.out.println("Either sentence is empty or exception in \"forceMaxentForSpecificTag\" Method");
				}

				//System.out.println(fileWriterStr);
				//System.out.println("\n replaced sequence:"+ tSentence.toString() + "\n");
			}
		}
		catch (Exception e)
		{
			System.out.println("ERROR IN DOING CUSTOM POSTAGGING::"
					+ inputSentence);
			e.printStackTrace();
		}
		return tSentence;

	}

	public List<TaggedWord> doPostagging(String inputSentence,
			List<Rule> ruleList)
	{
		if (tagger == null)
		{
			return null;
		}

		List<TaggedWord> tSentence = null;
		// Call MaxentTagger on text file
		try
		{

			String fileWriterStr = "";
			String tagged = tagger.tagString(inputSentence);
			tSentence = PosTagger.getTaggedWords(tagged);
			String wordSeq = "-";
			String posTagSeq = "-";
			for (TaggedWord tWord : tSentence)
			{
				wordSeq += tWord.word().replace("-", "*") + "-";
				posTagSeq += tWord.tag().replace("-", "*") + "-";
			}

			// now check all rule one by one if that applies,if applies
			// change pos tag sequence accordingly

			String prePosTagSeq = posTagSeq;
			int loopCount = 0;
			boolean flag = false;
			fileWriterStr += "Plain Sentence:\n\n";
			String taggedSentence = (tSentence.toString().replace(",,", "@@@"))
					.replace(", ", "-").replace("@@@", ",")
					.replaceAll("[|]", "");
			fileWriterStr += "pos Tagged Sentence:\n" + tSentence.toString()
					+ "\n\n";

			while (true)
			{
				loopCount++;
				boolean localflag = false;
				for (Rule rule : ruleList)
				{
					if (posTagSeq.contains("-" + rule.getWrongPosSeq() + "-"))
					{ // if rule exists in
						// String[] splited=posTagSeq.split(rule[0].trim());
						// postag sequence
						// @ check if exception exists in following wrong
						// rule,if yes not replace it with write rule else let
						// it run as it is
						// now fetch out exception word from Rule data structure

						Map<String, List<String>> exceptionList = rule
								.getExceptionList();
						Map<String, Boolean> shouldOccursList = rule
								.getShouldOccursList();
						boolean isExceptionExist = false;

						if (exceptionList != null && exceptionList.size() > 0)
						{
							List<String[]> pos_wordList = fetchRuleAttachedWords(
									rule.getWrongPosSeq(), taggedSentence);
							boolean ifAllExceptionWordNull = true;
							boolean ifAllShouldOccursFalse = true;

							if (shouldOccursList.toString().contains("true"))
								ifAllShouldOccursFalse = false;

							for (int pos_word_counter = 0; pos_word_counter < pos_wordList
									.size(); pos_word_counter++)
							{
								List<String> exceptionWords = exceptionList
										.get(pos_wordList.get(pos_word_counter)[0]);
								if (exceptionWords != null)
								{
									ifAllExceptionWordNull = false;
									boolean shouldOccur = shouldOccursList
											.get(pos_wordList
													.get(pos_word_counter)[0]);

									if (!shouldOccur)
									{
										// this is exception case exception word
										// occurs we will not apply rule
										if ((", "
												+ exceptionWords.toString()
														.replace("]", "")
														.replace("[", "") + ",")
												.contains(", "
														+ pos_wordList
																.get(pos_word_counter)[1]
														+ ","))
										{
											isExceptionExist = true;
											break;
										}
									}
									else
									{ // this is acceptence case we should only
										// go for change if that word exists
										if (!(", "
												+ exceptionWords.toString()
														.replace("]", "")
														.replace("[", "") + ",")
												.contains(", "
														+ pos_wordList
																.get(pos_word_counter)[1]
														+ ","))
										{
											// if acceptence criteria does not
											// match then don't apply rule
											isExceptionExist = true;
											break;
										}
									}
								}
							}

							if (!ifAllShouldOccursFalse)
							{

								if (ifAllExceptionWordNull)
								{
									isExceptionExist = true;
								}
							}
						}

						if (isExceptionExist)
						{
							break;
						}

						fileWriterStr += "\n\n" + "wrong pos tag seq:"
								+ rule.getWrongPosSeq()
								+ " ,          replaced pos tag seq: "
								+ rule.getApplicablePosSeq() + "\n";

						posTagSeq = posTagSeq.replaceAll(
								"-" + rule.getWrongPosSeq() + "-",
								"-" + rule.getApplicablePosSeq() + "-");

						flag = true;
						localflag = true;
					}

				}

				// add terminating condition
				if (!localflag)
				{
					break;
				}
				else
				{
					if (loopCount == 2)
					{
						fileWriterStr += "\n --looping for second time--";
					}

					if (loopCount >= 3)
					{
						fileWriterStr += " loop exists three time in pos tag sequence  ";
						break;
					}
				}
			}
			// now split both word list and postaglist and now pass it to
			// Forceified_MaxentTagger

			if (flag)
			{
				// remove extra "-" from biggening and last position
				wordSeq = wordSeq.substring(1, wordSeq.length() - 1);
				posTagSeq = posTagSeq.substring(1, posTagSeq.length() - 1);
				prePosTagSeq = prePosTagSeq.substring(1,
						prePosTagSeq.length() - 1);
				// System.out.println("word seq:" + wordSeq);
				// System.out.println("pre pos tag seq:" + prePosTagSeq);
				// System.out.println("postpos tag seq:" + posTagSeq);
				tSentence = forceMaxentForSpecificTag(wordSeq.split("-"),
						prePosTagSeq.split("-"), posTagSeq.split("-"));
				if (tSentence == null)
				{
					//System.out.println("Either sentence is empty or exception in \"forceMaxentForSpecificTag\" Method");
				}

				//System.out.println(fileWriterStr);
				//System.out.println("\n replaced sequence:"+ tSentence.toString() + "\n");
			}
		}
		catch (Exception e)
		{
			System.out.println("ERROR IN DOING CUSTOM POSTAGGING::"	+ inputSentence);
			e.printStackTrace();
		}
		return tSentence;

	}

	// method for forcifying specific tag
	public List<TaggedWord> forceMaxentForSpecificTag(String[] words,
			String[] preTagSeq, String[] postPosTagSeq)
	{
		// size of each string array will be same
		Boolean reuseTags = true;
		List<TaggedWord> tagSentence = new ArrayList<TaggedWord>();
		List<TaggedWord> tSentence = null;
		try
		{
			for (int i = 0; i < preTagSeq.length; i++)
			{

				if (preTagSeq[i].equals(postPosTagSeq[i]))
					tagSentence.add(new TaggedWord(words[i].replace("/", "-")
							.replace("*", "-"), null));

				else
					tagSentence.add(new TaggedWord(words[i].replace("/", "-"),
							postPosTagSeq[i]));

			}

			tSentence = tagger.tagSentence(tagSentence, reuseTags);
			/*for (TaggedWord tWord : tSentence)
				System.out.println(tWord.toString());*/
		}
		catch (Exception e)
		{
			System.out.println("");
		}
		return tSentence;
	}

	// method for forcifying specific tag
	public List<TaggedWord> forceMaxentForSpecificTag(List<String> words,
			List<String> postPosTagSeq)
	{
		// size of each string array will be same
		Boolean reuseTags = true;
		List<TaggedWord> tagSentence = new ArrayList<TaggedWord>();
		List<TaggedWord> tSentence = null;
		try
		{
			for (int i = 0; i < postPosTagSeq.size(); i++)
			{

				if (postPosTagSeq.get(i) == null)
					tagSentence.add(new TaggedWord(words.get(i)
							.replace("/", "-").replace("*", "-"), null));

				else
					tagSentence.add(new TaggedWord(words.get(i).replace("/",
							"-"), postPosTagSeq.get(i)));

			}

			tSentence = tagger.tagSentence(tagSentence, reuseTags);
			/*for (TaggedWord tWord : tSentence)
				System.out.println(tWord.toString());*/
		}
		catch (Exception e)
		{
			// TODO Auto-generated catch block
			System.out.println("");
		}
		return tSentence;
	}

	public List<String[]> fetchRuleAttachedWords(String rule, String sentence)
	{

		// pattern creater

		// pattern creater

		String pattern = "";
		String[] splitedRule = rule.split("-");

		// make pattern to find out tri gram token with Pos tag
		if (rule.split("-").length > 2)
		{

			pattern = "[' a-z A-Z]+(?=/" + splitedRule[0] + ")|"
					+ splitedRule[0] + "-[' a-z A-Z]+(?=/" + splitedRule[1]
					+ ")|" + splitedRule[1] + "-[' a-z A-Z]+(?=/"
					+ splitedRule[2] + ")";

		}
		else
		{// for bigram

			pattern = "[' a-z A-Z]+(?=/" + splitedRule[0] + ")|"
					+ splitedRule[0] + "-[' a-z A-Z]+(?=/" + splitedRule[1]
					+ ")";
		}

		// Create a Pattern object
		Pattern r = Pattern.compile(pattern);

		// Now create matcher object.
		Matcher m = r.matcher(sentence);

		// prepare list of pos and word
		List<String[]> pos_wordList = new ArrayList<String[]>();

		String[] pos_wordItem = new String[2];

		boolean isItemFound = false;

		int loopCounter = 0;
		// try {
		boolean ispos_wordExists = false;
		// iterate each match
		while (m.find())
		{

			if (loopCounter == 0)
			{
				pos_wordItem[1] = sentence.substring(m.start(), m.end());

			}
			else
			{
				if (sentence.substring(m.start(), m.end()).contains("-"))
				{
					pos_wordItem[0] = sentence.substring(m.start(), m.end())
							.split("-")[0];
					pos_wordList.add(pos_wordItem);
					pos_wordItem = new String[2];
					pos_wordItem[1] = sentence.substring(m.start(), m.end())
							.split("-")[1];
					ispos_wordExists = true;
				}
				else
				{
					if (!ispos_wordExists)
						pos_wordItem[1] = sentence
								.substring(m.start(), m.end());
				}

			}
			// pos_wordList.add(pos_wordItem);

			// System.out.println(sentence.substring(m.start(), m.end()));
			// pos_wordItem= new String[2];
			// if(loopCounter!=0){
			// pos_wordItem[0]=line.substring(m.start(), m.end()).split("-")[1];
			loopCounter++;
			// }

		}
		// } //catch (Exception e) {
		// TODO Auto-generated catch block
		// System.err.println("**&");
		// }

		pos_wordItem[0] = splitedRule[splitedRule.length - 1];
		pos_wordList.add(pos_wordItem);

		return pos_wordList;
	}

}
