package com.rage.nlp.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.LinkedHashMap;
import java.util.Map;

public class PosTaggedTokenLoader
{

	String				path			= "resource/stanford-parser/PosTagToken.txt";
	Map<String, String>	listPosTagToken	= new LinkedHashMap<String, String>();

	
	public PosTaggedTokenLoader(){
		loadPosTagToken();
	}
	public void loadPosTagToken()
	{
		try
		{

			File f = new File(path);
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = br.readLine();
			while (line != null)
			{
				if (line.length() == 0)
				{
					line = br.readLine();
					continue;
				}
				String[] splitPart = null;
				if ((splitPart = line.split("\t")).length > 1)
				{

					listPosTagToken.put(splitPart[0], splitPart[1]);
				}
				else if(splitPart.length ==1){
					listPosTagToken.put(splitPart[0], "");
				}
				line = br.readLine();
			}

		}
		catch (Exception e)
		{
		}
	}

	public static void main(String[] args)
	{

		PosTaggedTokenLoader loader=new PosTaggedTokenLoader();
		loader.loadPosTagToken();
		
	}
	public Map<String, String> getListPosTagToken()
	{
		return listPosTagToken;
	}
	public void setListPosTagToken(Map<String, String> listPosTagToken)
	{
		this.listPosTagToken = listPosTagToken;
	}

}
