package com.rage.nlp.core;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Vector;
import org.apache.commons.lang.WordUtils;

public class StopWords 
{
	private static String PROPERTY_STOP_WORDS_FILE = "stop.words.file" ;
	private static HashSet<String> stopwords ;

	public static HashSet<String> getStopWords()
	{
		if ( stopwords == null )
		{
			String fileName = Configuration.getProperty(PROPERTY_STOP_WORDS_FILE) ;
			stopwords = loadStopWordsFromFile(fileName) ;
		}

		return stopwords ;
	}

	private static HashSet<String> loadStopWordsFromFile(String fileName) 
	{
		HashSet<String> stopwords = new HashSet<String>() ;

		try
		{
			BufferedReader br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(fileName)))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				line = line.trim() ;
				if ( line.equals("") )
					continue ;

				line = line.toLowerCase() ;
				stopwords.add(line) ;
			}

			br.close() ;
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN LOADING STOP WORDS FROM FILE : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return stopwords ;
	}
	
	public static boolean isStopWord(String token)
	{
		if ( !token.toLowerCase().contains("no") && getStopWords().contains(token.toLowerCase()) )
			return true ;

		return false ;
	}

	/*public static boolean isStopWord(String token)
	{
		if ( getStopWords().contains(token.toLowerCase()) )
			return true ;

		return false ;
	}*/

	public static String removeStopWords(String value){

		Vector<String> tokens =  new Vector<String>(Arrays.asList(value.split(" ")));
		Vector<String> newTokens = new Vector<String>();
		for(String token : tokens){
			if(!StopWords.isStopWord(token.toLowerCase())){
				newTokens.add(token);
			}
		}
		return join(newTokens, " ");
	}

	public static String join(Vector<String> list, String conjunction)
	{
		StringBuilder sb = new StringBuilder();
		boolean first = true;
		for (String item : list)
		{
			if (first)
				first = false;
			else
				sb.append(conjunction);
			sb.append(WordUtils.capitalize(item));
		}
		return sb.toString();
	}


}
