package com.rage.nlp.core;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import com.rage.nlp.PVAI.FeatureExtractor;
import opennlp.tools.chunker.ChunkerME;
import opennlp.tools.chunker.ChunkerModel;

public class Chunker 
{
	public static Boolean DEBUG = Boolean.FALSE ;
	public static Boolean CHUNKER_DEBUG = Boolean.FALSE ;
	
	private static ChunkerModel chunkerModel ;
	private static ChunkerME chunker ;

	public static ChunkerModel getChunkerModel()
	{
		if ( chunkerModel == null )
		{
			try
			{
				String fileName = Configuration.getProperty("opennlp.chunker.modelfile") ;
				chunkerModel = new ChunkerModel(new FileInputStream(fileName)) ;
			}
			catch (Exception e) 
			{
				System.err.println("ERROR IN LOADING THE CHUNKER MODEL : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		return chunkerModel ;
	}

	public synchronized static ChunkerME getChunker()
	{
		if ( chunker == null )
			chunker = new ChunkerME(getChunkerModel()) ;

		return chunker ;
	}
	
	public synchronized static Vector<NLChunk> doShallowParsing(Vector<String> tokens, Vector<String> postags, Vector<NLWord> words)
	{
		Vector<NLChunk> chunks = doBasicParsing(tokens, postags, words);
		
		chunks = validateChunks(chunks) ;
		
		return chunks ;
	}

	private static Vector<NLChunk> validateChunks(Vector<NLChunk> chunks)
	{
		for ( NLChunk chunk : chunks )
		{
			NLWord lastWord = chunk.getTokens().get(chunk.getTokens().size()-1) ;
			if ( lastWord.getPostag().startsWith("NN") && chunk.getType().equalsIgnoreCase("VP") )
			{
				chunk.setType("NP") ;
				continue ;
			}
			
			if ( lastWord.getPostag().startsWith("VB") && chunk.getType().equalsIgnoreCase("NP") )
			{
				chunk.setType("VP") ;
				continue ;
			}
		}
		
		return chunks;
	}

	private static Vector<NLChunk> doBasicParsing(Vector<String> tokens, Vector<String> postags, Vector<NLWord> words)
	{
		Vector<NLChunk> chunks = new Vector<NLChunk>() ;

		String[] tokens_arr = tokens.toArray(new String[1]) ;
		String[] postags_arr = postags.toArray(new String[1]) ;
		String[] chunking_output_arr = getChunker().chunk(tokens_arr, postags_arr) ;
		
		if ( CHUNKER_DEBUG )
		{
			System.out.println("TOKENS : " + Arrays.asList(tokens_arr)) ;
			System.out.println("POSTAGS : " + Arrays.asList(postags_arr)) ;
			System.out.println("CHUNKING OUTPUT : " + Arrays.asList(chunking_output_arr)) ;	
		}

		NLChunk thisNLChunk = null ;
		for ( int i=0 ; i<chunking_output_arr.length ; i++ )
		{
			String token = tokens_arr[i] ;
			String postag = postags_arr[i] ;
			String lemma = words.get(i).getLemma();
			String chunkOutput = chunking_output_arr[i] ;
			String label = chunkOutput.contains("-") ? chunkOutput.substring(0, chunkOutput.indexOf("-")) : chunkOutput ;
			String chunkType = chunkOutput.contains("-") ? chunkOutput.substring(chunkOutput.lastIndexOf("-")+1, chunkOutput.length()) : "" ;

			if ( DEBUG )
			{
				System.out.println("\n\n") ;
				System.out.println("\tINDEX : " + i) ;
				System.out.println("\t\tTOKEN : " + token) ;
				System.out.println("\t\tCHUNK OUTPUT : " + chunkOutput) ;
				System.out.println("\t\tLABEL : " + label) ;
				System.out.println("\t\tCHUNK TYPE : " + chunkType) ;
			}
			
			// validateChunkType
			// chunkType = postag.startsWith("NN") ? "NP" : (postag.startsWith("VB") ? "VP" : chunkType) ;
			
			// if ( thisNLChunk.getStartIndex() == thisNLChunk.getEndIndex() && thisNLChunk.getStartIndex() == -1 )
			if ( thisNLChunk == null )
			{
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tAPPLYING RULE .... ENTRY CASE") ;
				}
				
				thisNLChunk = new NLChunk(chunks.size()) ;
				thisNLChunk.setStartIndex(i) ;
				thisNLChunk.setEndIndex(i) ;
				thisNLChunk.setType(chunkType) ;
				thisNLChunk.setChunk(token) ;
				thisNLChunk.setLemmatizedChunk(lemma);
				thisNLChunk.setIndex(chunks.size()) ;
				thisNLChunk.setTokens(new Vector<NLWord>(words.subList(i, i+1))) ;
				
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
					System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
				}

				continue ;
			}

			if ( label.equals("B") )
			{	
				/*if ( thisNLChunk.getTokens().lastElement().getPostag().equalsIgnoreCase("CC") )
				{
					if ( DEBUG )
					{
						System.out.println("\n") ;
						System.out.println("\t\t\tAPPLYING CC-RULE .... B-Label") ;
					}
					
					thisNLChunk.setEndIndex(i) ;
					thisNLChunk.setChunk(thisNLChunk.getChunk() + " " + token) ;
					thisNLChunk.getTokens().add(words.elementAt(i)) ;

					if ( DEBUG )
					{
						System.out.println("\n") ;
						System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
						System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
					}

					continue ;
				}*/
				
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tAPPLYING RULE .... B-Label") ;
				}
				
				NLChunk newChunk = new NLChunk(-1, -1) ;
				newChunk.setStartIndex(thisNLChunk.getStartIndex()) ;
				newChunk.setEndIndex(thisNLChunk.getEndIndex()) ;
				newChunk.setType(thisNLChunk.getType()) ;
				newChunk.setChunk(thisNLChunk.getChunk()) ;
				newChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()) ;
				newChunk.setIndex(thisNLChunk.getIndex()) ;
				newChunk.setTokens(new Vector<NLWord>(thisNLChunk.getTokens())) ;

				chunks.add(newChunk) ;

				thisNLChunk = new NLChunk(chunks.size(), i) ;
				thisNLChunk.setEndIndex(i) ;
				thisNLChunk.setType(chunkType) ;
				thisNLChunk.setChunk(token) ;
				thisNLChunk.setLemmatizedChunk(lemma) ;
				thisNLChunk.setTokens(new Vector<NLWord>(words.subList(i, i+1))) ;

				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
					System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
				}

				continue ;
			}
			else if ( label.equals("I") )
			{
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tAPPLYING RULE .... I-Label") ;
				}
				
				thisNLChunk.setEndIndex(i) ;
				thisNLChunk.setChunk(thisNLChunk.getChunk() + " " + token) ;
				thisNLChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()+ " "+lemma) ;
				thisNLChunk.getTokens().add(words.elementAt(i)) ;

				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
					System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
				}

				continue ;
			}
			else if ( label.equals("O") )
			{
				thisNLChunk.setEndIndex(i) ;
				// thisNLChunk.setChunk(thisNLChunk.getChunk() + " " + token) ;
				thisNLChunk.getTokens().add(words.elementAt(i)) ;
				
				String type = postag.equalsIgnoreCase("CC") ? (thisNLChunk != null ? (thisNLChunk.getType().equalsIgnoreCase("NP") || thisNLChunk.getType().equalsIgnoreCase("VP") ? thisNLChunk.getType() : "") : "") : "" ;
				/*if ( postag.equalsIgnoreCase("CC") && (type.equalsIgnoreCase("NP") || type.equalsIgnoreCase("VP")) )
				{
					if ( DEBUG )
					{
						System.out.println("\n") ;
						System.out.println("\t\t\tAPPLYING CC-NP-VP RULE .... O-Label") ;
					}
					
					thisNLChunk.setEndIndex(i) ;
					thisNLChunk.setChunk(thisNLChunk.getChunk() + " " + token) ;
					thisNLChunk.getTokens().add(words.elementAt(i)) ;

					if ( DEBUG )
					{
						System.out.println("\n") ;
						System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
						System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
					}

					continue ;
				}*/
				
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tAPPLYING RULE .... O-Label") ;
				}
				
				NLChunk newChunk = new NLChunk(-1, -1) ;
				newChunk.setStartIndex(thisNLChunk.getStartIndex()) ;
				newChunk.setEndIndex(thisNLChunk.getEndIndex()) ;
				newChunk.setType(thisNLChunk.getType()) ;
				newChunk.setChunk(thisNLChunk.getChunk()) ;
				newChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()) ;
				newChunk.setIndex(thisNLChunk.getIndex()) ;
				newChunk.setTokens(new Vector<NLWord>(thisNLChunk.getTokens())) ;
				
				chunks.add(newChunk) ;
				
				thisNLChunk = new NLChunk(chunks.size(), i) ;
				thisNLChunk.setEndIndex(i) ;
				thisNLChunk.setType(chunkType) ;
				thisNLChunk.setLemmatizedChunk(lemma) ;
				thisNLChunk.setChunk(token) ;
				thisNLChunk.setTokens(new Vector<NLWord>(words.subList(i, i+1))) ;
				
				
				newChunk = new NLChunk(-1, -1) ;
				newChunk.setStartIndex(thisNLChunk.getStartIndex()) ;
				newChunk.setEndIndex(thisNLChunk.getEndIndex()) ;
				newChunk.setType(type) ;
				newChunk.setChunk(thisNLChunk.getChunk()) ;
				newChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()) ;
				newChunk.setIndex(thisNLChunk.getIndex()) ;
				newChunk.setTokens(new Vector<NLWord>(thisNLChunk.getTokens())) ;

				chunks.add(newChunk) ;
				
				thisNLChunk = null ;
				
				if ( DEBUG )
				{
					System.out.println("\n") ;
					System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
					System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
				}

				continue ;
			}

			if ( DEBUG )
			{
				System.out.println("\n") ;
				System.out.println("\t\t\tAPPLYING RULE .... DEFAULT") ;
			}

			thisNLChunk.setEndIndex(i) ;
			thisNLChunk.setChunk(thisNLChunk.getChunk() + " " + token) ;
			thisNLChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()+" "+lemma) ;
			thisNLChunk.getTokens().add(words.elementAt(i)) ;

			if ( DEBUG )
			{
				System.out.println("\n") ;
				System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
				System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
			}

			continue ;
		}

		if ( DEBUG )
		{
			System.out.println("\n") ;
			System.out.println("\t\t\tAPPLYING RULE .... BOUNDARY CONDITION") ;
		}

		if ( thisNLChunk != null  )
		{
			NLChunk newChunk = new NLChunk(-1, -1) ;
			newChunk.setStartIndex(thisNLChunk.getStartIndex()) ;
			newChunk.setEndIndex(thisNLChunk.getEndIndex()) ;
			newChunk.setType(thisNLChunk.getType()) ;
			newChunk.setChunk(thisNLChunk.getChunk()) ;
			newChunk.setLemmatizedChunk(thisNLChunk.getLemmatizedChunk()) ;
			newChunk.setIndex(thisNLChunk.getIndex()) ;
			newChunk.setTokens(new Vector<NLWord>(thisNLChunk.getTokens())) ;

			chunks.add(newChunk) ;
		}

		if ( DEBUG )
		{
			System.out.println("\n") ;
			System.out.println("\t\t\tTHIS NL CHUNK : " + thisNLChunk) ;
			System.out.println("\t\t\tALL CHUNKS : " + chunks) ;
		}
		return chunks;
	}

	public static Vector<String> doMorphologicalAnalysis(Vector<String> postags, Vector<String> tokens) 
	{
		Vector<String> lemmas = new Vector<String>() ;

		try
		{
			lemmas = MorphologicalAnalyzer.analyze(tokens, postags) ;
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING MORPHOLOGICAL ANALYSIS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}

		return lemmas ;
	}
	
	public static void main(String[] args)
	{
		String str="Trulicity 0.75mg, weekly";
		FeatureExtractor.DEBUG=true;
		List<NLChunk> chunks= FeatureExtractor.doShallowParsing(str);
		String ret="";
		for(NLWord word : chunks.get(0).getTokens())
		{
			if(word.getPostag().equals("NNP"))
			{
				ret= ret.trim()+" "+word.getToken();
			}

		}
		System.out.println(ret);
	}

	
}
