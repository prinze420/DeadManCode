package com.rage.nlp.core;

import java.util.ResourceBundle;

public class Configuration 
{
	private static String resourceName = "config" ;
	private static ResourceBundle resource ;
	
	public static String getProperty(String name)
	{
		String value = null ;
		
		try
		{
			value = getResourceBundle().getString(name) ;
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN GETTING THE VALUE OF THE RESOURCE  : " + e.getMessage()) ;
		}
		
		return value ;
	}
	
	public static ResourceBundle getResourceBundle()
	{
		if ( resource == null )
		{
			resource = ResourceBundle.getBundle(getResourceName()) ;
		}
		
		return resource ;
	}
	
	public static String getResourceName()
	{
		return resourceName ;
	}
}
