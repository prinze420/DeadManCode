package com.rage.nlp.core;

import java.util.Vector;


public class Decapitalizer 
{
	public static String decapitalize(String sentence)
	{
		String ret = "" ;

		Vector<String> tokens = Tokenizer.tokenize(sentence) ;

		boolean isCapitalized = true ;

		for ( int i=0 ; i<tokens.size() ; i++ )
		{
			String token = tokens.elementAt(i) ;
			if ( StopWords.isStopWord(token) )
				continue ;

			if ( Character.isLowerCase(token.charAt(0)) )
			{
				isCapitalized = false ;
				break ;
			}
		}

		if ( isCapitalized )
		{
			for ( int i=0 ; i<tokens.size() ; i++ )
				ret = ret.trim() + " " + (i==0 ? tokens.elementAt(i) : tokens.elementAt(i).toLowerCase()) ;

			return ret ;
		}
		else
		{
			return sentence ;
		}
	}
	
	
	public static void main(String[] args) {
		
		String sentence = "Microsoft : Researchers Submit Patent Application, \"History as a Branching Visualization\", for Approval .";
		System.out.println(decapitalize(sentence));
		
		
	}
}
