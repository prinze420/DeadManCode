package com.rage.nlp.core;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Class read Rule.txt file and separate LHS and RHS part, save rule to List
 * data structure
 * 
 * @author rajendrasingh.rao
 * @version 1.1
 * @since 03-08-2016
 */

public class RuleLoader {

	// inner class for rule

	public class Rule {
		String WrongPosSeq;
		String applicablePosSeq;
		Map<String, List<String>> exceptionList = new LinkedHashMap<String, List<String>>();

		Map<String, Boolean> shouldOccursList = new LinkedHashMap<String, Boolean>();

		public Rule(String wrongPosSeq, String applicablePosSeq,
				Map<String, List<String>> exceptionList) {
			super();
			WrongPosSeq = wrongPosSeq;
			this.applicablePosSeq = applicablePosSeq;
			this.exceptionList = exceptionList;
		}

		public Map<String, Boolean> getShouldOccursList() {
			return shouldOccursList;
		}

		public void setShouldOccursList(Map<String, Boolean> shouldOccursList) {
			this.shouldOccursList = shouldOccursList;
		}

		public Rule() {
			super();
			// TODO Auto-generated constructor stub
		}

		public String getWrongPosSeq() {
			return WrongPosSeq;
		}

		public void setWrongPosSeq(String wrongPosSeq) {
			WrongPosSeq = wrongPosSeq;
		}

		public String getApplicablePosSeq() {
			return applicablePosSeq;
		}

		public void setApplicablePosSeq(String applicablePosSeq) {
			this.applicablePosSeq = applicablePosSeq;
		}

		public Map<String, List<String>> getExceptionList() {
			return exceptionList;
		}

		public void setExceptionList(Map<String, List<String>> exceptionList) {
			this.exceptionList = exceptionList;
		}

	}

	private List<Rule> rules;
	private static String PROPERTY_TAGGER_RULES = "nlp.custom.tagger.rules" ;
	
	public RuleLoader() {

		rules = new ArrayList<Rule>();
		loadRule();
	}

	// read rule from given path
	public void loadRule() {

		File f = new File(Configuration.getProperty(PROPERTY_TAGGER_RULES));
		try {
			BufferedReader br = new BufferedReader(new FileReader(f));
			String line = br.readLine();

			List<Rule> rules = new ArrayList<RuleLoader.Rule>();
			while (line != null) {
				if (line.length() == 0) {
					line = br.readLine();
					continue;
				}

				// first seprate rule and exception part by space

				Rule r = new Rule();
				Map<String, Boolean> shouldOccursList = new LinkedHashMap<String, Boolean>();

				if (line.trim().split("\t").length > 1) {
					String[] tempArr = line.trim().split("\t")[1].trim().split(
							":");

					Map<String, List<String>> li = new LinkedHashMap<String, List<String>>();
					for (int i = 0; i < tempArr.length; i++) {

						List<String> lst = new ArrayList<String>();
						String[] arrStr = tempArr[i].split("-")[1].split(",");
						for (int j = 0; j < arrStr.length; j++) {
							lst.add(arrStr[j]);

						}

						li.put(tempArr[i].split("-")[0].split("_")[0], lst);

						if (tempArr[i].split("-")[0].split("_")[1].equals("1"))
							shouldOccursList.put(
									tempArr[i].split("-")[0].split("_")[0],
									true);
						else {
							shouldOccursList.put(
									tempArr[i].split("-")[0].split("_")[0],
									false);
						}
						// tempArr[i].split("-")[0]

					}
					r.setExceptionList(li);
				}

				String[] sepPart = line.trim().split("\t")[0].split("=>");

				try
				{
					r.setWrongPosSeq(sepPart[0]);
					r.setApplicablePosSeq(sepPart[1]);
					r.setShouldOccursList(shouldOccursList);
				
				}
				catch (Exception e)
				{	System.out.println("RULE IS INCOMPLETE!\t"+line);
					line = br.readLine();
					continue;
					// TODO: handle exception
				}
				

				rules.add(r);
				line = br.readLine();
			}
			setRules(rules);

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public RuleLoader(List<Rule> rules) {
		super();
		this.rules = rules;
	}

	public List<Rule> getRules() {
		return rules;
	}

	public void setRules(List<Rule> rules) {
		this.rules = rules;
	}

	public static void main(String[] args) 
	{
		RuleLoader objRuleLoader = new RuleLoader();
		objRuleLoader.loadRule();
	}

}
