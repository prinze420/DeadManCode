package com.rage.nlp.core;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import com.rage.nlp.core.RuleLoader.Rule;
import edu.stanford.nlp.ling.TaggedWord;

public class PosTagger 
{
	
	private static MyTagger						customTagger;
	private static String						PROPERTY_STANFORD_POS_MODEL				= "nlp.stanford.pos.model";


	public static MyTagger getCutomPOSTagger()
	{

		if (customTagger == null)
		{
			try
			{
				customTagger = new MyTagger(Configuration.getProperty(PROPERTY_STANFORD_POS_MODEL));
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		return customTagger;
	}

	public static List<TaggedWord> getCustomTaggedWords(String sentence)
	{
		sentence = sentence.replaceAll("[^\\x20-\\x7e]", " ").replaceAll("\\s{1,}", " ").trim();
		MyTagger tagger = getCutomPOSTagger();
		List<Rule> ruleList = tagger.getRuleLists();
		// Map<String,String> posTaggedTokens= tagger.getPosTaggedWords();
		List<TaggedWord> taggedWords = tagger.doPostagging(sentence, ruleList);
		return taggedWords;
	}
	
	public static List<TaggedWord> getTaggedWords(String tagged)
	{
		List<String> taggedTokens = Arrays.asList(tagged.split(" "));
		List<TaggedWord> taggedWords = new ArrayList<TaggedWord>();
		for (String taggedToken : taggedTokens)
		{
			String tags[] = taggedToken.split("_");
			if (tags.length < 2)
				continue;

			else if (tags.length == 2)
			{
				TaggedWord taggedWord = new TaggedWord(tags[0], tags[1]);
				taggedWords.add(taggedWord);
			}
			else if (tags.length > 2)
			{
				TaggedWord taggedWord = new TaggedWord(taggedToken.substring(0,
						taggedToken.lastIndexOf("_")),
						taggedToken.substring(taggedToken.lastIndexOf("_") + 1));
				taggedWords.add(taggedWord);
			}
		}
		return taggedWords;
	}

}
