package com.rage.nlp.core;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Vector;
import com.rage.nlp.PVAI.ConceptCleanup;
import net.didion.jwnl.JWNL;
import net.didion.jwnl.JWNLException;
import net.didion.jwnl.data.IndexWord;
import net.didion.jwnl.data.POS;
import net.didion.jwnl.data.Synset;
import net.didion.jwnl.data.Word;
import net.didion.jwnl.dictionary.Dictionary;
import net.didion.jwnl.dictionary.MorphologicalProcessor;


public class MorphologicalAnalyzer 
{
	public static HashSet<String> GARBAGE_SET = new HashSet<String>(
			Arrays.asList("~ ` ! @ # $ % ^ & * ( ) _ - + = { } [ ] | \\ : ; \" ' < > , . / ?".split(" "))) ;
	private static Dictionary dictionary ;
	private static MorphologicalProcessor morphological_processor ;

	public static Dictionary getDictionary()
	{
		if ( dictionary == null )
		{
			try
			{
				String fileName = null ;
				try
				{
					fileName = Configuration.getProperty("jwnl.config.file.location") ;
				}
				catch (Exception e)
				{
					fileName = "resource/wordnet.xml" ;
				}
				
				if ( fileName == null )
					fileName = "resource/wordnet.xml" ;
				
				System.err.println("Loading wordnet ....") ; 
				JWNL.initialize(new FileInputStream(fileName)) ;
				dictionary = Dictionary.getInstance() ;
			}
			catch (Exception e) 
			{
				System.err.println("ERROR IN LOADING THE WORDNET : " + e.getMessage()) ;
				e.printStackTrace() ;
				dictionary = null ;
			}
		}

		return dictionary ;
	}

	public static MorphologicalProcessor getMorphologicalProcessor()
	{
		if ( morphological_processor == null )
		{
			try
			{
				morphological_processor = getDictionary().getMorphologicalProcessor() ;
			}
			catch (Exception e) 
			{
				System.err.println("ERROR IN GETTING THE MORPHOLOGICAL ANALYZER : " + e.getMessage()) ;
				e.printStackTrace() ;
				morphological_processor = null ;
			}
		}

		return morphological_processor ;
	}

	public static POS getPOS(String tag)
	{
		POS ret = POS.ADJECTIVE ;

		tag = tag.toUpperCase().trim() ;
		if ( tag.startsWith("RB") )
		{
			ret = POS.ADVERB ;
		}
		else if ( tag.startsWith("JJ") )
		{
			ret = POS.ADJECTIVE ;
		}
		else if ( tag.startsWith("VB") )
		{
			ret = POS.VERB ;
		}
		else if ( tag.startsWith("NN") )
		{
			ret = POS.NOUN ;
		}
		else 
		{
			ret = null ;
		}

		return ret ;
	}

	@SuppressWarnings("unchecked")
	public synchronized static Vector<String> getRawLemmas(String word, String tag)
	{
		POS pos = getPOS(tag.toUpperCase()) ;
		if ( pos == null )
			return new Vector<String>() ;
		
		if ( !isWordAppropriate(word) )
			return new Vector<String>() ;
		
		Vector<String> lemmas = new Vector<String>() ;
		try 
		{
			lemmas = new Vector<String>((List<String>)getMorphologicalProcessor().lookupAllBaseForms(pos, word)) ;
		}
		catch (JWNLException e) 
		{
			System.err.println("EXCEPTION IN FINDING LEMMAS : " + e.getMessage()) ;
			e.printStackTrace() ;
			lemmas = new Vector<String>() ;
		}
		
		return lemmas ;
	}
	
	@SuppressWarnings("unchecked")
	public synchronized static String getLemma(String word, String tag)
	{
		if ( word.trim().equalsIgnoreCase("") )
			return "" ;
		
		if(tag.equalsIgnoreCase("NNP"))
		{
			return word;
		}
		
		POS pos = getPOS(tag.toUpperCase()) ;
		if ( pos == null )
			return word ;
		
		if ( !isWordAppropriate(word) )
			return word ;
		
		Vector<String> lemmas ;
		try 
		{
			lemmas = new Vector<String>((List<String>)getMorphologicalProcessor().lookupAllBaseForms(pos, word.toLowerCase())) ;
		}
		catch (JWNLException e) 
		{
			System.err.println("EXCEPTION IN FINDING LEMMAS : " + e.getMessage()) ;
			e.printStackTrace() ;
			lemmas = new Vector<String>() ;
		}

		if ( lemmas.size() != 0 )
			return lemmas.elementAt(0).toString() ;
		else
			return word ;
	}

	public static boolean isWordAppropriate(String word) 
	{	
		for ( String garbage : GARBAGE_SET)
			if ( word.contains(garbage) )
				return false ;
		
		if ( word.contains(" ") )
			return false ;
		
		return true ;
	}

	public static Vector<String> analyze(Vector<String> tokens, Vector<String> tags)
	{
		Vector<String> lemmas = new Vector<String>() ;

		for ( int i=0 ; i<tokens.size() ; i++ )
		{
			String word = tokens.elementAt(i) ;
			String tag = tags.elementAt(i) ;
			if ( word.contains("_") || word.contains(" ") || word.contains("//") )
			{
				lemmas.addElement(word) ;
				continue ;
			}
			String lemma = getLemma(word, tag) ;
			lemmas.addElement(lemma) ;
		}
		
		return lemmas ;
	}

	public static Set<String> getSynonyms(String lookupWord, String posLabel)
	{
		Set<String> synonyms = new HashSet<String>();
		
		POS pos = POS.getPOSForLabel(posLabel);
		if(pos == null)
		{
			System.err.println("INVALID POS LABEL: " + posLabel 
					+ " -- VALID LABELS ARE: noun, verb, adjective, adverb");
			return synonyms;
		}
		
		try
		{
			IndexWord indexWord = getDictionary().getIndexWord(pos, lookupWord);
			if (indexWord == null)
			{
				//System.err.println("NO ENTRY IN WORDNET FOR: " + lookupWord);
				return synonyms;
			}
			
			for (Synset sense : indexWord.getSenses())
				for (Word word : sense.getWords())
					if (!word.getLemma().equalsIgnoreCase(lookupWord))
						synonyms.add(word.getLemma());
		}
		catch (JWNLException e)
		{
			System.err.println("ERROR IN WORDNET LOOKUP FOR: " + lookupWord);
			e.printStackTrace();
		}
		
		return synonyms;
	}
	
	public static void main(String[] args) throws JWNLException
	{
		System.out.println(getLemma("3 hrs and 43 minutes erection", "NN"));
		System.out.println(ConceptCleanup.createLemmatizedConceptWordnet("3 hrs and 43 minutes erection"));
	}
}
