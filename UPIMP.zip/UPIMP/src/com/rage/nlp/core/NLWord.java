package com.rage.nlp.core;

import java.io.Serializable;

public class NLWord implements Comparable<NLWord>, Serializable
{
	private static final long serialVersionUID = -8621901112117923118L ;
	
	private int index ;
	private String token ;
	private String postag ;
	private String lemma ;
	
	public NLWord(int index, String token)
	{
		this.index = index ;
		this.token = token ;
	}
	
	@Override
	public boolean equals(Object obj) 
	{
		if ( obj == null )
			return false ;
		
		if ( !(obj instanceof NLWord) )
			return false ;
		
		NLWord other = (NLWord) obj ;
		
		if ( other.getIndex() == this.getIndex() 
				&& other.getToken().equalsIgnoreCase(this.getToken()) 
				&& other.getPostag().equalsIgnoreCase(this.getPostag())
				&& other.getLemma().equalsIgnoreCase(this.getLemma()) )
			return true ;
			
		return false ;
	}
	
	@Override
	public int hashCode() 
	{
		int code = 0 ;
		int prime = 31 ;
		
		code = code + prime * getIndex() ;
		code = code + (getToken() == null ? 0 : prime * getToken().hashCode()) ;
		code = code + (getPostag() == null ? 0 : prime * getPostag().hashCode()) ;
		code = code + (getLemma() == null ? 0 : prime * getLemma().hashCode()) ;
		
		return code ;
	}
	
	@Override
	public int compareTo(NLWord other) 
	{
		if(this.getIndex()!=other.getIndex())
		return new Integer(this.getIndex()).compareTo(new Integer(other.getIndex())) ;
		else
			return this.getLemma().compareTo(other.getLemma());
	}
	
	@Override
	public String toString() 
	{
		String ret = "" ;
		ret = "[" + this.getToken() + "-" + this.getPostag() + "-" + this.getLemma() + "]" ;
		return ret ;
	}
	
	public int getIndex() 
	{
		return index;
	}

	public void setIndex(int index) 
	{
		this.index = index;
	}

	public String getToken() 
	{
		return token;
	}

	public void setToken(String token) 
	{
		this.token = token;
	}

	public String getPostag() 
	{
		return postag;
	}

	public void setPostag(String postag) 
	{
		this.postag = postag;
	}

	public String getLemma() 
	{
		return lemma;
	}

	public void setLemma(String lemma) 
	{
		this.lemma = lemma;
	}
}
