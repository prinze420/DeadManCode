package com.rage.nlp.core;

import java.io.Serializable;
import java.util.Vector;

public class NLChunk implements Comparable<NLChunk>, Serializable
{
	private static final long serialVersionUID = -8248654720718267074L ;

	private int index ;
	private String type ;
	private Vector<NLWord> tokens ;
	private String lemmatizedChunk;
	private String chunk ;
	private int startIndex ;
	private int endIndex ;

	public NLChunk(int index)
	{
		this.index = index ;
		this.tokens = new Vector<NLWord>() ;
		this.chunk = "" ;
		this.startIndex = -1 ;
		this.endIndex = -1 ;
		this.lemmatizedChunk="";
	}

	public NLChunk(int index, int startIndex)
	{
		this.index = index ;
		this.tokens = new Vector<NLWord>() ;
		this.chunk = "" ;
		this.startIndex = startIndex ;
		this.endIndex = startIndex ;
		this.lemmatizedChunk="";
	}

	public NLChunk(int index, int startIndex, NLWord word)
	{
		this.index = index ;
		this.tokens = new Vector<NLWord>() ;
		this.tokens.addElement(word) ;
		this.chunk = word.getToken() ;
		this.startIndex = startIndex ;
		this.endIndex = startIndex ;
		this.lemmatizedChunk=word.getLemma();
	}

	public void addChunk(NLWord word)
	{
		this.tokens.addElement(word) ;
		this.chunk = this.chunk.trim().equals("") ? word.getToken() : this.chunk.trim() + " " + word.getToken() ;
		this.lemmatizedChunk = this.lemmatizedChunk.trim().equals("") ? word.getLemma() : this.lemmatizedChunk.trim() + " " + word.getLemma() ;
		this.endIndex = word.getIndex() ;
	}

	public int getSize()
	{
		return this.endIndex - this.startIndex ;
	}

	@Override
	public int hashCode()
	{
		return this.getChunk().toLowerCase().hashCode() ;
	}

	@Override
	public String toString()
	{
		String ret = "" ;
		ret = this.chunk + "[" + this.type + ", " + this.startIndex + ", " + this.endIndex + "]" ;
		return ret ;
	}

	@Override
	public int compareTo(NLChunk o)
	{
		Integer thisStartIndex = new Integer(this.startIndex) ;
		Integer otherStartIndex = new Integer(o.getStartIndex()) ;
		return thisStartIndex.compareTo(otherStartIndex) ;
	}

	public Vector<String> getStrTokens()
	{
		Vector<String> strTokens = new Vector<String>() ;

		for ( int i=0 ; i<this.tokens.size() ; i++ )
			strTokens.addElement(this.tokens.elementAt(i).getToken()) ;

		return strTokens ;
	}

	public Vector<String> getStrPostags()
	{
		Vector<String> strPostags = new Vector<String>() ;

		for ( int i=0 ; i<this.tokens.size() ; i++ )
			strPostags.addElement(this.tokens.elementAt(i).getPostag()) ;

		return strPostags ;
	}

	public Vector<String> getStrLemmas()
	{
		Vector<String> strLemmas = new Vector<String>() ;

		for ( int i=0 ; i<this.tokens.size() ; i++ )
			strLemmas.addElement(this.tokens.elementAt(i).getLemma()) ;

		return strLemmas ;
	}

	public Vector<NLWord> getTokens()
	{
		return tokens;
	}

	public void setTokens(Vector<NLWord> tokens)
	{
		this.tokens = tokens;
	}

	public String getChunk()
	{
		return chunk;
	}

	public void setChunk(String chunk)
	{
		this.chunk = chunk;
	}

	public int getStartIndex()
	{
		return startIndex;
	}

	public void setStartIndex(int startIndex)
	{
		this.startIndex = startIndex;
	}

	public int getEndIndex()
	{
		return endIndex;
	}

	public void setEndIndex(int endIndex)
	{
		this.endIndex = endIndex;
	}

	public int getIndex()
	{
		return index;
	}

	public void setIndex(int index)
	{
		this.index = index;
	}

	public String getType()
	{
		return type;
	}

	public void setType(String type)
	{
		this.type = type;
	}

	public String getLemmatizedChunk()
	{
		/*String lemmatizedChunk="";
		for ( int i=0 ; i<this.tokens.size() ; i++ )
		{
			String lemma=this.tokens.elementAt(i).getLemma() ;
			lemmatizedChunk = lemmatizedChunk.trim().equals("") ? lemma : lemmatizedChunk.trim() + " " + lemma ;
		}
		return lemmatizedChunk.trim();*/
		return this.lemmatizedChunk;
	}

	public void setLemmatizedChunk(String lemmatizedChunk)
	{
		this.lemmatizedChunk = lemmatizedChunk;
	}
}
