package com.rage.nlp.core;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;

import junit.runner.Version;
import edu.stanford.nlp.process.WhitespaceTokenizer;

public class LuceneStemmer 
{
	//public static Analyzer analyzer = null;
	
	//public static Analyzer getDefaultAnalyzer()
//	{
//		Analyzer keywordAnalyzer = new Analyzer()
//		{
//			@SuppressWarnings("deprecation")
//			@Override
//			protected TokenStreamComponents createComponents(String field, Reader reader) {
//				TokenStream result = null;
//				Tokenizer source = new WhitespaceTokenizer(Version.LUCENE_CURRENT, reader);			
//				result = new LowerCaseFilter(Version.LUCENE_CURRENT,source);	
//				result = new PorterStemFilter(result);
//				return new TokenStreamComponents(source, result) ;
//
//			}
//		} ;
//
//		return keywordAnalyzer ;
//	}
	
	public static String getAnalyzedTerm(String input)
	{
		/*if(analyzer==null)
		{
			analyzer = getDefaultAnalyzer();
		}*/
		
		String ret = "" ;
		/*
		TokenStream stream =null;
		try
		{
			stream =analyzer.tokenStream("", new StringReader(input)) ;
			CharTermAttribute termAtt = stream.addAttribute(CharTermAttribute.class);
			stream.reset();

			while ( stream.incrementToken() )
			{
				String strToken =termAtt.toString();
				ret = ret.trim() + " " + strToken ;
			}
			stream.end();
		}
		catch (Exception e)
		{
			System.err.println("ERROR") ;
			e.printStackTrace() ;
		}
		finally
		{
			try {
				stream.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
*/
		return ret.trim();
	}
	
	public static void main(String[] args) 
	{
	  System.out.println(getAnalyzedTerm("chap-stick-a-holic"));
	}

}
