package com.rage.nlp.core;

import java.io.FileInputStream;
import java.util.Arrays;
import java.util.Vector;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;


public class Tokenizer 
{
	private static String PROPERTY_TOKENIZE_MODEL = "nlp.opennlp.tokenize.model" ;
	private static TokenizerME tokenizer ;
	
	public synchronized static TokenizerME getTokenizer()
	{
		if ( tokenizer == null )
		{
			try
			{
				String fileName = Configuration.getProperty(PROPERTY_TOKENIZE_MODEL) ;
				// System.out.println("TOKENIZER FILE NAME : " + fileName) ;
				TokenizerModel model = new TokenizerModel(new FileInputStream(fileName)) ;
				tokenizer = new TokenizerME(model) ;
				// System.out.println("TOKENIZER MODEL : " + tokenizer) ;
			}
			catch (Exception e) 
			{
				System.err.println("ERROR IN LOADING THE TOKENIZER MODEL : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		
		return tokenizer ;
	}
	public synchronized static Vector<String> tokenize(String sentence)
	{
		String[] tokens_arr = getTokenizer().tokenize(sentence) ;
		return new Vector<String>(Arrays.asList(tokens_arr)) ;
	}
	public  static Vector<String> split(String sentence)
	{
		String[] tokens_arr = sentence.trim().split(" ");
		return new Vector<String>(Arrays.asList(tokens_arr)) ;
	}
	
}
