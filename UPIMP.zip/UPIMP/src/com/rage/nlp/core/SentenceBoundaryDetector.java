package com.rage.nlp.core;

import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Vector;
import opennlp.tools.sentdetect.SentenceDetectorME;
import opennlp.tools.sentdetect.SentenceModel;



public class SentenceBoundaryDetector
{
	private static String PROPERTY_SENTDETECT_MODEL = "nlp.opennlp.sentdetect.model" ;
	private static SentenceDetectorME sentenceDetector ;

	public synchronized static SentenceDetectorME getSentenceDetector()
	{
		if ( sentenceDetector == null )
		{
			try
			{
				String fileName = Configuration.getProperty(PROPERTY_SENTDETECT_MODEL) ;
				SentenceModel model = new SentenceModel(new FileInputStream(fileName)) ;
				sentenceDetector = new SentenceDetectorME(model) ;
			}
			catch (Exception e) 
			{
				System.err.println("ERROR IN LOADING THE SENTENCE DETECTOR : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return sentenceDetector ;
	}

	/*public static Vector<String> detectBoundaries(String content)
	{
		Vector<String> sentences = new Vector<String>() ;

		if ( content.equalsIgnoreCase("") )
			return sentences ;

		content = StartGarbageRemover.removeStartingGarbage(content) ;
		content = EncodingNormalizer.normalizeEncoding(content) ;
		content = CommonPhraseReplacer.replaceCommonPhrases(content) ;

	//	System.out.println("INPUT TO STANFORD SENTENCE DETECTOR : " + content) ;
		Vector<String> stanfordSentences = detectSentenceBoundary(content) ;
	//	System.out.println("STANFORD SENTENCES : " + stanfordSentences) ;

		for ( int i=0 ; i<stanfordSentences.size() ; i++ )
		{
			String stanfordSentence = stanfordSentences.elementAt(i) ;
			Vector<String> openNLPSentences = new Vector<String>(Arrays.asList(getSentenceDetector().sentDetect(stanfordSentence))) ;

			for ( int j=0 ; j<openNLPSentences.size() ; j++ )
			{
				String openNLPSentence = openNLPSentences.elementAt(j) ;

				StringTokenizer st = new StringTokenizer(openNLPSentence, ";:=") ;
				while ( st.hasMoreTokens() )
				{
					String sentence = st.nextToken() ;
				//	System.out.println("SENTENCE : " + sentence) ;
					sentence = Decapitalizer.decapitalize(sentence) ;
					sentence = StartGarbageRemover.removeStartingGarbage(sentence) ;
					sentence = NumberCharacterSeparater.addSpaces(sentence) ;
					sentence = CommonPhraseReplacer.replaceCommonPhrases(sentence) ;
					//System.out.println("\tAFTER GARBAGE REMOVAL : " + sentence) ;
					sentences.addElement(sentence) ;
				}
			}
		}
		return sentences ;
	}*/

	/*public static String detectSentenceBoundaryUsingStanford(String content)
	{
		Vector<String> sentences = new Vector<String>() ;
		Options options = new Options() ;
		DocumentPreprocessor dp = new DocumentPreprocessor(options.tlpParams.treebankLanguagePack().getTokenizerFactory()) ;

		List<List<? extends HasWord>> dummy = dp.getSentencesFromText(new StringReader(content)) ;

		for ( int i=0 ; i<dummy.size() ; i++ )
		{
			List<? extends HasWord> tokens = dummy.get(i) ;
			String thisSentence = "" ;
			for ( int j=0 ; j<tokens.size() ; j++ )
			{
				thisSentence = thisSentence.trim() + " " + tokens.get(j).word() ;
			}

			thisSentence = thisSentence.replaceAll("-LRB-", "(").replaceAll("-RRB-", ")").trim() ;

			sentences.addElement(thisSentence) ;
		}

		String finalContent = "" ;
		for ( int i=0 ; i<sentences.size() ; i++ )
		{
			finalContent = finalContent.trim() + " " + sentences.elementAt(i).trim() ;
		}

		return finalContent ;
	}
*/
	public synchronized static Vector<String> detectSentenceBoundaryNew(String content)
	{
		if ( content.equals("") )
			return new Vector<String>() ;

		// content = detectSentenceBoundaryUsingStanford(content) ;
		//System.out.println("FINAL CONTENT : " + content) ;

		String[] sentence_arr = getSentenceDetector().sentDetect(content) ;

		Vector<String> sentences = new Vector<String>(Arrays.asList(sentence_arr)) ;
		for ( int i=0 ; i<sentences.size() ; i++ )
		{
			String sentence = sentences.elementAt(i) ;
			sentence = sentence.replaceAll("&", " and ") ;
			sentences.setElementAt(sentence, i) ;
		}

		Vector<String> newSentences = new Vector<String>() ;
		for ( int i=0 ; i<sentences.size() ; i++ )
		{
			String oldSentence = sentences.elementAt(i) ;
			if ( !oldSentence.trim().endsWith(".") && !oldSentence.trim().endsWith("?") && !oldSentence.trim().endsWith("!") && !oldSentence.trim().endsWith("\"") )
			{
				String newSentence = "" ;
				for ( int j=i ; j<sentences.size() ; j++ )
				{
					String thisSentence = sentences.elementAt(j) ;

					boolean added = false ;

					if ( !thisSentence.trim().endsWith(".") || !thisSentence.trim().endsWith("?") || !thisSentence.trim().endsWith("!") || !thisSentence.trim().endsWith("\"") )
					{
						newSentence = newSentence.trim() + " " + thisSentence ;
						added = true ;
					}

					if ( thisSentence.trim().endsWith(".") || thisSentence.trim().endsWith("?") || thisSentence.trim().endsWith("!") || thisSentence.trim().endsWith("\"") )
					{
						if ( !added )
							newSentence = newSentence.trim() + " " + thisSentence ;
						break ;
					}

					i++ ;
				}

				newSentence = newSentence.replaceAll("\\s{2}", " ");
				if(checkSentenceLength(newSentence))
					newSentences.addElement(newSentence) ;
			}
			else
			{
				oldSentence = oldSentence.replaceAll("\\s{2}", " ");
				if(checkSentenceLength(oldSentence))
					newSentences.addElement(oldSentence) ;
			}
		}

		return newSentences ;
	}

	public synchronized static Vector<String> detectSentenceBoundary(String content)
	{
		if ( content.equals("") )
			return new Vector<String>() ;
		
		// content = detectSentenceBoundaryUsingStanford(content) ;
		//System.out.println("FINAL CONTENT : " + content) ;

		String[] sentence_arr = getSentenceDetector().sentDetect(content) ;

		Vector<String> sentences = new Vector<String>(Arrays.asList(sentence_arr)) ;
		for ( int i=0 ; i<sentences.size(); i++ )
		{
			String sentence = sentences.elementAt(i) ;
			sentence = Decapitalizer.decapitalize(sentence) ;
			//	sentence =sentence.replaceAll("&amp;" ," and ");
			sentence = sentence.replaceAll("&", " and ") ;
			sentences.setElementAt(sentence, i) ;
		}

		Vector<String> newSentences = new Vector<String>() ;
		for ( int i=0 ; i<sentences.size() ; i++ )
		{
			String oldSentence = sentences.elementAt(i) ;
			if ( !oldSentence.trim().endsWith(".") && !oldSentence.trim().endsWith("?") && !oldSentence.trim().endsWith("!") && !oldSentence.trim().endsWith("\"") )
			{
				String newSentence = "" ;
				for ( int j=i ; j<sentences.size() ; j++ )
				{
					String thisSentence = sentences.elementAt(j) ;

					boolean added = false ;

					if ( !thisSentence.trim().endsWith(".") || !thisSentence.trim().endsWith("?") || !thisSentence.trim().endsWith("!") || !thisSentence.trim().endsWith("\"") )
					{
						newSentence = newSentence.trim() + " " + thisSentence ;
						added = true ;
					}

					// System.out.println("BEFORE ADDING LAST SENTENCE ... " + newSentence) ;
					if ( thisSentence.trim().endsWith(".") || thisSentence.trim().endsWith("?") || thisSentence.trim().endsWith("!") || thisSentence.trim().endsWith("\"") )
					{
						if ( !added )
							newSentence = newSentence.trim() + " " + thisSentence ;
						break ;
					}

					i++ ;
				}

				// System.out.println("ADDING MODIFIED SENTENCE : " + newSentence) ;
				newSentences.addElement(newSentence) ;
			}
			else
			{
				// System.out.println("ADDING SIMPLE SENTENCE : " + oldSentence) ;
				newSentences.addElement(oldSentence) ;
			}
		}

		return newSentences ;
	}

	public static boolean checkSentenceLength(String sentence)
	{
		List<String> tokens = new ArrayList<String>(Arrays.asList(sentence.split(" "))) ;
		Integer maxlength=Integer.parseInt(Configuration.getProperty("max.sentence.length"));
		if ( tokens.size() >= maxlength )
		{
			return false;
		}

		return true;
	}
	public static void main(String[] args) 
	{
		// String data = "ABOUT 2000 asylum-seekers living in the community will have to re_enter detention and have their cases reassessed by the Immigration Department bureaucracy after the opposition and Greens combined to have regulations in the U.S relating to bridging visas disallowed.The motion sought to disallow a regulation that allowed for the rollover of the bridging visas. But government sources said yesterday the move would only relate to bridging visas established prior to the August 13 revamp of asylum-seeker policy .This would force about 2000 people who had been issued with bridging visas , and who were living in the community , to re_enter detention to have their cases reassessed once they expired.The Senate motion came after the opposition accused the government of suffering a rolling crisis that has no end on asylum-seeker policy .This followed an announcement by Immigration Minister Chris Bowen that asylum-seekers arriving since the new Pacific Solution was announced would be allowed to live in the Australian community but would be subject_to the same no-advantage test as those sent for offshore processing.As opposition immigration spokesman Scott Morrision accused the government of being completely overwhelmed by the influx of asylum-seekers , the Greens accused Labor of becoming more cruel as it sought to arrest the flow of boatpeople .Greens leader Christine Milne said the government was guilty of flawed thinking ." ;

		String data = "Like in today's Giullieta and Mito hatchbacks, there's a three-step drive mode selector for the driver to choose from: Eco, Normal and Dynamic." ;

		/*String data = "Red Line: Retail sales (excluding food services) rate of change year over year. " +
				"This indicator has given us a rather clear cycle of a peak in year over year percent change in retail sales. " +
				"March of 1994, retail sales grew 11.6% year over year. " +
				"Sixty-five months later, August of 1999, retail sales peaked again at 10.7% year over year. " +
				"Seventy-one months later, July 2005, retail sales grew 9.4% and in June of 2011, which was seventy months after that peak, retail sales were growing at 9.5% year over year growth. " +
				"So 65, 71 and 70 are the months of time between each peak, which comes out to an average of 5.7 years. " +
				"The rate of change always caught up with the rate of change of wages and would even undershoot wage growth. " +
				"This implies that retail sales are set to continue to fall and at some point in the future will once again be at a level of growth that is less than the level of wage growth, which is at the lowest level in at least the last 50 years growing at just 1.4% for production workers. " +
				"Blue Line: All Employees in retail trade which shows that the rate of change in the number of people in the U.S. with a job in retail is trending down again. " +
				"Orange Line: Average hourly wage of non supervisor production workers year over year percent change. T" +
				"he year over year percent change trend has been lower and lower and the most recent data shows that average wages are growing only 1.5% year over year. " +
				"Green Line: Gross domestic product year over year percent change. " +
				"Since 1994, GDP rate of change more or less hugged the rate of change in retail sales.  " +
				"In the last recession, retail sales overshot the rate of decline in GPD and in the recovery, retail sales growth overshot to the upside. " +
				"It might well be payback time suggesting retail sales growth is heading down again. " +
				"Retail sales are coming and should continue to come under severe pressure from this perspective. " +
				"The consumer discretionary select ETF fund (XLY) has done spectacularly well in this latest retail sales recovery with many stocks in that sector setting all time highs. " +
				"Here is a chart of this fund:" ;*/ 	
		// String data = "I went to New York. The final vote on Sen. Joe Lieberman's (I-Conn.) Cybersecurity Act was 52-46, short of the 60 votes needed to cut off debate and move the legislation forward. Republican senators who voted for the bill were Sens. Dick Lugar (Ind.), Dan Coats (Ind.), Scott Brown (Mass.) and Susan Collins (R-Maine), who was also a main co-sponsor. I went to New York." ;
		// String data = "At the current price of $380.68, it's selling at 17x trailing 12 months earnings. Auto zone has a negative equity of $1.416 billion as of May 5th, 2012." ;
		Vector<String> sentences = detectSentenceBoundary(data) ;
		for ( int i=0 ; i<sentences.size() ; i++ )
			System.out.println(i + " : " + sentences.elementAt(i)) ;
	}
}
