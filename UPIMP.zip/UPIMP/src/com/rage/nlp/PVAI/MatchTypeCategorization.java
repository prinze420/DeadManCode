package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import com.rage.nlp.PVAI.ConceptCleanup;

public class MatchTypeCategorization
{
	public static final String DATE_FORMAT_ANS = "dd-MMM-yyyy";
	public static final String DATE_FORMAT_ANS1 = "d-MMM-yy";
	public static final String DATE_FORMAT_ANS2 = "d-MMM-yy";
	public static final String DATE_FORMAT_RES = "MM/dd/yyyy";
	public static final String DATE_FORMAT_RES1 = "dd-MM-yyyy";
	public static final String DATE_FORMAT_RES2 = "MM/dd/yy";
	public static final String DATE_FORMAT_RES3 = "dd-MM-yy";
	public static final String DATE_FORMAT_RES4 = "ddMMyyyy";
	public static final String DATE_FORMAT_RES5 = "dd-MMM-yyyy";
	public static String Synonyms_file = "resource/synonyms.txt" ;
	public static Map<String,HashSet<String>> synonymsMap;

	private static boolean DEBUG=false;

	public static Map<String,HashSet<String>> getSynonymsMap()
	{
		if(synonymsMap==null)
			loadMapFromFile();

		return synonymsMap;
	}


	private static void loadMapFromFile()
	{
		synonymsMap = new HashMap<String, HashSet<String>>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(Synonyms_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || line.startsWith("#"))
					continue ;

				List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
				String concept = split.get(0).toLowerCase().trim();
				String synonym = split.get(1).toLowerCase().trim();
				HashSet<String> synonyms = synonymsMap.containsKey(concept) ? synonymsMap.get(concept) : new HashSet<String>();
				synonyms.add(synonym);
				synonymsMap.put(concept, synonyms);
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + Synonyms_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
	}


	private static int minDistance(String word1, String word2) 
	{
		int len1 = word1.length();
		int len2 = word2.length();

		// len1+1, len2+1, because finally return dp[len1][len2]
		int[][] dp = new int[len1 + 1][len2 + 1];

		for (int i = 0; i <= len1; i++) {
			dp[i][0] = i;
		}

		for (int j = 0; j <= len2; j++) {
			dp[0][j] = j;
		}

		//iterate though, and check last char
		for (int i = 0; i < len1; i++) {
			char c1 = word1.charAt(i);
			for (int j = 0; j < len2; j++) {
				char c2 = word2.charAt(j);

				//if last two chars equal
				if (c1 == c2) {
					//update dp value for +1 length
					dp[i + 1][j + 1] = dp[i][j];
				} else {
					int replace = dp[i][j] + 1;
					int insert = dp[i][j + 1] + 1;
					int delete = dp[i + 1][j] + 1;

					int min = replace > insert ? insert : replace;
					min = delete > min ? min : delete;
					dp[i + 1][j + 1] = min;
				}
			}
		}

		return dp[len1][len2];
	}

	public static String checkMatchType(Set<String> answer, String conceptStr)
	{
		String matchType="";
		for(String goldValue : answer)
		{
			if(goldValue.contains("_") && !conceptStr.contains("_") )
			{
				goldValue= goldValue.substring(0,goldValue.indexOf("_")) ;
			}
			matchType=goldValue.equalsIgnoreCase(conceptStr) ?"Exact Match": "";
			if(matchType.isEmpty())
			{
				goldValue=ConceptCleanup.refineConcept(goldValue);
				conceptStr=ConceptCleanup.refineConcept(conceptStr);
				if(goldValue.isEmpty()||conceptStr.isEmpty())
					matchType="";
				else
					matchType=goldValue.equalsIgnoreCase(conceptStr) ? "Exact Match" 
							: (isPartialMatch(goldValue, conceptStr)) ? "Partial Match" : matchType;
			}

			if(matchType.equalsIgnoreCase("Exact Match"))
				return matchType;
		}
		if(!matchType.isEmpty())
			return matchType;
		return "Mis-Match";
	}

	public static String getLongDate(String date)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_ANS);
		Date parseDate = null;
		try
		{
			SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES);
			parseDate = sdf1.parse(date);
		}
		catch (ParseException e) 
		{
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES1);
				parseDate = sdf1.parse(date);
			}
			catch (ParseException e1) 
			{
				try
				{
					SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES2);
					parseDate = sdf1.parse(date);
				}
				catch (ParseException e2) 
				{
					try
					{
						SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES3);
						parseDate = sdf1.parse(date);
					}
					catch (ParseException e3) 
					{
						try
						{
							SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES4);
							parseDate = sdf1.parse(date);
						}
						catch (ParseException e4) 
						{
							try
							{
								SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_RES5);
								parseDate = sdf1.parse(date);
							}
							catch (ParseException e5) 
							{
								e.printStackTrace();
							}
						}
					}
				}
			}
		}
		String ret=parseDate!=null ?sdf.format(parseDate):date;
		return ret;
	}

	public static String getLongDate1(String date)
	{
		SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_ANS);
		Date parseDate = null;
		try
		{
			SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_ANS2);
			parseDate = sdf1.parse(date);
		}
		catch (ParseException e1) 
		{
			try
			{
				SimpleDateFormat sdf1 = new SimpleDateFormat(DATE_FORMAT_ANS1);
				parseDate = sdf1.parse(date);
			}
			catch (ParseException e2) 
			{
				e1.printStackTrace();
			}
		}

		String ret=parseDate!=null ?sdf.format(parseDate):date;
		return ret;
	}
	public static String checkMatchType(String goldValue, String conceptStr, boolean checkPartial)
	{
		String matchType="";
		if(goldValue.contains("_") && !conceptStr.contains("_") )
		{
			goldValue= goldValue.substring(0,goldValue.indexOf("_")) ;
		}
		matchType=goldValue.equalsIgnoreCase(conceptStr) ?"Exact Match": "";
		if(matchType.isEmpty() && checkPartial)
		{
			goldValue=ConceptCleanup.refineConcept(goldValue);
			conceptStr=ConceptCleanup.refineConcept(conceptStr);
			if(goldValue.isEmpty()||conceptStr.isEmpty())
				matchType="";
			else
				matchType=goldValue.equalsIgnoreCase(conceptStr) ? "Exact Match" 
						:(isPartialMatch(goldValue, conceptStr) ? "Partial Match" : matchType)  ;
		}
		return matchType;
	}



	private static boolean isPartialMatch(String goldValue, String conceptStr)
	{
		boolean ret=false;
		String reason="";
		HashSet<String> mentionsSet = new HashSet<String>(Arrays.asList(goldValue.split(" ")));
		HashSet<String> candidatesSet = new HashSet<String>(Arrays.asList(conceptStr.split(" ")));
		if(DEBUG)
		{
			System.out.println(mentionsSet);
			System.out.println(candidatesSet);
		}
		if(mentionsSet.size()==1 && candidatesSet.size()==1)
		{
			int distance=MatchTypeCategorization.minDistance(goldValue, conceptStr);
			if(distance<=2)
			{
				reason="Edit Distance "+distance;
				ret=true;
			}
		}
		else
		{
			boolean isContained= isOneContainedInOther(mentionsSet, candidatesSet);
			if(isContained)
			{
				if(DEBUG)
					reason="Tokens Overlap";
				ret=true;
			}
			else 			
			{
				HashSet<String> synonyms = getSynonymsMap().containsKey(goldValue.toLowerCase()) ? getSynonymsMap().get(goldValue.toLowerCase()): new HashSet<String>();
				if(synonyms.contains(conceptStr.toLowerCase()))
				{
					reason="Synonym Match";
					ret=true;
				}
				else if(candidatesSet.size()==1 && mentionsSet.size()>1)
				{
					String acronym= findAcronyms(goldValue);
					if(conceptStr.equalsIgnoreCase(acronym))
					{
						reason="Acronym Match";
						ret=true;
					}
					else
					{
						int distance=MatchTypeCategorization.minDistance(acronym.toLowerCase(), conceptStr.toLowerCase());
						if(distance<=1)
						{
							reason="Acronym Match Edit Distance "+distance;
							ret=true;
						}
					}
				}
			}
		}
		if(ret && !reason.isEmpty())
		{
			System.out.println("Found Partial Match\t"+reason+"\t"+goldValue+"\t"+conceptStr);
		}
		return ret;
	}

	private static boolean isOneContainedInOther(HashSet<String> mentionsSet, HashSet<String> candidatesSet) 
	{

		if ( mentionsSet.size() == 0 || candidatesSet.size() == 0 )
			return false ;

		for(String mention : mentionsSet)
		{
			boolean found = false;
			for(String candidate : candidatesSet)
			{
				if(mention.equalsIgnoreCase(candidate)|| ( mention.contains(candidate+" ") || candidate.contains(mention+" ")))
				{
					found=true;
					break;
				}
			}
			if(found)
			{
				return true;
			}
		}
		return false ;
	}

	private static String findAcronyms(String conceptStr)
	{
		String[] tokens = conceptStr.split("\\s");
		String ret = "";

		for(int i = 0; i < tokens.length; i++){
			if(tokens[i].isEmpty() || tokens[i].matches("Mr|Mrs|Dr|Mr\\.|Mrs.|Dr\\.|Ms|Ms\\."))
				continue;
			char capLetter = Character.toUpperCase(tokens[i].charAt(0));
			ret +=  capLetter;
		}
		return ret;

	}

	public static void main(String[] args)
	{
		System.out.println(getLongDate("13-DEC-1934"));
		System.out.println(checkMatchType("28-Aug-53", "28-Aug-53",false));
	}
}
