package com.rage.nlp.PVAI;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.rage.nlp.core.LuceneStemmer;
import com.rage.nlp.core.MorphologicalAnalyzer;
import com.rage.nlp.core.PosTagger;
import com.rage.nlp.core.StopWords;

import edu.stanford.nlp.ling.TaggedWord;

public class ConceptCleanup
{

	public static String createLemmatizedConcept(String concept)
	{
		StringBuffer ret= new StringBuffer();
		/*try
		{
			List<TaggedWord> taggedWords = PosTagger.getCustomTaggedWords(concept);
			for (TaggedWord taggedWord : taggedWords)
			{
				String lemma = MorphologicalAnalyzer.getLemma(taggedWord.word(), taggedWord.tag()) ;
				ret.append(lemma);
				ret.append(" ");
			}
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING TOKENIZATION-POSTAGGING-MORPHPOLOGICAL ANALYSIS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}*/
		List<String> tokens = Arrays.asList(concept.split(" "));
		for(String token : tokens)
		{
			String stem= LuceneStemmer.getAnalyzedTerm(token);
			if(!stem.isEmpty())
			{
				ret.append(stem);
			}
			else
				ret.append(token);
			ret.append(" ");
		}
		return ret.toString().trim();
	}

	public static String createLemmatizedConceptWordnet(String concept)
	{
		StringBuffer ret= new StringBuffer();
		try
		{
			StringTokenizer st = new StringTokenizer(concept," !@#$%^&*()+=~`{}[]|\\:;\"'<>?,./");
			while (st.hasMoreTokens())
			{
				String token = st.nextToken().trim();
				String lemma = MorphologicalAnalyzer.getLemma(token, "NN") ;
				ret.append(lemma);
				ret.append(" ");
			}
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING TOKENIZATION-POSTAGGING-MORPHPOLOGICAL ANALYSIS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		return ret.toString().trim();
	}

	public static String getNounTokens(String strSentence) 
	{
		String ret="";
		try
		{
			List<TaggedWord> taggedWords = PosTagger.getCustomTaggedWords(strSentence);
			for (TaggedWord taggedWord : taggedWords)
			{
				if(taggedWord.tag().startsWith("NN"))
					ret= ret.trim()+" "+taggedWord.word();
			}
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING TOKENIZATION-POSTAGGING-MORPHPOLOGICAL ANALYSIS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		return ret.trim() ;

	}

	public static String refineConcept(String split)
	{
		String ret = "";
		StringTokenizer st = new StringTokenizer(split.toLowerCase()," !@#$%^&*()+=~`{}[]|\\:;\"'<>?,./");
		while (st.hasMoreTokens())
		{
			String token = st.nextToken().trim();
			if (StopWords.isStopWord(token))
				continue;
			if(isNumber(token))
			{
				continue ;
			}
			if(token.length()==1 || token.equalsIgnoreCase("mg"))
				continue;
			//ret = ret.replaceAll("[^\\w]", " ");
			ret = ret.trim() + " " + token;
		}
		return ret.replaceAll("\\s+", " ").trim();
	}

	public static String refinePatientConcept(String split)
	{
		String ret = "";
		StringTokenizer st = new StringTokenizer(split," !@#$%^&*()_+=~`{}[]|\\:;\"'<>?,./");
		while (st.hasMoreTokens())
		{
			String token = st.nextToken().trim();
			if(isNumber(token))
			{
				continue ;
			}
			//ret = ret.replaceAll("[^\\w]", " ");
			ret = ret.trim() + " " + token;
		}
		return ret.replaceAll("\\s+", " ").trim();
	}

	public static String findPatientInitials(String conceptStr)
	{
		String[] tokens = conceptStr.split("\\s");
		String ret = "";
		for(int i = 0; i < tokens.length; i++)
		{
			if(tokens[i].isEmpty() || tokens[i].matches("Mr|Mrs|Dr|Mr\\.|Mrs.|Dr\\.|Ms|Ms\\."))
				continue;
			if(tokens[i].equalsIgnoreCase("Unknown") ||  tokens[i].toLowerCase().startsWith("unk"))
			{
				ret="Unknown";
				return ret;
			}

			if(tokens[i].toLowerCase().startsWith("no "))
			{
				return conceptStr;
			}

			if(tokens[i].length()<=4 /*&& tokens[i].toUpperCase().equals(tokens[i])*/)
			{
				ret +=  tokens[i];
			}
			else
			{
				char capLetter = Character.toUpperCase(tokens[i].charAt(0));
				ret +=  capLetter;
			}
		}
		return ret;
	}

	public static boolean isNumber(String token)
	{
		String regex= token.length()==1 ? "[0-9]"  : "[0-9\\.,\\/]+[^a-zA-Z]";
		Pattern pattern = Pattern.compile(regex);
		Matcher m = pattern.matcher(token.toLowerCase());
		while(m.find())
		{
			return true ;
		} 

		return false;
	}

	public static String getAge(String token)
	{
		String regex="[0-9]+-[0-9]+"  ;
		Pattern pattern = Pattern.compile(regex);
		Matcher m = pattern.matcher(token);
		while(m.find())
		{
			return m.group(0) ;
		}
		pattern = Pattern.compile("[0-9\\.]+");
		m = pattern.matcher(token);
		while(m.find())
		{
			try
			{
				return Integer.parseInt(m.group(0))+ "" ;	
			}
			catch(Exception e)
			{
				return Double.parseDouble(m.group(0))+ "";
			}
		}
		return token;
	}

	public static List<Integer> getAgePair(String token)
	{
		List<Integer> pairs= new ArrayList<Integer>();
		String regex= "([0-9]+)-([0-9]+)"  ;
		Pattern pattern = Pattern.compile(regex);
		Matcher m = pattern.matcher(token);
		while(m.find())
		{
			pairs.add(Integer.parseInt(m.group(1)));
			pairs.add(Integer.parseInt(m.group(2)));
		} 
		return pairs;
	}

	public static String extractAge(String token)
	{
		String regex="([0-9\\.]+)[\\s|-]?(year|years|yrs|yr)[\\s|-]old";
		Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher(token);
		while(m.find())
		{
			try
			{
				return Integer.parseInt(m.group(1))+ " Years" ;	
			}
			catch(Exception e)
			{
				return Double.parseDouble(m.group(1))+ " Years";
			}
		}
		regex="age[\\s|:|\\s:\\s]([0-9]+)";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(token);
		while(m.find())
		{
			return Integer.parseInt(m.group(1))+ " Years" ;
		}
		regex="([0-9]+)[\\s|-]?(months|month)[\\s|-]old";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(token);
		while(m.find())
		{
			return Integer.parseInt(m.group(1))+ " Months" ;
		}
		regex="(I am|I'm|Now at|I 'm)\\s([0-9]+)";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(token);
		while(m.find())
		{
			return Integer.parseInt(m.group(2))+ " Years";
		}
		return "";
	}
	public static String getGender(String token)
	{
		if(token.length()==1)
		{
			if( token.equalsIgnoreCase("M"))
				return "Male";
			if( token.equalsIgnoreCase("F"))
				return "Female";
		}

		String regex= "(Male|Female)";
		Pattern pattern = Pattern.compile(regex,Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher(token);
		while(m.find())
		{
			return m.group(1) ;
		} 

		regex= "(M)(\\s+)";
		pattern = Pattern.compile(regex);
		m = pattern.matcher(token);
		while(m.find())
		{
			return "Male";
		} 

		regex= "(F)(\\s+)";
		pattern = Pattern.compile(regex);
		m = pattern.matcher(token);
		while(m.find())
		{
			return "Female";
		} 

		return "";
	}

	public static String extractGender(String sentence)
	{
		String regex="\\s+(she|her|female|daugther|mom)\\s+";
		Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher m = pattern.matcher(sentence);
		while(m.find())
		{
			return "Female" ;
		}
		regex="\\s+(he|his|male|son|husband)\\s+";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(sentence);
		while(m.find())
		{
			return "Male" ;
		}
		regex="^(he|his)\\s+";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(sentence);
		while(m.find())
		{
			return "Male" ;
		}
		regex="^(she|her)\\s+";
		pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		m = pattern.matcher(sentence);
		while(m.find())
		{
			return "Female" ;
		}
		return "";
	}

	public static String capitalizeFirstChar(String concept) 
	{
		concept=concept.replaceAll("\\s+", " ").trim();
		if(concept.isEmpty())
			return "";
		String[] tokens = concept.split("\\s");
		String ret = "";

		for(int i = 0; i < tokens.length; i++){
			if(tokens[i].isEmpty())
				continue;
			char capLetter = Character.toUpperCase(tokens[i].charAt(0));
			ret +=  " " + capLetter + tokens[i].substring(1, tokens[i].length()).toLowerCase();
		}
		return ret.trim();
	}


	public static void main(String[] args)
	{
		String age="What about hysterectomy. I was on HRT for a few years, then a thickened uterus, now they want to do a DNC. I'd just like to get rid of the stuff. I'm 54. Anyone just opt to have uterus and overies removed?";
		System.out.println(extractAge(age));
		System.out.println(getAge("12"));
	}


}
