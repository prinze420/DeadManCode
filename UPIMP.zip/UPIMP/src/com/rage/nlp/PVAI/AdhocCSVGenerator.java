package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AdhocCSVGenerator
{

	public static void main(String[] args)
	{
		String folderPath="C:\\Users\\ig0e572\\Desktop\\output\\csv";
		Boolean append= true;
		String outputFolderPath="C:\\Users\\ig0e572\\Desktop\\output\\ConsolidatedCsvOutput";
		String caseFileName = "C:\\Users\\ig0e572\\Desktop\\output\\para";
		Set<String> cases= new HashSet<String>();
		if(new File(caseFileName).isDirectory())
			cases= ConsolidationAndScoringv1.extractAllCases(caseFileName);
		else
			cases= FileReader.readFile(caseFileName);
		Map<FieldName,Map<String, Set<String>>> allCsvResults= new HashMap<FieldName, Map<String,Set<String>>>();
		File f = new File(folderPath);
		processDirectory(allCsvResults, f, cases);
		f = new File(outputFolderPath);
		f.mkdir();
		CSVoutputgenerator.generateCSVs(outputFolderPath, cases, allCsvResults, append);
	}


	private static void processDirectory(Map<FieldName, Map<String, Set<String>>> allCsvResults, File f , Set<String> cases)
	{
		try 
		{
			if (f.isDirectory()) 
			{
				for (File inputFileName : f.listFiles())
				{
					if(!inputFileName.isDirectory())
					{
						String field=inputFileName.getName().replaceAll(".csv", "");
						FieldName fieldName = FieldName.valueOf(field);
						if(fieldName.equals(FieldName.AE_VERBATIM))
						{
							fieldName=FieldName.AE_VERBATIM_SENTENCE;
						}
						if(fieldName.equals(FieldName.AE_VERBATIM_Normalized))
						{
							System.out.println("Considering Normalized AE file ::"+inputFileName);
							fieldName=FieldName.AE_VERBATIM;
						}
						Map<String, Set<String>> results= allCsvResults.containsKey(fieldName) ? allCsvResults.get(fieldName) : new HashMap<String, Set<String>>();
						results= readCSV(inputFileName, results , fieldName);
						allCsvResults.put(fieldName, results);
						cases.addAll(results.keySet());
						cases = new HashSet<String>(cases);
						System.out.println("Processed ::"+inputFileName+"\t"+fieldName+"\t"+results.size());
					}
					else
					{
						processDirectory(allCsvResults, inputFileName, cases);
					}
				}
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	private static Map<String, Set<String>> readCSV(File inputFileName , Map<String, Set<String>> results, FieldName fieldName)
	{
		String line = "";
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(inputFileName)))) ;
			int i=0;
			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") || i==0 )
				{
					System.err.println("Ignoring::"+inputFileName+"\t"+line);
					i++;
					continue ;
				}

				List<String> split = new ArrayList<String>(Arrays.asList(line.split(","))) ;
				if(split.size()>=2)
				{
					String caseID = split.get(0);
					String result = fieldName.equals(FieldName.PAT_INITIALS) ? split.get(1) :ConceptCleanup.capitalizeFirstChar(split.get(1));
					Set<String> values = results.containsKey(caseID) ? results.get(caseID) : new HashSet<String>();
					values.add(result);
					results.put(caseID, values);
				}
				else if(split.size()<2)
				{
					System.err.println(inputFileName+"\t"+line);
				}
				i++;
			}

		} 
		catch (FileNotFoundException e) 
		{
			e.printStackTrace();	        
		} catch (IOException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			if (br != null) 
			{
				try {
					br.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return results;
	}

}
