package com.rage.nlp.PVAI;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CSVoutputgenerator
{

	private static boolean normalize =false;
	public static void updateCSVOutput(String csvFolderName ,Map<FieldName, Map<String, Set<String>>> allCsvResults, boolean append)
	{
		for(FieldName fieldName : allCsvResults.keySet())
		{
			Map<String, Set<String>> allResults = allCsvResults.get(fieldName);
			writeToCSV(csvFolderName, allResults, append, fieldName);
		}
	}

	public static void writeToCSV(String csvFolderName, Map<String, Set<String>> allResults, boolean append, FieldName fieldName)
	{
		String delimiter= ",";
		String sheetName=fieldName.toString();
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(csvFolderName+File.separator+sheetName+".csv", append);
			if(fieldName.equals(FieldName.TRADE_NAME))
			{
				fileWriter.append("CASENUMBER"+delimiter+sheetName+delimiter+"SUSPECT_CONMED_FLAG\n");
			}
			else
			{
				fileWriter.append("CASENUMBER"+delimiter+sheetName+"\n");
			}

			for(String caseID : allResults.keySet())
			{
				Set<String> results = allResults.get(caseID);
				for(String result : results)
				{
					result = result.replaceAll(",", " ").replaceAll("\\s+", " ");
					if(fieldName.equals(FieldName.TRADE_NAME))
					{
						result=ConceptCleanup.capitalizeFirstChar(result);
						fileWriter.append(caseID+delimiter+result+delimiter+"Suspect\n");
					}
					else
					{
						fileWriter.append(caseID+delimiter+result+"\n");
					}
				}
				fileWriter.flush();
			}
			System.out.println("Final CSV written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	public static void generateCSVs(String csvFolderName, Set<String> cases, Map<FieldName, Map<String, Set<String>>> allCsvResults,boolean append)
	{
		System.out.println("Total Cases ::"+cases.size());
		updateProductCSVOutput(csvFolderName, allCsvResults, append);
		updateEventCSVOutput(csvFolderName, allCsvResults,append);
		updatePatientCSVOutput(csvFolderName, allCsvResults, cases, append);
		updateReporterCSVOutput(csvFolderName, allCsvResults, cases, append);
	}


	private static void updateReporterCSVOutput(String csvFolderName, Map<FieldName, Map<String, Set<String>>> allCsvResults, 
			Set<String> cases,boolean append)
	{
		String delimiter= ",";
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(csvFolderName+File.separator+"case-reporter.csv",append);
			fileWriter.append("CASENUMBER"+delimiter+FieldName.REPORTER_TYPE+delimiter+FieldName.OCCUPATION+"\n");
			Map<String, Set<String>> allResults1=allCsvResults.get(FieldName.REPORTER_TYPE);
			System.out.println("Total  Reporter ::"+cases.size());
			for(String caseID :cases)
			{
				Set<String> results1 = allResults1.containsKey(caseID) ? allResults1.get(caseID) : new HashSet<String>();
				if(results1.size()==0)
				{
					fileWriter.append(caseID+delimiter+"Consumer or other non HCP"+delimiter+"NA"+"\n");
				}
				else 
				{
					for(String reporter : results1)
					{
						String normalReporter= normalize? ReporterNormalization.normalizeReporter(reporter) : new String(reporter);
						String occupation="NA";
						if(normalReporter.equalsIgnoreCase("Physician"))
							occupation="Physician";
						if(normalReporter.equalsIgnoreCase("Pharmacist"))
							occupation="Pharmacist";
						if(normalReporter.equalsIgnoreCase("Other HCP "))
							occupation=reporter;
						if(normalReporter.isEmpty())
							normalReporter="Consumer or other non HCP";
						fileWriter.append(caseID+delimiter+normalReporter+delimiter+occupation+"\n");
					}
				}
				fileWriter.flush();
			}
			System.out.println("Final CSV written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}


	private static void updatePatientCSVOutput(String csvFolderName, Map<FieldName, Map<String, Set<String>>> allCsvResults, 
			Set<String> cases,boolean append)
	{
		String delimiter= ",";
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(csvFolderName+File.separator+"case-patient.csv",append);
			fileWriter.append("CASENUMBER"+delimiter+FieldName.PAT_INITIALS+delimiter+FieldName.PAT_DOB_PARTIAL+delimiter+FieldName.PAT_AGE_UNIT+delimiter+FieldName.GENDER+"\n");
			Map<String, Set<String>> patientResults=allCsvResults.get(FieldName.PAT_INITIALS);
			Map<String, Set<String>> DOBResults=allCsvResults.get(FieldName.PAT_DOB_PARTIAL);
			Map<String, Set<String>> ageResults=allCsvResults.get(FieldName.PAT_AGE_UNIT);
			Map<String, Set<String>> GenderResults=allCsvResults.get(FieldName.GENDER);
			for(String caseID : cases)
			{
				List<String> patients = patientResults.containsKey(caseID)? new ArrayList<String>(patientResults.get(caseID)) : new ArrayList<String>();
				List<String> DOBs =  DOBResults.containsKey(caseID) ? new ArrayList<String>(DOBResults.get(caseID)): new ArrayList<String>();
				List<String> ages =  ageResults.containsKey(caseID)? new ArrayList<String>(ageResults.get(caseID)): new ArrayList<String>();
				List<String> genders =   GenderResults.containsKey(caseID)? new ArrayList<String>(GenderResults.get(caseID)): new ArrayList<String>();
				TreeMap<Integer, FieldName> size= new TreeMap<Integer, FieldName>();
				size.put(patients.size(), FieldName.PAT_INITIALS);
				size.put(DOBs.size(), FieldName.PAT_DOB_PARTIAL);
				size.put(ages.size(), FieldName.PAT_AGE_UNIT);
				size.put(genders.size(), FieldName.GENDER);
				int maxSize= size.lastKey();
				for(int i=0 ; i<maxSize ; i++)
				{
					String patient= patients.size()>0 ? (patients.size()>i ? patients.get(i): "") : "Unknown";
					String DOB =DOBs.size()>0 ? (DOBs.size()>i ? DOBs.get(i): "") : "";
					if(!DOB.isEmpty())
						DOB=MatchTypeCategorization.getLongDate1(DOB);
					String age = ages.size()>0 ? (ages.size()>i ? ages.get(i): "") : "";
					String gender = genders.size()>0 ? (genders.size()>i ? genders.get(i): "") : "";
					if(normalize)
					{
						if(age.contains("-"))
						{
							List<Integer> pairs =ConceptCleanup.getAgePair(age);
							int minValue =pairs.get(0);
							int maxValue =pairs.get(1);
							int average = ((minValue+maxValue)/2);
							age=average+" Years";							
						}
						else 
						{
							Pattern pattern = Pattern.compile("[0-9]+");
							Matcher m = pattern.matcher(age);
							if(m.find())
							{
								age=m.group(0)+" Years";
							}

						}
						if(gender.equalsIgnoreCase("M"))
							gender="Male";
						else if (gender.equalsIgnoreCase("F"))
							gender="Female";
						if(!gender.equalsIgnoreCase("Male") && !gender.equalsIgnoreCase("Female"))
							gender ="";
						if(age.toLowerCase().contains("unknown"))
							age="";
					}
					fileWriter.append(caseID+delimiter+patient+delimiter+DOB+delimiter+age+delimiter+gender+"\n");
				}
				fileWriter.flush();
			}
			System.out.println("Final CSV written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}


	private static void updateEventCSVOutput(String csvFolderName, Map<FieldName, Map<String, Set<String>>> allCsvResults,boolean append)
	{
		String delimiter= ",";
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(csvFolderName+File.separator+"case-event.csv",append);
			fileWriter.append("CASENUMBER"+delimiter+FieldName.AE_VERBATIM+delimiter+FieldName.AE_LLT+delimiter+"AE_VERBATIM_SENTENCE\n");
			Map<String, Set<String>> allResults1=allCsvResults.get(FieldName.AE_VERBATIM);
			Map<String, Set<String>> allResults2=allCsvResults.get(FieldName.AE_LLT);
			Map<String, Set<String>> allResults3=allCsvResults.get(FieldName.AE_VERBATIM_SENTENCE);
			System.out.println("Total AE_VERBATIM ::"+allResults1.size());
			System.out.println("Total AE_LLT ::"+allResults2.size());
			for(String caseID : allResults1.keySet())
			{
				List<String> results1 = allResults1.containsKey(caseID) ? new ArrayList<String>(allResults1.get(caseID)) : new ArrayList<String>();
				List<String> results2 = allResults2.containsKey(caseID) ? new ArrayList<String>(allResults2.get(caseID)) : new ArrayList<String>();
				List<String> results3 = allResults3.containsKey(caseID) ? new ArrayList<String>(allResults3.get(caseID)) : new ArrayList<String>();
				TreeSet<Integer> sizes= new TreeSet<Integer>();
				sizes.add(results1.size());
				sizes.add(results2.size());
				sizes.add(results3.size());
				int maxSize = sizes.last();
				for(int i=0 ; i<maxSize ; i++)
				{
					String result1= results1.size()>0 ? (results1.size()>i ? results1.get(i): "") : "";
					String result2= results2.size()>0 ? (results2.size()>i ? results2.get(i): "") : "";
					String result3= results3.size()>0 ? (results3.size()>i ? results3.get(i): result1) : result1;
					fileWriter.append(caseID+delimiter+result1+delimiter+result2+delimiter+result3+"\n");
				}
				fileWriter.flush();
			}
			System.out.println("Final CSV written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}

	private static void updateProductCSVOutput(String csvFolderName, Map<FieldName,Map<String, Set<String>>> allCsvResult,boolean append)
	{
		String delimiter= ",";
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter(csvFolderName+File.separator+"case-product.csv",append);
			fileWriter.append("CASENUMBER"+delimiter+FieldName.TRADE_NAME+delimiter+FieldName.GENERIC_NAME+delimiter+"SUSPECT_CONMED_FLAG\n");
			Map<String, Set<String>> tradeResults=allCsvResult.get(FieldName.TRADE_NAME);
			Map<String, Set<String>> genericNames= allCsvResult.containsKey(FieldName.GENERIC_NAME ) ? allCsvResult.get(FieldName.GENERIC_NAME) : new HashMap<String, Set<String>>();
			System.out.println("Total Trade Names ::"+tradeResults.size());
			System.out.println("Total Generic Names ::"+genericNames.size());
			for(String caseID : tradeResults.keySet())
			{
				List<String> results1 =tradeResults.containsKey(caseID) ? new ArrayList<String>(tradeResults.get(caseID)): new ArrayList<String>();
				List<String> results2 = genericNames.containsKey(caseID)? new ArrayList<String>(genericNames.get(caseID)) : new ArrayList<String>();
				int maxSize = results1.size()>results2.size()?results1.size() : results2.size();
				for(int i=0 ; i<maxSize ; i++)
				{
					String result1= results1.size()>0 ? (results1.size()>i ? results1.get(i): "") : "";
					String result2= results2.size()>0 ? (results2.size()>i ? results2.get(i): "") : "";
					String resultflag="";
					if(result2.endsWith("_concomitant"))
					{
						resultflag="Concomitant";
						result2=result2.replace("_concomitant", "");
					}
					else if(result2.endsWith("_suspect"))
					{
						resultflag="Suspect";
						result2=result2.replace("_suspect", "");
					}
					if(result1.endsWith("_concomitant"))
					{
						if(resultflag.isEmpty())
							resultflag="Concomitant";
						result1=result1.replace("_concomitant", "");
					}
					else if(result1.endsWith("_suspect"))
					{
						if(resultflag.isEmpty())
							resultflag="Suspect";
						result1=result1.replace("_suspect", "");
					}
					fileWriter.append(caseID+delimiter+result1+delimiter+result2+delimiter+resultflag+"\n");
				}
				fileWriter.flush();
			}
			System.out.println("Final CSV written successfully..");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
	}
}
