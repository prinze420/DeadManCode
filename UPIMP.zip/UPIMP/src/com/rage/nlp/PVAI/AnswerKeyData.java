package com.rage.nlp.PVAI;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AnswerKeyData
{
	private static String					caseAEsFilename	= "AnswerFiles_txt/case-aeAll.txt";
	private static String					caseDNsFilename	= "AnswerFiles_txt/case-dnAll.txt";

	private static Map<String, Set<Triplet<String, String, String>>> AEResults;
	private static Map<String, Set<Triplet<String, String, String>>> DrugResults;

	public static Set<String> getAdverseEvents(String caseID , String columnIndex)
	{		
		if(AEResults==null)
		{
			AEResults=populateAnswerData(caseAEsFilename, "\t", columnIndex);
		}
		Set<Triplet<String, String, String>> triplets = AEResults.containsKey(caseID) ? AEResults.get(caseID) : new HashSet<Triplet<String,String,String>>(); 
		Set<String> answer = new HashSet<String>();
		for(Triplet<String, String, String> triplet : triplets)
		{
			if(!triplet.getValue1().isEmpty())
				answer.add(triplet.getValue1());
			if(!triplet.getValue2().isEmpty())
				answer.add(triplet.getValue2());
			if(!triplet.getValue3().isEmpty())
				answer.add(triplet.getValue3());
		}
		return answer;
	}

	public static Set<String> getDrugNames(String caseID, String columnIndex)
	{
		if(DrugResults==null)
		{
			DrugResults=populateAnswerData(caseDNsFilename, "\t", columnIndex);
		}
		Set<Triplet<String, String, String>> triplets = DrugResults.containsKey(caseID) ? DrugResults.get(caseID) : new HashSet<Triplet<String,String,String>>(); 
		Set<String> answer = new HashSet<String>();
		for(Triplet<String, String, String> triplet : triplets)
		{
			if(!triplet.getValue1().isEmpty())
				answer.add(triplet.getValue1());
			if(!triplet.getValue2().isEmpty())
				answer.add(triplet.getValue2());
			if(!triplet.getValue3().isEmpty())
				answer.add(triplet.getValue3());
		}
		return answer;
	}



	public static Map<String, Set<Triplet<String, String, String>>> populateAnswerData(String fileName, String delimiter, String indexStr)
	{
		HashMap<String, Set<Triplet<String, String, String>>> ret= new HashMap<String, Set<Triplet<String, String, String>>>();
		List<List<String>> lines= FileReader.readFile(fileName, delimiter);
		List<String> indexes=Arrays.asList(indexStr.split(","));
		for(int i=0; i<lines.size() ; i++)
		{
			List<String> values=lines.get(i);
			String caseID="";
			Triplet<String, String, String> ae_triplet=null;
			String v1,v2,v3="";

			if(indexes.size()==4 && values.size()>=4)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				v1 = values.get(Integer.parseInt(indexes.get(1)));
				v2 = values.get(Integer.parseInt(indexes.get(2)));
				v3 = values.get(Integer.parseInt(indexes.get(3)));
			}
			else if(indexes.size()==3 && values.size()>=3)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				v1 = values.get(Integer.parseInt(indexes.get(1)));
				v2 = values.get(Integer.parseInt(indexes.get(2)));
				v3 = "";
			}
			else if(indexes.size()==2 && values.size()>=2)
			{
				caseID = values.get(Integer.parseInt(indexes.get(0))).trim();
				v1 = values.get(Integer.parseInt(indexes.get(1)));
				v2 = "";
				v3 = "";
			}
			else if(values.size()==2)
			{
				caseID = values.get(0).trim();
				v1 = values.get(1);
				v2 = "";
				v3 = "";
			}
			else
			{
				continue;
			}
			v1=FileReader.applyAsciiFilter(v1);
			v2=v2.replaceAll("\\s+", " ").trim();
			v3=v3.replaceAll("\\s+", " ").trim();
			if(v1.isEmpty() && v2.isEmpty() && v3.isEmpty())
				continue;
			
			ae_triplet= new Triplet<String, String, String>(v1, v2, v3);
			Set<Triplet<String, String, String>> triplets =ret.containsKey(caseID) ? ret.get(caseID) : new HashSet<Triplet<String,String,String>>();
			triplets.add(ae_triplet);
			ret.put(caseID, triplets);
		}		
		return ret;
	}
}

