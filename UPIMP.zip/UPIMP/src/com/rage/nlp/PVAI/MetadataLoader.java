package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class MetadataLoader
{
	public static String ParaPatterns_file = "resource/ParaPatterns.txt" ;
	public static String FiltersKWs_file = "resource/Keywords.txt" ;
	public static String Mapping_file = "resource/FieldMapping.txt";
	public static Map<Feature, Map<String, Integer>> linguisticPatterns;
	public static Map<Feature, Set<String>> paraPatterns;
	public static Map<String,FieldName> fieldMapping;
	public static Set<String> filtersKWs;

	public static Map<Feature, Map<String, Integer>> getLingusiticPatterns(String type)
	{
		if(linguisticPatterns==null)
			loadLinguisticPatternsFromFile(type);

		return linguisticPatterns;
	}
	
	public static Map<Feature, Set<String>> getParaPatterns()
	{
		if(paraPatterns==null)
			loadParaPatternsFromFile();

		return paraPatterns;
	}
	
	
	private static void loadParaPatternsFromFile()
	{
		paraPatterns= new HashMap<Feature, Set<String>>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(ParaPatterns_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;

				if (!line.startsWith("#"))
				{
					List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
					Feature feature = Feature.valueOf(split.get(0));
					Set<String> patterns= paraPatterns.containsKey(feature)? paraPatterns.get(feature) : new LinkedHashSet<String>();
					patterns.add(split.get(1));
					paraPatterns.put(feature, patterns);
				}
				
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + ParaPatterns_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}		
	}

	public static FieldName getFieldMapping(String extraction)
	{
		if(fieldMapping==null)
			loadFieldMapping();

		return fieldMapping.containsKey(extraction) ? fieldMapping.get(extraction): FieldName.NONE ;
	}

	private static void loadFieldMapping()
	{
		fieldMapping= new HashMap<String, FieldName>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(Mapping_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;

				if (!line.startsWith("#"))
				{
					List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
					String extraction =split.get(0).toLowerCase().trim();
					String field =split.get(1).trim();
					FieldName fieldName = FieldName.valueOf(field);
					fieldMapping.put(extraction, fieldName);							
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + Mapping_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		
	}

	public static Set<String> getFilterKeywords()
	{
		if(filtersKWs==null)
			loadKeywordsFromFile();
		return filtersKWs;
	}

	private static void loadKeywordsFromFile()
	{
		filtersKWs= new HashSet<String>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(FiltersKWs_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;

				if (!line.startsWith("#"))
					filtersKWs.add(line.toLowerCase());
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + FiltersKWs_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
	}

	private static void loadLinguisticPatternsFromFile(String type)
	{
		linguisticPatterns= new HashMap<Feature, Map<String,Integer>>();
		BufferedReader br = null ;
		String Patterns_file = type.equalsIgnoreCase("NLP") ? "resource/LinguisticPatterns.txt" : "resource/LinguisticPatternsLemma.txt";
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(Patterns_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;

				if (type.equalsIgnoreCase("NLP") &&!line.startsWith("#"))
				{
					List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
					Feature feature = Feature.valueOf(split.get(0));
					Map<String,Integer> regexMap= linguisticPatterns.containsKey(feature) ? linguisticPatterns.get(feature) : new LinkedHashMap<String, Integer>();
					regexMap.put(split.get(1), Integer.parseInt(split.get(2)));
					linguisticPatterns.put(feature, regexMap);
				}
				else if (!type.equalsIgnoreCase("NLP"))
				{
					line=line.replaceFirst("#", "");
					List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
					Feature feature = Feature.valueOf(split.get(0));
					Map<String,Integer> regexMap= linguisticPatterns.containsKey(feature) ? linguisticPatterns.get(feature) : new LinkedHashMap<String, Integer>();
					regexMap.put(split.get(1), Integer.parseInt(split.get(2)));
					linguisticPatterns.put(feature, regexMap);
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + Patterns_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
	}

	public static List<List<String>> readFile(File fileName, String delimiter)
	{
		List<List<String>> ret = new ArrayList<List<String>>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(fileName)))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.isEmpty())
					continue ;

				List<String> split = new ArrayList<String>(Arrays.asList(line.split(delimiter))) ;
				ret.add(split) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret;
	}


}
