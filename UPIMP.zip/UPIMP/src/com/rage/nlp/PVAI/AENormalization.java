package com.rage.nlp.PVAI;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AENormalization
{
	public static Map<String,Set<String>> normalizedAEMap=new HashMap<String, Set<String>>();
	public static Map<String,Set<String>> normalizedAEReverseMap=new HashMap<String, Set<String>>();
	public static boolean DEBUG =false;

	public static Pair<String> findNormalizedAE(String concept)
	{
		long start = System.nanoTime();
		String actualConcept= new String(concept);
		concept = ConceptCleanup.refineConcept(concept);
		if(concept.isEmpty())
			return new Pair<String>(actualConcept, "");
		String lemmatizedConcept = ConceptCleanup.createLemmatizedConcept(concept);
		Set<String> conceptList = new LinkedHashSet<String>(Arrays.asList(lemmatizedConcept.split(" ")));
		Set<String> normalizedConcepts = normalizedAEMap.containsKey(lemmatizedConcept) ? normalizedAEMap.get(lemmatizedConcept) : new HashSet<String>();
		Set<String> actualConcepts = normalizedAEReverseMap.containsKey(lemmatizedConcept)  ? normalizedAEReverseMap.get(lemmatizedConcept) : new HashSet<String>();
		if(normalizedConcepts.size()==0)
		{
			normalizedConcepts = MeddraOntology.getMeddraOntology().containsKey(conceptList) ? MeddraOntology.getMeddraOntology().get(conceptList) : normalizedConcepts;
			actualConcepts = MeddraOntology.getMeddraReverseOntology().containsKey(conceptList) ? MeddraOntology.getMeddraReverseOntology().get(conceptList) : actualConcepts;
			if(normalizedConcepts.size()==0)
			{
				long startAE=System.nanoTime();
				Set<String> bestPartialMatch = checkBestPartialMatch(MeddraOntology.getMeddraOntology().keySet(), lemmatizedConcept);
				long endAE = System.nanoTime();
				System.out.println("TOTAL TIME TAKEN PARTIAL MATCH:::\t"+((endAE-startAE)/1000000) + " miliseconds");
				if(!bestPartialMatch.isEmpty())
				{
					normalizedConcepts=MeddraOntology.getMeddraOntology().get(bestPartialMatch);
					actualConcepts=MeddraOntology.getMeddraReverseOntology().get(bestPartialMatch);
					if(DEBUG)
						System.out.println("Found Partial Match ::\t"+actualConcept+"\t"+bestPartialMatch+normalizedConcepts+"\t"+conceptList);
				}
			}
		}
		if(normalizedConcepts.size()>0)
		{
			String LLT=normalizedConcepts.toString().replaceAll("\\[|\\]", "").replaceAll(",", " # ").replaceAll("\\s+", " ");
			normalizedAEMap.put(lemmatizedConcept, normalizedConcepts);
			
			String normalizerdAE=actualConcepts.toString().replaceAll("\\[|\\]", "").replaceAll(",", " # ").replaceAll("\\s+", " ");
			normalizedAEReverseMap.put(lemmatizedConcept, actualConcepts);
			long end = System.nanoTime();
			System.out.println("TOTAL TIME TAKEN AE NORMALIZATION:::\t"+((end-start)/1000000)+ " miliseconds");
			return new Pair<String>(normalizerdAE, LLT);
		}
		long end = System.nanoTime();
		System.out.println("TOTAL TIME TAKEN AE NORMALIZATION:::\t"+(end-start));
		return new Pair<String>(actualConcept, "");
	}

	private static Set<String> checkBestPartialMatch(Set<Set<String>> set , String concept)
	{
		int maxLength=0;
		double maxSim =0.0d;
		Set<String> finalMatch = new LinkedHashSet<String>();
		List<String> conceptList =  Arrays.asList(concept.toLowerCase().split(" "));
		for (Set<String> listStr :set)
		{
			HashSet<String> one = new HashSet<String>(conceptList);
			HashSet<String> two = new HashSet<String>(listStr);				
			int length1=two.size();	
			two.retainAll(one) ;
			int commonSize = two.size() ;
			int length=listStr.toString().length();
			if(commonSize>0)
			{
				double sim = (double) commonSize / (double) length1 ;
				if(sim>maxSim)
				{
					maxLength=length;
					finalMatch = listStr;
					maxSim=sim;
				}
				else if(sim==maxSim)
				{
					if(DEBUG)
						System.out.println("Matches ::"+listStr+"\t"+MeddraOntology.getMeddraOntology().get(listStr));
					if(length>maxLength)
					{
						maxLength=length;
						finalMatch = listStr;
						maxSim=sim;
					}
				}

			}
		}	
		return finalMatch;
	}
	public static void main(String[] args)
	{
		String AE = "My Name Is April And I Am A Chap-stick-a-holic. " +
				"They Are Everywhere. Its Time To Buy Another Box From Sams Though Because They Are All Empty." +
				" Nothing Works Like Chap-stick. I Tried Others. :) I";
		AE="Have To Put On Every Nite.cant Sleep Without It. I Am Addicted To It";
		AE="Is There A Chapstick Without Spf?? Cuz I'm Allergic To The Ones That Do Have It.";
		System.out.println(findNormalizedAE(AE));
	}

}
