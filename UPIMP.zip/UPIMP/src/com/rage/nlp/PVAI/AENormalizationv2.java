package com.rage.nlp.PVAI;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AENormalizationv2
{
	public static Map<String,Set<String>> normalizedAEMap=null;
	public static Map<String,Set<String>> normalizedAEReverseMap=null;
	public static Map<String,String> lemmatizedMap=new HashMap<String, String>();
	public static boolean DEBUG =false;

	public static Pair<String> findNormalizedAE(String concept)
	{
		if(normalizedAEMap==null)
		{
			normalizedAEMap= new HashMap<String, Set<String>>();
			normalizedAEReverseMap= new HashMap<String, Set<String>>();
		}
		long start = System.nanoTime();
		String actualConcept= new String(concept);
		concept = ConceptCleanup.refineConcept(concept);
		if(concept.isEmpty())
			return new Pair<String>(actualConcept, "");
		String lemmatizedConcept = ConceptCleanup.createLemmatizedConcept(concept);
		Set<String> normalizedConcepts = normalizedAEMap.containsKey(lemmatizedConcept) ? normalizedAEMap.get(lemmatizedConcept) : new HashSet<String>();
		Set<String> actualConcepts = normalizedAEReverseMap.containsKey(lemmatizedConcept)  ? normalizedAEReverseMap.get(lemmatizedConcept) : new HashSet<String>();
		if(normalizedConcepts.size()==0)
		{
			normalizedConcepts = StringMeddraOntology.getMeddraOntology().containsKey(lemmatizedConcept) ? StringMeddraOntology.getMeddraOntology().get(lemmatizedConcept) : normalizedConcepts;
			actualConcepts = StringMeddraOntology.getMeddraReverseOntology().containsKey(lemmatizedConcept) ? StringMeddraOntology.getMeddraReverseOntology().get(lemmatizedConcept) : actualConcepts;
			if(normalizedConcepts.size()==0)
			{
				long startAE=System.nanoTime();
				String bestPartialMatch = checkBestPartialMatch(StringMeddraOntology.getMeddraOntology().keySet(), lemmatizedConcept, actualConcept);
				long endAE = System.nanoTime();
				System.out.println("TOTAL TIME TAKEN PARTIAL MATCH:::\t"+((endAE-startAE)/1000000) + " miliseconds");
				if(!bestPartialMatch.isEmpty())
				{
					normalizedConcepts=StringMeddraOntology.getMeddraOntology().get(bestPartialMatch);
					actualConcepts=StringMeddraOntology.getMeddraReverseOntology().get(bestPartialMatch);
					if(DEBUG)
						System.out.println("Found Partial Match ::\t"+actualConcept+"\t"+bestPartialMatch+"\t"+normalizedConcepts+"\t"+lemmatizedConcept);
				}
			}
		}
		if(normalizedConcepts.size()>0)
		{
			String LLT=normalizedConcepts.toString().replaceAll("\\[|\\]", "").replaceAll(",", " # ").replaceAll("\\s+", " ");
			normalizedAEMap.put(lemmatizedConcept, normalizedConcepts);

			String normalizerdAE=actualConcepts.toString().replaceAll("\\[|\\]", "").replaceAll(",", " # ").replaceAll("\\s+", " ");
			normalizedAEReverseMap.put(lemmatizedConcept, actualConcepts);

			long end = System.nanoTime();
			System.out.println("TOTAL TIME TAKEN AE NORMALIZATION:::\t"+((end-start)/1000000)+ " miliseconds");
			return new Pair<String>(normalizerdAE, LLT);
		}
		return new Pair<String>(actualConcept, "");
	}

	private static String checkBestPartialMatch(Set<String> set, String concept, String actualConcept)
	{
		boolean maxCandidate=false;
		int truemaxLength=0;
		int maxLength=0;
		double maxSim =0.0d;
		String finalMatch ="";
		List<String> conceptList =  Arrays.asList(concept.toLowerCase().split(" "));
		for (String listStr :set)
		{
			HashSet<String> one = new HashSet<String>(conceptList);
			HashSet<String> two = new HashSet<String>( Arrays.asList(listStr.toLowerCase().split(" ")));				
			int length1=two.size();	
			two.retainAll(one) ;
			int commonSize = two.size() ;
			int length=listStr.toString().length();
			if(commonSize>0)
			{
				boolean isCandidate=false;				
				Set<String> reverseConcepts=StringMeddraOntology.getMeddraReverseOntology().get(listStr);
				for(String reverseConcept: reverseConcepts)
				{
					String reverseConcept1=lemmatizedMap.containsKey(reverseConcept) ? lemmatizedMap.get(reverseConcept) : "";
					if(reverseConcept1.isEmpty())
					{
						reverseConcept1 = ConceptCleanup.refineConcept(reverseConcept);
						reverseConcept1 = ConceptCleanup.createLemmatizedConcept(reverseConcept1);
						if(reverseConcept1.isEmpty())
							continue;
						lemmatizedMap.put(reverseConcept, reverseConcept1);
					}
					if(concept.contains(reverseConcept1))
					{
						isCandidate=true;
						break;
					}
				}
				if(isCandidate)
					System.out.println("Partial Candidate::"+listStr);
				double sim = (double) commonSize / (double) length1 ;
				if(isCandidate && !maxCandidate)
				{
					maxCandidate=isCandidate;
					truemaxLength=length;
					finalMatch = listStr;
				}
				else if(isCandidate && maxCandidate)
				{
					if(length>truemaxLength)
					{
						truemaxLength=length;
						finalMatch = listStr;
					}
				}
				else if(sim>maxSim && !maxCandidate)
				{
					maxCandidate=isCandidate;
					maxLength=length;
					finalMatch = listStr;
					maxSim=sim;
				}
				else if(sim==maxSim && !maxCandidate)
				{
					maxCandidate=isCandidate;
					if(length>maxLength)
					{
						maxLength=length;
						finalMatch = listStr;
						maxSim=sim;
					}
				}
			}
		}	
		return finalMatch;
	}
	public static void main(String[] args)
	{
		String AE = "";
		AE="Love these . I had a lap band put on a year ago and I started to lose insane amounts of hair (I have plenty to spare). My nurse suggested I try these because they don't take up room in my small stomach pouch and they actually taste very good. I know when I forgot to take mine because I start getting wads of hair all around me like a shedding dog!";
		System.out.println(findNormalizedAE(AE));
	}

}
