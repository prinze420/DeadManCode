package com.rage.nlp.PVAI;

public enum Feature
{
	PatientName,
	AdverseEvent,
	DrugName
}
