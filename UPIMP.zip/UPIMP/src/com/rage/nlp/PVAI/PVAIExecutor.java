package com.rage.nlp.PVAI;

import java.io.FileWriter;
import java.io.IOException;
import java.util.LinkedHashSet;

public class PVAIExecutor
{

	public static void main(String[] args)
	{

		int pageIndex=0;
		int paraIndex=1;
		String nlpResultsFile ="C:\\Users\\ig0e572\\Desktop\\output\\NLPResults.txt";
		String outputFileNamePara ="C:\\Users\\ig0e572\\Desktop\\output\\NLPParas.txt";
		String inputFilePath = "C:\\Users\\ig0e572\\Desktop\\output\\para";
		FeatureExtractor.execute(pageIndex, paraIndex, nlpResultsFile, outputFileNamePara, inputFilePath,"ExtractionParaKey");
		String extractionResultsFile ="C:\\Users\\ig0e572\\Desktop\\output\\output.txt";
		String outputFileName = "C:\\Users\\ig0e572\\Desktop\\output\\EliLilly_results.xls";
		ConsolidationAndScoringv1.populateInitails=true;
		ConsolidationAndScoringv1.isTrain=true;
		String scoringFolderName="C:\\Users\\ig0e572\\Desktop\\output\\Scoring";
		String fields="TRADE_NAME";
		String csvFolderName="C:\\Users\\ig0e572\\Desktop\\output\\csv";
		ConsolidationAndScoringv1.doAENoralization=false;
		ConsolidationAndScoringv1.execute(nlpResultsFile, extractionResultsFile, outputFileName, inputFilePath, scoringFolderName, fields, csvFolderName);

	
		/*FeatureExtractor.DEBUG=true;
		FeatureExtractor.extractFeatures("She reports she ate dinner late on Thursday, 21Aug2014, and Friday, 22Aug2014 and there may be a lot of factors that caused her blood sugar to be high.", "Extraction");
		 */
		
		/*String content=FileReader.readFileContent("C:\\Users\\ig0e572\\Desktop\\EliLilly_Literature\\Literature_1.txt");
		FeatureExtractor.DEBUG=true;
		FileWriter fileWriter=null;
		try
		{
			fileWriter=new FileWriter("C:\\Users\\ig0e572\\Desktop\\EliLilly_Literature\\Literature_1_results.txt");
			fileWriter.append("Case No\tPageNo\tParagraph\tPatient Initials\tAE Verbatim\tTrade Name\n");
			FeatureExtractor.extractParaFeatures(content, fileWriter, "Extraction", "Literature_2", new LinkedHashSet<String>(), -1, "-1");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
*/
	}

}
