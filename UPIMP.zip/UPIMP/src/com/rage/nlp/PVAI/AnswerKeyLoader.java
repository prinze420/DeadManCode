package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class AnswerKeyLoader
{

	public static String Mapping_file = "resource/AnswerFieldMapping.txt";
	private static Map<FieldName,Map<String, Set<Triplet<String, String, String>>>> answerKeys;
	public static Map<FieldName, String> fieldFileMap;


	public static Set<String> getAnswer(FieldName fieldName , String caseID)
	{		
		if(answerKeys==null)
		{
			populateAnswerKeys();
		}
		Map<String, Set<Triplet<String, String, String>>> thisResults=answerKeys.containsKey(fieldName)?answerKeys.get(fieldName) : new HashMap<String, Set<Triplet<String,String,String>>>();
		Set<Triplet<String, String, String>> triplets = thisResults.containsKey(caseID) ? thisResults.get(caseID) : new HashSet<Triplet<String,String,String>>(); 
		Set<String> answer = new HashSet<String>();
		for(Triplet<String, String, String> triplet : triplets)
		{
			if(triplet.getValue1().toLowerCase().startsWith("no ") 
					|| triplet.getValue2().toLowerCase().startsWith("no ")
					|| triplet.getValue3().toLowerCase().startsWith("no ") || triplet.getValue1().equalsIgnoreCase("-1"))
				continue;
			
			if(!triplet.getValue1().isEmpty())
				answer.add(triplet.getValue1());
			if(!triplet.getValue2().isEmpty())
				answer.add(triplet.getValue2());
			if(!triplet.getValue3().isEmpty())
				answer.add(triplet.getValue3());
		
		}
		return answer;
	}
	
	public static Set<String> getAnswerValue1(FieldName fieldName , String caseID)
	{		
		if(answerKeys==null)
		{
			populateAnswerKeys();
		}
		Map<String, Set<Triplet<String, String, String>>> thisResults=answerKeys.containsKey(fieldName)?answerKeys.get(fieldName) : new HashMap<String, Set<Triplet<String,String,String>>>();
		Set<Triplet<String, String, String>> triplets = thisResults.containsKey(caseID) ? thisResults.get(caseID) : new HashSet<Triplet<String,String,String>>(); 
		Set<String> answer = new HashSet<String>();
		for(Triplet<String, String, String> triplet : triplets)
		{
			if(!triplet.getValue1().isEmpty())
				answer.add(triplet.getValue1());
		}
		return answer;
	}
	
	public static Set<Triplet<String, String, String>> getAnswerTriplet(FieldName fieldName , String caseID)
	{		
		Set<Triplet<String, String, String>> ret= new HashSet<Triplet<String,String,String>>();
		if(answerKeys==null)
		{
			populateAnswerKeys();
		}
		Map<String, Set<Triplet<String, String, String>>> thisResults=answerKeys.containsKey(fieldName)?answerKeys.get(fieldName) : new HashMap<String, Set<Triplet<String,String,String>>>();
		Set<Triplet<String, String, String>> triplets = thisResults.containsKey(caseID) ? thisResults.get(caseID) : new HashSet<Triplet<String,String,String>>(); 
		for(Triplet<String, String, String> triplet : triplets)
		{
			if(triplet.getValue1().toLowerCase().startsWith("no ") 
					|| triplet.getValue2().toLowerCase().startsWith("no ")
					|| triplet.getValue3().toLowerCase().startsWith("no ") || triplet.getValue1().equalsIgnoreCase("-1"))
				continue;
			String v1 = !triplet.getValue1().isEmpty() ? triplet.getValue1().trim().replaceAll(",", " # "): "";
			String v2 =!triplet.getValue2().isEmpty() ? triplet.getValue2().trim().replaceAll(",", " # "): "";
			String v3 = !triplet.getValue3().isEmpty() ? triplet.getValue3().trim().replaceAll(",", " # "): "";
			Triplet<String, String, String> newTriplet= new Triplet<String, String, String>(v1, v2, v3);
			ret.add(newTriplet);
		}
		return ret;
	}

	private static void loadFieldMapping()
	{
		fieldFileMap= new HashMap<FieldName, String>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(Mapping_file))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;

				if (!line.startsWith("#"))
				{
					List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
					String fileName =split.get(1);
					String field =split.get(0).trim();
					FieldName fieldName = FieldName.valueOf(field);
					fieldFileMap.put(fieldName,fileName);							
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + Mapping_file + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}
		
	}


	private static void populateAnswerKeys()
	{
		if(fieldFileMap==null)
			loadFieldMapping();
		answerKeys = new HashMap<FieldName, Map<String,Set<Triplet<String,String,String>>>>();
		for(FieldName fieldName : fieldFileMap.keySet())
		{
			String fileName = fieldFileMap.get(fieldName);
			String indexStr="0,1";
			if(fieldName.equals(FieldName.TRADE_NAME))
			{
				indexStr="0,1,2";
			}
			else if(fieldName.equals(FieldName.AE_VERBATIM))
			{
				indexStr="0,1,2,3";	;
			}
			else if (fieldName.equals(FieldName.AE_LLT))
			{
				indexStr="0,2,3";
			}
			else if(fieldName.equals(FieldName.GENERIC_NAME))
			{
				indexStr="0,2";
			}
			Map<String, Set<Triplet<String, String, String>>> thisResults=AnswerKeyData.populateAnswerData(fileName, "\t", indexStr);
			answerKeys.put(fieldName, thisResults);
			System.out.println("ADDED Answer Key ::"+fieldName+"\t"+thisResults.size());
		}
	}

}
