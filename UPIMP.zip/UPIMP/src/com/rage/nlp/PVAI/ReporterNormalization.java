package com.rage.nlp.PVAI;


public class ReporterNormalization
{

	public static String normalizeReporter(String reporter)
	{
		String normalReporter="";
		if(reporter.toLowerCase().contains("company representative"))
			normalReporter="Company Representative";
		else if(reporter.toLowerCase().contains("lawyer"))
			normalReporter="Lawyer";
		else if(reporter.toLowerCase().contains("pharmacist"))
		normalReporter="Pharmacist";
		else if(reporter.toLowerCase().contains("physician"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("(doctor"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("dentist"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("hcp") && !reporter.toLowerCase().contains("other"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("hcp") && reporter.toLowerCase().contains("other"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("health professional") && reporter.toLowerCase().contains("other"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("nurse"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("coroner"))
			normalReporter="Other HCP";
		else if(reporter.toLowerCase().contains("consumer or other non hcp "))
			normalReporter="Consumer or other non HCP";
		else if(reporter.toLowerCase().contains("consumer or other non-health professional"))
			normalReporter="Consumer or other non HCP";
		else if(reporter.toLowerCase().contains("consumer or other"))
			normalReporter="Consumer or other non HCP";
		else if(reporter.toLowerCase().contains("non-health professional"))
			normalReporter="Consumer or other non HCP";
		return normalReporter;
	}
}
