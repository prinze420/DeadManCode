package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class StringMeddraOntology
{

	public static String Meddra_file = "resource/MeddraOntologyNew.txt";
	public static String Meddra_map = "resource/MeddraMapString/meddraTokenOnto.map";
	public static String ReverseMeddra_map = "resource/MeddraMapString/reverseMeddraTokenOnto.map";
	public static Map<String,Set<String>> meddraMap;
	public static Map<String,Set<String>> meddraReverseMap;

	public static Map<String,Set<String>> getMeddraOntology()
	{
		if(meddraMap==null)
		{ 
			meddraMap=deserializeMap(Meddra_map);
			if(meddraMap==null)
			{
				meddraMap= new HashMap<String, Set<String>>();
				meddraReverseMap=new HashMap<String, Set<String>>();
				readOntology(Meddra_file);
				serializeMap(Meddra_map, meddraMap);
				serializeMap(ReverseMeddra_map , meddraReverseMap);
			}
		}
		return meddraMap;
	}

	public static Map<String,Set<String>> getMeddraReverseOntology()
	{
		if(meddraReverseMap==null)
		{
			meddraReverseMap= deserializeMap(ReverseMeddra_map);
		}
		return meddraReverseMap;
	}

	@SuppressWarnings("unchecked")
	public static Map<String,Set<String>> deserializeMap(String fileName)
	{
		if (!new File(fileName).exists() )
		{
			System.out.println("MEDDRA DOESN'T EXIST : " + fileName) ;
			return null;
		}
		else
		{
			System.out.println("DE-SERIALIZING ::"+fileName);
		}
		Map<String,Set<String>> ret = new HashMap<String, Set<String>>();
		try
		{
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream(new File(fileName))) ;
			ret = (Map<String,Set<String>>) ois.readObject() ;
			ois.close() ;
		}
		catch (Exception e) 
		{
			ret=null;
			System.err.println("ERROR IN DE-SERIALIZING THE MEDDRA : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		return ret;
	}

	public static void serializeMap(String fileName, Map<String,Set<String>> map)
	{

		System.out.println("SERIALIZING MEDDRA IN : " + fileName) ;
		try
		{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File(fileName))) ;
			oos.writeObject(map) ;
			oos.flush() ;
			oos.close() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN SERIALIZING THE MEDDRA : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
	}


	private static void readOntology(String fileName)
	{
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.isEmpty())
					continue ;

				List<String> split = new ArrayList<String>(Arrays.asList(line.split("\t"))) ;
				String llt =split.get(0);
				String conceptStr = split.get(1);		
				List<String> concepts = new ArrayList<String>(Arrays.asList(conceptStr.split(", "))) ;
				concepts.add(llt);
				for(String concept: concepts)
				{
					concept=concept.replaceAll(" # ", ",");
					String actualConcept = new String(concept);
					concept=ConceptCleanup.refineConcept(concept);
					if(!concept.isEmpty())
					{
						String lemmatizedConcept=ConceptCleanup.createLemmatizedConcept(concept);
						Set<String> llts = meddraMap.containsKey(lemmatizedConcept) ? meddraMap.get(lemmatizedConcept) : new HashSet<String>();
						llts.add(llt);
						meddraMap.put(lemmatizedConcept, llts);

						Set<String> actualConcepts = meddraReverseMap.containsKey(lemmatizedConcept) ? meddraReverseMap.get(lemmatizedConcept) : new HashSet<String>();
						actualConcepts.add(actualConcept);
						meddraReverseMap.put(lemmatizedConcept, actualConcepts);

						System.out.println("ADDING ::\t"+actualConcept+"\t"+llt+"\t"+lemmatizedConcept);
					}
				}
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

	}
}
