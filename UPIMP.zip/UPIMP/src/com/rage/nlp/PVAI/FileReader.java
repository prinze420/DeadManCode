package com.rage.nlp.PVAI;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class FileReader
{
	public static List<List<String>> readFile(String fileName, String delimiter)
	{
		List<List<String>> ret = new ArrayList<List<String>>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.isEmpty())
					continue ;
				List<String> split = new ArrayList<String>(Arrays.asList(line.split(delimiter))) ;
				ret.add(split) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret;
	}
	
	
	public static String readFileContent(String fileName)
	{
		String ret = "" ;
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.trim().equalsIgnoreCase("") )
					continue ;
				line =FileReader.applyAsciiFilter(line);
				if ( line.equalsIgnoreCase("") )
					continue ;
				ret = ret.trim() + " " + line ; 
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret ;
	}
	
	public static Set<String> readFile(String fileName)
	{
		Set<String> ret = new LinkedHashSet<String>();
		BufferedReader br = null ;
		try
		{
			br = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(new File(fileName))))) ;
			String line = "" ;

			while ( (line = br.readLine()) != null )
			{
				if ( line.isEmpty())
					continue ;

				ret.add(line) ;
			}
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PARSING THE FILE : " + fileName + " : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		finally
		{
			try
			{
				if ( br != null )
					br.close() ;
			}
			catch (Exception e)
			{
				System.err.println("ERROR IN CLOSING READER : " + e.getMessage()) ;
				e.printStackTrace() ;
			}
		}

		return ret;
	}
	
	public static String applyAsciiFilter(String paraContent)
	{
		paraContent=paraContent.replaceAll("\\s+", " ").trim();
		String ret = "";
		/*
		Analyzer analyzer1 = new Analyzer()
		{
			@SuppressWarnings("deprecation")
			@Override
			protected TokenStreamComponents createComponents(String field,
					Reader reader)
			{
				TokenStream result = null;
				Tokenizer source = new WhitespaceTokenizer(Version.LUCENE_CURRENT, reader);
				result = new ASCIIFoldingFilter(source);
				return new TokenStreamComponents(source, result);

			}
		};
		TokenStream stream = null;
		try
		{
			stream = analyzer1.tokenStream("", new StringReader(paraContent));
			CharTermAttribute termAtt = stream
					.addAttribute(CharTermAttribute.class);
			stream.reset();

			while (stream.incrementToken())
			{
				String strToken = termAtt.toString();
				ret = ret.trim() + " " + strToken;
			}
			stream.end();
		}
		catch (Exception e)
		{
			ret = paraContent;
		}
		ret = ret.replaceAll("[^\\x20-\\x7e]", " ").replaceAll("\\s+", " ").trim();
		ret = ret.replaceAll(" s ", "'s ").trim();
		ret = ret.replaceAll(" t ", "'t ").trim();
		ret = ret.replaceAll("\\.{1,}", "\\.").trim();
		if (!paraContent.trim().equalsIgnoreCase(ret))
		{
			System.out.println("\nBEFORE REFINEMENT::\n" + paraContent);
			System.out.println("AFTER REFINEMENT::\n" + ret);
		}
			*/
		return ret;
}


}
