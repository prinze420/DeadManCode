package com.rage.nlp.PVAI;

public class Pair<E>
{
	private E value1 ;
	private E value2 ;
	
	public Pair(E value1, E value2)
	{
		setValue1(value1) ;
		setValue2(value2) ;
	}
	
	@Override
	public String toString() 
	{
		return "[" + value1 + "\t" + value2 + "]" ;
	}
	
	public E getValue1() 
	{
		return value1;
	}

	public void setValue1(E value1) 
	{
		this.value1 = value1;
	}

	public E getValue2() 
	{
		return value2;
	}

	public void setValue2(E value2) 
	{
		this.value2 = value2;
	}
}
