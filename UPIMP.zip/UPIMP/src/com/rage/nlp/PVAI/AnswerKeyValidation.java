package com.rage.nlp.PVAI;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;

public class AnswerKeyValidation
{

	public static void main(String[] args)
	{
		String inputFilePath = args[0];
		String fieldsStr=args[1];
		String outputFileName=args[2];

		Set<FieldName> fields=new HashSet<FieldName>();
		if(!fieldsStr.isEmpty())
		{
			List<String> inputFields= Arrays.asList(fieldsStr.split(","));
			for(String field:inputFields)
			{
				FieldName fieldName = FieldName.valueOf(field.trim());
				fields.add(fieldName);
			}
		}
		FileWriter fileWriter=null;
		File f = new File(inputFilePath);
		try 
		{ 
			fileWriter=new FileWriter(outputFileName);
			fileWriter.append("Case No\tField Name\tAnswer\tMatch Type\tContent length\tMatched String\n");
			if (f.isDirectory()) 
			{
				for (File inputFileName : f.listFiles())
				{
					if(!inputFileName.isDirectory())
					{
						String caseID=inputFileName.getName().replaceAll(".txt", "");
						String fileContent=FileReader.readFileContent(inputFileName.getAbsolutePath());
						fileContent=fileContent.replaceAll("\\s+", " ").trim().toLowerCase();
						for(FieldName fieldName : fields)
						{
							Set<String> answers= AnswerKeyLoader.getAnswerValue1(fieldName, caseID);
							for(String answer : answers)
							{
								answer=answer.replaceAll("\\s+", " ").trim().toLowerCase();
								if(answer.equalsIgnoreCase("-1"))
									continue;
								if(answer.equalsIgnoreCase("na"))
									continue;
								String matchType="Not Matched";
								String matchedString="";
								if(fieldName.equals(FieldName.PAT_AGE_UNIT))
									answer=ConceptCleanup.getAge(answer);

								if(fileContent.contains(" "+answer+" ") || fileContent.contains(" "+answer) || fileContent.contains(answer+" "))
								{
									matchType="Exact";
									matchedString="Exact";

								}
								else
								{
									String lemmatizedConcept = ConceptCleanup.createLemmatizedConceptWordnet(answer);
									if(fileContent.contains(" "+lemmatizedConcept+" ") || fileContent.contains(" "+lemmatizedConcept) || fileContent.contains(lemmatizedConcept+" "))
									{
										matchType="Exact-Lemma";
										matchedString=lemmatizedConcept;
									}
									else
									{
										lemmatizedConcept = ConceptCleanup.createLemmatizedConcept(answer);
										if(fileContent.contains(" "+lemmatizedConcept+" ") || fileContent.contains(" "+lemmatizedConcept) || fileContent.contains(lemmatizedConcept+" "))
										{
											matchType="Exact-Lemma";
											matchedString=lemmatizedConcept;
										}
										else
										{
											Map<Integer, Vector<String>> nGrams = createNGrams(answer) ;
											List<Integer> keys=new ArrayList<Integer>(nGrams.keySet()) ;
											Collections.sort(keys, Collections.reverseOrder());
											OUT:	for(Integer ngram : keys)
											{
												Vector<String> grams=nGrams.get(ngram);
												for(String value : grams)
												{
													if(fileContent.contains(" "+value+" ") || fileContent.contains(" "+value) || fileContent.contains(value+" "))
													{
														matchType="Partial "+ngram;
														matchedString=value;
														break OUT;
													}
												}
											}	
										}
									}
								}
								fileWriter.append(caseID+"\t"+fieldName+"\t"+answer+"\t"+matchType+"\t"+fileContent.length()+"\t"+matchedString+"\n");
								fileWriter.flush();
							}
						}
					}
				}
			}
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}

	}

	public static Map<Integer, Vector<String>> createNGrams(String value)
	{
		Map<Integer, Vector<String>> ret = new TreeMap<Integer, Vector<String>>() ;

		Map<Integer, Vector<Vector<String>>> nGrams = new HashMap<Integer, Vector<Vector<String>>>() ;

		Vector<String> tokens = new Vector<String>(Arrays.asList(value.split(" "))) ;
		// System.out.println("TOKENS : " + tokens) ;

		for ( int i=2 ; i<=tokens.size()-1 ; i++ )
		{
			int nGramSize = i ;
			Vector<Vector<String>> thisNGram = createNGrams(tokens, nGramSize) ;
			nGrams.put(new Integer(nGramSize), thisNGram) ;
		}

		for ( Integer size : nGrams.keySet() )
		{
			Vector<Vector<String>> thisNGrams = nGrams.get(size) ;
			Vector<String> thisStrNGrams = new Vector<String>() ;
			for ( int i=0 ; i<thisNGrams.size() ; i++ )
			{
				Vector<String> thisTokens = thisNGrams.elementAt(i) ;
				String str = "" ;
				for ( int j=0 ; j<thisTokens.size() ; j++ )
				{
					String thisToken = thisTokens.elementAt(j) ;
					str = str.trim() + " " + thisToken ;
				}

				thisStrNGrams.addElement(str.trim()) ;
			}

			ret.put(size, thisStrNGrams) ;
		}

		return ret ;
	}

	private static Vector<Vector<String>> createNGrams(Vector<String> tokens, int nGramSize) 
	{
		Vector<Vector<String>> ret = new Vector<Vector<String>>() ;

		for ( int i=0 ; i<tokens.size()-nGramSize+1 ; i++ )
		{
			Vector<String> thisGram = new Vector<String>() ;
			for ( int j=i ; j<i+nGramSize ; j++ )
			{
				thisGram.addElement(tokens.elementAt(j)) ;
			}
			ret.addElement(thisGram) ;
		}

		return ret ;
	}

}
