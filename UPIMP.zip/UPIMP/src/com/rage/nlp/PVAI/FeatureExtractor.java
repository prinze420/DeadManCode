package com.rage.nlp.PVAI;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.rage.nlp.core.Chunker;
import com.rage.nlp.core.MorphologicalAnalyzer;
import com.rage.nlp.core.NLChunk;
import com.rage.nlp.core.NLWord;
import com.rage.nlp.core.PosTagger;
import com.rage.nlp.core.SentenceBoundaryDetector;
import com.rage.nlp.core.StopWords;
import edu.stanford.nlp.ling.TaggedWord;

/**
 * 
 * @author ig0e572
 *
 */


public class FeatureExtractor
{
	public static boolean DEBUG =false;
	private static int fileCounter=0;
	private static int paraCounter=0;
	private static int lineCounter=0;

	private static Map<Vector<String>,Map<Feature,Set<String>>> paraFeatureMap = new HashMap<Vector<String>, Map<Feature,Set<String>>>();

	private static String createChunkRegex(List<NLChunk> chunks, String type)
	{
		StringBuilder phrasesTypeSeq = new StringBuilder();
		for(NLChunk chunk :chunks)
		{
			if(!chunk.getType().isEmpty())
			{
				if(!chunk.getType().equalsIgnoreCase("NP") || chunk.getChunk().contains(" use") || chunk.getChunk().contains(" exposure") 
						|| chunk.getChunk().contains(" result") || chunk.getChunk().contains(" treatment"))
				{
					if(type.equalsIgnoreCase("NLP"))
						phrasesTypeSeq.append(" " + chunk.getChunk());
					else 
						phrasesTypeSeq.append(" " + chunk.getLemmatizedChunk());
				}
				else 
				{
					phrasesTypeSeq.append(" " + chunk.getType() + "__@@__"+ chunk.getIndex());
				}
			}

		}
		return phrasesTypeSeq.toString().trim();
	}


	private static String matchPattern(List<NLChunk> chunks, String regex, String text , int grpIndex)
	{
		String index="";
		Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(text);
		while(matcher.find())
		{
			String matchedString = matcher.group(grpIndex).trim();
			if(DEBUG)
				System.out.println("Matched Group ::"+matchedString);
			String tokens[] = matchedString.split(" ");
			for(int i=0 ; i<tokens.length ; i++)
			{
				String[] splitIndex = tokens[i].split("__@@__");
				if (splitIndex.length > 1)
				{
					index= index.isEmpty() ? splitIndex[1] :index+","+splitIndex[1] ;
				}
			}
		}
		return index;
	}

	private static String extractFeature(String sentence, List<NLChunk> chunks, String chunkStr, Feature feature, String type)
	{
		Map<String, Integer> regexPatterns=loadRegexPatterns(feature ,type);
		for(String regex  : regexPatterns.keySet())
		{
			int group = regexPatterns.get(regex);
			String indexStr= matchPattern(chunks,regex,chunkStr, group);
			if(indexStr.isEmpty())
				continue;

			Vector<NLWord> tokens= new Vector<NLWord>();
			String[] indexes=indexStr.split(",");
			String phrase="";
			String phrase1="";
			for(int i=0 ; i<indexes.length ; i++)
			{
				NLChunk nlChunk = chunks.get(Integer.parseInt(indexes[i]));
				tokens.addAll(nlChunk.getTokens());
				phrase= phrase.isEmpty() ? nlChunk.getLemmatizedChunk(): phrase+" "+nlChunk.getLemmatizedChunk();
			}

			if(Feature.PatientName.equals(feature))
			{
				/*if(phrase.toLowerCase().contains("lipitor") || phrase.toLowerCase().contains("pfizer")||
						phrase.toLowerCase().contains("defendant") || sentence.toLowerCase().contains("drug") 
						|| sentence.toLowerCase().contains("outside counsel") || sentence.toLowerCase().contains("used for")
						|| sentence.toLowerCase().contains("compan"))
					continue;*/
				if( phrase.toLowerCase().contains("pfizer") || 
						phrase.toLowerCase().contains("pharmacia") || 
						phrase.toLowerCase().contains("corporation") || 
						phrase.toLowerCase().contains("company") ||
						phrase.toLowerCase().contains(" inc.") 
						|| phrase.toLowerCase().contains(" plc")
						|| phrase.toLowerCase().contains("below ") || phrase.equalsIgnoreCase("Zoloft"))
					continue;
				String ret="";
				for(NLWord word : tokens)
				{
					if(word.getLemma().equalsIgnoreCase("Plaintiff") || word.getLemma().equalsIgnoreCase("Decedent"))
						continue;
					if(word.getPostag().equals("NNP"))
						ret= ret.trim()+" "+word.getToken();
				}
				if(!ret.trim().isEmpty())
				{
					Matcher m = Pattern.compile("\\sresident\\s|\\sresidents\\s|\\scitizen\\s|\\scitizens\\s|\\sold\\s|\\smen\\s" +
							"|\\sman\\s|\\swoman\\s|\\swomen\\s|\\schildren\\s|patient\\s|plaintiff\\s|plaintiffs\\s|\\scity\\s" +
							"|\\sstate\\s|\\scities\\s|\\sstates\\s|\\sage\\s|\\slady\\s|\\sindividual").matcher(sentence.toLowerCase());
					if(m.find()) 
					{
						if(DEBUG)
							System.out.println("FOUND GROUP ::"+m.group(0));
						phrase=ret.trim();
					}
					else
					{
						if(DEBUG)
							System.out.println("Ignoring Concept:\t"+feature+"\t"+phrase+"\t"+sentence);
						phrase="";
					}
				}
				else
					phrase="";
			}
			else
			{
				if(phrase.contains("Plaintiff"))
					phrase=phrase.substring(0,phrase.indexOf("Plaintiff"));
				else if(phrase.contains("plaintiff"))
					phrase=phrase.substring(0,phrase.indexOf("plaintiff"));
				phrase1=ConceptCleanup.refineConcept(phrase);
				if(phrase1.isEmpty())
					phrase="";
				else
					phrase=StopWords.removeStopWords(phrase);
			}

			if(!phrase.isEmpty())
			{
				System.out.println("Matched Concept:\t"+feature+"\t"+phrase+"\t"+regex+"\t"+sentence);
				return phrase;
			}
		}
		return "";
	}

	private static Map<String, Integer> loadRegexPatterns(Feature feature , String type)
	{
		Map<String, Integer> regexPatterns=MetadataLoader.getLingusiticPatterns(type).containsKey(feature) 
				? MetadataLoader.getLingusiticPatterns(type).get(feature) : new HashMap<String, Integer>();

				return regexPatterns;
	}

	public static Map<Feature,Set<String>> extractFeatures(String pageNo, Vector<String> sentences, int paraID, String type)
	{
		//TODO
		/*if(MetadataLoader.getFilterKeywords().size()>0)
			sentences=filterSentences(sentences, pageNo, paraID);*/
		Map<Feature,Set<String>> featureMap = new HashMap<Feature, Set<String>>();
		sentences=refineSenetnces(sentences);
		if(paraFeatureMap.containsKey(sentences))
		{
			if(DEBUG)
				System.out.println("Already present ::");
			return paraFeatureMap.get(sentences) ;
		}
		Set<String> patientNames= new LinkedHashSet<String>();
		Set<String> adverseEvents= new LinkedHashSet<String>();
		Set<String> drugNames= new LinkedHashSet<String>();
		for(int i=0 ; i<sentences.size() ; i++)
		{
			lineCounter++;
			String sentence = sentences.elementAt(i);
			if(DEBUG)
				System.out.println("Running Sentence ::\t"+sentence);
			List<NLChunk> chunks = doShallowParsing(sentence);
			String chunkRegex= createChunkRegex(chunks, type);
			if(DEBUG)
				System.out.println("Chunk Expression ::"+chunkRegex);
			String patientName=extractFeature(sentence, chunks,chunkRegex, Feature.PatientName, type);
			if(!patientName.isEmpty())
				patientNames.add(patientName);
			String adverseEvent=extractFeature(sentence, chunks,chunkRegex, Feature.AdverseEvent, type);
			if(!adverseEvent.isEmpty())
				adverseEvents.add(adverseEvent);
			String drugName= extractFeature(sentence, chunks,chunkRegex, Feature.DrugName, type);
			if(!drugName.isEmpty())
				drugNames.add(drugName);
		}
		if(patientNames.size()>0)
			featureMap.put(Feature.PatientName, patientNames);
		if(adverseEvents.size()>0)
			featureMap.put(Feature.AdverseEvent, adverseEvents);
		if(drugNames.size()>0)
			featureMap.put(Feature.DrugName, drugNames);

		paraFeatureMap.put(sentences, featureMap);
		return featureMap;
	}

	public static Map<Feature,Set<String>> extractFeatures(String sentence,  String type)
	{
		Map<Feature,Set<String>> featureMap = new HashMap<Feature, Set<String>>();
		Set<String> patientNames= new LinkedHashSet<String>();
		Set<String> adverseEvents= new LinkedHashSet<String>();
		Set<String> drugNames= new LinkedHashSet<String>();
		if(DEBUG)
			System.out.println("Running Sentence ::\t"+sentence);
		List<NLChunk> chunks = doShallowParsing(sentence);
		String chunkRegex= createChunkRegex(chunks,type);
		if(DEBUG)
			System.out.println("Chunk Expression ::"+chunkRegex);
		String patientName=extractFeature(sentence, chunks,chunkRegex, Feature.PatientName, type);
		if(!patientName.isEmpty())
			patientNames.add(patientName);
		String adverseEvent=extractFeature(sentence, chunks,chunkRegex, Feature.AdverseEvent, type);
		if(!adverseEvent.isEmpty())
			adverseEvents.add(adverseEvent);
		String drugName= extractFeature(sentence, chunks,chunkRegex, Feature.DrugName, type);
		if(!drugName.isEmpty())
			drugNames.add(drugName);
		if(patientNames.size()>0)
			featureMap.put(Feature.PatientName, patientNames);
		if(adverseEvents.size()>0)
			featureMap.put(Feature.AdverseEvent, adverseEvents);
		if(drugNames.size()>0)
			featureMap.put(Feature.DrugName, drugNames);

		return featureMap;
	}
	private static Vector<String> refineSenetnces(Vector<String> sentences)
	{
		Vector<String> ret= new Vector<String>();
		for(int i=0 ; i<sentences.size() ; i++)
		{
			String sentence = sentences.elementAt(i);
			sentence=sentence.replaceAll("\\s+", " ").trim();
			Matcher m = Pattern.compile("^([a-zA-Z]\\.)\\s{1,}").matcher(sentence);
			if(m.find()) 
			{
				if(DEBUG)
					System.out.println("Enumeration found ::"+sentence);
				sentence = sentence.replace(m.group(1), "").trim();
			}
			m = Pattern.compile("^([0-9]+\\.)\\s{1,}").matcher(sentence);
			if(m.find()) 
			{
				if(DEBUG)
					System.out.println("Enumeration found ::"+sentence);
				sentence = sentence.replace(m.group(1), "").trim();
			}
			ret.add(sentence);
		}
		return ret;
	}


	@SuppressWarnings("unused")
	private static Vector<String> filterSentences(Vector<String> sentences, String pageNo, int paraID)
	{
		Vector<String> refinedSentences = new Vector<String>();
		for(String sentence : sentences)
		{
			boolean found =false;
			for(String keyword : MetadataLoader.getFilterKeywords())
			{
				if(sentence.toLowerCase().contains(keyword))
				{
					refinedSentences.add(sentence);
					found=true;
					break;
				}

			}
			if(!found)
				System.out.println("Leaving Sentence ::"+pageNo+"\t"+paraID+"\t"+sentence);
		}

		return refinedSentences;
	}


	public static List<NLWord> createTokens(String strSentence) 
	{
		List<NLWord> words = new ArrayList<NLWord>() ;
		try
		{
			List<TaggedWord> taggedWords = PosTagger.getCustomTaggedWords(strSentence);
			for (TaggedWord taggedWord : taggedWords)
			{
				NLWord word=new NLWord(taggedWord.beginPosition(), taggedWord.word());
				word.setPostag(taggedWord.tag());
				String lemma = MorphologicalAnalyzer.getLemma(word.getToken(), word.getPostag()) ;
				word.setLemma(lemma) ;
				words.add(word) ;

			}
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING TOKENIZATION-POSTAGGING-MORPHPOLOGICAL ANALYSIS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		if(DEBUG)
			System.out.println("Tokens : " + words) ;
		return words ;

	}


	public static List<NLChunk> doShallowParsing(String sentence)
	{
		Vector<NLWord> words = new  Vector<NLWord>(createTokens(sentence));
		List<NLChunk> chunks = new ArrayList<NLChunk>() ;
		Vector<String> tokens = new Vector<String>() ;
		Vector<String> postags = new Vector<String>() ;
		for ( int i=0 ; i<words.size() ; i++ )
		{
			tokens.add(words.get(i).getToken()) ;
			postags.add(words.get(i).getPostag()) ;
		}
		try
		{
			chunks = Chunker.doShallowParsing(tokens, postags, words) ;
		}
		catch (Exception e) 
		{
			System.err.println("ERROR IN DOING SHALLOW PARSING : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		if(DEBUG)
			System.out.println("CHUNKS : " + chunks) ;
		return chunks ;
	}

	private static void processSingleFile(File inputFileName, int paraIndex, int pageIndex, FileWriter fileWriter, 
			FileWriter fileWriterPara, String type)
	{
		if(!inputFileName.getName().endsWith(".txt"))
			return;
		String caseName=inputFileName.getName().replaceAll(".txt", "");
		fileCounter++;
		List<List<String>> lines = MetadataLoader.readFile(inputFileName, "\t");
		Set<String> paragraphs = new LinkedHashSet<String>();
		for(int paraID=0 ; paraID<lines.size() ; paraID++)
		{
			paraCounter++;
			try
			{
				List<String> lineSplits =lines.get(paraID);
				String pageNo= pageIndex!=-1 ? lineSplits.get(pageIndex) :"";
				String paragraph = lineSplits.get(paraIndex);
				paragraph=FileReader.applyAsciiFilter(paragraph);
				if(DEBUG)
					System.out.println("Processing paragraph:\t"+caseName+"\t"+pageNo+"\t"+paragraph);
				fileWriterPara.append(caseName+"\t"+pageNo+"\t"+paragraph+"\n");
				fileWriterPara.flush();
				extractParaFeatures(paragraph, fileWriter, type, caseName, paragraphs, paraID, pageNo);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		if(paragraphs.size()>0)
			appendParaExtraction(fileWriter, caseName, paragraphs);
		System.out.println("Files Processed :"+fileCounter+"\t"+caseName);
	}


	public static void extractParaFeatures(String paragraph, FileWriter fileWriter,
			String type, String caseName, Set<String> paragraphs, int paraID, String pageNo) throws IOException
			{
		Vector<String> sentences=SentenceBoundaryDetector.detectSentenceBoundary(paragraph);
		Map<Feature,Set<String>> featureMap=extractFeatures(pageNo, sentences, paraID, type);
		String patientNames= featureMap.containsKey(Feature.PatientName)? featureMap.get(Feature.PatientName).toString().replaceAll("\\[|\\]", "") :" ";
		String adverseEvents= featureMap.containsKey(Feature.AdverseEvent)? featureMap.get(Feature.AdverseEvent).toString().replaceAll("\\[|\\]", "") :" ";
		String drugNames= featureMap.containsKey(Feature.DrugName)? featureMap.get(Feature.DrugName).toString().replaceAll("\\[|\\]", "") :" ";
		if(type.equalsIgnoreCase("ExtractionParaKey") && paragraph.contains(":") && !(featureMap.containsKey(Feature.AdverseEvent) && featureMap.containsKey(Feature.DrugName)))
			paragraphs.add(paragraph);
		if(featureMap.size()>0)
		{
			if(DEBUG)
				System.out.println("Found Entries ::\t"+pageNo+"\t"+paragraph+"\t"+patientNames+"\t"+adverseEvents+"\t"+drugNames);
			fileWriter.append(caseName+"\t"+pageNo+"\t"+paragraph+"\t"+patientNames+"\t"+adverseEvents+"\t"+drugNames+"\n");
			fileWriter.flush();
		}
			}


	private static void appendParaExtraction(FileWriter fileWriter, String caseName, Set<String> paragraphs)
	{
		try
		{
			Map<Feature,Set<String>> featureMap=extractParaFeatures(paragraphs);
			String patientNames=" ";
			String adverseEvents= featureMap.containsKey(Feature.AdverseEvent)? featureMap.get(Feature.AdverseEvent).toString().replaceAll("\\[|\\]", "") :" ";
			String drugNames= featureMap.containsKey(Feature.DrugName)? featureMap.get(Feature.DrugName).toString().replaceAll("\\[|\\]", "") :" ";
			if(featureMap.size()>0)
			{
				System.out.println("Found Entries ::\t"+-1+"\t"+""+"\t"+patientNames+"\t"+adverseEvents+"\t"+drugNames);
				fileWriter.append(caseName+"\t"+"-1"+"\t"+""+"\t"+patientNames+"\t"+adverseEvents+"\t"+drugNames+"\n");
				fileWriter.flush();
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	private static Map<Feature, Set<String>> extractParaFeatures(Set<String> paragraphs)
	{
		Map<Feature,Set<String>> featureMap= new HashMap<Feature, Set<String>>();
		for(Feature feature : MetadataLoader.getParaPatterns().keySet())
		{
			Set<String> patterns= MetadataLoader.getParaPatterns().get(feature);
			Set<String> results= featureMap.containsKey(feature) ? featureMap.get(feature) : new HashSet<String>();
			OUT: for(String pattern : patterns)
			{
				for(String paragraph:paragraphs)
				{
					if(paragraph.contains(pattern))
					{
						String result=paragraph.substring(paragraph.indexOf(pattern)+pattern.length());
						result=result.contains(":") ? result.substring(0,result.indexOf(":")): result;
						if(!result.isEmpty())
						{ 
							results.add(result.toLowerCase().replaceAll(",", " ").replaceAll("\\s+", " ").trim());
						}
						break OUT;
					}
				}
			}
			if(results.size()>0)
				featureMap.put(feature, results);
		}
		return featureMap;
	}


	public static void main(String[] args)
	{

		int pageIndex=Integer.parseInt(args[1]);
		int paraIndex=Integer.parseInt(args[2]);
		String outputFileName =args[3];
		String outputFileNamePara =args[4];
		String inputFilePath = args[0];
		execute(pageIndex, paraIndex, outputFileName, outputFileNamePara, inputFilePath , "NLP");
	}


	public static void execute(int pageIndex, int paraIndex, String outputFileName, String outputFileNamePara, 
			String inputFilePath, String type)
	{
		long start = System.nanoTime();
		File f = new File(inputFilePath);
		FileWriter fileWriter=null;
		FileWriter fileWriterPara=null;
		try 
		{ 
			fileWriter=new FileWriter(outputFileName);
			fileWriter.append("Case No\tPageNo\tParagraph\tPatient Initials\tAE Verbatim\tTrade Name\n");

			fileWriterPara= new FileWriter(outputFileNamePara);
			fileWriterPara.append("Case No\tPageNo\tParagraph\n");
			if (f.isDirectory()) 
			{
				for (File inputFileName : f.listFiles())
				{
					if(!inputFileName.isDirectory())
					{
						processSingleFile(inputFileName, paraIndex, pageIndex , fileWriter, fileWriterPara, type);
					}
				}
			}
			else
			{
				processSingleFile(f, paraIndex, pageIndex, fileWriter, fileWriterPara,type); 
			}
		} 
		catch(Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			try
			{
				fileWriter.close();
				fileWriterPara.close();
			}
			catch (IOException e)
			{
				e.printStackTrace();
			}
		}
		long end = System.nanoTime();
		System.out.println("Total Files :"+fileCounter);
		System.out.println("Total Para :"+paraCounter);
		System.out.println("Total Sentences :"+lineCounter);
		System.out.println("Total Time Taken :"+(end-start));
	}
}
