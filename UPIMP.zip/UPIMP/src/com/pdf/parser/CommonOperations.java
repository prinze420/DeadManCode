package com.pdf.parser;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.base.SegmentGroup;
import com.pdf.parser.complex.ComplexStructure;
import com.pdf.parser.complex.TableCell;
import com.pdf.parser.complex.strategy.configBasedTable.rules.Alignment;

/*import org.openqa.selenium.WebElement;

import com.dp.generic.ElementStructure;
import com.dp.nativedoc.pdf.parser.base.BasicStructure;
import com.dp.nativedoc.pdf.parser.base.PDFSegment;
import com.dp.nativedoc.pdf.parser.complex.ComplexStructure;
import com.dp.nativedoc.pdf.parser.complex.TableCell;
import com.dp.nativedoc.pdf.parser.complex.strategy.configbasedtable.SegmentGroup;
import com.dp.nativedoc.pdf.parser.complex.strategy.configbasedtable.rules.Alignment;*/

public class CommonOperations {

	static ResourceBundle complexConfig, basicConfig,Utf_Characters;

	static{
		try {
			complexConfig = ResourceBundle.getBundle("complex-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config_extraction").toURI().toURL()}));
			//			complexConfig = ResourceBundle.getBundle("complex-structure-config");
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config_extraction").toURI().toURL()}));
			//			basicConfig = ResourceBundle.getBundle("basic-structure-config");
			Utf_Characters = ResourceBundle.getBundle("Utf_Characters",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config_extraction").toURI().toURL()}));
			//			Utf_Characters = ResourceBundle.getBundle("Utf_Characters");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


	//Whether s2 overlaps with s1 on y-axis
	public static boolean isOverlapOnY(BasicStructure s1, BasicStructure s2){
		boolean overlap = false;

		if(s2.getRectangle().getY() <= s1.getRectangle().getY() && s2.getRectangle().getY() > s1.getRectangle().getY2())
			overlap = true;

		else if(s2.getRectangle().getY2() >= s1.getRectangle().getY2() && s2.getRectangle().getY2() < s1.getRectangle().getY())
			overlap = true;

		else if(s2.getRectangle().getY() >= s1.getRectangle().getY() && s2.getRectangle().getY2() <= s1.getRectangle().getY2())
			overlap = true;

		//Special handling for periods and commas which may have their y2 just below the word's y
		else if(Math.abs(s2.getRectangle().getY() - s1.getRectangle().getY()) <= Float.valueOf(basicConfig.getString("allowedYDiffInSort")))
			overlap = true;

		return overlap;
	}

	/*public static boolean isOverlapOnY(ElementStructure s1, ElementStructure s2){
		boolean overlap = false;

		if(s2.getY() <= s1.getY() && s2.getY() > s1.getY2())
			overlap = true;

		else if(s2.getY2() >= s1.getY2() && s2.getY2() < s1.getY())
			overlap = true;

		else if(s2.getY() >= s1.getY() && s2.getY2() <= s1.getY2())
			overlap = true;

		//Special handling for periods and commas which may have their y2 just below the word's y
		else if(Math.abs(s2.getY() - s1.getY()) <= Float.valueOf(basicConfig.getString("allowedYDiffInSort")))
			overlap = true;

		return overlap;
	}*/

	public static boolean isOverlapOnY(ComplexStructure s1, ComplexStructure s2){
		boolean overlap = false;

		if(s2.getRectangles().get(0).getY() <= s1.getRectangles().get(0).getY() && s2.getRectangles().get(0).getY() > s1.getRectangles().get(0).getY2())
			overlap = true;

		else if(s2.getRectangles().get(0).getY2() >= s1.getRectangles().get(0).getY2() && s2.getRectangles().get(0).getY2() < s1.getRectangles().get(0).getY())
			overlap = true;

		else if(s2.getRectangles().get(0).getY() >= s1.getRectangles().get(0).getY() && s2.getRectangles().get(0).getY2() <= s1.getRectangles().get(0).getY2())
			overlap = true;

		//Special handling for periods and commas which may have their y2 just below the word's y
		else if(Math.abs(s2.getRectangles().get(0).getY() - s1.getRectangles().get(0).getY()) <= Float.valueOf(basicConfig.getString("allowedYDiffInSort")))
			overlap = true;

		return overlap;
	}

	//Whether s2 overlaps with s1 on x-axis
	public static boolean isOverlapOnX(BasicStructure s1, BasicStructure s2){
		boolean overlap = false;

		if(s2.getRectangle().getX() >= s1.getRectangle().getX() && s2.getRectangle().getX() < s1.getRectangle().getX2())
			overlap = true;

		else if(s2.getRectangle().getX2() <= s1.getRectangle().getX2() && s2.getRectangle().getX2() > s1.getRectangle().getX())
			overlap = true;

		else if(s2.getRectangle().getX() <= s1.getRectangle().getX() && s2.getRectangle().getX2() >= s1.getRectangle().getX2())
			overlap = true;

		return overlap;
	}

	//Whether s2 overlaps with s1 on x-axis
	/*public static boolean isOverlapOnX(ComplexStructure s1, ComplexStructure s2){
			boolean overlap = false;

			if(s1.getRectangles().size()==s2.getRectangles().size()){
				for (int i=0;i<s1.getRectangles().size();i++) {
					if(s2.getRectangles().get(i).getX() >= s1.getRectangles().get(i).getX() && s2.getRectangles().get(i).getX() < s1.getRectangles().get(i).getX2())
						overlap = true;

					else if(s2.getRectangles().get(i).getX2() <= s1.getRectangles().get(i).getX2() && s2.getRectangles().get(i).getX2() > s1.getRectangles().get(i).getX())
						overlap = true;

					else if(s2.getRectangles().get(i).getX() <= s1.getRectangles().get(i).getX() && s2.getRectangles().get(i).getX2() >= s1.getRectangles().get(i).getX2())
						overlap = true;
				}

			}
			return overlap;
	}*/


	//Whether s2 overlaps with s1 on x-axis
	public static boolean isOverlapOnX(ComplexStructure s1, BasicStructure s2){
		boolean overlap = false;

		if(s2.getRectangle().getX() >= s1.getRectangles().get(0).getX() && s2.getRectangle().getX() < s1.getRectangles().get(0).getX2())
			overlap = true;

		else if(s2.getRectangle().getX2() <= s1.getRectangles().get(0).getX2() && s2.getRectangle().getX2() > s1.getRectangles().get(0).getX())
			overlap = true;

		else if(s2.getRectangle().getX() <= s1.getRectangles().get(0).getX() && s2.getRectangle().getX2() >= s1.getRectangles().get(0).getX2())
			overlap = true;

		return overlap;
	}

	public static List<? extends BasicStructure> yxSort(Set<? extends BasicStructure> original, boolean considerYOverlap, float allowedYDiff){

		List<BasicStructure> structures = new ArrayList<BasicStructure>(original);
		Map<Float,List<BasicStructure>> yMap = new TreeMap<Float, List<BasicStructure>>();

		//Load the map based on y match or y overlap with the first element
		for(BasicStructure s : structures){

			//			if(s.getRectangle().getY()>396 && s.getRectangle().getY()<413)
			//				System.out.println("debug");

			boolean successfulOverlap = false;
			s.getRectangle().getY();
			if(yMap.containsKey(s.getRectangle().getY())){
				yMap.get(s.getRectangle().getY()).add(s);

				//				if(s.getRectangle().getY()>396 && s.getRectangle().getY()<414)
				//					System.out.println("Mapped "+yMap.get(s.getRectangle().getY())+" -- "+s.getStringRepresentation());

				continue;

			}else if(considerYOverlap){
				for(List<BasicStructure> existingStructures : yMap.values()){
					if(isOverlapOnY(existingStructures.get(0), s)){
						successfulOverlap = true;
						existingStructures.add(s);
						break;
					}
				}

			}else if(allowedYDiff != 0){
				outer:
					for(List<BasicStructure> existingStructures : yMap.values()){
						//Should match with atleast one of the existing structures
						for(BasicStructure existingStructure : existingStructures){
							if(isOverlapOnY(existingStructure, s) 
									&& Math.abs(existingStructure.getRectangle().getY() - s.getRectangle().getY()) <= allowedYDiff){

								successfulOverlap = true;
								existingStructures.add(s);

								//							if(s.getRectangle().getY()>396 && s.getRectangle().getY()<414)
								//								System.out.println("Mapped "+existingStructures+" -- "+s.getStringRepresentation());

								break outer;
							}
						}
					}
			}

			if(!successfulOverlap){
				List<BasicStructure> ss = new ArrayList<BasicStructure>();
				ss.add(s);
				yMap.put(s.getRectangle().getY(), ss);
			}
		}

		structures.clear();
		for(List<BasicStructure> list : yMap.values()){
			Collections.sort(list, new Comparator<BasicStructure>() {
				@Override
				public int compare(BasicStructure o1, BasicStructure o2) {
					return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
				}
			});

			//			for(Structure z : list)
			//				System.out.print(z.getStringRepresentation() + " ");
			//			System.out.println();

			structures.addAll(list);
		}

		return structures;
	}


	public static List<? extends ComplexStructure> yxSort(Set<? extends ComplexStructure> original, Boolean considerYOverlap, float allowedYDiff){

		List<ComplexStructure> structures = new ArrayList<ComplexStructure>(original);
		Map<Float,List<ComplexStructure>> yMap = new TreeMap<Float, List<ComplexStructure>>();

		//Load the map based on y match or y overlap with the first element
		for(ComplexStructure s : structures){

			//			if(s.getRectangle().getY()>396 && s.getRectangle().getY()<413)
			//				System.out.println("debug");

			boolean successfulOverlap = false;
			if(yMap.containsKey(s.getRectangles().get(0).getY())){
				yMap.get(s.getRectangles().get(0).getY()).add(s);

				//				if(s.getRectangles().get(0).getY()>396 && s.getRectangles().get(0).getY()<414)
				//					System.out.println("Mapped "+yMap.get(s.getRectangles().get(0).getY())+" -- "+s.getStringRepresentation());

				continue;

			}else if(considerYOverlap){
				for(List<ComplexStructure> existingStructures : yMap.values()){
					if(isOverlapOnY(existingStructures.get(0), s)){
						successfulOverlap = true;
						existingStructures.add(s);
						break;
					}
				}

			}else if(allowedYDiff != 0){
				outer:
					for(List<ComplexStructure> existingStructures : yMap.values()){
						//Should match with atleast one of the existing structures
						for(ComplexStructure existingStructure : existingStructures){
							if(isOverlapOnY(existingStructure, s) 
									&& Math.abs(existingStructure.getRectangles().get(0).getY() - s.getRectangles().get(0).getY()) <= allowedYDiff){

								successfulOverlap = true;
								existingStructures.add(s);

								//							if(s.getRectangles().get(0).getY()>396 && s.getRectangles().get(0).getY()<414)
								//								System.out.println("Mapped "+existingStructures+" -- "+s.getStringRepresentation());

								break outer;
							}
						}
					}
			}

			if(!successfulOverlap){
				List<ComplexStructure> ss = new ArrayList<ComplexStructure>();
				ss.add(s);
				yMap.put(s.getRectangles().get(0).getY(), ss);
			}
		}

		structures.clear();
		for(List<ComplexStructure> list : yMap.values()){
			Collections.sort(list, new Comparator<ComplexStructure>() {
				@Override
				public int compare(ComplexStructure o1, ComplexStructure o2) {
					return Float.valueOf(o1.getRectangles().get(0).getX()).compareTo(o2.getRectangles().get(0).getX());
				}
			});

			//			for(Structure z : list)
			//				System.out.print(z.getStringRepresentation() + " ");
			//			System.out.println();

			structures.addAll(list);
		}

		return structures;
	}

	public enum SORT_CRITERIA{X, Y, X2, Y2}
	public enum DIRECTION{MIN, MAX}

	public static List<BasicStructure> sort(List<? extends BasicStructure> s, final SORT_CRITERIA c, final DIRECTION d){
		List<BasicStructure> structures = new ArrayList<BasicStructure>(s);

		Collections.sort(structures, new Comparator<BasicStructure>() {
			@Override
			public int compare(BasicStructure o1, BasicStructure o2) {

				if(c == SORT_CRITERIA.X){
					if(d == DIRECTION.MIN)
						return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
					else
						return Float.valueOf(o2.getRectangle().getX()).compareTo(o1.getRectangle().getX());

				}else if(c == SORT_CRITERIA.Y){
					if(d == DIRECTION.MIN)
						return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
					else
						return Float.valueOf(o2.getRectangle().getY()).compareTo(o1.getRectangle().getY());

				}else if(c == SORT_CRITERIA.X2){
					if(d == DIRECTION.MIN)
						return Float.valueOf(o1.getRectangle().getX2()).compareTo(o2.getRectangle().getX2());
					else
						return Float.valueOf(o2.getRectangle().getX2()).compareTo(o1.getRectangle().getX2());

				}else if(c == SORT_CRITERIA.Y2){
					if(d == DIRECTION.MIN)
						return Float.valueOf(o1.getRectangle().getY2()).compareTo(o2.getRectangle().getY2());
					else
						return Float.valueOf(o2.getRectangle().getY2()).compareTo(o1.getRectangle().getY2());

				}

				return 0;
			}
		});

		return structures;
	}

	/**
	 * For Algnment.Before, it checks whether s1 is before s2
	 * @param s1 value
	 * @param s2 head1
	 * @param s3 head2 - Required for before and between
	 * @param align left/right/top/bottom/before
	 * @return
	 */
	public static boolean isAligned(List<TableCell> headers, TableCell head, PDFSegment seg){

		ComplexStructure s2 = head,s3 = null;
		Alignment align = head.getRule().getAlignment();

		if(align == Alignment.Before){

			s3 = headers.get(headers.indexOf(head) + 1); //Get next header

		}else if(align == Alignment.Between){
			s2 = headers.get(headers.indexOf(head) - 1);
			s3 = headers.get(headers.indexOf(head) + 1);
		}

		float tolerance = new Float(complexConfig.getString("alignmentTolerance"));

		if(align == Alignment.Left)
			return percentageDiff(seg.getRectangle().getX(), s2.getRectangles().get(0).getX()) >= tolerance;

			else if(align == Alignment.Right)
				return percentageDiff(seg.getRectangle().getX2(), s2.getRectangles().get(0).getX2()) >= tolerance;

				else if(align == Alignment.Bottom)
					return percentageDiff(seg.getRectangle().getY(), s2.getRectangles().get(0).getY()) >= tolerance;

					else if(align == Alignment.Top)
						return percentageDiff(seg.getRectangle().getY2(), s2.getRectangles().get(0).getY2()) >= tolerance;

						else if(align == Alignment.Overlap)
							return CommonOperations.isOverlapOnX(s2, seg);

						else if(align == Alignment.Before)
							return seg.getRectangle().getX2() < s3.getRectangles().get(0).getX() && seg.getRectangle().getX()>=s2.getRectangles().get(0).getX();

							else if(align == Alignment.Between)
								return seg.getRectangle().getX2() < s3.getRectangles().get(0).getX() && seg.getRectangle().getX()>s2.getRectangles().get(0).getX2();

								return false;
	}

	public static float percentageDiff(float a, float b){
		return (Math.abs(a-b)/a)*100;
	}

	public static String getRomanNumerals(int Int) {
		LinkedHashMap<String, Integer> roman_numerals = new LinkedHashMap<String, Integer>();
		//		roman_numerals.put("M", 1000);
		//		roman_numerals.put("CM", 900);
		//		roman_numerals.put("D", 500);
		//		roman_numerals.put("CD", 400);
		//		roman_numerals.put("C", 100);
		roman_numerals.put("XC", 90);
		roman_numerals.put("L", 50);
		roman_numerals.put("XL", 40);
		roman_numerals.put("X", 10);
		roman_numerals.put("IX", 9);
		roman_numerals.put("V", 5);
		roman_numerals.put("IV", 4);
		roman_numerals.put("I", 1);
		String res = "";
		for(Map.Entry<String, Integer> entry : roman_numerals.entrySet()){
			int matches = Int/entry.getValue();
			res += repeat(entry.getKey(), matches);
			Int = Int % entry.getValue();
		}
		return res;
	}

	public static String repeat(String s, int n) {
		if(s == null) {
			return null;
		}
		final StringBuilder sb = new StringBuilder();
		for(int i = 0; i < n; i++) {
			sb.append(s);
		}
		return sb.toString();
	}

	/**
	 * Primary goal is to convert the dt to it's reg-ex based form.
	 * Data Types are:
	 * $Num$ - Any number, decimal number, negative number.
	 * $Currency$ - Same as number but with a prefix dollar or pound sign
	 * $Text$ - Text of any length and numbers are allowed. Most relaxed constraint.
	 * $OR$ - creates two independent reg-ex patterns that are ORed
	 * $Date$ - Matches many date representations
	 * $Char$ - One character that can also be a number
	 * $Alphabet$ - One character that cannot be a number
	 * 
	 * $Num(n)$ - Restrict number of digits
	 * $Num(m-n) - Retrict number of digits in a range
	 * Same modifications are allowed for currency, char, alphabets and text
	 * 
	 * Also have added the header handler for suffix anything and starts with string
	 * 
	 * @param dt Data type string representation
	 * @return
	 */
	public static String processDataType(String dt){

		//\\(?\\$\\s*\\d+((\\,\\s*\\d+){0,})?((\\.\\s*\\d+))?\\)?
		// \\(?(�|$|-)?\\d+((\\,\\s*\\d+){0,})?(\\.\\s*\\d+)?(%)?\\)?

		//Refer to https://docs.oracle.com/javase/tutorial/essential/regex/pre_char_classes.html
		//We have to further escape the character classes

		String num = "((-)?(\\\\d+)?((\\,\\\\s*\\\\d+){0,})?(\\.\\\\s*\\\\d+)?)";
		String curr = "((�|\\$|�|�)?(-)?(\\\\d+)?((\\,\\\\s*\\\\d+){0,})?(\\.\\\\s*\\\\d+)?)";
		String text = "(.+)";
		String or = "|";
		String date = "("
				+ "((January|February|March|April|May|June|July|August|September|October|November|December)\\\\s{0,2}\\\\d{1,2}\\\\s{0,2}(th|TH|st|ST)?(.|,)\\\\s{0,2}(\\\\d{4}))|"
				+ "(\\\\d{1,2}\\\\s*(January|February|March|April|May|June|July|August|September|October|November|December)\\\\s*(\\\\d{4}))|"
				+ "(\\\\d{1,2}\\\\s*(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\\\s*(\\\\d{4}))|"
				+ "((\\\\d{1,2})(th|nd|rd)\\\\s*(January|February|March|April|May|June|July|August|September|October|November|December)\\\\s*(\\\\d{4}))|"
				+ "((\\\\d{1,2})(.|,|-)\\\\s{0,10}(January|February|March|April|May|June|July|August|September|October|November|December)(.|,|-)\\\\s{0,10}(\\\\d{4}|\\\\d{2}))|"
				+ "((\\\\d{1,2})(.|,|-)\\\\s{0,10}(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)(.|,|-)\\\\s{0,10}(\\\\d{4}|\\\\d{2}))|"
				+ "((\\\\d{1,2})(.|,|-)\\\\s{0,10}(JAN|FEB|MAR|APR|MAY|JUN|JUL|AUG|SEP|OCT|NOV|DEC)(.|,|-)\\\\s{0,10}(\\\\d{4}|\\\\d{2}))|"
				+ "((\\\\d{1,2})\\\\s*(-?)\\\\s*(January|February|March|April|May|June|July|August|September|October|November|December)(,?)\\\\s{0,10}(\\\\d{4}))|"
				+ "((January|February|March|April|May|June|July|August|September|October|November|December)\\\\s*(-)?\\\\s*(\\\\d{4}|\\\\d{2}))|"
				+ "((Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\\\\s*(-)?\\\\s*(\\\\d{4}|\\\\d{2}))|"
				+ "(\\\\d{1,2}/\\\\d{1,2}/\\\\d\\\\d\\\\d\\\\d)"
				+ ")";
		String character = "[A-Za-z0-9]";
		String alphabet = "[A-Za-z]";

		String pattern = "\\$(.*?)\\$";
		Pattern dataTypePattern = Pattern.compile(pattern);
		Matcher m = dataTypePattern.matcher(dt);
		while(m.find()){
			if(m.group(1).equalsIgnoreCase("num"))
				dt = dt.replaceFirst("\\$(.*?)\\$", num);

			else if(m.group(1).equalsIgnoreCase("currency"))
				dt = dt.replaceFirst(pattern, curr);

			else if(m.group(1).equalsIgnoreCase("text"))
				dt = dt.replaceFirst(pattern, text);

			else if(m.group(1).equalsIgnoreCase("or"))
				dt = dt.replaceFirst(pattern, or);

			else if(m.group(1).equalsIgnoreCase("date"))
				dt = dt.replaceFirst(pattern, date);

			else if(m.group(1).equalsIgnoreCase("char"))
				dt = dt.replaceFirst(pattern, character);

			else if(m.group(1).equalsIgnoreCase("alphabet"))
				dt = dt.replaceFirst(pattern, alphabet);

			else if(m.group(1).equalsIgnoreCase("*"))
				dt = dt.replaceFirst(pattern, "(.*)");			
		}

		pattern = "\\$(.*?)\\((\\d+)\\)\\$";
		dataTypePattern = Pattern.compile(pattern);
		m = dataTypePattern.matcher(dt);
		while(m.find()){

			int n = new Integer(m.group(2));

			if(m.group(1).equalsIgnoreCase("num"))
				dt = dt.replaceFirst(pattern,"([\\d-\\.,]{"+n+"})");

			else if(m.group(1).equalsIgnoreCase("text"))
				dt = dt.replaceFirst(pattern,"((.){"+n+"})");

			else if(m.group(1).equalsIgnoreCase("date"))
				dt = dt.replaceFirst(pattern,date);

			else if(m.group(1).equalsIgnoreCase("char"))
				dt = dt.replaceFirst(pattern,"([A-Za-z0-9]{"+n+"})");

			else if(m.group(1).equalsIgnoreCase("alphabet"))
				dt = dt.replaceFirst(pattern,"([A-Za-z]{"+n+"})");
		}

		//StartsWith(String) handler
		pattern = "\\$(.*?)\\((.*?)\\)\\$";
		dataTypePattern = Pattern.compile(pattern);
		m = dataTypePattern.matcher(dt);
		while(m.find()){
			if(m.regionStart()==0 && m.group(1).equalsIgnoreCase("startswith"))//There shouldn't be any string or pattern before startswith rule
				dt = dt.replaceFirst(pattern,"^"+m.group(2)+".*");
		}

		pattern = "\\$(.*?)\\((\\d+),(\\d+)\\)\\$";
		dataTypePattern = Pattern.compile(pattern);
		m = dataTypePattern.matcher(dt);
		while(m.find()){

			int n1 = new Integer(m.group(2));
			int n2 = new Integer(m.group(2));

			if(m.group(1).equalsIgnoreCase("num")){
				dt.replaceFirst(pattern,"([\\d-\\.,]{"+n1+","+n2+"})");
			}

			else if(m.group(1).equalsIgnoreCase("text"))
				dt = dt.replaceFirst(pattern,"((.){"+n1+","+n2+"})");

			else if(m.group(1).equalsIgnoreCase("date"))
				dt = dt.replaceFirst(pattern,date);

			else if(m.group(1).equalsIgnoreCase("char"))
				dt = dt.replaceFirst(pattern,"([A-Za-z0-9]{"+n1+","+n2+"})");

			else if(m.group(1).equalsIgnoreCase("alphabet"))
				dt = dt.replaceFirst(pattern,"([A-Za-z]{"+n1+","+n2+"})");
		}

		return dt;
	}

	public static List<SegmentGroup> groupSegmentsOnY(List<? extends BasicStructure> segs){
		List<BasicStructure> segments = new ArrayList<BasicStructure>(segs);
		List<SegmentGroup> segmentPerY = new ArrayList<SegmentGroup>();
		for(int i=0; i<segments.size(); i++){
			BasicStructure s = segments.get(i);
			int index = segmentPerY.indexOf(new SegmentGroup(s.getRectangle().getY())); 
			if(index==-1){

				//Add in a segment group based on y overlap
				boolean groupFound = false;
				for(SegmentGroup sg : segmentPerY){
					if(CommonOperations.isOverlapOnY(s, sg.getBasicStructures().get(0))){
						List<BasicStructure> bs = sg.getBasicStructures();
						bs.add(s);
						sg.setSegments(bs);
						groupFound = true;
						break;
					}
				}

				if(!groupFound){
					SegmentGroup group = new SegmentGroup(s.getRectangle().getY());
					group.getBasicStructures().add(s);
					segmentPerY.add(group);
				}

			}else{
				List<BasicStructure> bs = segmentPerY.get(index).getBasicStructures();
				bs.add(s);
				segmentPerY.get(index).setSegments(bs);
			}
		}

		return segmentPerY;
	}

	public static boolean isStartwithBulletPoint(String segStr) {
		if(segStr==null||segStr.trim().isEmpty())
			return false;
		/*List<String> utfBulletPoints = Arrays.asList(Utf_Characters.getString("bulletPoints").split(","));

		for (String string : utfBulletPoints) {
			if(string.trim().equals(bulletChar)){
				return true;
			}
		}*/

		List<String> utfBulletPointsInt = Arrays.asList(Utf_Characters.getString("bulletPointsInt").split(","));
		Character bulletChar=segStr.trim().charAt(0);
		int charValue =(int)bulletChar;
		for (String string : utfBulletPointsInt) {
			if(Integer.valueOf(string)==charValue){
				//				System.out.println("bulletPoint :"+segStr);
				return true;
			}
		}

		List<String> bulletPointsInGroupOfAscci = Arrays.asList(Utf_Characters.getString("bulletPointsInGroupOfAscci").split(","));
		for (String string : bulletPointsInGroupOfAscci){
			String[] range = string.split("to");

			if(charValue>=Integer.valueOf(range[0].trim())&&charValue<=Integer.valueOf(range[1].trim())){
				return true;
			}
		}
		return false;
	}


	public static boolean utfInlineCharacter(PDFCharacter ch){

		List<String> bulletPointsInGroupOfAscci = Arrays.asList(Utf_Characters.getString("utfInlineCharacters").split(","));
		for (String string : bulletPointsInGroupOfAscci){
			if((int)(ch.getStringRepresentation().charAt(0))==Integer.valueOf(string.trim()))
				return true;
		}

		return false;
	}

	public static Map<Integer,List<PDFWord>> getMultiColumnWisePDFWord(List<PDFWord>structList){
		Map<Integer,List<PDFWord>> colWiseMap = new TreeMap<Integer,List<PDFWord>>();
		//=================== 1 =====================
		for ( PDFWord struct: structList) {
			//			if(((PDFWord)struct).isPartOfTable()){
			int index =((PDFWord)struct).getMultiColumnIndex();
			if(colWiseMap.containsKey(index)){
				colWiseMap.get(index).add(struct);
			}else{
				List<PDFWord> temp =new ArrayList<PDFWord>();
				temp.add(struct);
				colWiseMap.put(index, temp);
			}
			//			}
		}
		return colWiseMap;
	}
	
	/*public static Map<Integer,List<PDFSegment>> getMultiColumnWisePDFSegment(List<PDFSegment>structList){
		Map<Integer,List<PDFSegment>> colWiseMap = new TreeMap<Integer,List<PDFSegment>>();
		//=================== 1 =====================
		for ( PDFSegment struct: structList) {
			if(struct.getStringRepresentation().contains("review this comparator group")){
				System.out.println("");
			}
			//			if(((PDFSegment)struct).isPartOfTable()){
			int index =((PDFSegment)struct).getMultiColumnIndex();
			if(colWiseMap.containsKey(index)){
				colWiseMap.get(index).add(struct);
			}else{
				List<PDFSegment> temp =new ArrayList<PDFSegment>();
				temp.add(struct);
				colWiseMap.put(index, temp);
			}
			//			}
		}
		return colWiseMap;
	}*/
	public static void main(String[] args) {
		System.out.println(getRomanNumerals(8).toLowerCase());
	}

	/*public static Map<Integer, List<Structure>> getMultiColumnWiseStructure(List<Structure> structList) {

		Map<Integer,List<Structure>> colWiseMap = new TreeMap<Integer,List<Structure>>();
		if(structList==null){
			return colWiseMap;
		}
		//=================== 1 =====================
		for ( Structure struct: structList) {

			int index =struct.getMultiColumnIndex();
			if(colWiseMap.containsKey(index)){
				colWiseMap.get(index).add(struct);
			}else{
				List<Structure> temp =new ArrayList<Structure>();
				temp.add(struct);
				colWiseMap.put(index, temp);
			}
		}
		return colWiseMap;
	}
	*/
	/*public static Map<Integer, List<BasicStructure>> getMultiColumnWiseB_Structure(List<BasicStructure> structList) {

		Map<Integer,List<BasicStructure>> colWiseMap = new TreeMap<Integer,List<BasicStructure>>();
		if(structList==null){
			return colWiseMap;
		}
		//=================== 1 =====================
		for ( BasicStructure struct: structList) {

			int index =struct.getMultiColumnIndex();
			if(colWiseMap.containsKey(index)){
				colWiseMap.get(index).add(struct);
			}else{
				List<BasicStructure> temp =new ArrayList<BasicStructure>();
				temp.add(struct);
				colWiseMap.put(index, temp);
			}
		}
		return colWiseMap;
	}
*/
	public static DPRectangle createRectangle(List<PDFSegment> dateSeg) {

		if(dateSeg==null||dateSeg.isEmpty()){
			//DPRectangle rect=new DPRectangle(0, 0, 0, 0, 0);
			return null;
		}
		Collections.sort(dateSeg, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o2.getRectangle().getX2()).compareTo(o1.getRectangle().getX2());
			}
		});
		float maxX2 = dateSeg.get(0).getRectangle().getX2();


		Collections.sort(dateSeg, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
			}
		});
		float minX = dateSeg.get(0).getRectangle().getX();

		Collections.sort(dateSeg, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o2.getRectangle().getY()).compareTo(o1.getRectangle().getY());
			}
		});
		float maxY = dateSeg.get(0).getRectangle().getY();

		Collections.sort(dateSeg, new Comparator<PDFSegment>() {
			public int compare(PDFSegment o1, PDFSegment o2) {
				return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
			}
		});
		float minY2 = dateSeg.get(0).getRectangle().getY2();

		DPRectangle rect=new DPRectangle(minX, maxY, (maxX2-minX), (maxY-minY2),  dateSeg.get(0).getRectangle().getPage());

		return rect;
	}


	/*public static Set<DPCell> assignLineCellsData(List<PDFSegment> pageData) {

		Map<DPCell, List<PDFSegment>>cellWisePageData=new HashMap<DPCell, List<PDFSegment>>();

		for (PDFSegment p : pageData) {

			if(struct instanceof Paragraph ){
				Paragraph p=(Paragraph)struct; 
				if(p.getLineCell()!=null){
					if(cellWisePageData.containsKey(p.getLineCell())){
						List<Structure> list = cellWisePageData.get(p.getLineCell());
						list.add(struct);
						cellWisePageData.put(p.getLineCell(), list);

					}else{
						List<Structure> list = new ArrayList<Structure>();
						list.add(struct);
						cellWisePageData.put(p.getLineCell(), list);

					}	
				}
			}else if(struct instanceof PDFSegment ){

			//	PDFSegment p=(PDFSegment)struct; 
				if(p.getLineCell()!=null){
					if(cellWisePageData.containsKey(p.getLineCell())){
						List<PDFSegment> list = cellWisePageData.get(p.getLineCell());
						list.add(p);
						cellWisePageData.put(p.getLineCell(), list);

					}else{
						List<PDFSegment> list = new ArrayList<PDFSegment>();
						list.add(p);
						cellWisePageData.put(p.getLineCell(), list);

					}	
				}
			}

			for ( DPCell k : cellWisePageData.keySet()) {
				List<PDFSegment> data = cellWisePageData.get(k);
				k.setLineCellDataList(data);
			}

		Set<DPCell> lineCells = cellWisePageData.keySet(); 
		return lineCells;
	}
	 */
}
