package com.pdf.parser.pipeline;

/**
 * This is the model of the default pipeline. It represents the series of steps to be taken to parse a PDF.
 * Overall it represents the formulation of basic and complex Structures
 * @author Shishir.Mane
 *
 */
public interface PDFParser {
	
	/**
	 * This method would encompass the steps required to parse a PDF.
	 * @param pdfPath
	 */
	public void parse();
	
	/**
	 * A PDF parse is not possible until all the basic Structures have been formulated.
	 */
	public void formulateStructures();
}
