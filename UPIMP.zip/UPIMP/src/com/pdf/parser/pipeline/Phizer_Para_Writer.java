package com.pdf.parser.pipeline;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.io.RandomAccessBuffer;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.complex.strategy.PDFParaDetectionStrategy;
import com.pdf.parser.utils.MultiThreadHelper;

public class Phizer_Para_Writer {
	
	private static Set<String>processedFiles=new HashSet<String>();
	static ResourceBundle basicConfig;
	private Map<Integer,List<String>> startPageKeywords = new TreeMap<Integer, List<String>>();


	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

			BufferedReader reader = new BufferedReader(new FileReader("config/processedFiles.list"));//use for skip already processed files
			String line ="";
			while((line = reader.readLine()) != null)
				processedFiles.add(line.trim());
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	static final Object lock=new Object();
	//how many keywords are matched for start page detection
	static final Integer forStartPageDetection_matching_Limit = Integer.valueOf(basicConfig.getString("forStartPageDetection_matching_Limit"));

	public static void main(String[] args) throws Exception{
		String input = args[0];
		final String output = args[1];
		int parallel = new Integer(args[2]);
		
		List<String> exceptions = new ArrayList<String>();
		for(File f : new File(output).listFiles())
			exceptions.add(f.getName());
		
		List<Runnable> runs = new ArrayList<Runnable>();
		
		for(final File f : new File(input).listFiles()){
			
			if(exceptions.contains(f.getName()))
				continue;
			
			runs.add(new Runnable() {
				public void run() {
					
					try{
						PDDocument pdf = PDDocument.load(f, new RandomAccessBuffer());
	
						pdf.setAllSecurityToBeRemoved(true);
						if(pdf.isEncrypted()){
							try {
								pdf.decrypt("");
							} catch (CryptographyException e) {
								e.printStackTrace();
							}
						}
						pdf.setAllSecurityToBeRemoved(true);
						
						DefaultParser parser = new DefaultParser(pdf);
						parser.parse();
						Map<Integer, List<PDFSegment>> pageSegments = parser.getSegments();
						List<PDPage> pdPages = parser.getPdfPages();
						
						Phizer_Para_Writer ppw = new Phizer_Para_Writer();
						int startPage=ppw.detectStartPage(pageSegments); 
						
						PDFParaDetectionStrategy pdp=new PDFParaDetectionStrategy(pageSegments,pdPages,startPage);
						pdp.apply();
						Map<Integer, List<PDFPara>> pageWiseParas = pdp.getOutcome();
						
						String parafile=output+File.separator+f.getName().substring(0, f.getName().lastIndexOf("."))+".txt";
						ppw.writeStructure(pageWiseParas,parafile,startPage);
						
					}catch(Exception e){
						System.err.println("Error in "+f.getAbsolutePath());
						e.printStackTrace();
					}
				}
			});
		}
		
		MultiThreadHelper.processThreads(runs, parallel);
	}
	
	private Integer detectStartPage(Map<Integer, List<PDFSegment>> map)
	{
		int sartPage=0;

		if(startPageKeywords==null ||startPageKeywords.isEmpty()){
			return sartPage;
		}
		for (Integer pg : map.keySet()) {

			List<PDFSegment>list=map.get(pg);
			if(list!=null && !list.isEmpty()){
				sartPage=list.get(0).getRectangle().getPage();
			}
			// TODO: Get character lines/segments, read keywords, match minimum N keywords

			for (Integer key : startPageKeywords.keySet()) { // template keyword matching on same page
				int matchCount=0;
				List<String> pageStartIndicatorList = startPageKeywords.get(key);
				List<String> matchedKeyWords=new ArrayList<String>();
				for ( PDFSegment seg :list ) 
				{
					for (String string : pageStartIndicatorList) {
						if(seg.getStringRepresentation().contains(string) && !matchedKeyWords.contains(seg.getStringRepresentation()))
						{
							matchedKeyWords.add(seg.getStringRepresentation());
							matchCount++;
							break;
						}
					}
				}
				if(forStartPageDetection_matching_Limit > 0){
					if(matchCount>=forStartPageDetection_matching_Limit){
						System.out.println("It is Starting page\t"+sartPage);
						return list.get(0).getRectangle().getPage();
					}
				}else{
					if(matchCount>=pageStartIndicatorList.size()){
						return list.get(0).getRectangle().getPage();
					}
				}

			}


		}
		return 0;
	}
	
	public void writeStructure(	Map<Integer, List<PDFPara>> pageWiseParas,String filePath, int startPage){
		BufferedWriter writer;
		try {

			writer = new BufferedWriter(new FileWriter(filePath));
			//writer.newLine();
			/*writer.write("\n\n\n ######################## KV pairs "+pairs.size());
			for (Structure p : pairs) {
				if(p instanceof KeyValuePair ){
					KeyValuePair p2 = (KeyValuePair)p;
					writer.write("\n\t"+p2.getKey().getStringRepresentation()+"\t:"+p2.getValueText());
				}
			}*/


			//	writer.write("\n\n ######################## Other Text");
			for (Integer em : pageWiseParas.keySet()) {
				if(!pageWiseParas.get(em).isEmpty() && em>=startPage){
					//writer.newLine();
					//writer.write("\n\t page:"+em);
					for (PDFPara structure : pageWiseParas.get(em)) {
						writer.write("\n#"+structure.getRectangles().get(0).getPage()+"#\t"+(structure.getStringRepresentation()));	
					}
				}
			}

			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

}
