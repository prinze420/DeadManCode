package com.pdf.parser.test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.MultiThreadHelper;

public class WordHtmlGenerator {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		String file = "D:\\Platform\\Phizer\\TestSample\\temp\\marketedEDC.pdf";
		//String file=args[0];
		PDDocument pdf = PDDocument.load(file);
		
		final DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();
		
		String finalHtml = "<html><body>\n";
		List<Runnable> runs = new ArrayList<Runnable>();
		final Map<Integer,String> pageOutputs = new HashMap<Integer, String>();
		
		for(final int page : parser.getWords().keySet()){

//			if(page!=1)
//				continue;
			
			runs.add(new Runnable() {
				public void run() {
					String html = "";
					int pageWidth = (int)parser.getPageWidthHeight().get(page).getX();
					int pageHeight = (int)parser.getPageWidthHeight().get(page).getY();
					
//					int rotation = Math.abs(((PDPage)pdf.getDocumentCatalog().getAllPages().get(page)).getRotation());
//					if(rotation == 90 || rotation == 270){
//						int temp = pageWidth;
//						pageWidth = pageHeight;
//						pageHeight = temp;
//					}
					
					html += "<div>Page: "+(page+1)+"</div>\n";
					html += "\t<div style='width:"+pageWidth+"px; height:"+pageHeight+"px;border:1px solid red; margin-bottom: 10px;position:relative;'>\n";
					
					for(PDFWord element : parser.getWords().get(page)){
						
						String fontName = element.getCharacters().get(0).getFontName();
						if(fontName == null)
							fontName = "";
						if(fontName.contains("+"))
							fontName = fontName.substring(fontName.lastIndexOf("+")+1);
						
						float fontScale = 1f;
						int fontSize = (int)(element.getCharacters().get(0).getFontSizeInPt()*fontScale);
						if(fontSize>20)
							fontSize = 20;
						
						String tooltip = "x="+(int)element.getRectangle().getX()+" x2="+(int)element.getRectangle().getX2();
						tooltip += "\ny="+(int)element.getRectangle().getY()+" y2="+(int)element.getRectangle().getY2();
						tooltip += "\nwidth="+(int)element.getRectangle().getWidth();
						tooltip += "\nHeight="+(int)element.getRectangle().getHeight();
						tooltip += "\nFont="+element.getCharacters().get(0).getFontName();
						tooltip += "\nBold="+element.getCharacters().get(0).isBold();
						tooltip += "\nFont-Size="+element.getCharacters().get(0).getFontSizeInPt()+"pt";
						tooltip += "\nWidth of Space="+element.getWidthOfSpace();
						tooltip += "\nEntirely bold="+element.isCompletelyBold();
						
						boolean isBold = element.getCharacters().get(0).isBold() ||
								element.getCharacters().get(0).getFontName().toLowerCase().endsWith("bold");
						
						String boldProp = isBold ? "font-weight: bold;" : "font-weight: normal;";
						
						int rotation = 0;
						if(element.getCharacters().get(0).getRoatation()!=0){
							rotation = (int)element.getCharacters().get(0).getRoatation();
							if(rotation == 90)
								rotation = 270;
							else if(rotation == 270)
								rotation = 90;
						}
							
						html += "\t\t<div" +
								" style='font-family:"+fontName+";left:"+(int)element.getRectangle().getX()+"px;font-size:"+fontSize+"px;"
								+ "top:"+(int)element.getRectangle().getY()+"px; position:absolute; transform:rotate("+rotation+"deg); "
								+ "text-decoration: underline;"+boldProp+"'" +
								" title='"+tooltip+"' onmouseover=\"this.style.color='red'\" onmouseout=\"this.style.color='black'\"" +
								">\n";
						html += "\t\t\t"+element.getStringRepresentation()+"\n";
						html += "\t\t</div>\n";
					}
					
					html += "\t</div>\n";
					
					synchronized(pageOutputs){
						pageOutputs.put(page, html);
					}
				}
			});
		}
		
		MultiThreadHelper.processThreads(runs, 4);
		
		for(int i=0; i<pdf.getDocumentCatalog().getAllPages().size(); i++){
			if(pageOutputs.containsKey(i)){
				finalHtml += pageOutputs.get(i);
			}
		}
		finalHtml += "</body></html>";
		
		String fname = new File(file).getName();
		fname = fname.substring(0, fname.lastIndexOf("."));
		BufferedWriter writer = new BufferedWriter(new FileWriter("Words-"+fname+".html"));
		writer.write(finalHtml.toString());
		writer.flush();
		writer.close();
	
		pdf.close();
	}
	
//	private static boolean nearlyEqual(float n1, float n2, float comp){
//		if(Math.abs(n1-n2)>comp)
//			return false;
//		return true;
//	}
}
