package com.pdf.parser.test;

import java.awt.Color;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;

import com.pdf.parser.base.PDFVerticalGap;
import com.pdf.parser.pipeline.DefaultParser;

public class AllVGapGen {

	public static void main(String[] args) throws Exception{
		final String file = "19951022.pdf";
		final PDDocument pdf = PDDocument.load(file);

		DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();
		
		final Random random = new Random();
		List<Thread> threads = new ArrayList<Thread>();
		
		for(int pg=0; pg<pdf.getNumberOfPages(); pg++){
			
			List<PDFVerticalGap> vgaps = parser.getVgaps().get(pg);
			
//			vgaps = PDFVerticalGapFormationStrategy.filterIrrelevantVGaps(vgaps);
			
			if(vgaps!=null && vgaps.size()>0){
				
				PDPage page = (PDPage)pdf.getDocumentCatalog().getAllPages().get(pg);
				float pheight = page.getMediaBox().getHeight();
				PDPageContentStream stream = new PDPageContentStream(pdf, page, true, false);
				
				for(final PDFVerticalGap vgap : vgaps){
					Color color = new Color(random.nextInt(254), random.nextInt(254), random.nextInt(254), 200);				
					stream.setNonStrokingColor(color);
					stream.setStrokingColor(color);
					
					float x = vgap.getRectangle().getX();
					float y = pheight - vgap.getRectangle().getY();
					float width = vgap.getRectangle().getWidth();
					float height = vgap.getRectangle().getHeight();
					stream.addRect(x, y, width, height);
					System.out.println(vgap.getStringRepresentation()+" -> "+x+","+y+","+width+","+height);

					stream.fillRect(10, page.getBleedBox().getHeight(), 10, 10);
				}
				
				stream.close();
			}
		}
		
		pdf.save("AllVGaps - "+file);
		pdf.close();
	}

}
