package com.pdf.parser.test;

import org.apache.commons.math.stat.descriptive.SummaryStatistics;

public class StandardDevTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SummaryStatistics s = new SummaryStatistics();
		
		s.addValue(5);
		s.addValue(7);
		s.addValue(5);
		s.addValue(4);
		s.addValue(5);
		
		System.out.println(s.getStandardDeviation()+" "+s.getVariance()+" "+s.getMean());
	}

}
