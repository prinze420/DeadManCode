package com.pdf.parser.test;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

public class PageToImage {

	public static void main(String[] args) throws Exception{
		PDDocument doc = PDDocument.load(new File("Honda-sample-1searchable.pdf"));
		
		PDPage page = (PDPage)doc.getDocumentCatalog().getAllPages().get(0);
		
		System.out.println(page.getBleedBox().getWidth()+"x"+page.getBleedBox().getHeight());
		
//		ImageIO.write(page.convertToImage(), "jpg", new File("00000.jpg")) ;
//		int i=1;
//		for(PDXObjectImage img : page.getResources().getImages().values()){
//			System.out.println(img.getWidth()+"x"+img.getHeight());
//			img.write2file(i+"");
//			//			BufferedImage im = img.getRGBImage();
//////			img.getPDStream().
////			ImageIO.write(im, "png", new File(i+".png"));
////			System.out.println(img.getCOSObject().toString());
//			i++;
//		}
//		
//		for(PDXObject o : page.getResources().getXObjects().values()){
//			System.out.println("Obj") ;
//			
//			((PDPixelMap)o).write2file("2.png");
//		}
		
////		if(doc.isEncrypted())
////			doc.decrypt("");
//		PDFRenderer ren = new PDFRenderer(doc);
//		PDPage p = doc.getPage(0);
		
//		Iterator<COSName> it = p.getResources().getXObjectNames().iterator();
//		while(it.hasNext()){
//			System.out.println(it.next().getCOSObject().toString());
//		}
		
//		doc.getPrintable(0).
//		BufferedImage im = new BufferedImage((int)p.getBleedBox().getWidth(), (int)p.getBleedBox().getHeight(), BufferedImage.TYPE_BYTE_GRAY);
//		
//		PageFormat pf = new PageFormat();
//		pf.setOrientation(pf.PORTRAIT);
		
//		new PDFPageable(doc).getPrintable(0).print(im.getGraphics(), pf, 0); 
//		//		ren.renderPageToGraphics(0, im.createGraphics());
////		BufferedImage img = ren.renderImageWithDPI(0, 300);
//		ImageIO.write(im, "png", new File("Page.png"));
		
//		doc.save("temp.pdf");
		
		doc.close();
	}

}
