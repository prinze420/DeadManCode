package com.pdf.parser.test;

import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.pipeline.DefaultParser;

public class SegmentPrinter {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		String file = "D:/SwissRe/SwissRe-Extraction/Samples/AWD1000/Acord-125-Commercial-Insurance-Application.pdf";
		
		DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();

		for(int page=0; page<parser.getSegments().size(); page++){
			System.out.println("PAGE "+(page+1));
			PDFSegment lastWord = null;
			for(PDFSegment segment : parser.getSegments().get(page)){
				
				if(lastWord!=null){
					float yDiff = Math.abs(lastWord.getRectangle().getY() - segment.getRectangle().getY());
					if(yDiff>segment.getRectangle().getHeight()/2)
						System.out.println();
				}
				System.out.print("{"+segment.getStringRepresentation()+"} ");
				lastWord = segment;
			}
			System.out.println("\n");
		}
	}

}
