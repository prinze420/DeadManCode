package com.pdf.parser.test;

import java.awt.Color;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.io.File;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.edit.PDPageContentStream;
import org.apache.pdfbox.pdmodel.graphics.color.PDGamma;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationTextMarkup;

import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;

public class WordHighlighting {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		String file = "19951835.pdf";

		DefaultParser parser = new DefaultParser(PDDocument.load(new File(file)));
		parser.parse();

		PDDocument pdf = PDDocument.load(file);

		for(int i=0; i<pdf.getDocumentCatalog().getAllPages().size(); i++){
			PDPage page = (PDPage)pdf.getDocumentCatalog().getAllPages().get(i);
			//			System.out.println(page.getMediaBox().getWidth()+" X "+page.getMediaBox().getHeight());

			PDPageContentStream stream = new PDPageContentStream(pdf, page, true, false);
			stream.setStrokingColor(Color.RED);
			stream.setNonStrokingColor(Color.RED);
			stream.setLineWidth(0.3f);

			boolean isRotate = false;//Math.abs(page.getRotation()) == 90 || Math.abs(page.getRotation()) == 270;
			float centerX = page.getBleedBox().getWidth()/2;
			float centerY = page.getBleedBox().getHeight()/2;

			float height = page.getBleedBox().getHeight();
			for(PDFWord word : parser.getWords().get(i)){

				System.out.println(word.getStringRepresentation()+" "+word.getRectangle().getX()+","+word.getRectangle().getX2()+" "+word.getWidthOfSpace());

				float x1 = word.getRectangle().getX();
				float y1 = height - word.getRectangle().getY();
				float x2 = word.getRectangle().getX2();
				float y2 = height - word.getRectangle().getY();

				if(isRotate){
					Point2D p = rotate(page.getRotation(), new Point2D.Float(centerX, centerY), new Point2D.Float(x1, y1));
					x1 = (float)p.getX();
					y1 = (float)p.getY();

					p = rotate(page.getRotation(), new Point2D.Float(centerX, centerY), new Point2D.Float(x2, y2));
					x2 = (float)p.getX();
					y2 = (float)p.getY();
				}

				stream.drawLine(x1, y1, x2, y2);
				
				PDRectangle wr = new PDRectangle();
				wr.setLowerLeftX(x1);
				wr.setLowerLeftY(y1);
				wr.setUpperRightX(x2);
				wr.setUpperRightY(y1 + (word.getRectangle().getHeight()*1.25f));

				final PDGamma c = new PDGamma();
				c.setR((float) 0.9843);
				c.setG((float) 0.9098);
				c.setB((float) 0.3879);

				final float[] quads = new float[8];
				// top left
				quads[0] = wr.getLowerLeftX(); // x1
				quads[1] = wr.getUpperRightY(); // y1
				// bottom left
				quads[2] = wr.getUpperRightX(); // x2
				quads[3] = quads[1]; // y2
				// top right
				quads[4] = quads[0]; // x3
				quads[5] = wr.getLowerLeftY(); // y3
				// bottom right
				quads[6] = quads[2]; // x4
				quads[7] = quads[5]; // y5
				
//				TextHighlight th = new TextHighlight("UTF-8");
				
				if(word.getStringRepresentation().equals("the")){
					PDAnnotationTextMarkup m = new PDAnnotationTextMarkup(PDAnnotationTextMarkup.SUB_TYPE_HIGHLIGHT);
					m.setRectangle(wr);
					m.setColour(c);
					m.setQuadPoints(quads);
					m.setConstantOpacity((float) 0.8);
					m.setPrinted(true);
					m.setContents(word.getStringRepresentation());
					m.setNoRotate(page.getRotation()==null);
					m.setPage(page);
	
					page.getAnnotations().add(m);
				}
			}

			stream.setStrokingColor(Color.BLUE);
			stream.setNonStrokingColor(Color.BLUE);
			for(PDFWord word : parser.getWords().get(i)){
				float x1 = word.getRectangle().getX();
				float y1 = word.getRectangle().getY();
				float x2 = word.getRectangle().getX2();
				float y2 = word.getRectangle().getY();

				if(isRotate){
					Point2D p = rotate(page.getRotation(), new Point2D.Float(centerX, centerY), new Point2D.Float(x1, y1));
					x1 = (float)p.getX();
					y1 = (float)p.getY();

					p = rotate(page.getRotation(), new Point2D.Float(centerX, centerY), new Point2D.Float(x2, y2));
					x2 = (float)p.getX();
					y2 = (float)p.getY();
				}

				stream.drawLine(x1, y1, x2, y2);
			}

			stream.close();
		}

		pdf.save("test_word_highlighting.pdf");
		pdf.close();
	}

	private static Point2D rotate(float angle, Point2D pivot, Point2D point){
		Point2D result = new Point2D.Float();
		AffineTransform rotation = new AffineTransform();
		float angleInRadians = (float)Math.toRadians(angle);
		rotation.rotate(angleInRadians, pivot.getX(), pivot.getY());
		rotation.transform(point, result);
		return result;
	}
}
