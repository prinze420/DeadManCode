package com.pdf.parser.test;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;


public class NLP_OP_Reader {

	List<NLP_Output> NLP_OutputList;


	public List<NLP_Output> readNLP_Output(String nlpexcelPath){
		//		RULE_ID	TEMPLATE_ID	TOPIC	KEYWORDS	EXTRACTION AREA	OPERATION	EXTRACTION TYPE	PATTERN		Comment		
		NLP_OutputList = new ArrayList<NLP_Output>();

		HSSFWorkbook workbook;
		try {
			FileInputStream inputStream = new FileInputStream(new File(nlpexcelPath));

			workbook = new HSSFWorkbook(inputStream);

			int totalSheets = workbook.getNumberOfSheets();

			for (int i = 0; i < totalSheets; i++) {

				HSSFSheet worksheet = workbook.getSheetAt(i);
				Iterator<Row> iterator = worksheet.iterator();
				if(iterator.hasNext()){
					iterator.next();//skip first line
				}

				//Case No	TRADE_NAME	Answer	Extraction Type	Page No	Paragraph	Match Type


				while(iterator.hasNext()){
					Row nextRow = iterator.next();
					String fileName= "",extractedOp="",extractionType="",paragraph="";

					int pagenum=-1;


					if(nextRow.getCell(0)!=null){
						fileName =(nextRow.getCell(0).getStringCellValue());
					}
					if(nextRow.getCell(1)!=null){
						extractedOp = (nextRow.getCell(1).getStringCellValue());
					}

					if(nextRow.getCell(3)!=null){
						extractionType =nextRow.getCell(3).getStringCellValue();
					}


					if(nextRow.getCell(4)!=null && !nextRow.getCell(4).getStringCellValue().trim().isEmpty()){
						pagenum = Integer.valueOf(nextRow.getCell(4).getStringCellValue().trim());
					}

					if(nextRow.getCell(5)!=null){
						paragraph = nextRow.getCell(5).getStringCellValue();
						//						pattern=patternConvertor(pattern);
					}

					if(pagenum !=-1){
						NLP_OutputList.add(new NLP_Output(fileName, extractedOp, extractionType, paragraph, pagenum));
					}
				}
			}
			inputStream.close();
		}
		catch(Exception e){
			//logger.log(Level.ALL, "RuleReader: readInvoiceRules()"+ e.getMessage());
			e.printStackTrace();
		}

		return NLP_OutputList;
	}	

	public static void main(String[] args) {

		String 	nlpexcelPath="D:\\Platform\\Phizer\\TestSample\\eliLilly.xls";
		NLP_OP_Reader n=new NLP_OP_Reader();

		List<NLP_Output> nlpOp = n.readNLP_Output(nlpexcelPath);

		for (NLP_Output nlp_Output : nlpOp) {
			System.out.print(nlp_Output.getFileName()+"\t");
			System.out.print(nlp_Output.getExtractionType()+"\t");
			System.out.println(nlp_Output.getExtractedOp());
		}
		System.out.println("\n\n Done");
	}


}
