package com.pdf.parser.test;

public class NLP_Output {

	//Case No	TRADE_NAME	Answer	Extraction Type	Page No	Paragraph	Match Type

	String fileName,extractedOp,extractionType,paragraph;
	
	int pagenum;
	
	public NLP_Output(String fileName, String extractedOp,
			String extractionType, String paragraph, int pagenum) {
		super();
		this.fileName = fileName;
		this.extractedOp = extractedOp;
		this.extractionType = extractionType;
		this.paragraph = paragraph;
		this.pagenum = pagenum;
	}

	public String getFileName() {
		return fileName;
	}

	public String getExtractedOp() {
		return extractedOp;
	}

	public String getExtractionType() {
		return extractionType;
	}

	public String getParagraph() {
		return paragraph;
	}

	public int getPagenum() {
		return pagenum;
	}
	
	
}
