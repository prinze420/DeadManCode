package com.pdf.parser.nlp;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.Set;

public class StopWords {
	public static final Set<String> SET = new HashSet<String>();
	
	static{
		try{
			BufferedReader reader = new BufferedReader(new InputStreamReader(StopWords.class.getResourceAsStream("config_extraction/stop-words.txt")));
			String line = "";
			while((line = reader.readLine())!=null)
				SET.add(line);
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	//This is only accessing the set of stop-words without modifying it
	//Hence multiple threads can access this function without synchronization
	public static boolean contains(String phrase, NLPTools instance){
		
		phrase = phrase.trim();
		
		if(!phrase.contains(" "))//If single word
			return SET.contains(phrase.toLowerCase());
		
		else{//Check if all words are stop words within the phrase
			boolean isStopWord = true;
			
			for(String word : instance.tokenize(phrase)){
				if(!SET.contains(word.toLowerCase())){
					isStopWord=false;
					break;
				}
			}
			
			return isStopWord;
		}
	}
}
