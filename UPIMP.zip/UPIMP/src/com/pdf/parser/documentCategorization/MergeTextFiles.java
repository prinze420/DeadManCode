package com.pdf.parser.documentCategorization;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MergeTextFiles {
	public static void main(String[] args) {
//		String inputdir = "D:\\Platform\\Phizer\\TextFiles";
//		String Outputpath = "D:\\Platform\\Phizer\\TextFiles";
		String inputdir =args[0];
		String Outputpath =args[1];

		File folder = new File(inputdir);

		List<File>textFiles=new ArrayList<File>();

		if (folder.isDirectory()) {
			File[]  listFiles = folder.listFiles();
			for (File file : listFiles) {
				if(file.getName().endsWith(".txt")){
					textFiles.add(file);
				}
			}
		}
		if(textFiles.size()>0){
			mergeTxtFile(textFiles, Outputpath);
		}

	}
	private static void mergeTxtFile(List<File> files, String Outputpath) {

		FileWriter fstream = null;
		BufferedWriter out = null;
		File resultFile=new File(Outputpath);
		if(resultFile.isDirectory()){
			resultFile=new File(Outputpath+File.separator+"MergedResult.txt");
		}
		try {
			fstream = new FileWriter(resultFile, true);
			out = new BufferedWriter(fstream);
		} catch (IOException e1) {
			e1.printStackTrace();
		}


		for (int i = 0; i < files.size(); i++) {
			File f= files.get(i);
			boolean skipFirstLine=false;
			FileInputStream fis;
			try {
				fis = new FileInputStream(f);
				BufferedReader in = new BufferedReader(new InputStreamReader(fis));

				String aLine;
				while ((aLine = in.readLine()) != null) {
					if(!aLine.trim().isEmpty()){
						if(i!=0 && !skipFirstLine ){
							skipFirstLine=true;
							continue;
						}
						out.write(aLine);
						out.newLine();
					}
				}

				in.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		try {
			out.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}


}
