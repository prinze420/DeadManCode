package com.pdf.parser.documentCategorization;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Set;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;

public class FilePageWriter {

	public static void main(String[] args) {

//"D:\\Platform\\Phizer\\TestSample\\" "D:\\Platform\\Phizer\\others" "D:\\Platform\\Phizer"
		
//		String inputDir="D:\\Platform\\Phizer\\TestSample\\";
//		String allreadyProcessedDir="D:\\Platform\\Phizer\\others";
//		String saveAt="D:\\Platform\\Phizer";
		
		String inputDir=args[0];
		String allreadyProcessedDir=args[1];
		String saveAt=args[2];
		FilePageWriter pw=new FilePageWriter();
		try {

			pw.apply(inputDir,allreadyProcessedDir,saveAt);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void	apply(String inputDir,String allreadyProcessedDir,String saveAt) throws IOException{

		Set<String>processedFiles=new HashSet<String>();
		if(!allreadyProcessedDir.isEmpty()){
			Queue<File> temp = new LinkedList<File>();
			temp.addAll(Arrays.asList(new File(allreadyProcessedDir).listFiles()));

			while(!temp.isEmpty()){
				final File in = temp.poll();
				if(in.isDirectory())//f.getName().startsWith("AWD")){
					temp.addAll(Arrays.asList(in.listFiles()));
				else
				{
					processedFiles.add(in.getName());
				}
			}
		}
		
		
		final BufferedWriter writer = new BufferedWriter(new FileWriter(saveAt+File.separator+"FileName_TotalPages.txt"));
		writer.write("\nFileName\t TotalPages");
		Queue<File> inputQ = new LinkedList<File>();
		inputQ.addAll(Arrays.asList(new File(inputDir).listFiles()));

		while(!inputQ.isEmpty()){
			final File in = inputQ.poll();
			if(in.isDirectory()){//f.getName().startsWith("AWD")){
				inputQ.addAll(Arrays.asList(in.listFiles()));

			}else if(processedFiles.contains(in.getName())){
				System.out.println(in.getName()+"\t ProcessedFiles");
			}
			else if(in.getName().toLowerCase().endsWith(".pdf") && !processedFiles.contains(in.getName()))
			{
				String fileName=in.getName().substring(0, in.getName().lastIndexOf("."));

				PDDocument pdf = null;
				try {
					pdf = PDDocument.load(in);
					if(pdf.isEncrypted()){
						try {
							pdf.decrypt("");
						} catch (CryptographyException e) {
							e.printStackTrace();
						}
					}

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				writer.write("\n"+fileName+"\t"+pdf.getDocumentCatalog().getAllPages().size());
			}
		}
		writer.close();
		System.out.println("End");
	}

}
