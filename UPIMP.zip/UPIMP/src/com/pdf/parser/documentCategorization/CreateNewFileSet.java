package com.pdf.parser.documentCategorization;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Queue;
import java.util.ResourceBundle;
import java.util.Set;

import org.apache.pdfbox.exceptions.COSVisitorException;
import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;



public class CreateNewFileSet{


	static ResourceBundle basicConfig;
	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch(Exception e){
			e.printStackTrace();
		}
	}


	static Set<String> processedDFiles=new HashSet<String>();
	public 	CreateNewFileSet() {

		try{
			BufferedReader reader = new BufferedReader(new FileReader("config/processedFiles.list"));
			String line ="";
			while((line = reader.readLine()) != null){
				if(!line.trim().isEmpty()){
					processedDFiles.add(line.trim());
				}
			}
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws COSVisitorException {
		//"D:\\Platform\\Phizer\\TestSample\\Type4" "D:\\Platform\\Phizer\\TestSample\\Type4"

		String inputDir=args[0];
		String processedFile=args[1];
		String unProcessedFile=args[2];

		int processedFileCount=0;
		int unProcessedFileCount=0;
		Queue<File> inputQ = new LinkedList<File>();
		inputQ.addAll(Arrays.asList(new File(inputDir).listFiles()));

		CreateNewFileSet cs=new CreateNewFileSet(); 
		while(!inputQ.isEmpty()){
			final File in = inputQ.poll();
			if(in.isDirectory()){//f.getName().startsWith("AWD")){
				inputQ.addAll(Arrays.asList(in.listFiles()));

			}else if(processedDFiles.contains(in.getName().substring(0, in.getName().lastIndexOf(".")).trim()))
			{
				processedFileCount++;
				PDDocument pdf = null;
				try {
					pdf = PDDocument.load(in);

					if(pdf.isEncrypted()){
						try {
							pdf.decrypt("");
						} catch (CryptographyException e) {
							e.printStackTrace();
						}
					}

					pdf.save(processedFile+File.separator+in.getName() );

				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				System.out.println(in.getName()+"\t ProcessedFiles");

			}else{
				//unprocessed files
				unProcessedFileCount++;
				PDDocument pdf = null;
				try {
					pdf = PDDocument.load(in);

					if(pdf.isEncrypted()){
						try {
							pdf.decrypt("");
						} catch (CryptographyException e) {
							e.printStackTrace();
						}
					}
					pdf.save(unProcessedFile+File.separator+in.getName() );
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}

			}
		}
		
		System.out.println("\n----------------RESULT---------------------");
		System.out.println("ProcessedFileCount: \t"+processedFileCount);
		System.out.println("UnProcessedFileCount: \t"+unProcessedFileCount);
	}

}

