package com.pdf.parser.ocrQuality;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.base.PDFCharacter;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.MultiThreadHelper;

public class PageNumberWriter {

	static ResourceBundle basicConfig;
	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static Integer Apply(String inputFile){

		File f=new File(inputFile);
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(f);

			if(pdf.isEncrypted()){
				try {
					pdf.decrypt("");
				} catch (CryptographyException e) {
					e.printStackTrace();
				}
			}
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		int pages=pdf.getDocumentCatalog().getAllPages().size();
		return pages;
	}



	private static void saveDirResult(Map<Integer, PageAccuracyRecord> PageAccuracyRecordMap, File file, BufferedWriter writer) {
		try {
			String fileName=file.getName().substring(0, file.getName().lastIndexOf("."));

			for (Integer pgNo : PageAccuracyRecordMap.keySet()) 
			{
				PageAccuracyRecord record = PageAccuracyRecordMap.get(pgNo);

				synchronized (writer) {
					writer.write(fileName+"\t"+record.getPageNum()+"\t"+record.getValidCharacterRatio()+"\t"+
							record.getInValidCharacterRatio()+"\t"+record.getOverlappedRatio()+"\t"+record.getWordAccuracyRatio()+"\t"+record.getTotal_PageWords());
					writer.newLine();
				}
			}
			System.out.println("******---------End of "+file.getName());
		}catch (Exception e){
			e.printStackTrace();
		}
	}

	public static void main(String[] a) throws IOException {
		//dir "D:/Platform/Phizer/TestSample/Result" "D:/Platform/Phizer/TestSample/Result"
		if(a[0].equalsIgnoreCase("dir")){  

			String inputDirPath =a[1];
			final String outputFileDirPath=a[2];

			Queue<File> inputQ = new LinkedList<File>();
			inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));


			String outpuResult=outputFileDirPath+File.separator+"FilePageNum_Result.txt";

			final BufferedWriter writer = new BufferedWriter(new FileWriter(outpuResult));
			writer.write("Sub_ID\t FileName \tTotal_Pages");
			writer.newLine();
			while(!inputQ.isEmpty()){
				final File in = inputQ.poll();
				if(in.isDirectory())//f.getName().startsWith("AWD")){
					inputQ.addAll(Arrays.asList(in.listFiles()));

				else if(in.getName().toLowerCase().endsWith(".pdf")){
					int pageCount = Apply(in.getAbsolutePath());
					writer.write(in.getParentFile().getName()+"\t"+in.getName()+"\t"+pageCount);
					writer.newLine();

				}else if(in.getName().toLowerCase().endsWith(".xlsx") || in.getName().toLowerCase().endsWith(".xls")){
					int pageCount = 1;
					writer.write(in.getParentFile().getName()+"\t"+in.getName()+"\t"+pageCount);
					writer.newLine();
				}else{
					int pageCount = 1;
					writer.write(in.getParentFile().getName()+"\t"+in.getName()+"\t"+pageCount);
					writer.newLine();
				}
				
			}
			writer.close();
		}
		System.out.println("Done");

	}


}
