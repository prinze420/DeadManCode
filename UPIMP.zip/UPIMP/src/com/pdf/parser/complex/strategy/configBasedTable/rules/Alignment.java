package com.pdf.parser.complex.strategy.configBasedTable.rules;

public enum Alignment {
	Left, Right, Overlap, Top, Bottom, Before, Mid, Between;
	
	Alignment(){}
	
	static Alignment getAlignment(String align){
		if(align.equalsIgnoreCase("left"))
			return Left;
		
		else if(align.equalsIgnoreCase("right"))
			return Right;
		
		else if(align.equalsIgnoreCase("top"))
			return Top;
		
		else if(align.equalsIgnoreCase("bottom"))
			return Bottom;
		
		else if(align.equalsIgnoreCase("before"))
			return Before;
		
		else if(align.equalsIgnoreCase("mid") || align.equalsIgnoreCase("middle"))
			return Mid;
		
		else if(align.equalsIgnoreCase("between"))
			return Between;
		
		return Overlap;
	}
}
