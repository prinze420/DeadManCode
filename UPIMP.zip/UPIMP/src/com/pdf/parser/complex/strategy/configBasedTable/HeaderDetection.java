package com.pdf.parser.complex.strategy.configBasedTable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.complex.TableCell;
import com.pdf.parser.complex.strategy.configBasedTable.rules.ColumnRule;
import com.pdf.parser.complex.strategy.configBasedTable.rules.TableRule;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.CommonOperations.DIRECTION;
import com.pdf.parser.utils.CommonOperations.SORT_CRITERIA;

public class HeaderDetection {
	List<PDFSegment> segments;
	List<StructureGroup> segmentPerY;
	TableRule rule;
	int searchStart;
	
	Set<TableCell> headers;
	List<Integer> headerYIndexes;
	
	/**
	 * @param search Start start index for search of headers from segments/words
	 * @param segments
	 * @param rules Meta-data
	 */
	public HeaderDetection(int searchStart, List<PDFSegment> segments, TableRule rule, List<StructureGroup> segmentPerY){
		this.segments = segments;
		this.searchStart = searchStart;
		this.rule = rule;
		this.segmentPerY = new ArrayList<StructureGroup>(segmentPerY);//Copy the list as we might remove the elements temporarily
		headers = new HashSet<TableCell>();
	}
	
	public void detect(){
		
		//*****************************
		//Try and find a bunch of consecutive y coordinates that have segments/words that are part of a rule's column keywords set
		//In other words we first mark the header boundary
		List<Integer> yIndexes = new ArrayList<Integer>();
		
		//rule should have atleast one column head
		if(yIndexes.size()==0 && rule.getColumnHeadWords().size()>0){
			int i=0;
			for(i=searchStart; i<segmentPerY.size(); i++){
				
				//If a y is detected as header, ideally we would want the next line to be the header
				if(yIndexes.size()>0 && i>yIndexes.get(yIndexes.size()-1)+1)
					break;
				
				List<PDFSegment> segments = segmentPerY.get(i).getCastedPDFSegments();
				boolean isEligible = true;
				
				outer:
				for(PDFSegment s : segments){
					if(!rule.getColumnHeadWords().contains(s.getStringRepresentation().toLowerCase())){
						for(String word : s.getStringRepresentation().toLowerCase().split("\\s")){
							if(!rule.getColumnHeadWords().contains(word)){
								isEligible=false;
								break outer;
							}
						}
					}
				}
				
				if(isEligible)
					yIndexes.add(i);
			}
			if(yIndexes.size()>0)
				searchStart = i-1;
		}
		//********************************
		
		if(yIndexes.size()>0){
			
			Map<PDFSegment, List<PDFSegment>> consolidatedSegmentsTracker = new HashMap<PDFSegment, List<PDFSegment>>();
			Map<ColumnRule,Boolean> ruleSuccessTracker = new HashMap<ColumnRule,Boolean>();
			Map<ColumnRule,List<PDFSegment>> possibleHeaders = new HashMap<ColumnRule,List<PDFSegment>>();
			
			for(ColumnRule columnRule : rule.getColumnRules()){
				
//				System.out.println("Debug");
				
				head:
				for(String head : Arrays.asList(columnRule.getHead(), columnRule.getSubHead())){
					if(head.length()>0){
						
						head = head.trim();
						
						//Let's first find a segment if it directly matches the head
						for(int y : yIndexes){
							
							List<PDFSegment> segs = segmentPerY.get(y).getCastedPDFSegments();
							segmentPerY.get(y).setSegments(segs);
							
							Iterator<PDFSegment> it = segs.iterator();
							while(it.hasNext()){
								PDFSegment seg = it.next();
								if(head.toLowerCase().trim().equals(seg.getStringRepresentation().toLowerCase().trim())){
									it.remove();
									possibleHeaders.put(columnRule,Arrays.asList(seg));
									continue head;
								}
							}
						}
						
						//Now the head is present in a broken form
						//Find the first segment that has the starting word
						String[] headWords = head.split("\\s");
						int i=0;
						
						PDFSegment startSegment = null;
						Map<PDFSegment, List<PDFSegment>> brokenSegmentsTracker = new HashMap<PDFSegment, List<PDFSegment>>();
						List<PDFSegment> segmentToBeRemoved = new ArrayList<PDFSegment>();
						String jointPhrase = "";
						
						y:
						for(int y : yIndexes){
							
							String subPhrase = "";
							for(PDFSegment segment : segmentPerY.get(y).getCastedPDFSegments()){
								
								if((startSegment == null || CommonOperations.isOverlapOnX(startSegment, segment)) 
										&& segment.getStringRepresentation().toLowerCase().startsWith(headWords[i].toLowerCase())){
									
									if(startSegment==null)
										startSegment = segment;
									
									for(; i<headWords.length; i++){
										
										//Continue appending until false
										boolean startsWithCondition = segment.getStringRepresentation().toLowerCase().startsWith((subPhrase+" "+headWords[i]).toLowerCase().trim()); 
										if(startsWithCondition){
											
											subPhrase += " "+headWords[i].toLowerCase();
											subPhrase = subPhrase.trim();
											
										}
										
										//If the above condition fails or we find the head word
										if(!startsWithCondition || (jointPhrase+subPhrase).equals(head.toLowerCase().trim())){
											
											if(segment.getStringRepresentation().toLowerCase().equals((subPhrase)))
												segmentToBeRemoved.add(segment);
											
											else if(segment.getStringRepresentation().toLowerCase().startsWith(subPhrase)){
												brokenSegmentsTracker.put(segment, segment.breakSegment(subPhrase));
											}
											
											jointPhrase += subPhrase.trim()+" ";
											
											//We have got the required phrase, hence we can finalize segment removal or breaks
											if((jointPhrase.trim()).equals(head.toLowerCase().trim())){
												jointPhrase = jointPhrase.trim();
												break;
											}else
												//Jump only if you the phrase is incomplete
												continue y;
										}
									}
								
								}
								
								if(jointPhrase.equals(head.toLowerCase().trim())){
									
									List<PDFSegment> columnHeader = new ArrayList<PDFSegment>();
									possibleHeaders.put(columnRule,columnHeader);
									
									outer:
									for(int y1 : yIndexes){
										
										List<PDFSegment> ySegments = segmentPerY.get(y1).getCastedPDFSegments();
										segmentPerY.get(y1).setSegments(ySegments);
										
										Iterator<PDFSegment> it = ySegments.iterator();
										while(it.hasNext()){
											PDFSegment seg = it.next();
											
											//Replace the segment with the second part of the broken segment
											//This will avoid the first part to be considered in any of the next headers excavation
											if(brokenSegmentsTracker.containsKey(seg)){
												ySegments.set(ySegments.indexOf(seg), brokenSegmentsTracker.get(seg).get(1));
												columnHeader.add(brokenSegmentsTracker.get(seg).get(0));
											
											}else if(segmentToBeRemoved.contains(seg)){
												columnHeader.add(seg);
												it.remove();
											}
											
											if(columnHeader.size()==brokenSegmentsTracker.size()+segmentToBeRemoved.size())
												break outer;
										}
									}
									
									consolidatedSegmentsTracker.putAll(brokenSegmentsTracker);
									ruleSuccessTracker.put(columnRule, true);
									
									segmentToBeRemoved.clear();
									brokenSegmentsTracker.clear();
									
									continue head;
								}
							}
						}
					}
				}
			}
			
			//By now the segmentPerY should be empty for yIndices
//			boolean isEmpty=true;
//			for(int y : yIndexes){
//				if(segmentPerY.get(y).getSegments().size()>0){
//					isEmpty = false;
//					break;
//				}
//			}
			int ruleSegments = 0;
			for(ColumnRule c : rule.getColumnRules()){
				if(c.getHead().trim().length()>0)
					ruleSegments++;
				if(c.getSubHead().trim().length()>0)
					ruleSegments++;
			}
			
			if(possibleHeaders.size() == ruleSegments){
				for(PDFSegment seg : consolidatedSegmentsTracker.keySet()){
					int index = segments.indexOf(seg);
					segments.remove(index);
					segments.add(index, consolidatedSegmentsTracker.get(seg).get(0));
					segments.add(index+1, consolidatedSegmentsTracker.get(seg).get(1));
				}
				
				for(ColumnRule rule : possibleHeaders.keySet()){
					
					List<PDFSegment> segments = possibleHeaders.get(rule);
					
					List<BasicStructure> xSorted = CommonOperations.sort(segments, SORT_CRITERIA.X, DIRECTION.MIN);
					float x = xSorted.get(0).getRectangle().getX();
					
					List<BasicStructure> x2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.X2, DIRECTION.MAX);
					float x2 = x2Sorted.get(0).getRectangle().getX2();
					
					List<BasicStructure> ySorted = CommonOperations.sort(segments, SORT_CRITERIA.Y, DIRECTION.MAX); //Y increases as origin is top-left
					float y = ySorted.get(0).getRectangle().getY();
					
					List<BasicStructure> y2Sorted = CommonOperations.sort(segments, SORT_CRITERIA.Y2, DIRECTION.MIN); //Y2 decreases as origin is top-left
					float y2 = y2Sorted.get(0).getRectangle().getY2();
					
					float w = x2 - x;
					float h = y - y2;
					
					int page = segments.get(0).getRectangle().getPage();
					
					String cell = "";
					for(PDFSegment seg : segments)
						cell += seg.getStringRepresentation()+" ";
					
					Map<Integer, List<PDFSegment>> pageWiseSegments = new HashMap<Integer, List<PDFSegment>>();
					pageWiseSegments.put(0, segments);
					
					List<DPRectangle> rects = new ArrayList<DPRectangle>();
					rects.add(new DPRectangle(x, y, w, h, page));
					
					headers.add(new TableCell(rects, cell.trim(), StructureType.TABLE_CELL, pageWiseSegments, true, rule));
				}
				headerYIndexes = yIndexes;
			}
		}
	}

	public Set<TableCell> getHeaders() {
		return headers;
	}

	public int getSearchStart() {
		return searchStart;
	}

	public List<StructureGroup> getSegmentPerY() {
		return segmentPerY;
	}
}
