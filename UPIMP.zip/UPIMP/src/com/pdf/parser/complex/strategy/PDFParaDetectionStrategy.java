package com.pdf.parser.complex.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.SegmentGroup;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.nlp.NLPTools;
import com.pdf.parser.utils.CommonOperations;

public class PDFParaDetectionStrategy implements Strategy<Map<Integer, List<PDFPara>>> {

	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("complex-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	private Map<Integer, List<PDFPara>> pageWisePara;
	//private Map<Integer, List<BasicStructure>> segmentsInParaPerPage;
	//private int totalPages;
	private List<PDPage> pages;
	private int startPage;
	private Map<Integer, List<PDFSegment>> pageWiseSegments;
	//	Map<Integer, List<PDFVerticalGap>> pageWiseVGaps;

	public PDFParaDetectionStrategy(Map<Integer, List<PDFSegment>> pageWiseSegments, List<PDPage> pages, int startPage){
		this.pageWiseSegments = pageWiseSegments;
		//	this.pageWiseVGaps = pageWiseVGaps;
		this.pages = pages;
		//this.totalPages = pages.size();
		this.startPage=startPage;
		pageWisePara = new TreeMap<Integer, List<PDFPara>>();
		//segmentsInParaPerPage = new TreeMap<Integer, List<BasicStructure>>();
		NLPTools.init();
	}

	public void apply() {

		pageWisePara=findIndividualParas(pageWiseSegments);


		//Enumerate the para if the first segment is enumerated
		for(List<PDFPara> paras : pageWisePara.values()){
			para:
				for(PDFPara para : paras){
					Iterator<Entry<Integer, List<BasicStructure>>> iterator = para.getSegments().entrySet().iterator();
					while(iterator.hasNext()){

						List<BasicStructure> segments = iterator.next().getValue();
						if(segments.size()==0){
							iterator.remove();
							continue;
						}

						if(((PDFSegment)segments.get(0)).isEnumerated()){
							para.setEnumerated(true);
							para.setEnumeration(((PDFSegment)segments.get(0)).getEnumeration());
						}

						continue para;
					}
				}
		}

		//Merge paras across pages

		if(config.getString("mergeEnumBasedPara").equalsIgnoreCase("true")){
			enumBasedMergeParasAcrossPages();
		}
		if(config.getString("mergeParas").equalsIgnoreCase("true") && !config.getString("mergeEnumBasedPara").equalsIgnoreCase("true")){
			mergeParasAcrossPages();
		}

		//Fill segments in paras, per page map
		//This will help us while formulating hierarchy
		//for(int i=0; i<totalPages; i++){
//		for (Integer i : pageWisePara.keySet()) {
//
//			if(pageWisePara.containsKey(i)){
//				List<BasicStructure> paraSegments = new ArrayList<BasicStructure>();
//				segmentsInParaPerPage.put(i, paraSegments);
//
//				for(PDFPara paras : pageWisePara.get(i)){
//					if(!paras.getSegments().isEmpty())
//					paraSegments.addAll(paras.getSegments().get(i));
//				}
//			}
//		}
	}

	//	private void findIndividualParas() {
	//		Map<Integer,Float> pageWiseElectedDiff = new TreeMap<Integer, Float>();
	//		float minFrequencyFactor = Float.valueOf(config.getString("minFrequencyFactor"));
	//		
	//		//*********Find page wise min diffs for segment's y-diff
	//		//We are planning to ignore those segments that are aligned with vgaps for now. These
	//		//will either be a part of a table of independent para blocks
	//		for(int page=0; page<totalPages; page++){
	//			
	////			if(page == 3)
	////				System.out.println();
	//			
	//			if(!pageWiseSegments.containsKey(page))
	//				continue;
	//			
	//			List<PDFSegment> segments = pageWiseSegments.get(page);
	//			
	//			List<StructureGroup> segmentsPerY = Commons.groupStructuresOnY(segments);
	//			List<NewDiffFrequency> diffFrequency = new ArrayList<DiffFrequency>();
	//			
	//			for(int i=0; i<segmentsPerY.size()-1; i++){
	//				PDFSegment s1 = segmentsPerY.get(i).getCastedPDFSegments().get(0);
	//				PDFSegment s2 = segmentsPerY.get(i+1).getCastedPDFSegments().get(0);
	//				
	//				if(isOverlap(s1, pageWiseVGaps.get(page)) || isOverlap(s2, pageWiseVGaps.get(page)))
	//					continue;
	//				
	//				//We are choosing diff based on both y instead of y and y2. Because y2 usually varies a lot depending
	//				//on the characters in a word. Y being at the base, is more consistent.
	//				DiffFrequency diff = new DiffFrequency(Math.abs(s1.getRectangle().getY() - s2.getRectangle().getY()), 1);
	//				int index = diffFrequency.indexOf(diff);
	//				if(index == -1)
	//					diffFrequency.add(diff);
	//				else{
	//					diff = diffFrequency.get(index);
	//					diff.setFreq(diff.getFreq()+1);
	//				}
	//			}
	//			
	//			if(diffFrequency.size()==0)
	//				continue;
	//			
	//			Collections.sort(diffFrequency, new Comparator<DiffFrequency>() {
	//				@Override
	//				public int compare(DiffFrequency o1, DiffFrequency o2) {
	//					return Float.valueOf(o1.getDiff()).compareTo(o2.getDiff());
	//				}
	//			});
	//			
	//			float diff = -1;
	//			//if diff frequency is acceptable for the minimum diff on page, in terms of number of segments
	//			//This is usually helpful where there are a lot of single line enumerated segments but only a few multi-line enumerated segments
	//			if(diffFrequency.get(0).getFreq() > segments.size()*minFrequencyFactor){
	//				diff = diffFrequency.get(0).getDiff();
	//			
	//			//Else we can always go with the most frequent difference
	//			}else{
	//				Collections.sort(diffFrequency, new Comparator<DiffFrequency>() {
	//					@Override
	//					public int compare(DiffFrequency o1, DiffFrequency o2) {
	//						return Integer.valueOf(o2.getFreq()).compareTo(o1.getFreq());
	//					}
	//				});
	//				diff = diffFrequency.get(0).getDiff();
	//			}
	//			
	//			//Increment the diff by the same amount of percentage so that all the para formations can be with less than condition
	//			//No need to calculate percentage diff every time
	//			pageWiseElectedDiff.put(page, diff*(1+DiffFrequency.allowedPercentageDiff));
	//		}
	//		//***********************
	//		
	//		for(int page=0; page<totalPages; page++){
	//			
	//			if(!pageWiseSegments.containsKey(page))
	//				continue;
	//			
	//			List<PDFSegment> segments = pageWiseSegments.get(page);
	//			
	//			List<PDFPara> paras = new ArrayList<PDFPara>(); 
	//			pageWisePara.put(page, paras);
	//			
	//			List<PDFSegment> paraSegments = new ArrayList<PDFSegment>();
	//			for(int i=0; i<segments.size()-1; i++){
	//				
	//				if(page==3 && segments.get(i+1).getStringRepresentation().equals("Part 4"))
	//					System.out.println("debug");
	//				
	//				PDFSegment s1 = segments.get(i);
	//				PDFSegment s2 = segments.get(i+1);
	//				
	//				float diff = Math.abs(s1.getRectangle().getY() - s2.getRectangle().getY());
	//				
	//				//The next segment should not be enumerated
	//				if(pageWiseElectedDiff.get(page)!=null && diff<pageWiseElectedDiff.get(page) && !s2.isEnumerated()){
	//					if(paraSegments.size()==0)//Only the first time for each para
	//						paraSegments.add(s1);
	//					
	//					paraSegments.add(s2);
	//					
	//					//But if it's the last iteration
	//					if(i == segments.size()-2){
	//						paras.add(PDFPara.create(paraSegments));
	//						paraSegments.clear();
	//					}
	//				
	//				}else if(paraSegments.size()>1){
	//					paras.add(PDFPara.create(paraSegments));
	//					paraSegments.clear();
	//					
	//					//But if it's the last iteration
	//					if(i == segments.size()-2)
	//						paras.add(PDFPara.create(Arrays.asList(s2)));
	//				
	//				}else if(paraSegments.size() == 0){
	//					paras.add(PDFPara.create(Arrays.asList(s1)));//Create with only s1, s2 might form para with next set of segments
	//					
	//					//But if it's the last iteration
	//					if(i == segments.size()-2)
	//						paras.add(PDFPara.create(Arrays.asList(s2)));
	//				}
	//			}
	//			
	//			if(pageWisePara.get(page).size()==0)
	//				pageWisePara.remove(page);
	//		}
	//	}

	private Map<Integer, List<PDFPara>> findIndividualParas(Map<Integer, List<PDFSegment>> multColumnSegs) {
		boolean enumBasedParaFormation=false;
		if(config.getString("enumBasedParaFormation").equalsIgnoreCase("true")){
			enumBasedParaFormation=true;
		}
		Map<Integer,Float> columnWiseElectedDiff=columnWiseElectedDiff(multColumnSegs);
		//***********************
		boolean pageEnumerationFlag=false;
		boolean nextEnumFlag=false;
		boolean startPageFlag=false;

		for (Integer pageIndex : multColumnSegs.keySet()) {

			if(!multColumnSegs.containsKey(pageIndex))
				continue;
			if(!startPageFlag  && pageIndex >= startPage){
				startPageFlag=true;
			}
			List<PDFPara> paras = new ArrayList<PDFPara>();
			//			PDRectangle pageTrimBox=pages.get(pdPageNo).getTrimBox();
			//Page pgn=new Page(pg, pageTrimBox.getLowerLeftX(), pageTrimBox.getLowerLeftY(), pageTrimBox.getWidth(), pageTrimBox.getHeight(),new ArrayList<Structure>(),-1,StructureType.PAGE);
			pageWisePara.put(pageIndex, paras);

			List<PDFSegment> paraSegments = new ArrayList<PDFSegment>();

			List<PDFSegment> colSegments = multColumnSegs.get(pageIndex);
			if(startPageFlag){
				if(nextEnumFlag){
					pageEnumerationFlag=true;
				}else{
					pageEnumerationFlag=false;
				}
			}
			if(colSegments.size()==1){
				paras.add(PDFPara.create(colSegments));
				continue;
			}
			for(int i=0; i < colSegments.size()-1; i++){
				PDFSegment prevSeg =null;
				if(i>0){
					prevSeg = colSegments.get(i-1);
				}
				PDFSegment s1 = colSegments.get(i);
				PDFSegment s2 = colSegments.get(i+1);

				if(s1.getStringRepresentation().contains("Facebook | Twitter | LinkedIn")){
					System.out.print("");
				}
				boolean s2StartsWithLowerOrSymbolOrNum = s2StartsWithLowerOrSymbolOrNum(s2.getStringRepresentation());

				if(startPageFlag){
					if(s1.isEnumerated()){
						pageEnumerationFlag=true;
					}
					if(pageEnumerationFlag){
						nextEnumFlag=checkNextEnum(s1,pageIndex,multColumnSegs);
					}
				}

				//s1 and s2 gap difference 
				boolean s1s2CharHeightBasedDiff=false;
				int val1 = (int)(s2.getRectangle().getY2()-s1.getRectangle().getY());
				float height = s2.getWords().get(0).getCharacters().get(0).getRectangle().getHeight();
				if((val1)> 0 && (val1) < height || CommonOperations.isOverlapOnY(s1, s2)){
					s1s2CharHeightBasedDiff=true;
				}

				float diff = Math.abs(s1.getRectangle().getY() - s2.getRectangle().getY());
				//				boolean s1EndsWithpunctuation=isEndWithPunctuation(s1.getStringRepresentation());
				//				boolean s2EndsWithpunctuation=isEndWithPunctuation(s2.getStringRepresentation());


				//if  y diff is same for all line then is s1 (x2) shoud be > 50%(s2(x2))

				//	float x2diff = Math.abs(s1.getRectangle().getX2() - s2.getRectangle().getX2());

				// finally add in previous list  i.e. paraSegments and create para // max depends on s2 segment


				if(enumBasedParaFormation && pageEnumerationFlag  && nextEnumFlag && startPageFlag  ){
					//----------------breaking conditions ...............
					if(	s2.isEnumerated())
					{
						if(!paraSegments.contains(s1)){
							paraSegments.add(s1);
						}
						PDFPara p = PDFPara.create(paraSegments);
						paras.add(p);
						paraSegments.clear();
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));

					}else if(!s2.isEnumerated() )
					{
						if(paraSegments.size()==0)//Only the first time for each para
							paraSegments.add(s1);

						paraSegments.add(s2);

						//But if it's the last iteration
						if(i == colSegments.size()-2){
							paras.add(PDFPara.create(paraSegments));
							paraSegments.clear();
						}

					}else if(paraSegments.size()>1)
					{
						paras.add(PDFPara.create(paraSegments));
						paraSegments.clear();

						//But if it's the last iteration
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));

					}else if(paraSegments.size() == 0)
					{
						paras.add(PDFPara.create(Arrays.asList(s1)));//Create with only s1, s2 might form para with next set of segments

						//But if it's the last iteration
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));
					}

				}else{
					//----------------breaking conditions...............
					if(
							((diff > columnWiseElectedDiff.get(pageIndex) )&&(s2.getRectangle().getY()!=s1.getRectangle().getY()&& /*s1EndsWithpunctuation && s2EndsWithpunctuation &&*/ !s2StartsWithLowerOrSymbolOrNum))
							||(diff > 2*columnWiseElectedDiff.get(pageIndex) && columnWiseElectedDiff.get(pageIndex)>0) //if too much different then split it
							||(s1.isEnumerated()&& s1.getEnumeration()!=null 					
							&& !s2.isEnumerated()
							//&&(s1.getRectangle().getY()!=s2.getRectangle().getY()) 
							&& !s2StartsWithLowerOrSymbolOrNum ) 

							)
					{
						if(!paraSegments.contains(s1)){
							paraSegments.add(s1);
						}
						PDFPara p = PDFPara.create(paraSegments);
						paras.add(p);
						paraSegments.clear();
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));

					}else if((columnWiseElectedDiff.get(pageIndex)> 0 && (diff < columnWiseElectedDiff.get(pageIndex) ||s1s2CharHeightBasedDiff)  
							&& !s2.isEnumerated() )
							//						&& !s1EndsWithpunctuation
							//						&& !s2EndsWithpunctuation 
							//						||(s1.isEnumerated() && !s1.getStringRepresentation().trim().endsWith(".")&&!s1EndsWithpunctuation
							//								&&!s2.isEnumerated() && s2StartsWithLowerOrSymbolOrNum )//check y difference is necessory or not

							||((columnWiseElectedDiff.get(pageIndex)> 0 && diff < columnWiseElectedDiff.get(pageIndex) ||s1s2CharHeightBasedDiff )
									&&!s2.isEnumerated() 
									&& s2StartsWithLowerOrSymbolOrNum )
							){
						if(paraSegments.size()==0)//Only the first time for each para
							paraSegments.add(s1);

						paraSegments.add(s2);

						//But if it's the last iteration
						if(i == colSegments.size()-2){
							paras.add(PDFPara.create(paraSegments));
							paraSegments.clear();
						}

					}else if(paraSegments.size()>1)
					{
						paras.add(PDFPara.create(paraSegments));
						paraSegments.clear();

						//But if it's the last iteration
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));

					}else if(paraSegments.size() == 0)
					{
						paras.add(PDFPara.create(Arrays.asList(s1)));//Create with only s1, s2 might form para with next set of segments

						//But if it's the last iteration
						if(i == colSegments.size()-2)
							paras.add(PDFPara.create(Arrays.asList(s2)));
					}
				}
			}


			//			if(mColumnWisePDFPAra.get(colIndex).size()==0)
			//				mColumnWisePDFPAra.remove(colIndex);
		}

		return pageWisePara;
	}


	private boolean checkNextEnum(PDFSegment s1, Integer colIndex, Map<Integer, List<PDFSegment>> pageSegs) {
		boolean match=false;
		for (PDFSegment seg : pageSegs.get(colIndex)) {
			if(s1.equals(seg) && !match ){
				match=true;
				continue;
			}
			if(match){
				if(seg.isEnumerated()){
					return true;
				}
			}
		}
		// if current page does not contain enum text check next page 
		if(pageSegs.containsKey(colIndex+1)){

			for (PDFSegment seg : pageSegs.get(colIndex+1)) {
				if(seg.isEnumerated()){
					return true;
				}
			}
		}

		return false;
	}


	public  List<String> punctuationsList =Arrays.asList(":,:-".split(","));

	public  boolean isEndWithPunctuation(String inputString) {
		for (String string : punctuationsList) {
			if(inputString.trim().endsWith(string.trim())){
				return true;
			}
		}
		return false;
	}
	public static boolean s2StartsWithLowerOrSymbolOrNum(String s2Text) {
		// TODO Auto-generated method stub

		if(s2Text.trim().matches("[a-z].*"))return true;
		if(s2Text.matches("[0-9].*"))return true; 
		if(s2Text.matches("[#��,&'$!%@()/\"].*"))return true;

		if(s2Text.matches("[0-9].*"))return true;

		return false;
	}
	private Map<Integer, Float> columnWiseElectedDiff(Map<Integer, List<PDFSegment>> multColumnSegs) {

		Map<Integer,Float> pageWiseElectedDiff = new TreeMap<Integer, Float>();

		float minFrequencyFactor = Float.valueOf(config.getString("minFrequencyFactor"));

		//*********Find page wise min diffs for segment's y-diff
		//We are planning to ignore those segments that are aligned with vgaps for now. These
		//will either be a part of a table of independent para blocks
		int totalColumns=multColumnSegs.keySet().size();

		for (Integer colIndex : multColumnSegs.keySet()) {		

			//		for(int colIndex=0; colIndex<totalColumns; colIndex++){
			//
			//			if(!multColumnSegs.containsKey(colIndex)){


			//				continue;

			List<PDFSegment> segments = multColumnSegs.get(colIndex);

			List<SegmentGroup> segmentsPerY = CommonOperations.groupSegmentsOnY(segments);
			List<NewDiffFrequency> diffFrequency = new ArrayList<NewDiffFrequency>();

			for(int i=0; i<segmentsPerY.size()-1; i++){
				PDFSegment s1 = segmentsPerY.get(i).getCastedPDFSegments().get(0);
				PDFSegment s2 = segmentsPerY.get(i+1).getCastedPDFSegments().get(0);
				String seg1GropuText="";
				for ( PDFSegment segg : segmentsPerY.get(i).getCastedPDFSegments()) {
					seg1GropuText= seg1GropuText+" "+segg.getStringRepresentation();
				}
				String seg2GropuText="";
				for ( PDFSegment segg : segmentsPerY.get(i+1).getCastedPDFSegments()) {
					seg2GropuText= seg2GropuText+" "+segg.getStringRepresentation();
				}

				if(s1.isEnumerated() || /*checkSegIsTitle(seg1GropuText) ||*/ s2.isEnumerated()/*|| checkSegIsTitle(seg2GropuText)*/){
					continue;
				}
				//				if(isOverlap(s1, pageWiseVGaps.get(pdPageNo)) || isOverlap(s2, pageWiseVGaps.get(pdPageNo)))
				//					continue;

				//We are choosing diff based on both y instead of y and y2. Because y2 usually varies a lot depending
				//on the characters in a word. Y being at the base, is more consistent.
				NewDiffFrequency diff = new NewDiffFrequency(Math.abs(s1.getRectangle().getY() - s2.getRectangle().getY()), 1);
				int index = diffFrequency.indexOf(diff);
				if(index == -1)
					diffFrequency.add(diff);
				else{
					diff = diffFrequency.get(index);
					diff.setFreq(diff.getFreq()+1);
				}
			}

			Collections.sort(diffFrequency, new Comparator<NewDiffFrequency>() {
				@Override
				public int compare(NewDiffFrequency o1, NewDiffFrequency o2) {
					return Float.valueOf(o1.getDiff()).compareTo(o2.getDiff());
				}
			});

			float diff = -1;
			//if diff frequency is acceptable for the minimum diff on page, in terms of number of segments
			//This is usually helpful where there are a lot of single line enumerated segments but only a few multi-line enumerated segments
			if(diffFrequency!=null && diffFrequency.size()>0 && diffFrequency.get(0).getFreq() > segments.size()*minFrequencyFactor){
				diff = diffFrequency.get(0).getDiff();

				//Else we can always go with the most frequent difference
			}else if(diffFrequency!=null && diffFrequency.size()>0){
				Collections.sort(diffFrequency, new Comparator<NewDiffFrequency>() {
					@Override
					public int compare(NewDiffFrequency o1, NewDiffFrequency o2) {
						return Integer.valueOf(o2.getFreq()).compareTo(o1.getFreq());
					}
				});
				diff = diffFrequency.get(0).getDiff();
			}
			if(diff==-1){
				System.out.print(" ");
			}
			//Increment the diff by the same amount of percentage so that all the para formations can be with less than condition
			//No need to calculate percentage diff every time
			pageWiseElectedDiff.put(colIndex, diff*(1+NewDiffFrequency.allowedPercentageDiff));
		}
		return pageWiseElectedDiff;
	}

	private void enumBasedMergeParasAcrossPages(){

		//for(int page=0; page<totalPages-1; page++){
		for (Integer page : pageWisePara.keySet()) {

			if(!pageWisePara.containsKey(page) || !pageWisePara.containsKey(page+1)|| pageWisePara.get(page+1).isEmpty())
				continue;

			if(page < startPage){
				continue;
			}
			PDFPara nextPara = pageWisePara.get(page+1).get(0);
			boolean nxtPageEnumPresent=false;
			for (PDFPara nxtPageEnum : pageWisePara.get(page+1)) {
				if(nxtPageEnum.isEnumerated()){
					nxtPageEnumPresent=true;
					break;
				}
			}

			if(nextPara.isEnumerated())
				continue;
			List<PDFPara> paras = pageWisePara.get(page);

			if(paras==null || paras.isEmpty())
				continue;

			PDFPara lastPara = paras.get(paras.size()-1);

			if(lastPara.isEnumerated() && !nextPara.isEnumerated() && nxtPageEnumPresent){
				//Finally merge both paras
				lastPara.merge(nextPara, page+1);
				//Remove next para after merge
				pageWisePara.get(page+1).remove(0);
			}
		}
	}

	/**
	 * 1. The X2 of the last word of the last segment should be nearbout the max X2 in the para
	 * 2. The last word should not end with a ./?/!
	 * 2. The para on the next page should not be enumerated
	 */
	private void mergeParasAcrossPages(){

		int lastSegmentX2Tolerance = Integer.valueOf(config.getString("lastSegmentX2Tolerance"));
		float lastSegmentYThreshold = Float.valueOf(config.getString("lastSegmentYThreshold"));

		//for(int page=0; page<totalPages-1; page++){
		for (Integer page : pageWisePara.keySet()) {
			if(!pageWisePara.containsKey(page) || !pageWisePara.containsKey(page+1) ||pageWisePara.get(page+1).isEmpty())
				continue;

			PDFPara nextPara = pageWisePara.get(page+1).get(0);
			if(nextPara.isEnumerated())
				continue;
			BasicStructure firstSeg = nextPara.getSegments().get(page+1).get(0);

			List<PDFPara> paras = pageWisePara.get(page);
			PDFPara lastPara = paras.get(paras.size()-1);

			List<BasicStructure> lastParaSegs = new ArrayList<BasicStructure>(lastPara.getSegments().get(page));

			Collections.sort(lastParaSegs, new Comparator<BasicStructure>() {
				public int compare(BasicStructure o1, BasicStructure o2) {
					return Float.valueOf(o2.getRectangle().getX2()).compareTo(o1.getRectangle().getX2());
				}
			});
			float maxX2 = lastParaSegs.get(0).getRectangle().getX2();

			lastParaSegs = lastPara.getSegments().get(page);
			BasicStructure lastSeg = lastParaSegs.get(lastParaSegs.size()-1); 
			float segX2 = lastSeg.getRectangle().getX2();

			//X2 and Y should be within tolerance for the last segment
			if(Math.abs(maxX2 - segX2) <= lastSegmentX2Tolerance 
					&& lastSeg.getRectangle().getY() > pages.get(page).getBleedBox().getHeight()*(1-lastSegmentYThreshold)){

				String lastChar = lastSeg.getStringRepresentation().trim().charAt(lastSeg.getStringRepresentation().length()-1)+"";
				if(!Arrays.asList(".","?","!").contains(lastChar)){

					//Now let's apply a similar check of X and Y2 for the next Para's first segment
					lastParaSegs = new ArrayList<BasicStructure>(nextPara.getSegments().get(page+1));
					Collections.sort(lastParaSegs, new Comparator<BasicStructure>() {
						public int compare(BasicStructure o1, BasicStructure o2) {
							return Float.valueOf(o1.getRectangle().getX()).compareTo(o2.getRectangle().getX());
						}
					});
					float minX = lastParaSegs.get(0).getRectangle().getX();

					float segX = firstSeg.getRectangle().getX();

					if(Math.abs(minX - segX) <= lastSegmentX2Tolerance && firstSeg.getRectangle().getY() < pages.get(page).getBleedBox().getHeight()*lastSegmentYThreshold){

						//Finally merge both paras
						lastPara.merge(nextPara, page+1);

						//Remove next para after merge
						pageWisePara.get(page+1).remove(0);
					}
				}
			}

		}
	}

	/*private boolean isOverlap(PDFSegment seg, List<PDFVerticalGap> vgaps){

		for(PDFVerticalGap vgap : vgaps)
			return Commons.isOverlapOnY(seg, vgap);

		return false;
	}*/

	public Map<Integer, List<PDFPara>> getOutcome() {
		return pageWisePara;
	};

	//	public static void main(String[] args) throws Exception{
	//		DefaultParser dp = new DefaultParser(PDDocument.load(new File("SwissRe-Sample/AWD100184/AWD100184.pdf")));
	//		dp.parse();
	//		
	//		PDFParaDetectionStrategy s = new PDFParaDetectionStrategy(dp.getSegments(), dp.getVgaps(), dp.getPdfPages());
	//		s.apply();
	//		
	//		for(List<PDFPara> paras : s.getOutcome().values()){
	//			for(PDFPara para : paras){
	//				System.out.println("***********PARAGRAPH");
	//				System.out.println(para);
	//				System.out.println("*************************\n");
	//			}
	//		}
	//	}
}

class NewDiffFrequency{
	float diff;
	int freq;

	static final float allowedPercentageDiff = 0.2f;

	public NewDiffFrequency(float diff, int freq) {
		this.diff = diff;
		this.freq = freq;
	}

	public String toString(){
		return diff+"/"+freq;
	}

	public boolean equals(Object o){
		if(o instanceof NewDiffFrequency){
			NewDiffFrequency d = (NewDiffFrequency)o;
			float per = Math.abs(d.getDiff() - diff)/diff;

			return d.getDiff() == diff || per <= allowedPercentageDiff;//Less than 20% difference
		}
		return false;
	}

	public float getDiff() {
		return diff;
	}

	public int getFreq() {
		return freq;
	}

	public void setFreq(int freq) {
		this.freq = freq;
	}

}