package com.pdf.parser.complex.strategy.headings;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.PDFSegment;

public class SimpleHeadingDetector implements Strategy<Map<Integer,List<PDFSegment>>>{
	
	Map<Integer,List<PDFSegment>> pageHeadings = new HashMap<Integer,List<PDFSegment>>();
	List<PDFSegment> segments;
	String configPath;
	
	public SimpleHeadingDetector(List<PDFSegment> segments, String configPath) {
		this.segments = segments;
		this.configPath = configPath;
	}
	
	/**
	 * It will record the heading segments based on a list file. Also it will remove the respective segments from the input list.
	 */
	@Override
	public void apply() {
		
		try {
			BufferedReader reader = new BufferedReader(new FileReader(configPath));
			
			reader.close();
			
			Iterator<PDFSegment> it = segments.iterator();
			while(it.hasNext()){
				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public Map<Integer, List<PDFSegment>> getOutcome() {
		return pageHeadings;
	}
	
	
}
