package com.pdf.parser.extraction;


import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.Structure;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.KeyValuePair;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.rules.ExtractionRule;
import com.pdf.parser.rules.Extraction_Result;
import com.pdf.parser.utils.CommonOperations;

import edu.stanford.nlp.util.Comparators;

public class RuleProcessor {

	private Map<Integer, List<PDFSegment>> segGroups=new HashMap<Integer, List<PDFSegment>>();
	private Set<ExtractionRule> rules=new HashSet<ExtractionRule>();
	private Map<Integer, List<PDFPara>> pageWiseParas;
	private int startPage;
	private List<Structure> kVP=new ArrayList<Structure>();
	private List<PDPage> pdPages=new ArrayList<PDPage>();

	static ResourceBundle basicConfig;
	//private  List<String>columnKyeWords=new ArrayList<String>();
	private Map<Integer, List<DPCell>> pageWiseCells;
	private static Map<Integer,BufferedImage> pageAndImage;//=new TreeMap<Integer, BufferedImage>();

	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public RuleProcessor(List<PDPage> pdPages,Map<Integer, List<PDFSegment>> segGroups, Set<ExtractionRule> rules, Map<Integer, List<PDFPara>> pageWiseParas, int startPage, List<Structure> kVP, Map<Integer, List<DPCell>> pageWiseCells) {
		this.pdPages=pdPages;
		this.segGroups=segGroups;
		this.rules=rules;
		this.pageWiseParas=pageWiseParas;
		this.startPage=startPage;
		this.kVP=kVP;
		this.pageWiseCells=pageWiseCells;
		//this.pageAndImage=pageAndImage;
		pageAndImage=new TreeMap<Integer, BufferedImage>();

		/*try{
			BufferedReader reader = new BufferedReader(new FileReader("config/phizerColumnIndicator.list"));
			String line ="";
			while((line = reader.readLine()) != null)
				columnKyeWords.add(line.trim());
			reader.close();

		}catch(Exception e){
			e.printStackTrace();
		}*/

	}

	public  List<Extraction_Result> process(List<PDFSegment> ruleTitles){

		List<Extraction_Result> fresh = new ArrayList<Extraction_Result>();

		for( ExtractionRule rule : rules){

			try{
				if(rule.getTemplateID()==2000 && rule.getRuleId()==6){
					System.out.print("");
				}
				String inputKeyword = rule.getKeywords();
				if(!inputKeyword.trim().isEmpty() && inputKeyword.contains("##")){
					inputKeyword=inputKeyword.split("##")[0];
				}

				int getGroup=-2;
				if(rule.getExtractionArea().equalsIgnoreCase("paragraph")){

					if(rule.getDataType().toLowerCase().contains("pattern")){
						List<String> val=getRegexData("([0-9])", rule.getDataType(), 1);

						if(!val.isEmpty() && val.get(0).trim().matches("[0-9]")){
							getGroup=Integer.valueOf(val.get(0));
						}

						outer:	for (Integer pg : pageWiseParas.keySet()) 
						{
							if(pg<startPage)
							{
								//System.out.println("Before Start page");
								continue;
							}

							for (PDFPara pa : pageWiseParas.get(pg)) 
							{
								String content=pa.getStringRepresentation();
								List<String> values=getRegexData(inputKeyword, content, getGroup);
								if(values!=null && !values.isEmpty()){
									Extraction_Result er=new Extraction_Result(0, 0, rule, pa.getRectangles().get(0).getY(), pa.getRectangles().get(0).getPage());

									for (Integer kk : pa.getSegments().keySet()) 
									{ //TO DO : add specific result segment only
										er.getResultSegments().addAll(pa.getSegments().get(kk));
									}
									er.setOutputList(values);
									//er.setResultSegments
									fresh.add(er);
									er.setCoordinatesBox(er.getResultSegments());
									break outer;
								}
							}
						}

					}else{ // other than pattern from Paragraph
						for (Integer pg : pageWiseParas.keySet()) {
							if(pg<startPage){
								//	System.out.println("Before Start page");
								continue;
							}
							for (PDFPara pa : pageWiseParas.get(pg)) {
								String content=pa.getStringRepresentation();
								if(content.contains("NDC codes of any HT medication")){
									System.out.println("Debug");
								}
								if(content.contains(inputKeyword)){

									List<String> values = DatatypeInterpretor.getExtractedValue(pa.getStringRepresentation(), rule.getDataType());
									if(values!=null && !values.isEmpty()){
										Extraction_Result er=new Extraction_Result(0, 0, rule, pa.getRectangles().get(0).getY(), pa.getRectangles().get(0).getPage());
										for (Integer kk : pa.getSegments().keySet()) 
										{ //TO DO : add specific result segment only
											er.getResultSegments().addAll(pa.getSegments().get(kk));
										}
										er.setOutputList(values);
										fresh.add(er);
										er.setCoordinatesBox(er.getResultSegments());
									}
								}
							}
						}
					}
				}else if(rule.getExtractionArea().equalsIgnoreCase("ColumnCells")){

					//	else if(rule.getDataType().toLowerCase().contains("list")){
					for (Integer pg : pageWiseCells.keySet()) {
						
					
						
						if(!pageWiseCells.get(pg).isEmpty()){

							List<DPCell> currentPageCells = pageWiseCells.get(pg);

							List<DPCell> nextPageCells =null;
							if(pageWiseCells.get(pg+1)!=null && !pageWiseCells.get(pg+1).isEmpty()){
								nextPageCells=pageWiseCells.get(pg+1);
							}

							
							PDFPara startPara = pageWiseParas.get(pg).get(0);
							Extraction_Result er=new Extraction_Result(0, 0, rule, startPara.getRectangles().get(0).getY(), startPara.getRectangles().get(0).getPage());
							System.out.println();
							List<String> values = detectPageCellData(startPara,pg,currentPageCells,nextPageCells,rule,er);

							if(values!=null && !values.isEmpty()){
								er.setOutputList(values);
								fresh.add(er);
								er.setCoordinatesBox(er.getResultSegments());
								System.out.println();
								//break;
							}

						}
					}
				}else if(rule.getExtractionArea().equalsIgnoreCase("KeyValue")){

					if(rule.getKeywords().contains(". Date and Place of Birth")){
						System.out.println();
					}
					if(inputKeyword!=null  && !inputKeyword.trim().isEmpty() && inputKeyword.length()>2)
					{
						//inputKeyword=inputKeyword.substring(1, inputKeyword.length()-1).trim();
						inputKeyword=inputKeyword.replaceAll("\\{", "").replaceAll("\\}", "");
					} 

					for (Structure structure : kVP) {
						if(structure instanceof KeyValuePair){


							KeyValuePair p=(KeyValuePair)structure;
							if(p.getRectangle().getPage()< startPage){
								//	System.out.println("Before Start page");
								continue;
							}
							//						System.out.println(p.getStringRepresentation());
							if(p.getKeyText().toLowerCase().contains("hiff complaint")){
								System.out.println(p.getKeyText().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim());
								System.out.println(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim());

							}
							//if(p.getKey().getStringRepresentation().replaceAll("[^A-Za-z0-9 ]", "").contains(inputKeyword.replaceAll("[^A-Za-z0-9 ]", ""))){
							if(p.getKeyText().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim())){

								List<String> values = DatatypeInterpretor.getExtractedValue(p.getValueText(), rule.getDataType());
								if(values!=null && !values.isEmpty()){
									Extraction_Result er=new Extraction_Result(0, 0, rule, p.getRectangle().getY(), p.getRectangle().getPage());
									er.getResultSegments().addAll(p.getValueList());
									er.setOutputList(values);
									fresh.add(er);
									er.setCoordinatesBox(er.getResultSegments());
								}
							}
						}
					} 
				}else if(rule.getExtractionArea().toLowerCase().trim().endsWith("cell") 
						&& !rule.getExtractionArea().toLowerCase().contains("checkbox")
						&& !rule.getExtractionArea().toLowerCase().startsWith("segment")){

					for (Integer pg : pageWiseCells.keySet()) {

						if(pageWiseCells.get(pg).isEmpty()){
							continue;
						}
						Extraction_Result er=new Extraction_Result(0, 0, rule, 0, pg);

						List<DPCell> pageCells = pageWiseCells.get(pg);
						List<String> values=processCells(pageCells,rule, segGroups.get(pg),ruleTitles,er);

						if(values!=null && !values.isEmpty()){

							//er.getResultSegments().addAll(new ArrayList<BasicStructure>());
							er.setOutputList(values);
							fresh.add(er);
						}
					}
				}else if(rule.getExtractionArea().toLowerCase().equals("checkbox_segment")){

					if(rule.getKeywords().contains("Sex")){
						System.out.print("");
					}
				
							
					List<PDFSegment> keySegList = FormProcesses.getmatchedSeg(rule.getKeywords(), segGroups);
					System.out.println();
					if(keySegList!=null && !keySegList.isEmpty()){

						PDFSegment matchedSeg = keySegList.get(0);
						int pgNo = matchedSeg.getRectangle().getPage();
						PDPage pdfCurrentPage = pdPages.get(matchedSeg.getRectangle().getPage());

						List<PDFSegment> pageSegs = segGroups.get(pgNo);

						List<PDFWord>checkBoxWords=FormProcesses.getcheckBoxWords(matchedSeg,pageSegs,rule.getCheckBoxSecondWord());

						//values = DatatypeInterpretor.getExtractedValue(rowColText, rule.getDataType());
						//do image storage here for avoiding Heap memory error
						boolean checkBoxFound=false;
						if(checkBoxWords!=null && !checkBoxWords.isEmpty()){
							//if current page image is not present in map >> add it 
							if(!pageAndImage.containsKey(pgNo) && pdfCurrentPage!=null){
								BufferedImage image = null;
								try {
									image  = pdfCurrentPage.convertToImage(BufferedImage.TYPE_INT_RGB,500);
									pageAndImage.put(pgNo, image);
								} catch (IOException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}

							List<String> values = DatatypeInterpretor.getCheckBoxResult("",checkBoxWords, 
									pdfCurrentPage, rule.getDataType(),pageAndImage,pageSegs);

							List<PDFSegment> resultSegs = DatatypeInterpretor.getResultSegs();
							
							//List<PDFWord> matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);
							
							if(values!=null && !values.isEmpty() && !resultSegs.isEmpty()){

								//if(matchedWord!=null){
								Extraction_Result er=new Extraction_Result(0, 0, rule, resultSegs.get(0).getRectangle().getY(), resultSegs.get(0).getRectangle().getPage());
								er.getResultSegments().addAll(resultSegs);
								er.setOutputList(values);
								fresh.add(er);
								er.setCoordinatesBox(er.getResultSegments());
								/*}else{
									Extraction_Result er=new Extraction_Result(0, 0, rule, matchedSeg.getRectangle().getY(), matchedSeg.getRectangle().getPage());
									er.getResultSegments().add(matchedWords);
									er.setOutputList(values);
									fresh.add(er);
								}*/
							}


							/*//handle CEP Front X : X before CheckBox
							if(values== null || values.isEmpty()){
								if(!checkBoxFound && checkBoxWords!=null && !checkBoxWords.isEmpty()){

									values = detect_X_AfterWord(pageSegs,checkBoxWords);

									if(values!=null && !values.isEmpty()){
										matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);
										Extraction_Result er=new Extraction_Result(0, 0, rule, checkBoxWords.get(0).getRectangle().getY(), checkBoxWords.get(0).getRectangle().getPage());
										er.getResultSegments().addAll(matchedWords);
										er.setOutputList(values);
										fresh.add(er);
									}

								}
							}*/
						}

					}

				}else if(rule.getExtractionArea().toLowerCase().contains("checkbox")){


					if(rule.getExtractionArea().toLowerCase().contains("cell")){

						String direction=rule.getExtractionArea().split("_")[1].toLowerCase().trim();

						List<String> checkBoxText =new ArrayList<String>();
						List<String> checkBoxSecondWords =new ArrayList<String>();
						String[] splits = rule.getCheckBoxSecondWord().split("##");
						for (String string : splits) {
							if(string.contains("%")){
								checkBoxSecondWords.add(string.split("%")[0].trim());
								checkBoxText.add(string.split("%")[1].trim());
								
							}else{
								
								checkBoxSecondWords.add(string.trim());
								checkBoxText.add(string.trim());
								
							}
						}


						for (Integer pg : pageWiseCells.keySet()) {

							List<PDFSegment> pageSegs = segGroups.get(pg);

							if(pageWiseCells.get(pg).isEmpty()){
								continue;
							}
							List<DPCell> pageCells = pageWiseCells.get(pg);
							List<DPCell> matchingCells = CellProcessor.getMatchingCells(rule.getKeywords(), pageCells, segGroups.get(pg), ruleTitles);

							if(matchingCells!=null && !matchingCells.isEmpty()){
								List<PDFWord>checkBoxWords=new ArrayList<PDFWord>();
								List<String> values=new ArrayList<String>();
								boolean checkBoxFound=false;
								for (DPCell matchedCell : matchingCells) {

									if(direction.contains("below")){
										List<DPCell> belowCells = CellProcessor.getBelowCells(matchedCell, pageCells);

										if(belowCells!=null && !belowCells.isEmpty()){
											int belowNum=0;
											if(direction.contains("|")){
												belowNum=Integer.valueOf(direction.split("|")[1].trim());
											}
											DPCell belowFirst = belowCells.get(belowNum);



											if(belowFirst!=null && !belowFirst.getStringRepresentation().isEmpty()){

												checkBoxWords= CellProcessor.detectCheboxWords(belowFirst,checkBoxSecondWords);
											}
											//values = DatatypeInterpretor.getExtractedValue(rowColText, rule.getDataType());

											if(checkBoxWords!=null && !checkBoxWords.isEmpty()){
												//if current page image is not present in map >> add it 	

												PDPage pdfCurrentPage = pdPages.get(pg);
												if(!pageAndImage.containsKey(pg) && pdPages.get(pg)!=null){
													BufferedImage image = null;
													try {
														image  = pdfCurrentPage.convertToImage(BufferedImage.TYPE_INT_RGB,500);
														pageAndImage.put(pg, image);
													} catch (IOException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
												}

												values = DatatypeInterpretor.getCheckBoxResult(belowFirst.getStringRepresentation(),checkBoxWords, pdfCurrentPage, rule.getDataType(),pageAndImage,pageSegs);

												List<PDFWord> matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);


												if(values!=null && !values.isEmpty() && !matchedWords.isEmpty()){
													List<String> newValues=new ArrayList<String>();
													for (String pdfWord : values) {
														int index=checkBoxSecondWords.indexOf(pdfWord);
														newValues.add(checkBoxText.get(index));
													}

													//	for (PDFWord pdfWord : matchedWords) {
													checkBoxFound=true;

													Extraction_Result er=new Extraction_Result(0, 0, rule, matchedWords.get(0).getRectangle().getY(), matchedWords.get(0).getRectangle().getPage());
													er.getResultSegments().addAll(matchedWords);
													er.setOutputList(newValues);
													fresh.add(er);
													er.setCoordinatesBox(er.getResultSegments());
													//}

												}
											}
										}

									}else if(direction.equals("same")){

										DPCell sameCell=matchedCell;
										//List<PDFWord>checkBoxWords=new ArrayList<PDFWord>();
										if(sameCell!=null && !sameCell.getStringRepresentation().isEmpty()){
											checkBoxWords= CellProcessor.detectCheboxWords(sameCell,checkBoxSecondWords);
										}
										//values = DatatypeInterpretor.getExtractedValue(rowColText, rule.getDataType());
										if(checkBoxWords!=null && !checkBoxWords.isEmpty()){
											//if current page image is not present in map >> add it 	

											PDPage pdfCurrentPage = pdPages.get(pg);
											if(!pageAndImage.containsKey(pg) && pdPages.get(pg)!=null){
												BufferedImage image = null;
												try {
													image  = pdfCurrentPage.convertToImage(BufferedImage.TYPE_INT_RGB,500);
													pageAndImage.put(pg, image);
												} catch (IOException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
												}
											}

											values = DatatypeInterpretor.getCheckBoxResult(sameCell.getStringRepresentation(),checkBoxWords, pdPages.get(pg), rule.getDataType(),pageAndImage,pageSegs);

											List<PDFWord> matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);
											List<PDFSegment> resultSegs = DatatypeInterpretor.getResultSegs();
											
											if(values!=null && !values.isEmpty() && !resultSegs.isEmpty()){
												//List<String> newValues=new ArrayList<String>();
												/*for (String pdfWord : values) {
													int index=checkBoxSecondWords.indexOf(pdfWord);
													newValues.add(checkBoxText.get(index));
												}*/

												checkBoxFound=true;
												Extraction_Result er=new Extraction_Result(0, 0, rule, resultSegs.get(0).getRectangle().getY(), resultSegs.get(0).getRectangle().getPage());
												er.getResultSegments().addAll(resultSegs);
												er.setOutputList(values);
												fresh.add(er);
												er.setCoordinatesBox(er.getResultSegments());
											}
										}

									}else if(direction.contains("next")){

										List<DPCell> frontCells=CellProcessor.getFrontCells(matchedCell, pageCells);

										if(frontCells!=null && !frontCells.isEmpty()){
											int belowNum=0;
											if(direction.contains("|")){
												belowNum=Integer.valueOf(direction.split("|")[1].trim());
											}
											DPCell frontCell = frontCells.get(belowNum);
											//List<PDFWord>checkBoxWords=new ArrayList<PDFWord>();
											if(frontCell!=null && !frontCell.getStringRepresentation().isEmpty()){
												checkBoxWords= CellProcessor.detectCheboxWords(frontCell,checkBoxSecondWords);
											}
											//values = DatatypeInterpretor.getExtractedValue(rowColText, rule.getDataType());
											if(checkBoxWords!=null && !checkBoxWords.isEmpty()){
												PDPage pdfCurrentPage = pdPages.get(pg);
												if(!pageAndImage.containsKey(pg) && pdPages.get(pg)!=null){
													BufferedImage image = null;
													try {
														image  = pdfCurrentPage.convertToImage(BufferedImage.TYPE_INT_RGB,500);
														pageAndImage.put(pg, image);
													} catch (IOException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
													}
												}
												values = DatatypeInterpretor.getCheckBoxResult(frontCell.getStringRepresentation(),checkBoxWords, pdPages.get(pg), rule.getDataType(),pageAndImage,pageSegs);
												System.out.println();
												List<PDFWord> matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);

												if(values!=null && !values.isEmpty() &&!matchedWords.isEmpty()){
													checkBoxFound=true;
													Extraction_Result er=new Extraction_Result(0, 0, rule, matchedWords.get(0).getRectangle().getY(), matchedWords.get(0).getRectangle().getPage());
													er.getResultSegments().addAll(matchedWords);
													er.setOutputList(values);
													fresh.add(er);
													er.setCoordinatesBox(er.getResultSegments());
												}
											}

										}

									}
								}

								/*//handle CEP Front X : X After CheckBoxWord

								if(!checkBoxFound && checkBoxWords!=null && !checkBoxWords.isEmpty() && (values==null||values.isEmpty())){

									values = detect_X_AfterCheckBoxWord_InCell(matchingCells.get(0),checkBoxWords);
									List<PDFWord> matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);

									if(values!=null && !values.isEmpty() &&!matchedWords.isEmpty()){
										Extraction_Result er=new Extraction_Result(0, 0, rule, matchedWords.get(0).getRectangle().getY(), matchedWords.get(0).getRectangle().getPage());
										er.getResultSegments().addAll(matchedWords);
										er.setOutputList(values);
										fresh.add(er);
									}

								}*/

							}
						}
					}

				}else if(rule.getExtractionArea().toLowerCase().startsWith("segment_")){

					// segment based extraction 

					
					int pageNum=0;
					float y=0;
					PDFSegment titleSeg = null;
					String isEqual="";

					if(rule.getKeywords().contains("##")){
						isEqual = rule.getKeywords().split("##")[1].trim();

						if(isEqual.startsWith("Title:")){//Cells are to be found only under a specific title segment
							isEqual = isEqual.substring(6).trim();

							pageLoop:
								for(List<PDFSegment> pageSegs : segGroups.values()){
									for(PDFSegment s : pageSegs){
										if(pageSegs.indexOf(s) < pageSegs.size()-1){

											if((s.getStringRepresentation()+" "+pageSegs.get(pageSegs.indexOf(s)+1).getStringRepresentation()).equalsIgnoreCase(isEqual)){//|| isEqual.contains(s.getStringRepresentation())){
												titleSeg = s;
												isEqual="";
												pageNum=s.getRectangle().getPage();
												y=s.getRectangle().getY();

												break pageLoop;
											}	
										}
									}
								}
							if(titleSeg==null){

								pageLoop:
									for(List<PDFSegment> pageSegs : segGroups.values()){
										for(PDFSegment s : pageSegs){
											if(s.getStringRepresentation().equalsIgnoreCase(isEqual)){//|| isEqual.contains(s.getStringRepresentation())){
												titleSeg = s;
												isEqual="";
												pageNum=s.getRectangle().getPage();
												y=s.getRectangle().getY();

												break pageLoop;
											}
										}
									}
							}

							if(titleSeg==null){
								System.out.println("Title Not Found ::"+rule.getKeywords()+"\t"+rule.getRuleId());
								isEqual="";
								continue;
							}
						}
					}
					String direction = rule.getExtractionArea().toLowerCase().split("_")[1];
					PDFSegment seg = null;
					//GOTO keyword segment
					PDFSegment matchedSegment=null;
					outer:
						for(List<PDFSegment> segs : segGroups.values()){

							//Collections.sort(seg, new Comparators());

							for(int i=0; i<segs.size()-1; i++){

								PDFSegment s = segs.get(i);
								if(s.getRectangle().getPage()<pageNum ){
									break;
								}
								if(s.getRectangle().getPage()==pageNum && s.getRectangle().getY()<(y-1)){
									continue;
								}
								if(isEqual.isEmpty() || isEqual.equalsIgnoreCase("equal") ||isEqual.equalsIgnoreCase("equals")){
									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim()))
									{
										matchedSegment=s;
										break outer;
									}
								}else if(isEqual.equalsIgnoreCase("contains")||isEqual.equalsIgnoreCase("contain"))
								{
									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().toLowerCase().contains(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().toLowerCase()))
									{
										matchedSegment=s;
										break outer;
									}
								}
							}
						}

					if(matchedSegment!=null){
						System.out.println("Matched Seg :"+matchedSegment.getStringRepresentation());
					}else{
						System.out.println("Input Keyword doeses not matched");
						continue;
					}

					/*if(direction.equals("same")){
						outer:
							for(List<PDFSegment> segs : segGroups.values()){
								for(int i=0; i<segs.size()-1; i++){
									PDFSegment s = segs.get(i);

									if(s.getStringRepresentation().contains(rule.getKeywords())){
										seg = segs.get(i+1);
										break outer;
									}
								}
							}

					}*/
					if(direction.equalsIgnoreCase("next")){

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						seg = matchedSegmentPageList.get(index+1);

						//						outer:
						//							for(List<PDFSegment> segs : segGroups.values()){
						//
						//								//Collections.sort(seg, new Comparators());
						//
						//								for(int i=0; i<segs.size()-1; i++){
						//
						//									PDFSegment s = segs.get(i);
						//									if(s.getRectangle().getPage()<pageNum ){
						//										break;
						//									}
						//									if(s.getRectangle().getY()<(y-1)){
						//										continue;
						//									}
						//									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim()))
						//									{
						//										//	if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){
						//										//										for(int ij=0; ij<segs.size()-1; ij++){
						//										//											if(CommonOperations.isOverlapOnY(s, segs.get(ij)) && s.getRectangle().getX2()< segs.get(ij).getRectangle().getX() ){
						//										//seg = segs.get(ij);
						//
						//										seg = segs.get(i+1);
						//										break outer;
						//										//											}
						//										//										}
						//									}
						//								}
						//							}

					}if(direction.equals("nextall")){

                        List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

                        int index = matchedSegmentPageList.indexOf(matchedSegment);
                        if(index>=matchedSegmentPageList.size()){
                              continue;
                        }

                        List<PDFSegment> nextSegs=new ArrayList<PDFSegment>();
                        for(int j=index+1; j<matchedSegmentPageList.size(); j++)
                        {
                              PDFSegment s = matchedSegmentPageList.get(j);
                              if(CommonOperations.isOverlapOnY(s, matchedSegment) )
                              {
                                    nextSegs.add(s);
                              }

                        }

                        if(!nextSegs.isEmpty()){
                              Extraction_Result r=createExtractionResultObject(nextSegs,rule);
                              fresh.add(r);
                              continue;
                        }

					}
					else if(direction.equalsIgnoreCase("below")){

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);
						if(index>=matchedSegmentPageList.size()){
							continue;
						}

						for(int j=index+1; j<matchedSegmentPageList.size(); j++){
							PDFSegment currSeg = matchedSegmentPageList.get(j);
							if(CommonOperations.isOverlapOnX(matchedSegment, currSeg)){
								seg = currSeg;
								break;
							}
						}


						//						outer:
						//							for(List<PDFSegment> segs : segGroups.values()){
						//								for(int i=0; i<segs.size()-1; i++){
						//									PDFSegment s = segs.get(i);
						//
						//									if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){
						//										for(int j=i+1; j<segs.size()-1; j++){
						//											if(CommonOperations.isOverlapOnX(s, segs.get(j))){
						//												seg = segs.get(j);
						//												break outer;
						//											}
						//										}
						//									}
						//								}
						//							}
					}

					if(seg!=null){

						List<String> vals = DatatypeInterpretor.getExtractedValue(seg.getStringRepresentation(), rule.getDataType());

						Extraction_Result r = new Extraction_Result(seg.getId(), 0, rule, seg.getRectangle().getY(), seg.getRectangle().getPage());
						r.getResultSegments().add(seg);
						r.setOutputList(vals);
						fresh.add(r);
						r.setCoordinatesBox(r.getResultSegments());

					}else if(direction.equalsIgnoreCase("belowcell")){

						PDFSegment s = matchedSegment;

						if(pageWiseCells.get(s.getRectangle().getPage())!=null){
							for(DPCell cell : pageWiseCells.get(s.getRectangle().getPage())){
								if(cell.getRectangle().getY2() > s.getRectangle().getY2()){
									if(CommonOperations.isOverlapOnX(s, cell)){
										List<String> vals = DatatypeInterpretor.getExtractedValue(cell.getStringRepresentation(), rule.getDataType());
										if(!vals.isEmpty()){
											Extraction_Result r = new Extraction_Result(cell.getId(), 0, rule, cell.getRectangle().getY(), cell.getRectangle().getPage());
											r.getResultSegments().addAll(cell.getLineCellDataList());
											r.setOutputList(vals);
											fresh.add(r);
											r.setCoordinatesBox(r.getResultSegments());
										}
										break ;
									}
								}
							}
						}

						/*	outer:
							for(List<PDFSegment> segs : segGroups.values()){
								for(int i=0; i<segs.size()-1; i++){
									PDFSegment s = segs.get(i);

									if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){

										if(pageWiseCells.get(s.getRectangle().getPage())!=null){
											for(DPCell cell : pageWiseCells.get(s.getRectangle().getPage())){
												if(cell.getRectangle().getY2() > s.getRectangle().getY2()){
													if(CommonOperations.isOverlapOnX(s, cell)){
														List<String> vals = DatatypeInterpretor.getExtractedValue(cell.getStringRepresentation(), rule.getDataType());
														if(!vals.isEmpty()){
															Extraction_Result r = new Extraction_Result(cell.getId(), 0, rule, cell.getRectangle().getY(), cell.getRectangle().getPage());
															r.getResultSegments().addAll(cell.getLineCellDataList());
															r.setOutputList(vals);
															fresh.add(r);
														}
														break outer;
													}
												}
											}
										}
									}
								}
							}*/
					}else if(direction.equalsIgnoreCase("belowAllCell")){

						PDFSegment s = matchedSegment;
						DPCell lastCell = null;
						if(pageWiseCells.get(s.getRectangle().getPage())!=null){
							List<DPCell> pageCells = pageWiseCells.get(s.getRectangle().getPage());
							for(DPCell cell : pageCells){
								if(cell.getRow()==5 && cell.getColumn()==2 ){
									System.out.println();	
								}
								if(cell.getRectangle().getY2() > s.getRectangle().getY2()){
									if(CommonOperations.isOverlapOnX(s, cell)){

										if(lastCell!=null){
											if((cell.getRectangle().getY2()-lastCell.getRectangle().getY())>5){
												//	breakByGap=true;
												if(blankCellIsPresentInBetween(pageCells, lastCell, cell))											
													break;
											}
										}

										List<String> vals = DatatypeInterpretor.getExtractedValue(cell.getStringRepresentation(), rule.getDataType());
										if(!vals.isEmpty()){
											Extraction_Result r = new Extraction_Result(cell.getId(), 0, rule, cell.getRectangle().getY(), cell.getRectangle().getPage());
											r.getResultSegments().addAll(cell.getLineCellDataList());
											r.setOutputList(vals);
											fresh.add(r);
											lastCell=cell;
											r.setCoordinatesBox(r.getResultSegments());
										}

									}
								}
							}
						}
					}
					else if(direction.equalsIgnoreCase("nextCell")){

						PDFSegment s = matchedSegment;

						if(pageWiseCells.get(s.getRectangle().getPage())!=null){
							for(DPCell cell : pageWiseCells.get(s.getRectangle().getPage())){

								if(cell.getStringRepresentation().contains("HCP")){
									System.out.print(" ");
								}
								if(cell.getRectangle().getX() > s.getRectangle().getX()){
									if(CommonOperations.isOverlapOnY(s, cell)){
										List<String> vals = DatatypeInterpretor.getExtractedValue(cell.getStringRepresentation(), rule.getDataType());
										if(!vals.isEmpty()){

											Extraction_Result r = new Extraction_Result(cell.getId(), 0, rule, cell.getRectangle().getY(), cell.getRectangle().getPage());
											r.getResultSegments().addAll(cell.getLineCellDataList());
											r.setOutputList(vals);
											fresh.add(r);
											r.setCoordinatesBox(r.getResultSegments());
										}
										break;
									}
								}
							}
						}

						/*
						outer:
							for(List<PDFSegment> segs : segGroups.values()){
								for(int i=0; i<segs.size()-1; i++){
									PDFSegment s = segs.get(i);
									if(s.getStringRepresentation().contains("Occupation/Specialty")){
										System.out.println();
									}
									boolean flag=false;

									if(isEqual.equalsIgnoreCase("contains")||isEqual.equalsIgnoreCase("contain")){
										if(s.getStringRepresentation().contains(inputKeyword)){
											flag=true;
										}
									}else{
										if(s.getStringRepresentation().contains(inputKeyword)){
											flag=true;
										}

									}

									if(flag){

										if(pageWiseCells.get(s.getRectangle().getPage())!=null){
											for(DPCell cell : pageWiseCells.get(s.getRectangle().getPage())){

												if(cell.getStringRepresentation().contains("HCP")){
													System.out.print(" ");
												}
												if(cell.getRectangle().getX() > s.getRectangle().getX()){
													if(CommonOperations.isOverlapOnY(s, cell)){
														List<String> vals = DatatypeInterpretor.getExtractedValue(cell.getStringRepresentation(), rule.getDataType());
														if(!vals.isEmpty()){

															Extraction_Result r = new Extraction_Result(cell.getId(), 0, rule, cell.getRectangle().getY(), cell.getRectangle().getPage());
															r.getResultSegments().addAll(cell.getLineCellDataList());
															r.setOutputList(vals);
															fresh.add(r);
														}
														break outer;
													}
												}
											}
										}
									}
								}
							}*/

					}else if(direction.equalsIgnoreCase("belowAll")){


						List<PDFSegment>belowwSegs=new ArrayList<PDFSegment>();

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						PDFSegment s = matchedSegment;
						for(int j=index+1; j<matchedSegmentPageList.size(); j++){
							PDFSegment currSeg = matchedSegmentPageList.get(j);
							if(CommonOperations.isOverlapOnX(matchedSegment, currSeg) && currSeg.getRectangle().getY()>s.getRectangle().getY() ){
								seg = currSeg;
								break;
							}
						}

						if(!belowwSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(belowwSegs,rule);
							fresh.add(r);
						}


						/*String keyW = rule.getKeywords().split("##")[0].trim();

						outer:
							for(List<PDFSegment> segs : segGroups.values()){

								for(int i=0; i<segs.size()-1; i++){

									PDFSegment s = segs.get(i);
									if(s.getRectangle().getPage()<pageNum ){
										break;
									}
									if(titleSeg!=null && titleSeg.getRectangle().getPage()==s.getRectangle().getPage() && s.getRectangle().getY()<(y-1)){
										continue;
									}

									if(s.getStringRepresentation().equalsIgnoreCase(keyW)){
										for(int j=i+1; j<segs.size()-1; j++){
											if(CommonOperations.isOverlapOnX(s, segs.get(j)) && segs.get(j).getRectangle().getY()>s.getRectangle().getY() ){
												seg = segs.get(j);
												belowwSegs.add(seg);
												//break outer;
											}
										}
										break;
									}
								}
							}
						if(!belowwSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(belowwSegs,rule);
							fresh.add(r);
						}*/

					}else if(direction.equalsIgnoreCase("nextPara")){


						List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						PDFSegment s = matchedSegment;
						PDFSegment nextSeg = matchedSegmentPageList.get(index+1);
						if(CommonOperations.isOverlapOnY(s,nextSeg)){


							for(int j=index+1; j<matchedSegmentPageList.size(); j++){
								PDFSegment currSeg = matchedSegmentPageList.get(j);
								float ydiff;
								if(matchedSegs.isEmpty()){
									ydiff=Math.abs(s.getRectangle().getY()-currSeg.getRectangle().getY());
								}else{
									ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-currSeg.getRectangle().getY());
								}
								if(ydiff<=2*s.getRectangle().getHeight()){
									matchedSegs.add(currSeg);
								}
							}
							if(!matchedSegs.isEmpty()){
								Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
								fresh.add(r);
							}
						}

						/* boolean matchedFlag=false;
						  outer:
							for(List<PDFSegment> segs : segGroups.values()){



								for(int i=0; i<segs.size()-1; i++){

									PDFSegment s = segs.get(i);
									if(s.getRectangle().getPage()<pageNum ){
										break;
									}
									if(s.getRectangle().getY()<(y-1)){
										continue;
									}
									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim()))
									{
										//	if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){
										if(CommonOperations.isOverlapOnY(s, segs.get(i+1))){
											matchedFlag=true;
											continue;
										}
										//	matchedSegs.add(segs.get(i+1));

									}

									if(matchedFlag){
										float ydiff;
										if(matchedSegs.isEmpty()){
											ydiff=Math.abs(s.getRectangle().getY()-segs.get(i).getRectangle().getY());
										}else{
											ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-segs.get(i).getRectangle().getY());
										}
										if(ydiff<=2*s.getRectangle().getHeight()){
											matchedSegs.add(segs.get(i));
										}

									}
								}

								if(!matchedSegs.isEmpty()){
									break;
								}
							}

						if(!matchedSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
							fresh.add(r);
						}*/


					}else if(direction.equalsIgnoreCase("NextParaAll")){


						List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						PDFSegment nextSeg = matchedSegmentPageList.get(index+1);
						if(CommonOperations.isOverlapOnY(matchedSegment,nextSeg)){

							outer:
								for(int j=index+1; j<matchedSegmentPageList.size(); j++){
									PDFSegment currSeg = matchedSegmentPageList.get(j);


									for(int jk=index; jk<matchedSegmentPageList.size(); jk++){
										PDFSegment otherSeg = matchedSegmentPageList.get(jk);

										if(!otherSeg.equals(matchedSegment) && !currSeg.equals(matchedSegment) && CommonOperations.isOverlapOnY(otherSeg,currSeg)){
											if(currSeg.getRectangle().getX()<= matchedSegment.getRectangle().getX2()
													|| otherSeg.getRectangle().getX()<= matchedSegment.getRectangle().getX2()
													){
												break outer;
											}
										}

									}


									if(currSeg.getRectangle().getX()<= matchedSegment.getRectangle().getX2()){
										break;
									}
									//break on y gap
									if(!matchedSegs.isEmpty() && Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-currSeg.getRectangle().getY()) > currSeg.getRectangle().getHeight()*5){
										break;
									}

									matchedSegs.add(currSeg);
								}

						if(!matchedSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
							fresh.add(r);
						}
						}
					}else if(direction.equalsIgnoreCase("nextOverlappedPara")){


						List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);

						PDFSegment s = matchedSegment;
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						PDFSegment nextSeg = matchedSegmentPageList.get(index+1);
						PDFSegment lastSeg=null;

						if(CommonOperations.isOverlapOnY(s, nextSeg)){
							for(int j=index+1; j<matchedSegmentPageList.size(); j++){
								PDFSegment currSeg = matchedSegmentPageList.get(j);

								float ydiff;
								if(matchedSegs.isEmpty()){
									ydiff=Math.abs(s.getRectangle().getY()-currSeg.getRectangle().getY());
								}else{
									ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-currSeg.getRectangle().getY());
								}
								if(lastSeg==null){
									//if(ydiff<=2*s.getRectangle().getHeight()){
									if(CommonOperations.isOverlapOnY(currSeg, matchedSegment)){
										lastSeg=currSeg;
										matchedSegs.add(currSeg);
									}
									//}
								}else{
									if(ydiff<=2*lastSeg.getRectangle().getHeight()){
										if(CommonOperations.isOverlapOnX(lastSeg, currSeg)){
											lastSeg=currSeg;
											matchedSegs.add(currSeg);
										}
									}
								}

							}

						}

						if(!matchedSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
							fresh.add(r);
						}

						/*		boolean matchedFlag=false;
						List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();
						PDFSegment lastSeg=null;

						outer:
							for(List<PDFSegment> segs : segGroups.values()){

								for(int i=0; i<segs.size()-1; i++){

									PDFSegment s = segs.get(i);
									if(s.getRectangle().getPage()<pageNum ){
										break;
									}
									if(s.getRectangle().getY()<(y-1)){
										continue;
									}
									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim()))
									{
										//	if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){
										if(CommonOperations.isOverlapOnY(s, segs.get(i+1))){
											matchedFlag=true;
											continue;
										}
										//	matchedSegs.add(segs.get(i+1));

									}

									if(matchedFlag){
										float ydiff;
										if(matchedSegs.isEmpty()){
											ydiff=Math.abs(s.getRectangle().getY()-segs.get(i).getRectangle().getY());
										}else{
											ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-segs.get(i).getRectangle().getY());
										}
										if(lastSeg==null){
											if(ydiff<=2*s.getRectangle().getHeight()){
												if(CommonOperations.isOverlapOnY(segs.get(i), segs.get(i+1))){
													lastSeg=segs.get(i);
													matchedSegs.add(segs.get(i));
												}
											}
										}else{
											if(ydiff<=2*lastSeg.getRectangle().getHeight()){
												if(CommonOperations.isOverlapOnX(lastSeg, segs.get(i))){
													lastSeg=segs.get(i);
													matchedSegs.add(segs.get(i));
												}
											}
										}
									}
								}
								if(!matchedSegs.isEmpty()){
									break;
								}
							}

						if(!matchedSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
							fresh.add(r);
						}*/

					}else if(direction.equalsIgnoreCase("belowOverlappedPara")){


						List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();

						List<PDFSegment> matchedSegmentPageList = segGroups.get(matchedSegment.getRectangle().getPage());

						int index = matchedSegmentPageList.indexOf(matchedSegment);

						//PDFSegment s = matchedSegment;
						if(index>=matchedSegmentPageList.size()){
							continue;
						}
						PDFSegment nextSeg = matchedSegmentPageList.get(index+1);
						PDFSegment lastSeg=null;

						for(int j=index+1; j<matchedSegmentPageList.size(); j++){
							PDFSegment currSeg = matchedSegmentPageList.get(j);

							if(CommonOperations.isOverlapOnX(matchedSegment, currSeg)){

								float ydiff;
								if(matchedSegs.isEmpty()){
									ydiff=Math.abs(matchedSegment.getRectangle().getY()-currSeg.getRectangle().getY());
								}else{
									ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-currSeg.getRectangle().getY());
								}

								if(lastSeg==null){
									//if(ydiff<=2*matchedSegment.getRectangle().getHeight())
									{
										//if(CommonOperations.isOverlapOnY(currSeg, matchedSegmentPageList.get(j+1)))
										{
											lastSeg=currSeg;
											matchedSegs.add(currSeg);
										}
									}
								}else{
									if(ydiff<=2*lastSeg.getRectangle().getHeight()){
										if(CommonOperations.isOverlapOnX(lastSeg, currSeg)){
											lastSeg=currSeg;
											matchedSegs.add(currSeg);
										}
									}
								}

							}

						}

						if(!matchedSegs.isEmpty()){
							Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
							fresh.add(r);
						}
					}

				}


				/* else if(rule.getExtractionArea().toLowerCase().startsWith("para_")){
					int pageNum=0;
					float y=0;
					PDFSegment title;

					if(rule.getKeywords().contains("##")){
						String isEqual = rule.getKeywords().split("##")[1];

						if(isEqual.startsWith("Title:")){//Cells are to be found only under a specific title segment
							isEqual = isEqual.substring(6).trim();

							pageLoop:
								for(List<PDFSegment> pageSegs : segGroups.values()){
									for(PDFSegment s : pageSegs){
										if(s.getStringRepresentation().equalsIgnoreCase(isEqual)){//|| isEqual.contains(s.getStringRepresentation())){
											title = s;

											pageNum=s.getRectangle().getPage();
											y=s.getRectangle().getY();

											break pageLoop;
										}
									}
								}
						}
					}
					String direction = rule.getExtractionArea().toLowerCase().split("_")[1];
					List<PDFSegment>matchedSegs=new ArrayList<PDFSegment>();
					// seg = null;
					if(direction.equals("next")){
						boolean matchedFlag=false;
						outer:
							for(List<PDFSegment> segs : segGroups.values()){

								for(int i=0; i<segs.size()-1; i++){

									PDFSegment s = segs.get(i);
									if(s.getRectangle().getPage()<pageNum ){
										break;
									}
									if(s.getRectangle().getY()<(y-1)){
										continue;
									}
									if(s.getStringRepresentation().replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim().equalsIgnoreCase(inputKeyword.replaceAll("[^A-Za-z0-9& ]", "").replaceAll("\\s+", " ").trim()))
									{
										//	if(s.getStringRepresentation().equalsIgnoreCase(rule.getKeywords())){
										if(CommonOperations.isOverlapOnY(s, segs.get(i+1))){
											matchedFlag=true;
											continue;
										}
										//	matchedSegs.add(segs.get(i+1));

									}

									if(matchedFlag){
										float ydiff;
										if(matchedSegs.isEmpty()){
											ydiff=Math.abs(s.getRectangle().getY()-segs.get(i).getRectangle().getY());
										}else{
											ydiff=Math.abs(matchedSegs.get(matchedSegs.size()-1).getRectangle().getY()-segs.get(i).getRectangle().getY());
										}
										if(ydiff<=2*s.getRectangle().getHeight()){
											matchedSegs.add(segs.get(i));
										}

									}
								}

								if(!matchedSegs.isEmpty()){
									break;
								}
							}

					}

					if(!matchedSegs.isEmpty()){
						Extraction_Result r=createExtractionResultObject(matchedSegs,rule);
						fresh.add(r);
					}
				}*/
			}catch(Exception e){
				e.printStackTrace();
			}

		}
		return fresh;
	}



	private Extraction_Result createExtractionResultObject(	List<PDFSegment> resultSegs, ExtractionRule rule) {
		String rText="";
		PDFSegment seg=resultSegs.get(0);
		for (PDFSegment se : resultSegs) { 
			rText= (rText+" "+se.getStringRepresentation()).trim();
		}
		List<String> vals = DatatypeInterpretor.getExtractedValue(rText, rule.getDataType());
		Extraction_Result r = new Extraction_Result(seg.getId(), 0, rule, seg.getRectangle().getY(), seg.getRectangle().getPage());
		r.getResultSegments().addAll(resultSegs);
		r.setOutputList(vals);
		r.setCoordinatesBox(r.getResultSegments());
		return r;
	}

	private List<PDFWord> getCheckBoxmatchedWords(List<PDFWord> checkBoxWords,	List<String> values) {
		List<PDFWord> matchedWords=new ArrayList<PDFWord>();

		for (PDFWord wrd : checkBoxWords) {
			for (String string : values) {
				//PG added conatins
				//if(string.trim().equalsIgnoreCase(wrd.getStringRepresentation().trim())){
				if(string.trim().contains(wrd.getStringRepresentation().trim())){
					matchedWords.add(wrd);
					break;
				}
			}
		}
		return matchedWords;
	}

	/*private List<String> detect_X_AfterWord(List<PDFSegment> pageSegs,	List<PDFWord> checkBoxWords) {

		List<String>temp=new ArrayList<String>();

		for (PDFWord chboxWord : checkBoxWords) {

			for (PDFSegment seg : pageSegs) {

				List<PDFWord> segWords = seg.getWords();

				List<PDFWord> frontwords = FormProcesses.getFrontWords(chboxWord, segWords);

				if(frontwords!=null && !frontwords.isEmpty()){
					if(!chboxWord.equals(frontwords.get(0)) && frontwords.get(0).getStringRepresentation().equalsIgnoreCase("x"))
						temp.add(chboxWord.getStringRepresentation());
				}
			}
		}
		return temp;
	}
	 */

	private List<String> detect_X_AfterCheckBoxWord_InCell(DPCell dpCell,List<PDFWord> checkBoxWords) {

		List<String>temp=new ArrayList<String>();
		List<PDFWord> cellWords = dpCell.getLineCellDataList();
		for (PDFWord chboxWord : checkBoxWords) {
			List<PDFWord> frontwords = FormProcesses.getFrontWords(chboxWord, cellWords);
			if(frontwords!=null && !frontwords.isEmpty() && frontwords.get(0).getStringRepresentation().equalsIgnoreCase("x")){
				temp.add(chboxWord.getStringRepresentation());
			}
		}
		return temp;
	}


	public static List<String> processCells(List<DPCell> pageCells,ExtractionRule rule, List<PDFSegment> segs, List<PDFSegment> ruleTitles, Extraction_Result er){
		//find the page of the cell
		List<String> values=new ArrayList<String>();

		String keywoString=rule.getKeywords();
		String direction=rule.getExtractionArea().split("_")[0].trim();

		if(rule.getRuleId()==6){
			System.out.print(" ");
		}
		List<DPCell>matchingCells=new ArrayList<DPCell>();

		matchingCells=CellProcessor.getMatchingCells(rule.getKeywords(),pageCells, segs, ruleTitles);
		System.out.println("");
		
		if(!matchingCells.isEmpty()){
			for (DPCell matchingCell : matchingCells) {

				System.out.println("DPCell matchingCell \t"+matchingCell.getStringRepresentation());

				String resultText= "";

				if(matchingCell.getStringRepresentation().contains("Suspect Product"))//Provide clear narrative description
					System.out.println();

				if(direction.equalsIgnoreCase("same")){
					resultText=matchingCell.getStringRepresentation();
					resultText=resultText.replace(rule.getKeywords().trim(), "").trim();
					//	System.out.println(resultText);
				}else if(direction.toLowerCase().contains("below")){
					List<DPCell> belowCells=new ArrayList<DPCell>();
					int belowCellNum=0;

					if(direction.toLowerCase().contains("|")){
						belowCellNum=(Integer.valueOf(direction.split("\\|")[1].trim())-1);
					}

					belowCells=CellProcessor.getBelowCells(matchingCell, pageCells);

					if(!belowCells.isEmpty() && belowCells.size() > belowCellNum){
						DPCell below = belowCells.get(belowCellNum);
						if(below!=null && !below.getStringRepresentation().trim().isEmpty())
						{
							matchingCell = below;
							resultText=below.getStringRepresentation();
						}

					}

				}
				else if(direction.equalsIgnoreCase("next")){
					DPCell next = null;

					List<DPCell> frontCells=CellProcessor.getFrontCells(matchingCell, pageCells);

					if (frontCells!=null && !frontCells.isEmpty()){
						next = frontCells.get(0);
					}

					if(next!=null && !next.getStringRepresentation().trim().isEmpty()){
						matchingCell = next;
						resultText=next.getStringRepresentation();
						if(rule.getKeywords().contains("Suspect Product") && resultText.contains("Start Date")){
							resultText=resultText.replaceAll("Start Date", "");
							resultText=resultText.replaceAll("Stop Date", "").replaceAll("\\s+", " ").trim();
						}
					}

				} if(direction.matches("[0-9]{1,2},[0-9]{1,2}")) // direct customize row and column number for Cell
				{

					int rowNum=Integer.valueOf(direction.split(",")[0]);
					int colNum=Integer.valueOf(direction.split(",")[1]);

					resultText=CellProcessor.getCellText(pageCells,rowNum,colNum);
					//	System.out.println("RC:Text:\t"+rowNum+","+colNum+" :"+resultText);

				}

				if(resultText.contains(keywoString)){
					resultText=resultText.replaceFirst(keywoString, "").trim();
				}

				List<String> values2 = null;
				if(!resultText.isEmpty())
					values2 = DatatypeInterpretor.getExtractedValue(resultText, rule.getDataType());

				if(values2!=null && !values2.isEmpty()){
					values.add(values2.get(0));
				}
				//Resolve extraction type now
				if(!resultText.isEmpty()){
					er.getResultSegments().addAll(matchingCell.getLineCellDataList());
					er.setCoordinatesBox(er.getResultSegments());
				}
			}
		}


		if(values.isEmpty() && direction.matches("[0-9]{1,2},[0-9]{1,2}"))// direct customize row and column number for Cell
		{ 
			int rowNum=Integer.valueOf(direction.split(",")[0]);
			int colNum=Integer.valueOf(direction.split(",")[1]);

			String	rowColText=CellProcessor.getCellText(pageCells,rowNum,colNum);

			if(rowColText.contains(keywoString)){
				rowColText=rowColText.replaceFirst(keywoString, "").trim();
			}
			if(!rowColText.isEmpty())
				values = DatatypeInterpretor.getExtractedValue(rowColText, rule.getDataType());
		}

		return values;
	}


	private List<String> detectPageCellData(PDFPara startPara, Integer pg, List<DPCell> currentPageCells, List<DPCell> nextPageCells, ExtractionRule rule, Extraction_Result er) {

		List<String> temp= new ArrayList<String>();

		int resultColumn=-1;
		int resultRow=-1;
		List<DPCell>pageCells=currentPageCells;

		String columnKyeWord = rule.getKeywords().trim();

		DPCell lastCell=null;
		boolean breakByGap=false;
		if(!pageCells.isEmpty())
		{
			// detect column num  which have required data (drugs name)

			for (int i = 0; i < pageCells.size(); i++) {
				//				for (DPCell dpCell : pageCells) {
				DPCell dpCell = pageCells.get(i);
				//if(dpCell.getStringRepresentation().contains(str)){
				if(!columnKyeWord.contains("##")){
					if(dpCell.getStringRepresentation().trim().equals(columnKyeWord)){
						resultColumn=dpCell.getColumn();
						resultRow=dpCell.getRow();
						lastCell=dpCell;
						break;
					}
				}else if(columnKyeWord.contains("##") && i+1< pageCells.size()){
					DPCell nextDpCell = pageCells.get(i+1);
					if(dpCell.getStringRepresentation().trim().equals(columnKyeWord.split("##")[0])
							&& nextDpCell.getStringRepresentation().trim().equals(columnKyeWord.split("##")[1])
							){
						resultColumn=dpCell.getColumn();
						resultRow=dpCell.getRow();
						lastCell=dpCell;
						break;
					}

				}
			}

			if(resultColumn!=-1 && lastCell!=null)
			{
				System.out.println("\n--------------------cell Data Result ColumnCells Rule");

				for (DPCell dpCell : pageCells) {

					//do based on overlapped  Cell

					if(dpCell.getStringRepresentation().contains("364,481.14")){
						System.out.println("");
					}
					
					if(rule.getDataType().equalsIgnoreCase("OverlappedCells")){
						if(!lastCell.equals(dpCell) && CommonOperations.isCellOverlapOnX(lastCell, dpCell)){
							temp.add(dpCell.getStringRepresentation());

							er.getResultSegments().addAll(dpCell.getLineCellDataList());
							breakByGap=true;//dnt wnt to check on next page
						}
					}else
						if(!lastCell.equals(dpCell) && CommonOperations.isCellOverlapOnX(lastCell, dpCell)){

							if(Math.abs(lastCell.getRectangle().getX()-dpCell.getRectangle().getX())>3 && Math.abs(lastCell.getRectangle().getX2() - dpCell.getRectangle().getX2())>3 ){
								break;
							}

							if(!blankCellIsPresentInBetween(pageCells,lastCell, dpCell)){

								if(lastCell!=null && (dpCell.getRectangle().getY2()-lastCell.getRectangle().getY())>5){
									breakByGap=true;
									break;
								}
							}
							
							if(!columnKyeWord.equalsIgnoreCase(dpCell.getStringRepresentation().trim())){
								temp.add(dpCell.getStringRepresentation());
							
								lastCell=dpCell;
								//er.setCoordinatesBox(basicStr);
								er.getCoordinatesBoxList().add(getCoordinatesBox(dpCell.getLineCellDataList()));
								
								er.getResultSegments().addAll(dpCell.getLineCellDataList());
							}
							
						}
						//based on col number
						
						
						/*
						 * (Math.abs((dpCell.getRectangle().getWidth() - lastCell.getRectangle().getWidth()))<2)&&  dpCell.getColumn()==resultColumn && !dpCell.getStringRepresentation().trim().isEmpty()
						 * 
						 * 
						 * 
						 * 
						 * if(dpCell.getColumn()==resultColumn && dpCell.getRow()>resultRow && !dpCell.getStringRepresentation().trim().isEmpty()){
							//System.out.println(dpCell.getStringRepresentation());
							if((dpCell.getRectangle().getY2()-lastCell.getRectangle().getY())>5){
								breakByGap=true;
								break;
							}

							if(!columnKyeWord.equalsIgnoreCase(dpCell.getStringRepresentation().trim())){
								temp.add(dpCell.getStringRepresentation());
								lastCell=dpCell;
								er.getResultSegments().addAll(dpCell.getLineCellDataList());
							}
						}*/
				}
			}
		}

		if(resultColumn!=-1 && !breakByGap ){ // catch if table is extends on on next page

			PDFPara nextEnumPara=getEndPara(startPara,pageWiseParas,pg);
			if(nextEnumPara==null && startPara.getRectangles().size()>=2 ){
				List<DPRectangle> rectangles=new ArrayList<DPRectangle>();
				rectangles.add(startPara.getRectangles().get(1));
				nextEnumPara =new PDFPara(rectangles,new HashMap<Integer, List<BasicStructure>>(), StructureType.PARA);
			}

			CellProcessor cp=new CellProcessor(pageWiseParas);
			int pgNo = startPara.getRectangles().get(0).getPage();

			//List<DPCell>pageCells=cp.cellProcess(segGroups,pdPages.get(pgNo),startPara,"");

			//List<DPCell>nextPageCells=null;
			if(nextPageCells==null){
				if(nextEnumPara!=null 
						&& nextEnumPara.getRectangles().get(0).getPage()!=pgNo
						&& pageCells!=null 
						&& !pageCells.isEmpty() 
						&& pageWiseParas.containsKey(pg+1) 
						){

					nextPageCells=cp.cellProcess(segGroups,pdPages.get(pgNo+1),nextEnumPara,"");
					System.out.println("Vlaid next page for: nextPageCells "+(pgNo+1)+"\t"+nextPageCells.size());
					if(!nextPageCells.isEmpty()){

						pageWiseCells.put(pgNo+1, nextPageCells);
					}
				}
			}

			DPCell nextpagelastCell = null;
			if(nextPageCells!=null){
				for (DPCell dpCell : nextPageCells) {

					if(/*dpCell.getColumn()==resultColumn */ CommonOperations.isOverlapOnX(lastCell, dpCell) && !dpCell.getStringRepresentation().trim().isEmpty()){
						//System.out.println(dpCell.getStringRepresentation());
						
						if(Math.abs(lastCell.getRectangle().getX()-dpCell.getRectangle().getX())>3 && Math.abs(lastCell.getRectangle().getX2() - dpCell.getRectangle().getX2())>3 ){
							break;
						}
						
						if(nextpagelastCell==null){
							nextpagelastCell=dpCell;
						}else if((dpCell.getRectangle().getY2()-nextpagelastCell.getRectangle().getY())>5){
							breakByGap=true;
							break;
						}
						temp.add(dpCell.getStringRepresentation());
						nextpagelastCell=dpCell;
						er.getResultSegments().addAll(dpCell.getLineCellDataList());
					}
				}
			}	
		}
		return temp;
	}


	private boolean blankCellIsPresentInBetween(List<DPCell> pageCells,	DPCell lastCell, DPCell currentCell) {


		for (DPCell dpCell : pageCells) {
			if(dpCell.getStringRepresentation().contains("Plan Request Type")){
				System.out.println();
			}
			if(dpCell.getRectangle().getY() > lastCell.getRectangle().getY() && dpCell.getRectangle().getY() < currentCell.getRectangle().getY()  ){
				return true;
			}
		}

		return false;
	}

	private PDFPara getEndPara(PDFPara startPara,Map<Integer, List<PDFPara>> pageWiseParas, Integer pg) {
		boolean startflag=false;

		for (int i = pg; i < pageWiseParas.keySet().size(); i++) {

			for ( PDFPara p : pageWiseParas.get(i) ) {
				if(startPara.equals(p))
				{
					startflag=true;
					continue;
				}

				if(startflag)
				{
					if(p.isEnumerated())
						return p;

				}
			}

		}

		if(pageWiseParas.containsKey(pg+1)){
			if(!pageWiseParas.get(pg+1).isEmpty()){
				return pageWiseParas.get(pg+1).get(0);
			}	
		}
		return null;
	}

	public  List<String> getRegexData(String regex,String content,int groupNum){
		// 		regex="([A-Z]{1,3}\\b|[0-9]{1,2}\\b)";
		//		 content=". See Answer to Section 12 E IX";
		if(content.contains("Question")){
			System.out.print("");
		}
		List<String> temp = new ArrayList<String>();
		Matcher m = Pattern.compile(regex).matcher(content);
		String val="";
		if(groupNum>0){
			//System.out.println(m.group());
			while(m.find()){
				val=m.group(groupNum);
				temp.add(val.trim());
			}
		}
		if(val.trim().isEmpty()){
			while(m.find())
				temp.add(m.group().trim());
		}
		return temp;
	}
	
public String getCoordinatesBox(List<PDFWord> list) {
		
		float x1=100000,y2=100000;
		
		float x2=-1,y1=-1;
		int pageNum=-1;
		String coordinatesBox="-1";
		if(list!=null && !list.isEmpty()){
			for (BasicStructure basicStructure : list) {
				if(pageNum==-1){
					pageNum=basicStructure.getRectangle().getPage()+1;
				}
				
				if(basicStructure.getRectangle().getX()<x1){
					x1=basicStructure.getRectangle().getX();
					
				}
				if(basicStructure.getRectangle().getX2()>x2){
					x2=basicStructure.getRectangle().getX2();
				}
				
				if(basicStructure.getRectangle().getY2()<y2){
					y2=basicStructure.getRectangle().getY2();
				}
				if(basicStructure.getRectangle().getY()>y1){
					y1=basicStructure.getRectangle().getY();
				}
			}
			if(x1!=100000 && y2!=100000 && x2!=-1 && y1!=-1){
				coordinatesBox= x1+","+y2+","+x2+","+y1+","+pageNum;
			}else{
				System.err.println("Coordinates Not Found");
			}
			
		}else{
			System.err.println("Null | Empty Structure List");
		}
		return coordinatesBox;
	}

	public static void main(String[] args) {
		//String str="submission for  injuries which you claim XYZ ABC.";
		//String regex="injuries which you claim(.*)";
		//		String str="NDC codes of any HT medication(s) ingested. See Answer to Question IX. MDL Fact Sheet - Bianchini ";
		//		String regex=".*(medication\\(s\\) ingested)(.*)";
		//
		//		if(str.matches(regex)){
		//			System.out.println("Match");
		//		}
		System.out.println("End");
		//String regex="COMES NOW Plaintiff (.*) and";
		RuleProcessor rp=new RuleProcessor(null, null, null, null, 0, null,null);
		List<String> res = rp.getRegexData("([0-9])", "Pttern(2)", -1);
		//
		//	System.out.println(res);

	}
}
