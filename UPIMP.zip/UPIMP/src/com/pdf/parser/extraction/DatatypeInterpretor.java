package com.pdf.parser.extraction;

import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.rules.Extraction_Result;

import edu.stanford.nlp.ie.AbstractSequenceClassifier;
import edu.stanford.nlp.ie.crf.CRFClassifier;
import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;

public class DatatypeInterpretor {
	public static AbstractSequenceClassifier<CoreLabel> nameFinder=null;
	public static Map<String,String>monthAndNum=new HashMap<String,String>();

	static List<String>	regex = null;

	public static List<String> dateRegex = new ArrayList<String>() ;

	static{
		try {
			String[] months = "jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec".split(",");
			for (int i = 0; i < months.length; i++) {
				if(i<9){
					monthAndNum.put(months[i], "0"+(i+1));
				}else{
					monthAndNum.put(months[i], ""+(i+1));
				}
			}
			BufferedReader reader = new BufferedReader(new FileReader("config/Date-Regex.list"));
			String line = "";
			while((line = reader.readLine()) != null){
				dateRegex.add(line.trim()+"\\b");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static List<String> getNER_Person(String content) {

		List<String> values = new ArrayList<String>();
		if(nameFinder==null){
			try {
				nameFinder = CRFClassifier.getClassifier("models/stanford-ner/english.all.3class.distsim.crf.ser.gz");
			} catch (ClassCastException | ClassNotFoundException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		List<List<CoreLabel>> labels = nameFinder.classify(content);

		for(List<CoreLabel> labelList : labels){
			for(int i=0 ; i<labelList.size() ; i++){
				CoreLabel label = labelList.get(i);
				if(label.get(CoreAnnotations.AnswerAnnotation.class).equals("PERSON")){

					String name = label.toString();
					for(int j=i+1;j<labelList.size();j++){
						CoreLabel nextLabel = labelList.get(j);
						i=j;
						if(!nextLabel.get(CoreAnnotations.AnswerAnnotation.class).equals("PERSON"))
							break;
						name += " "+nextLabel.toString();
					}
					if(name.split(" ").length==2){
						for(int k=i+2;k<labelList.size();k++){
							CoreLabel nextLabel = labelList.get(k);
							i=k;
							if(!nextLabel.get(CoreAnnotations.AnswerAnnotation.class).equals("PERSON"))
								break;
							name += " "+nextLabel.toString();
						}

					}
					if(name.split(" ").length>1){
						if(name.split(" ")[0].equalsIgnoreCase(name.split(" ")[1])){
							name=name.substring(name.indexOf(" "));
						}
					}
					if(name.split(" ").length<=3)
						values.add(name);
				}
			}
		}
		if(values.isEmpty() && (content.contains("@") ||content.contains("_"))){
			content=content.replaceAll("@", " @");
			content=content.replaceAll("_", " ");
			List<List<CoreLabel>> labels2 = nameFinder.classify(content);

			for(List<CoreLabel> labelList : labels2){
				for(int i=0 ; i<labelList.size() ; i++){
					CoreLabel label = labelList.get(i);
					if(label.get(CoreAnnotations.AnswerAnnotation.class).equals("PERSON")){

						String name = label.toString();
						for(int j=i+1;j<labelList.size();j++){
							CoreLabel nextLabel = labelList.get(j);
							i=j;
							if(!nextLabel.get(CoreAnnotations.AnswerAnnotation.class).equals("PERSON"))
								break;
							name += " "+nextLabel.toString();
						}
						values.add(name);
					}
				}
			}
		}
		return values;
	}
	public static List<String> getNER_Location(String content) {

		List<String> values = new ArrayList<String>();

		if(nameFinder==null){
			try {
				nameFinder = CRFClassifier.getClassifier("models/stanford-ner/english.all.3class.distsim.crf.ser.gz");
			} catch (ClassCastException | ClassNotFoundException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		List<List<CoreLabel>> labels = nameFinder.classify(content);

		for(List<CoreLabel> labelList : labels){
			for(int i=0 ; i<labelList.size() ; i++){
				CoreLabel label = labelList.get(i);

				if(label.get(CoreAnnotations.AnswerAnnotation.class).equals("LOCATION")){

					String name = label.toString();
					for(int j=i+1;j<labelList.size();j++){
						CoreLabel nextLabel = labelList.get(j);
						i=j;
						if(!nextLabel.get(CoreAnnotations.AnswerAnnotation.class).equals("LOCATION"))
							break;
						name += " "+nextLabel.toString();
					}
					//System.out.println("Location: "+name);
					values.add(name);
				}
			}
		}
		return values;
	}


	public static List<String> findPhone(String content){
		List<String> phones = new ArrayList<String>();
		String regex = "\\(?[\\d]{3}\\)?"
				+ "(\\s|\\.|-)"
				+ "[\\d]{3}"
				+ "(\\s|\\.|-)"
				+ "[\\d]{4}"; 

		Matcher m = Pattern.compile(regex).matcher(content);
		while(m.find())
			phones.add(m.group());

		return phones;
	}


	//Details, Currency, Number, Date, Percentage, Pattern, Person, Address, Company
	public static List<String> getExtractedValue(String content, String dataType){
		//TODO 
		List<String> values = new ArrayList<String>();

		if(content.trim().isEmpty()){
			return values;
		}
		String currencyPattern = "(USD|GBP|EUR)";

		if((dataType.matches("\\d+") || dataType.toLowerCase().trim().startsWith("detail")) && content.trim().length()>0){
			values.add(content);

		}else if(dataType.trim().equalsIgnoreCase("currency")){

			//Specific handling to include N/A as a valid value
			if(content.trim().toLowerCase().contains("n/a")){
				values.add("N/A");
				return values;

			}else if(content.trim().toLowerCase().endsWith("waived")){//Special handling for AS contracts
				values.add("WAIVED");
				//				return values;//Commenting because getting currencies and waived in the same sentence
			}

			//Problem of space between digits due to OCR
			Pattern space = Pattern.compile("\\d\\s(\\d|\\,|\\.)");
			Matcher spaceMatch = space.matcher(content);
			if(spaceMatch.find()){
				content = content.substring(0,spaceMatch.start()+1) + content.substring(spaceMatch.end()-1, content.length());
			}				

			if(Pattern.compile(currencyPattern+"\\s*\\d").matcher(content).find())
				content = content.replaceAll(currencyPattern+"[\\s]{0,}", "\\$");

			//Special fix for BNYM OCR issue - $l 5 coming as header
			if(content.matches("\\$l\\s\\d")){
				content = content.replace(" ", "").replace("l", "1");
			}

			String regex = "\\(?\\$\\s*\\d+((\\,\\s*\\d+){0,})?((\\.\\s*\\d+))?\\)?";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(content.replaceAll(currencyPattern, "").trim());//Special fix for BNY
			boolean found = false;
			while (m.find()){
				found = true;
				values.add(m.group());
			}

			//Following is to handle decimal number starting with decimal point that has no preceding digit
			if(!found){
				regex = "\\(?\\$\\s*(\\.\\s*\\d+)?\\)?";
				p = Pattern.compile(regex);
				m = p.matcher(content.replaceAll(currencyPattern, "").trim());//Special fix for BNY
				while (m.find())
					values.add(m.group());
			}

			regex = "\\d+((\\,\\s*\\d+){0,})?((\\.\\s*\\d+))?\\s*(USD|EUR|GBP)";//may include $
			p = Pattern.compile(regex);
			m = p.matcher(content.trim());
			while (m.find()){
				values.add(m.group());
			}

			//------------------remove spacial characters from TIV number
			if(values==null||values.isEmpty()){

			}else
			{
				List<String> olTemp=new ArrayList<String>();
				for (String val : values) {
					String str=val.replaceAll("[^0-9.]", "");
					olTemp.add(str);
				}
				values=olTemp;
			}

		}else if(dataType.trim().equalsIgnoreCase("text")){

			//Specific handling to include N/A as a valid value
			content=content.replaceAll("[^A-Z,a-z]", " ").replaceAll("\\s+", " ").trim();
			values.add(content);
			return values;

		}else if(dataType.trim().equalsIgnoreCase("number")){

			//Specific handling to include N/A as a valid value
			if(content.trim().toLowerCase().contains("n/a")){
				values.add("N/A");
				return values;

			}else if(content.trim().toLowerCase().endsWith("waived")){//Special handling for AS contracts
				values.add("WAIVED");
				return values;
			}

			//Problem of space between digits due to OCR
			Pattern space = Pattern.compile("\\d\\s(\\d|\\,|\\.)");
			Matcher spaceMatch = space.matcher(content);
			if(spaceMatch.find()){
				content = content.substring(0,spaceMatch.start()+1) + content.substring(spaceMatch.end()-1, content.length());
			}

			String regex = "(-)?\\d+((\\,\\s*\\d+){0,})?((\\.\\s*\\d+))?";//may include $
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(content.replace("USD", "").trim());
			boolean found = false;
			while (m.find()){

				found = true;

				if(m.start()-2>=0 && content.charAt(m.start()-2)=='$')
					continue;

				if(m.start()-1>=0 && content.charAt(m.start()-1)=='$')
					continue;

				if(content.indexOf(m.group())-1>=0 && content.charAt(content.indexOf(m.group())-1)=='.'){
					found = false;
					continue;
				}

				values.add(m.group());
			}

			//Following is to handle decimal number starting with decimal point that has no preceding digit
			//			if(!found){
			regex = "((^\\.)|(\\s\\.))\\d+";//may include $
			p = Pattern.compile(regex);
			m = p.matcher(content.replace("USD", "").trim());
			while (m.find()){

				if(m.start()-2>=0 && content.charAt(m.start()-2)=='$')
					continue;

				if(m.start()-1>=0 && content.charAt(m.start()-1)=='$')
					continue;

				values.add(m.group());
			}
			//			}

		}else if(dataType.trim().equalsIgnoreCase("date")){

			values = getCustomNERForDate(content, false);

		}else if(dataType.trim().equalsIgnoreCase("percentage")){

			String regex = "\\d+\\s*(\\.\\s*\\d+)?\\s*%";
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(content);
			while (m.find())
				values.add(m.group());

		}else if(dataType.trim().toLowerCase().contains("pattern")){

			//	if(rule.getDataType().toLowerCase().contains("pattern")){
			String[] dtAndPattern = dataType.split("##"); //pattern(2)## (submission of)(.*)(INC|LTD)

			List<String> group=getRegexData("([0-9])", dtAndPattern[0], 1);

			if(!group.isEmpty()){
				values=getRegexData(dtAndPattern[1].trim(),content, Integer.valueOf(group.get(0).trim()));
			}

			if(values.isEmpty() && !content.isEmpty()){
				values.add(content);
			}

		}else if(dataType.trim().equalsIgnoreCase("person")){
			values=getNER_Person(content.replaceAll("[^A-Za-z ]", "").trim());

		}else if(dataType.trim().toLowerCase().contains("address")){  //Address

			String add = "";//findAddress(content);
			if(!add.trim().isEmpty()&& add.trim().length()>4){
				values.add(add);
			}

			//	 if(values.isEmpty())
			//		 values=getNER_Location(content);

		}else if(dataType.trim().toLowerCase().contains("period-from")){

			//****UTF Chars for dash: 8210 to 8215, 8259, 8275
			content = correctDashes(content);
			//*******************

			content = content.replaceAll("[\\s]{2,}", " ");

			List<String> dates = getCustomNERForDate(content, false);
			for(int i=0; i<dates.size()-1; i++){
				if(content.matches(".*"+dates.get(i)+"\\s?(-|to)\\s?(\\d+)") || 
						content.matches(".*"+dates.get(i)+"\\s?(-|to)\\s?"+dates.get(i+1))){
					values.add(dates.get(i));
				}
			}
			if(dates.size()==1 && content.matches(".*("+dates.get(0)+")\\s?(-|to)\\s?(\\d+)")){
				values.add(dates.get(0));
			}
			if(dates.size()==2 && content.matches(".*"+dates.get(0).trim()+" ?(-|to)\\s?"+dates.get(1).trim())){
				values.add(dates.get(0));
			}
			else if(dates.size()==2 && content.matches(".*"+dates.get(1).trim()+" ?(-|to)\\s?"+dates.get(0).trim())){
				values.add(dates.get(1));

			}
		}else if(dataType.trim().toLowerCase().contains("period-to")){

			//****UTF Chars for dash: 8210 to 8215, 8259, 8275
			content = correctDashes(content);
			//*******************

			content = content.replaceAll("[\\s]{2,}", " ");

			List<String> dates = getCustomNERForDate(content, false);
			for(int i=0; i<dates.size(); i++){
				if(i+1<dates.size() && content.matches(".*"+dates.get(i).trim()+" ?(-|to)\\s?"+dates.get(i+1).trim())){
					values.add(dates.get(i+1));

				}else if(i+1<dates.size() && content.matches(".*"+dates.get(i+1).trim()+" ?(-|to)\\s?"+dates.get(i).trim())){
					values.add(dates.get(i));

				}else if(content.matches(".*"+dates.get(i)+"\\s?(-|to)\\s?(\\d+)")){
					Pattern p = Pattern.compile(".*("+dates.get(i)+")\\s?(-|to)\\s?(\\d+)");
					Matcher m = p.matcher(content);
					while(m.find()){
						char[] fromDate = dates.get(i).toCharArray();
						String toYear = m.group(3);
						for(int j=fromDate.length-1, k=toYear.length()-1; j>=0 && k>=0; j--, k--){
							fromDate[j] = toYear.charAt(k);
						}
						values.add(new String(fromDate));
					}
				}
			}
		}

		if(values!=null)
			return new ArrayList<String>(new HashSet<String>(values));

		return values;
	}


	static List<PDFSegment>resultSegs;

	public static List<PDFSegment> getResultSegs() {
		return resultSegs;
	}
	
	public static List<String> getCheckBoxResult(String content,List<PDFWord>checkBoxWords,PDPage page, String dataType,Map<Integer,BufferedImage> pageAndImage, List<PDFSegment> pageSegs)
	{


			resultSegs=new ArrayList<PDFSegment>();
		List<String>initialResult=new ArrayList<String>();
		if(dataType.contains("_") && !content.isEmpty()){
			initialResult=getExtractedValue(content, dataType.split("_")[0]);

		}


		float height_pdf =0;
		float width_pdf = 0;

		if(page.getBleedBox()!=null){
			height_pdf = page.getBleedBox().getHeight();
			width_pdf = page.getBleedBox().getWidth(); 
		}
		else if(page.getMediaBox()!=null){
			height_pdf = page.getMediaBox().getHeight();
			width_pdf = page.getMediaBox().getWidth(); 
		}
		else if(page.getTrimBox()!=null){
			height_pdf = page.getTrimBox().getHeight();
			width_pdf = page.getTrimBox().getWidth(); 
		}


		List<String>resultText=new ArrayList<String>(); 
		if(height_pdf==0&& width_pdf==0){
			return resultText;
		}

		BufferedImage image = null;
		if(pageAndImage.get(checkBoxWords.get(0).getRectangle().getPage())!=null){
			image  = pageAndImage.get(checkBoxWords.get(0).getRectangle().getPage());
		}
		/*try {
			image  = page.convertToImage(BufferedImage.TYPE_INT_RGB,500);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/

		CheckBoxProcessor cbp=new CheckBoxProcessor();
		for (PDFWord pdfWord : checkBoxWords) {
			try{
				boolean  result=false;
				if(dataType.equalsIgnoreCase("checkbox")){
					float x=pdfWord.getRectangle().getX();
					float y=pdfWord.getRectangle().getY();
					result = cbp.check_box_LeftDirection(x,  y,  width_pdf,  height_pdf,   image);
					System.out.println("");

				}else{
					float x2=pdfWord.getRectangle().getX2();
					float y=pdfWord.getRectangle().getY();
					
					result = cbp.check_box_RightDirection(x2,  y,  width_pdf,  height_pdf,   image);
					
				}
				if (result) {
					System.out.println("Checkbox Is Selected True for \t"+pdfWord.getStringRepresentation());
					/*if(!initialResult.isEmpty()){
						resultText.add(initialResult.get(0)+" "+pdfWord.getStringRepresentation());
					}else{
						resultText.add(pdfWord.getStringRepresentation());
					}*/
					//break; 

					for (PDFSegment ss : pageSegs) {

						for (PDFWord w : ss.getWords()) {
							if(w.equals(pdfWord)){
								resultSegs.add(ss);
								initialResult.add(ss.getStringRepresentation());
								resultText.add(ss.getStringRepresentation());
								break;
							}
						}
					}
				}
				/* else {
				System.out.println("Checkbox Is Not Selected for \t"+pdfWord.getStringRepresentation());

			}*/
			}catch (Exception e){
				e.printStackTrace();
			}

		}

		if(resultText.isEmpty()){
			//handle CEP Front X : X before CheckBox

			if(dataType.equalsIgnoreCase("checkbox")){
				//check_box_LeftDirection(x,  y,  width_pdf,  height_pdf,   image);
				resultText = detect_X_BeforeWord(pageSegs,checkBoxWords);

			}else{
				//check_box_RightDirection(x2,  y,  width_pdf,  height_pdf,   image);

				resultText = detect_X_AfterWord(pageSegs,checkBoxWords);

			}

			/*if(values!=null && !values.isEmpty()){
				matchedWords=getCheckBoxmatchedWords(checkBoxWords,values);
				Extraction_Result er=new Extraction_Result(0, 0, rule, checkBoxWords.get(0).getRectangle().getY(), checkBoxWords.get(0).getRectangle().getPage());
				er.getResultSegments().addAll(matchedWords);
				er.setOutputList(values);
				fresh.add(er);
			}*/
		}
		return resultText;
	}


	private static List<String> detect_X_BeforeWord(List<PDFSegment> pageSegs,	List<PDFWord> checkBoxWords) {

		List<String>temp=new ArrayList<String>();

		for (PDFWord chboxWord : checkBoxWords) {

			List<PDFWord> backWords = FormProcesses.getBackWords(chboxWord, pageSegs);
			if(backWords!=null && !backWords.isEmpty()){
				if(!chboxWord.equals(backWords.get(backWords.size()-1)) && backWords.get(backWords.size()-1).getStringRepresentation().equalsIgnoreCase("x"))
					temp.add(chboxWord.getStringRepresentation());
			}

		}
		return temp;
	}

	private static List<String> detect_X_AfterWord(List<PDFSegment> pageSegs,	List<PDFWord> checkBoxWords) {

		List<String>temp=new ArrayList<String>();

		for (PDFWord chboxWord : checkBoxWords) {

			for (PDFSegment seg : pageSegs) {

				List<PDFWord> segWords = seg.getWords();

				List<PDFWord> frontwords = FormProcesses.getFrontWords(chboxWord, segWords);

				if(frontwords!=null && !frontwords.isEmpty()){
					if(!chboxWord.equals(frontwords.get(0)) && frontwords.get(0).getStringRepresentation().equalsIgnoreCase("x"))
						temp.add(chboxWord.getStringRepresentation());
				}
			}
		}
		return temp;
	}


	public static String correctDashes(String content){

		Vector<String> dates = getCustomNERForDate(content, false);

		if(dates.size()==2){
			String	temp=content;
			temp=temp.replace(dates.get(0), "");
		}

		for(int i=0; i<content.length(); i++){
			int code = content.charAt(i);
			if((code>=8210 && code<=8215) || code==8259 || code==8275|| content.charAt(i)=='-'||isDash(content.charAt(i))){
				String start = content.substring(0,i);
				String end = i<content.length()-1 ? content.substring(i+1) : ""; 
				content = start+"-"+end;
			}
		}

		return content;
	}

	static List<String>dash=Arrays.asList("-,־ ,‐,‑,‒,–,―,⁻,₋,−,﹣,－,᠆,-".split(","));


	private static	boolean isDash(char c){
		for (String d : dash) {
			if(!d.trim().isEmpty() && d.charAt(0)==c){
				return true;
			}
		}
		return false;
	}


	public static Vector<String> getCustomNERForDate(String eachSentence, boolean isTable) {
		Vector<String> ret = new Vector<String>();
		List<String> regexList = dateRegex;
		boolean continueFlag = false ;
		for (String regex : regexList) 
		{
			Pattern p = Pattern.compile(regex);
			Matcher m = p.matcher(eachSentence);
			boolean flag = false ;
			while (m.find()) 
			{
				String dateStr=m.group(0);
				//dateStr=modifyDate(dateStr).trim();
				//				if(dateStr.contains(" "))
				//					dateStr=dateStr.replaceAll(" ", "/");
				ret.add(dateStr);
				flag = true ;
				eachSentence = eachSentence.substring( (eachSentence.indexOf(m.group(0))
						+ m.group(0).length())
						, eachSentence.length() ) ;
				if( eachSentence.length()>0  && !continueFlag)
					continueFlag = true ;
			}
			if( flag && !continueFlag )
				break;
		}
		ret = new Vector<String>(new HashSet<String>(ret));

		return ret;
	}

	private static String modifyDate(String dateStr) {
		dateStr=dateStr.toLowerCase();
		if(dateStr.toLowerCase().replaceAll("[^a-z]", "").length()<1){
			return dateStr;
		}else{
			Pattern p=Pattern.compile("[a-z]*");
			Matcher m = p.matcher(dateStr);
			while(m.find()){
				String text=m.group();
				if(!text.trim().isEmpty()){

					for (String mnth : monthAndNum.keySet()) {
						if(dateStr.contains(mnth)){
							dateStr=dateStr.replaceAll(text, ""+monthAndNum.get(mnth));
							return dateStr;
						}
					}
					//return text;
				}

			}

		}
		return dateStr;
	}

	public static void main2(String[] args) throws IOException {

		//String addressFilePath=args[0];
		String addressFilePath="C:/Users/bb0e1165/Desktop/addresses.txt";
		List<String>addresses=new ArrayList<String>();

		BufferedReader reader = new BufferedReader(new FileReader(addressFilePath));
		String line = "";
		while((line = reader.readLine()) != null){
			String street = line.trim();
			addresses.add(street);
		}
		reader.close();

		if(!addresses.isEmpty()){
			System.out.println("Addresses size:\t"+addresses.size());
			int cnt=1;
			for (String add : addresses) {
				String ss = "";//findAddress(add);
				if(!ss.isEmpty()){
					System.out.println(cnt+++"\tAddress:\t"+ss);
				}else{
					System.out.println(cnt+++"\tMissing Address:\t"+add);
				}
			}
		}
	}

	public static  List<String> getRegexData(String regex,String content,int groupNum){
		// 		regex="([A-Z]{1,3}\\b|[0-9]{1,2}\\b)";
		//		 content=". See Answer to Section 12 E IX";
		List<String> temp = new ArrayList<String>();
		Matcher m = Pattern.compile(regex).matcher(content);
		String val="";
		if(groupNum>0){
			//System.out.println(m.group());
			while(m.find()){
				val=m.group(groupNum);
				temp.add(val.trim());
			}
		}
		if(val.trim().isEmpty()){
			while(m.find())
				temp.add(m.group().trim());
		}
		return temp;
	}

	public static void main(String[] args) {
		//broker_company //insured_company
		//System.out.println(getNER_Person("The underwriter on this account Sherlyn Little will soon be in contact with you."));
		//System.out.println(findCompanies("This message is to confirm the risk you submission for TJD Holdings LLC DBA GATES Construction has been cleared. The underwriter on this account Lisa Tischendorf will soon be in contact with you.","company"));//Ex - AmWINS Brokerage & Florida Inc.
		//System.out.println(getNER_Person("Jeffrey S. Dunn"));//Ex - AmWINS Brokerage & Florida Inc.
		//Amber Sipos with you.
		//	System.out.println(isDash('-'));
		//System.out.println("Done");
		//System.out.println("OP\t"+findCompanies("submission for “Redifield Village” has been cleared for.","insured_company"));
		//		String ss = findAddress("Inc. 10375 Richmond Avenue, Ste 500 Houston, TX 77042 Dire:");
		//		System.out.println("Res:\t"+ss);

		//		List<String> ss = DBOperations.getList("Broker_Name");
		//System.out.println("----"+broker_List);

	}
}
