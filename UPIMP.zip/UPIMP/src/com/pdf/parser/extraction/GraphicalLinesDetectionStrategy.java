package com.pdf.parser.extraction;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFGraphicalLine;

import edu.stanford.nlp.parser.lexparser.Extractor;


/*import com.pdf.parser.base.PDFWord;
import com.pdf.parser.pipeline.DefaultParser;*/
//com.pdf.parser.complex.strategy.GraphicalLinesDetectionStrategy.java
public class GraphicalLinesDetectionStrategy {

	int threshold=140;
	BufferedImage img, oimg;
	int VerticalGap = 60;
	List<PDFGraphicalLine> HLine= null;
	float hRatio=0;
	float wRatio =0;



	public List<DPCell> extractPageCell(int pg, PDPage pdPage,String outputDirPath) throws IOException
	{
		/*-------Get image of pdf page stored in buffer--------*/
		try {
			oimg = pdPage.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
			img = Thresholding(oimg);
			//			oimg = pdPage.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		/*---------Converting image into gray scale then into binary for better line detection ----------*/
		//img = ImagePreprocessing.Thresholding(img);

		Graphics2D graphics = oimg.createGraphics();
		graphics.drawImage(oimg, 0, 0, null);


		/*try {
			img = pdPage.convertToImage(BufferedImage.TYPE_INT_RGB, 500);
			//					ImageIO.write(img,"png",new File(Dir+File.separator+fname+pg+".png"));
			img = Thresholding(img);
			oimg = pdPage.convertToImage(BufferedImage.TYPE_INT_RGB, 500); 
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e+" page-"+pg);
		}
		 */		hRatio = img.getHeight()/(pdPage.getMediaBox().getHeight());
		 wRatio = img.getWidth()/(pdPage.getMediaBox().getWidth()); 


		 List<PDFGraphicalLine> horizontalLines = GetCells.detectLinesImageBased(img, true);
		 //		List<PDFGraphicalLine> combinedHorizontalLines = combineNearestHorizontalLines2(horizontalLines, VerticalGap);
		 List<PDFGraphicalLine> combinedHorizontalLines = combineNearestLines(horizontalLines, true);

		 /*graphics.setColor(Color.BLUE);
		graphics.setFont(new Font("TimesRoman", Font.BOLD, 22));
		int i=-1;
		for (PDFGraphicalLine pdfGraphicalLine : combinedHorizontalLines) {
			i++;
			graphics.drawLine((int)pdfGraphicalLine.getX(),(int) pdfGraphicalLine.getY(), (int)pdfGraphicalLine.getX2(),(int) pdfGraphicalLine.getY2());
			graphics.drawChars(("Line "+i).toCharArray(), 0,("Line "+i).toCharArray().length,(int)pdfGraphicalLine.getX()-5,(int) pdfGraphicalLine.getY()-5);
		}
		ImageIO.write(oimg, "PNG", new File("test1_Line.png"));//"D:\\Platform\\Sample\\SwissRe\\Sample" + File.separator + "cellExtraction.png"));
		  */

		 List<PDFGraphicalLine> verticalLines =GetCells.detectLinesImageBased(img, false);
		 List<PDFGraphicalLine> combinedverticalLines = combineNearestLines(verticalLines, false);
		 /*graphics.setColor(Color.RED);
		graphics.setFont(new Font("TimesRoman", Font.BOLD, 22));
		i=-1;
		for (PDFGraphicalLine pdfGraphicalLine : combinedverticalLines) {
			i++;
			graphics.drawLine((int)pdfGraphicalLine.getX(),(int) pdfGraphicalLine.getY(), (int)pdfGraphicalLine.getX2(),(int) pdfGraphicalLine.getY2());
			graphics.drawChars(("Line "+i).toCharArray(), 0,("Line "+i).toCharArray().length,(int)pdfGraphicalLine.getX()-5,(int) pdfGraphicalLine.getY()-5);
		}
		ImageIO.write(oimg, "PNG", new File("test1_LineV.png"));
		  */
		 graphics.setColor(Color.RED);
		 graphics.setFont(new Font("TimesRoman", Font.BOLD, 28));
		 List<DPCell> pageCells=new ArrayList<DPCell>();
		 int  rowCount=0;
		 if (combinedHorizontalLines.size()>0 
				 && combinedverticalLines.size()>0) {
			 for (int index = 0; index < combinedHorizontalLines.size()-1; index++) {
				 /*---------Getting cells for rows i.e. between line 1 and 2 and so on...---------*/

				 List<DPRectangle> rectangles = GetCells.getCellsInHorizontalLines(combinedHorizontalLines,
						 index, combinedverticalLines, img, pg);
				 if (!rectangles.isEmpty()) {
					 rowCount++;
				 }
				 //System.out.println("RS: "+rectangles.size());
				 /*---------Iterating cells loop with pdf words for given page and getting words lies within boundary formed cells------------*/
				 for (int rectIndex = 0; rectIndex < rectangles.size(); rectIndex++) {

					 DPRectangle rectangle = rectangles.get(rectIndex);
					 graphics.drawRect((int) rectangle.getX(), (int) rectangle.getY(), (int) rectangle.getWidth(),
							 (int) rectangle.getHeight());
					 graphics.drawChars((rowCount - 1 + "," + rectIndex).toCharArray(), 0,
							 (rowCount - 1 + "," + rectIndex).length(),(int) rectangle.getX() + 20,
							 (int) rectangle.getY() + 20);

					 List<BasicStructure> paraList=new ArrayList<BasicStructure>();

					 DPCell dc=new DPCell(0, rowCount-1, rectIndex, rectangle, "", "", paraList, 0);
					 pageCells.add(dc);
				 }
			 }
		 }

		 graphics.dispose();
		 //System.out.println(pageCells.size());
		 /*try{
			 if(new File(outputDirPath).isDirectory() && Extractor.email_config.getString("imageCreate").equalsIgnoreCase("true")){
				 ImageIO.write(oimg, "PNG", new File(outputDirPath+"/"+"temp.png"));//"D:\\Platform\\Sample\\SwissRe\\Sample" + File.separator + "cellExtraction.png"));
			 }
		 }catch(Exception o){
			 System.out.print("");
			// continue;
		 }*/
		 if (pageCells.size()>0) {
			 for (DPCell dpCell : pageCells) {
				 dpCell.getRectangle().setX(dpCell.getRectangle().getX()/wRatio);
				 dpCell.getRectangle().setWidth(dpCell.getRectangle().getWidth()/wRatio);
				 dpCell.getRectangle().setY(dpCell.getRectangle().getY()/hRatio);
				 //dpCell.getRectangle().setY((dpCell.getRectangle().getY()+dpCell.getRectangle().getHeight())/hRatio);	
				 dpCell.getRectangle().setHeight(dpCell.getRectangle().getHeight()/hRatio);
				// System.out.print("");
			 }
		 }

		 return pageCells;

	}

	/**
	 * Combines horizontal lines which are close to each other. Closeness is
	 * decided based on vertical gap between lines.
	 * 
	 * @param horizontalLines
	 *            : List of all horizontal lines.
	 * @param yGap
	 *            : Expected vertical gap between two horizontal lines.
	 * @return : List of new horizontal lines.
	 */
	public List<PDFGraphicalLine> combineNearestHorizontalLines(List<PDFGraphicalLine> horizontalLines, int yGap) {

		final int Y1_INITIAL_VALUE = -1;
		final int X1_INITIAL_VALUE = -1;
		final int MINIMUM_HORIZONTAL_LINE_WIDTH = 100;

		int newX2 = 0;
		int lineIndex = 0;
		int prevY1 = Y1_INITIAL_VALUE;
		int prevX1 = X1_INITIAL_VALUE;
		List<PDFGraphicalLine> newHorizontalLines = new ArrayList<PDFGraphicalLine>();
		Collections.sort(horizontalLines,	new Comparator<Object>() {
			public int compare(Object o1,Object o2) {
				//			int ret = -1;
				PDFGraphicalLine r1 = (PDFGraphicalLine)o1;
				PDFGraphicalLine r2 = (PDFGraphicalLine)o2;
				return Integer.valueOf((int)r1.getX()).compareTo((int)r2.getX());
			}
		});
		for (PDFGraphicalLine line : horizontalLines) {
			lineIndex++;
			if (prevY1 == Y1_INITIAL_VALUE) {
				prevX1 = (int) line.getX();
				prevY1 = (int) line.getY();
			} else {
				if (Math.abs(line.getY() - prevY1) < yGap) {
					if (line.getX() < prevX1) {
						prevX1 = (int) line.getX();
						prevY1 = (int) line.getY();
					}
					if (newX2 < line.getX2()) {
						newX2 = (int) line.getX2();
					}
					if (lineIndex == horizontalLines.size()) // for last line
					{
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
					}
				} else if ((line.getY() - prevY1) > yGap) {
					// added NewX2 comparison to
					// avoid continuous lines
					if ((newX2 - prevX1) > MINIMUM_HORIZONTAL_LINE_WIDTH) {
						int x1 = (int) line.getX();
						int y1 = (int) line.getY();
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
						prevY1 = y1;
						prevX1 = x1;
						newX2 = (int) line.getX2();//0;
					} else {
						prevY1 = (int) line.getY(); // prevY2 = y2 ;
						prevX1 = (int) line.getX();
						newX2 = (int) line.getX2();//0;// H.getX2();
					}
				}
			}
		}
		// HLine.subList(i+1, HLine.size()).clear();

		return newHorizontalLines;
	}

	public List<PDFGraphicalLine> combineNearestHorizontalLines2(List<PDFGraphicalLine> horizontalLines, int yGap) {

		final int INITIAL_VALUE = -1;

		final int MINIMUM_HORIZONTAL_LINE_WIDTH = 0;

		int newX2 = 0;
		int lineIndex = 0;
		int prevY1 = INITIAL_VALUE;
		int prevX1 = INITIAL_VALUE;
		int prevX2 = INITIAL_VALUE;
		List<PDFGraphicalLine> newHorizontalLines = new ArrayList<PDFGraphicalLine>();
		List<PDFGraphicalLine> newHorizontalLines2 = new ArrayList<PDFGraphicalLine>();

		for (PDFGraphicalLine line : horizontalLines) {
			lineIndex++;
			if (prevY1 == INITIAL_VALUE) {
				newHorizontalLines2.add(line);
				prevX1 = (int) line.getX();
				prevX2 = (int) line.getX2();
				prevY1 = (int) line.getY();
			} else {
				if (Math.abs(prevX1 - line.getX())<5
						&& Math.abs(prevX2 - line.getX2())<5 
						&& line.getY() - prevY1<10) {
					//					newHorizontalLines2.remove(lineIndex-1);
				}
				else {
					newHorizontalLines2.add(line);
					prevX1 = (int) line.getX();
					prevX2 = (int) line.getX2();
					prevY1 = (int) line.getY();
				}
				if (Math.abs(line.getY() - prevY1) < yGap) {
					if (line.getX() < prevX1) {
						prevX1 = (int) line.getX();
						prevY1 = (int) line.getY();
					}
					if (newX2 < line.getX2()) {
						newX2 = (int) line.getX2();
					}
					if (lineIndex == horizontalLines.size()) // for last line
					{
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
					}
				} else if ((line.getY() - prevY1) > yGap) {
					// added NewX2 comparison to
					// avoid continuous lines
					if ((newX2 - prevX1) > MINIMUM_HORIZONTAL_LINE_WIDTH) {
						int x1 = (int) line.getX();
						int y1 = (int) line.getY();
						line.setX(prevX1);
						line.setX2(newX2);
						line.setY(prevY1);
						line.setY2(prevY1);
						newHorizontalLines.add(line);
						prevY1 = y1;
						prevX1 = x1;
						newX2 = (int) line.getX2();//0;
					} else {
						prevY1 = (int) line.getY(); // prevY2 = y2 ;
						prevX1 = (int) line.getX();
						newX2 = (int) line.getX2();//0;// H.getX2();
					}
				}
			}
		}
		// HLine.subList(i+1, HLine.size()).clear();

		return newHorizontalLines2;
	}

	public List<PDFGraphicalLine> combineNearestLines(List<PDFGraphicalLine> allLines,boolean horizontal) {
		List<PDFGraphicalLine> updatedLines = new ArrayList<PDFGraphicalLine>() ;
		if (horizontal) {
			updatedLines =new ArrayList<PDFGraphicalLine>(allLines);
			for (PDFGraphicalLine line : allLines) {
				/*if((int)line.getX2()==397 || (int)line.getX2()==398 ){
					System.out.println("debug");
				}*/
				if(updatedLines.contains(line))
					for (PDFGraphicalLine innnerLine : updatedLines) {
						if(line!=innnerLine 
								&&(Math.abs(line.getY()-innnerLine.getY())<=10) 
								&& (Math.abs(line.getX()-innnerLine.getX())<=5)
								&& (Math.abs(line.getX2()-innnerLine.getX2())<=5)){
							if(line.getWidth()<innnerLine.getWidth())
								updatedLines.remove(line);
							else
								updatedLines.remove(innnerLine);
							break;
						}
						else if(line!=innnerLine &&(Math.abs(line.getY()-innnerLine.getY())<=3) && (Math.abs(line.getX2()-innnerLine.getX2())<=2)){
							if(line.getWidth()<innnerLine.getWidth())
								updatedLines.remove(line);
							else
								updatedLines.remove(innnerLine);
							break;
						}
					}
			}
		}
		else{
			//		List<PDFGraphicalLine> verticalLines = detectLines(img, false);
			updatedLines =new ArrayList<PDFGraphicalLine>(allLines);
			for (PDFGraphicalLine line : allLines) {
				if(updatedLines.contains(line))
					for (PDFGraphicalLine innnerLine : allLines) {
						if(line!=innnerLine 
								&&(Math.abs(line.getX()-innnerLine.getX())<=10) 
								&& (Math.abs(line.getY()-innnerLine.getY())<=5)
								&& (Math.abs(line.getY2()-innnerLine.getY2())<=5) ){
							updatedLines.remove(innnerLine);
						}
						/*else if(line!=innnerLine &&(Math.abs(line.getX()-innnerLine.getX())<=5) && (Math.abs(line.getY2()-innnerLine.getY2())<=5)){
						if(line.getWidth()<innnerLine.getWidth())
							updatedHLines.remove(line);
						else
							updatedHLines.remove(innnerLine);
						break;
					}*/
					}
			}
			/*if(updatedVLines!=null && updatedVLines.size()>0){
				if(updatedHLines==null || updatedHLines.size()==0){
					updatedHLines =new ArrayList<PDFGraphicalLine>();
					updatedHLines.addAll(updatedVLines);
				}
				else
					updatedHLines.addAll(updatedVLines);
			}*/
		}

		return updatedLines;

	}

	public int gray (int xImg, int yImg)
	{
		Color c = new Color(oimg.getRGB(xImg,yImg));
		int red = (int) (c.getRed() * 0.299);
		int green = (int) (c.getGreen() * 0.587);
		int blue = (int) (c.getBlue() * 0.114);

		int k = truncate( red + green + blue);
		return k ;
	}

	public BufferedImage Thresholding(BufferedImage img) {
		int newPixel = 0;
		BufferedImage binarize = new BufferedImage(img.getWidth(), img.getHeight(),BufferedImage.TYPE_INT_BGR);
		for(int i=0; i<img.getWidth(); i++)
		{
			for(int j=0; j<img.getHeight(); j++)
			{
				int alpha = new Color(img.getRGB(i, j)).getRed();
				//int gray = gray(i, j);
				if(alpha< threshold)
				{
					newPixel =0;
				}
				else{
					newPixel =255;
				}
				int rgb=new Color(newPixel, newPixel, newPixel).getRGB();
				//				newPixel = colorToRGB(alpha, newPixel, newPixel, newPixel);
				binarize.setRGB(i, j, rgb);
			}
		}

		return binarize;
	}

	public int truncate(int a) {
		if      (a <   0) return 0;
		else if (a > 255) return 255;
		else              return a;
	}
	//get page line tables 

	/*	public Map<Integer, List<List<Cell>>>  getPageTablesapply(List<com.dp.nda.pdf.beans.PDFWord>pageWords,Map<Integer,Map<Integer, List<Rectangle>> pageCellsData)
	{
		//List<PDFWord>pageWords;
		Map<Integer, List<List<LineCell>>> pageTables=new HashMap<K, V>();
	//	Map<Integer, List<Rectangle>> pageCellsData;

		if(pageCellsData.size()>2){
				for (int i = 1; i <=pageCellsData.size(); i++) {

					List<List<Rectangle>>rows=new ArrayList<List<Rectangle>>();
					double diff;
					List<Rectangle>  prev= pageCellsData.get(i-1);
					rows.add(prev);
					List<Rectangle> current;
					do{
						current= (pageCellsData.containsKey(i) ? pageCellsData.get(i):null );
						if(current==null)break;

						diff = Math.abs((prev.get(0).getY()+prev.get(0).getHeight())-(current.get(0).getY()));
						if(diff<2){
							prev=current;
							rows.add(current);
							i++;
						}else{
							break;
						}

					}while(i <= pageCellsData.size());

					if(rows.size()>1){ //row size is greater than 1
					 List<List<LineCell>>tableRowCells=new ArrayList<LineCell>();
						int row=0,col=0;

						for ( List<Rectangle> rowRects : rows) {
							List<LineCell>rowCells=new ArrayList<LineCell>();

							for (Rectangle colRect : rowRects) {

								float y2 = (float)colRect.getY();
								float y = (float) (y2+ colRect.getHeight());
								float x=(float) colRect.getX();
								float x2=(float) (x+colRect.getWidth());

								List<PDFWord> temp = getRectWords(colRect, pageWords);
								String cellText="";
								for (PDFWord pdfSegment : temp) {
									cellText=(cellText+" "+pdfSegment.getStringRepresentation()).trim();
								}
								LineCell lc=new LineCell(x, y, (float)colRect.getWidth(), (float)colRect.getHeight(),pageNo ,cellText, StructureType.LINECELL.toString(), temp,row,col);
								rowCells.add(lc);
								col++;
							}
							tableRowCells.add(rowCells);
							row++;
						}
						if(pageTables.size()==0){
							pageTables.put(0, tableRowCells);
						}else{
							pageTables.put(pageTables.size()+1, tableRowCells);
						}
					}
				}
			}

		return pageTables;
		}


	private List<PDFWord> getRectWords(Rectangle rect,List<PDFWord> pageWords) {
		float y2 = (float)rect.getY();
		float y = (float) (y2+ rect.getHeight());
		double x=rect.getX();
		double x2=x+rect.getWidth();

		List<PDFWord> temp=new ArrayList<PDFWord>();

		for (PDFWord seg : pageWords) {
			if(seg.getRectangle().getY()<=y
					&& seg.getRectangle().getY2()>=y2
					&& seg.getRectangle().getX()>=x
					&& seg.getRectangle().getX2()<=x2
					){

				temp.add(seg);
			}
		}

		return temp;
	}*/

	public static void main(String[] args) {
		System.out.println("Start");
		try {
			String filepath =args[0];
			int pg = Integer.valueOf(args[1]);
			PDDocument pdf = PDDocument.load(filepath);
			
			File f=new File(filepath);
			String dir = f.getParentFile().getAbsolutePath();
			
			PDPage page = (PDPage) pdf.getDocumentCatalog().getAllPages().get(pg);
			//		outputPath=new File(pathname)
			System.out.println("dir:\t"+dir);
			GraphicalLinesDetectionStrategy gs=new GraphicalLinesDetectionStrategy();
			List<DPCell> pageResult;
			pageResult = gs.extractPageCell(pg,page,dir);
			System.out.println("pageResult size:\t"+pageResult.size());
		} catch (IOException e) {
			e.printStackTrace();
		}
	
	}

	/*public void main2(String[] args) throws Exception{


		try{
			System.out.println("Start");
			String filepath =args[0];
			int pg = Integer.valueOf(args[1]);
			//String out =args[2];
			//			long t1 = System.currentTimeMillis();
			//String filepath = "D:/SwissRe/SwissRe-Extraction/Samples/AWD138708/temp-out.pdf";
			//int pg=1;

			PDDocument pdf = PDDocument.load(filepath);
			File f=new File(filepath);
			//String fileName =file.getName();
			String dir = f.getParentFile().getAbsolutePath();
			//	GraphicalLinesDetectionStrategy.createPDFpageImage(pdf,fileName);
			PDPage page = (PDPage) pdf.getDocumentCatalog().getAllPages().get(pg);
			//			outputPath=new File(pathname)
			System.out.println("dir:\t"+dir);
			List<DPCell> pageResult = extractPageCell(pg,page,dir);
			//			long t2 = System.currentTimeMillis();
			//			System.out.println("Total time: "+ (t2-t1));
			System.out.println("pageResult size:\t"+pageResult.size());
			//List<PDFGraphicalLine>CellsData = Cells_Extraction(pg+1, page);//,fileName,dir);

		}catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
			e.printStackTrace();
		}

	}*/

}
