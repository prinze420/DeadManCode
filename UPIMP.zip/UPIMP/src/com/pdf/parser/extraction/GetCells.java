package com.pdf.parser.extraction;


import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.ResourceBundle;

import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFGraphicalLine;
import com.pdf.parser.base.Pixel;
import com.pdf.parser.complex.strategy.GeneralUtility;


public class GetCells {//GraphicalCellGenerationStrategy
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("email-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	public static float minLineLengthThreshold=Float.valueOf(config.getString("minLineLengthThreshold"));

	public static List<PDFGraphicalLine> detectLinesImageBased(BufferedImage img,boolean horizontal){
		List<PDFGraphicalLine> lines = new ArrayList<PDFGraphicalLine>();

		//		Raster raster = img.getData();

		//**********Decide how to parse the pixel matrix based on whether to extract horizontal/vertical line
		int outer = horizontal ? img.getHeight() : img.getWidth();
		int inner = horizontal ? img.getWidth() : img.getHeight();
		int minLineLength = (int)(horizontal ? img.getWidth()*(minLineLengthThreshold) : img.getHeight()*(0.01));
		minLineLength = (int)(horizontal ? minLineLength : minLineLength);
		//***************************************

		//************Detect lines
		for(int i=0;i<outer;i++){

			PDFGraphicalLine line = null;
			for(int j=0;j<inner;j++){


				int x = horizontal ? j : i;
				int y = horizontal ? i : j;
				Color color = new Color(img.getRGB(x, y));
				int[] pixel = {color.getRed() ,color.getGreen(),color.getBlue(),color.getAlpha()} ;

				Pixel pix = new Pixel(pixel , x, y);
				//				Pixel pix = new Pixel(raster.getPixel(x, y, new int[4]),x,y);

				if(pix.isWhite()){//Ignore white pixels and treat them as breaking points between lines

					if(line!=null){
						float start = horizontal ? line.getX() : line.getY();
						float end = horizontal ? line.getX2() : line.getY2();

						if((int)(end-start)>=minLineLength){//The line is actually created in the else part below

							//##########Find the max color for line
							HashMap<Pixel, Integer> pxCounts = new HashMap<Pixel,Integer>();
							for(float a=line.getX();a<=line.getX2();a++){
								for(float b=line.getY();b<=line.getY2();b++){

									Color c = new Color(img.getRGB((int)a, (int)b));
									int[] pi = {c.getRed() ,c.getGreen(),c.getBlue(),c.getAlpha()} ;

									Pixel p = new Pixel(pi,a,b);

									//									Pixel p = new Pixel(raster.getPixel((int)a, (int)b, new int[4]),a,b);
									if(pxCounts.containsKey(p)){
										pxCounts.put(p, pxCounts.get(p)+1);
									}else{
										pxCounts.put(p, 1);
									}
								}
							}

							Pixel max = null;
							int count = 0;
							for(Pixel key : pxCounts.keySet()){
								if(max==null){
									max = key;
									count = pxCounts.get(max);
									continue;
								}

								if(pxCounts.get(key) > count){
									max = key;
									count = pxCounts.get(max);
								}
							}

							line.setColor(max);
							line.setHorizontal(horizontal);
							//#####################################
							lines.add(line);
						}
					}

					line = null;
					continue;

				}else{//For any non-white pixel append it to the line, thereby extending its length
					if(line==null){
						line = new PDFGraphicalLine(pix.getX(),pix.getY(),0,0,true,pix);
						continue;
					}
					line.setX2(pix.getX());
					line.setY2(pix.getY());
				}
				if(horizontal== true && line.getX2()-line.getX()> minLineLength && x==img.getWidth()-1)
				{
					lines.add(line);
				}

			}

		}

		return lines;
		//************************************

		//**************Draw vertical lines based on hierarchyNode's Table-Columns
		//			if(!horizontal && tableNode!=null && tableNode.getParagraph()!=null && tableNode.getParagraph().isTable()){}
		//**********************************************************

		//**************Detect fat rows due to color fills and deduce to two line; top/bottom
		/*List<PDFGraphicalLine> existingLines = new ArrayList<PDFGraphicalLine>(lines);
		lines = new ArrayList<PDFGraphicalLine>();//New set of lines to be populated after pruning of color fills to just two lines

		//There are cases where two lines occur one after the other with significant white space in between.
		//So we need to keep track of only those lines that are sandwiched in a fat line and not the ones outside the vicinity.
		List<PDFGraphicalLine> excludedLines = new ArrayList<PDFGraphicalLine>();

		for(int i=0;i<existingLines.size();i++){
			PDFGraphicalLine focus = existingLines.get(i);

			if(excludedLines.contains(focus))
				continue;

			int j=0;
			for(j=i+1;j<existingLines.size();j++){
				PDFGraphicalLine nextLine = existingLines.get(j);

				float checkStart = horizontal ? focus.getX() : focus.getY();
				float checkEnd = horizontal ? nextLine.getX() : nextLine.getY();
				if(checkStart!=checkEnd)
					continue;

				float start = horizontal ? focus.getY() : focus.getX();
				float end = horizontal ? nextLine.getY() : nextLine.getX();

				if((end-start)<=1 && nextLine.getColor().equals(focus.getColor())){//Same line or next
					focus = nextLine;
					excludedLines.add(focus);
				}else{
					break;
				}
			}

			if(j-i > (int)(img.getHeight()*0.025)){
				//Now that we have first and the last of a set of consecutive lines, add those to the lines list
				lines.add(existingLines.get(i));
				lines.add(focus);
			}else
				lines.add(existingLines.get(i));
		}
		excludedLines.clear();
		//*****************************

		//*******************Detect Fat lines and deduce to one
		existingLines = new ArrayList<PDFGraphicalLine>(lines);
		lines = new ArrayList<PDFGraphicalLine>();//New set of lines to be populated after pruning of fat lines to one

		//There are cases where two lines occur one after the other with significant white space in between.
		//So we need to keep track of only those lines that are sandwiched in a fat line and not the ones outside the vicinity.
		excludedLines = new ArrayList<PDFGraphicalLine>();

		for(int i=0;i<existingLines.size();i++){
			PDFGraphicalLine focus = existingLines.get(i);

			int j=0;
			for(j=i+1;j<existingLines.size();j++){
				if(j >= existingLines.size()){//Same line or next
					break;
				}
				float checkStart = horizontal ? focus.getX() : focus.getY();
				float checkEnd = horizontal ? existingLines.get(j).getX() : existingLines.get(j).getY();

				if(checkStart!=checkEnd)
					continue;

				float start = horizontal ? focus.getY() : focus.getX();
				float end = horizontal ? existingLines.get(j).getY() : existingLines.get(j).getX();

				if((end-start)<=1 && j< existingLines.size()){//Same line or next
					focus = existingLines.get(j);
					excludedLines.add(focus);
				}else{
					break;
				}
			}

			if(j-i >= 2){
				//Now that we have first and the last of a set of consecutive lines, choose the first and ignore the rest
				lines.add(existingLines.get(i));
			}else
				lines.add(existingLines.get(i));
		}
		excludedLines.clear();
		//***********************************

		return lines;*/
	}

	/*public static List<DPRectangle> getCellsInHorizontalLines(List<PDFGraphicalLine>horizontalLine, int index, //Line currentHorizontalLine, Line previousHorizontalLine,
			List<PDFGraphicalLine> verticalLines, BufferedImage img, int pgNum) 
			{
		int i = 0;

		PDFGraphicalLine currentHorizontalLine = null;
		PDFGraphicalLine nextHorizontalLine1 = horizontalLine.get(index+1);
		PDFGraphicalLine previousHorizontalLine = horizontalLine.get(index);
		PDFGraphicalLine nextHorizontalLine2 = null;

		List<DPRectangle> rectangles = new ArrayList<DPRectangle>();
		PDFGraphicalLine previousVerticalLine = null;
		Boolean flag = false;
		Boolean flag2 = true;
		int newIndex;
		for (PDFGraphicalLine currentVerticalLine : verticalLines) {
			DPRectangle rectangle = new DPRectangle(0, 0, 0, 0, pgNum);
			if (previousVerticalLine == null) {
				previousVerticalLine = currentVerticalLine;
			}
			if(currentHorizontalLine==null)
			{
				if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine1.getX()) <10 
						|| nextHorizontalLine1.getX()<previousHorizontalLine.getX() )
				{
					flag = false;
					currentHorizontalLine = nextHorizontalLine1;
				}
				else 
				{
					for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								|| nextHorizontalLine2.getX()<previousHorizontalLine.getX() )
						{
							flag = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
						else continue;
					}
				}
			}

			if(flag2 && !flag)
			{
				if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine1.getX()) <10 
						|| (nextHorizontalLine1.getX()<previousHorizontalLine.getX() 
								&& nextHorizontalLine1.getX2()>previousHorizontalLine.getX() ))
				{
					flag = false;
					currentHorizontalLine = nextHorizontalLine1;
				}
				else 
				{
					for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX() 
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX()))
						{
							flag = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}
			else if(!flag){
				for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
				{
					nextHorizontalLine2 = horizontalLine.get(newIndex);
					//					if(Math.abs(previousHorizontalLine.getX2() - nextHorizontalLine2.getX2()) <10 )
					if(rectangles.get(rectangles.size()-1).getX()!=0
							&&(rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) >= nextHorizontalLine2.getX()
							//							&& Math.abs(rectangles.get(rectangles.size()-1).getX2() - nextHorizontalLine2.getX2()) >15 )
							//							&& nextHorizontalLine2.getX2()-currentVerticalLine.getX()>=1)
							&& nextHorizontalLine2.getX2() - (rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) > 10 )

					{
						flag = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else if (rectangles.get(rectangles.size()-1).getX()==0
							&& nextHorizontalLine2.getX()==nextHorizontalLine2.getX()) {
						flag = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else continue;
				}
			}


			//			if(rectangles.isEmpty() 
			//					&& Math.abs(previousVerticalLine.getX()- previousHorizontalLine.getX())>10)
			//			{
			//				previousVerticalLine = currentVerticalLine;
			//				continue;
			//			}
			//			else
			//				{
			if (currentHorizontalLine!=null 
					&& currentVerticalLine!=null 
					&& previousVerticalLine!=null 
					&& previousHorizontalLine !=null //added by Bharat
					&& Math.abs(img.getWidth() - currentVerticalLine.getX()) < 15
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
							&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
							&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
									|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
									&& (previousVerticalLine.getX() < currentVerticalLine.getX()
											|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
											&& currentVerticalLine.getX() < previousHorizontalLine.getX2()
											&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20) {

				int x1 = (int)previousVerticalLine.getX();
				int x2 = (int)currentVerticalLine.getX();
				int y1 = (int)previousHorizontalLine.getY();
				int y2 = (int)currentHorizontalLine.getY();
				previousVerticalLine = currentVerticalLine;
				//rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);

				rectangle.setX(x1);
				rectangle.setY(y1);
				rectangle.setWidth(x2 - x1);
				rectangle.setHeight(y2 - y1);

				rectangles.add(rectangle);
				i = 0;
				//newly added logic
				if(Math.abs(x2- nextHorizontalLine1.getX2())<10){
					currentHorizontalLine= null;
					flag2 = false;
					continue;
				}
				else
					break;

			}

			// else
			if (previousVerticalLine != null && currentHorizontalLine!=null
					//						&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
							&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
							&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
									|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
									&& (previousVerticalLine.getX() < currentVerticalLine.getX()
											|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
											&& currentVerticalLine.getX() < previousHorizontalLine.getX2()
											&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20)// &&
			{
				i++;
				if (i >= 1) {
					int count1 = 0;
					int count2 = 0;
					count1 = GeneralUtility.compare((int)currentVerticalLine.getX() - 12, 
							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
					count2 = GeneralUtility.compare((int)currentVerticalLine.getX() + 5, 
							(int)currentHorizontalLine.getY() - 22, 6, 20, img);

					if (count2 > 80 || count1 > 80) {
						int x1 = (int) previousVerticalLine.getX();
						int x2 = (int)currentVerticalLine.getX();
						int y1 = (int)previousHorizontalLine.getY();
						int y2 = (int)currentHorizontalLine.getY();

						if(x1<previousHorizontalLine.getX())// Math.abs(x1- previousHorizontalLine.getX())>10  )
						{
							previousVerticalLine = currentVerticalLine;
							rectangles.add(rectangle);
							continue;
						}
						else{
							previousVerticalLine = currentVerticalLine;
							//								rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);
							rectangle.setX(x1);
							rectangle.setY(y1);
							rectangle.setWidth(x2 - x1);
							rectangle.setHeight(y2 - y1);
							rectangles.add(rectangle);
						}
						i = 0;
						if(flag && Math.abs(x2- nextHorizontalLine1.getX())<10)
						{
							currentHorizontalLine = nextHorizontalLine1;
						}
						else if(rectangles.size()>0
								&& Math.abs(x2- currentHorizontalLine.getX2())<10
								//									||(Math.abs(x2- currentHorizontalLine.getX2())<5)
								){
							flag2 = false;
						}

						if ( Math.abs(x2 - currentHorizontalLine.getX2())> 15) {
							continue;
						}
						else if(rectangles.size()>0){
							flag2 = false;
						}
					}
				}
			}
		}
		// prevY = hLine.getY();
		return rectangles;
			}
*/
	public static List<DPRectangle> getCellsInHorizontalLines(List<PDFGraphicalLine>horizontalLine, int index, //Line currentHorizontalLine, Line previousHorizontalLine,
			List<PDFGraphicalLine> verticalLines, BufferedImage img, int pgNum) 
	{
		int i = 0;

		PDFGraphicalLine currentHorizontalLine = null;
		PDFGraphicalLine nextHorizontalLine1 = horizontalLine.get(index+1);
		PDFGraphicalLine previousHorizontalLine = horizontalLine.get(index);
		PDFGraphicalLine nextHorizontalLine2 = null;
		List<DPRectangle> rectangles = new ArrayList<DPRectangle>();
		PDFGraphicalLine previousVerticalLine = null;
		Boolean flag = false;
		Boolean flag2 = true;
		Boolean checkCell = false;
		int newIndex;
		
		for (PDFGraphicalLine currentVerticalLine : verticalLines) {
			DPRectangle rectangle = new DPRectangle(0, 0, 0, 0, pgNum);
			if (previousVerticalLine == null) {
				previousVerticalLine = currentVerticalLine;
			}
			
			
			if(flag2 && !flag)
			{
				if( //currentHorizontalLine != nextHorizontalLine1
//						&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
//						&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
						Math.abs(previousHorizontalLine.getX() - nextHorizontalLine1.getX()) <10 
						&& nextHorizontalLine1.getY()>previousHorizontalLine.getY()
						|| (nextHorizontalLine1.getX()<previousHorizontalLine.getX()
								&& nextHorizontalLine1.getX2()>previousHorizontalLine.getX() ))
				{
					flag = false;
					currentHorizontalLine = nextHorizontalLine1;
				}
				else 
				{
					for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
					{
						nextHorizontalLine2 = horizontalLine.get(newIndex);
						if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
//								&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
//								&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
								|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
										&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
						{
							flag = true;
							currentHorizontalLine = nextHorizontalLine2;
							break;
						}
					}
				}
			}
			else if (!flag && rectangles.size()!=0)
			{	
				for(newIndex= index+1; newIndex< horizontalLine.size() ; newIndex++)
				{
					nextHorizontalLine2 = horizontalLine.get(newIndex);
//					if(Math.abs(previousHorizontalLine.getX2() - nextHorizontalLine2.getX2()) <10 )
					if(rectangles.get(rectangles.size()-1).getX()!=0
							&&(rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) >= nextHorizontalLine2.getX()
//							&& Math.abs(rectangles.get(rectangles.size()-1).getX2() - nextHorizontalLine2.getX2()) >15 )
//							&& nextHorizontalLine2.getX2()-currentVerticalLine.getX()>=1)
							 && nextHorizontalLine2.getX2() - (rectangles.get(rectangles.size()-1).getX()+rectangles.get(rectangles.size()-1).getWidth()) > 10 )

					{
						flag = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else if (rectangles.get(rectangles.size()-1).getX()==0
							&& nextHorizontalLine2.getX()==nextHorizontalLine2.getX()) {
						flag = false;
						currentHorizontalLine = nextHorizontalLine2;
						break;
					}
					else continue;
				}
			}
		
			

			if (
					previousVerticalLine != null && currentHorizontalLine!=null
					&& previousVerticalLine != currentVerticalLine 
//					&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& currentVerticalLine.getX() < previousHorizontalLine.getX2()
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20
					) {
					checkCell = true;
					if (currentHorizontalLine.getX2() < currentVerticalLine.getX() 
							&& currentHorizontalLine == nextHorizontalLine1) {
						for(newIndex= index+2; newIndex< horizontalLine.size() ; newIndex++)
						{
							nextHorizontalLine2 = horizontalLine.get(newIndex);
							if(Math.abs(previousHorizontalLine.getX() - nextHorizontalLine2.getX()) <10 
									&& currentVerticalLine.getY()< nextHorizontalLine2.getY()
									&& currentVerticalLine.getX()<= nextHorizontalLine2.getX2()
									|| (nextHorizontalLine2.getX()<previousHorizontalLine.getX()
											&& nextHorizontalLine2.getX2()>previousHorizontalLine.getX() ) )
							{
								flag = true;
								
								currentHorizontalLine = nextHorizontalLine2;
								break;
							}
						}
					}
			}
			
			
			
			if (currentHorizontalLine!=null 
					&& currentVerticalLine!=null 
					&& previousVerticalLine!=null 
					&& previousHorizontalLine !=null //added by Bharat
					&& Math.abs(img.getWidth() - currentVerticalLine.getX()) < 15
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& currentVerticalLine.getX() < previousHorizontalLine.getX2()
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20) {
				
				int x1 = (int)previousVerticalLine.getX();
				int x2 = (int)currentVerticalLine.getX();
				int y1 = (int)previousHorizontalLine.getY();
				int y2 = (int)currentHorizontalLine.getY();
				previousVerticalLine = currentVerticalLine;
				//rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);
				
				rectangle.setX(x1);
				rectangle.setY(y1);
				rectangle.setWidth(x2 - x1);
				rectangle.setHeight(y2 - y1);
				
				rectangles.add(rectangle);
				i = 0;
				//newly added logic
				if(Math.abs(x2- nextHorizontalLine1.getX2())<10){
				    currentHorizontalLine= null;
					flag2 = false;
					continue;
				}
			   else
				break;
			
			}
			/*else if (!checkCell) {
				continue;
			}*/
			
			if (checkCell && previousVerticalLine != null && currentHorizontalLine!=null
//						&& (Math.abs(previousHorizontalLine.getX2()-currentVerticalLine.getX())>20)
					&& (currentHorizontalLine.getY() > currentVerticalLine.getY()
							|| Math.abs(currentVerticalLine.getY() - currentHorizontalLine.getY()) < 20)
					&& currentVerticalLine.getY() - previousHorizontalLine.getY() < 20
					&& (currentHorizontalLine.getY() < currentVerticalLine.getY2()
							|| Math.abs(currentVerticalLine.getY2() - currentHorizontalLine.getY()) < 30)
					&& (previousVerticalLine.getX() < currentVerticalLine.getX()
							|| Math.abs(previousHorizontalLine.getX() - currentVerticalLine.getX()) < 10)
					&& currentVerticalLine.getX() < previousHorizontalLine.getX2()
					&& currentVerticalLine.getX2() - previousVerticalLine.getX() > 20)// &&
			{
				
				i++;
				if (i >= 1) {
					int count1 = 0;
					int count2 = 0;
					count1 = GeneralUtility.compare((int)currentVerticalLine.getX() - 12, 
							(int)currentHorizontalLine.getY() - 22, 6, 20, img);
					count2 = GeneralUtility.compare((int)currentVerticalLine.getX() + 5, 
							(int)currentHorizontalLine.getY() - 22, 6, 20, img);

					if (count2 > 80 || count1 > 80) {
						int x1 = (int) previousVerticalLine.getX();
						int x2 = (int)currentVerticalLine.getX();
						int y1 = (int)previousHorizontalLine.getY();
						int y2 = (int)currentHorizontalLine.getY();
						
						if(x1<previousHorizontalLine.getX())// Math.abs(x1- previousHorizontalLine.getX())>10  )
						{
							previousVerticalLine = currentVerticalLine;
							rectangles.add(rectangle);
							continue;
						}
						else{
							previousVerticalLine = currentVerticalLine;
//								rectangle.setBounds(x1, y1, x2 - x1, y2 - y1);
							rectangle.setX(x1);
							rectangle.setY(y1);
							rectangle.setWidth(x2 - x1);
							rectangle.setHeight(y2 - y1);
							rectangles.add(rectangle);
						}
						i = 0;
						if(flag && Math.abs(x2- nextHorizontalLine1.getX())<10)
						{
							currentHorizontalLine = nextHorizontalLine1;
						}
						else if(rectangles.size()>0
								&& Math.abs(x2- currentHorizontalLine.getX2())<10
								||(Math.abs(x2- nextHorizontalLine1.getX())<5)
								){
							flag2 = false;
						}
						
						if ( Math.abs(x2 - currentHorizontalLine.getX2())> 15) {
							continue;
						}
						else if(rectangles.size()>0){
							flag2 = false;
						}
					}
				}
			}
		}
		// prevY = hLine.getY();
		return rectangles;
	}



}
