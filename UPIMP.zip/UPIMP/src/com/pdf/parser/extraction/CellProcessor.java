package com.pdf.parser.extraction;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.Structure;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.base.strategy.KeyValueStrategy;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.complex.strategy.GraphicalLinesDetectionStrategy;
import com.pdf.parser.utils.CommonOperations;

public class CellProcessor {
	Map<Integer, List<PDFPara>> pageWiseParas=new HashMap<Integer, List<PDFPara>>();

	public CellProcessor(Map<Integer, List<PDFPara>> pageWiseParas) {
		this.pageWiseParas=pageWiseParas;
	}

	public List<DPCell> cellProcess(Map<Integer, List<PDFSegment>> segGroups,PDPage pdPage,PDFPara startPara,String outputDir) {

		List<DPCell> pageCells =new  ArrayList<DPCell>();

		int pgNo = startPara.getRectangles().get(0).getPage();
		try {

			pageCells = getPageCells(pdPage,  pgNo, outputDir);

		} catch (Exception e) {
			e.printStackTrace();
		}  

		System.out.println("Done with Cell Detection \t ::"+pgNo+"\t Size:"+pageCells.size());
		//*****Fill Cells
		/*		for(int page : pageCells.keySet()){
			if(pageCells.get(page).size()>0){*/
		List<DPCell> cells = pageCells;//.get(page);

		if(segGroups.get(pgNo)==null)
			return pageCells;

		for(PDFSegment seg : segGroups.get(pgNo)){

			for (PDFWord wrd : seg.getWords()) {
				DPCell c = isInCellArea(seg, cells);
				if(c!=null && !c.getLineCellDataList().contains(wrd)){
					//	System.out.println("Cell Seg:"+seg+"\t"+c.getRow()+"\t"+c.getColumn());
					c.getLineCellDataList().add(wrd);
					wrd.setIsCellPart(true);
					wrd.setLineDPCell(c); 
					String cc = c.getStringRepresentation()+" "+wrd.getStringRepresentation();
					c.setStringRepresentation(cc.trim());
				}

			}

		}
		//sort cell YX
		for (DPCell c : cells) {
			if(c!=null && !c.getLineCellDataList().isEmpty() && c.getLineCellDataList().size()>1){
				List<PDFWord> list = c.getLineCellDataList();
				Collections.sort(list,new Comparator<PDFWord>() {
					@Override
					public int compare(PDFWord o1, PDFWord o2) {
						return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
					}
				});
				//System.out.println("sorted Cell List\t"+list);
				c.setLineCellDataList(list);
			}
		}
		//remove blank cells
		Iterator<DPCell> cellsIterator = pageCells.iterator();
		while (cellsIterator.hasNext()) {
			DPCell next = cellsIterator.next();
			if(next.getStringRepresentation().trim().isEmpty()){
				cellsIterator.remove();
			}
		}
		//detect KV Pairs of Each cell
		//		for (DPCell dpCell : cells) {
		//			KeyValueStrategy kv = new KeyValueStrategy(CommonOperations.groupStructuresOnY(dpCell.getParaList()));
		//			kv.apply();
		//			List<Structure> cellKVPairs = kv.getOutcome();
		//			if(cellKVPairs!=null || !cellKVPairs.isEmpty()){
		//				dpCell.setCellKVP(cellKVPairs);
		//			}
		//			
		//		}


		return pageCells;
	}

	private DPCell isInCellArea(BasicStructure c, List<DPCell> cell_list) {


		for (DPCell dpLineCell : cell_list) {

			if(c.getRectangle().getPage()!=dpLineCell.getRectangle().getPage()){
				continue;
			}
			float y2 = (float)dpLineCell.getRectangle().getY();
			float y = (float) (y2+ dpLineCell.getRectangle().getHeight());
			double x=dpLineCell.getRectangle().getX();
			
			double x2=x+dpLineCell.getRectangle().getWidth();

			float struMiddleX = c.getRectangle().getX2()+c.getRectangle().getWidth()/2;
			if(c.getRectangle().getY()<=y
					&& c.getRectangle().getY2()>=y2
					//&& (c.getRectangle().getX()>=x	&& c.getRectangle().getX2()<=x2)
					&& struMiddleX > x
					&& struMiddleX < x2 
					
					){

				return dpLineCell;

			}

		}
		return null;
	}

	public static List<DPCell> getPageCells(PDPage pdPage,int pageNo,String outputDir){
		List<DPCell> pageCells = new ArrayList<DPCell>();

		try 
		{
			// TODO: Run this only on a given selected pages
			List<DPCell> cells = new ArrayList<DPCell>() ;
			cells = new GraphicalLinesDetectionStrategy().extractPageCell(pageNo,pdPage);
			pageCells=cells;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return pageCells;
	}

	public static List<DPCell> getFrontCells(DPCell matchingCell, List<DPCell> pageCells) {
		List<DPCell> frontCells=new ArrayList<DPCell>();

		for(int j=0; j<pageCells.size(); j++){
			DPCell c = (DPCell)pageCells.get(j); 

			if(c.getStringRepresentation().contains("Suspect Product(s)")){//Provide clear narrative description
				System.out.print(""); //Lyrica
			}
			if(c.getStringRepresentation().contains("Lyrica")){//Provide clear narrative description
				System.out.print(""); //Lyrica
			}
			//float xDiff = matchingCell.getRectangle().getX2()-c.getRectangle().getX();

			if(!c.equals(matchingCell) 
					&& isOverlapOnY(c, matchingCell) 
					&& ((matchingCell.getRectangle().getX2()<=c.getRectangle().getX()+2)
							&& (Math.abs(matchingCell.getRectangle().getX2()-c.getRectangle().getX())<=5)
							|| matchingCell.getRectangle().getY() >= c.getRectangle().getY() && matchingCell.getRectangle().getY2() <= c.getRectangle().getY2())

							&& ((Math.abs(matchingCell.getRectangle().getY()-c.getRectangle().getY())<4 
									|| matchingCell.getRectangle().getY() >= c.getRectangle().getY() && matchingCell.getRectangle().getY2() <= c.getRectangle().getY2()))
					){

				//next = c;
				if(c.getRow()==matchingCell.getRow() && c.getColumn()>matchingCell.getColumn())
					frontCells.add(c);
				//TODO add empty cell in page list andd do this process for all front cells

				//break;
			}
		}

		return frontCells;
	}

	public static List<DPCell> getMatchingCells(String keywoString2,List<DPCell> pageCells, List<PDFSegment> pageSegs, List<PDFSegment> ruleTitles) {

		List<DPCell>matchingCells=new ArrayList<DPCell>();

		/*System.out.println("page Cells start");
		System.out.println("Page cell "+pageCells);
		
		System.out.println("page Cells end");
		*/
		
		String isEqual="";
		PDFSegment title = null;
		float nextTitleY = -1;
		String keywoString = keywoString2;

		if(keywoString2.contains("##")){
			isEqual=keywoString2.split("##")[1];
			keywoString=keywoString2.split("##")[0];

			if(isEqual.startsWith("Title:")){//Cells are to be found only under a specific title segment
				isEqual = isEqual.substring(6).trim();

				for(PDFSegment s : pageSegs){
					if(s.getStringRepresentation().equalsIgnoreCase(isEqual)){//|| isEqual.contains(s.getStringRepresentation())){
						title = s;

						int index = ruleTitles.indexOf(s);
						if(index < ruleTitles.size()-1 && title.getRectangle().getPage()==ruleTitles.get(index+1).getRectangle().getPage())
							nextTitleY = ruleTitles.get(index+1).getRectangle().getY();

						break;
					}
				}

				if(title==null)//If title is not found then no point proceeding with matching cells
					return matchingCells;
			}
		}

		for (DPCell dpCell : pageCells) {
			String content = dpCell.getStringRepresentation();
			DPCell matchingCell=null;
			if(isEqual.isEmpty()){
				if(content.trim().contains(keywoString.trim())){
					matchingCell=dpCell;
					matchingCells.add(matchingCell);

				}
			}else{
				if(title!=null){

					if(dpCell.getRectangle().getY() > title.getRectangle().getY()){
						if(nextTitleY==-1 || dpCell.getRectangle().getY() < nextTitleY){
							if(content.trim().contains(keywoString.trim())){
								matchingCell=dpCell;
								matchingCells.add(matchingCell);
								return matchingCells;
							}
						}
					}

				}else if(isEqual.equalsIgnoreCase("equals")||isEqual.equalsIgnoreCase("equal")){
					if(content.trim().equals(keywoString.trim())){
						matchingCell=dpCell;
						matchingCells.add(matchingCell);

					}
				}

			}
		}

		return matchingCells;
	}


	public  static List<DPCell> getBelowCells(DPCell matchingCell, List<DPCell> pageCells){
		List<DPCell> belowCells=new ArrayList<DPCell>();

		DPCell lastCell = matchingCell;
		for(int j=0; j<pageCells.size(); j++)
		{
			DPCell c = (DPCell)pageCells.get(j); 
			if(c.getRow()==4||c.getStringRepresentation().contains("Wyeth Product:")){
				System.out.println("");
			}
			if(	!c.equals(matchingCell)
					&& isOverlapOnX(c, matchingCell)
					&& matchingCell.getRectangle().getY()<c.getRectangle().getY()
					&& ( lastCell.getRectangle().getY()== c.getRectangle().getY() || Math.abs(lastCell.getRectangle().getY()-c.getRectangle().getY2())<1)
					)
			{
				belowCells.add(c);
				lastCell=c;
			}
		}
		return belowCells;
	}
	public static String getCellText(List<DPCell> pageCells, int rowNum,int colNum) {

		for (DPCell dpCell : pageCells) {
			if(dpCell.getStringRepresentation().contains("REVATIO")){
				System.out.println("True");

			}
			if(dpCell.getRow()==rowNum && dpCell.getColumn()==colNum){
				return dpCell.getStringRepresentation();
			}
		}
		return "";
	}

	public static boolean isOverlapOnY(BasicStructure s1, BasicStructure s2){//
		boolean overlap = false;
		/*System.out.print(s2.getRectangle().getY());
System.out.println("\t"+s2.getRectangle().getY2());
System.out.print(s1.getRectangle().getY());
System.out.println("\t"+s1.getRectangle().getY2());
		 */
		if(s2.getRectangle().getY() > s1.getRectangle().getY() && s2.getRectangle().getY2() < s1.getRectangle().getY())
			overlap = true;

		else if(s2.getRectangle().getY() < s1.getRectangle().getY() && s2.getRectangle().getY() > s1.getRectangle().getY2())
			overlap = true;

		else if(s2.getRectangle().getY() > s1.getRectangle().getY() && s2.getRectangle().getY2() < s1.getRectangle().getY2())
			overlap = true;

		else if(s2.getRectangle().getY() == s1.getRectangle().getY() && s2.getRectangle().getY2() == s1.getRectangle().getY2())
			overlap = true;

		return overlap;
	}

	public static boolean isOverlapOnX(BasicStructure s1, BasicStructure s2){
		boolean overlap = false;
		//		System.out.println(s2.getRectangle().getX()+"\t"+s2.getRectangle().getX2());
		//		System.out.println(s1.getRectangle().getX()+"\t"+s1.getRectangle().getX2());
		if(s2.getRectangle().getX() >= s1.getRectangle().getX() && s2.getRectangle().getX()+1 < s1.getRectangle().getX2())
			overlap = true;

		else if(s2.getRectangle().getX2() <= s1.getRectangle().getX2() && s2.getRectangle().getX2() > s1.getRectangle().getX())
			overlap = true;

		else if(s2.getRectangle().getX() <= s1.getRectangle().getX() && s2.getRectangle().getX2() >= s1.getRectangle().getX2())
			overlap = true;

		return overlap;
	}

	public static List<PDFWord> detectCheboxWords(DPCell belowFirst,List<String> splits) {
		// TODO Auto-generated method stub
		List<PDFWord>checkBoxWords=new ArrayList<PDFWord>();
		//List<String> splits = Arrays.asList(checkBoxSecondWords.split("##"));
		if(splits!=null && !splits.isEmpty())
			for (PDFWord pdfWord : belowFirst.getLineCellDataList()) {
				for (String inWrd : splits) {
					if(/*!checkBoxWords.contains(inWrd)&&*/ inWrd.trim().equalsIgnoreCase(pdfWord.getStringRepresentation().trim())){
						checkBoxWords.add(pdfWord);
						break;
					}
				}

			}
		System.out.println("checkBoxWords "+checkBoxWords);
		return checkBoxWords;
	}
	

}
