package com.pdf.parser.base.strategy;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.ResourceBundle;
import java.util.Set;

import com.pdf.parser.Strategy;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFVerticalGap;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.utils.CommonOperations;
import com.pdf.parser.utils.CommonOperations.DIRECTION;
import com.pdf.parser.utils.CommonOperations.SORT_CRITERIA;

public class PDFVerticalGapFormationStrategy implements Strategy<List<PDFVerticalGap>> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}
	
	float verticalGapFactor = new Float(config.getString("verticalGapFactor"));
	float minimumVGapWidth = new Float(config.getString("minimumVGapWidth"));
	
	List<PDFVerticalGap> verticalGaps;
	List<BasicStructure> words;
	int page;
	float pageHeight, pageWidth;
	
	public PDFVerticalGapFormationStrategy(List<BasicStructure> words, int page, float pageHeight, float pageWidth){
		this.words = words;
		this.page = page;
		this.pageHeight = pageHeight;
		this.pageWidth = pageWidth;
		
		verticalGaps = new ArrayList<PDFVerticalGap>();
	}
	
	public void apply(){
		List<StructureGroup> sg = CommonOperations.groupStructuresOnY(words);
		
		for(int g=0; g<sg.size(); g++){
			StructureGroup grp = sg.get(g);
			
			for(int i=0; i<grp.getSegmentsSize(); i++){
				BasicStructure word = grp.getBasicStructures().get(i);
				
//				if(word.getStringRepresentation().contains("Truck") /*&& word2.getStringRepresentation().contains("2,858")*/)
//					System.out.println("debug");
				
				//word2 only considered if word1 and word2 are at the same y-level
				BasicStructure word2 = null;
				if(i+1 != grp.getSegmentsSize())
					word2 = grp.getBasicStructures().get(i+1);
				
				float vgapWidth = pageWidth-word.getRectangle().getX2();
				if(word2 != null)
					vgapWidth = word2.getRectangle().getX() - word.getRectangle().getX2();
				
				PDFVerticalGap vgap = new PDFVerticalGap(word, 
						new DPRectangle(word.getRectangle().getX2(), word.getRectangle().getY(), vgapWidth, word.getRectangle().getHeight(), page), 
						StructureType.VERTICAL_GAP, word.getWidthOfSpace());
				
				if(word2!=null)
					vgap.setWord2(word2);
				
				if(vgapWidth > minimumVGapWidth*word.getWidthOfSpace()){
					
					boolean foundCompleteOverlap = false;
					boolean runOnce = true;
					
					nextGroup:
					for(int j=g+1; j<sg.size(); j++){
						StructureGroup nextGrp = sg.get(j);
						
						List<BasicStructure> bs = new ArrayList<BasicStructure>(nextGrp.getBasicStructures());
						Collections.reverse(bs);
						
						for(BasicStructure thisWord : bs){
							
							//Right now there is no word2 and hence the vgap has defaulted to max width on the right
							//But as soon as we find the first word that falls within this broad width, we would like
							//to limit the width of the vgap to the left of this first word
							if(word2 == null && runOnce
									&& thisWord.getRectangle().getX()>=vgap.getRectangle().getX() 
									&& thisWord.getRectangle().getX()<=vgap.getRectangle().getX2()
									&& thisWord.getRectangle().getX2() < vgap.getRectangle().getX2()){
								
								runOnce = false;
								
								vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2()));
								vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
								
								float width = thisWord.getRectangle().getX() - vgap.getRectangle().getX();
								if(width > minimumVGapWidth*word.getWidthOfSpace()){
									vgap.getRectangle().setWidth(width);
								
								}else if(vgap.getRectangle().getHeight() > word.getRectangle().getHeight() * verticalGapFactor){//Obstruction found, but now check for eligible height
									verticalGaps.add(vgap);
									foundCompleteOverlap = true;
									break nextGroup;
								
								}else{
									foundCompleteOverlap = true;
									break nextGroup;
								}
							}
							
							//left end of the word overlap but the right end doesn't
							else if(thisWord.getRectangle().getX()>=vgap.getRectangle().getX() 
									&& thisWord.getRectangle().getX()<=vgap.getRectangle().getX2()
									&& thisWord.getRectangle().getX2() > vgap.getRectangle().getX2()){
								
								vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2()));
								vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
								
								float width = thisWord.getRectangle().getX() - vgap.getRectangle().getX();
								if(width > minimumVGapWidth*word.getWidthOfSpace()){
									vgap.getRectangle().setWidth(width);
								
								}else if(vgap.getRectangle().getHeight() > word.getRectangle().getHeight() * verticalGapFactor){//Obstruction found, but now check for eligible height
									verticalGaps.add(vgap);
									foundCompleteOverlap = true;
									break nextGroup;
								
								}else{
									foundCompleteOverlap = true;
									break nextGroup;
								}
							}
							
							//right end of the word overlap
							//Do not put a condition of whether the left of the word overlaps. Even if it is between the width of vgap, we still would
							//like the vgap to form on the right. This takes care of missing values between columns. If we have two numbers with a
							//blank cell in between, we ideally want the vgap between the blank cell and the second number.
							else if(thisWord.getRectangle().getX2()>vgap.getRectangle().getX() && thisWord.getRectangle().getX2()<=vgap.getRectangle().getX2()){
								float width = vgap.getRectangle().getX2() - thisWord.getRectangle().getX2();
								
								vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2()));
								vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
								
								if(width > minimumVGapWidth*word.getWidthOfSpace()){
									vgap.getRectangle().setX(thisWord.getRectangle().getX2());
									vgap.getRectangle().setWidth(width);
								
								}else if(vgap.getRectangle().getHeight() > word.getRectangle().getHeight() * verticalGapFactor){
									verticalGaps.add(vgap);
									foundCompleteOverlap = true;
									break nextGroup;
								
								}else{
									foundCompleteOverlap = true;
									break nextGroup;
								}
								
								//As we have adjusted the x of the vgap, there is no point checking the same segment group.
								//Because we wanted the best candidate from the seg group that can best minimize the vgap from the left.
								//Hence we had reverse ordered the seg group
								//We can now move to the next group.
								continue nextGroup;
							}
							
							//mid of the word overlap, hence a complete block
							else if(thisWord.getRectangle().getX()<=vgap.getRectangle().getX() && thisWord.getRectangle().getX2()>=vgap.getRectangle().getX2()){
								
								vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2())+1);
								vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
								vgap.setBottomWord(thisWord.getStringRepresentation());
								
								if(vgap.getRectangle().getHeight() > word.getRectangle().getHeight() * verticalGapFactor 
										&& vgap.getRectangle().getWidth() > minimumVGapWidth*word.getWidthOfSpace()){
									
									verticalGaps.add(vgap);
								}
								
								foundCompleteOverlap = true;
								break nextGroup;
							}
						}
					}
					
					//If we din't found an overlap, this goes till the end of the page
					if(!foundCompleteOverlap && vgap.getRectangle().getWidth()>word.getWidthOfSpace()){
						
						vgap.getRectangle().setHeight(pageHeight-vgap.getRectangle().getY2());
						vgap.getRectangle().setY(pageHeight-1);
						verticalGaps.add(vgap);
					}
				}
			}
		}
		
		//Remove vertical gaps on the right edge
//		Iterator<PDFVerticalGap> vgapIterate = verticalGaps.iterator();
//		while(vgapIterate.hasNext()){
//			if(vgapIterate.next().getRectangle().getX2() >= pageWidth)
//				vgapIterate.remove();
//		}
		
		CommonOperations.sort(verticalGaps, SORT_CRITERIA.Y2, DIRECTION.MIN);
	}
	

	
	public boolean areWordsWithinExistingGap(BasicStructure word1, BasicStructure word2){
		
		float gap = word2.getRectangle().getX() - word1.getRectangle().getX2();
		
		PDFVerticalGap v = new PDFVerticalGap(word1, 
				new DPRectangle(word1.getRectangle().getX2(), word1.getRectangle().getY(), gap, word1.getRectangle().getHeight(), page), 
				StructureType.VERTICAL_GAP, word1.getWidthOfSpace());
		v.setWord2(word2);
		
		for(PDFVerticalGap existingGap : verticalGaps){
			
			if(v.getRectangle().getX()>=existingGap.getRectangle().getX() && v.getRectangle().getX()<=existingGap.getRectangle().getX2() 
					&& v.getRectangle().getY()>=existingGap.getRectangle().getY() && v.getRectangle().getY()<=existingGap.getRectangle().getY2())
				return true;
			
			if(v.getRectangle().getX2()>=existingGap.getRectangle().getX() && v.getRectangle().getX2()<=existingGap.getRectangle().getX2() 
					&& v.getRectangle().getY()>=existingGap.getRectangle().getY() && v.getRectangle().getY()<=existingGap.getRectangle().getY2())
				return true;
			
			if(v.getRectangle().getX()<=existingGap.getRectangle().getX() && v.getRectangle().getX2()>=existingGap.getRectangle().getX2() 
					&& v.getRectangle().getY()>=existingGap.getRectangle().getY() && v.getRectangle().getY()<=existingGap.getRectangle().getY2())
				return true;
		}
		
		return false;
	}
	
	public static List<PDFVerticalGap> filterIrrelevantVGaps(List<PDFVerticalGap> vgaps){
		
		Map<PDFVerticalGap, List<PDFVerticalGap>> vgapColumnTracker = new HashMap<PDFVerticalGap, List<PDFVerticalGap>>();
		Set<PDFVerticalGap> vgapTrack = new HashSet<PDFVerticalGap>();
		
//		for(PDFVerticalGap vgap : vgaps)
//			System.out.println(vgap.getWord2().getStringRepresentation());
//		
//		System.out.println("**********");
		
		for(int i=0; i<vgaps.size(); i++){
			PDFVerticalGap headVgap = vgaps.get(i);
			boolean isColumn = vgapColumnTracker.containsKey(headVgap);
			
//			if(vgap1.getWord2().getStringRepresentation().contains("873"))
//				System.out.println("debug");
			
			for(int j=i+1; j<vgaps.size(); j++){
				PDFVerticalGap childVgap = vgaps.get(j);
				
				if(!vgapTrack.contains(childVgap) && headVgap.getRectangle().getY() == childVgap.getRectangle().getY()
						&& CommonOperations.isOverlapOnX(headVgap, childVgap)){
					
					List<PDFVerticalGap> vgapGroup = null;
					if(!isColumn){
						vgapGroup = new ArrayList<PDFVerticalGap>();
						vgapColumnTracker.put(headVgap, vgapGroup);
						isColumn = true;
					
					}else
						vgapGroup = vgapColumnTracker.get(headVgap);
					
					vgapGroup.add(childVgap);
					vgapTrack.add(childVgap);
				}
//				if(!vgapTrack.contains(childVgap)
//						&& headVgap.getRectangle().getY() == childVgap.getRectangle().getY()
//						&& headVgap.getRectangle().getX()>=childVgap.getRectangle().getX()-5 && headVgap.getRectangle().getX2()<=childVgap.getRectangle().getX2()+5){
//					
//					List<PDFVerticalGap> vgapGroup = null;
//					if(!isColumn){
//						vgapGroup = new ArrayList<PDFVerticalGap>();
//						vgapColumnTracker.put(headVgap, vgapGroup);
//						isColumn = true;
//					
//					}else
//						vgapGroup = vgapColumnTracker.get(headVgap);
//					
//					//Check if atleast one word2 in vgaps has an overlap with the new vgap2-word2
//					boolean overlap = vgapGroup.size() == 0 ? true : false;
//					for(PDFVerticalGap existingVgap : vgapGroup){
//						float ex = existingVgap.getWord2().getRectangle().getX(), ex2 = existingVgap.getWord2().getRectangle().getX2();
//						float nx = childVgap.getWord2().getRectangle().getX(), nx2 = childVgap.getWord2().getRectangle().getX2();
//						
//						if(nx>=ex && nx<ex2)
//							overlap = true;
//						
//						else if(nx2>ex && nx2<=ex2)
//							overlap = true;
//						
//						else if(nx<=ex && nx2>=ex2)
//							overlap = true;
//						
//						if(overlap)
//							break;
//					}
//					
//					if(overlap){
//						vgapGroup.add(childVgap);
//						vgapTrack.add(childVgap);
//					}
//				}
			}
		}
		
		//****Now that we have the map of vgaps stacked, let's remove those that have less than required stacking
		int minStackedVgaps = new Integer(config.getString("minimumStackedVGaps"));
		vgapTrack.clear();//reset
		Iterator<Entry<PDFVerticalGap, List<PDFVerticalGap>>> it = vgapColumnTracker.entrySet().iterator();
		while(it.hasNext()){
			Entry<PDFVerticalGap, List<PDFVerticalGap>> tuple = it.next();
			if(tuple.getValue().size() < minStackedVgaps){//Key is counted as 1, hence the count for values should be one less
				it.remove();
			
			}else{
				vgapTrack.add(tuple.getKey());
				vgapTrack.addAll(tuple.getValue());
			}
		}
		if(vgapColumnTracker.size() == 0)
			return new ArrayList<PDFVerticalGap>();
		//*******************
		
		for(PDFVerticalGap key : vgapColumnTracker.keySet()){
			System.out.println("Key - "+key);
			System.out.println("Values:");
			for(PDFVerticalGap value : vgapColumnTracker.get(key))
				System.out.println(value);
		}
		System.out.println();
		
		//Now vgapTrack has all the eligible vgaps that have acceptable stacking
		//Let's consider those vgaps that are not in vgapTrack but have some y overlap or y2 overlap
		//But such overlapping vgaps should have an acceptable height
		float minVgapHeight = new Float(config.getString("minimumHeightOnYOverlap"));
		outer:
		for(PDFVerticalGap original : vgaps){
			if(!vgapTrack.contains(original)){
				for(PDFVerticalGap head : vgapColumnTracker.keySet()){
					
//					if(original.getWord2().getStringRepresentation().contains("AB1-1104") || 
//							head.getWord2().getStringRepresentation().contains("AB1-1104"))
//						System.out.println("debug");
					
					if(CommonOperations.isOverlapOnY(original, head) && original.getRectangle().getHeight() > head.getRectangle().getHeight()*minVgapHeight){
						vgapTrack.add(original);
						continue outer;
					}
				}
			}
		}
		
		return new ArrayList<PDFVerticalGap>(vgapTrack);
	}

	@Override
	public List<PDFVerticalGap> getOutcome() {
		return verticalGaps;
	}
	
}


//@Override
//public void apply() {
//	
//	for(int i=0; i<words.size()-1; i++){
//		
//		BasicStructure word1 = words.get(i);
////		BasicStructure word2 = words.get(i+1);
//		
//		if(word1.getStringRepresentation().contains("TerraForm Power, Inc.") /*&& word2.getStringRepresentation().contains("2,858")*/)
//			System.out.println("debug");
//		
////		float ydiff = Math.abs(word1.getRectangle().getY()-word2.getRectangle().getY());
//		
////		if(word2.getRectangle().getX()>word1.getRectangle().getX() && Commons.isOverlapOnY(word1, word2)/*ydiff<word1.getRectangle().getHeight()/2*/ 
////				&& !areWordsWithinExistingGap(word1, word2)){
//			
//			//Horizontal gap
////			float gap = word2.getRectangle().getX() - word1.getRectangle().getX2();
//			
//			PDFVerticalGap vgap = new PDFVerticalGap(word1, 
//					new Rectangle(word1.getRectangle().getX2(), word1.getRectangle().getY(), pageWidth-word1.getRectangle().getX2(), word1.getRectangle().getHeight(), page), 
//					StructureType.VERTICAL_GAP, word1.getWidthOfSpace());
//			
//			//If word1 and word2 is the last pair, there is no point looking for overlap
////			if(i+2 == words.size()-1){
////				vgap.setHeight(pageHeight - word1.getY2() - 1);
////				verticalGaps.add(vgap);
////				continue;
////			}
//			
//			boolean foundCompleteOverlap = false;
//			//Try finding a word that has some or complete overlap with the gap between these two words
//			for(int j=i+1; j<words.size(); j++){
//				BasicStructure thisWord = words.get(j);
//				
////				if(thisWord.getStringRepresentation().contains("3,265")){
////					System.out.println("Debug "+thisWord.getX2()+" "+vgap.getX2());
////				}
//				
//				//left end of the word overlap but the right end doesn't
//				if(thisWord.getRectangle().getX()>=vgap.getRectangle().getX() 
//						&& thisWord.getRectangle().getX()<=vgap.getRectangle().getX2()){
//					
//					
//					vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2()));
//					vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
//					
//					float width = thisWord.getRectangle().getX() - vgap.getRectangle().getX();
//					if(width > minimumVGapWidth*word1.getWidthOfSpace()){
//						vgap.getRectangle().setWidth(width);
//					
//					}else if(vgap.getRectangle().getHeight() > word1.getRectangle().getHeight() * verticalGapFactor){//Obstruction found, but now check for eligible height
//						verticalGaps.add(vgap);
//						foundCompleteOverlap = true;
//						break;
//					
//					}else{
//						foundCompleteOverlap = true;
//						break;
//					}
//				}
//				
//				//right end of the word overlap
//				//Do not put a condition of whether the left of the word overlaps. Even if it is between the width of vgap, we still would
//				//like the vgap to form on the right. This takes care of missing values between columns. If we have two numbers with a
//				//blank cell in between, we ideally want the vgap between the blank cell and the second number.
//				else if(thisWord.getRectangle().getX2()>vgap.getRectangle().getX() && thisWord.getRectangle().getX2()<=vgap.getRectangle().getX2()){
//					float width = vgap.getRectangle().getX2() - thisWord.getRectangle().getX2();
//					
//					vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2()));
//					vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
//					
//					if(width > minimumVGapWidth*word1.getWidthOfSpace()){
//						vgap.getRectangle().setX(thisWord.getRectangle().getX2());
//						vgap.getRectangle().setWidth(width);
//					
//					}else if(vgap.getRectangle().getHeight() > word1.getRectangle().getHeight() * verticalGapFactor){
//						verticalGaps.add(vgap);
//						foundCompleteOverlap = true;
//						break;
//					
//					}else{
//						foundCompleteOverlap = true;
//						break;
//					}
//				}
//				
//				//mid of the word overlap, hence a complete block
//				else if(thisWord.getRectangle().getX()<=vgap.getRectangle().getX() && thisWord.getRectangle().getX2()>=vgap.getRectangle().getX2()){
//					
//					vgap.getRectangle().setHeight(Math.abs(vgap.getRectangle().getY2() - thisWord.getRectangle().getY2())+1);
//					vgap.getRectangle().setY(thisWord.getRectangle().getY2()-1);
//					vgap.setBottomWord(thisWord.getStringRepresentation());
//					
//					if(vgap.getRectangle().getHeight() > word1.getRectangle().getHeight() * verticalGapFactor && vgap.getRectangle().getWidth() > minimumVGapWidth*word1.getWidthOfSpace()){
//						verticalGaps.add(vgap);
//					}
//					
//					foundCompleteOverlap = true;
//					break;
//				}
//			}
//			
//			//If we din't found an overlap, this goes till the end of the page
//			if(!foundCompleteOverlap && vgap.getRectangle().getWidth()>word1.getWidthOfSpace()){
//				
//				vgap.getRectangle().setHeight(pageHeight-vgap.getRectangle().getY2());
//				vgap.getRectangle().setY(pageHeight-1);
//				verticalGaps.add(vgap);
//			}
////		}
//	}
//}
