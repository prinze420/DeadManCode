package com.pdf.parser.base.strategy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.apache.pdfbox.pdmodel.PDDocument;

import com.pdf.parser.Strategy;
import com.pdf.parser.Structure;
import com.pdf.parser.StructureType;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.KeyValuePair;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.base.strategy.IgnoredKey.POSITION;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;

public class KeyValueStrategy implements Strategy<List<Structure>> {

	//Successive segments may be merged in values based on the difference between y/y2 times this factor
	public static final float SEG_MERGE_HEIGHT_FACTOR = 3.5f;

	List<Structure> structures;
	List<StructureGroup> segLists;
	List<IgnoredKey> ignoredKeys; //Certain segments ending with colon might be false positives
	List<PDFSegment> pageSegments;
	public KeyValueStrategy(List<StructureGroup> segLists, List<PDFSegment> pageSegments) {
		this.segLists = segLists;
		this.structures = new ArrayList<Structure>();
		this.pageSegments=pageSegments;
		readIgnoredKeys();
		breakSegmentsOnKeys();//a segment may contain more than one key
	}

	private void readIgnoredKeys(){
		ignoredKeys = new ArrayList<IgnoredKey>();

		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/KeyValue-Ignore.list"));

			String line = "";
			while((line = reader.readLine()) != null){
				String key = line.split("\\t")[0];
				String pos = line.split("\\t")[1];

				ignoredKeys.add(new IgnoredKey(key, pos.equalsIgnoreCase("contains")?POSITION.CONTAINS : POSITION.ENDS_WITH));
			}

			reader.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void breakSegmentsOnKeys(){
		for(StructureGroup g : segLists){

			Iterator<BasicStructure> it = g.getBasicStructures().iterator();
			List<PDFSegment> segs = new ArrayList<PDFSegment>();

			while( it.hasNext()){
				BasicStructure bs = it.next();

				if(bs instanceof PDFSegment){
					PDFSegment seg = (PDFSegment)bs;
					String s = seg.getStringRepresentation().trim();

					if(s.contains(":")){ //Segment contains colon

						//Find out the break points in the segment based on how many colons are present
						List<Integer> breakPoints = new ArrayList<Integer>();
						for(int i=0; i<seg.getWords().size()-1; i++){//Find words ending with colon until second last word
							PDFWord w = seg.getWords().get(i);
							if(w.getStringRepresentation().trim().endsWith(":"))
								breakPoints.add(i);
						}

						if(breakPoints.size()==0){
							segs.add(seg);
							it.remove();
							continue;
						}

						int lastbp = 0;
						for(int bp : breakPoints){
							List<PDFWord> sublist = seg.getWords().subList(lastbp, bp+1);
							String wordString = "";
							for(PDFWord word : sublist)
								wordString += word.getStringRepresentation().trim()+" ";

							PDFSegmentFormationStrategy.makeSegment(sublist, wordString.trim(), segs, sublist.get(0).getRectangle().getPage());
							lastbp = bp+1;
						}

						if(lastbp<seg.getWords().size()){
							List<PDFWord> sublist = seg.getWords().subList(lastbp, seg.getWords().size());
							String wordString = "";
							for(PDFWord word : sublist)
								wordString += word.getStringRepresentation().trim()+" ";

							PDFSegmentFormationStrategy.makeSegment(sublist, wordString.trim(), segs, sublist.get(0).getRectangle().getPage());
						}

					}else
						segs.add(seg);
				}

				it.remove();
			}

			g.getBasicStructures().addAll(segs);
		}
	}

	public void apply() {
		List<BasicStructure> keys = getKeys();

		for(int i=0; i<keys.size(); i++){

			BasicStructure ckey = keys.get(i); //current key
			if(ckey.getStringRepresentation().contains("COMPLAINT")){
				System.out.print("");	
			}
			BasicStructure nearestRight = null, nearestBottom = null;
			for(int j=i+1; j<keys.size(); j++){
				BasicStructure tkey = keys.get(j); //key to compare
				
				if(nearestRight==null && CommonOperations.isOverlapOnY(ckey, tkey)){
					nearestRight = tkey;
					continue;
				}

				/*if(CommonOperations.isOverlapOnX(ckey, tkey)){
					nearestBottom = tkey;
					break;
				}*/

				if(nearestBottom != null) //If we find a nearest key below, we do not need to search for a adjacent key
					break;
			}

			List<BasicStructure> valueSegs = findValueSegs(ckey, nearestRight, nearestBottom,keys);

			if(valueSegs.size()>0){//Create a key value pair

				float x=ckey.getRectangle().getX(), y=ckey.getRectangle().getY(), x2=ckey.getRectangle().getX(), y2=ckey.getRectangle().getY2();
				String valueText = "";
				for(BasicStructure v : valueSegs){
					if(v.getRectangle().getX() < x)
						x = v.getRectangle().getX();

					if(v.getRectangle().getY() > y)
						y = v.getRectangle().getY();

					if(v.getRectangle().getX2() > x2)
						x2 = v.getRectangle().getX2();

					if(v.getRectangle().getY2() < y2)
						y2 = v.getRectangle().getY2();

					valueText += v.getStringRepresentation() + " ";
				}

				DPRectangle rect = new DPRectangle(x, y, x2-x, y-y2, ckey.getRectangle().getPage());
				String text = ckey.getStringRepresentation()+" "+valueText.trim();

				if(ckey instanceof PDFSegment){
					((PDFSegment)ckey).setIsInKVPair(true);
				}
				for (BasicStructure seg : valueSegs) {
					if(seg instanceof PDFSegment){
						((PDFSegment)seg).setIsInKVPair(true);
					}
				}
				//remove enum from key
				String ckeyText=ckey.getStringRepresentation();
				if(ckey instanceof PDFSegment && ((PDFSegment)ckey).isEnumerated()){
					String enTxt = ((PDFSegment)ckey).getEnumeration();
					ckeyText=ckey.getStringRepresentation().substring(ckey.getStringRepresentation().indexOf(enTxt)+enTxt.length()).trim();
				}
				structures.add(new KeyValuePair(ckey, ckeyText, valueSegs, valueText.trim(), text, rect, ckey.getWidthOfSpace()));
			}
		}
	}

	private List<BasicStructure> getKeys(){
		List<BasicStructure> segs = new ArrayList<BasicStructure>();

		for(StructureGroup group : segLists){
			for(BasicStructure s : group.getBasicStructures()){
				if(s.getStringRepresentation().contains("COMPLAINT")){
					System.out.print("");
				}

				if(IgnoredKey.shouldIgnore(s.getStringRepresentation(), ignoredKeys))
					continue;
				//if(s2Text.matches("[#��,&'$!%@()/\"].*"))
				else if(s.getStringRepresentation().trim().endsWith(":")  /*&& !s.getStringRepresentation().matches(".*[0-9(]+.*") && !s.getStringRepresentation().contains("[#��$!%@()/\"]")*/)
					segs.add(s);
			}
		}

		return segs;
	}

	/**
	 * 
	 * @param ckey Current Key to be investigated
	 * @param rKey Adjacent Key
	 * @param bKey Key under the current key
	 * @param keys 
	 * @return List of segments that are the value of the current key
	 */
	private List<BasicStructure> findValueSegs(BasicStructure ckey, BasicStructure rKey, BasicStructure bKey, List<BasicStructure> keys){
		List<BasicStructure> valueSegs = new ArrayList<BasicStructure>();

		boolean currentGroupFound = false;
		if(ckey.getStringRepresentation().contains("Event Description")){
			System.out.print("");	
		}
		lists:
			for(StructureGroup grp : segLists){
				int index = grp.getBasicStructures().indexOf(ckey);

				if(index!=-1 || currentGroupFound){
					currentGroupFound = true;
					BasicStructure lastSeg = ckey;
					for(int i=index+1; i<grp.getBasicStructures().size(); i++){
	 					BasicStructure bs = grp.getBasicStructures().get(i);
						if(bs.equals(rKey)){
							
							//Customize for: liveworld source PVAI ("CONTENT OF POST" and "AUTHOR NAME:" and "PROFILE URL:" are in single line)
							if(bs.getStringRepresentation().endsWith("AUTHOR NAME:")){
								String text="";
								List<PDFWord>temp=new ArrayList<PDFWord>();
								for (PDFWord w : ((PDFSegment)bs).getWords()) {
									if(w.getStringRepresentation().contains("AUTHOR"))
										break;
									text+=w.getStringRepresentation()+" ";
									temp.add(w);
								}
								PDFSegment s=new PDFSegment(text.trim(), bs.getRectangle(), StructureType.WORD, temp);
								if(addNear(valueSegs, s));


							}else if(bs.getStringRepresentation().endsWith("PROFILE URL:")){//for liveworld PVAI
								String text="";
								List<PDFWord>temp=new ArrayList<PDFWord>();
								for (PDFWord w : ((PDFSegment)bs).getWords()) {
									if(w.getStringRepresentation().contains("PROFILE"))
										break;
									text+=w.getStringRepresentation()+" ";
									temp.add(w);
								}
								PDFSegment s=new PDFSegment(text.trim(), bs.getRectangle(), StructureType.WORD, temp);
								if(addNear(valueSegs, s));

							}

							break;
						}
						//					consider only same simple KVP
						float diff = Math.abs(ckey.getRectangle().getY()-bs.getRectangle().getY());
						
						float xDiff = bs.getRectangle().getX()-lastSeg.getRectangle().getX2();
						/*if(diff>2 && xDiff<0){
							xDiff=1;
						}*/
						if((diff < 1 || CommonOperations.isOverlapOnY(ckey, bs)) && xDiff >0  && xDiff < bs.getRectangle().getWidth()*2.5){

							if(bKey != null){
								if(rKey!=null && bs.equals(rKey))
									continue lists;

								if(bs.equals(bKey))
									break lists;

								//-2 is the acceptable tolerance
								if(bs.getRectangle().getX()>=ckey.getRectangle().getX()-2){

									//If rKey exists then check whether the current segment's x is before that
									boolean cont = true;
									if(rKey!=null && bs.getRectangle().getX()>rKey.getRectangle().getX())
										cont = false;

									if(cont){
										if(!addNear(valueSegs, bs)){
											lastSeg=bs;
											continue lists;
										}
									}
								}

							}else{//Simple case where we do not find an adjacent or below key
								if(bs.getRectangle().getX()>=ckey.getRectangle().getX()-2){
									if(addNear(valueSegs, bs)){
										lastSeg=bs;
										continue ;//lists;
									}
									else
										break lists;
								}
							}
						}

						if(keys.contains(bs)){
							break;
						}

						//for multiline KVP
						BasicStructure lastseg = null;
						if(!valueSegs.isEmpty()){
							lastseg=valueSegs.get(valueSegs.size()-1);

							float hightDiff = Math.abs(lastseg.getRectangle().getY()-bs.getRectangle().getY2());

							if(rKey==null && hightDiff < (ckey.getRectangle().getHeight()+1)){

								//System.out.println("Add:\t"+bs.getStringRepresentation());
								if(addNear(valueSegs, bs)){
									//lastSeg=bs;
									continue ;//lists;
								}
								else
									break lists;

							}else{
								break;
							}
						}
					}
				}
			}

		//customize for ADVERSE EVENT : keys value detection only: multi lines (values) are in front of this key with center aligned : need to check top and below segments to catch proper value text 
		if(/*valueSegs.isEmpty() && */ckey.getStringRepresentation().contains("ADVERSE EVENT :") && rKey!=null){

			BasicStructure middleStructOfCurrentAndNextKey=null; 
			outer:
				for(StructureGroup ySegsStrGrp : segLists){
					if(ySegsStrGrp.toString().contains("Unique toxicity in the liver(cause")){
						System.out.println(ySegsStrGrp.getRect().getY());
						System.out.println(ckey.getRectangle().getY());
						System.out.println(ySegsStrGrp.getRect().getY()-ckey.getRectangle().getY());
					}

					for (BasicStructure currentSeg : ySegsStrGrp.getBasicStructures()) {

						if(middleStructOfCurrentAndNextKey==null && !currentSeg.equals(ckey) && !currentSeg.equals(rKey)
								&& (Math.abs(currentSeg.getRectangle().getY2()-ckey.getRectangle().getY())<2 
										|| (Math.abs(currentSeg.getRectangle().getY()-ckey.getRectangle().getY2())<2)
										|| (Math.abs(currentSeg.getRectangle().getY()-ckey.getRectangle().getY())<2))
								){
							if(currentSeg.getRectangle().getX2()< rKey.getRectangle().getX()){
								addNear(valueSegs, currentSeg);
								middleStructOfCurrentAndNextKey = currentSeg;
								break outer;
							}
						}

					}
				}
			if(middleStructOfCurrentAndNextKey!=null){
				List<BasicStructure> bStru = getBelowSegs(middleStructOfCurrentAndNextKey, segLists, 0,ckey);
				List<BasicStructure> topStru = getTopOverlapedData(middleStructOfCurrentAndNextKey, segLists,ckey);

				for(BasicStructure bs : bStru){
					if(!valueSegs.contains(bs))
						addNear(valueSegs, bs);
				}

				for(BasicStructure bs : topStru){
					if(!valueSegs.contains(bs))
						addNear(valueSegs, bs);
				}
			}

		}

		Collections.sort(valueSegs, new Comparator<BasicStructure>() {

			@Override
			public int compare(BasicStructure o1, BasicStructure o2) {
				// TODO Auto-generated method stub
				//return 0;
				return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
			}


		});
		return valueSegs;
	}

	public static List<BasicStructure>getBelowSegs(BasicStructure midleValStrGrp, List<StructureGroup> segLists2, int i, BasicStructure ckey){
		List<BasicStructure> temp=new ArrayList<BasicStructure>();

		//	float belowLineLimit = 3*mainKeyWord_Seg.getRectangle().getHeight();

		BasicStructure lastStructure=midleValStrGrp;

		for(int segNo=i;segNo<segLists2.size();segNo++){
			StructureGroup strGrp = segLists2.get(segNo);

			for (BasicStructure currentSeg : strGrp.getBasicStructures()) {
				if(currentSeg.getRectangle().getY2()> lastStructure.getRectangle().getY()){
					/*if(currentSeg.getBasicStructures().contains(ckey)){
					continue;
				}*/
					//				System.out.println(lastStrGrp.getRect().getY()-currentSeg.getRect().getY2());
					//				System.out.println(currentSeg.getRect().getHeight());
					if(CommonOperations.isOverlapOnX(lastStructure, currentSeg) 
							&& Math.abs(lastStructure.getRectangle().getY()-currentSeg.getRectangle().getY2()) < 2*currentSeg.getRectangle().getHeight()
							&& lastStructure.getRectangle().getX()==currentSeg.getRectangle().getX()
							){
						temp.add(currentSeg);
						lastStructure=currentSeg;
					}
				}

			}
		}
		return temp;
	}

	public static List<BasicStructure> getTopOverlapedData(BasicStructure pdfCurrentSegment, List<StructureGroup> pageSegs, BasicStructure ckey) {
		List<BasicStructure> topMatchedSeg = new ArrayList<>();
		BasicStructure lastStrGrp=pdfCurrentSegment;

		//outer:
		for (int i = (pageSegs.size() - 1); i >= 0; i--) {

			StructureGroup strGrp = pageSegs.get(i);

			for (BasicStructure currentSeg : strGrp.getBasicStructures()) {
				//	if(currentSeg.getRectangle().getY2()> lastStructure.getRectangle().getY()){

				if (currentSeg.getRectangle().getY() < lastStrGrp.getRectangle().getY() ) {
					if(currentSeg.getStringRepresentation().contains("Unique toxicity")){
						//continue;
						System.out.println();
					}
					if (CommonOperations.isOverlapOnX(currentSeg, lastStrGrp)
							&& Math.abs(lastStrGrp.getRectangle().getY2()-currentSeg.getRectangle().getY()) < 2*currentSeg.getRectangle().getHeight()
							&& lastStrGrp.getRectangle().getX()==currentSeg.getRectangle().getX()
							) {
						topMatchedSeg.add(currentSeg);
						lastStrGrp=currentSeg;
					}
				}
			}
		}

		return topMatchedSeg;
	}

	/*public static boolean isOverlapOnX(StructureGroup midleValStrGrp, StructureGroup currentSeg){
		boolean overlap = false;

		if(currentSeg.getRect().getX() >= midleValStrGrp.getRect().getX() && currentSeg.getRect().getX() < midleValStrGrp.getRect().getX2())
			overlap = true;

		else if(currentSeg.getRect().getX2() <= midleValStrGrp.getRect().getX2() && currentSeg.getRect().getX2() > midleValStrGrp.getRect().getX())
			overlap = true;

		else if(currentSeg.getRect().getX() <= midleValStrGrp.getRect().getX() && currentSeg.getRect().getX2() >= midleValStrGrp.getRect().getX2())
			overlap = true;

		return overlap;
	}*/
	//Add to the list if it's vertically near.... similar to para formation
	private boolean addNear(List<BasicStructure> values, BasicStructure bs){
		if(values.size() == 0){
			values.add(bs);
			return true;
		
		}else if(values.contains(bs))
			return false;

		BasicStructure lastVal = values.get(values.size()-1);
		if(CommonOperations.isOverlapOnY(bs, lastVal)){
			values.add(bs);
			return true;
		}

		float diffH = bs.getRectangle().getY2() - lastVal.getRectangle().getY();
		if(diffH < lastVal.getRectangle().getHeight() * SEG_MERGE_HEIGHT_FACTOR){
			values.add(bs);
			return true;
		}

		return false;
	}

	public List<Structure> getOutcome() {
		return structures;
	}

	public static void main(String[] args) throws Exception{
		//		DefaultParser p = new DefaultParser("SwissRe-Sample\\AWD100183\\100183.pdf");
		DefaultParser p = new DefaultParser(PDDocument.load(new File("SwissRe-Sample\\AWD100183\\100183.pdf")));
		p.parse();

		//		KeyValueStrategy kv = new KeyValueStrategy(CommonOperations.groupStructuresOnY(p.getSegments().get(0)));
		//		kv.apply();

		//System.out.println(""+kv.getOutcome());
	}
}

class IgnoredKey{

	public enum POSITION{CONTAINS,ENDS_WITH}

	String keyword;
	POSITION pos;

	public IgnoredKey(String keyword, POSITION pos) {
		this.keyword = keyword;
		this.pos = pos;
	}

	public static boolean shouldIgnore(String s, List<IgnoredKey> keys){

		s = s.toLowerCase().trim();

		for(IgnoredKey k : keys){
			if(k.getPos().equals(POSITION.CONTAINS)){
				if(s.contains(k.getKeyword()))
					return true;

			}else if(k.getPos().equals(POSITION.ENDS_WITH)){
				if(s.endsWith(k.getKeyword()))
					return true;
			}
		}

		return false;
	}

	public String getKeyword() {
		return keyword;
	}

	public POSITION getPos() {
		return pos;
	}
	public static List<PDFSegment> findAllOverlapedSegment(PDFSegment pdfCurrentSegment, List<PDFSegment> pagSegs,int segNum) {
		List<PDFSegment> temp=new ArrayList<PDFSegment>();

		for (int i = 0; i < pagSegs.size(); i++) {
			PDFSegment nextSeg = pagSegs.get(i);

			float diff = nextSeg.getRectangle().getY() - pdfCurrentSegment.getRectangle().getY();

			if (nextSeg.getRectangle().getY() > pdfCurrentSegment.getRectangle().getY() && diff > 2 && diff <= pdfCurrentSegment.getRectangle().getHeight()+1 ) {

				if(temp.size()==0&&CommonOperations.isOverlapOnX(nextSeg, pdfCurrentSegment))
				{
					temp.add(nextSeg);
					pdfCurrentSegment=nextSeg;
				}else if (CommonOperations.isOverlapOnX(nextSeg, pdfCurrentSegment)&& isValid_Y_gap(nextSeg,pdfCurrentSegment)) 
				{	pdfCurrentSegment=nextSeg;
				temp.add(nextSeg);
				}
			}
		}

		return temp;
	}

	private static boolean isValid_Y_gap(PDFSegment nextSeg,PDFSegment pdfCurrentSegment) {
		float threshold=nextSeg.getRectangle().getHeight()*3;
		float diff = nextSeg.getRectangle().getY2()-pdfCurrentSegment.getRectangle().getY();
		if(diff<threshold){
			return true;
		}
		return false;
	}

	public static List<PDFSegment> findFirst_TopOverlapedSegment(PDFSegment pdfCurrentSegment, List<PDFSegment> pageSegs) {
		List<PDFSegment> topMatchedSeg = new ArrayList<PDFSegment>();
		for (int i = (pageSegs.size() - 1); i >= 0; i--) {
			PDFSegment s1 = pageSegs.get(i);
			PDFSegment s2 = pdfCurrentSegment;

			float diff = s2.getRectangle().getY() - s1.getRectangle().getY();

			if (s1.getRectangle().getY() < s2.getRectangle().getY() && diff > 2 && diff <= 34) {
				if (CommonOperations.isOverlapOnX(s1, s2)) {
					topMatchedSeg.add(s1);
				}
			}
		}

		return topMatchedSeg;
	}
	public List<PDFSegment>getFrontSegment(PDFSegment mainKeyWord_Seg, List<PDFSegment> pageSegments, int i){
		List<PDFSegment> temp=new ArrayList<PDFSegment>();

		for(int segNo=i;segNo<pageSegments.size();segNo++){
			PDFSegment currentSeg = pageSegments.get(segNo);
			if(mainKeyWord_Seg.equals(currentSeg)|| mainKeyWord_Seg.getRectangle().getX2() > currentSeg.getRectangle().getX()){
				continue;
			}
			float ydiff = Math.abs(currentSeg.getRectangle().getY()-mainKeyWord_Seg.getRectangle().getY());
			boolean slightYdiff=false;

			if(currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY2() <= mainKeyWord_Seg.getRectangle().getY() ){
				slightYdiff=true;
			}
			if(currentSeg.getRectangle().getY() <= mainKeyWord_Seg.getRectangle().getY()&& currentSeg.getRectangle().getY() >= mainKeyWord_Seg.getRectangle().getY2() ){
				slightYdiff=true;
			}


			if(ydiff<1.0 || slightYdiff){
				temp.add(pageSegments.get(segNo));
			}

		}

		return temp;
	}

	public List<PDFSegment>getBelowText(PDFSegment mainKeyWord_Seg, List<PDFSegment> pageSegments, int i){
		List<PDFSegment> temp=new ArrayList<PDFSegment>();

		float belowLineLimit = 3*mainKeyWord_Seg.getRectangle().getHeight();

		for(int segNo=i;segNo<pageSegments.size();segNo++){
			PDFSegment currentSeg = pageSegments.get(segNo);
			if(currentSeg.getRectangle().getY2()>mainKeyWord_Seg.getRectangle().getY()){

				float ydiff = Math.abs(currentSeg.getRectangle().getY()-mainKeyWord_Seg.getRectangle().getY());

				if(ydiff>1.0 && currentSeg.getRectangle().getY()<(mainKeyWord_Seg.getRectangle().getY()+belowLineLimit)){
					temp.add(pageSegments.get(segNo));
				}
			}

		}

		return temp;
	}

}