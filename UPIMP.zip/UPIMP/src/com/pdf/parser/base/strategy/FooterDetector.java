package com.pdf.parser.base.strategy;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.commons.lang.StringUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.Strategy;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.pipeline.DefaultParser;
import com.pdf.parser.utils.CommonOperations;

/**
 * We are planning to detect footers based on the following strategies:
 * 1. Predefined pattern file
 * 2. Repetition of text at a similar location
 * @author Shishir.Mane
 *
 */
public class FooterDetector implements Strategy<Map<Integer,List<PDFSegment>>> {
	
	static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	Map<Integer,List<PDFSegment>> pageWiseSegments;
	List<PDPage> pages;
	
	public FooterDetector(Map<Integer,List<PDFSegment>> pageWiseSegments, List<PDPage> pages){
		this.pageWiseSegments = pageWiseSegments;
		this.pages = pages;
	}
	
	public void apply() {
		float heightThreshold = Float.valueOf(config.getString("footerHeightThreshold"));
		int editDistance = Integer.valueOf(config.getString("allowedEditDistance"));
		float footerPagesFactor = Float.valueOf(config.getString("footerPagesFactor"));
		
		Map<Integer,List<PDFSegment>> pageWiseFooters = new HashMap<Integer,List<PDFSegment>>();
		
		List<String> patterns = new ArrayList<String>();
		try {
			BufferedReader reader = new BufferedReader(new FileReader("config/footer-pattern.list"));
			
			String line = "";
			while((line = reader.readLine()) != null)
				patterns.add(CommonOperations.processDataType(line.trim().toLowerCase()));
			
			reader.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//****Remove segments based on patterns
		for(List<PDFSegment> segments : pageWiseSegments.values()){
			Iterator<PDFSegment> it = segments.iterator();
			
			seg:
			while(it.hasNext()){
				PDFSegment segment = it.next();
				float pageHeight = pages.get(segment.getRectangle().getPage()).getBleedBox().getHeight();
				if(segment.getRectangle().getY() > pageHeight*(1-heightThreshold)){
					
					for(String pattern : patterns){
						if(segment.getStringRepresentation().toLowerCase().trim().matches(pattern)){
							
							it.remove();
							
							int page = segment.getRectangle().getPage();
							List<PDFSegment> footers = pageWiseFooters.get(page);
							if(footers == null){
								footers = new ArrayList<PDFSegment>();
								pageWiseFooters.put(page, footers);
							}
							footers.add(segment);
							
//							System.out.println("Pattern - "+segment.getStringRepresentation());
							continue seg;
						}
					}
				}
			}
		}
		//*****************
		
		//**Find similar segments on pages that can be termed footer and be removed
		if(config.getString("dynamicFind").equals("true")){
			
			Map<PDFSegment,Integer> segmentFreq = new HashMap<PDFSegment,Integer>();
			
			for(List<PDFSegment> segments : pageWiseSegments.values()){
				for(PDFSegment segment : segments){
					
					float pageHeight = pages.get(segment.getRectangle().getPage()).getBleedBox().getHeight();
					
					if(segment.getRectangle().getY() > pageHeight*(1-heightThreshold)){
						if(segmentFreq.containsKey(segment)){
							segmentFreq.put(segment, segmentFreq.get(segment)+1);
						
						}else{
							
							boolean isSuccessful = false;
							for(PDFSegment key : segmentFreq.keySet()){
								String s1 = segment.getStringRepresentation().toLowerCase().trim();
								String s2 = key.getStringRepresentation().toLowerCase().trim();
								
								if(s1.length()>editDistance && s2.length()> editDistance && 
										StringUtils.getLevenshteinDistance(s1, s2) <= editDistance){
									
									segmentFreq.put(key, segmentFreq.get(key)+1);
									isSuccessful = true;
									break;
								}
							}
							
							if(!isSuccessful)
								segmentFreq.put(segment, 1);
						}
					}
				}
			}
			
			//Remove segments if they occur in more than min pages
			for(PDFSegment footer : segmentFreq.keySet()){
				
				int minPages = (int)(pages.size() * footerPagesFactor);
				if(segmentFreq.get(footer) >= minPages){
					
					for(List<PDFSegment> segments : pageWiseSegments.values()){
						Iterator<PDFSegment> it = segments.iterator();
						
						while(it.hasNext()){
							PDFSegment segment = it.next();
							float pageHeight = pages.get(segment.getRectangle().getPage()).getBleedBox().getHeight();
							if(segment.getRectangle().getY() > pageHeight*(1-heightThreshold)){
								
								String s1 = segment.getStringRepresentation().toLowerCase().trim();
								String s2 = footer.getStringRepresentation().toLowerCase().trim();
								if(s1.equals(s2) || StringUtils.getLevenshteinDistance(s1, s2) <= editDistance){
									it.remove();
									
									int page = segment.getRectangle().getPage();
									List<PDFSegment> footers = pageWiseFooters.get(page);
									if(footers == null){
										footers = new ArrayList<PDFSegment>();
										pageWiseFooters.put(page, footers);
									}
									footers.add(segment);
//									System.out.println(segment.getStringRepresentation());
								}
							}
						}
					}
				}
			}
		}
		//****************
		
		//*******Try and detect plain numbers based on location and sequence
		if(config.getString("detectNumberSeries").equals("true")){
			
			int locationToleranceForSeries = Integer.valueOf(config.getString("locationToleranceForSeries"));
			int seriesTolerance = Integer.valueOf(config.getString("seriesTolerance"));
			
			Map<Integer,PDFSegment> possiblePageNumbers = new HashMap<Integer,PDFSegment>();
			
			int pg=0;
			outer:
			for(List<PDFSegment> segments : pageWiseSegments.values()){
				
				for(PDFSegment segment : segments){
					
					float pageHeight = pages.get(segment.getRectangle().getPage()).getBleedBox().getHeight();
					if(segment.getRectangle().getY() > pageHeight*(1-heightThreshold) && segment.getStringRepresentation().matches("\\d+")){
						
						if(possiblePageNumbers.isEmpty()){
							possiblePageNumbers.put(pg,segment);
							pg++;
							continue outer;
						
						}else{
							PDFSegment last = possiblePageNumbers.get(pg-1);
							
							if(last == null)
								break outer;
							
							int val1 = Integer.valueOf(last.getStringRepresentation());
							int val2 = Integer.valueOf(segment.getStringRepresentation());
							int diffVal = Math.abs(val1 - val2);
							
							float diffX = Math.abs(segment.getRectangle().getX() - last.getRectangle().getX());
							float diffY = Math.abs(segment.getRectangle().getY() - last.getRectangle().getY());
							
							if(diffVal<seriesTolerance && diffX<locationToleranceForSeries && diffY<locationToleranceForSeries){
								possiblePageNumbers.put(pg,segment);
								pg++;
								continue outer;
								
							}else
								break outer;//Completely break
						}
					}
				}
				
				pg++;
			}
			
			int minPages = (int)(pages.size() * footerPagesFactor);
			if(possiblePageNumbers.size() >= minPages){
				for(int i=0; i<pages.size(); i++){
					if(possiblePageNumbers.containsKey(i)){
						pageWiseSegments.get(i).remove(possiblePageNumbers.get(i));
						
						List<PDFSegment> footers = pageWiseFooters.get(i);
						if(footers == null){
							footers = new ArrayList<PDFSegment>();
							pageWiseFooters.put(i, footers);
						}
						footers.add(possiblePageNumbers.get(i));
					}
				}
			}
		}
		//*********************
		
		//************With all the footers that have been removed, we need to eliminate all the segments that fall at the same y-level or below of the footer
		
		for(int i=0; i<pageWiseSegments.size(); i++){
			
			if(!pageWiseFooters.containsKey(i) || pageWiseFooters.get(i).size()==0)
				continue;
			
			List<PDFSegment> footers = pageWiseFooters.get(i);
			//Let's first sort all the footers per page to get the min y2
			Collections.sort(footers, new Comparator<PDFSegment>(){
				@Override
				public int compare(PDFSegment o1, PDFSegment o2) {
					return Float.valueOf(o1.getRectangle().getY2()).compareTo(o2.getRectangle().getY2());
				}
			});
			
			List<PDFSegment> segments = pageWiseSegments.get(i);
			Iterator<PDFSegment> it = segments.iterator();
			
			while(it.hasNext()){
				PDFSegment segment = it.next();
				if(segment.getRectangle().getY() > footers.get(0).getRectangle().getY2()){
					it.remove();
				}
			}
		}
		//***********************
	}

	public Map<Integer,List<PDFSegment>> getOutcome() {
		return pageWiseSegments;
	}
	
	public static void main(String[] args) throws Exception{
//		System.out.println(StringUtils.getLevenshteinDistance("ravi", "raviravi"));
		
		DefaultParser dp = new DefaultParser(PDDocument.load(new File("D:\\MPhasis\\03152016\\OCR\\Lisa ISDA_1.pdf")));
		dp.parse();
		
		FooterDetector f = new FooterDetector(dp.getSegments(), dp.getPdfPages());
		f.apply();
		
		System.out.println("done");
	}
}
