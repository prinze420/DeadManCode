package com.pdf.parser.base;

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;

/**
 * A word is nothing but a list of characters that do not have space.
 * @author Shishir.Mane
 * @see 2.1.1.2.
 */
public class PDFWord implements BasicStructure {
	
	long id;
	DPRectangle rectangle;
	String stringRepresentation;
	StructureType type;
	List<PDFCharacter> characters;
	boolean isCompletelyBold;
	
	public PDFWord(String word, DPRectangle rectangle, StructureType type, List<PDFCharacter> characters) {
		id = Structure_Id.getInstance().getNext();
		this.stringRepresentation = word;
		this.rectangle = rectangle;
		this.type = type;
		this.characters = new ArrayList<PDFCharacter>(characters);
		isCompletelyBold = false;
	}
	
	public long getId() {
		return id;
	}

	@Override
	public String toString() {
		return stringRepresentation;//+" "+x+" "+getX2()+" "+getWidthOfSpace();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangle == null) ? 0 : rectangle.hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFWord other = (PDFWord) obj;
		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public String getStringRepresentation() {
		return stringRepresentation.trim();
	}
	public void setStringRepresentation(String text) {
		this.stringRepresentation=text;
	}

	public StructureType getType() {
		return type;
	}

	public List<PDFCharacter> getCharacters() {
		return characters;
	}

	public DPRectangle getRectangle() {
		return rectangle;
	}

	@Override
	public float getWidthOfSpace() {
		return getCharacters().get(0).getWidthOfSpace();
	}

	public boolean isCompletelyBold() {
		return isCompletelyBold;
	}

	public void setCompletelyBold(boolean isCompletelyBold) {
		this.isCompletelyBold = isCompletelyBold;
	}

	public int getMultiColumnIndex() {
		// TODO Auto-generated method stub
		return 0;
	}
	
	boolean isCellPart;
	public void setIsCellPart(boolean b) {
		// TODO Auto-generated method stub
		this.isCellPart = b;
	}
	
	public boolean isCellPart() {
		
		return isCellPart;
	}
	
	DPCell lineDPCell;
	public void setLineDPCell(DPCell c) {
		this.lineDPCell=c;
	}
	
	public DPCell getLineDPCell(){
		return lineDPCell;
	}
	public List<PDFWord> breakWord(String phrase){
		List<PDFWord> broken = new ArrayList<PDFWord>();

		String word1 = "", word2 = "";
		List<PDFCharacter> words1 = new ArrayList<PDFCharacter>();
		List<PDFCharacter> words2 = new ArrayList<PDFCharacter>();

		if(stringRepresentation.toLowerCase().trim().contains(phrase.toLowerCase().trim())){
			int i=0;

			for(i=0; i<characters.size(); i++){
				word1 += characters.get(i).getStringRepresentation();
				if(characters.get(i).getStringRepresentation().toLowerCase().trim().equals(phrase.toLowerCase().trim()))
					break;
			}

			for(int j=i+1; j<characters.size(); j++)
				word2 += characters.get(j).getStringRepresentation();

			for(int j=0; j<characters.size(); j++){
				if(j<=i)
					words1.add(characters.get(j));
				else
					words2.add(characters.get(j));
			}

		}
//		else if(stringRepresentation.toLowerCase().trim().contains(phrase.toLowerCase().trim())){
//			int i=0;
//
//			for(i=characters.size()-1; i>=0; i--){
//				word2 = characters.get(i).getStringRepresentation()+" "+word2;
//				if(word2.toLowerCase().trim().equals(phrase.toLowerCase().trim()))
//					break;
//			}
//
//			for(int j=0; j<i; j++)
//				word1 += characters.get(j).getStringRepresentation()+" ";
//
//			for(int j=0; j<characters.size(); j++){
//				if(j<i)
//					words1.add(characters.get(j));
//				else
//					words2.add(characters.get(j));
//			}
//		}

		if(words1.size()>0 && words2.size()>0){
			float x = words1.get(0).getRectangle().getX();
			float y = words1.get(0).getRectangle().getY();
			float width = words1.get(words1.size()-1).getRectangle().getX2() - words1.get(0).getRectangle().getX();
			float height = words1.get(0).getRectangle().getHeight();
			
			DPRectangle rectangle=new DPRectangle(x, y, width, height, words1.get(0).getRectangle().getPage());
			//String word, DPRectangle rectangle, StructureType type, List<PDFCharacter> characters
			PDFWord newWord1=new PDFWord(word1, rectangle, StructureType.WORD, words1);
			broken.add(newWord1);

			x = words2.get(0).getRectangle().getX();
			y = words2.get(0).getRectangle().getY();
			width = words2.get(words2.size()-1).getRectangle().getX2() - words2.get(0).getRectangle().getX();
			height = words2.get(0).getRectangle().getHeight();
			
			DPRectangle rectangle2=new DPRectangle(x, y, width, height, words2.get(0).getRectangle().getPage());
			PDFWord newWord2=new PDFWord(word2, rectangle2, StructureType.WORD, words2);
			broken.add(newWord2);
		}

		return broken;
	}

}
