package com.pdf.parser.base;

import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;






/**
 * A character on a particular PDF's page.
 * @author Shishir.Mane
 * @see Point 2.1.1.1.
 */
public class PDFCharacter implements BasicStructure {

private long id;
private DPRectangle rectangle;
private String stringRepresentation;
private StructureType type;
private String fontName, fontFamily;
private float fontSize, fontSizeInPt, widthOfSpace, roatation;
private boolean isBold, isItalic,isSpaceChar;
private int multiColumnIndex;
private DPCell lineCell;

	public PDFCharacter(DPRectangle rectangle,
			String stringRepresentation, StructureType type, String fontName,
			String fontFamily, float fontSize, float fontSizeInPt,
			float widthOfSpace, boolean isBold, boolean isItalic) {
		this.id=Structure_Id.getInstance().getNext();
		this.rectangle = rectangle;
		this.stringRepresentation = stringRepresentation;
		this.type = type;
		this.fontName = fontName;
		this.fontFamily = fontFamily;
		this.fontSize = fontSize;
		this.fontSizeInPt = fontSizeInPt;
		this.widthOfSpace = widthOfSpace;
		this.isBold = isBold;
		this.isItalic = isItalic;
		this.multiColumnIndex =0;
	}

	public PDFCharacter(DPRectangle rectangle,
			String stringRepresentation, StructureType type, String fontName,
			String fontFamily, float fontSize, float fontSizeInPt,
			float widthOfSpace, boolean isBold, boolean isItalic, float rotation) {
		this.id=Structure_Id.getInstance().getNext();
		
		this.rectangle = rectangle;
		this.stringRepresentation = stringRepresentation;
		this.type = type;
		this.fontName = fontName;
		this.fontFamily = fontFamily;
		this.fontSize = fontSize;
		this.fontSizeInPt = fontSizeInPt;
		this.widthOfSpace = widthOfSpace;
		this.isBold = isBold;
		this.isItalic = isItalic;
		this.multiColumnIndex =0;
		this.roatation =rotation;
	}
	
	public boolean isSpaceChar() {
		return isSpaceChar;
	}

	public void setSpaceChar(boolean isSpaceChar) {
		this.isSpaceChar = isSpaceChar;
	}

	@Override
	public String toString() {
		return "x=" + rectangle.getX() + ", y=" + rectangle.getY() + ", stringRepresentation=" + stringRepresentation+"\n";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((rectangle == null) ? 0 : rectangle.hashCode());
		result = prime * result + ((stringRepresentation == null) ? 0
				: stringRepresentation.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		PDFCharacter other = (PDFCharacter) obj;
		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		if (stringRepresentation == null) {
			if (other.stringRepresentation != null)
				return false;
		} else if (!stringRepresentation.equals(other.stringRepresentation))
			return false;
		return true;
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public DPRectangle getRectangle(){
		return rectangle;
	}

	public StructureType getType() {
		return type;
	}

	public String getFontName() {
		return fontName;
	}

	public String getFontFamily() {
		return fontFamily;
	}

	public float getFontSize() {
		return fontSize;
	}

	public float getFontSizeInPt() {
		return fontSizeInPt;
	}

	public float getWidthOfSpace() {
		return widthOfSpace;
	}

	public boolean isBold() {
		return isBold;
	}

	public boolean isItalic() {
		return isItalic;
	}

	public int getMultiColumnIndex() {
		return multiColumnIndex;
	}

	public void setMultiColumnIndex(int multiColumnIndex) {
		this.multiColumnIndex = multiColumnIndex;
	}

	@Override
	public long getId() {
		// TODO Auto-generated method stub
		return id;
	}

	public float getRoatation() {
		return roatation;
	}

	public void setRoatation(float roatation) {
		this.roatation = roatation;
	}

	public void setStringRepresentation(String stringRepresentation) {
		this.stringRepresentation = stringRepresentation;
	}
	
	public void setLineCell(DPCell lineCell) {
		this.lineCell=lineCell;
	}

	public DPCell getLineCell() {
		return lineCell;
	}
	
}
