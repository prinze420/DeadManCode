package com.pdf.parser.base;

import com.pdf.parser.Structure;

/**
 * This represents the basic constructs of the PDF. E.g. character, word, etc.
 * These are single page structures. They do not span across pages.
 * @author Shishir.Mane
 * @see 2.1.1
 *
 */
public interface BasicStructure extends Structure {
	
	public DPRectangle getRectangle();
	
	public int hashCode();
	
	public boolean equals(Object o);
	
}
