/**
 * 
 */
package com.pdf.parser.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.Structure;
import com.pdf.parser.StructureType;
import com.pdf.parser.utils.Structure_Id;



/**
 * @author BB0e1165
 *
 */
public class DPCell implements BasicStructure ,Serializable  {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int row,column;
	private long id;
	private DPRectangle  rectangle;
	private String fontName,text="";

	private List<BasicStructure> paraList;
	private StructureType type;
	private float widthOfSpace=-1;

	private Object excelCellObj=null;
	private String dataType="";
	private int multiColumnIndex;
	
	private List<PDFWord> lineCellDataList=new ArrayList<PDFWord>();
	private List<Structure> cellKVP=new ArrayList<Structure>();
	
	
	public List<Structure> getCellKVP() {
		return cellKVP;
	}
	
	public void setCellKVP(List<Structure> cellKVP) {
		this.cellKVP = cellKVP;
	}


	public DPCell(int id, int row, int column, DPRectangle  rectangle, String fontName, String text, List<BasicStructure> paraList,float widthOfSpace) {
		super();
		this.id=Structure_Id.getInstance().getNext();

		this.row = row;
		this.column = column;
		this.rectangle=rectangle;
		this.widthOfSpace=widthOfSpace;
		this.fontName = fontName;
		this.text = text;
		this.paraList = paraList;
		this.type = StructureType.TABLE_CELL;
	}


	public DPCell(long l, int row, int column, float x,float y,float width,float height,int pageNo, String fontName, String text,List<BasicStructure> paraList,float widthOfSpace){

		super();
		this.id=Structure_Id.getInstance().getNext();
		this.row = row;
		this.column = column;

		this.rectangle=new DPRectangle(x, y, width, height, pageNo);
		this.fontName = fontName;
		this.text = text;
		this.paraList = paraList;
		this.widthOfSpace=widthOfSpace;
		this.type = StructureType.TABLE_CELL;
	}


	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}



	public long getId() {
		return id;
	}

	public List<BasicStructure> getParaList() {
		return paraList;
	}

	public int getRow() {
		return row;
	}

	public void setRow(int row) {
		this.row = row;
	}

	public int getColumn() {
		return column;
	}

	public void setColumn(int column) {
		this.column = column;
	}

	public void setParaList(List<BasicStructure> paraList) {
		this.paraList = paraList;
	}
	
	
	public void setLineCellDataList(List<PDFWord> lineCellDataList) {
		this.lineCellDataList = lineCellDataList;
	}
	
	public List<PDFWord> getLineCellDataList(){
		
		return lineCellDataList; 
	}
	
	public String getFontName() {
		return fontName;
	}



	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		//		result = prime * result
		//				+ ((rectangle == null) ? 0 : rectangle.hashCode());

		result = prime * result + ((getStringRepresentation() == null) ? 0
				: getStringRepresentation().hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;

		DPCell other = (DPCell) obj;

		if (rectangle == null) {
			if (other.rectangle != null)
				return false;
		} else if (!rectangle.equals(other.rectangle))
			return false;
		
		if(this.id!=((DPCell)obj).getId()){
			return false;
		}

		//		if (getText() == null) {
		//			if (other.getText() != null)
		//				return false;
		//		} else if (!getText().equals(other.getText()))
		//			return false;
		for(BasicStructure struct: ((DPCell) obj).getParaList()){
			if(!getParaList().contains(struct)){
				return false;
			}
		}
				return true;
	}

	@Override
	public String toString() 
	{
//		if(paraList==null)
//			return null;
//		String content=+getRow()+"/"+getColumn()+":";
//		for(BasicStructure para:paraList)
//		{
//			content=content+"== "+para.getStringRepresentation();
//		}
//		return content.trim();
		return text;
	}



	@Override
	public StructureType getType() {
		return type;
	}



	@Override
	public String getStringRepresentation() {
		// TODO Auto-generated method stub
		return text;
	}



	@Override
	public float getWidthOfSpace() {
		// TODO Auto-generated method stub
		return widthOfSpace;
	}



	@Override 
	public DPRectangle getRectangle() {
		// TODO Auto-generated method stub
		return rectangle;
	}

	public void setRectangle(DPRectangle rectangle) {
		this.rectangle = rectangle;
	}



	public void setStringRepresentation(String string) {
		// TODO Auto-generated method stub
		this.text = string;
	}

	public Object getExcelCellObj() {
		return excelCellObj;
	}

	public void setExcelCellObj(Object excelCell) {
		this.excelCellObj = excelCell;
	}
	public int getMultiColumnIndex() {
		return multiColumnIndex;
	}

	public void setMultiColumnIndex(int multiColumnIndex) {
		this.multiColumnIndex = multiColumnIndex;
	}

	
	
}
