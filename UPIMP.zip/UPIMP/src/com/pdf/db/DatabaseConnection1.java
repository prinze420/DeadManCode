/*package com.pdf.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;


import com.pdf.parser.base.PDFSegment;
//import com.pdf.parser.base.Rectangle;
//import com.pdf.parser.w8form.W8ResultBean;



//import com.rage.db.DatabaseConnection;
//import com.rage.db.TextComment;
//import com.rage.siapp.doc.identifier.DTQResult;

public class DatabaseConnection1 {

	
	 * private static Date START_DATE; private static Date END_DATE;
	 

	private static String LSCONNECTION_DRIVER_NAME = "db.connection.driver100";
	private static String LSCONNECTION_STRING_PROPERTY = "db.connection.string100";
	private static String LSCONNECTION_USERNAME = "db.connection.username100";
	private static String LSCONNECTION_PASSWORD = "db.connection.password100";

	private static String LSCONNECTION_DRIVER_NAME2 = "db.connection.driver103";
	private static String LSCONNECTION_STRING_PROPERTY2 = "db.connection.string103";
	private static String LSCONNECTION_USERNAME2 = "db.connection.username103";
	private static String LSCONNECTION_PASSWORD2 = "db.connection.password103";

	// private static String LSCONNECTION_DRIVER_NAME =
	// "ls.db.connection.driver";
	// private static String LSCONNECTION_STRING_PROPERTY =
	// "ls.db.connection.string";
	// private static String LSCONNECTION_USERNAME = "db_user_name";
	// private static String LSCONNECTION_PASSWORD = "db_password";

	*//**
	 * Get LS database connection
	 * 
	 * @return
	 *//*


	public Connection getConnection() {
		Connection conn = null;

		String driver = Configuration.getProperty(LSCONNECTION_DRIVER_NAME);
		String connectionString = Configuration.getProperty(LSCONNECTION_STRING_PROPERTY);
		String username = Configuration.getProperty(LSCONNECTION_USERNAME);
		String password = Configuration.getProperty(LSCONNECTION_PASSWORD);

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(connectionString, username, password);
			System.out.println("Conn Done");
		} catch (Exception e) {
			System.err.println("ERROR IN GETTING THE LS CONNECTION : " + e.getMessage());
			System.err.println("\tDRIVER = " + driver);
			System.err.println("\tCONNECTION STRING = " + connectionString);
			System.err.println("\tUSERNAME = " + username);
			System.err.println("\tPASSWORD = " + password);
			e.printStackTrace();
		}
		return conn;
	}

	public Connection getConnection2() {
		Connection conn = null;

		String driver = Configuration.getProperty(LSCONNECTION_DRIVER_NAME2);
		String connectionString = Configuration.getProperty(LSCONNECTION_STRING_PROPERTY2);
		String username = Configuration.getProperty(LSCONNECTION_USERNAME2);
		String password = Configuration.getProperty(LSCONNECTION_PASSWORD2);

		try {
			Class.forName(driver);
			conn = DriverManager.getConnection(connectionString, username, password);
			System.out.println("Conn Done");
		} catch (Exception e) {
			System.err.println("ERROR IN GETTING THE LS CONNECTION : " + e.getMessage());
			System.err.println("\tDRIVER = " + driver);
			System.err.println("\tCONNECTION STRING = " + connectionString);
			System.err.println("\tUSERNAME = " + username);
			System.err.println("\tPASSWORD = " + password);
			e.printStackTrace();
		}
		return conn;
	}


	//	public void insertData(List<W8ResultBean> W8FormResult, Connection con, int FILING_ID) {
	//		// FILING_ID PO_ID PO_SECTION PO_INDEX_ORDER PO_AS_REP_LABEL
	//		// PO_AS_REP_VAL1 PO_VAL1 PO_AS_REP_VAL2 PO_VAL2
	//		// PO_CRUD_ACCOUNT
	//		// CREATE_DATE 
	//		// PAGE_NO PO_YCOORDINATES
	//
	//		int PO_IDval = 0;
	//		String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
	//		PreparedStatement pst = null;
	//		try {
	//			pst = con.prepareStatement(sqlIdentifier);
	//		} catch (SQLException e1) {
	//			// TODO Auto-generated catch block
	//			e1.printStackTrace();
	//		}
	//
	//		String query2 = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"
	//				+ "PO_AS_REP_VAL1,PO_VAL1,PO_AS_REP_VAL2,PO_VAL2,PO_CRUD_ACCOUNT,CREATE_DATE,"
	//				+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	//		int PO_INDEX_ORDER = 0;
	//		PreparedStatement statement = null;
	//		try {
	//			statement = con.prepareStatement(query2);
	//
	//			for (W8ResultBean ruleReslt : W8FormResult) {
	//				synchronized (this) {
	//					ResultSet rs = pst.executeQuery();
	//					if (rs != null) {
	//						if (rs.next())
	//							PO_IDval = rs.getInt(1);
	//					}
	//				}
	//				PO_INDEX_ORDER = PO_INDEX_ORDER + 10;
	//
	//	
	//				statement.setInt(1, FILING_ID);
	//				statement.setInt(2, PO_IDval); // PO_IDval
	//				statement.setString(3, "WF");
	//				statement.setInt(4, (PO_INDEX_ORDER));
	//				statement.setString(5, ruleReslt.getLabel());// PO_AS_REP_LABEL
	//
	//				statement.setString(6, ruleReslt.getExtractedText());// PO_AS_REP_VAL1
	//				statement.setString(7, ruleReslt.getExtractedText());// PO_VAL1
	//				
	//				statement.setString(8, ruleReslt.getIsCheckBoxSelect());
	//				statement.setString(9, ruleReslt.getIsCheckBoxSelect());
	//				
	//				statement.setString(10, "C");
	//				statement.setTimestamp(11, new Timestamp(System.currentTimeMillis()));// CREATE_DATE
	//
	//				statement.setFloat(12, ruleReslt.getPAGE_NO());
	//				statement.setFloat(13, ruleReslt.getPO_YCOORDINATES());
	//
	//				statement.addBatch();
	//
	//				// int status = statement.executeUpdate();
	//				// System.out.println("status :" + status);
	//
	//			}
	//			statement.executeBatch();
	//			System.out.println(FILING_ID+":: ****  Data Inserted ***");
	//		} catch (Exception e) {
	//			System.out.println(e.getMessage());
	//			e.printStackTrace();
	//		} finally {
	//			try {
	//				if (statement != null)
	//					statement.close();
	//				close(con);
	//			} catch (Exception e) {
	//				e.printStackTrace();
	//			}
	//		}
	//
	//	}

	public void insertDataNew(List<W8ResultBean> W8FormResult, Connection con, int FILING_ID) {
		// FILING_ID PO_ID PO_SECTION PO_INDEX_ORDER PO_AS_REP_LABEL
		// PO_AS_REP_VAL1 PO_VAL1 PO_AS_REP_VAL2 PO_VAL2
		// PO_CRUD_ACCOUNT
		// CREATE_DATE 
		// PAGE_NO PO_YCOORDINATES
		//String	expectedSeq="1,2,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,6,7,8,9a,9a,9b,9b,10,14a,14a,14b,14c,15,26,26,29a 29b 29c 29d 29e,29f,44,44,44,44";
		//String	expectedSeq="1,2,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,4.10,4.11,5.1,5.2,5.3,5.4,5.5,5.6,6,7,8,9.1,9.2,9.3,9.4,10,14.1,14.2,14.3,14.4,15,26,26,29.1,29.2,44.1,44.2,44.3,44.4";

		//String[] PO_INDEX_ORDER = expectedSeq.split("\\,");

		int PO_IDval = 0,order=10;
		String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sqlIdentifier);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String query2 = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				+ "PO_AS_REP_VAL1,PO_VAL1,"//2
				+ "PO_AS_REP_VAL2,PO_VAL2,PO_AS_REP_VAL3,PO_VAL3,PO_AS_REP_VAL4,PO_VAL4,PO_AS_REP_VAL5,PO_VAL5,PO_AS_REP_VAL6,PO_VAL6,"//10

				+ "PO_CRUD_ACCOUNT,CREATE_DATE,"//2
				+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";//2
				PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(query2);

			for (W8ResultBean ruleReslt : W8FormResult) {
				synchronized (this) {
					ResultSet rs = pst.executeQuery();
					if (rs != null) {
						if (rs.next())
							PO_IDval = rs.getInt(1);
					}
				}
//				if(ruleReslt.getKeyword().contains("Nonreporting IGA FFI")){
//					System.out.println("");
//				}

				statement.setInt(1, FILING_ID);
				statement.setInt(2, PO_IDval); // PO_IDval
				statement.setString(3, "WF");
				statement.setFloat(4,Float.valueOf(order));//PO_INDEX_ORDER
				order=order+10;
				statement.setString(5, ruleReslt.getLabel());// PO_AS_REP_LABEL

				statement.setString(6, ruleReslt.getExtractedText());// PO_AS_REP_VAL1
				statement.setString(7, ruleReslt.getExtractedText());// PO_VAL1

				//insert based on type
				if(ruleReslt.getType().contains("keyValue|")){
					List<String> list = ruleReslt.getFilingTheBlanks();
					int cnt=0;
					if(list.size()>cnt){
						statement.setString(8, list.get(cnt));//PO_AS_REP_VAL2
						statement.setString(9, list.get(cnt));//PO_VAL2
						cnt++;
					}else{
						statement.setString(8, "");//PO_AS_REP_VAL2
						statement.setString(9, "");//PO_VAL2
					}

					if(list.size()>cnt){
						statement.setString(10, list.get(cnt));//PO_AS_REP_VAL3
						statement.setString(11, list.get(cnt));//PO_VAL3
						cnt++;
						}else{
							statement.setString(10, "");//PO_AS_REP_VAL3
							statement.setString(11, "");//PO_VAL3
						}

					if(list.size()>cnt){
						statement.setString(12, list.get(cnt));//PO_AS_REP_VAL4
						statement.setString(13, list.get(cnt));//PO_VAL4
						cnt++;
						}else{
							statement.setString(12, "");//PO_AS_REP_VAL4
							statement.setString(13, "");//PO_VAL4
						}
					if(list.size()>cnt){
						statement.setString(14, list.get(cnt));//PO_AS_REP_VAL5
						statement.setString(15, list.get(cnt));//PO_VAL5
						cnt++;
						}else{
							statement.setString(14, "");//PO_AS_REP_VAL5
							statement.setString(15, "");//PO_VAL5
						}
					if(list.size()>cnt){
						statement.setString(16, list.get(cnt));//PO_AS_REP_VAL6
						statement.setString(17, list.get(cnt));//PO_VAL6
						cnt++;
						}else{
							statement.setString(16, "");//PO_AS_REP_VAL6
							statement.setString(17, "");//PO_VAL6
						}


				}else if(ruleReslt.getType().contains("overlap|")){
					String[] list = ruleReslt.getExtractedText().split("\\#");
					int cnt=0;
					if(list.length>cnt){
						statement.setString(8, list[cnt].trim());//PO_AS_REP_VAL2
						statement.setString(9, list[cnt].trim());//PO_VAL2
						cnt++;
					}else{
						statement.setString(8, "");//PO_AS_REP_VAL2
						statement.setString(9, "");//PO_VAL2
					}

					if(list.length>cnt){
						statement.setString(10, list[cnt].trim());//PO_AS_REP_VAL3
						statement.setString(11, list[cnt].trim());//PO_VAL3
						cnt++;
						}else{
							statement.setString(10, "");//PO_AS_REP_VAL3
							statement.setString(11, "");//PO_VAL3
						}

					if(list.length>cnt){
						statement.setString(12, list[cnt].trim());//PO_AS_REP_VAL4
						statement.setString(13, list[cnt].trim());//PO_VAL4
						cnt++;
						}else{
							statement.setString(12, "");//PO_AS_REP_VAL4
							statement.setString(13, "");//PO_VAL4
						}
					if(list.length>cnt){
						statement.setString(14, list[cnt].trim());//PO_AS_REP_VAL5
						statement.setString(15, list[cnt].trim());//PO_VAL5
						cnt++;
						}else{
							statement.setString(14, "");//PO_AS_REP_VAL5
							statement.setString(15, "");//PO_VAL5
						}
					if(list.length>cnt){
						statement.setString(16, list[cnt].trim());//PO_AS_REP_VAL6
						statement.setString(17, list[cnt].trim());//PO_VAL6
						cnt++;
						}else{
							statement.setString(16, "");//PO_AS_REP_VAL6
							statement.setString(17, "");//PO_VAL6
						}

				}else if(ruleReslt.getKeyword().equalsIgnoreCase("Exempt Retirement Plans")){

					String[] list = ruleReslt.getIsCheckBoxSelect().replaceAll("Checkbox Selected:", "").split("\\#");
					int cnt=0;
					if(list.length>cnt){
						statement.setString(8, list[cnt].trim());//PO_AS_REP_VAL2
						statement.setString(9, list[cnt].trim());//PO_VAL2
						cnt++;
					}else{
						statement.setString(8, "");//PO_AS_REP_VAL2
						statement.setString(9, "");//PO_VAL2
					}

					if(list.length>cnt){
						statement.setString(10, list[cnt].trim());//PO_AS_REP_VAL3
						statement.setString(11, list[cnt].trim());//PO_VAL3
						cnt++;
						}else{
							statement.setString(10, "");//PO_AS_REP_VAL3
							statement.setString(11, "");//PO_VAL3
						}

					if(list.length>cnt){
						statement.setString(12, list[cnt].trim());//PO_AS_REP_VAL4
						statement.setString(13, list[cnt].trim());//PO_VAL4
						cnt++;
						}else{
							statement.setString(12, "");//PO_AS_REP_VAL4
							statement.setString(13, "");//PO_VAL4
						}
					if(list.length>cnt){
						statement.setString(14, list[cnt].trim());//PO_AS_REP_VAL5
						statement.setString(15, list[cnt].trim());//PO_VAL5
						cnt++;
						}else{
							statement.setString(14, "");//PO_AS_REP_VAL5
							statement.setString(15, "");//PO_VAL5
						}
					if(list.length>cnt){
						statement.setString(16, list[cnt].trim());//PO_AS_REP_VAL6
						statement.setString(17, list[cnt].trim());//PO_VAL6
						cnt++;
						}else{
							statement.setString(16, "");//PO_AS_REP_VAL6
							statement.setString(17, "");//PO_VAL6
						}
				}else if(ruleReslt.getKeyword().equalsIgnoreCase("Print Name")||ruleReslt.getKeyword().equalsIgnoreCase("-DD-YYYY)")){

					String[] list = ruleReslt.getExtractedText().split("\\##");
					int cnt=0;
					if(list.length>cnt){
						statement.setString(8, list[cnt].trim());//PO_AS_REP_VAL2
						statement.setString(9, list[cnt].trim());//PO_VAL2
						cnt++;
					}else{
						statement.setString(8, "");//PO_AS_REP_VAL2
						statement.setString(9, "");//PO_VAL2
					}

					if(list.length>cnt){
						statement.setString(10, list[cnt].trim());//PO_AS_REP_VAL3
						statement.setString(11, list[cnt].trim());//PO_VAL3
						cnt++;
						}else{
							statement.setString(10, "");//PO_AS_REP_VAL3
							statement.setString(11, "");//PO_VAL3
						}

					if(list.length>cnt){
						statement.setString(12, list[cnt].trim());//PO_AS_REP_VAL4
						statement.setString(13, list[cnt].trim());//PO_VAL4
						cnt++;
						}else{
							statement.setString(12, "");//PO_AS_REP_VAL4
							statement.setString(13, "");//PO_VAL4
						}
					if(list.length>cnt){
						statement.setString(14, list[cnt].trim());//PO_AS_REP_VAL5
						statement.setString(15, list[cnt].trim());//PO_VAL5
						cnt++;
						}else{
							statement.setString(14, "");//PO_AS_REP_VAL5
							statement.setString(15, "");//PO_VAL5
						}
					if(list.length>cnt){
						statement.setString(16, list[cnt].trim());//PO_AS_REP_VAL6
						statement.setString(17, list[cnt].trim());//PO_VAL6
						cnt++;
						}else{
							statement.setString(16, "");//PO_AS_REP_VAL6
							statement.setString(17, "");//PO_VAL6
						}
				}else{

					statement.setString(8, ruleReslt.getIsCheckBoxSelect());//PO_AS_REP_VAL2
					statement.setString(9, ruleReslt.getIsCheckBoxSelect());//PO_VAL2

					statement.setString(10, "");//PO_AS_REP_VAL3
					statement.setString(11, "");//PO_VAL3

					statement.setString(12, "");//PO_AS_REP_VAL4
					statement.setString(13, "");//PO_VAL4

					statement.setString(14, "");//PO_AS_REP_VAL5
					statement.setString(15, "");//PO_VAL5

					statement.setString(16, "");//PO_AS_REP_VAL6
					statement.setString(17, "");//PO_VAL6


				}

				statement.setString(18, "C");
				statement.setTimestamp(19, new Timestamp(System.currentTimeMillis()));// CREATE_DATE

				statement.setFloat(20, ruleReslt.getPAGE_NO());
				statement.setFloat(21, ruleReslt.getPO_YCOORDINATES());

				statement.addBatch();

//				 int status = statement.executeUpdate();
//				 System.out.println("getKeyword :" + ruleReslt.getKeyword());
//				 System.out.println("status :" + status);

			}
			statement.executeBatch();
			System.out.println(FILING_ID+":: ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				close(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	 

	public void insertFormData(List<W8ResultBean> W8FormResult, Connection con, int FILING_ID) {

		int PO_IDval = 0,order=10;
		String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sqlIdentifier);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String query2 = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				+ "PO_AS_REP_VAL1,PO_VAL1,"//2
				+ "PO_AS_REP_VAL2,PO_VAL2,PO_AS_REP_VAL3,PO_VAL3,PO_AS_REP_VAL4,PO_VAL4,PO_AS_REP_VAL5,PO_VAL5,PO_AS_REP_VAL6,PO_VAL6,"//10

				+ "PO_CRUD_ACCOUNT,CREATE_DATE,"//2
				+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";//2
		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(query2);

			for (W8ResultBean ruleReslt : W8FormResult) {

				synchronized (this) {
					ResultSet rs = pst.executeQuery();
					if (rs != null) {
						if (rs.next())
							PO_IDval = rs.getInt(1);
					}
				}
				String query3 = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
						+ "PO_AS_REP_VAL1,PO_VAL1,"//2
						+ "PO_AS_REP_VAL2,PO_VAL2,PO_AS_REP_VAL3,PO_VAL3,PO_AS_REP_VAL4,PO_VAL4,PO_AS_REP_VAL5,PO_VAL5,PO_AS_REP_VAL6,PO_VAL6,"//10

						+ "PO_CRUD_ACCOUNT,CREATE_DATE,"//2
						+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";//2


				statement.setInt(1, FILING_ID);
				statement.setInt(2, PO_IDval); // PO_IDval
				statement.setString(3, "InvoiceBody");
				statement.setFloat(4,Float.valueOf(order));//PO_INDEX_ORDER
				order=order+10;
				statement.setString(5, ruleReslt.getLabel());// PO_AS_REP_LABEL

				statement.setString(6, ruleReslt.getExtractedText());// PO_AS_REP_VAL1
				statement.setString(7, ruleReslt.getExtractedText());// PO_VAL1


				if(ruleReslt.getExtractedText().contains("##")){
					String[] list = ruleReslt.getExtractedText().split("\\##");
					int cnt=0;
					if(list.length>cnt){
						statement.setString(8, list[cnt].trim());//PO_AS_REP_VAL2
						statement.setString(9, list[cnt].trim());//PO_VAL2
						cnt++;
					}else{
						statement.setString(8, "");//PO_AS_REP_VAL2
						statement.setString(9, "");//PO_VAL2
					}

					if(list.length>cnt){
						statement.setString(10, list[cnt].trim());//PO_AS_REP_VAL3
						statement.setString(11, list[cnt].trim());//PO_VAL3
						cnt++;
					}else{
						statement.setString(10, "");//PO_AS_REP_VAL3
						statement.setString(11, "");//PO_VAL3
					}

					if(list.length>cnt){
						statement.setString(12, list[cnt].trim());//PO_AS_REP_VAL4
						statement.setString(13, list[cnt].trim());//PO_VAL4
						cnt++;
					}else{
						statement.setString(12, "");//PO_AS_REP_VAL4
						statement.setString(13, "");//PO_VAL4
					}
					if(list.length>cnt){
						statement.setString(14, list[cnt].trim());//PO_AS_REP_VAL5
						statement.setString(15, list[cnt].trim());//PO_VAL5
						cnt++;
					}else{
						statement.setString(14, "");//PO_AS_REP_VAL5
						statement.setString(15, "");//PO_VAL5
					}
					if(list.length>cnt){
						statement.setString(16, list[cnt].trim());//PO_AS_REP_VAL6
						statement.setString(17, list[cnt].trim());//PO_VAL6
						cnt++;
					}else{
						statement.setString(16, "");//PO_AS_REP_VAL6
						statement.setString(17, "");//PO_VAL6
					}

				}else{

					statement.setString(8, ruleReslt.getIsCheckBoxSelect());//PO_AS_REP_VAL2
					statement.setString(9, ruleReslt.getIsCheckBoxSelect());//PO_VAL2

					statement.setString(10, "");//PO_AS_REP_VAL3
					statement.setString(11, "");//PO_VAL3

					statement.setString(12, "");//PO_AS_REP_VAL4
					statement.setString(13, "");//PO_VAL4

					statement.setString(14, "");//PO_AS_REP_VAL5
					statement.setString(15, "");//PO_VAL5

					statement.setString(16, "");//PO_AS_REP_VAL6
					statement.setString(17, "");//PO_VAL6


				}

				statement.setString(18, "C");
				statement.setTimestamp(19, new Timestamp(System.currentTimeMillis()));// CREATE_DATE

				statement.setFloat(20, ruleReslt.getPAGE_NO());
				statement.setFloat(21, ruleReslt.getPO_YCOORDINATES());

				statement.addBatch();

				//				 int status = statement.executeUpdate();
				//				 System.out.println("getKeyword :" + ruleReslt.getKeyword());
				//				 System.out.println("status :" + status);
			}
			statement.executeBatch();
			System.out.println(FILING_ID+":: ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				close(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}


	public void insertFormDataGeneric(List<W8ResultBean> W8FormResult, Connection con, int FILING_ID) {

		int PO_IDval = 0,order=10;
		String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sqlIdentifier);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//		String query2 = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
		//				+ "PO_AS_REP_VAL1,PO_VAL1,"//2
		//				+ "PO_AS_REP_VAL2,PO_VAL2,PO_AS_REP_VAL3,PO_VAL3,PO_AS_REP_VAL4,PO_VAL4,PO_AS_REP_VAL5,PO_VAL5,PO_AS_REP_VAL6,PO_VAL6,"//10
		//				
		//				+ "PO_CRUD_ACCOUNT,CREATE_DATE,"//2
		//				+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";//2
		PreparedStatement statement = null;
		try {

			for (W8ResultBean ruleReslt : W8FormResult) {

				synchronized (this) {
					ResultSet rs = pst.executeQuery();
					if (rs != null) {
						if (rs.next())
							PO_IDval = rs.getInt(1);
					}
				}
				String dynamicquery=getQuery(ruleReslt);
				statement = con.prepareStatement(dynamicquery);
				//				insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				//						+ "PO_CRUD_ACCOUNT,CREATE_DATE,PAGE_NO,PO_YCOORDINATES

				statement.setInt(1, FILING_ID);
				statement.setInt(2, PO_IDval); // PO_IDval
				statement.setString(3, "InvoiceBody");//PO_SECTION
				statement.setFloat(4,Float.valueOf(order));//PO_INDEX_ORDER
				order=order+10;
				statement.setString(5, ruleReslt.getLabel());// PO_AS_REP_LABEL

				statement.setString(6, "C");
				statement.setTimestamp(7, new Timestamp(System.currentTimeMillis()));// CREATE_DATE

				statement.setFloat(8, ruleReslt.getPAGE_NO());
				statement.setFloat(9, ruleReslt.getPO_YCOORDINATES());
				int cnt=10;
				for(PDFSegment seg:ruleReslt.getExtractionSegments()){
					statement.setString(cnt++, seg.getStringRepresentation());//PO_AS_REP_VAL i
					statement.setString(cnt++, seg.getStringRepresentation()); //PO_VAL i
				}
				statement.executeUpdate();
				//				statement.addBatch();
			}
			//				 int status = statement.executeUpdate();
			System.out.println(FILING_ID+":: ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				close(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}

	private String getQuery(W8ResultBean ruleReslt) {
		String values="";
		String qMarks="";
		for(int i=1;i<=ruleReslt.getExtractionSegments().size();i++){
			values=values+",PO_AS_REP_VAL"+i+",PO_VAL"+i+"";
			qMarks=qMarks+",?,?";
		}
		String query = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				+ "PO_CRUD_ACCOUNT,CREATE_DATE,PAGE_NO,PO_YCOORDINATES,LS_PO_ID,UPLOAD_ID,WQ_ID"+values
				+") values(?,?,?,?,?,?,?,?,?,?,?,?"+qMarks+")";

		return query;
	}


	private static void close(Connection conn) {
		try {
			if (conn != null)
				conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	}

	private void readData(Connection conn) {

		String query ="select FILING_ID, PO_ID, PO_SECTION, PO_INDEX_ORDER, PO_AS_REP_LABEL, PO_AS_REP_VAL1, PO_VAL1, PO_AS_REP_VAL2, PO_VAL2,PO_CRUD_ACCOUNT,CREATE_DATE,PAGE_NO,PO_YCOORDINATES from parser_output where FILING_ID= 25808"; 

		String query1 = "select * from parser_output where FILING_ID= 25495 order by PO_ID";
		PreparedStatement ps;
		try {
			ps = conn.prepareStatement(query);

			ps.executeQuery();
			ResultSet resultset = ps.getResultSet();
			ResultSetMetaData rmd = resultset.getMetaData();
			int columnSize = rmd.getColumnCount();
			int cnt = 0;
			System.out.println(": \t FILING_ID \t PO_ID \t PAGE_NO \t PO_YCOORDINATES \t PO_AS_REP_LABEL");
			while (resultset.next()) {

				// PO_AS_REP_LABEL,PO_AS_REP_VAL1, PO_VAL1,"
				// + "FILING_ID, PO_ID, PAGE_NO, PO_YCOORDINATES"
				int a = resultset.getInt("FILING_ID");
				int b = resultset.getInt("PO_ID");
				int c = resultset.getInt("PAGE_NO");
				float d = resultset.getFloat("PO_YCOORDINATES");

				String e = resultset.getString("PO_AS_REP_LABEL");
				// String
				// f=resultset.getString("PO_AS_REP_VAL1").replaceAll("\n", "
				// ");

				System.out.println(cnt++ + ": \t" + a + "\t" + b + "\t" + c + "\t" + d + "\t" + e + "\t");

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void deleteData(Connection con,int id) {

		String query = "delete from parser_output where FILING_ID = "+id;
		PreparedStatement statement2 = null;
		try {
			statement2 = con.prepareStatement(query);
			statement2.executeQuery();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (statement2 != null)
					statement2.close();
				close(con);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		System.out.println(query.substring(query.indexOf("=")+1, query.length())+" Data deleted successfully");
	}


	public void insertFormData2(List<W8ResultBean> W8FormResult, Connection con, int FILING_ID,int doc_Id,int wqID) {
		//Connection con2=getConnection2();

		int PO_IDval = 0,order=10;
		String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sqlIdentifier);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		String dynamicquery = "insert into PARSER_OUTPUT (FILING_ID,PO_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				+ "PO_CRUD_ACCOUNT,CREATE_DATE,PAGE_NO,PO_YCOORDINATES,LS_PO_ID,UPLOAD_ID,WQ_ID,PO_AS_REP_VAL1,PO_VAL1) "
				+ "values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";

		PreparedStatement statement = null;
		try {
			//String dynamicquery="";
			statement = con.prepareStatement(dynamicquery);
			for (W8ResultBean ruleReslt : W8FormResult) {
				//	System.out.println(ruleReslt.getResultRule().getRowID());

				if(ruleReslt.getResultRule().getType().toLowerCase().contains("checkbox")){
					if(ruleReslt.getIsCheckBoxSelect().contains(": No")){
						continue;
					}
				}

				synchronized (this) {
					ResultSet rs = pst.executeQuery();
					if (rs != null) {
						if (rs.next())
							PO_IDval = rs.getInt(1);
					}
				}
				insertCoOrdData(ruleReslt,con, FILING_ID, ruleReslt.getLabel(), PO_IDval);//PO_CORD_HIGHLIGHT_DETAILS insertion

				//				if(dynamicquery.isEmpty()){
				//				 	dynamicquery=getQuery(ruleReslt);
				//					statement = con.prepareStatement(dynamicquery);
				//				}
				//				
				statement.setInt(1, FILING_ID);//FILING_ID
				statement.setInt(2, PO_IDval); // PO_IDval

				if(ruleReslt.getResultRule().getType().toLowerCase().contains("checkbox")){
					statement.setString(3,  ruleReslt.getLabel().split("##")[0].trim());//PO_SECTION
				}else{
					statement.setString(3,  ruleReslt.getLabel());//PO_SECTION
				}
	
				statement.setFloat(4,Float.valueOf(order));//PO_INDEX_ORDER
				order=order+10;

				if(ruleReslt.getResultRule().getType().toLowerCase().contains("checkbox")){
					statement.setString(5,  ruleReslt.getLabel().split("##")[1].trim());// PO_AS_REP_LABEL
				}else{
					statement.setString(5,  ruleReslt.getKeyword());// PO_AS_REP_LABEL
				}
				
				statement.setString(6, "C");//PO_CRUD_ACCOUNT
				statement.setTimestamp(7, new Timestamp(System.currentTimeMillis()));// CREATE_DATE

				statement.setFloat(8, ruleReslt.getPAGE_NO());//PAGE_NO
				statement.setFloat(9, ruleReslt.getPO_YCOORDINATES());//PO_YCOORDINATES
				statement.setFloat(10, PO_IDval);//LS_PO_ID
				statement.setFloat(11, doc_Id);//				UPLOAD_ID
				statement.setFloat(12, wqID);//				wq_id
				if(!ruleReslt.getExtractionSegments().isEmpty()){
					if(ruleReslt.getResultRule().getType().toLowerCase().contains("checkbox")){
						statement.setString(13, ruleReslt.getKeyword());//PO_AS_REP_VAL i
						statement.setString(14, ruleReslt.getKeyword()); //PO_VAL i
					}else{
						statement.setString(13, ruleReslt.getExtractionSegments().get(0).getStringRepresentation());//PO_AS_REP_VAL i
						statement.setString(14, ruleReslt.getExtractionSegments().get(0).getStringRepresentation()); //PO_VAL i
							
					}
				}else{
					statement.setString(13, "");//PO_AS_REP_VAL i
					statement.setString(14, ""); //PO_VAL i

				}

				//				int cnt=13;
				//				for(PDFSegment seg:ruleReslt.getExtractionSegments()){
				//					statement.setString(cnt++, seg.getStringRepresentation());//PO_AS_REP_VAL i
				//					statement.setString(cnt++, seg.getStringRepresentation()); //PO_VAL i
				//				}
				//				statement.executeUpdate();

				statement.addBatch();
			}
			statement.executeBatch();

			System.out.println(FILING_ID+":: ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				close(con);

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}



	public void insertCoOrdData(W8ResultBean ruleReslt,Connection con2,int FILING_ID2,String PO_SECTION2,int PO_ID2){

		//		SEQ_POCH_ID
		int POCH_ID2 = 0;
		String sqlIdentifier = "select SEQ_POCH_ID.NEXTVAL from PO_CORD_HIGHLIGHT_DETAILS";
		PreparedStatement pst = null;
		try {
			pst = con2.prepareStatement(sqlIdentifier);

			synchronized (this) {
				ResultSet rs = pst.executeQuery();
				if (rs != null) {
					if (rs.next())
						POCH_ID2 = rs.getInt(1);
				}
			}


			idMax = con2.createStatement().executeQuery("select nvl(max(poch_id),0) max_id from PO_CORD_HIGHLIGHT_DETAILS");

			int POCH_ID2 = -1;
			if (idMax.next()) {
				POCH_ID2 = idMax.getInt("max_id")+1;  
			}
			
			if(ruleReslt.getResultRule().getType().toLowerCase().contains("checkbox")){
				PO_SECTION2=ruleReslt.getLabel().split("##")[0].trim();//PO_SECTION
			}else{
				PO_SECTION2=ruleReslt.getLabel();//PO_SECTION
			}
			String CORD_DETAILS_VAL12="";
			List<PDFSegment> resultSegs = ruleReslt.getExtractionSegments();
			if(resultSegs!=null&&!resultSegs.isEmpty()){//&&resultSegs.get(0)!=null||resultSegs.get(0).getRectangle()!=null){


				Rectangle rect = resultSegs.get(0).getRectangle();
				CORD_DETAILS_VAL12=rect.getX()+","+rect.getY2()+","+rect.getX2()+","+rect.getY()+","+(rect.getPage()+1);
				PreparedStatement statement2 = null;

				// insert the data
				//statement.executeUpdate("INSERT INTO Customers " + "VALUES ("+1001, 'Simpson', 'Mr.', 'Springfield', 2001)");		
				String qr="insert into PO_CORD_HIGHLIGHT_DETAILS(POCH_ID,PO_ID,CORD_DETAILS_VAL1,FILING_ID,PO_SECTION) values ("+POCH_ID2+","+PO_ID2+","+
						"'"+CORD_DETAILS_VAL12+"'"+","+FILING_ID2+","+"'"+PO_SECTION2+"'"+")";

				statement2 = con2.prepareStatement(qr);

				statement2.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static void testInsert(Connection con2){

		ResultSet idMax;
		try {
			idMax = con2.createStatement().executeQuery("select nvl(max(poch_id),0) max_id from PO_CORD_HIGHLIGHT_DETAILS");

			int POCH_ID2 = -1;
			if (idMax.next()) {
				POCH_ID2 = idMax.getInt("max_id")+1;  
			}




			PreparedStatement statement = null;

			// insert the data
			//statement.executeUpdate("INSERT INTO Customers " + "VALUES ("+1001, 'Simpson', 'Mr.', 'Springfield', 2001)");		
			String qr="insert into PO_CORD_HIGHLIGHT_DETAILS(POCH_ID,PO_ID,CORD_DETAILS_VAL1,FILING_ID,PO_SECTION) values ("+1111+","+2222+","+
					"'"+"CORD_DETAILS_VAL12"+"'"+","+3333+","+"'"+"PO_SECTION2"+"'"+")";

			statement = con2.prepareStatement(qr);

			statement.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void main(String args[]) {
		
		 * String str = "//PO_AS_REP_VAL1//NT"; System.out.println(" :" +
		 * str.split("//")[1].lastIndexOf("_")); System.out.println(" :" +
		 * str.split("//")[0] + " :" + str.split("//")[1] + " :" +
		 * str.split("//")[2]); getConnection();
		 
		//		String	expectedSeq="1,2,4,4,4,4,4,4,4,4,4,4,4,5,5,5,5,5,5,6,7,8,9a,9a,9b,9b,10,14a,14a,14b,14c,15,26,26,29a 29b 29c 29d 29e,29f,44,44,44,44";
		//		String[] PO_INDEX_ORDER = expectedSeq.split("\\,");
		//String	expectedSeq="1,2,4.1,4.2,4.3,4.4,4.5,4.6,4.7,4.8,4.9,4.10,4.11,5.1,5.2,5.3,5.4,5.5,5.6,6,7,8,9.1,9.2,9.3,9.4,10,14.1,14.2,14.3,14.4,15,26,26,29.1,29.2,44.1,44.2,44.3,44.4";
		//		
		//		String[] PO_INDEX_ORDER = expectedSeq.split("\\,");
		//		
		//	 for (int i = 0; i < PO_INDEX_ORDER.length; i++) {
		//		//  System.out.println((i+1)+"0 :"+PO_INDEX_ORDER[i]);
		//		  System.out.println(Float.valueOf(PO_INDEX_ORDER[i]));
		//			
		//	}

		DatabaseConnection1 dbc = new DatabaseConnection1();
		Connection conn = dbc.getConnection();
		//		testInsert(conn);
		//		dbc.readData(conn);
		//		int id=258010;
		//		dbc.deleteData(conn,id);

	}
}
*/