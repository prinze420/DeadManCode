package com.pdf.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection2 {

	/*
	 * private static Date START_DATE; private static Date END_DATE;
	 */
	
	public DatabaseConnection2(){
		getConnection();
	}
	private static String LSCONNECTION_DRIVER_NAME = "mssql.db.connection.driver201";
	private static String LSCONNECTION_STRING_PROPERTY = "mssql.db.connection.string201";
	private static String LSCONNECTION_USERNAME = "mssql.db.connection.username201";
	private static String LSCONNECTION_PASSWORD = "mssql.db.connection.password201";
	//			mssql.db.connection.driver200
	//			mssql.db.connection.string200
	//			mssql.db.connection.username200
	//			mssql.db.connection.password200

	public static Connection getConnection() {
		Connection conn = null;
		int tryCount=0;
		do{
			String driver = Configuration.getProperty(LSCONNECTION_DRIVER_NAME);
			String connectionString = Configuration.getProperty(LSCONNECTION_STRING_PROPERTY);
			String username = Configuration.getProperty(LSCONNECTION_USERNAME);
			String password = Configuration.getProperty(LSCONNECTION_PASSWORD);

			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(connectionString, username, password);
				System.out.println("Conn Done");
			} catch (Exception e) {
				System.err.println("ERROR IN GETTING THE LS CONNECTION : " + e.getMessage());
				System.err.println("\tDRIVER = " + driver);
				System.err.println("\tCONNECTION STRING = " + connectionString);
				System.err.println("\tUSERNAME = " + username);
				System.err.println("\tPASSWORD = " + password);
				e.printStackTrace();
			}

			tryCount++;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}while(conn==null && tryCount<=5);
		
		if(conn==null){
			System.out.println("Connection not established");
		}
		
		return conn;
	}

	/*static ResourceBundle config;
	static{
		try {
			config = ResourceBundle.getBundle("database",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}

	public static Connection getConnection() {
		Connection conn = null;
		int tryCount=0;
		do{
			String driver = config.getString("driver");
			String connectionString = config.getString("connection");
			String username = config.getString("username");
			String password = config.getString("password");

			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(connectionString, username, password);
				return conn;
			} catch (Exception e) {
				e.printStackTrace();
			}
			tryCount++;

			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}while(conn==null && tryCount<=5);

		return conn;
	}*/
}
