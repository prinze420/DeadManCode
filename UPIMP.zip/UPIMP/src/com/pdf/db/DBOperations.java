package com.pdf.db;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.pdf.parser.rules.ExtractionRule;
import com.pdf.parser.rules.Extraction_Result;

public class DBOperations {


	public static String getPath(int fileId){
		String path = "";

		try{
			Connection c = DatabaseConnection.getConnection();
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select FILE_PATH,FILE_NAME from FILE_DATA where FILE_ID="+fileId);

			if(rs.next())
				path = rs.getString(1)+rs.getString(2);

			rs.close();
			st.close();
			c.close();

		}catch(Exception e){
			e.printStackTrace();
		}

		return path;
	}

	public static void deleteData(int fileId){
		String path = "";

		try{
			Connection c = DatabaseConnection.getConnection();
			Statement st = c.createStatement();
			st.executeQuery("delete from parser_output where filing_id="+fileId);


			st.close();
			c.close();

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public static void readData(int fileId ){
		Set<ExtractionRule> rules=new HashSet<ExtractionRule>();

		PreparedStatement preparedStatement = null;
		String selectSQL = "SELECT * FROM "+ "parser_output where filing_id="+fileId;
		Connection conn=null;
		try {
			conn = DatabaseConnection.getConnection();	
			preparedStatement = conn.prepareStatement(selectSQL);
			ResultSet rs = preparedStatement.executeQuery();
			int c=0;
			while (rs.next()) {
				System.out.print(rs.getString("PO_ID")+"\t");
				System.out.print(rs.getString("PO_AS_REP_LABEL")+"\t");
				System.out.println(rs.getString("PO_VAL1"));
				c++;
				if(c>5)
					break;
			}

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());

		} finally {

			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}

	}
	public static String getSubmissionId(int fileId){
		String path = "";

		try{
			Connection c = DatabaseConnection.getConnection();
			Statement st = c.createStatement();
			ResultSet rs = st.executeQuery("select PARENT_ID from FILE_DATA where FILE_ID="+fileId);

			if(rs.next())
				path = rs.getInt(1)+"";

			rs.close();
			st.close();
			c.close();

		}catch(Exception e){
			e.printStackTrace();
		}

		return path;
	}


	public static void save(List<Extraction_Result> res, int fileId){
		try{
			Connection c = DatabaseConnection.getConnection();		
			//Find max id
			Statement statement = c.createStatement();
			ResultSet rs = statement.executeQuery("select max(ID) from EXTRACTED_OUTPUT");
			rs.next();
			int maxid = rs.getInt(1)+1;
			rs.close();
			statement.close();

			PreparedStatement st = c.prepareStatement("insert into EXTRACTED_OUTPUT values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

			for(Extraction_Result s:res){
				ExtractionRule r = s.getRule();

				for(String val : s.getOutputList()){

					if(val==null)
						continue;
					val = val.replace("null", "").trim();
					if(val.trim().length()==0)
						continue;

					int a=1;

					st.setInt(a++, maxid++);
					st.setInt(a++, fileId);
					st.setInt(a++, r.getRuleId());
					st.setString(a++, r.getFieldName());
					st.setString(a++, r.getExtractionArea());
					st.setString(a++, r.getDataType());
					st.setNull(a++, Types.NULL);
					st.setString(a++, val);
					st.setLong(a++, s.getNodeId());
					st.setInt(a++, s.getSentenceIndex());
					//st.setInt(a++, r.getTraverse());
					st.setString(a++, getSubmissionId(fileId));
					st.setString(a++, r.getKeywords());
					st.setString(a++, r.getDataType());
					st.setInt(a++, (int)s.getyCoordinate());
					st.setInt(a++, s.getPage());

					st.addBatch();
				}
			}
			st.executeBatch();
			System.out.println("DB Insertion Done");
			st.close();
			c.close();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static void updateTimeStamps(int fileid, long start, long end, int total){
		try{
			Connection c = DatabaseConnection.getConnection();
			PreparedStatement st = c.prepareStatement("update FILE_DATA set EXTRACTION_START_TIME=?,EXTRACTION_END_TIME=?,TOTAL_EXTRACTION_TIME=?");

			st.setDate(1, new Date(start));
			st.setDate(2, new Date(end));
			st.setInt(3, total);
			st.addBatch();

			st.executeBatch();
			st.close();
			c.close();

		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public static List<String> getList(String listName){
		List<String>requiredList=new ArrayList<String>();
		PreparedStatement stmt = null;
		Connection conn = DatabaseConnection.getConnection();
		if (conn != null) {
			try {
				String query = "select KEYWORD from EXTRACTION_LIST where LIST_NAME="+"'"+listName.trim()+"'";
				stmt = conn.prepareStatement(query);

				ResultSet rs = stmt.executeQuery();
				while (rs.next()) {
					String value = rs.getString("KEYWORD");
					if(!value.isEmpty())
						requiredList.add(value);
				}

				rs.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} finally {

				if (stmt != null || conn !=null) {
					try {
						stmt.close();
						conn.close();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}

			}
		}
		System.out.println(listName+" size\t"+requiredList.size());
		return requiredList;
	}

	public static void saveExtractionResult(List<Extraction_Result> results,String fileName){
		try{
			Connection c = DatabaseConnection.getConnection();		
			//Output_ID,FileName PageNum Extraction_Area Field_Name ResultList NLP_Process TemplateID RuleID InputKeywords
			String query="insert into Extraction_Output (FileName,PageNum,Extraction_Area,Field_Name,ResultList,NLP_Process,TemplateID,RuleID,InputKeywords) values(?,?,?,?,?,?,?,?,?)";
			PreparedStatement st = c.prepareStatement(query);			
			//PreparedStatement st = c.prepareStatement("insert into Extraction_Output values(?,?,?,?,?,?,?,?,?,?)");

			for(Extraction_Result res:results){
				ExtractionRule rule = res.getRule();

				for(String val : res.getOutputList()){

					if(val==null)
						continue;
					val = val.replace("null", "").trim();
					if(val.trim().length()==0)
						continue;

					int a=1;
					//String FileName PageNum Extraction_Area Field_Name ResultList NLP_Process TemplateID RuleID InputKeywords
					st.setString(a++,fileName);
					st.setInt(a++,res.getPage());
					st.setString(a++,rule.getExtractionArea());
					st.setString(a++,rule.getFieldName());
					st.setString(a++,val);
					st.setString(a++,rule.getNLP_Process());
					st.setInt(a++,rule.getTemplateID());
					st.setInt(a++,rule.getRuleId());
					st.setString(a++,rule.getKeywords());

					st.addBatch();
				}
			}
			int[] status = st.executeBatch();
			System.out.println(status);
			System.out.println("DB Insertion Done");

			st.close();
			if (c != null) {
				try {
					c.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}

	}

	public void saveInToLiveSpreadDB(List<Extraction_Result> result, int FILING_ID) {

		Connection con = DatabaseConnection.getConnection();
		int PO_IDval = 0,order=10;

		/*String sqlIdentifier = "select seq_po_id.NEXTVAL from parser_output";
		PreparedStatement pst = null;
		try {
			pst = con.prepareStatement(sqlIdentifier);
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}*/

		String query2 = "insert into PARSER_OUTPUT (FILING_ID,PO_SECTION,PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
				+ "PO_AS_REP_VAL1,PO_VAL1,"//2
				//+ "PO_AS_REP_VAL2,PO_VAL2,PO_AS_REP_VAL3,PO_VAL3,PO_AS_REP_VAL4,PO_VAL4,PO_AS_REP_VAL5,PO_VAL5,PO_AS_REP_VAL6,PO_VAL6,"//10

				+ "PO_CRUD_ACCOUNT,CREATE_DATE,"//2
				+ "PAGE_NO,PO_YCOORDINATES) values(?,?,?,?,?,?,?,?,?,?)";//2
		PreparedStatement statement = null;
		try {
			statement = con.prepareStatement(query2);

			for (Extraction_Result ruleReslt : result) {

				List<String> opList = ruleReslt.getOutputList();
				ExtractionRule rule = ruleReslt.getRule();

				for (String string : opList) {
					int a=1;


					//					synchronized (this) {
					//						ResultSet rs = pst.executeQuery();
					//						if (rs != null) {
					//							if (rs.next())
					//								PO_IDval = rs.getInt(1);
					//						}
					//					}

					//For :   PO_CORD_HIGHLIGHT_DETAILS
					//	insertCoordinates(ruleReslt, FILING_ID, PO_IDval, con);

					statement.setInt(a++, FILING_ID);//FILING_ID,
					//statement.setInt(a++, PO_IDval); // PO_ID,
					statement.setString(a++, "FORM");//PO_SECTION,
					statement.setFloat(a++,Float.valueOf(order));//PO_INDEX_ORDER
					order=order+10;

					statement.setString(a++, rule.getFieldName());//PO_AS_REP_LABEL

					statement.setString(a++, string);// PO_AS_REP_VAL1
					statement.setString(a++, string);// PO_VAL1

					statement.setString(a++, "C");//PO_CRUD_ACCOUNT,
					statement.setTimestamp(a++, new Timestamp(System.currentTimeMillis()));// CREATE_DATE

					statement.setFloat(a++, ruleReslt.getPage());//PAGE_NO,
					statement.setFloat(a++, ruleReslt.getyCoordinate());//PO_YCOORDINATES
				}
				statement.addBatch();

				//				 int status = statement.executeUpdate();
				//				 System.out.println("getKeyword :" + ruleReslt.getKeyword());
				//				 System.out.println("status :" + status);
			}
			statement.executeBatch();
			System.out.println(FILING_ID+":: ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {
				if (statement != null)
					statement.close();
				if(con != null)
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}


	public void insertCoordinates(List<Extraction_Result> result, int FILING_ID) {

		Connection con = DatabaseConnection.getConnection();
		
		try {
			for (Extraction_Result ruleReslt : result) {

				List<String> opList = ruleReslt.getOutputList();
				int indxOrder=0;
				for (String string : opList) {
					//For :   PO_CORD_HIGHLIGHT_DETAILS
					indxOrder=indxOrder+10;
				//	insertCoordinates(ruleReslt, FILING_ID,con,indxOrder);
					
				}

			}

			System.out.println(FILING_ID+":: insertCoordinates ****  Data Inserted ***");
		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		} finally {
			try {

				if(con != null)
					con.close();

			} catch (Exception e) {
				e.printStackTrace();
			}
		}


	}
	private void insertCoordinates(Extraction_Result result, int FILING_ID,Connection con,int indxOrder ) {


		String sqlCoordRow = "insert into PO_CORD_HIGHLIGHT_DETAILS (filing_id,po_id,po_section,CORD_DETAILS_VAL1,CORD_DETAILS_VAL2"
				//+ ",CORD_DETAILS_VAL3,CORD_DETAILS_VAL4,CORD_DETAILS_VAL5,CORD_DETAILS_VAL6,CORD_DETAILS_VAL7,CORD_DETAILS_VAL8,CORD_DETAILS_VAL9,CORD_DETAILS_VAL10"
				+ ") values ("
				+ "?,?,?,?,?"
				//+ ",?,?,?,?,?,?,?,?"
				+ ")";

		long poID = getpoID(FILING_ID, con, "FORM",indxOrder);

		PreparedStatement pStmt1 = null;
		int ct = 0;
		try {

			pStmt1 = con.prepareStatement(sqlCoordRow);
			pStmt1.setLong(++ct, FILING_ID);
			pStmt1.setLong(++ct, poID);
			pStmt1.setString(++ct, "FORM");
			pStmt1.setString(++ct, "");
			//pStmt1.setString(++ct, result.getCoordinatesBox());
			pStmt1.executeUpdate();
			if (pStmt1 != null)
				pStmt1.close();

		} catch (Exception e) {

			if (pStmt1 != null)
				try {
					pStmt1.close();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		}
	}

	public static long getpoID(int fILING_ID,Connection c, String section,int indxOrder) {


		long poID = 0;

		//PO_INDEX_ORDER,PO_AS_REP_LABEL,"//5
		//+ "PO_AS_REP_VAL1,PO_VAL1,"//2
		try{
		//	Connection c = DatabaseConnection.getConnection();
			Statement st = c.createStatement();
			//			ResultSet rs = st.executeQuery("select PO_ID from PARSER_OUTPUT where filing_id="+fILING_ID);
			ResultSet rs = st.executeQuery("select PO_ID from PARSER_OUTPUT where po_section="+"'"+section+"'"+"AND filing_id=" +"'"+ fILING_ID+ "'" +"AND PO_INDEX_ORDER="+ "'" +indxOrder+ "'");
			//			ResultSet rs = st.executeQuery("select PO_ID from PARSER_OUTPUT where po_section="+section+"AND filing_id="+fILING_ID+"AND PO_INDEX_ORDER="+indxOrder);
			//			ResultSet rs = st.executeQuery("select PO_ID from PARSER_OUTPUT where PO_SECTION="+"'"+FORM'+" AND FILE_ID='162801' AND PO_INDEX_ORDER='10'");

			if(rs.next())
				poID = rs.getInt(1);

			rs.close();
			st.close();

		}catch(Exception e){
			e.printStackTrace();
		}

		return poID;

	}

	public static  Set<ExtractionRule> getRuleFromDB( ){
		Set<ExtractionRule> rules=new HashSet<ExtractionRule>();

		PreparedStatement preparedStatement = null;
		String selectSQL = "SELECT * FROM "+ "Ontology_Structure";
		Connection conn=null;
		try {
			conn = DatabaseConnection.getConnection();	
			preparedStatement = conn.prepareStatement(selectSQL);
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				//TemplateID RuleID Field_Name Keyword Extraction_Area DataType NLP_Proces CheckBoxSecondWord 
				ExtractionRule newGroup = new ExtractionRule() ;
				newGroup.setTemplateID(new Integer(rs.getString("TemplateID")));
				newGroup.setRuleId(new Integer(rs.getString("RuleID")));
				newGroup.setFieldName(rs.getString("Field_Name")) ;
				newGroup.setKeywords(rs.getString("keyword").trim()) ;
				newGroup.setExtractionArea(rs.getString("Extraction_Area")) ;
				newGroup.setDataType(rs.getString("DataType"));		
				newGroup.setNLP_Process(rs.getString("NLP_Proces"));
				newGroup.setCheckBoxSecondWord(rs.getString("CheckBoxSecondWord"));

				if(newGroup!=null)
					rules.add(newGroup);
			}

		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());

		} finally {

			if (preparedStatement != null) {
				try {
					preparedStatement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		return rules;
	}

	public static Set<ExtractionRule> getRulesFromText(String ruleFile){
		Set<ExtractionRule> rules = new HashSet<ExtractionRule>();

		if(rules.size()==0){
			String line = "";
			try{
				BufferedReader reader = new BufferedReader(new FileReader(ruleFile));

				boolean skipFirstLine = true;
				while((line = reader.readLine())!=null){

					if(skipFirstLine){
						skipFirstLine = false;
						continue;
					}

					line = line.trim() ;
					//TemplateID	ID	Field Name	Keyword	Extraction Area	DataType	NLP_Proces	CheckBoxSecondWord

					String[] split = line.split("\\t") ;
					ExtractionRule newGroup = new ExtractionRule() ;
					newGroup.setTemplateID(new Integer(split[0]));
					newGroup.setRuleId(new Integer(split[1]));
					newGroup.setFieldName(split[2]) ;
					String keywordToSet = split[3] ;
					newGroup.setKeywords(keywordToSet.trim()) ;
					newGroup.setExtractionArea(split[4]) ;
					newGroup.setDataType(split[5]) ;							
					newGroup.setNLP_Process(split[6]);
					if(split.length>=8){
						newGroup.setCheckBoxSecondWord(split[7]);
					}
					rules.add(newGroup);
				}

				reader.close();

			}catch(Exception e){
				e.printStackTrace();
				System.out.println("Issue - "+line);
			}
		}
		System.out.println("Total Rules :"+rules.size());
		return rules;
	}

	public static void getRuleFromTextAndInsertInDB(String ruleFilePath, int templateID){

		Set<ExtractionRule> rules = getRulesFromText(ruleFilePath);

		if(rules!=null && !rules.isEmpty()){
			Connection c = DatabaseConnection.getConnection();	

			for (ExtractionRule r : rules) {
				if(templateID>0){
					if(r.getTemplateID()==templateID){
						insertRuleInTable(r,c);
					}
				}else{
					insertRuleInTable(r,c);
				}
			}

			if (c != null) {
				try {
					c.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}

	}


	private static void insertRuleInTable(ExtractionRule r,Connection c) {

		try{

			String query="insert into Ontology_Structure (TemplateID,RuleID,Field_Name,Keyword,Extraction_Area,DataType,NLP_Proces,CheckBoxSecondWord) values(?,?,?,?,?,?,?,?)";
			PreparedStatement st = c.prepareStatement(query);			

			//TemplateID RuleID Field_Name Keyword Extraction_Area DataType NLP_Proces CheckBoxSecondWord 
			int a=1;
			st.setInt(a++,r.getTemplateID());
			st.setInt(a++,r.getRuleId());
			st.setString(a++,r.getFieldName());
			st.setString(a++,r.getKeywords());
			st.setString(a++,r.getExtractionArea());
			st.setString(a++,r.getDataType());
			st.setString(a++,r.getNLP_Process());
			st.setString(a++,r.getCheckBoxSecondWord());
			st.execute();

			st.close();

		}catch(Exception e){
			e.printStackTrace();
		}

	}



	public static void main(String[] args) {

		/*List<String> streets = DBOperations.getList("Adress_Street");

		for (String string : streets) {
			System.out.println(string);
		}*/

		File file=new File("subset.txt");
		String keyword="##Cell {MAILING ADDRESS(Including ZIP+4)}";
		ExtractionRule r=new  ExtractionRule();
		r.setTemplateID(1000);
		r.setRuleId(1);
		r.setFieldName(file.getName());
		r.setKeywords("patient Name");
		r.setExtractionArea("KeyValue");
		r.setDataType("Detail");
		r.setNLP_Process("N");
		r.setCheckBoxSecondWord("");

		List<Extraction_Result>results=new ArrayList<Extraction_Result>();
		Extraction_Result er=new Extraction_Result(100011, 0, r, 120.34f, 1);
		List<String>opList=new ArrayList<>();
		opList.add("xyz kapur");
		opList.add("abc kapur");
		er.setOutputList(opList);

		results.add(er);

		DBOperations.saveExtractionResult(results, file.getName());
		System.out.println("Done");


		//		String ruleFilePath="E:\\ExtractionDir\\RuleFileTemp.txt";
		//		DBOperations.getRuleFromTextAndInsertInDB(ruleFilePath, -1);

		Set<ExtractionRule> rules = DBOperations.getRuleFromDB();
		System.out.println(rules);


		/*keyword = keyword.replaceAll("[\\[\\]\\{\\}]", "").replace("##Cell", "").trim();
		System.out.println(keyword);
		String content="NAME (First name insured) AND MAILING ADDRESS(Including ZIP+4) CaarWil LLC 505 Westmoreland Road Winnemucca, NV 89445";
		if(content.contains(keyword)){
			System.out.println("contain");
			content=content.substring(content.indexOf(keyword)+keyword.length(), content.length());
		}
		content = content.replace(keyword, "").trim();
		System.out.println(content);*/
	}
}
