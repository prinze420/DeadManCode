package com.rage.siapp.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.List;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFWord;

public class WordExtraction {

	List<PDFLine> finalListLine;
	
	public WordExtraction(List<PDFLine> finalListLine) {
		this.finalListLine=finalListLine;
	}

	public List<PDFWord> createWords() throws Exception
	{

		List<PDFWord> finalWord= new ArrayList<PDFWord>();
		List<PDFCharacter> charInWords = new ArrayList<PDFCharacter>();
		
		for(int i=0;i<finalListLine.size();i++)
		{
			List<PDFCharacter> listChars = finalListLine.get(i).getListChars();
			
			String word="";
			
			
			for(int j=0;j<listChars.size();j++)
			{
				
				float curX2 =0f;
				float nextX1=0f;  
				
				
				curX2=listChars.get(j).getX2();
				
				if(j+1 < listChars.size())
				{
				
					nextX1=listChars.get(j+1).getX1();
					
					
					float xDiff = Math.abs( curX2-nextX1 );
					//System.out.println(xDiff);
					
					if( (xDiff < 2) && (listChars.get(j).getCharacter().trim().length()!=0) )
					{
						word+=listChars.get(j).getCharacter().trim();
						charInWords.add(listChars.get(j));
					}
					else
					{
						
						if(charInWords.size()>0)
						{
							word+=listChars.get(j).getCharacter().trim();
							if (listChars.get(j).getCharacter().trim().length()!=0)
							{
								charInWords.add(listChars.get(j));
							}
							finalWord.add( new PDFWord(word,charInWords));
							word="";
							charInWords.clear();
							
						}
						
							
					}
				}
				else
				{
						word+=listChars.get(j).getCharacter().trim();
						charInWords.add(listChars.get(j));
						finalWord.add( new PDFWord(word,charInWords));
						word="";
						charInWords.clear();
							
					
				}
				
				
			}
			
		}
				
		List<PDFWord> cleanFinalWord = new ArrayList<PDFWord>();
		
		 for (int i=0;i<finalWord.size();i++) 
		 {
		      if ( !(finalWord.get(i).getWord().trim().length()==0) ) 
		      { 
		    	  cleanFinalWord.add(finalWord.get(i));
		      }
		 }
		 
		 
		return cleanFinalWord;
		
		
		
	}
	
	
}
