package com.rage.siapp.extraction.pdf.parse;

import java.io.IOException;
import java.util.Vector;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.PDFTextStripper;
import org.apache.pdfbox.util.TextPosition;

public class TextPositionsFinder extends PDFTextStripper
{
	private PDPage page ;
	private Vector<TextPosition> textPositions ;
	
	public static Vector<TextPosition> findTextPositions(PDPage page) // NO_UCD (unused code)
	{
		try
		{
			TextPositionsFinder ptlf = new TextPositionsFinder(page) ;
			ptlf.run() ;
			return ptlf.getTextPositions() ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN FINDING TEXT-POSITIONS : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
		
		return new Vector<TextPosition>() ;
	}
	
	public TextPositionsFinder(PDPage page) throws IOException 
	{
		super();
		super.setSortByPosition(true) ;
		
		setPage(page) ;
		setTextPositions(new Vector<TextPosition>()) ;
	}
	
	public void run()
	{
		try
		{
			if ( getPage().getContents() == null )
				return ;
			processStream(getPage(), getPage().findResources(), getPage().getContents().getStream()) ;
		}
		catch (Exception e)
		{
			System.err.println("ERROR IN PROCESSING STREAM : " + e.getMessage()) ;
			e.printStackTrace() ;
		}
	}
	
	@Override
    protected void processTextPosition(TextPosition text) 
	{
		getTextPositions().addElement(text) ;
		// System.out.println(text.getCharacter() + "[" + text.getX() + ", " + text.getY() + "]") ;
    }
	
	public PDPage getPage() {
		return page;
	}

	public void setPage(PDPage page) {
		this.page = page;
	}

	public Vector<TextPosition> getTextPositions() {
		return textPositions;
	}

	public void setTextPositions(Vector<TextPosition> textPositions) {
		this.textPositions = textPositions;
	}
}
