package com.rage.siapp.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.List;
import java.util.TreeMap;
import java.util.TreeSet;

import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.util.TextPosition;

import com.rage.siapp.extraction.pdf.PDFCharacter;

public class CharacterCreator 
{
	public List<PDFCharacter> createCharacters(PDPage page) 
	{
		List<PDFCharacter> characters = new ArrayList<PDFCharacter>() ;
        try
        {
                TextPositionsFinder tpf = new TextPositionsFinder(page) ;
                tpf.run() ;
                List<TextPosition> textPositions = tpf.getTextPositions() ;
               
                if(textPositions.size()<1)
                	return characters;
                
                
                List<Float> validDirections = findMainDirections(textPositions) ;
                
                for ( int i=0 ; i<textPositions.size() ; i++ )
                {
                        TextPosition tp = textPositions.get(i) ;
                        float direction = tp.getDir() ;
                        if ( !validDirections.contains(direction) )
                                continue ;
                        
                        PDFCharacter character = new PDFCharacter(tp) ;
                        characters.add(character) ;
                }
        }
        catch (Exception e)
        {
                System.out.println(e.getMessage());
                e.printStackTrace() ; 
        }
        return characters;
	}
	
	private List<Float> findMainDirections(List<TextPosition> textPositions) 
	{
	        TreeMap<Float, Integer> directionCountsMap = new TreeMap<Float, Integer>() ;
	        
	        for ( int i=0 ; i<textPositions.size() ; i++ )
	        {
	                TextPosition tp = textPositions.get(i) ;
	                float direction = tp.getDir() ;
	                
	                Integer count = directionCountsMap.containsKey(direction) ? directionCountsMap.get(direction) : new Integer(0) ;
	                count = count.intValue() + 1 ;
	                directionCountsMap.put(direction, count) ;
	        }
	        
	        List<Integer> counts = new ArrayList<Integer>(new TreeSet<Integer>(directionCountsMap.values())) ;
	        Integer maxCount = counts.get(counts.size()-1) ;
	        
	        List<Float> directions = new ArrayList<Float>() ;
	        for ( Float direction : directionCountsMap.keySet() )
	        {
	                Integer count = directionCountsMap.get(direction) ;
	                if ( count.intValue() == maxCount.intValue() )
	                        directions.add(direction) ;
	        }
	        
	        return directions ;
	}
	
}
