package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;

public class PDFParagraph {

	String para;
	ArrayList<PDFLine> lineInPara;
	
	public PDFParagraph(String para, ArrayList<PDFLine> lineInPara) {
		
		this.para=para;
		this.lineInPara = new ArrayList<PDFLine>(lineInPara);
		
	}

	public String getPara() {
		return para;
	}

	public void setPara(String para) {
		this.para = para;
	}

	public ArrayList<PDFLine> getLineInPara() {
		return lineInPara;
	}

	public void setLineInPara(ArrayList<PDFLine> lineInPara) {
		this.lineInPara = lineInPara;
	}

	@Override
	public String toString() {
		return "PDFParagraph [para=" + para + ", lineInPara=" + lineInPara + "]";
	}

	
	
}
