package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

public class PDFWord {

	String word;
	List<PDFCharacter> charInWords;
	
	
	public PDFWord(String word, List<PDFCharacter> charInWords) {
		this.word=word;
		this.charInWords = new ArrayList<PDFCharacter>(charInWords);
		
		
		
	}


	public String getWord() {
		return word;
	}


	public void setWord(String word) {
		this.word = word;
	}


	public List<PDFCharacter> getCharInWords() {
		return charInWords;
	}


	public void setCharInWords(List<PDFCharacter> charInWords) {
		this.charInWords = charInWords;
	}


	@Override
	public String toString() {
		return "PDFWord [word=" + word + ", charInWords=" + charInWords + "]";
	}

}
