package com.rage.siapp.extraction.pdf.parse;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFParagraph;

public class ParaExtraction {

	List<PDFLine> boundLine;
	
	public ParaExtraction(List<PDFLine> finalListLine) {
		this.boundLine=finalListLine;
	}

	public void createPara() throws Exception 
	{
		System.out.println(boundLine.get(0).getX1());
		//List<PDFLine> listBoundLine = new ArrayList<PDFLine>();
		PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\Temp.txt");
		
		
		ArrayList<PDFLine> lineInPara = new ArrayList<PDFLine>();		
		ArrayList<PDFParagraph> finalPara = new ArrayList<PDFParagraph>();
		String para="";
		
		
		float prevYDiff =0f;
		float Ydiff=0f;
		
		
		
		int vGap = findAvgVgaps(boundLine);
		
		System.out.println(vGap);
		
		for(int p=0;p<boundLine.size();p++)
		{
			float curY2= boundLine.get(p).getY2();
			float nextY2;
			
			
			if(p+1 < boundLine.size())
			{
				nextY2=boundLine.get(p+1).getY2();
				
				Ydiff = Math.abs(curY2-nextY2);
				
				if((int)Ydiff < vGap )
				{
					para+=boundLine.get(p).getFinalLine()+"\n";
					lineInPara.add(boundLine.get(p));
				}
				else
				{
					
					para+=boundLine.get(p).getFinalLine()+"\n";
					lineInPara.add(boundLine.get(p));
					finalPara.add(new PDFParagraph(para,lineInPara));
					para="";
					lineInPara.clear();
					prevYDiff=Ydiff;
					
				}
			}
			else
			{
				para+=boundLine.get(p).getFinalLine()+"\n";
				lineInPara.add(boundLine.get(p));
				finalPara.add(new PDFParagraph(para,lineInPara));
				para="";
				lineInPara.clear();
				prevYDiff=Ydiff;
				
			}
		}
		
		for(int p=0;p<finalPara.size();p++)
		{
			writer.println(p+"\n"+finalPara.get(p).getPara());
			writer.println();
		}
		
		
		writer.close();
	}

	public int  findAvgVgaps(List<PDFLine> boundLine) 
	{
		int maxGap=0;
		
		List<Integer> vGaps = new ArrayList<Integer>();
		
		float prevYDiff =0f;
		float Ydiff=0f;
		
		for(int v=0;v<boundLine.size();v++)
		{
			float curY2= boundLine.get(v).getY2();
			float nextY2;
			
			if(v+1 < boundLine.size())
			{
				nextY2=boundLine.get(v+1).getY2();
				
				Ydiff = Math.abs(curY2-nextY2);
				vGaps.add((int)Ydiff);
			
			}
		}
		
		System.out.println("gaps "+vGaps);
		
		
		TreeMap <Integer, Integer> tMap = new TreeMap<Integer, Integer>();
		 
		for(int index = 0; index < vGaps.size(); index++) 
		{
		 
		    if(tMap.get(vGaps.get(index)) == null) 
		    {
		        tMap.put(vGaps.get(index), 1);
		    }
		    else 
		    {
		        int val = tMap.get(vGaps.get(index));
		        tMap.put(vGaps.get(index), ++val);
		    }
		}
		
	//	System.out.println("Map "+tMap);
		
		Map.Entry<Integer, Integer> maxEntry = null;
		
		for(Map.Entry<Integer, Integer> entry : tMap.entrySet())
		{
		   if(maxEntry == null || entry.getValue().compareTo(maxEntry.getValue()) > 0)
		      maxEntry = entry;
		}
		
		maxGap = maxEntry.getKey();
		
		//System.out.println("The key with maximum value is : " + maxEntry.getKey());
		
		return maxGap;
	}


	
	
}
