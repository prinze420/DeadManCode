package com.rage.siapp.extraction.pdf.parse;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;

public class LineExtraction {

	Map<Integer, List<PDFCharacter>> pageWiseCharacterMap;
	
	List<PDFLine> finalListLine ;
	
	public LineExtraction(Map<Integer, List<PDFCharacter>> pageWiseCharacterMap) {
		this.pageWiseCharacterMap=pageWiseCharacterMap;
		finalListLine = new ArrayList<PDFLine>();
	}

	public List<PDFLine> createLines() throws Exception{
		
		List<PDFCharacter> listCharacters = new ArrayList<PDFCharacter>();
		for(Map.Entry<Integer, List<PDFCharacter>> entry : pageWiseCharacterMap.entrySet() )
		{
			for(PDFCharacter ch : entry.getValue())
			{
				listCharacters.add(ch);
			}
		}

		
		float prevX1 = 0f;
		float prevY1 = 0f;
		
		float prevX2 = 0f;
		float prevY2 = 0f;
		
		
		
		float curX1 = 0f;
		float curY1 = 0f;
		
		float curX2 = 0f;
		float curY2 = 0f;
		
		
		String line=listCharacters.get(0).getCharacter();;
		String finalLine="";
		List<PDFCharacter> listChars = new ArrayList<PDFCharacter>();
		listChars.add(listCharacters.get(0));
		
		for(int i=1;i<listCharacters.size();i++)
		{
			 
			curX1  = listCharacters.get(i).getX1();
			curY1  = listCharacters.get(i).getY1();
			
			prevX1 = listCharacters.get(i-1).getX1();
			prevX2 = listCharacters.get(i-1).getX2();
			prevY1 = listCharacters.get(i-1).getY1();
			prevY2 = listCharacters.get(i-1).getY2();
			
			
			//System.out.println(i+" "+listCharacters.get(i-1)+"  X1 "+prevX1+"  Y1 "+prevY1);
			//System.out.println(listCharacters.get(i-1)+"  X2 "+prevX2+"  Y2 "+prevY2);
			//System.out.println();
			
			//7 234.681
			//A 45.322468
			
			if( (Math.abs(curY1-prevY1) < 8) )
			{
				line+= listCharacters.get(i).getCharacter();
				listChars.add(listCharacters.get(i));
				
			}
			else
			{
				finalListLine.add(new PDFLine(line,listChars));
				listChars.clear();
				line="";
				line+= listCharacters.get(i).getCharacter();
				listChars.add(listCharacters.get(i));
			}
			
		}
		finalListLine.add(new PDFLine(line,listChars));
		listChars.clear();
		line="";
		
		
		finalListLine=setBounds(finalListLine);
		
		return finalListLine;
		
	}
	
	
	
	
	
	public List<PDFLine> setBounds(List<PDFLine> listLine) throws Exception
	{
		//PrintWriter writer = new PrintWriter("C:\\Users\\pg0e1373\\Desktop\\Temp.txt");
		List<PDFLine> boundLine = new ArrayList<PDFLine>();
		
		
		for(int i=0;i<listLine.size();i++)
		{
			PDFLine line = listLine.get(i);
			
			PDFCharacter firstChar = line.getListChars().get(0);
			PDFCharacter lastChar = line.getListChars().get(line.getListChars().size()-1);			
			
			
			//System.out.println(firstChar+" "+lastChar);
			
			boundLine.add(new PDFLine(listLine.get(i).getFinalLine(),listLine.get(i).getListChars(),firstChar.getX1(),firstChar.getY1(),lastChar.getX2(),lastChar.getY2()));
			
			
		}
		return boundLine;
		
		/*for(int j=0;j<boundLine.size();j++)
		{
			writer.println(boundLine.get(j).getFinalLine()+" "
						+boundLine.get(j).getX1()+" "
						+boundLine.get(j).getY1()+" "
						+boundLine.get(j).getX2()+" "
						+boundLine.get(j).getY2());
		}
		*/

		
		//createPara(boundLine);
		//writer.close();
		
	}

		
	
	
	
}
