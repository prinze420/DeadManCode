package com.rage.siapp.extraction.pdf;

import java.util.ArrayList;
import java.util.List;

public class PDFLine extends PDFBoundedObject{
	
	String finalLine; 
	List<PDFCharacter> listChars; 
	
	public PDFLine(String finalLine, List<PDFCharacter> listChars) {
		this.finalLine=finalLine;
		this.listChars= new ArrayList<PDFCharacter>(listChars);
	}

	public PDFLine(String finalLine, List<PDFCharacter> listChars,float x1, float y1, float x2, float y2) 
	{
		this.finalLine=finalLine;
		this.listChars= new ArrayList<PDFCharacter>(listChars);
		setBounds("Line", x1, y1, x2, y2);
	}
	
	
	
	public String getFinalLine() {
		return finalLine;
	}

	public List<PDFCharacter> getListChars() {
		return listChars;
	}

	public void setListChars(List<PDFCharacter> listChars) {
		this.listChars = listChars;
	}

	public void setFinalLine(String finalLine) {
		this.finalLine = finalLine;
	}

	

	@Override
	public String toString() {
		return "PDFLine [finalLine=" + finalLine + ", listChars=" + listChars + "]";
	}
	
	

}
