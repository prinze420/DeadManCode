package com.rage.siapp.extraction.pdf;

import java.io.Serializable;
import java.util.List;

public abstract class PDFBoundedObject implements Comparable<PDFBoundedObject>,Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -1722069429344465701L;
	private float x1 ;
	private float y1 ;
	private float x2 ;
	private float y2 ;
	private float width ;
	private float height ;
	private float midX ;
	private float midY ;
	
	public void setBounds(String thisClass, List<Float> bounds)
	{
		setBounds(thisClass, bounds.get(0), bounds.get(1), bounds.get(2), bounds.get(3)) ;
	}
	
	void setBounds(String thisClass, float x1, float y1, float x2, float y2)
	{
		
		setX1(x1) ;
		setY1(y1) ;
		setX2(x2) ;
		setY2(y2) ;
		
		 //System.out.println("THIS CLASS : " + thisClass + " ::: X1 = " + x1 + " ::: Y1 = " + y1 + " ::: X2 = " + x2 + " ::: Y2 = " + y2) ;
		
		float width = (x2-x1) ;
		float height = (y2-y1) ;
		float midX = (x1+x2) / 2 ;
		float midY = (y1+y2) / 2 ;
		
		setWidth(width) ;
		setHeight(height) ;
		setMidX(midX) ;
		setMidY(midY) ;
	}
	
	@Override
	public int compareTo(PDFBoundedObject other) 
	{
		PDFBoundedObject maxYWord = getMidY() > other.getMidY() ? this : other ;
		PDFBoundedObject minYWord = getMidY() < other.getMidY() ? this : other ;
		
		if ( maxYWord.getMidY() >= minYWord.getMidY() && maxYWord.getMidY() <= minYWord.getY2() )
		{
			if ( getMidX() != other.getMidX() )
				return new Float(getMidX()).compareTo(new Float(other.getMidX())) ;
			else if ( getX1() != other.getX1() )
				return new Float(getX1()).compareTo(new Float(other.getX1())) ;
			else if ( getX2() != other.getX2() )
				return new Float(getX2()).compareTo(new Float(other.getX2())) ;
			else 
				return 0 ;
		}
		else if ( getMidY() != other.getMidY() )
			return new Float(getMidY()).compareTo(new Float(other.getMidY())) ;
		else if ( getY1() != other.getY1() )
			return new Float(getY1()).compareTo(new Float(other.getY1())) ;
		else if ( getY2() != other.getY2() )
			return new Float(getY2()).compareTo(new Float(other.getY2())) ;
		else if ( getMidX() != other.getMidX() )
			return new Float(getMidX()).compareTo(new Float(other.getMidX())) ;
		else if ( getX1() != other.getX1() )
			return new Float(getX1()).compareTo(new Float(other.getX1())) ;
		else if ( getX2() != other.getX2() )
			return new Float(getX2()).compareTo(new Float(other.getX2())) ;
		
		
		return new Float(getMidY()).compareTo(other.getMidY()) ;
	}
	
	@Override
	public String toString() 
	{
		return "[" + getX1() + ", " + getY1() + ", " + getX2() + ", " + getY2() + "]" ;
	}
	
	@Override
	public int hashCode()
	{
		final int prime = 31;
		int result = 1;
		
		result = prime * result + Float.floatToIntBits(height);
		result = prime * result + Float.floatToIntBits(midX);
		result = prime * result + Float.floatToIntBits(midY);
		result = prime * result + Float.floatToIntBits(width);
		result = prime * result + Float.floatToIntBits(x1);
		result = prime * result + Float.floatToIntBits(x2);
		result = prime * result + Float.floatToIntBits(y1);
		result = prime * result + Float.floatToIntBits(y2);
		
		return result;
	}

	@Override
	public boolean equals(Object obj) 
	{
		if (this == obj)
			return true;
		
		if (obj == null)
			return false;
		
		if (getClass() != obj.getClass())
			return false;
		
		PDFBoundedObject other = (PDFBoundedObject) obj;
		
		if (Float.floatToIntBits(height) != Float.floatToIntBits(other.height))
			return false;
		
		if (Float.floatToIntBits(midX) != Float.floatToIntBits(other.midX))
			return false;
		
		if (Float.floatToIntBits(midY) != Float.floatToIntBits(other.midY))
			return false;
		
		if (Float.floatToIntBits(width) != Float.floatToIntBits(other.width))
			return false;
		
		if (Float.floatToIntBits(x1) != Float.floatToIntBits(other.x1))
			return false;
		
		if (Float.floatToIntBits(x2) != Float.floatToIntBits(other.x2))
			return false;
		
		if (Float.floatToIntBits(y1) != Float.floatToIntBits(other.y1))
			return false;
		
		if (Float.floatToIntBits(y2) != Float.floatToIntBits(other.y2))
			return false;
		
		return true;
	}

	public float getX1() {
		return x1;
	}

	public void setX1(float x1) {
		this.x1 = x1;
	}

	public float getY1() {
		return y1;
	}

	public void setY1(float y1) {
		this.y1 = y1;
	}

	public float getX2() {
		return x2;
	}

	public void setX2(float x2) {
		this.x2 = x2;
	}

	public float getY2() {
		return y2;
	}

	public void setY2(float y2) {
		this.y2 = y2;
	}

	public float getWidth() {
		return width;
	}

	public void setWidth(float width) {
		this.width = width;
	}

	public float getHeight() {
		return height;
	}

	public void setHeight(float height) {
		this.height = height;
	}

	public float getMidX() {
		return midX;
	}

	public void setMidX(float midX) {
		this.midX = midX;
	}

	public float getMidY() {
		return midY;
	}

	public void setMidY(float midY) {
		this.midY = midY;
	}
}
