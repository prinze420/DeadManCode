package com.rage.pdf.test;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.rage.siapp.extraction.pdf.PDFCharacter;
import com.rage.siapp.extraction.pdf.PDFLine;
import com.rage.siapp.extraction.pdf.PDFWord;
import com.rage.siapp.extraction.pdf.parse.CharacterCreator;
import com.rage.siapp.extraction.pdf.parse.LineExtraction;
import com.rage.siapp.extraction.pdf.parse.ParaExtraction;
import com.rage.siapp.extraction.pdf.parse.WordExtraction;

public class PDFTest {
	
	
	static List<PDFCharacter> characters;
	static List<PDFLine> finalListLine;
	static List<PDFWord> cleanFinalWord;
	
	
	@SuppressWarnings("unchecked")
	public static void main(String[] args) 
	{
		System.out.println("Start");
		try
		{
			
			//String fileName = "./testCase/881304_AYI.pdf" ;	
			//String fileName = "./testCase/048130a_2014-09.pdf";
			String fileName = "./testCase/contract.pdf" ;
			
			PDDocument document = PDDocument.load(new File(fileName)) ;
			List<PDPage> pages = document.getDocumentCatalog().getAllPages() ;
			Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= getPageCharacterMap(pages);
			for (Integer pgNO:pageWiseCharacterMap.keySet())
			{
				characters=pageWiseCharacterMap.get(pgNO);
			}
		
			
			/*for(int i=0;i<characters.size();i++)
			{
				System.out.print(characters.get(i));
			}*/
			
			LineExtraction lineExt = new LineExtraction(pageWiseCharacterMap);
			finalListLine=lineExt.createLines();
			
			//for(int i=0;i<finalListLine.size();i++)
				//System.out.println("Line "+finalListLine.get(i));
			
			
			ParaExtraction paraExt = new ParaExtraction(finalListLine);
			paraExt.createPara();
			
			
			//WordExtraction wordExt = new WordExtraction(finalListLine);
			//cleanFinalWord=wordExt.createWords();
			
			//for(int i=0;i<cleanFinalWord.size();i++)
				//System.out.println("word "+cleanFinalWord.get(i));
			
			
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("End");
	}

	private static Map<Integer, List<PDFCharacter>> getPageCharacterMap(List<PDPage> pages) 
	{
		Map<Integer,List<PDFCharacter>> pageWiseCharacterMap= new TreeMap<Integer,List<PDFCharacter>>();
		for(int i=0;i<pages.size();i++)
		{
			PDPage page=pages.get(i);
			CharacterCreator cc= new CharacterCreator();
			List<PDFCharacter> characters=cc.createCharacters(page);
			pageWiseCharacterMap.put(i, characters);
		}
		
		return pageWiseCharacterMap;
	}

}
