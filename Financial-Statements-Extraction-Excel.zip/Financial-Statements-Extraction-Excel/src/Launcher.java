import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Level;
import org.apache.log4j.Logger;

import com.rage.excel.ExcelFileProcessor;
import com.rage.excel.constants.Constants;
import com.rage.excel.logger.LoggerProperties;
import com.rage.extraction.statements.classifier.LabelMapper;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;
import com.rage.extraction.statements.train.commands.Export;
import com.rage.extraction.statements.train.commands.Train;

public class Launcher {

	public static void main(String args[]) {
		int filingId = -2;
		String fileName = "samples/CRU/2012.XLSX";
		List<String> fileNames = new ArrayList<String>();
		fileNames.add(fileName);
		List<Integer> uploadIds = new ArrayList<>();
		uploadIds.add(-1);
		new ExcelFileProcessor(filingId, true, uploadIds, fileNames).processFile();
		
//		String args1[] = {"RealEstate", "resource/sample.txt", "English"};
//		try {
//			String file = "resource/train/realestate-cru-fin-train.dataset";
//			File _file = new File(file);
//			_file.delete();
//			FinancialStatementExtractor.setLanguage(args1[2]);
//			Train.main(args1);
//			LabelMapper mapper = new LabelMapper(file, "RealEstate", "English");
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
	}
}