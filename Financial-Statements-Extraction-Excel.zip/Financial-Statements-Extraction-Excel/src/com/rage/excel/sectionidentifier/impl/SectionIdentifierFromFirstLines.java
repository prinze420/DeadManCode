package com.rage.excel.sectionidentifier.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.rage.document.pdf.utils.StringUtility;
import com.rage.excel.constants.Constants;
import com.rage.excel.headeridentifier.IHeaderIdentifier;
import com.rage.excel.headeridentifier.impl.HeaderIdentifierFromNumericColumns;
import com.rage.excel.model.Pair;
import com.rage.excel.model.Section;
import com.rage.excel.sectionidentifier.ISectionIdentifier;
import com.rage.excel.utility.metadareader.MetadataReader;

public class SectionIdentifierFromFirstLines implements ISectionIdentifier{

	private static List<Pair<String, String>> metadata = new ArrayList<>();
	
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);

	static{
		metadata = MetadataReader.readSectionIdentifyInitialRowsMetadata();
	}

	@Override
	public List<Section> identifySection(Sheet sheet) {
		logger.debug("Identifying section using lines above header lines.");
		List<Section> list = new ArrayList<>();
		IHeaderIdentifier headerIdentifier = new HeaderIdentifierFromNumericColumns();
		int headerIndex = headerIdentifier.identifyHeader(sheet);
		boolean found = false;
		if(headerIndex != -1){
			while(headerIndex > -1){
				headerIndex--;
				Row row = sheet.getRow(headerIndex);
				String rowContent = getRowText(row);
				for(Pair<String, String> pair : metadata){
					logger.trace("Comparing \"" + rowContent + "\" with \"" + pair.getB() + "\"");
					boolean result = StringUtility.doesKeywordMatchTokenSerialExcel(pair.getB(), rowContent);
					if(result){
						Section section = new Section(pair.getA(), null, null, null, null);
						list.add(section);
						found = true;
						logger.debug("Match Found");
						logger.debug("Input text : " + rowContent);
						logger.debug("Metadata text : " + pair.getB());
						logger.debug("Identified Section : " + pair.getA());
						break;
					}
				}
				if(found){
					break;
				}
			}
		}
		if(list.isEmpty()){
			logger.debug("Identification section using lines above header failed.");
		}
		return list;
	}

	private static String getRowText(Row row){
		if(row == null){
			return "";
		}
		StringBuilder builder = new StringBuilder();
		for(int index = 0; index < row.getLastCellNum(); index++){
			Cell cell = row.getCell(index);
			if(cell != null){
				builder.append(cell.toString() + " ");
			}
		}
		return builder.toString();
	}
}
