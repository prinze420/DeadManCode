package com.rage.excel.sectionidentifier.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;

import com.rage.document.pdf.utils.StringUtility;
import com.rage.excel.constants.Constants;
import com.rage.excel.headeridentifier.impl.HeaderIdentifierFromNumericColumns;
import com.rage.excel.model.NumericColumnData;
import com.rage.excel.model.Pair;
import com.rage.excel.model.Section;
import com.rage.excel.sectionidentifier.ISectionIdentifier;
import com.rage.excel.utility.metadareader.MetadataReader;

public class SectionIdentifierFromLineItem implements ISectionIdentifier{

	private static List<Pair<String, String>> metadata = new ArrayList<>();
	
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);

	static{
		metadata = MetadataReader.readSectionIdentifyLineItemMetadata();
	}

	@Override
	public List<Section> identifySection(Sheet sheet) {
		logger.debug("Identifying section using line items");
		List<Section> list = new ArrayList<>();
		HeaderIdentifierFromNumericColumns headerIdentifier = new HeaderIdentifierFromNumericColumns();
		List<NumericColumnData> numericColumns = headerIdentifier.getNumericColumnList(sheet);
		if(numericColumns == null || numericColumns.isEmpty()){
			return list;
		}
			
		Comparator<NumericColumnData> comparator = new Comparator<NumericColumnData>() {
			@Override
			public int compare(NumericColumnData column1, NumericColumnData column2) {
				return column1.getColumnIndex() - column2.getColumnIndex();
			}
		};
		NumericColumnData firstNumericColumn = Collections.min(numericColumns, comparator);
		boolean found = false;
		if(firstNumericColumn != null){
			int lineItemColumnIndex = firstNumericColumn.getColumnIndex() - 1;
			for(int index = 0; index < sheet.getLastRowNum(); index++){
				Row row = sheet.getRow(index);
				if(row == null){
					continue;
				}
				Cell cell = row.getCell(lineItemColumnIndex);
				if(cell != null){
					for(Pair<String, String> pair : metadata){
						logger.trace("Comparing \"" + cell.toString() + "\" with \"" + pair.getB() + "\"");
						boolean result = StringUtility.doesKeywordMatchTokenSerialExcel(pair.getB().toLowerCase(), cell.toString().toLowerCase().trim());
						if(result){
							Section section = new Section(pair.getA(), null, null, null, null);
							list.add(section);
							found = true;
							logger.debug("Match Found");
							logger.debug("Input text : " + cell.toString());
							logger.debug("Metadata text : " + pair.getB());
							logger.debug("Identified Section : " + pair.getA());
							break;
						}
					}
				}
				if(found){
					break;
				}
			}
		}
		if(list.isEmpty()){
			logger.debug("Identification section using line items failed.");
		}
		return list;
	}
}
