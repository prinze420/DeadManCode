package com.rage.excel.sectionidentifier.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Sheet;

import com.rage.excel.constants.Constants;
import com.rage.excel.model.Pair;
import com.rage.excel.model.Section;
import com.rage.excel.sectionidentifier.ISectionIdentifier;
import com.rage.excel.utility.metadareader.MetadataReader;

public class SectionIdentifierFromSheetName implements ISectionIdentifier{

	private static List<Pair<String, String>> metadata = new ArrayList<>();
	
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);
	
	static{
		metadata = MetadataReader.readSectionIdentifySheetNameMetadata();
	}
	
	@Override
	public List<Section> identifySection(Sheet sheet) {
		logger.debug("Identifying section using sheet name.");
		List<Section> list = new ArrayList<>();
		String sheetName = sheet.getSheetName();
		for(Pair<String, String> pair : metadata){
			logger.trace("Comparing \"" + sheetName + "\" with \"" + pair.getB() + "\"");
			if(sheetName.toLowerCase().contains(pair.getB().toLowerCase())){
				Section section = new Section(pair.getA(), null, null, null, null);
				list.add(section);
				logger.debug("Match Found");
				logger.debug("Input text : " + sheetName);
				logger.debug("Metadata text : " + pair.getB());
				logger.debug("Identified Section : " + pair.getA());
				break;
			}
		}
		if(list.isEmpty()){
			logger.debug("Identification section using sheet name failed.");
		}
		return list;
	}
}
