package com.rage.excel.sectionidentifier;

import java.util.List;

import org.apache.poi.ss.usermodel.Sheet;

import com.rage.excel.model.Section;

public interface ISectionIdentifier {

	public List<Section> identifySection(Sheet sheet);
}
