package com.rage.excel.subsection;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import com.rage.extraction.statements.classifier.LabelMapper;
import com.rage.extraction.statements.constant.Constants;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.mapping.IndustryMapReader;
import com.rage.extraction.statements.mapping.MapReader;
import com.rage.extraction.statements.train.MetaTree;
import com.rage.extraction.statements.train.Tree;

public class SubSectionHelper {

	private Map<String, ArrayList<ParserOutput>> sectionMap = null;
	private String industry;
	private String language;

	public SubSectionHelper(Map<String, ArrayList<ParserOutput>> sectionMap) {
		super();
		this.sectionMap = new TreeMap<>(sectionMap);
	}

	public void mapSubSection(){
		try{
			Map<String, LabelMapper> metaMap=new HashMap<String, LabelMapper>();
			String[] taxonomies=null;

			if (Constants.getProperty("train.src")!=null)
				taxonomies=Constants.getProperty("train.src").split("\\|");

			String taxonomyPath="";
			if (Constants.getProperty("train.path")!=null)
				taxonomyPath=Constants.getProperty("train.path");

			if (!taxonomyPath.endsWith(File.separator))
			{
				taxonomyPath+=File.separator;
			}
			if (!isDataSetAvailable() && taxonomies!=null)
			{
				for(String section:sectionMap.keySet())
				{
					for (String fileName:taxonomies)
					{
						String file = "";
						/*	if(!language.equalsIgnoreCase(""))
					file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";
				else*/
						file = fileName.substring(0,fileName.lastIndexOf(".txt"))+"-"+industry+".txt";

						if(!new File(taxonomyPath+file).exists())
						{
							continue;
						}
						if (file.startsWith(section) && new File(taxonomyPath+file).exists())
							metaMap.put(section.toUpperCase(), new LabelMapper(taxonomyPath+file, industry,language));
					}
				}
			} else
			{
				MapReader mapReader=new IndustryMapReader(industry, language);
				Tree tree=null;
				for(String section:sectionMap.keySet())
				{
					/*	if(section.equalsIgnoreCase("IS") ||  section.equalsIgnoreCase("BS") || section.equalsIgnoreCase("CF"))
			{
					 */	tree=new MetaTree();
					 //				 logger.info("section :"+section+"\n");
					 tree.setRoot(mapReader.getDataSet().getTrainDataSet().get(section));
					 metaMap.put(section.toUpperCase(), new LabelMapper(tree));
					 /*	}*/
				}
			}
		}catch(Exception e){

		}
	}

	private boolean isDataSetAvailable()
	{
		try{
			String fileName=Constants.getProperty("train.path");
			if (!fileName.trim().endsWith(System.getProperty("file.separator")))
				fileName+=System.getProperty("file.separator");
			if (Constants.getProperty("train.dataset")!=null)
			{

				if(language.equalsIgnoreCase("Spanish ITR"))
					fileName+=language+"/"+industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
				else
					fileName+=industry.toLowerCase()+"-"+Constants.getProperty("train.dataset");
			}
			else
				return false;
			if (new File(fileName).exists())
				return true;
		} catch(Exception e){

		}
		return false;
	}
}
