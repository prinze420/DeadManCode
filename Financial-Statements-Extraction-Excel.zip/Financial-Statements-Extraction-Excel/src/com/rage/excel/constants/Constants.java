package com.rage.excel.constants;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.MissingResourceException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

/**
 * @author kiran.umadi
 *
 */
public class Constants {
	public final static String LOGGER_NAME = "excelparser";
	private static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger(Constants.LOGGER_NAME);

	// Static constants
	public static final String EXTRACTOR_HOME = "extractor.home";
	public static final String EXTRACTOR_CONFIG = "extractor.config";
	public static final String EXTRACTOR_RESOURCE = "extractor.resource";
	public static final String COMMON_LOGGER = "common.parser.log";

	// Property file
	public static final String PROPERTY_FILENAME = "resource1/logger.properties";
	private static ResourceBundle resource = null;


	public static void loadResourceProperty() {

		if (resource == null) {

			File file = new File(PROPERTY_FILENAME);

			try {
				resource = new PropertyResourceBundle(new FileReader(file));
			} catch (IOException e) {
				logger.error(e);
				e.printStackTrace();
			}
		}
	}

	public static String getProperty(String propertyName) {

		if (resource == null)
			return null;

		try {

			return resource.getString(propertyName);

		} catch (MissingResourceException e) {
			return null;
		}
	}

}
