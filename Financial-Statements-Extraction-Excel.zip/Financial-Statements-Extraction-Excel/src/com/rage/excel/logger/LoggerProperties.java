package com.rage.excel.logger;

import java.io.File;

import org.apache.log4j.PropertyConfigurator;

import com.rage.excel.constants.Constants;

public final class LoggerProperties {
	private String logSubFolder = "logs" + File.separator;
	private String logFolderName = ".";

	public LoggerProperties() {
		Constants.loadResourceProperty();

		if (Constants.getProperty(Constants.EXTRACTOR_HOME) != null)
			logFolderName = Constants.getProperty(Constants.EXTRACTOR_HOME);

		if (!logFolderName.endsWith(File.separator))
			logFolderName = logFolderName + File.separator + logSubFolder;
		else
			logFolderName = logFolderName + logSubFolder;

		if (!new File(logFolderName).exists())
			new File(logFolderName).mkdir();
	}

	public void init() {
		init(null, null);
	}

	public void init(final String ID, final String userName) {
		String logFileName = Constants.LOGGER_NAME;

		if (ID != null && !ID.trim().isEmpty()) {
			System.setProperty("filingID", ID);
			if (Constants.getProperty(Constants.COMMON_LOGGER) != null
					&& !Constants.getProperty(Constants.COMMON_LOGGER).equalsIgnoreCase("Yes"))
				logFileName = ID;
		}

		if (userName != null && !userName.trim().isEmpty())
			System.setProperty("userName", userName);

		System.setProperty("logFileName", logFolderName + logFileName + ".log");
		String propertyFile = Constants.PROPERTY_FILENAME;
		PropertyConfigurator.configure(propertyFile);
	}
}
