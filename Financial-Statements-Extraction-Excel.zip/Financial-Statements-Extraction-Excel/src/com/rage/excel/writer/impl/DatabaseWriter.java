package com.rage.excel.writer.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.rage.excel.writer.IDataWriter;
import com.rage.excel.writer.ParserOutputHelper;
import com.rage.extraction.statements.db.ParserOutput;

public class DatabaseWriter implements IDataWriter {


	private Connection connection;

	public DatabaseWriter(Connection connection) {
		super();
		this.connection = connection;
	}

	@Override
	public void writeData(List<ParserOutput> data) {
		if(data != null && !data.isEmpty()){
			int filingId = data.get(0).getStmtID();
//			deletePreviousData(filingId);
			PreparedStatement statement = null;

			try {
				statement = ParserOutputHelper.getStatement(connection);
				for(ParserOutput po : data){
					ParserOutputHelper.populateStatement(statement, po);
					statement.addBatch();
				}
				statement.executeBatch();
				statement.clearBatch();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch(Exception e){
				e.printStackTrace();
			}
			if(statement != null){
				try {
					statement.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void deletePreviousData(int filingId){
		String query = "DELETE FROM PARSER_OUTPUT WHERE FILING_ID = ?";
		PreparedStatement pStatement = null;
		try {
			pStatement = connection.prepareStatement(query);
			pStatement.setInt(1, filingId);
			pStatement.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(pStatement != null){
			try {
				pStatement.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
