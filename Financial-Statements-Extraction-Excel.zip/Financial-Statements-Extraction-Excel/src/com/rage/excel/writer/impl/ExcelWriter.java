package com.rage.excel.writer.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.rage.excel.constants.Constants;
import com.rage.excel.writer.IDataWriter;
import com.rage.excel.writer.ParserOutputHelper;
import com.rage.extraction.statements.db.ParserOutput;

public class ExcelWriter implements IDataWriter{

	private String fileName;
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);
	
	public ExcelWriter(String fileName) {
		super();
		this.fileName = fileName;
	}


	@Override
	public void writeData(List<ParserOutput> data) {
		logger.info("Writing to file...");
		// TODO Auto-generated method stub
		List<String[]> output = new ArrayList<>(data.size());
		String[] header = ParserOutputHelper.getHeaders();
		output.add(header);
		for(ParserOutput po : data){
			String[] values = ParserOutputHelper.getValues(po);
			output.add(values);
		}
		writeStringData(output);
		logger.info("File Writing complete.");
	}
	
	public void writeStringData(List<String[]> data){
		final int SECTION_COLUMN_INDEX = 1;
		fileName = this.fileName.trim();
		Workbook workbook = null;
		if(fileName.endsWith("xlsx") || fileName.endsWith("XLSX")){
			workbook = new XSSFWorkbook();
		}
		else if(fileName.endsWith("xls") || fileName.endsWith("XLS")){
			workbook = new HSSFWorkbook();
		}
		
		for(int rowIndex = 1; rowIndex < data.size(); rowIndex++){
			String[] _row = data.get(rowIndex);
			String section = _row[SECTION_COLUMN_INDEX];
			Sheet sheet = workbook.getSheet(section.toUpperCase());
			if(sheet == null){
				sheet = workbook.createSheet(section.toUpperCase());
				createRow(data.get(0), sheet, 0);
			}
			createRow(_row, sheet, -1);			
		}
		if(data == null || data.isEmpty() || data.size() == 1){
			Sheet sheet = workbook.createSheet();
			Row row = sheet.createRow(0);
			Cell cell = row.createCell(0);
			cell.setCellValue("Unable to detect Section");
		}
		try {
			File file = new File(fileName);
			if(file.exists()){
				file.delete();
			}
			workbook.write(new FileOutputStream(fileName));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void createRow(String[] _row, Sheet sheet, int rowNum){
		if(rowNum == -1){
			rowNum = sheet.getLastRowNum() + 1;
		}
		Row row = sheet.createRow(rowNum);
		for(int index = 0; index < _row.length; index++){
			Cell cell = row.createCell(index);
			cell.setCellValue(_row[index]);
		}
	}
}
