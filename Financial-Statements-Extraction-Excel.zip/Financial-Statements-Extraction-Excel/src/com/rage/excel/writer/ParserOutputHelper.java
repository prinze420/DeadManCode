package com.rage.excel.writer;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.rage.excel.constants.Constants;
import com.rage.extraction.statements.db.ParserOutput;

public class ParserOutputHelper {

	private Method getterMethod;
	private Method setterMethod;
	private String dbColumnName;
	private String fileColumnName;
	
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);

	private static final List<ParserOutputHelper> helpers = new ArrayList<>();
	static {
		init();
	}

	public ParserOutputHelper(Method getterMethod, Method setterMethod, String dbColumnName, String fileColumnName) {
		super();
		this.getterMethod = getterMethod;
		this.setterMethod = setterMethod;
		this.dbColumnName = dbColumnName;
		this.fileColumnName = fileColumnName;
	}

	public Method getGetterMethod() {
		return getterMethod;
	}

	public Method getSetterMethod() {
		return setterMethod;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}

	public String getFileColumnName() {
		return fileColumnName;
	}



	public static PreparedStatement getStatement(Connection connection){
		StringBuilder queryBuilder = new StringBuilder("INSERT INTO PARSER_OUTPUT (");
		for(int index = 0; index < helpers.size(); index++){
			ParserOutputHelper helper = helpers.get(index);
			queryBuilder.append(helper.getDbColumnName() + ", ");
		}

		if(queryBuilder.length() > 0){
			queryBuilder.setLength(queryBuilder.length() - 1);
		}

		queryBuilder.append(") VALUES (");

		for(int index = 0; index < helpers.size(); index++){
			queryBuilder.append("?, ");
		}

		if(queryBuilder.length() > 0){
			queryBuilder.setLength(queryBuilder.length() - 1);
		}

		queryBuilder.append(")");
		logger.info(queryBuilder);
		try {
			PreparedStatement statement = connection.prepareStatement(queryBuilder.toString());
			return statement;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	public static void populateStatement(PreparedStatement statement, ParserOutput po){
		for(int index = 0; index < helpers.size(); index++){
			ParserOutputHelper helper = helpers.get(index);
			Method setterMethod = helper.getSetterMethod();
			Method getterMethod = helper.getGetterMethod();

			try {
				Object obj = getterMethod.invoke(po);
				if(obj == null){
					if(obj instanceof String){
						statement.setNull(index + 1, Types.VARCHAR);
					}
					else{
						statement.setNull(index + 1, Types.NUMERIC);
					}
				}
				else{
					setterMethod.invoke(statement, index + 1, obj);
				}

			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public static String[] getHeaders(){
		List<String> header = new ArrayList<>(helpers.size());
		for(ParserOutputHelper helper : helpers){
			header.add(helper.getFileColumnName());
		}
		return header.toArray(new String[header.size()]);
	}

	public static String[] getValues(ParserOutput po){
		List<String> output = new ArrayList<>(helpers.size());
		for(ParserOutputHelper helper : helpers){
			Method getterMethod = helper.getGetterMethod();
			try {
				Object object = getterMethod.invoke(po);
				if(object == null){
					output.add(null);
				}
				else{
					output.add(object.toString());
				}

			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				System.out.println(getterMethod.getName());
				e.printStackTrace();
			}
		}
		return output.toArray(new String[output.size()]);
	}


	private static final String PO_VAL_COLUMN_NAME = "PO_VAL";
	private static final String PO_AS_REP_VAL_COLUMN_NAME = "PO_AS_REP_VAL";


	public static void init(){
		ParserOutputHelper helper = null;
		helper = getParserOutputHelper("getStmtID", "setLong", long.class, "FILING_ID", "FILING_ID");
		helpers.add(helper);
		helper = getParserOutputHelper("getSection", "setString", String.class, "PO_SECTION", "PO_SECTION");
		helpers.add(helper);
		helper = getParserOutputHelper("getSubSection", "setString", String.class, "PO_SUB_SECTION", "PO_SUB_SECTION");
		helpers.add(helper);
		helper = getParserOutputHelper("getIndexOrder", "setLong", long.class, "PO_INDEX_ORDER", "PO_INDEX_ORDER");
		helpers.add(helper);
		helper = getParserOutputHelper("getWorqueID", "setLong", long.class, "UPLOAD_ID", "UPLOAD_ID");
		helpers.add(helper);
		helper = getParserOutputHelper("getBreakups", "setString", String.class, "PO_BREAKUP", "PO_BREAKUP");
		helpers.add(helper);
		helper = getParserOutputHelper("getTableID", "setLong", long.class, "PO_TABLE_ID", "PO_TABLE_ID");
		helpers.add(helper);
		helper = getParserOutputHelper("getAsRepLabel", "setString", String.class, "PO_AS_REP_LABEL", "PO_AS_REP_LABEL");
		helpers.add(helper);
		for(int index = 1; index < 31; index++){
			helper = getParserOutputHelper("getValue" + index, "setString", String.class, PO_VAL_COLUMN_NAME + index, PO_VAL_COLUMN_NAME + index);
			helpers.add(helper);

			helper = getParserOutputHelper("getValue" + index, "setString", String.class, PO_AS_REP_VAL_COLUMN_NAME + index, PO_AS_REP_VAL_COLUMN_NAME + index);
			helpers.add(helper);
		}
	}

	private static ParserOutputHelper getParserOutputHelper(String getterMethodName, String setterMethodName, 
			Class<?> param, String dbColumnName, String fileColumnName)
	{
		try {
			Method getterMethod = ParserOutput.class.getMethod(getterMethodName);

			Method setterMethod = PreparedStatement.class.getMethod(setterMethodName, int.class, param);
			ParserOutputHelper helper = new ParserOutputHelper(getterMethod, setterMethod, dbColumnName, fileColumnName);
			return helper;
		} catch (NoSuchMethodException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
