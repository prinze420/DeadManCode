package com.rage.excel.writer;

import java.util.List;

import com.rage.extraction.statements.db.ParserOutput;

public interface IDataWriter {

	public void writeData(List<ParserOutput> data);
}
