package com.rage.excel.model;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;

public class Section {
	
	private String sectionName;
	private String filePath;
	private Sheet sheet;
	private Cell startCell;
	private Cell endCell;
	public Section(String sectionName, String filePath, Sheet sheet, Cell startCell, Cell endCell) {
		super();
		this.sectionName = sectionName;
		this.filePath = filePath;
		this.sheet = sheet;
		this.startCell = startCell;
		this.endCell = endCell;
	}
	public String getSectionName() {
		return sectionName;
	}
	public void setSectionName(String sectionName) {
		this.sectionName = sectionName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Sheet getSheet() {
		return sheet;
	}
	public void setSheet(Sheet sheet) {
		this.sheet = sheet;
	}
	public Cell getStartCell() {
		return startCell;
	}
	public void setStartCell(Cell startCell) {
		this.startCell = startCell;
	}
	public Cell getEndCell() {
		return endCell;
	}
	public void setEndCell(Cell endCell) {
		this.endCell = endCell;
	}
	@Override
	public String toString() {
		return "Section [sectionName=" + sectionName + ", filePath=" + filePath + ", sheet=" + sheet + ", startCell="
				+ startCell + ", endCell=" + endCell + "]";
	}
}
