package com.rage.excel.model;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;

public class NumericColumnData {
	private int columnIndex;
	private int startRowIndex;
	private Sheet sheet;

	public NumericColumnData(int columnIndex, int startRowIndex, Sheet sheet) {
		super();
		this.columnIndex = columnIndex;
		this.startRowIndex = startRowIndex;
		this.sheet = sheet;
	}

	public int getColumnIndex() {
		return columnIndex;
	}

	public int getStartRowIndex() {
		return startRowIndex;
	}

	public Sheet getSheet() {
		return sheet;
	}

	@Override
	public String toString() {
		Cell cell = sheet.getRow(startRowIndex).getCell(columnIndex);
		return "NumericColumnData [columnIndex=" + columnIndex + ", startRowIndex=" + startRowIndex + ", cell=" + cell
				+ "]";
	}
}
