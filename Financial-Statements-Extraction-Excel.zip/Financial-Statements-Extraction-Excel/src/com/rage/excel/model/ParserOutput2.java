package com.rage.excel.model;

import java.io.Serializable;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;

/**
 * Stores the 
 *
 */
public final class ParserOutput2 implements Serializable {

	private static final long serialVersionUID = -6027340279914938585L;

	private long poID;
	private int filingId;
	private int uploadId;
	private int poIndexOrder;
	private int tableID;
	private String breakups;
	
	private String section;
	private String subSection;
	
	private Cell asRepLabel;
	private Map<String, Cell> poval = new TreeMap <String, Cell>();

	private static final String PO_VAL_COLUMN_NAME = "PO_VAL";
	private static final String PO_AS_REP_VAL_COLUMN_NAME = "PO_AS_REP_VAL";
	private static final int MAX_PO_VAL_COUNT = 10;
	
	public ParserOutput2(){
		this.breakups = "NO";
	}
	
	public void setPoVal(int index, Cell cell){
		if(index > 0 && index <= MAX_PO_VAL_COUNT){
			String poValColumnName = PO_VAL_COLUMN_NAME + index;
			poval.put(poValColumnName, cell);
			
			poValColumnName = PO_AS_REP_VAL_COLUMN_NAME + index;
			poval.put(poValColumnName, cell);
		}
	}

	public Cell getPoVal(String PoValColumnName){
		if(PoValColumnName != null && !PoValColumnName.trim().isEmpty()){
			PoValColumnName = PoValColumnName.trim().toLowerCase();
			return poval.get(PoValColumnName);
		}
		return null;
	}
	
	

	public long getPoID() {
		return poID;
	}

	public void setPoID(long poID) {
		this.poID = poID;
	}

	public int getFilingId() {
		return filingId;
	}

	public void setFilingId(int filingId) {
		this.filingId = filingId;
	}

	public int getUploadId() {
		return uploadId;
	}

	public void setUploadId(int uploadId) {
		this.uploadId = uploadId;
	}

	public int getPoIndexOrder() {
		return poIndexOrder;
	}

	public void setPoIndexOrder(int poIndexOrder) {
		this.poIndexOrder = poIndexOrder;
	}

	public int getTableID() {
		return tableID;
	}

	public void setTableID(int tableID) {
		this.tableID = tableID;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getSubSection() {
		return subSection;
	}

	public void setSubSection(String subSection) {
		this.subSection = subSection;
	}

	public Cell getAsRepLabel() {
		return asRepLabel;
	}

	public void setAsRepLabel(Cell asRepLabel) {
		this.asRepLabel = asRepLabel;
	}

	@Override
	public String toString() {
		return "ParserOutput [asRepLabel=" + asRepLabel + ", poval=" + poval + "]";
	}
	
	public String[] fillData(){
		List<String> list = new ArrayList<>(8 + MAX_PO_VAL_COUNT * 2);
		list.add("" + filingId);
		list.add("" + section);
		list.add("" + subSection);
		list.add("" + poIndexOrder);
		list.add("" + uploadId);
		list.add("" + breakups);
		list.add("" + tableID);
		
		setString(list, asRepLabel);
		
		Cell cell = null;
		for(int index = 1; index <= MAX_PO_VAL_COUNT; index++){
			cell = poval.get(PO_VAL_COLUMN_NAME + index);
			setString(list, cell);
			
			cell = poval.get(PO_AS_REP_VAL_COLUMN_NAME + index);
			setString(list, cell);
		}
		return list.toArray(new String[list.size()]);
	}
	
	void setString(List<String> values, Cell cell){
		String cellContent = setString(cell);
		if(cellContent == null){
			values.add(null);
			return;
		}
		values.add(cellContent);
	}
	
	public void fillData(PreparedStatement statement){
		int columnIndex = 1;
		try {
			statement.setLong(columnIndex++, filingId);
			statement.setString(columnIndex++, section);
			statement.setString(columnIndex++, subSection);
			statement.setLong(columnIndex++, poIndexOrder);
			statement.setLong(columnIndex++, uploadId);
			statement.setString(columnIndex++, breakups);
			statement.setLong(columnIndex++, tableID);
			
			setString(statement, asRepLabel, columnIndex);
			columnIndex++;
			Cell cell = null;
			for(int index = 1; index <= MAX_PO_VAL_COUNT; index++){
				cell = poval.get(PO_VAL_COLUMN_NAME + index);
				setString(statement, cell, columnIndex);
				columnIndex++;
				
				cell = poval.get(PO_AS_REP_VAL_COLUMN_NAME + index);
				setString(statement, cell, columnIndex);
				columnIndex++;
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private void setString(PreparedStatement statement, Cell cell, int index) throws SQLException{
		String cellContent = setString(cell);
		
		if(cellContent == null){
			statement.setNull(index, Types.VARCHAR);
			return;
		}
		statement.setString(index, cellContent);
	}
	
	private String setString(Cell cell){
		if(cell == null){
			return null;
		}
		if(cell.getCellType() == Cell.CELL_TYPE_FORMULA){
			FormulaEvaluator evaluator = cell.getSheet().getWorkbook().getCreationHelper().createFormulaEvaluator();
			CellValue cellValue = evaluator.evaluate(cell);
			String cellContent = "" + cellValue.getNumberValue();
			return cellContent;
		}
		else{
			return cell.toString();
		}
	}
	
	public static PreparedStatement getPrepearedStatement(Connection connection){
		StringBuilder query = new StringBuilder("INSERT INTO PARSER_OUTPUT (FILING_ID, PO_SECTION, "
				+ "PO_SUB_SECTION, PO_INDEX_ORDER, UPLOAD_ID, PO_BREAKUP, PO_TABLE_ID, PO_AS_REP_LABEL, ");
		
		for(int index = 1; index <= MAX_PO_VAL_COUNT; index++){
			query.append(PO_VAL_COLUMN_NAME + index + ", ");
			query.append(PO_AS_REP_VAL_COLUMN_NAME + index + ", ");
		}
		
		query.setLength(query.length() - 2);
		query.append(") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ");
		
		for(int index = 1; index <= MAX_PO_VAL_COUNT; index++){
			query.append("?, ?, ");
		}
		
		query.setLength(query.length() - 2);
		query.append(")");
		
		PreparedStatement statement = null;
		try {
			statement = connection.prepareStatement(query.toString());
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return statement;
	}
	
	public static String[] getHeaderRow(){
		List<String> list = new ArrayList<>(8 + MAX_PO_VAL_COUNT * 2);
		list.add("FILING_ID");
		list.add("PO_SECTION");
		list.add("PO_SUB_SECTION");
		list.add("PO_INDEX_ORDER");
		list.add("UPLOAD_ID");
		list.add("PO_BREAKUP");
		list.add("PO_TABLE_ID");
		list.add("PO_AS_REP_LABEL");
		
		for(int index = 1; index <= MAX_PO_VAL_COUNT; index++){
			String columnName = (PO_VAL_COLUMN_NAME + index);
			list.add(columnName);
			
			columnName = (PO_AS_REP_VAL_COLUMN_NAME + index);
			list.add(columnName);
		}
		return list.toArray(new String[list.size()]);
	}
	
	private static void setSequence(){
		List<ParserOutputHelper> helpers = new ArrayList<>();
		
		Method method = null;
		String dbColumnName = null;
		String columnName = null;
		List<Object> parameters = new ArrayList<>();
		
		
		
		try {
			method = ParserOutput2.class.getMethod("getFilingId");
			dbColumnName = "FILING_ID";
			columnName = "FILING_ID";
			parameters = new ArrayList<>();
//			ParserOutputHelper helper = new ParserOutputHelper(dbColumnName, columnName, method, parameters);
//			helpers.add(helper);
			
			
		} catch (NoSuchMethodException | SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}

class ParserOutputHelper{
	private String dbColumnName;
	private String columnName;
	private Method getterMethod;
	private Method setterMethod;
	private List<Object> parameters;

	public ParserOutputHelper(String dbColumnName, String columnName, Method getterMethod, Method setterMethod,
			List<Object> parameters) {
		super();
		this.dbColumnName = dbColumnName;
		this.columnName = columnName;
		this.getterMethod = getterMethod;
		this.setterMethod = setterMethod;
		this.parameters = parameters;
	}

	public String getDbColumnName() {
		return dbColumnName;
	}
	
	public String getColumnName() {
		return columnName;
	}
	
	public List<Object> getParameters() {
		return parameters;
	}
	
	public Method getGetterMethod() {
		return getterMethod;
	}
	
	public Method getSetterMethod() {
		return setterMethod;
	}
}