package com.rage.excel.utility;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;

public class DBConnection {

	private static final String PROPERTY_FILENAME = "resource1/db.details.properties"; 
	private static Connection connection = null;
	private static ResourceBundle resource = null;
	
	static{
		loadPropertyFile();
	}
	
	public static Connection getNewConnection(){
		String driver = resource.getString("jdbc.driver");
		String url = resource.getString("rage.database.source_url");
		String userName = resource.getString("rage.user");
		String password = resource.getString("rage.pwd");
		Connection connection = getConnection(driver, url, userName, password);
		return connection;
	}
	
	public static synchronized Connection getConnection(){
		if(connection == null){
			connection = getNewConnection();
		}
		return connection;
	}
	
	public static void closeConnection(Connection connection){
		if(connection != null){
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	public static void closeConnection(){
		closeConnection(connection);
	}
	
	private static void loadPropertyFile(){
		File file = new File(PROPERTY_FILENAME);
		try {
			resource = new PropertyResourceBundle(new FileReader(file));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private static Connection getConnection(String driver, String url, String userName, String password){
		Connection connection = null;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, userName, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}
}
