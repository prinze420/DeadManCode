package com.rage.excel.utility.metadareader.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.rage.excel.utility.metadareader.IMetadataReader;

public class FileMetadataReader implements IMetadataReader {

	@Override
	public List<String[]> read(String fileName) {
		File file = new File(fileName);
		List<String[]> output = new ArrayList<>();
		if(!file.exists()){
			return output;
		}
		try {
			BufferedReader reader = new BufferedReader(new FileReader(file));
			String line;
			while((line = reader.readLine()) != null){
				if(line.contains("#") || line.trim().isEmpty()){
					continue;
				}
				String split[] = line.split("\t");
				output.add(split);
			}
			reader.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return output;
	}

}
