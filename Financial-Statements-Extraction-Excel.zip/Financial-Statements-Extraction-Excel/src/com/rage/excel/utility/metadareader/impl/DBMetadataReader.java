package com.rage.excel.utility.metadareader.impl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.rage.excel.utility.metadareader.IMetadataReader;

public class DBMetadataReader implements IMetadataReader {

	private Connection connection;

	public DBMetadataReader(Connection connection) {
		super();
		this.connection = connection;
	}

	@Override
	public List<String[]> read(String query) {
		List<String[]> list = new ArrayList<>();
		Statement statement;
		try {
			statement = connection.createStatement();
			ResultSet rs = statement.executeQuery(query);
			ResultSetMetaData rsmt = rs.getMetaData();
			while(rs.next()){
				String row[] = new String[rsmt.getColumnCount()];
				for(int index = 1; index <= rsmt.getColumnCount(); index++){
					Object object = rs.getObject(index);
					if(object != null){
						row[index - 1] = object.toString();
					}
					else{
						row[index - 1] = "";
					}
				}
				list.add(row);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
}
