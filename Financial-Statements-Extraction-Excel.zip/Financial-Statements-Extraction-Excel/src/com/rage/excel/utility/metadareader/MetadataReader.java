package com.rage.excel.utility.metadareader;

import java.util.ArrayList;
import java.util.List;

import com.rage.excel.model.Pair;
import com.rage.excel.utility.metadareader.impl.FileMetadataReader;

public class MetadataReader {
	
	private static IMetadataReader fileMetadataReader = new FileMetadataReader();
//	private static IMetadataReader dbMetadataReader = new DBMetadataReader(DBConnection.getConnection());

	public static List<Pair<String, String>> readSectionIdentifySheetNameMetadata(){
		return readSectionIdentifyMetadata("resource1/SectionIdentifierSheetNameKeywords.txt");
	}
	
	public static List<Pair<String, String>> readSectionIdentifyInitialRowsMetadata(){
		return readSectionIdentifyMetadata("resource1/SectionIderntifierInitialLinesKeywords.txt");
	}
	
	public static List<Pair<String, String>> readSectionIdentifyLineItemMetadata(){
		return readSectionIdentifyMetadata("resource1/SectionIdentifierLineItemKeywords.txt");
	}
	
	private static List<Pair<String, String>> readSectionIdentifyMetadata(String fileName){
		List<String[]> list = fileMetadataReader.read(fileName);
		List<Pair<String, String>> output = new ArrayList<>();
		for(String[] split : list){
			Pair<String, String> pair = new Pair<String, String>(split[0], split[1]);
			output.add(pair);
		}
		return output;
	}
}
