package com.rage.excel.utility.metadareader;

import java.util.List;

public interface IMetadataReader {

	public List<String[]> read(String input);
}
