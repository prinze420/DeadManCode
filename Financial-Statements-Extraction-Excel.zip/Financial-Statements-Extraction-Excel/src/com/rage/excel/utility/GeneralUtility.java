package com.rage.excel.utility;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;

public class GeneralUtility {
	
	public static String cleanCellContent(Cell cell) {
		String cellContent = cell.toString().trim();
		cellContent = cellContent.replaceAll("%", "");
		cellContent = cellContent.replaceAll("$", "");
		return cellContent;
	}

	public static boolean isEmptyRow(Row row) {
		int consecutiveNullColumnCount = 0;
		final int MAX_ALLOWED_EMPTY_COLUMN_COUNT = 15;
		if (row == null) {
			return true;
		}
		for (int columnIndex = 0; columnIndex < row.getLastCellNum(); columnIndex++) {
			Cell cell = row.getCell(columnIndex);
			if (cell == null || cell.getCellType() == Cell.CELL_TYPE_BLANK || cell.toString().trim().isEmpty()) {
				consecutiveNullColumnCount++;
				if (consecutiveNullColumnCount == (row.getLastCellNum() - 1)
						|| consecutiveNullColumnCount == MAX_ALLOWED_EMPTY_COLUMN_COUNT) {
					return true;
				}
			} else {
				consecutiveNullColumnCount = 0;
			}
		}
		return false;
	}
	
	public static boolean isEmptyColumn(Sheet sheet, int columnIndex){
		return isEmptyColumn(sheet, 0, columnIndex);
	}
	
	public static boolean isEmptyColumn(Sheet sheet, int startRowIndex, int columnIndex){
		for(int index = startRowIndex; index < sheet.getLastRowNum(); index++){
			Row row = sheet.getRow(index);
			if(row == null){
				continue;
			}
			Cell cell = row.getCell(columnIndex);
			if(cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK){
				return false;
			}
		}
		return true;
	}
	
	public static String mergeCellContent(List<Cell> cells){
		StringBuilder builder = new StringBuilder();
		for(Cell cell : cells){
			if(cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK){
				builder.append(cell.toString() + " ");
			}
		}
		if(builder.length() > 0){
			builder.setLength(builder.length() - 1);
		}
		return builder.toString();
	}
	
	private static DecimalFormat df = new DecimalFormat("#");
	static{
		df.setMaximumFractionDigits(2);
	}
	
	public static String cellToString(Cell cell){
		if(cell == null){
			return null;
		}
		if(cell.getCellType() == Cell.CELL_TYPE_FORMULA){
			FormulaEvaluator formula = cell.getSheet().getWorkbook().getCreationHelper().createFormulaEvaluator();
			try{
				CellValue value = formula.evaluate(cell);
//				BigDecimal decimal = new BigDecimal("" + value.getNumberValue());
				return df.format(value.getNumberValue());
//				return return "" + decimal.toPlainString();
//				return "" + value.getNumberValue();
			} catch(Exception e){
				if(cell instanceof XSSFCell){
					return ((XSSFCell)cell).getRawValue();
				}
			}
		}
		else if(cell.getCellType() == Cell.CELL_TYPE_NUMERIC){
//			BigDecimal decimal = new BigDecimal("" + cell.getNumericCellValue());
//			return "" + new Double(cell.getNumericCellValue()).doubleValue();
//			return "" + decimal.toPlainString();
			return df.format(cell.getNumericCellValue());
			
		}
		return cell.toString();
	}
}
