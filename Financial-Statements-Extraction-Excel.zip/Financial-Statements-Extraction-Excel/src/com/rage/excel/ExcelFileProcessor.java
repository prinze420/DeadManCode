package com.rage.excel;

import java.io.*;
import java.util.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.rage.excel.constants.Constants;
import com.rage.excel.headeridentifier.impl.HeaderIdentifierFromNumericColumns;
import com.rage.excel.logger.LoggerProperties;
import com.rage.excel.model.NumericColumnData;
import com.rage.excel.model.Section;
import com.rage.excel.sectionidentifier.ISectionIdentifier;
import com.rage.excel.sectionidentifier.impl.SectionIdentifierFromFirstLines;
import com.rage.excel.sectionidentifier.impl.SectionIdentifierFromLineItem;
import com.rage.excel.sectionidentifier.impl.SectionIdentifierFromSheetName;
import com.rage.excel.utility.DBConnection;
import com.rage.excel.utility.GeneralUtility;
import com.rage.excel.utility.StatementAttributes;
import com.rage.excel.writer.IDataWriter;
import com.rage.excel.writer.impl.DatabaseWriter;
import com.rage.excel.writer.impl.ExcelWriter;
import com.rage.extraction.statements.db.ParserOutput;
import com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor;

public class ExcelFileProcessor {

	private int filingId;
	private List<String> inputFiles = new ArrayList<>();
	private List<Integer> uploadIds = new ArrayList<>();
	private String industry = "RealEstate";
	private String language = "English";
	private boolean standalone;
	private String currentFile;
	private int currentUploadId;
	private HeaderIdentifierFromNumericColumns headerIdentifier = new HeaderIdentifierFromNumericColumns();
	private Sheet currentSheet;
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);
	
	private List<ParserOutput> allPO = new ArrayList<>();

	public ExcelFileProcessor(int filingId, boolean standalone, List<Integer> uploadIds, List<String> inputFiles) {
		super();
		this.filingId = filingId;
		this.standalone = standalone;
		this.inputFiles = new ArrayList<>(inputFiles);
		this.uploadIds = new ArrayList<>(uploadIds);
	}

	public void processFile() {
		LoggerProperties logger = new LoggerProperties();
		logger.init("" + filingId, null);
		allPO = new ArrayList<>();
		for(int fileIndex = 0; fileIndex < inputFiles.size(); fileIndex++){
			String fileName = inputFiles.get(fileIndex);
			int uploadId = uploadIds.get(fileIndex);
			processFile(fileName, uploadId);
		}
		writeData(allPO);
		DBConnection.closeConnection();
	}

	private void processFile(String fileName, int uploadId){
		logger.info("Processing file " + fileName);
		currentFile = fileName;
		currentUploadId = uploadId;
		Workbook workbook = null;
		try {
			if (fileName.toLowerCase().endsWith("xlsx")) {
				workbook = new XSSFWorkbook(new FileInputStream(fileName));
			} else if (fileName.toLowerCase().endsWith("xls")) {
				workbook = new HSSFWorkbook(new FileInputStream(fileName));
			}
			if (workbook != null) {
				FinancialStatementExtractor.setIndustry(industry);
				FinancialStatementExtractor.setLanguage(language);

				workbook.setForceFormulaRecalculation(true);
//				LabelMapper mapper = new LabelMapper("resource/realestate-cru-fin-train.dataset", industry, language); 
				
				for (int index = 1; index < workbook.getNumberOfSheets(); index++) {
					Sheet sheet = workbook.getSheetAt(index);
					logger.info("Processing Sheet " + sheet.getSheetName());
					currentSheet = sheet;
					headerIdentifier.identifyHeader(sheet);
					mergeLineItemCells();
					List<Section> sections = identifySection(sheet);
					if(sections != null && !sections.isEmpty()){
						List<ParserOutput> list = getParserOutputList(sheet, sections);
//						mapper.map(list);
						allPO.addAll(list);
					}
					break;
				}
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		logger.info("File processing complete " + fileName);
	}

	private List<Section> identifySection(Sheet sheet) {
		logger.info("Identifying section");
		List<ISectionIdentifier> sectionIdentifiers = new ArrayList<>();
		sectionIdentifiers.add(new SectionIdentifierFromSheetName());
		sectionIdentifiers.add(new SectionIdentifierFromLineItem());
		sectionIdentifiers.add(new SectionIdentifierFromFirstLines());
		for (ISectionIdentifier sectionIdentifier : sectionIdentifiers) {
			if (sectionIdentifier != null) {
				List<Section> sections = sectionIdentifier.identifySection(sheet);
				if (!sections.isEmpty()) {
					logger.info("Identified section is : " + sections);
					return sections;
				}
			}
		}
		logger.info("Section identification failed");
		return null;
	}

	private void mergeLineItemCells(){
		int headerRowIndex = headerIdentifier.getHeaderIndex();
		List<NumericColumnData> numericColumns = headerIdentifier.getNumericColumnList();
		if(numericColumns == null || numericColumns.isEmpty()){
			return;
		}
		Comparator<NumericColumnData> comparator = new Comparator<NumericColumnData>() {
			@Override
			public int compare(NumericColumnData column1, NumericColumnData column2) {
				return column1.getColumnIndex() - column2.getColumnIndex();
			}
		};
		NumericColumnData firstNumericColumn = Collections.min(numericColumns, comparator);
		int lineItemColumnIndex = firstNumericColumn.getColumnIndex() - 1;
		while(lineItemColumnIndex == -1){
			numericColumns.remove(firstNumericColumn);
			if(numericColumns.isEmpty()){
				return;
			}
			firstNumericColumn = Collections.min(numericColumns, comparator);
			lineItemColumnIndex = firstNumericColumn.getColumnIndex() - 1;
		}
		for(int rowIndex = headerRowIndex; rowIndex < currentSheet.getLastRowNum(); rowIndex++){
			List<Cell> cells = new ArrayList<>();
			Row row = currentSheet.getRow(rowIndex);
			if(row != null){
				for(int columnIndex = 0; columnIndex <= lineItemColumnIndex; columnIndex++){
					Cell cell = row.getCell(columnIndex);
					cells.add(cell);
				}
				String mergedCellContent = GeneralUtility.mergeCellContent(cells);
				Cell cell = currentSheet.getRow(rowIndex).getCell(lineItemColumnIndex);
				if(cell != null){
					cell.setCellValue(mergedCellContent);
				}
			}

		}
	}

	private List<ParserOutput> getParserOutputList(Sheet sheet, List<Section> sections) {
		logger.info("Generating Parser Output Objects");
		int headerRowIndex = headerIdentifier.getHeaderIndex();
		List<NumericColumnData> numericColumns = headerIdentifier.getNumericColumnList();
		Comparator<NumericColumnData> comparator = new Comparator<NumericColumnData>() {
			@Override
			public int compare(NumericColumnData column1, NumericColumnData column2) {
				return column1.getColumnIndex() - column2.getColumnIndex();
			}
		};

		Set<Integer> emptyColumnList = new HashSet<>();
		NumericColumnData firstNumericColumn = null;
		if(numericColumns.isEmpty()){
			firstNumericColumn = new NumericColumnData(1, 1, sheet);
		}
		else{
			firstNumericColumn = Collections.min(numericColumns, comparator);
			Row headerRow = sheet.getRow(headerRowIndex);
			if(headerRow != null){
				for(int index = 0; index < headerRow.getLastCellNum(); index++){
					boolean isEmptyColumn = GeneralUtility.isEmptyColumn(sheet, headerRowIndex + 1, index);
					if(isEmptyColumn){
						emptyColumnList.add(index);
					}
				}
			}
		}

		int lineItemColumnIndex = firstNumericColumn.getColumnIndex() - 1;

		List<ParserOutput> output = new ArrayList<>();
		final int START_PO_INDEX_ORDER = 0;
		final int PO_ORDER_INDEX_INCREMENT = 20;
		int currentPOIndexOrder = START_PO_INDEX_ORDER;

		
		logger.debug("Generating Header Parser Output object");
		ParserOutput headerPO = populateParserOutput(emptyColumnList, 
				sheet.getRow(headerRowIndex), sections.get(0), currentPOIndexOrder, 
				lineItemColumnIndex, firstNumericColumn.getColumnIndex(), numericColumns.size());
		headerPO.setType("HEADER");
		output.add(headerPO);
		
		logger.debug("Generating Parser Output objects for rows");
		for (int rowIndex = headerRowIndex + 1; rowIndex < sheet.getLastRowNum(); rowIndex++) {
			logger.debug("Generating Parser Output objects for row " + rowIndex);
			Row row = sheet.getRow(rowIndex);
			if (!GeneralUtility.isEmptyRow(row)) {
				ParserOutput po = populateParserOutput(emptyColumnList, row, 
						sections.get(0), currentPOIndexOrder, lineItemColumnIndex, 
						firstNumericColumn.getColumnIndex(), numericColumns.size());
				output.add(po);
				currentPOIndexOrder += PO_ORDER_INDEX_INCREMENT;
			}
		}
		try {
			StatementAttributes attributes = new StatementAttributes();
			List<ParserOutput> statement1 = attributes.getStatementAttributes(output.subList(0, 4), 
					sections.get(0).getSectionName(), numericColumns.size(), 
					-1, new TreeSet<Integer>(), "");
			for(ParserOutput po : statement1){
				getParserOutput(po, sections.get(0), 0, numericColumns.size());
			}
			output.addAll(0, statement1);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return output;
	}
	
	private void getParserOutput(ParserOutput po, Section section, int poIndexOrder, int maxCols){
		po.setStmtID(filingId);
		po.setSection(section.getSectionName());
		po.setWorqueID(currentUploadId);
		po.setIndexOrder(poIndexOrder);
		po.setPageNo(0);
		po.setLineNo(0);
		po.setMaxCol(maxCols);
		po.setPOVal(ParserOutput.MAX_PO_VAL, currentSheet.getSheetName());
	}

	private ParserOutput populateParserOutput(Set<Integer> emptyColumnList, 
			Row row, Section section, int poIndexOrder, int lineItemColumnIndex, 
			int rowStartIndex, int maxCols){
		ParserOutput po = new ParserOutput();
		getParserOutput(po, section, poIndexOrder, maxCols);
		po.setType("ROW");
		po.setPOVal(ParserOutput.MAX_PO_VAL, currentSheet.getSheetName());
		po.setTableID(currentSheet.getWorkbook().getSheetIndex(currentSheet));
		if(row == null){
			return po;
		}

		try{
			po.setAsRepLabel(GeneralUtility.cellToString(row.getCell(lineItemColumnIndex)));
		} catch(Exception e){
			logger.warn(e.getMessage());
		}
		int poColumnIndex = 1;
		StringBuilder line = new StringBuilder();
		line.append(GeneralUtility.cellToString(row.getCell(lineItemColumnIndex)));
		for (int columnIndex = rowStartIndex ; columnIndex < row.getLastCellNum(); columnIndex++) {
			if(!emptyColumnList.contains(columnIndex)){
				Cell cell = row.getCell(columnIndex);
				if(cell != null){
					po.setPOVal(poColumnIndex, GeneralUtility.cellToString(row.getCell(columnIndex)));
					poColumnIndex++;
				}
				String cellContent = GeneralUtility.cellToString(cell);
				if(cellContent == null){
					cellContent = "";
				}
				line.append(cellContent + " ");
			}
		}
		if(line.length() > 0){
			line.setLength(line.length() - 1);
		}
		po.setLine(line.toString());
		return po;
	}

	private void writeData(List<ParserOutput> list){
		IDataWriter dataWriter = null;
		if(standalone){
			String outputFilePath = createOutputFileName(currentFile);
			File file = new File(outputFilePath);
			dataWriter = new ExcelWriter(file.getAbsolutePath());
		}
		else{
			dataWriter = new DatabaseWriter(DBConnection.getConnection());
		}
		dataWriter.writeData(list);
	}

	private static String createOutputFileName(String inputFileName){
		String outputFileName = new File(inputFileName).getAbsolutePath();
		int index = outputFileName.lastIndexOf(".");
		String fileExtenasion = outputFileName.substring(index + 1);
		outputFileName = outputFileName.replace("." + fileExtenasion, "-output." + fileExtenasion);
		return outputFileName;
	}
}
