package com.rage.excel.headeridentifier.impl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;

import com.rage.excel.constants.Constants;
import com.rage.excel.headeridentifier.IHeaderIdentifier;
import com.rage.excel.model.NumericColumnData;
import com.rage.excel.utility.GeneralUtility;

public class HeaderIdentifierFromNumericColumns implements IHeaderIdentifier{

	private Sheet currentSheet;
	private List<NumericColumnData> numericColumns = null;
	private NumericColumnData firstStartingNumericColumn = null; 
	private int headerRowIndex = -1;
	
	private static Logger logger = Logger.getLogger(Constants.LOGGER_NAME);
	
	{
		refresh();
	}

	private void refresh(){
		consecutiveNullRowCount = 0;
		numericColumns = null;
		firstStartingNumericColumn = null;
		headerRowIndex = -1;
	}

	@Override
	public int identifyHeader(Sheet sheet) {
		logger.info("Identifying Header");
		refresh();
		currentSheet = sheet;
		List<NumericColumnData> numericColumns = getNumericColumnList();
		if(numericColumns.isEmpty()){
			return -1;
		}
		NumericColumnData firstStartingNumericColumn = getFirstNumericColumn(numericColumns);

		int headerRowIndex = getHeaderLine(firstStartingNumericColumn);
		if(headerRowIndex == -1){
			List<NumericColumnData> clone = new ArrayList<>(numericColumns);
			clone.remove(firstStartingNumericColumn);
			do{
				firstStartingNumericColumn = getFirstNumericColumn(clone);
				headerRowIndex = getHeaderLine(firstStartingNumericColumn);
				clone.remove(firstStartingNumericColumn);
			} while(headerRowIndex == -1 && !clone.isEmpty());
		}
		return headerRowIndex;
	}

	public int getHeaderIndex(){
		return headerRowIndex;
	}

	public List<NumericColumnData> getNumericColumns(){
		if(numericColumns != null){
			new ArrayList<>(numericColumns);
		}
		return new ArrayList<>();
	}

	public NumericColumnData getFirstNumericColumn(){
		return firstStartingNumericColumn;
	}

	private int getHeaderLine(NumericColumnData firstStartingNumericColumn) {
		if(firstStartingNumericColumn == null){
			return -1;
		}
		int startRowIndex = firstStartingNumericColumn.getStartRowIndex() - 1;
		while (startRowIndex > -1) {
			Row row = firstStartingNumericColumn.getSheet().getRow(startRowIndex);
			if(row == null){
				startRowIndex--;
				continue;
			}
			Cell cell = row.getCell(firstStartingNumericColumn.getColumnIndex());
			if(cell == null){
				startRowIndex--;
				continue;
			}
			if(!cell.toString().trim().isEmpty()){
				this.headerRowIndex = startRowIndex;
				return startRowIndex;
			}
			startRowIndex--;
		}
		int lineItemColumnIndex = firstStartingNumericColumn.getColumnIndex() - 1;
		if(lineItemColumnIndex == -1){
			return -1;
		}
		int rowIndex = firstStartingNumericColumn.getStartRowIndex() - 1;
		do{
			Row row = currentSheet.getRow(rowIndex);
			if(row != null){
				Cell cell = row.getCell(lineItemColumnIndex);
				if(cell != null && cell.getStringCellValue() != null && !cell.getStringCellValue().trim().isEmpty()){
					this.headerRowIndex = rowIndex;
					return rowIndex;
				}
			}
			rowIndex--;
		} while(rowIndex > -1);
		return -1;
	}

	public NumericColumnData getFirstNumericColumn(Sheet sheet){
		refresh();
		this.currentSheet = sheet;
		List<NumericColumnData> numericColumns = getNumericColumnList();
		return getFirstNumericColumn(numericColumns);
	}

	private NumericColumnData getFirstNumericColumn(List<NumericColumnData> numericColumns) {
		NumericColumnData firstStartingNumericColumn = null;
		for (NumericColumnData data : numericColumns) {
			if (firstStartingNumericColumn == null
					|| data.getStartRowIndex() < firstStartingNumericColumn.getStartRowIndex()) {
				firstStartingNumericColumn = data;
			}
		}
		this.firstStartingNumericColumn = firstStartingNumericColumn;
		return firstStartingNumericColumn;
	}

	public List<NumericColumnData> getNumericColumnList(Sheet sheet) {
		refresh();
		this.currentSheet = sheet;
		return getNumericColumnList();	
	}

	public List<NumericColumnData> getNumericColumnList() {
		if(numericColumns != null){
			return new ArrayList<>(numericColumns);
		}
		logger.info("Detecting Numeric Columns");
		final int MAX_ALLOWED_ROWS = 10;
		int maxColumns = -1;
		for (int index = 0; index < MAX_ALLOWED_ROWS; index++) {
			Row row = currentSheet.getRow(index);
			if (row != null && row.getLastCellNum() > maxColumns) {
				maxColumns = row.getLastCellNum();
			}
		}
		List<NumericColumnData> numericColumns = new ArrayList<>();
		for (int index = 0; index < maxColumns; index++) {
			NumericColumnData data = identifyNumericColumn(index);
			if (data != null) {
				numericColumns.add(data);
			}
		}
		if(!numericColumns.isEmpty()){
			if(numericColumns.get(0).getColumnIndex() == 0){
				numericColumns.remove(0);
			}
		}
		logger.debug("Identified numeric columns are : " + numericColumns);
		this.numericColumns = numericColumns;
		return numericColumns;
	}

	
	private final float MINIMUM_NUMERIC_THRESHOLD = 0.3f;
	private NumericColumnData identifyNumericColumn(int columnIndex) {
		logger.debug("Deciding column " + columnIndex + " is numeric column");
		int validNumericValueCount = 0;
		NumericColumnData data = null;
		boolean foundFirstNumericValue = false;
		Workbook workbook = currentSheet.getWorkbook();
		FormulaEvaluator evaluator = workbook.getCreationHelper().createFormulaEvaluator();
		for (int rowIndex = 0;; rowIndex++) {
			try {
				Row row = currentSheet.getRow(rowIndex);
				boolean isLastRow = isLastRow(row);
				if (isLastRow) {
					if(data != null){
						int startRow = data.getStartRowIndex();
						int endRow = rowIndex;
						int diff = endRow - startRow;
						float pct = (validNumericValueCount * 1.0f) / diff;
						logger.trace("Start row index :" + startRow);
						logger.trace("End row index :" + endRow);
						logger.trace("Numeric value Percentage :" + pct * 100);
						logger.trace("Minimum threshold : " + MINIMUM_NUMERIC_THRESHOLD * 100);
						if(pct < MINIMUM_NUMERIC_THRESHOLD){
							data = null;
						}
					}
					break;
				} else {
					if (row != null) {
						Cell cell = row.getCell(columnIndex);
						if (cell == null || cell.toString().trim().isEmpty() || isSpecialCell(cell)) {
							continue;
						}
						if (isAvoidableCell(cell)) {
							continue;
						}

						String cellContent = GeneralUtility.cleanCellContent(cell);
						if(cell.getCellType() == Cell.CELL_TYPE_FORMULA){
							
							try{
								logger.trace("Evaluating formula for cell : (" + cell.getRowIndex() + ", " + cell.getColumnIndex() + ")\t" + cell.toString());
								CellValue cellValue = evaluator.evaluate(cell);
								cellContent = "" + cellValue.getNumberValue();
							} catch(Exception e){
								if(cell instanceof XSSFCell){
									cellContent = ((XSSFCell)cell).getRawValue();
									logger.trace("Formula evaluation failed, populting raw value : " + cellContent);
								}
							}
						}

						try {
							Double.parseDouble(cellContent);
							if (!foundFirstNumericValue) {
								foundFirstNumericValue = true;
								data = new NumericColumnData(columnIndex, rowIndex, currentSheet);
							}
							logger.trace("Numeric value detected : " + cellContent);
							validNumericValueCount++;
						} catch (NumberFormatException e) {
							// e.printStackTrace();
							logger.trace("Found text content : " + cellContent);
							if (foundFirstNumericValue) {
								logger.debug("Column " + columnIndex + " is not a numeric column.");
								return null;
							}
						}

					}
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		if (!foundFirstNumericValue) {
			logger.debug("Column " + columnIndex + " is not a numeric column.");
			return null;
		}
		logger.debug("Column " + columnIndex + " is a numeric column. Details : " + data);
		return data;
	}

	private static Set<String> specialCellContents = new HashSet<>();

	static {
		specialCellContents.add("#DIV/0!");
	}

	private static boolean isSpecialCell(Cell cell) {
		return specialCellContents.contains(cell.toString().trim());
	}

	private static Set<String> avoidableCellContents = new HashSet<>();

	static {
		avoidableCellContents.add("2011");
		avoidableCellContents.add("2012");
		avoidableCellContents.add("2013");
	}

	private static boolean isAvoidableCell(Cell cell) {
		return avoidableCellContents.contains(cell.toString().trim());
	}

	private int consecutiveNullRowCount = 0;
	private final int MAX_ALLOWED_EMPTY_ROW_COUNT = 10;

	private boolean isLastRow(Row row) {
		boolean isEmptyRow = GeneralUtility.isEmptyRow(row);
		if (isEmptyRow) {
			consecutiveNullRowCount++;
			if (consecutiveNullRowCount == MAX_ALLOWED_EMPTY_ROW_COUNT) {
				return true;
			}
		} else {
			consecutiveNullRowCount = 0;
		}
		return false;
	}
}
