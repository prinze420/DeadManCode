package com.rage.excel.headeridentifier;

import org.apache.poi.ss.usermodel.Sheet;

public interface IHeaderIdentifier {
	public int identifyHeader(Sheet sheet);
}
