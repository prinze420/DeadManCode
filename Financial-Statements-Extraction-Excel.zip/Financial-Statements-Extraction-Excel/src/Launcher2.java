import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

import com.rage.excel.ExcelFileProcessor;

public class Launcher2 {

	public static void main(String[] args) {
		List<String> baseDir = new ArrayList<>();
		baseDir.add("samples/CRU");
		baseDir.add("samples/RJ");

		for(String fileName : baseDir){
			File file = new File(fileName);
			FileFilter filter = new FileFilter() {

				@Override
				public boolean accept(File file) {
					String fileName = file.getName().toLowerCase();
					return (fileName.endsWith("xlsx") || fileName.endsWith("xls")) && !fileName.contains("-output");
				}
			};

			for(File _file : file.listFiles(filter)){
				List<Integer> uploadIds = new ArrayList<>();
				uploadIds.add(-2);

				List<String> fileNames = new ArrayList<>();
				fileNames.add(_file.getAbsolutePath());
				try{
					new ExcelFileProcessor(-1, true, uploadIds, fileNames).processFile();
				}catch(Exception e){
//					logger.info(_file.getName());
					break;
				}
			}
		}
	}

}
