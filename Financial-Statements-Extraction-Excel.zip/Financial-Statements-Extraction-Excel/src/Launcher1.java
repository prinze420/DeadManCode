import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Launcher1 {

	public static void main(String[] args) {
		List<String> baseDir = new ArrayList<>();
		baseDir.add("samples/CRU");
		baseDir.add("samples/RJ");
		
		List<String> sheetNames = new  ArrayList<>();
		List<String> filePath = new  ArrayList<>();
		
		for(String fileName : baseDir){
			File file = new File(fileName);
			FileFilter filter = new FileFilter() {

				@Override
				public boolean accept(File file) {
					String fileName = file.getName().toLowerCase();
					return (fileName.endsWith("xlsx") || fileName.endsWith("xls"));
				}
			};

			
			for(File _file : file.listFiles(filter)){
				try {
					XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(_file));
					for(int index = 0; index < workbook.getNumberOfSheets(); index++){
						sheetNames.add(workbook.getSheetAt(index).getSheetName().toLowerCase());
						filePath.add(_file.getAbsolutePath());
					}
				} catch (IOException e) {
					// TODO Auto-generated catch block
//					e.printStackTrace();
				} catch(Exception e){
				}
			}
		}
//		for(int index = 0; index < filePath.size(); index++){
//			logger.info(sheetNames.get(index) + "\t\t" + filePath.get(index));
//		}
	}
}
