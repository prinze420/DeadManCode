JAVA_HOME=/home/rage/jdk1.6.0_31/bin
JAVA=$JAVA_HOME/java
EXECUTION_DIR=/home/rage/Parser_Scripts/Spanish-ITR-Extraction
LIB_DIR=$EXECUTION_DIR/lib
RES_DIR=$EXECUTION_DIR/resource
APP_JAR=$EXECUTION_DIR/PDF-Financials-Extraction.jar

export CLASSPATH=$CLASSPATH:$APP_JAR;
export CLASSPATH=$CLASSPATH:$RES_DIR;
export CLASSPATH=$CLASSPATH:$LIB_DIR/classes12.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-validator-1.4.0.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/dom4j-1.6.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/pdfbox-app-1.8.9.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-ooxml-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-ooxml-schemas-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/xmlbeans-2.6.0.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/log4j.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-lang3-3.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/lucene-core-2.9.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/muc.7class.distsim.crf.ser.gz;


echo "CHANGING TO THE APPROPRIATE DIRECTORY"
cd $EXECUTION_DIR

stmtID=$1
documentName=$2
industry=$3
companyID=$4
#language=$5
#coordReqd=$6

$JAVA -mx1024m com.rage.extraction.statements.extract.pdf.FinancialStatementExtractor $stmtID false $documentName No $industry On Yes No $companyID "Spanish ITR" "No"
echo "Completed executing PDF Financials Extraction Parser"

cnt=`grep -ic exception PDF-Financials-Extraction-Error.txt`

echo "Exception count is "$cnt

if [[ $cnt -gt 2 ]]; then
   exit 1;
fi 
exit 0;