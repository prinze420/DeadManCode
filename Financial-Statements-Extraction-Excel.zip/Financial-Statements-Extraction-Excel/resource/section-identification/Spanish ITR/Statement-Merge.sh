#JAVA_HOME=/home/rage/jdk1.6.0_31/bin
JAVA_HOME=/home/rage/jdk1.7.0_21/bin
JAVA=$JAVA_HOME/java
EXECUTION_DIR=/home/rage/Parser_Scripts/PDF-Financials-Extraction
LIB_DIR=$EXECUTION_DIR/lib
RES_DIR=$EXECUTION_DIR/resource
APP_JAR=$EXECUTION_DIR/PDF-Financials-Extraction.jar

export CLASSPATH=$CLASSPATH:$APP_JAR;
export CLASSPATH=$CLASSPATH:$RES_DIR;
export CLASSPATH=$CLASSPATH:$LIB_DIR/ojdbc14.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-codec-1.10.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-io-2.5.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-lang3-3.4.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-logging-1.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-validator-1.4.0.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/cssparser-0.9.20.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/dom4j-1.6.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/htmlunit-2.23.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/htmlunit-core-js-2.23.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/httpclient-4.5.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/httpcore-4.4.4.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/httpmime-4.5.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/jetty-io-9.2.18.v20160721.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/jetty-util-9.2.18.v20160721.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/jsoup-1.9.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/jtds-1.2.5.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/log4j.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/lucene-core-2.9.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/muc.7class.distsim.crf.ser.gz;
export CLASSPATH=$CLASSPATH:$LIB_DIR/neko-htmlunit-2.23.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/pdfbox-app-1.8.7.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-ooxml-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/poi-ooxml-schemas-3.10.1.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/sac-1.3.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/serializer-2.7.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/sqljdbc4.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/websocket-api-9.2.18.v20160721.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/websocket-client-9.2.18.v20160721.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/websocket-common-9.2.18.v20160721.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/xalan-2.7.2.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/xercesImpl-2.11.0.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/xml-apis-1.4.01.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/xmlbeans-2.6.0.jar;


echo "CHANGING TO THE APPROPRIATE DIRECTORY"
cd $EXECUTION_DIR

stmtID=$1

$JAVA -mx1024m com.rage.extraction.statements.fs.merge.MergeStatement $stmtID On
echo "Completed executing Merge Statement"

cnt=`grep -ic exception Statement-Merge-Error.txt`

echo "Exception count is "$cnt

if [[ $cnt -gt 2 ]]; then
   exit 1;
fi 

exit 0;