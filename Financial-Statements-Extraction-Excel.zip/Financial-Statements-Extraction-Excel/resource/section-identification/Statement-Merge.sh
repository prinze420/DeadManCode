JAVA_HOME=/home/rage/jdk1.6.0_31/bin
JAVA=$JAVA_HOME/java
EXECUTION_DIR=/home/rage/Parser_Scripts/PDF-Financials-Extraction
LIB_DIR=$EXECUTION_DIR/lib
RES_DIR=$EXECUTION_DIR/resource
APP_JAR=$EXECUTION_DIR/PDF-Financials-Extraction.jar

export CLASSPATH=$CLASSPATH:$APP_JAR;
export CLASSPATH=$CLASSPATH:$RES_DIR;
export CLASSPATH=$CLASSPATH:$LIB_DIR/classes12.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/log4j.jar;
export CLASSPATH=$CLASSPATH:$LIB_DIR/commons-lang3-3.2.jar;


echo "CHANGING TO THE APPROPRIATE DIRECTORY"
cd $EXECUTION_DIR

stmtID=$1

$JAVA -mx1024m com.rage.extraction.statements.fs.merge.MergeStatement $stmtID On
echo "Completed executing Bank Extraction Parser"

cnt=`grep -ic exception Statement-Merge-Error.txt`

echo "Exception count is "$cnt

if [[ $cnt -gt 2 ]]; then
   exit 1;
fi 
exit 0;