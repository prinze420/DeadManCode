package com.pdf.parser.pipeline;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Queue;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.TreeMap;

import org.apache.pdfbox.exceptions.CryptographyException;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;

import com.pdf.parser.Structure;
import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPCell;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.KeyValuePair;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.base.PDFWord;
import com.pdf.parser.base.strategy.KeyValueStrategy;
import com.pdf.parser.base.strategy.LeftNumbersDetectionStrategy;
import com.pdf.parser.base.strategy.PDFSegmentFormationStrategy;
import com.pdf.parser.complex.PDFPara;
import com.pdf.parser.complex.strategy.GraphicalLinesDetectionStrategy;
import com.pdf.parser.complex.strategy.PDFParaDetectionStrategy;
import com.pdf.parser.complex.strategy.configBasedTable.StructureGroup;
import com.pdf.parser.extraction.Highlighter;
import com.pdf.parser.extraction.RuleProcessor;
import com.pdf.parser.rules.CreateRules;
import com.pdf.parser.rules.ExtractionRule;
import com.pdf.parser.rules.Extraction_Result;
import com.pdf.parser.test.NLP_OP_Reader;
import com.pdf.parser.test.NLP_Output;
import com.pdf.parser.utils.CommonOperations;

public class Extractor_Phizer {

	private String inputFile = "";
	private String outputParagraphFileDirPath = "";
	private Set<ExtractionRule> rules;
	private static Set<String>processedFiles=new HashSet<String>();
	static ResourceBundle basicConfig;
	private Map<Integer,List<String>> startPageKeywords = new TreeMap<Integer, List<String>>();
	private static boolean printFlag=false;

	private Map<String,Set<String>> validPagKeywordsForCellDetection=new TreeMap<String, Set<String>>();
	private int forPageCellDetection_matching_Limit;
	private static String highlight_flag,highlight_outputFilePath;

	static{
		try{
			basicConfig = ResourceBundle.getBundle("basic-structure-config",Locale.ENGLISH,new URLClassLoader(new URL[]{new File("config").toURI().toURL()}));

			highlight_flag=basicConfig.getString("highlight_flag");
			highlight_outputFilePath=basicConfig.getString("highlight_outputFilePath");
			BufferedReader reader = new BufferedReader(new FileReader("config/processedFiles.list"));//use for skip already processed files
			String line ="";
			while((line = reader.readLine()) != null)
				processedFiles.add(line.trim());
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	static final Object lock=new Object();
	//how many keywords are matched for start page detection
	static final Integer forStartPageDetection_matching_Limit = Integer.valueOf(basicConfig.getString("forStartPageDetection_matching_Limit"));

	public Extractor_Phizer(String inputFile,Set<ExtractionRule> rules,String outputParagraphFileDirPath) 
	{

		this.inputFile=inputFile;
		this.rules=rules;
		this.outputParagraphFileDirPath=outputParagraphFileDirPath;
		try{
			//how many keywords are matched for cellpage detection / for now it's 2
			forPageCellDetection_matching_Limit=Integer.valueOf(basicConfig.getString("forPageCellDetection_matching_Limit"));

			BufferedReader reader = new BufferedReader(new FileReader("config/startPageKeywords.list"));
			if(basicConfig.getString("printFlag").equalsIgnoreCase("true")){
				printFlag=true;
			}
			String line ="";
			while((line = reader.readLine()) != null){
				String[] split = line.split("##");
				int templateID=Integer.valueOf(split[1]);
				if(startPageKeywords.containsKey(templateID))
				{
					List<String> kw = startPageKeywords.get(templateID);
					
					
					kw.add(split[0]);
					startPageKeywords.put(templateID, kw);
				}else{
					List<String> kw = new ArrayList<String>();
					
					kw.add(split[0]);
					startPageKeywords.put(templateID, kw);
				}
			}
			
			
			reader = new BufferedReader(new FileReader("config/validPagKeywordsForCellDetection.list"));
			line ="";
			while((line = reader.readLine()) != null){
				if(!line.trim().isEmpty()){
					String[] split = line.split("=");
					//template wise separate keywords:  split[0] is template name is used only for grouping specific keywords, nothing else. from that set must match atleast "forPageCellDetection_matching_Limit" keywords. 
					if(validPagKeywordsForCellDetection.containsKey(split[0])){
						Set<String> list = validPagKeywordsForCellDetection.get(split[0]);
						list.add(split[1]);
						validPagKeywordsForCellDetection.put(split[0], list);
					}else if(split.length > 1){
						Set<String> list = new HashSet<String>();
						list.add(split[1]);
						validPagKeywordsForCellDetection.put(split[0], list);
					}
				}
			}
			
			reader.close();
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	private List<Extraction_Result> apply() throws IOException {
		//defaultEmailLastPage=;

		List<Extraction_Result> results = new ArrayList<Extraction_Result>();
		File f=new File(inputFile);
		PDDocument pdf = PDDocument.load(f);

		pdf.setAllSecurityToBeRemoved(true);
		if(pdf.isEncrypted()){
			try {
				pdf.decrypt("");
			} catch (CryptographyException e) {
				e.printStackTrace();
			}
		}
		pdf.setAllSecurityToBeRemoved(true);

		//Create image cet of pdf Pages for CheckBoxProcessing


		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, DPRectangle> pageWiseRectangle = parser.getPageSizes();
		Map<Integer, List<PDFSegment>> pageSegments = parser.getSegments();

		
		
		//************Break segments with colon in them
		for(List<PDFSegment> segs : pageSegments.values())
		{
			Iterator<PDFSegment> it = segs.iterator();
			List<PDFSegment> temp = new ArrayList<PDFSegment>();
			seg:
				while(it.hasNext()){
					PDFSegment seg = it.next();

					if(seg.getStringRepresentation().contains("SUSPECT MEDICATION(S)/ PRODUCT(S) (INCLUDE DOSAGE AND"))
						System.out.println("debug");

					if(seg.getStringRepresentation().contains(":"))
					{
						List<PDFWord> firstHalf = new ArrayList<PDFWord>();
						String wordStr = "";
						
						for(int i=0;  i<seg.getWords().size(); i++)
						{
							PDFWord word = seg.getWords().get(i);
							wordStr += word.getStringRepresentation()+" ";
							
							if(word.getStringRepresentation().endsWith(":") && word.getStringRepresentation().length()>1)
							{
								
								if(i < seg.getWords().size()-1)
								{//At least one word remains for seg split
									firstHalf.add(word);
									//System.out.println("if word "+word);
									PDFSegmentFormationStrategy.makeSegment(firstHalf, wordStr.trim(), temp, seg.getRectangle().getPage());

									List<PDFWord> secondHalf = new ArrayList<PDFWord>();
									wordStr = "";
									for(int j=i+1; j<seg.getWords().size(); j++){
										secondHalf.add(seg.getWords().get(j));
										wordStr += seg.getWords().get(j).getStringRepresentation()+" ";
									}
									PDFSegmentFormationStrategy.makeSegment(secondHalf, wordStr.trim(), temp, seg.getRectangle().getPage());
									it.remove();//Remove original segment after split.
									continue seg;

								}
								else
								{
									//System.out.println("else word "+word);
									temp.add(seg);
									continue seg;
								}
							}else
								firstHalf.add(word);
						}

					}
					else
					{
						temp.add(seg);
					}
				}

			segs.clear();
			segs.addAll(temp);
		}
		//***********************************************

		List<PDPage> pdPages = parser.getPdfPages();

		//remove header and footer
		Map<Integer,List<BasicStructure>> SegsInBasicStru1=new TreeMap<Integer, List<BasicStructure>>();
		for (Integer pdPage : pageSegments.keySet()) {
			List<PDFSegment> lst = pageSegments.get(pdPage);
			List<BasicStructure>temp=new ArrayList<BasicStructure>(lst);
			SegsInBasicStru1.put(pdPage, temp);
		}

		
		//System.out.println(" SegsInBasicStru1 "+SegsInBasicStru1);
		
		
		//		System.out.println("\n------------------- Headers ------------------------------");
		//		PDFHeaderDetectionStrategy hds= new PDFHeaderDetectionStrategy(SegsInBasicStru1,pageWiseRectangle); //need to also remove from pageAndMColWiseSegments 
		//		hds.apply();
		//		Map<Integer, List<Header>> pageWiseHeaders = hds.getOutcome();
		//		System.out.println(pageWiseHeaders);
		//		Map<Integer, List<BasicStructure>> segmentsAftrHeaderRemoval = hds.getRemainingPageWiseParas();
		//
		//		//		remove footers
		//		System.out.println("\n------------------- Footers ------------------------------");
		//		System.out.println("PDFFooterDetectorStrategy");
		//		PDFFooterDetectorStrategy fds= new PDFFooterDetectorStrategy(segmentsAftrHeaderRemoval,pageWiseRectangle,parser.getPages());
		//		fds.apply();
		//
		//		Map<Integer, List<BasicStructure>> pageWiseFooters = fds.getOutcome();
		//		System.out.println(pageWiseFooters);
		//		Map<Integer, List<PDFSegment>> segmentsAftrFooterRemoval=fds.getRemainingPageWiseSegs();

		//		System.out.println("*****************************");
		//		for(PDFSegment s : pageSegments.get(1))
		//			System.out.println(s.getStringRepresentation());
		//		System.out.println("*****************************");

		//LeftNumbersDetectionStrategy
		LeftNumbersDetectionStrategy lNum=new LeftNumbersDetectionStrategy(pageSegments, pageWiseRectangle);
		lNum.apply();
		Map<Integer, List<PDFSegment>> afterLeftMargineDataRemoval = lNum.getOutcome();

		//System.out.println("afterLeftMargineDataRemoval "+afterLeftMargineDataRemoval);
		pageSegments=afterLeftMargineDataRemoval;

		//		System.out.println("*****************************");
		//		for(PDFSegment s : pageSegments.get(2))
		//			System.out.println(s.getStringRepresentation());
		//		System.out.println("*****************************");

		//----------------------------------startPage-----------------------------
		int startPage=detectStartPage(pageSegments); 

		System.out.println("****************\n StartPage :\t "+startPage+"\n********************");
		/*if(startPage>0){
			pageSegments = updateSegmentsMap(pageSegments,startPage);
		}*/

		//--------------------------------- KVP Process --------- 
		System.out.println("--------------------- KVP Strategy --------------------");
		List<Structure> KVP = getKVPairs(pageSegments,startPage);
		if(!printFlag){
			System.out.println("\n **** KVP ******");
			for (Structure structure : KVP) {
				if(structure instanceof KeyValuePair){
					KeyValuePair p=(KeyValuePair)structure;
					System.out.println("KVP "+p.getStringRepresentation());
				}
			} 
		}
		//--------------------------------- Cell Process --------- 
		long	start=System.currentTimeMillis();
		Map<Integer, List<DPCell>> pageWiseCells = new HashMap<Integer, List<DPCell>>();
		pageWiseCells=getPageWiseCells(pageSegments, pdf, startPage, inputFile);
		//	pageCells=cellProcess(parser, pdf, startPage,inputFile);
		long	end=System.currentTimeMillis();
		System.out.println("CellProcessing Time:"+(end-start)/1000);

		//---------------------------------Create Paragraph Process --------- 
		System.out.println("--------------------- PDFParaDetectionStrategy --------------------");
		PDFParaDetectionStrategy pdp=new PDFParaDetectionStrategy(pageSegments,pdPages,startPage);
		pdp.apply();
		Map<Integer, List<PDFPara>> pageWiseParas = pdp.getOutcome();

		if(printFlag){
			System.out.println("\n ***** Paras: *******");
			for ( Integer k : pageWiseParas.keySet()) { 
				System.out.println("page \t"+k);
				for ( PDFPara p : pageWiseParas.get(k)) {
					System.out.println("Enum:  "+ p.getEnumeration() +"\t "+p.getStringRepresentation());
				}
			}
		}

		//--------------------------------- Write Paragraph --------- 
		if(!outputParagraphFileDirPath.isEmpty()){
			String parafile=outputParagraphFileDirPath+File.separator+f.getName().substring(0, f.getName().lastIndexOf("."))+".txt";
			writeStructure(pageWiseParas,parafile,startPage);
		}

		/*for(int i=0; i<parser.getPageSizes().size(); i++){
			if(parser.getWords().get(i) == null)//Blank Page
				continue;
			segGroups.put(i, Commons.groupStructuresOnY(parser.getSegments().get(i)));
			wordGroups.put(i, Commons.groupStructuresOnY(parser.getWords().get(i)));
		}*/

		//********Remove Footer
		//		SimpleFooterStrategy.removeFooters(wordGroups);
		//		SimpleFooterStrategy.removeFooters(segGroups);
		//*********************

		//***********List of titles segments based on rules
		Set<String> titles = new HashSet<String>();
		String t;
		for(ExtractionRule rule : rules){
			if(rule.getKeywords().contains("##")){
				t=rule.getKeywords().split("##")[1];

				if(t.startsWith("Title:")){//Cells are to be found only under a specific title segment
					titles.add(t.substring(6).trim());
				}
			}
		}

		List<PDFSegment> ruleTitles = new ArrayList<PDFSegment>();
		for(List<PDFSegment> segs : pageSegments.values()){
			for(PDFSegment seg : segs){
				if(titles.contains(seg.getStringRepresentation()))
					ruleTitles.add(seg);
			}
		}
		//**********************************

		long	start2=System.currentTimeMillis();
		RuleProcessor rp=new RuleProcessor(pdPages,pageSegments,rules,pageWiseParas,startPage,KVP,pageWiseCells);
		//List<Extraction_Result> rawResults = rp.rowProcess(rules);
		results=rp.process(ruleTitles);
		long	end2=System.currentTimeMillis();
		System.out.println("Ontology Extraction Time:"+(end2-start2)/1000);


		//-----------------------Highlighting Process--------------------------
		//String fName=f.getName().substring(0, f.getName().lastIndexOf("."));
		//String highlight_outputFilePath=f.getParentFile().getAbsolutePath()+File.separator+"New_"+f.getName();
		
		if(highlight_outputFilePath.trim().isEmpty()){
			highlight_outputFilePath="D:/Platform/Phizer/TestSample/HighlightingOutput"+File.separator+"New_"+f.getName();
		}else{
			highlight_outputFilePath=highlight_outputFilePath+File.separator+"New_"+f.getName();
		}
		if(highlight_flag.equalsIgnoreCase("true")){
			Highlighter.highLightResult(inputFile, results, highlight_outputFilePath);
			String	nlpexcelPath="D:\\Platform\\Phizer\\TestSample\\eliLilly.xls";
			excel_Highlighting_Process(nlpexcelPath,pageWiseParas,highlight_outputFilePath);
		}


		return results;

	}

	/*private Map<Integer, List<PDFSegment>> removeFirstVerticleNumbers(Map<Integer, List<PDFSegment>> pageSegments) {


		return pageSegments;
	}*/

	private void excel_Highlighting_Process(String nlpexcelPath, Map<Integer, List<PDFPara>> pageWiseParas, String highlight_outputFilePath) {
		// TODO Auto-generated method stub
		PDDocument pdf = null;
		List<PDPage> pages = null;
		try{
			pdf = PDDocument.load(new File(highlight_outputFilePath));
			pages = (List<PDPage>) pdf.getDocumentCatalog().getAllPages();
		} catch (IOException e) {
			e.printStackTrace();
		}

		NLP_OP_Reader nlpr=new NLP_OP_Reader();
		List<NLP_Output> NLP_OutputList = nlpr.readNLP_Output(nlpexcelPath);

		String fileName=highlight_outputFilePath.split("New_")[1];
		for (NLP_Output nlp_Output : NLP_OutputList) {

			if(nlp_Output.getExtractionType().equalsIgnoreCase("nlp") && fileName.contains(nlp_Output.getFileName()) ){
				String resultPara=nlp_Output.getParagraph();
				List<PDFPara> pageParas = pageWiseParas.get(nlp_Output.getPagenum());
				PDFPara matchedPdfPara=null;

				for (PDFPara pdfPara : pageParas) {
					if(resultPara.replaceAll("[^A-Za-z0-9 ]", "").trim().equals(pdfPara.getStringRepresentation().replaceAll("[^A-Za-z0-9 ]", "").trim())){
						matchedPdfPara=pdfPara;
						break;
					}
				}
				if(matchedPdfPara==null) continue;

				List<BasicStructure>resultMatchedSegment=getmatchedWords(nlp_Output.getExtractedOp(),matchedPdfPara);


				if(resultMatchedSegment!=null && !resultMatchedSegment.isEmpty()){
					for (BasicStructure pdfSegment : resultMatchedSegment) {
						try {
							PDPage page = pages.get(pdfSegment.getRectangle().getPage());
							Highlighter.highlight(pdf, page, pdfSegment.getRectangle().getX2(), pdfSegment.getRectangle().getY(),
									pdfSegment.getRectangle().getX(), pdfSegment.getRectangle().getY2(), "green");
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
		}
		try {
			System.out.println("\n\n highlighting Data");
			pdf.save(highlight_outputFilePath);
			System.out.println("\n\n highlighting process end***");
			pdf.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

	private List<BasicStructure> getmatchedWords(String extractedOp,PDFPara matchedPdfPara) {
		List<BasicStructure> temp=new ArrayList<BasicStructure>();
		List<String>resultWords=Arrays.asList(extractedOp.split("\\s"));

		Map<Integer, List<BasicStructure>> parasegs = matchedPdfPara.getSegments();

		for (Integer pg : parasegs.keySet()) {
			List<BasicStructure> segs = parasegs.get(pg);
			for (BasicStructure s : segs) {

				for (PDFWord pdfwor : ((PDFSegment)s).getWords()) {

					for (String opWrd : resultWords) {
						if(opWrd.equalsIgnoreCase(pdfwor.getStringRepresentation().trim())){
							temp.add(pdfwor);
						}
					}
				}
			}
		}
		return temp;
	}

	public  Map<Integer,List<DPCell>> getPageWiseCells(Map<Integer, List<PDFSegment>> pageSegments, PDDocument pdf, int startPage, String inputFile){
		Map<Integer,List<DPCell>> pageWiseCells = new TreeMap<Integer,List<DPCell>>();
		try {

			for (Integer pg : pageSegments.keySet()) {
				if(pg<startPage){
					continue;
				}
				try 
				{
					if(pageSegments.get(pg)!=null && pageSegments.get(pg).size()>0)
					{
						// TODO: Run this only on a few selected pages
						List<DPCell> pageCells = new ArrayList<DPCell>() ;

						if ( validPageForCellsDetection(pageSegments.get(pg)) ){

							new GraphicalLinesDetectionStrategy();
							//long	start=System.currentTimeMillis();
							//System.out.println(start); 
							pageCells = GraphicalLinesDetectionStrategy.extractPageCell(pg,(PDPage)pdf.getDocumentCatalog().getAllPages().get(pg));
							System.out.println("CellSize:\t"+pageCells.size());
							//long	end=System.currentTimeMillis();
							//System.out.println("CellProcessing Time:"+(end-start)/1000);

						}

						//---*****Fill Cells-------------------------------------------
						List<DPCell> cells = pageCells;//.get(page);
						if(pageSegments.get(pg)==null ||pageCells.isEmpty()){
							continue;
						}
						for(PDFSegment seg : pageSegments.get(pg)){
							if(seg.getStringRepresentation().contains("11/May/1976")){
								System.out.print("");
							}
							for (PDFWord wrd : seg.getWords()) {

								List<DPCell> cList = isInCellArea(wrd, cells);
								for (DPCell c : cList) {
									if(c!=null && !c.getLineCellDataList().contains(wrd)){
										//	System.out.println("Cell Seg:"+seg+"\t"+c.getRow()+"\t"+c.getColumn());
										c.getLineCellDataList().add(wrd);
										wrd.setIsCellPart(true);
										wrd.setLineDPCell(c); 
										String cc = c.getStringRepresentation()+" "+wrd.getStringRepresentation();
										c.setStringRepresentation(cc.trim());
									}
								}
							}
						}
						//sort cell YX
						for (DPCell c : cells) {
							if(c!=null && !c.getLineCellDataList().isEmpty() && c.getLineCellDataList().size()>1){
								List<PDFWord> list = c.getLineCellDataList();
								Collections.sort(list,new Comparator<PDFWord>() {
									@Override
									public int compare(PDFWord o1, PDFWord o2) {
										return Float.valueOf(o1.getRectangle().getY()).compareTo(o2.getRectangle().getY());
									}
								});
								//System.out.println("sorted Cell List\t"+list);
								c.setLineCellDataList(list);
								String cc="";
								for (PDFWord pdfWord : list) {
									cc = cc+" "+ pdfWord.getStringRepresentation();
								}
								c.setStringRepresentation(cc.trim());
							}
						}
						//remove blank cells
						Iterator<DPCell> cellsIterator = pageCells.iterator();
						while (cellsIterator.hasNext()) {
							DPCell next = cellsIterator.next();
							if(next.getStringRepresentation().trim().isEmpty()){
								cellsIterator.remove();
							}
						}
						//detect KV Pairs of Each cell
						//						for (DPCell dpCell : cells) {
						//							KeyValueStrategy kv = new KeyValueStrategy(CommonOperations.groupStructuresOnY(dpCell.getParaList()));
						//							kv.apply();
						//							List<Structure> cellKVPairs = kv.getOutcome();
						//							if(cellKVPairs!=null || !cellKVPairs.isEmpty()){
						//								dpCell.setCellKVP(cellKVPairs);
						//							}
						//							
						//						}
						pageWiseCells.put(pg,new ArrayList<DPCell>(cells));
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}

		} catch (Exception e1) {
			e1.printStackTrace();
		}

		return pageWiseCells;
	}

	private List<DPCell> isInCellArea(BasicStructure c, List<DPCell> cell_list) {
		//TODO do it on word level   
		List<DPCell> temp=new ArrayList<DPCell>();


		if(c.getStringRepresentation().contains("LYRICA")){
			System.out.print("");
		}
		if(c.getStringRepresentation().contains("DETROL LA")){
			System.out.print("");
		}
		for (DPCell dpLineCell : cell_list) {

			/*if(dpLineCell.getRow()==5 && dpLineCell.getColumn()==3){
				System.out.print(""+c.getRectangle().getY2());
			}*/
			if(c.getRectangle().getPage()!=dpLineCell.getRectangle().getPage()){
				continue;
			}
			float y2 = (float)dpLineCell.getRectangle().getY2();
			float y = (float) (dpLineCell.getRectangle().getY());
			double x=dpLineCell.getRectangle().getX();
			double x2=dpLineCell.getRectangle().getX2();

			if(c.getRectangle().getY()<=y
					&& c.getRectangle().getY()>=y2
					&& c.getRectangle().getX()>=x
					&& c.getRectangle().getX2()<=x2
					//&& !temp.contains(dpLineCell)
					){
				temp.add(dpLineCell);
				//return dpLineCell;

			}
		}
		return temp;
	}	

	private boolean validPageForCellsDetection(List<PDFSegment> pageSegments) 
	{
		if(pageSegments==null || pageSegments.isEmpty()|| validPagKeywordsForCellDetection==null ||validPagKeywordsForCellDetection.isEmpty() ){
			return false;
		}

		// TODO: Get character lines/segments, read keywords, match minimum N keywords
		int matchCount=0;


		for (String formType : validPagKeywordsForCellDetection.keySet()) {
			Set<String> keywords = validPagKeywordsForCellDetection.get(formType);

			List<String> matchedKeyWords=new ArrayList<String>();

			for ( PDFSegment seg :pageSegments) 
			{
				String segText=seg.getStringRepresentation().trim();
				if(seg.getEnumeration()!=null && !seg.getEnumeration().isEmpty()){
					segText=seg.getStringRepresentation().substring(seg.getStringRepresentation().indexOf(seg.getEnumeration())+1).trim();//(seg.getEnumeration(), "").trim();
				}

				if(keywords.contains(segText)&& !matchedKeyWords.contains(segText))
				{
					matchedKeyWords.add(seg.getStringRepresentation());
					matchCount++;
				}
				/*for (String string : validPagKeywordsForCellDetection) {

				if(segText.contains(string) && !matchedKeyWords.contains(segText))
				{
					matchedKeyWords.add(seg.getStringRepresentation());
					matchCount++;
					break;
				}
			}*/
			}


			if(matchCount>=forPageCellDetection_matching_Limit){
				System.out.println("Valid Page No:\t"+pageSegments.get(0).getRectangle().getPage()+"\tFormType: "+formType);
				return true;
			}
		}
		return false;
	}
	private Map<Integer, List<PDFSegment>> updateSegmentsMap(Map<Integer, List<PDFSegment>> pageSegments, int startPage) {
		// TODO Auto-generated method stub

		/*for (Integer pg : pageSegments.keySet()) {
			if(pg < startPage){
				pageSegments.put(pg, new ArrayList<PDFSegment>());
			}
		}*/

		return pageSegments;
	}

	public void writeStructure(	Map<Integer, List<PDFPara>> pageWiseParas,String filePath, int startPage){
		BufferedWriter writer;
		try {

			writer = new BufferedWriter(new FileWriter(filePath));
			//writer.newLine();
			/*writer.write("\n\n\n ######################## KV pairs "+pairs.size());
			for (Structure p : pairs) {
				if(p instanceof KeyValuePair ){
					KeyValuePair p2 = (KeyValuePair)p;
					writer.write("\n\t"+p2.getKey().getStringRepresentation()+"\t:"+p2.getValueText());
				}
			}*/


			//	writer.write("\n\n ######################## Other Text");
			for (Integer em : pageWiseParas.keySet()) {
				if(!pageWiseParas.get(em).isEmpty() && em>=startPage){
					//writer.newLine();
					//writer.write("\n\t page:"+em);
					for (PDFPara structure : pageWiseParas.get(em)) {
						writer.write("\n#"+structure.getRectangles().get(0).getPage()+"#\t"+(structure.getStringRepresentation()));	
					}
				}
			}

			writer.close();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}

	private Integer detectStartPage(Map<Integer, List<PDFSegment>> map)
	{
		int sartPage=0;

		if(startPageKeywords==null ||startPageKeywords.isEmpty()){
			return sartPage;
		}
		for (Integer pg : map.keySet()) {

			List<PDFSegment>list=map.get(pg);
			if(list!=null && !list.isEmpty()){
				sartPage=list.get(0).getRectangle().getPage();
			}
			// TODO: Get character lines/segments, read keywords, match minimum N keywords

			for (Integer key : startPageKeywords.keySet()) { // template keyword matching on same page
				int matchCount=0;
				List<String> pageStartIndicatorList = startPageKeywords.get(key);
				List<String> matchedKeyWords=new ArrayList<String>();
				for ( PDFSegment seg :list ) 
				{
					for (String string : pageStartIndicatorList) {
						if(seg.getStringRepresentation().contains(string) && !matchedKeyWords.contains(seg.getStringRepresentation()))
						{
							matchedKeyWords.add(seg.getStringRepresentation());
							matchCount++;
							break;
						}
					}
				}
				if(forStartPageDetection_matching_Limit > 0){
					if(matchCount>=forStartPageDetection_matching_Limit){
						System.out.println("It is Starting page\t"+sartPage);
						return list.get(0).getRectangle().getPage();
					}
				}else{
					if(matchCount>=pageStartIndicatorList.size()){
						return list.get(0).getRectangle().getPage();
					}
				}

			}


		}
		return 0;
	}

	public static List<Structure> getKVPairs(Map<Integer, List<PDFSegment>> pageSegments, int startPage){
		List<Structure> pairs = new ArrayList<Structure>();

		for (Integer pg : pageSegments.keySet()) {
			if(pageSegments.get(pg)==null || pg < startPage)
				continue;
			List<StructureGroup> segLists=CommonOperations.groupStructuresOnY(pageSegments.get(pg));
			KeyValueStrategy kv = new KeyValueStrategy(segLists,pageSegments.get(pg));
			kv.apply();

			pairs.addAll(kv.getOutcome());
		}

		return pairs;
	}


	//	public static void main(String[] a) throws Exception {
	//
	//		//Aberdeen Leaders Limited Annual Report 30 June 2016## AWD100200##  Response## Template_3## complaint1
	//		if(a.length<1){
	//			System.out.println("Missing input Arguments");
	//			return;
	//		}
	//
	//		if(a[0].equalsIgnoreCase("file")){ // file "D:/Platform/Phizer/TestSample/Response.pdf"
	//			String inputFile =a[1]; //StartPage.pdf
	//
	//			String outputFilePath =a[2];
	//			//int parallel=Integer.valueOf(a[3]);
	//
	//			final String outputParagraphFileDirPath = basicConfig.getString("outputParagraphFileDirPath");
	//
	//			File file = new File(inputFile);
	//			String ruleTextFile=basicConfig.getString("ruleTextFile");
	//			Set<ExtractionRule> rules=new HashSet<ExtractionRule>();
	//			if(!ruleTextFile.trim().isEmpty()){
	//				String ruleFile=ruleTextFile;
	//				rules = CreateRules.getRulesFromText(ruleFile);
	//				if(rules!=null)
	//					System.out.println("Rule reading From Text Is Done:\t"+rules.size());
	//			}else{
	//				System.out.println("RuleFile Missing");	
	//			}
	//
	//			Extractor_Phizer ph = new Extractor_Phizer(inputFile,rules,outputParagraphFileDirPath);
	//			List<Extraction_Result> res=ph.apply();
	//			if(outputFilePath.isEmpty()){
	//				outputFilePath="Extraction_Result.txt";
	//			}
	//
	//			final BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
	//			writer.write("\n FileName \t PageNum \t Extractioon_Area \t Field_Name \t ResultList");
	//
	//			//	sveResult(res,file,outpuResult);
	//			saveDirResult(res,file,writer);
	//			writer.close();
	//
	//		}else if(a[0].equalsIgnoreCase("dir")){  //dir "D:/Platform/Phizer/TestSample/Type4" "D:/Platform/Phizer/TestSample/Type4\\TestSample1.txt" 1
	//
	//			//"D:/Platform/Phizer/TestSample"
	//
	//			String inputDirPath =a[1];
	//			String outputFilePath =a[2];
	//			int parallel=Integer.valueOf(a[3]);
	//
	//			final String outputParagraphFileDirPath = basicConfig.getString("outputParagraphFileDirPath");
	//
	//			String ruleTextFile=basicConfig.getString("ruleTextFile");
	//
	//			int numOfThreads=Integer.valueOf(basicConfig.getString("numOfThreads"));
	//
	//			Set<ExtractionRule> rulesTemp=new HashSet<ExtractionRule>();
	//			if(!ruleTextFile.trim().isEmpty()){
	//				String ruleFile=ruleTextFile;
	//				rulesTemp = CreateRules.getRulesFromText(ruleFile);
	//				if(rulesTemp!=null)
	//					System.out.println("Rule reading From Text Is Done:\t"+rulesTemp.size());
	//			}else{
	//				System.out.println("RuleFile Missing");	
	//			}
	//
	//			TreeMap<Integer, Set<ExtractionRule>>templateWiseRuleSetHM=new TreeMap<Integer, Set<ExtractionRule>>();
	//			for (ExtractionRule extractionRule : rulesTemp) {
	//				if(templateWiseRuleSetHM.containsKey(extractionRule.getTemplateID())){
	//					Set<ExtractionRule> group = templateWiseRuleSetHM.get(extractionRule.getTemplateID());
	//					group.add(extractionRule);
	//				}else{
	//					Set<ExtractionRule> group =new HashSet<ExtractionRule>();
	//					group.add(extractionRule);
	//					templateWiseRuleSetHM.put(extractionRule.getTemplateID(), group);
	//				}
	//			}
	//			//---------------Template Identification--------------------
	//			int templateID=findTemplateID(""); 
	//			Set<ExtractionRule> finalRuleSet=new HashSet<ExtractionRule>();
	//
	//			if(templateID!=0 && templateWiseRuleSetHM.containsKey(templateID)){
	//				finalRuleSet=templateWiseRuleSetHM.get(templateID);
	//			}else{
	//				finalRuleSet=rulesTemp;
	//			}
	//
	//			final Set<ExtractionRule> rules=new HashSet<ExtractionRule>(finalRuleSet);
	//			Queue<File> inputQ = new LinkedList<File>();
	//			inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));
	//			List<Runnable> threads = new ArrayList<Runnable>();
	//
	//			//final String outputFilePath=outputFileDirPath+File.separator+"Extraction_Result.txt";
	//
	//			final BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));
	//
	//			writer.write("FileName \tPageNum \tExtraction_Area \tField_Name \tResultList \tNLP_Process");
	//
	//			while(!inputQ.isEmpty())
	//			{
	//				final File in = inputQ.poll();
	//				System.out.println("\n##------##--------## Start of "+in.getName());
	//				if(in.isDirectory())//f.getName().startsWith("AWD")){
	//					inputQ.addAll(Arrays.asList(in.listFiles()));
	//
	//				else if(in.getName().toLowerCase().endsWith(".pdf")){
	//					threads.add(new Runnable() {
	//						public void run() {
	//							//Trying to avoid the entire loop to break on exception
	//							try{
	//
	//								Extractor_Phizer ph=new Extractor_Phizer(in.getAbsolutePath(),rules,outputParagraphFileDirPath);
	//								List<Extraction_Result> res=ph.apply();
	//								saveDirResult(res,in,writer);	
	//
	//							}catch(Exception e){e.printStackTrace();}
	//						}
	//					});
	//				}
	//
	//				if(threads.size()>numOfThreads){
	//					MultiThreadHelper.processThreads(threads, parallel);
	//					threads.clear();
	//				}
	//			}
	//
	//			//Remaining threads
	//			if(threads.size()>0){
	//				MultiThreadHelper.processThreads(threads, 2);
	//				threads.clear();
	//			}
	//			writer.close();
	//		}
	//
	//	}

	public static void main(String[] a) throws Exception {

		if(a[0].equalsIgnoreCase("dir")){

			//dir "D:\\Platform\\Phizer\\TestSample\\temp" "D:/Platform/Phizer/ExtractionResult.txt" "D:/Platform/Phizer/TestSample/ParagraphOutput"

			String inputDirPath =a[1];
			String outputFilePath =a[2];
			final String outputParagraphFileDirPath = a[3];


			String ruleTextFile=basicConfig.getString("ruleTextFile");

			//int numOfThreads=Integer.valueOf(basicConfig.getString("numOfThreads"));

			Set<ExtractionRule> rulesTemp=new HashSet<ExtractionRule>();
			if(!ruleTextFile.trim().isEmpty()){
				String ruleFile=ruleTextFile;
				rulesTemp = CreateRules.getRulesFromText(ruleFile);
				if(rulesTemp!=null)
					System.out.println("Rule reading From Text Is Done:\t"+rulesTemp.size());
			}else{
				System.out.println("RuleFile Missing");	
			}

			TreeMap<Integer, Set<ExtractionRule>>templateWiseRuleSetHM=new TreeMap<Integer, Set<ExtractionRule>>();
			for (ExtractionRule extractionRule : rulesTemp) {
				if(templateWiseRuleSetHM.containsKey(extractionRule.getTemplateID())){
					Set<ExtractionRule> group = templateWiseRuleSetHM.get(extractionRule.getTemplateID());
					group.add(extractionRule);
				}else{
					Set<ExtractionRule> group =new HashSet<ExtractionRule>();
					group.add(extractionRule);
					templateWiseRuleSetHM.put(extractionRule.getTemplateID(), group);
				}
			}
			//---------------Template Identification--------------------
			int templateID=findTemplateID(""); 
			Set<ExtractionRule> finalRuleSet=new HashSet<ExtractionRule>();

			if(templateID!=0 && templateWiseRuleSetHM.containsKey(templateID)){
				finalRuleSet=templateWiseRuleSetHM.get(templateID);
			}else{
				finalRuleSet=rulesTemp;
			}

			final Set<ExtractionRule> rules=new HashSet<ExtractionRule>(finalRuleSet);
			Queue<File> inputQ = new LinkedList<File>();
			inputQ.addAll(Arrays.asList(new File(inputDirPath).listFiles()));
			//			List<Runnable> threads = new ArrayList<Runnable>();

			//final String outputFilePath=outputFileDirPath+File.separator+"Extraction_Result.txt";

			final BufferedWriter writer = new BufferedWriter(new FileWriter(outputFilePath));

			writer.write("FileName \tPageNum \tExtraction_Area \tField_Name \tResultList \tNLP_Process \tTemplateID \tRuleID \tInputKeywords");

			while(!inputQ.isEmpty())
			{
				final File in = inputQ.poll();
				long start=System.currentTimeMillis();
				System.out.println("\n##------##--------## Start of "+in.getName()+"\t "+start);
				if(in.isDirectory())//f.getName().startsWith("AWD")){
					inputQ.addAll(Arrays.asList(in.listFiles()));

				else if(in.getName().toLowerCase().endsWith(".pdf")){

					try
					{

						Extractor_Phizer ph=new Extractor_Phizer(in.getAbsolutePath(),rules,outputParagraphFileDirPath);
						List<Extraction_Result> res=ph.apply();
						saveDirResult(res,in,writer);	
						System.out.println("\n***********##------##--------## End of\t"+in.getAbsolutePath()+"\t "+(System.currentTimeMillis()-start)/1000);
					}catch(Exception e)
					{
						e.printStackTrace();
					}
				}

			}


			writer.close();
		}

	}

	private static int findTemplateID(String inputFile) {
		/*File f=new File(inputFile);
		PDDocument pdf = null;
		try {
			pdf = PDDocument.load(f);

			pdf.setAllSecurityToBeRemoved(true);
			if(pdf.isEncrypted()){
				try {
					pdf.decrypt("");
				} catch (CryptographyException e) {
					e.printStackTrace();
				}
			}
			pdf.setAllSecurityToBeRemoved(true);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		DefaultParser parser = new DefaultParser(pdf);
		parser.parse();
		Map<Integer, List<PDFSegment>> pageSegments = parser.getSegments();*/
		//read input keywords and check wich set of keyWord is going to match and return its template id

		return 0;
	}

	private static void saveDirResult(List<Extraction_Result> res, File file, BufferedWriter writer) {
		// TODO Auto-generated method stub

		try {
			/*int fileID=-1;
			try{
				fileID=Integer.valueOf(file.getName().trim());
			}catch (Exception e){
				//System.out.println("String fileID \t"+file.getName());
			}*/
			System.out.println("\n\n************************************ Extraction ----Resut -----");
			String fileName=file.getName().substring(0, file.getName().lastIndexOf("."));
			StringBuffer strb=new StringBuffer();

			for (Extraction_Result rs : res) {
				ExtractionRule r = rs.getRule();
				if(rs.getOutputList().isEmpty())
					continue;

				String extraction_Area="";
				if(r.getExtractionArea().toLowerCase().contains("checkbox")){
					extraction_Area="CheckBox";
				}else if(r.getExtractionArea().toLowerCase().contains("cell")){
					extraction_Area="Cell";
				}else{
					extraction_Area=r.getExtractionArea();
				}


				List<String> resultList = rs.getOutputList();
				if(resultList!=null && !resultList.isEmpty()){
					String inputKeyword=r.getKeywords();
					if(inputKeyword.contains("##")){
						inputKeyword=inputKeyword.split("##")[0];
					}
					for (String extraction_Result : resultList) {

						System.out.println("\n"+fileName+"\t"+r.getTemplateID()+"\t"+r.getRuleId()+"\t"+r.getFieldName()+"\t"+
								inputKeyword+"\t"+extraction_Area+"\t"+
								r.getDataType()+"\t"+rs.getNodeId()+"\t"+(int)rs.getyCoordinate()+"\t"+extraction_Result+"\t"+r.getNLP_Process()+"\t"+r.getTemplateID()+"\t"+r.getRuleId()+"\t"+r.getKeywords());

						strb.append("\n"+fileName+"\t"+rs.getPage()+"\t"+extraction_Area+"\t"+r.getFieldName()+"\t"+extraction_Result+"\t"+r.getNLP_Process()+"\t"+r.getTemplateID()+"\t"+r.getRuleId()+"\t"+r.getKeywords());

					}
				}
			}

			synchronized (lock) {
				writer.write(strb.toString());
				writer.flush();
			}
			//	System.out.println("\n************************************End of\t"+file.getAbsolutePath()+"\t "+System.currentTimeMillis());
		}catch (Exception e){
			e.printStackTrace();
		}
	}
}
