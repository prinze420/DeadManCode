package com.pdf.parser.complex.strategy.configBasedTable;

import java.util.ArrayList;
import java.util.List;

import com.pdf.parser.base.BasicStructure;
import com.pdf.parser.base.DPRectangle;
import com.pdf.parser.base.PDFSegment;
import com.pdf.parser.utils.CommonOperations;

/**
 * Group segments based on Y
 * @author Shishir.Mane
 *
 */
public class StructureGroup {
	float y;
	int page;
	List<? extends BasicStructure> segments;
	
	public StructureGroup(float y, int page){
		this.y = y;
		this.page = page;
		segments = new ArrayList<BasicStructure>();
	}
	
	public int getPage() {
		return page;
	}

	public boolean contains(PDFSegment seg){
		return segments.contains(seg);
	}
	
	public int indexOf(PDFSegment seg){
		return segments.indexOf(seg);
	}

	@Override
	public String toString() {
		String str = "";
		for(BasicStructure s : segments){
			if(s!=null)
				str += s.getStringRepresentation()+" ";
		}
		return str.trim();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(y);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StructureGroup other = (StructureGroup) obj;
		if (Float.floatToIntBits(y) != Float.floatToIntBits(other.y))
			return false;
		return true;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public List<BasicStructure> getBasicStructures() {
		List<BasicStructure> bs = new ArrayList<BasicStructure>(segments);
		segments = bs;
		
		return bs;
	}
	
	public DPRectangle getRect(){
		DPRectangle rect = null;
		
		for(BasicStructure bs : segments){
			if(rect == null)
				rect = bs.getRectangle();
			else
				rect = CommonOperations.merge(rect, bs.getRectangle());
		}
		
		return rect;
	}
	
	public void setSegments(List<? extends BasicStructure> segments){
		this.segments = segments;
	}
	
	public int getSegmentsSize(){
		return segments.size();
	}
	
	public List<PDFSegment> getCastedPDFSegments(){
		List<PDFSegment> segs = new ArrayList<PDFSegment>();
		
		for(BasicStructure s : new ArrayList<BasicStructure>(segments)){
			segs.add((PDFSegment)s);
		}
		
		segments = segs;
		return segs;
	}
}	
